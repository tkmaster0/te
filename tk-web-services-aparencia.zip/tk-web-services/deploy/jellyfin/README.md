# Jellyfin

O código para os plugins do Jellyfin é servido pelo próprio portal, já com o endereço certo:

- **Admin → Jellyfin** (no portal): o que instalar e colar, passo a passo, com botões de copiar:
  1. repositórios de plugins (JavaScript Injector, Custom Pages, Jellyfin Security);
  2. **JavaScript Injector** — o ícone "Ajuda" (assistente) em todas as páginas: o carregador de 3 linhas que vai buscar `https://<portal>/jellyfin/widget.js`;
  3. **Custom Pages** — a página "A minha conta" (`https://<portal>/jellyfin/conta.html`);
  4. botão "Entrar com a conta TK" para o plugin 9p4 SSO (`sso-login-button.html` aqui);
  5. **apps nativas** (Android TV, Swiftfin, Moonfin, Roku…) — botão que cria/atualiza a coleção "Ajuda" no Jellyfin, com cartaz e fundo com QR code para `https://<portal>/ajuda` e o WhatsApp do assistente.

Compatibilidade: o botão "Ajuda" funciona onde corre o jellyfin-web (browser, apps Android/iOS, Jellyfin Desktop, Samsung Tizen e LG webOS — estas em modo TV, navegável com o comando). As apps nativas (Jellyfin Android TV, Swiftfin, Moonfin em todas as plataformas, Roku, Kodi…) não executam JavaScript do servidor: aí o ponto de entrada é a coleção "Ajuda".
- `sso-plugin-config.json` — configuração de exemplo do plugin 9p4 SSO (o cliente OIDC é criado em Admin → SSO).

Os ficheiros-fonte do widget e da página estão em `backend/app/jellyfin_files/`.
