#!/bin/sh
# TK Web Services — ponto de entrada do contentor.
#   aio    → TUDO num contentor (por omissão): PostgreSQL + portal (API, fila de jobs, tarefas, túnel Cloudflare)
#            + cópia diária da base de dados. Um só volume: /data.
#   all    → só o portal (API + fila + tarefas), com a base de dados noutro sítio (DATABASE_URL)
#   api    → só a API (para separar API e worker em dois contentores)
#   worker → só a fila de jobs e as tarefas periódicas
#   cli    → comandos de gestão: create-admin, import-legacy, ...
set -e

DATA="${TKWS_DATA:-/data}"
PGBIN="${PGBIN:-/usr/local/pgbin}"
PGSOCK=/tmp

gen() { head -c 512 /dev/urandom | tr -dc 'A-Za-z0-9' | head -c "$1"; }

# Segredos da instalação: gerados no primeiro arranque e guardados no volume — não é preciso .env nenhum. Um
# SECRET_KEY / DATABASE_URL vindo do ambiente (ex.: .env antigo) tem sempre prioridade.
load_secrets() {
  d="${TKWS_SECRETS_DIR:-/var/lib/tkws}"
  if [ -z "$SECRET_KEY" ] && [ -r "$d/secret_key" ]; then
    SECRET_KEY="$(cat "$d/secret_key")"; export SECRET_KEY
  fi
  if [ -z "$DATABASE_URL" ] && [ -r "$d/db_password" ]; then
    DATABASE_URL="postgresql+asyncpg://tkws:$(cat "$d/db_password")@${TKWS_DB_HOST:-tkws-db}:5432/tkws"
    export DATABASE_URL
  fi
  if [ -z "$SECRET_KEY" ]; then
    echo "Sem SECRET_KEY: arranca com o docker-compose.yml do projeto (gera-a sozinho) ou define-a no .env." >&2
    exit 1
  fi
}

serve() {
  # O IP real do cliente é resolvido pela própria aplicação (TRUSTED_PROXIES). Com "*" o uvicorn aceitava o
  # X-Forwarded-For de qualquer origem e o rate limiting por IP deixava de valer.
  exec uvicorn app.main:app --host 0.0.0.0 --port ${PORT:-8000} --proxy-headers --no-access-log \
       --forwarded-allow-ips="${FORWARDED_ALLOW_IPS:-127.0.0.1}" --workers "$1"
}

migrate() {
  # A base de dados pode ainda estar a arrancar ou a recuperar: esperar por ela.
  i=0
  until alembic upgrade head; do
    i=$((i + 1))
    [ "$i" -ge 30 ] && { echo "Base de dados inacessível — desisto." >&2; exit 1; }
    echo "Base de dados ainda não disponível (tentativa $i/30) — nova tentativa em 5 s…" >&2
    sleep 5
  done
}

# ------------------------------------------------------------------------------------------------ tudo-em-um
aio_secrets() {
  s="$DATA/secrets"
  mkdir -p "$s" "$DATA/backups"
  chmod 0700 "$s"
  # Valores de um .env antigo passam a ser os guardados; senão são gerados uma vez.
  if [ -n "$TKWS_DB_PASSWORD" ]; then printf %s "$TKWS_DB_PASSWORD" > "$s/db_password"
  elif [ ! -s "$s/db_password" ]; then gen 40 > "$s/db_password"; echo "Password da base de dados gerada."; fi
  if [ -n "$SECRET_KEY" ]; then printf %s "$SECRET_KEY" > "$s/secret_key"
  elif [ ! -s "$s/secret_key" ]; then gen 64 > "$s/secret_key"; echo "SECRET_KEY gerada."; fi
  chmod 0600 "$s/db_password" "$s/secret_key"
  export TKWS_SECRETS_DIR="$s"
}

pg_start() {
  PGDATA="$DATA/postgres"
  new=""
  if [ ! -s "$PGDATA/PG_VERSION" ]; then
    echo "Base de dados: a criar em $PGDATA…"
    pw="$(mktemp)"; cat "$TKWS_SECRETS_DIR/db_password" > "$pw"
    "$PGBIN/initdb" -D "$PGDATA" -U tkws --pwfile="$pw" -E UTF8 --locale=C \
                    --auth-local=trust --auth-host=scram-sha-256 >/dev/null
    rm -f "$pw"
    new=1
  fi
  # Só dentro do contentor: socket em /tmp e TCP em 127.0.0.1 (nada exposto).
  "$PGBIN/postgres" -D "$PGDATA" -c listen_addresses=127.0.0.1 -c port=5432 -c unix_socket_directories="$PGSOCK" \
                    -c shared_buffers=64MB -c max_connections=40 -c logging_collector=off &
  PG_PID=$!
  i=0
  until "$PGBIN/pg_isready" -q -h "$PGSOCK" -U tkws -d postgres; do
    kill -0 "$PG_PID" 2>/dev/null || { echo "O PostgreSQL não arrancou." >&2; exit 1; }
    i=$((i + 1)); [ "$i" -ge 120 ] && { echo "O PostgreSQL não respondeu." >&2; exit 1; }
    sleep 1
  done
  [ -n "$new" ] && "$PGBIN/createdb" -h "$PGSOCK" -U tkws tkws
  # A password guardada é sempre a do utilizador tkws (ex.: depois de mudar o TKWS_DB_PASSWORD).
  printf "ALTER USER tkws PASSWORD :'pw';\n" | "$PGBIN/psql" -q -h "$PGSOCK" -U tkws -d postgres \
      -v pw="$(cat "$TKWS_SECRETS_DIR/db_password")" >/dev/null
  echo "Base de dados pronta (PostgreSQL $(cat "$PGDATA/PG_VERSION"))."
}

pg_stop() {
  # Paragem "fast": desliga as ligações e grava tudo (sem recuperação no arranque seguinte).
  if [ -n "$PG_PID" ] && kill -0 "$PG_PID" 2>/dev/null; then
    kill -INT "$PG_PID" 2>/dev/null || true
    wait "$PG_PID" 2>/dev/null || true
  fi
}

shutdown() {
  echo "A parar (portal e base de dados)…"
  kill -TERM "$APP_PID" 2>/dev/null || true
  kill "$BK_PID" 2>/dev/null || true
  pg_stop
  wait "$APP_PID" 2>/dev/null || true
}

backups() {
  # Uma cópia por dia em /data/backups (a primeira 10 minutos depois de arrancar); guarda TKWS_BACKUP_KEEP_DAYS dias.
  keep="${TKWS_BACKUP_KEEP_DAYS:-14}"
  sleep 600
  while true; do
    f="$DATA/backups/tkws-$(date +%Y%m%d-%H%M).dump"
    if "$PGBIN/pg_dump" -h "$PGSOCK" -U tkws -Fc -f "$f.part" tkws; then mv "$f.part" "$f"; echo "Cópia da base de dados: $f"
    else rm -f "$f.part"; echo "Cópia da base de dados FALHOU" >&2; fi
    find "$DATA/backups" -name 'tkws-*.dump' -mtime +"$keep" -delete 2>/dev/null || true
    sleep 86400
  done
}

aio() {
  if [ -n "$DATABASE_URL" ]; then
    # Base de dados externa (ex.: instalação antiga com tkws-db): só o portal.
    load_secrets; migrate; export RUN_WORKER_IN_API=true; serve 1
  fi
  aio_secrets
  pg_start
  export DATABASE_URL="postgresql+asyncpg://tkws:$(cat "$TKWS_SECRETS_DIR/db_password")@127.0.0.1:5432/tkws"
  load_secrets
  backups &
  BK_PID=$!
  migrate
  export RUN_WORKER_IN_API=true
  uvicorn app.main:app --host 0.0.0.0 --port ${PORT:-8000} --proxy-headers --no-access-log \
          --forwarded-allow-ips="${FORWARDED_ALLOW_IPS:-127.0.0.1}" --workers 1 &
  APP_PID=$!
  trap 'shutdown; exit 0' TERM INT
  # Se o portal ou a base de dados pararem, o contentor termina e o Docker volta a arrancá-lo.
  while kill -0 "$APP_PID" 2>/dev/null && kill -0 "$PG_PID" 2>/dev/null; do sleep 2; done
  echo "Um dos processos terminou — a reiniciar o contentor." >&2
  shutdown
  exit 1
}

case "$1" in
  aio)
    aio
    ;;
  all)
    load_secrets
    migrate
    # Um só processo: a fila de jobs, o agendador e os limites de pedidos (em memória) têm de ser únicos.
    export RUN_WORKER_IN_API=true
    serve 1
    ;;
  api)
    load_secrets
    migrate
    serve "${WEB_WORKERS:-1}"
    ;;
  worker)
    load_secrets
    exec python -m app.worker
    ;;
  cli)
    shift
    [ -d "$DATA/secrets" ] && export TKWS_SECRETS_DIR="${TKWS_SECRETS_DIR:-$DATA/secrets}"
    [ -z "$DATABASE_URL" ] && [ -r "$DATA/secrets/db_password" ] && \
      export DATABASE_URL="postgresql+asyncpg://tkws:$(cat "$DATA/secrets/db_password")@127.0.0.1:5432/tkws"
    load_secrets
    exec python -m app.cli "$@"
    ;;
  *)
    exec "$@"
    ;;
esac
