#!/bin/sh
# TK Web Services — ajuda OPCIONAL para a mesma máquina do TKFLIX. O arranque normal é só:
#     docker compose up -d        (e o resto configura-se por web em http://<IP>:8090)
#
# Este script cria a rede "tkflix-link", liga o contentor do DUMB a ela (alias DUMB) e arranca o portal com o
# docker-compose.tkflix-link.yml — para o portal falar com o DUMB por dentro (http://DUMB:8096…).
#   DUMB_CONTAINER=<nome>  se o contentor do DUMB não se chamar "DUMB".
set -e
cd "$(dirname "$0")/.."
DUMB="${DUMB_CONTAINER:-DUMB}"

say() { printf '\n\033[1;33m» %s\033[0m\n' "$*"; }
warn() { printf '\033[1;31m! %s\033[0m\n' "$*" >&2; }

say "Rede partilhada com o TKFLIX (tkflix-link)"
docker network inspect tkflix-link >/dev/null 2>&1 || docker network create tkflix-link
if docker ps --format '{{.Names}}' | grep -qx "$DUMB"; then
  docker network connect --alias DUMB tkflix-link "$DUMB" 2>/dev/null && echo "DUMB ligado à tkflix-link." \
    || echo "DUMB já estava na tkflix-link."
else
  warn "Não encontrei o contentor '$DUMB'. Liga-o depois:  docker network connect --alias DUMB tkflix-link <contentor>"
fi

if ! grep -qs '^COMPOSE_FILE=.*tkflix-link' .env; then
  say "A juntar COMPOSE_FILE ao .env (para o 'docker compose up -d' usar sempre a rede tkflix-link)"
  printf '\nCOMPOSE_FILE=docker-compose.yml:docker-compose.tkflix-link.yml\n' >> .env
fi

say "Arrancar"
mkdir -p backups
docker compose up -d --build --remove-orphans

say "À espera que o portal responda…"
PORT="$(sed -n 's/^TKWS_PORT=//p' .env 2>/dev/null | tail -n 1)"; PORT="${PORT:-8090}"
i=0
until curl -fsS "http://127.0.0.1:$PORT/api/health" >/dev/null 2>&1; do
  i=$((i + 1)); [ "$i" -ge 80 ] && { warn "O portal não arrancou — vê: docker compose logs tkws"; exit 1; }
  sleep 3
done
if docker exec "$DUMB" sh -c 'command -v curl >/dev/null && curl -fsS http://tk-web-services:8000/api/health || wget -qO- http://tk-web-services:8000/api/health' >/dev/null 2>&1; then
  echo "DUMB → portal (por dentro): OK"
fi

say "Pronto. Abre http://<IP do servidor>:$PORT, entra com testews / testews e segue o assistente."
echo "Nos endereços do Jellyfin/Seerr/TV usa o atalho \"DUMB\" (http://DUMB:<porta>)."
