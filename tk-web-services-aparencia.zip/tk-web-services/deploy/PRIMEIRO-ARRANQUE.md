# Primeiro arranque — TK Web Services

## Um comando
Na pasta do projeto (onde está o `docker-compose.yml`):

```bash
docker compose up -d
```

Fica **um só contentor**, `tk-web-services`, como o DUMB: portal + base de dados (PostgreSQL) + cópias diárias + túnel Cloudflare, com tudo guardado no volume `tkws_data`. Na primeira vez a imagem é construída (alguns minutos), a base de dados é criada com uma password e uma `SECRET_KEY` geradas, e as migrações correm (ficam criados o TKFLIX, em beta fechado, e o TKGPT). Não é preciso `.env` — a não ser para o token do túnel.

## Túnel ligado logo no arranque (sem acesso pela rede local)
Põe o token do túnel num ficheiro `.env` ao lado do `docker-compose.yml`:
```
CLOUDFLARE_TUNNEL_TOKEN=eyJ...
```
O `cloudflared` embutido arranca com o portal. No painel da Cloudflare, o Public Hostname pode apontar para `http://localhost:8000` (recomendado) — ou continuar em `http://localhost:8090` / `:8080` / `:80`, que o portal também atende dentro do contentor. Depois podes mudar o token por web (Admin → Configuração → Túnel), que passa a ter prioridade.

### Erro 1033 no browser (o túnel não tem nenhum conector ligado)
```bash
docker ps                                                     # o tk-web-services está "Up (healthy)"?
docker logs tk-web-services 2>&1 | grep -i "túnel\|cloudflared" | tail -30
```
- **"sem token"** → o token não chegou ao contentor: o `.env` tem de estar na mesma pasta do `docker-compose.yml` (é um ficheiro escondido — confirma com `ls -a`). No Portainer/Dockge põe `CLOUDFLARE_TUNNEL_TOKEN` nas variáveis da stack.
- **"Failed to dial a quic connection" / "Allow outbound QUIC traffic on port 7844"** → a rede bloqueia UDP: põe `CLOUDFLARE_TUNNEL_PROTOCOL=http2` no `.env` (precisa de TCP 7844 de saída) e `docker compose up -d`.
- **"Registered tunnel connection"** → está ligado; se continuar o erro, confirma no painel que o hostname está neste túnel e aponta para `http://localhost:8000`.
- **Sem nenhuma linha do túnel / contentor a reiniciar** → `docker logs tk-web-services | tail -50`.

## O resto é por web
1. Abre **`http://<IP do servidor>:8090/registar`** e cria a conta com o email **`geral@tkmasterproductions.eu`** (username e password à tua escolha). Fica logo **administradora, sem código OTP** nem convite. Faz isto logo a seguir ao arranque: o atalho só vale enquanto não existir nenhum administrador.
2. O **assistente de configuração** abre sozinho. Cada passo grava logo e podes saltar o que não usas:

   | Passo | O que fazes |
   |---|---|
   | A tua conta | Confirmas a conta de administrador |
   | Endereço público | "usar este endereço" ou o teu domínio (ex.: `https://tkws.tkflix.eu`) |
   | Túnel Cloudflare | Crias o túnel na Cloudflare (link direto), Public Hostname → **`http://localhost:8000`**, e colas o token |
   | Email | SMTP + "Guardar e testar" (envia-te um email) |
   | Pagamentos | GoCardless: token + webhook (URL pronto a copiar e link para a página). Stripe: chaves + **"Criar webhook automaticamente"** |
   | Jellyfin, Seerr e TV | Endereços (atalhos "anfitrião"/"DUMB") e API keys + "Testar ligação" |
   | SSO e Jellyfin | "Criar / atualizar" os clientes OIDC e o bloco do LibreChat (TKGPT); **Admin → Jellyfin** tem o que colar nos plugins e o botão da coleção "Ajuda" para as apps de TV |
   | Serviços e planos | O preço do TKGPT, outros produtos, preços e automações (webhooks) — nada a criar na GoCardless/Stripe |
   | Clientes antigos | **Admin → Migração**: arrastas o `users.db`, simulas, importas e ligas as subscrições GoCardless |
3. "Concluir". Tudo pode ser mudado depois em **Admin → Configuração** (aplicado na hora, sem reiniciar) — incluindo mais emails de administrador, sessões, assistente de IA, WhatsApp, carteira e logs.

Depois do túnel ligado, podes fechar a porta 8090 ao exterior com um `.env` com `TKWS_BIND=127.0.0.1` e `docker compose up -d`.

## Instalações que já tinham `.env`
Continuam a funcionar sem mudar nada: o `SECRET_KEY` e o `TKWS_DB_PASSWORD` do `.env` passam a ser os valores guardados, e o `CLOUDFLARED_TOKEN` é usado pelo túnel embutido. No painel do túnel, o Service do hostname do portal deve ser **`http://localhost:8000`** (o contentor `tk-web-services-tunnel` antigo já não existe — `docker compose up -d --remove-orphans` apaga-o).

## Mesma máquina do TKFLIX: rede com o DUMB (opcional)
Para o portal falar com o DUMB por dentro (`http://DUMB:8096`…) em vez de `http://host.docker.internal:<porta>`:
```bash
sh deploy/primeiro-arranque.sh          # cria a rede tkflix-link e liga o DUMB (DUMB_CONTAINER=<nome> se for outro)
```
e num `.env`: `COMPOSE_FILE=docker-compose.yml:docker-compose.tkflix-link.yml`. Para sobreviver a recriações do DUMB, acrescenta `deploy/dumb/docker-compose.dumb-network.yml` ao compose dele.

## Forward-auth nas UIs do DUMB (opcional)
Copia `deploy/dumb/traefik-tkws-auth.yml` para `traefik/dynamic/` do DUMB e junta `tkws-admin@file` aos routers a proteger. Com *Bot Fight Mode*/WAF na Cloudflare, cria uma regra **Skip** no host do portal para `/.well-known/*`, `/oidc/*`, `/auth/verify` e `/api/webhooks/*`.

## Problemas
### "Bad gateway" (502) de fora, mas o portal responde em `http://IP:8090`
O Public Hostname do túnel tem de apontar para **`http://localhost:8000`** (o cloudflared está dentro do contentor do portal). Em Admin → Definições → Túnel vês o estado e o registo do túnel.

| Onde corre o cloudflared desse túnel | Service |
|---|---|
| Dentro do portal (token em Definições → Túnel) | `HTTP` → `localhost:8000` |
| Dentro do DUMB (rede `tkflix-link`) | `HTTP` → `tk-web-services:8000` |
| Instalado no anfitrião (serviço do sistema) | `HTTP` → `localhost:8090` |

### Erro na imagem `tk-web-services`
A imagem é **construída a partir desta pasta** (o `Dockerfile`, o `backend/` e o `frontend/` têm de estar ao lado do `docker-compose.yml`); nunca é descarregada (`pull_policy: build`).
- "pull access denied" / "No such image": corre `docker compose build` na pasta e depois `docker compose up -d`.
- Portainer / Dockge com a stack colada no editor web (sem o código): constrói uma vez no terminal e põe `TKWS_PULL_POLICY=never` na stack — ou usa a imagem publicada pelo GitHub (`TKWS_IMAGE=ghcr.io/<conta>/tk-web-services:latest`, `TKWS_PULL_POLICY=always`, `.github/workflows/imagem.yml`).
- Para atualizar: `docker compose up -d --build`.

### Esqueci-me da password do administrador
```bash
docker compose exec tkws /entrypoint.sh cli create-admin --email tu@exemplo.pt --username tkmaster
```

## Cópias de segurança
Uma por dia em `/data/backups` (dentro do volume), durante 14 dias. Traz-as para fora com `docker cp tk-web-services:/data/backups ./backups` e guarda-as fora do servidor, juntamente com a `SECRET_KEY` (`docker exec tk-web-services cat /data/secrets/secret_key`).
