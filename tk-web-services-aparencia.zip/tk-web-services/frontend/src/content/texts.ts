/**
 * Textos do portal editáveis em Admin → Aparência → Textos.
 *
 * Cada texto tem uma chave, o grupo onde aparece no editor e o texto por omissão. O admin só guarda o que muda;
 * vazio volta ao texto daqui. `{chave}` é substituído (ex.: {app} = nome do portal, {empresa} = nome da empresa).
 * Para tornar um texto novo editável: acrescenta-o aqui e usa `t('chave')` (hook useText) no componente.
 */
export interface TextDef {
  group: string
  label: string
  default: string
  multiline?: boolean
  vars?: string[]
}

const G = {
  meta: 'Separador do browser e partilha de links',
  brand: 'Marca',
  landing: 'Página inicial',
  auth: 'Entrar, registo e password',
  nav: 'Menu da área de cliente',
  app: 'Área de cliente',
}

export const TEXTS = {
  // ------------------------------------------------------------------------------------------- fora do portal
  'meta.title': { group: G.meta, label: 'Título do separador (e das pré-visualizações de links)', default: 'TK Web Services' },
  'meta.description': {
    group: G.meta,
    label: 'Descrição (motores de busca e pré-visualizações de links)',
    default: 'A plataforma de serviços digitais da TKmaster Productions.',
    multiline: true,
  },
  'brand.wordmark.strong': { group: G.brand, label: 'Logótipo em texto — parte em destaque', default: 'TK' },
  'brand.wordmark.rest': { group: G.brand, label: 'Logótipo em texto — resto', default: 'Web Services' },
  'brand.company': { group: G.brand, label: 'Nome da empresa (rodapé, página inicial)', default: 'TKmaster Productions' },

  // ------------------------------------------------------------------------------------------- página inicial
  'landing.nav.products': { group: G.landing, label: 'Menu — Produtos', default: 'Produtos' },
  'landing.nav.platform': { group: G.landing, label: 'Menu — Plataforma', default: 'Plataforma' },
  'landing.nav.faq': { group: G.landing, label: 'Menu — Perguntas', default: 'Perguntas' },
  'landing.header.login': { group: G.landing, label: 'Botão do topo — Entrar', default: 'Entrar' },
  'landing.header.console': { group: G.landing, label: 'Botão do topo — com sessão iniciada', default: 'Consola' },
  'landing.hero.eyebrow': { group: G.landing, label: 'Etiqueta por cima do título', default: '{empresa}', vars: ['empresa'] },
  'landing.hero.title': { group: G.landing, label: 'Título — primeira parte', default: 'TK' },
  'landing.hero.title_highlight': { group: G.landing, label: 'Título — parte em destaque (cor)', default: 'Web Services' },
  'landing.hero.text': {
    group: G.landing,
    label: 'Texto por baixo do título',
    default: 'A plataforma de serviços digitais da {empresa}. Adere, gere e acompanha tudo a partir de uma única consola.',
    multiline: true,
    vars: ['empresa'],
  },
  'landing.cta.register_open': { group: G.landing, label: 'Botão de registo (registo aberto)', default: 'Criar conta' },
  'landing.cta.register_invite': { group: G.landing, label: 'Botão de registo (só com convite)', default: 'Tenho um convite' },
  'landing.cta.login': { group: G.landing, label: 'Botão Entrar na consola', default: 'Entrar na consola' },
  'landing.cta.console': { group: G.landing, label: 'Botão para quem já tem sessão', default: 'Abrir a consola' },
  'landing.products.eyebrow': { group: G.landing, label: 'Produtos — etiqueta', default: 'Produtos' },
  'landing.products.title': { group: G.landing, label: 'Produtos — título', default: 'Serviços TKWS' },
  'landing.products.text': { group: G.landing, label: 'Produtos — texto', default: 'Um catálogo que vai crescendo. Ativa o que precisas, quando precisas.' },
  'landing.products.cta_guest': { group: G.landing, label: 'Produtos — botão (sem sessão)', default: 'Começar' },
  'landing.products.cta_user': { group: G.landing, label: 'Produtos — botão (com sessão)', default: 'Ver na consola' },
  'landing.products.locked': { group: G.landing, label: 'Produtos — etiqueta dos serviços por convite', default: 'por convite' },
  'landing.products.from': { group: G.landing, label: 'Produtos — preço', default: 'desde {preco}/mês', vars: ['preco'] },
  'landing.products.empty_title': { group: G.landing, label: 'Produtos — sem serviços (título)', default: 'Novos serviços a caminho' },
  'landing.products.empty_text': { group: G.landing, label: 'Produtos — sem serviços (texto)', default: 'Cria a tua conta TKWS e serás dos primeiros a ter acesso.' },
  'landing.platform.eyebrow': { group: G.landing, label: 'Plataforma — etiqueta', default: 'Plataforma' },
  'landing.platform.title': { group: G.landing, label: 'Plataforma — título', default: 'Feita para ser simples.' },
  'landing.platform.1.title': { group: G.landing, label: 'Plataforma — ponto 1 (título)', default: 'Uma consola' },
  'landing.platform.1.text': { group: G.landing, label: 'Plataforma — ponto 1 (texto)', default: 'Todos os serviços, contas e faturas num só lugar.' },
  'landing.platform.2.title': { group: G.landing, label: 'Plataforma — ponto 2 (título)', default: 'Uma identidade' },
  'landing.platform.2.text': { group: G.landing, label: 'Plataforma — ponto 2 (texto)', default: 'A mesma conta TKWS para entrar em tudo.' },
  'landing.platform.3.title': { group: G.landing, label: 'Plataforma — ponto 3 (título)', default: 'Segurança' },
  'landing.platform.3.text': { group: G.landing, label: 'Plataforma — ponto 3 (texto)', default: 'Autenticação em dois passos e parceiros de pagamento certificados.' },
  'landing.platform.4.title': { group: G.landing, label: 'Plataforma — ponto 4 (título)', default: 'Suporte' },
  'landing.platform.4.text': { group: G.landing, label: 'Plataforma — ponto 4 (texto)', default: 'Assistente sempre disponível e uma equipa por trás.' },
  'landing.faq.eyebrow': { group: G.landing, label: 'Perguntas — etiqueta', default: 'Perguntas frequentes' },
  'landing.faq.title': { group: G.landing, label: 'Perguntas — título', default: 'Dúvidas?' },
  'landing.final.title': { group: G.landing, label: 'Faixa final — título', default: 'Começa hoje com a TKWS.' },
  'landing.final.text': { group: G.landing, label: 'Faixa final — texto', default: 'Uma conta para todos os serviços da {empresa}.', vars: ['empresa'] },

  // ------------------------------------------------------------------------------------------- entrar e registo
  'auth.login.title': { group: G.auth, label: 'Entrar — título', default: 'Entrar' },
  'auth.login.description': { group: G.auth, label: 'Entrar — texto', default: 'Bem-vindo de volta à {app}.', vars: ['app'] },
  'auth.register.title': { group: G.auth, label: 'Registo — título', default: 'Criar conta' },
  'auth.register.description_open': { group: G.auth, label: 'Registo — texto (registo aberto)', default: 'Cria a tua conta em menos de um minuto.' },
  'auth.register.description_invite': {
    group: G.auth,
    label: 'Registo — texto (só com convite)',
    default: 'A {app} funciona por convite. Usa o código que recebeste.',
    vars: ['app'],
  },
  'auth.forgot.title': { group: G.auth, label: 'Recuperar password — título', default: 'Recuperar password' },
  'auth.forgot.description': {
    group: G.auth,
    label: 'Recuperar password — texto',
    default: 'Indica o email da tua conta e enviamos-te um link para definires uma nova password.',
  },
  'auth.reset.title': { group: G.auth, label: 'Nova password — título', default: 'Nova password' },
  'auth.reset.description': { group: G.auth, label: 'Nova password — texto', default: 'Escolhe uma password nova para a tua conta TKWS.' },

  // ------------------------------------------------------------------------------------------- menu
  'nav.app.home': { group: G.nav, label: 'Início', default: 'Início' },
  'nav.app.services': { group: G.nav, label: 'Os meus serviços', default: 'Os meus serviços' },
  'nav.app.services_short': { group: G.nav, label: 'Os meus serviços (barra do telemóvel)', default: 'Serviços' },
  'nav.app.store': { group: G.nav, label: 'Loja', default: 'Loja' },
  'nav.app.wallet': { group: G.nav, label: 'Carteira', default: 'Carteira' },
  'nav.app.billing': { group: G.nav, label: 'Faturação', default: 'Faturação' },
  'nav.app.games': { group: G.nav, label: 'Jogos', default: 'Jogos' },
  'nav.app.invites': { group: G.nav, label: 'Convites', default: 'Convites' },
  'nav.app.account': { group: G.nav, label: 'Conta', default: 'Conta' },
  'nav.app.help': { group: G.nav, label: 'Ajuda', default: 'Ajuda' },

  // ------------------------------------------------------------------------------------------- área de cliente
  'app.home.newcomer': { group: G.app, label: 'Início — texto para contas novas', default: 'Bem-vindo à {app}. Começa por escolher um serviço.', vars: ['app'] },
  'app.home.attention': { group: G.app, label: 'Início — há pendentes', default: 'Há coisas que precisam da tua atenção.' },
  'app.home.ok': { group: G.app, label: 'Início — tudo em ordem', default: 'Está tudo em ordem.' },
  'app.services.title': { group: G.app, label: 'Os meus serviços — título', default: 'Os meus serviços' },
  'app.services.description': { group: G.app, label: 'Os meus serviços — texto', default: 'Tudo o que tens ativo: acessos, opções e o que muda em cada serviço.' },
  'app.store.title': { group: G.app, label: 'Loja — título', default: 'Loja' },
  'app.store.description': {
    group: G.app,
    label: 'Loja — texto',
    default: 'Junta serviços à tua conta. Tudo é pago numa só cobrança mensal, com o mesmo método de pagamento.',
  },
  'app.billing.title': { group: G.app, label: 'Faturação — título', default: 'Faturação' },
  'app.billing.description': {
    group: G.app,
    label: 'Faturação — texto',
    default: 'Uma só cobrança por mês, com todos os teus serviços. Aqui vês o que vais pagar, como pagas e o histórico.',
  },
  'app.wallet.title': { group: G.app, label: 'Carteira — título', default: 'Carteira' },
  'app.wallet.description': { group: G.app, label: 'Carteira — texto', default: 'Os teus créditos pagam os serviços antes de qualquer cobrança. 1 crédito = 1 €.' },
  'app.games.title': { group: G.app, label: 'Jogos — título', default: 'Jogos' },
  'app.games.description': {
    group: G.app,
    label: 'Jogos — texto',
    default: 'Usa os teus créditos na roleta ou no blackjack. O que ganhares fica na carteira e paga as tuas mensalidades.',
  },
  'app.invites.title': { group: G.app, label: 'Convites — título', default: 'Convites' },
  'app.invites.description': {
    group: G.app,
    label: 'Convites — texto',
    default: 'Convida amigos para a {app}. Podes ter até {limite} convites por usar ao mesmo tempo.',
    vars: ['app', 'limite'],
  },
  'app.account.title': { group: G.app, label: 'Conta — título', default: 'Conta' },
  'app.account.description': { group: G.app, label: 'Conta — texto', default: 'Gere os teus dados, a segurança e as sessões.' },
  'app.help.title': { group: G.app, label: 'Ajuda — título', default: 'Ajuda' },
  'app.help.description': {
    group: G.app,
    label: 'Ajuda — texto',
    default: 'Fala com os assistentes de faturação e de suporte. Respondem na hora e pedem sempre confirmação antes de mudar alguma coisa.',
  },
} satisfies Record<string, TextDef>

export type TextKey = keyof typeof TEXTS
