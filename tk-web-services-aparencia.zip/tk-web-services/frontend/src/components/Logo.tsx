import clsx from 'clsx'
import { useSiteImages, useText } from '../lib/texts'

/**
 * Marca do portal TK Web Services (o TKFLIX é apenas um dos produtos vendidos aqui).
 * Monograma "TK" desenhado em traço (sem depender de fontes), num quadrado arredondado amarelo.
 * Com um logótipo carregado em Admin → Aparência → Imagens, é esse que aparece; o texto ao lado também é editável
 * (Admin → Aparência → Textos → Marca).
 */
export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={clsx('shrink-0', className ?? 'size-8')} aria-hidden>
      <rect width="64" height="64" rx="15" fill="#f5c518" />
      <g fill="none" stroke="#0b0b0c" strokeWidth="7" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12.5 21H30.5M21.5 21V43" />
        <path d="M37.5 21V43M51 21 39.5 32 51 43" />
      </g>
    </svg>
  )
}

export function Logo({ className, size = 'md', wordmarkOnly }: { className?: string; size?: 'sm' | 'md' | 'lg'; wordmarkOnly?: boolean }) {
  const t = useText()
  const images = useSiteImages()
  const name = t('meta.title')
  const mark = { sm: 'size-7', md: 'size-8', lg: 'size-11' }[size]
  const text = { sm: 'text-base', md: 'text-lg', lg: 'text-3xl' }[size]
  if (images.logo) {
    const h = { sm: 'h-7', md: 'h-8', lg: 'h-12' }[size]
    return <img src={images.logo} alt={name} className={clsx('w-auto max-w-[220px] shrink-0 object-contain', h, className)} />
  }
  return (
    <span className={clsx('inline-flex shrink-0 items-center gap-2.5', className)} role="img" aria-label={name}>
      {!wordmarkOnly && <LogoMark className={mark} />}
      <span className={clsx('whitespace-nowrap leading-none tracking-[-0.02em]', text)} aria-hidden>
        <span className="font-black tracking-[-0.04em] text-fg">{t('brand.wordmark.strong')}</span>{' '}
        <span className="font-medium text-brand-text">{t('brand.wordmark.rest')}</span>
      </span>
    </span>
  )
}
