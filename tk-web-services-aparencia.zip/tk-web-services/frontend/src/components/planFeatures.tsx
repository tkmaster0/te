import { Clapperboard, Download, MessageSquarePlus, MonitorPlay, Radio, Tv } from 'lucide-react'
import type { ReactNode } from 'react'
import type { PlanFeatures } from '../api/types'

export interface FeatureLine {
  key: string
  icon: ReactNode
  label: string
}

export function planFeatureLines(f: PlanFeatures): FeatureLine[] {
  const out: FeatureLine[] = []
  const ic = 'size-4'
  if (f.jellyfin.enabled) {
    out.push({ key: 'jf', icon: <Clapperboard className={ic} />, label: 'Filmes e séries no Jellyfin' })
    out.push({
      key: 'streams',
      icon: <MonitorPlay className={ic} />,
      label:
        f.jellyfin.max_streams === 0
          ? 'Ecrãs ilimitados em simultâneo'
          : `${f.jellyfin.max_streams} ${f.jellyfin.max_streams === 1 ? 'ecrã' : 'ecrãs'} em simultâneo`,
    })
    if (f.jellyfin.live_tv) out.push({ key: 'livetv', icon: <Tv className={ic} />, label: 'TV em direto' })
    if (f.jellyfin.downloads) out.push({ key: 'dl', icon: <Download className={ic} />, label: 'Downloads para ver offline' })
  }
  if (f.seerr.enabled) out.push({ key: 'seerr', icon: <MessageSquarePlus className={ic} />, label: 'Pedidos de filmes e séries' })
  if (f.iptv.enabled)
    out.push({
      key: 'iptv',
      icon: <Radio className={ic} />,
      label:
        f.iptv.stream_limit === 0
          ? 'Credenciais IPTV para apps externas'
          : `Credenciais IPTV (${f.iptv.stream_limit} ${f.iptv.stream_limit === 1 ? 'ligação' : 'ligações'})`,
    })
  return out
}
