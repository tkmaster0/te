import clsx from 'clsx'

const SUITS: Record<string, { sym: string; red: boolean; name: string }> = {
  S: { sym: '♠', red: false, name: 'espadas' },
  H: { sym: '♥', red: true, name: 'copas' },
  D: { sym: '♦', red: true, name: 'ouros' },
  C: { sym: '♣', red: false, name: 'paus' },
}

const RANK_NAME: Record<string, string> = { A: 'Ás', J: 'Valete', Q: 'Dama', K: 'Rei' }

/** Carta de jogar ("10H", "AS", ou "??" para a carta tapada). */
export function PlayingCard({ card, className, index = 0 }: { card: string; className?: string; index?: number }) {
  const style = { animationDelay: `${index * 90}ms` }
  if (card === '??')
    return (
      <div
        style={style}
        className={clsx(
          'animate-card-in grid aspect-[5/7] w-16 place-items-center rounded-xl border border-brand/40 bg-zinc-900 bg-[repeating-linear-gradient(45deg,var(--c-brand-soft),var(--c-brand-soft)_6px,transparent_6px,transparent_12px)] shadow-lg sm:w-20',
          className,
        )}
        aria-label="Carta tapada"
        role="img"
      >
        <span className="text-xl font-black text-brand-text/70">TK</span>
      </div>
    )
  const rank = card.slice(0, -1)
  const suit = SUITS[card.slice(-1)] ?? SUITS.S
  return (
    <div
      style={style}
      role="img"
      aria-label={`${RANK_NAME[rank] ?? rank} de ${suit.name}`}
      className={clsx(
        'animate-card-in relative aspect-[5/7] w-16 select-none rounded-xl border border-black/10 bg-white shadow-lg sm:w-20',
        suit.red ? 'text-red-600' : 'text-neutral-900',
        className,
      )}
    >
      <span className="absolute left-1.5 top-1 text-sm font-bold leading-none sm:text-base">
        {rank}
        <br />
        {suit.sym}
      </span>
      <span className="absolute inset-0 grid place-items-center text-3xl sm:text-4xl">{suit.sym}</span>
      <span className="absolute bottom-1 right-1.5 rotate-180 text-sm font-bold leading-none sm:text-base">
        {rank}
        <br />
        {suit.sym}
      </span>
    </div>
  )
}
