import clsx from 'clsx'
import { formatMoney } from '../../lib/format'

const CHIP_STYLE: Record<number, string> = {
  20: 'bg-sky-500 text-white ring-sky-200',
  50: 'bg-emerald-500 text-white ring-emerald-200',
  100: 'bg-zinc-100 text-zinc-900 ring-zinc-400',
  200: 'bg-rose-500 text-white ring-rose-200',
  500: 'bg-violet-600 text-white ring-violet-300',
  1000: 'bg-amber-400 text-zinc-900 ring-amber-100',
}

export function chipLabel(cents: number): string {
  return cents < 100 ? `${cents}c` : `${cents / 100}`
}

/** Ficha de casino (valores 0,20 € a 10 €). */
export function Chip({
  cents,
  selected,
  onClick,
  size = 'md',
  className,
}: {
  cents: number
  selected?: boolean
  onClick?: () => void
  size?: 'sm' | 'md'
  className?: string
}) {
  const Tag = onClick ? 'button' : 'span'
  return (
    <Tag
      type={onClick ? 'button' : undefined}
      onClick={onClick}
      aria-pressed={onClick ? !!selected : undefined}
      aria-label={onClick ? `Ficha de ${formatMoney(cents)}` : undefined}
      className={clsx(
        'grid shrink-0 place-items-center rounded-full font-extrabold tabular-nums shadow-md ring-2 ring-inset transition-transform',
        'border-[3px] border-dashed border-white/60',
        size === 'md' ? 'size-12 text-sm' : 'size-7 text-[10px]',
        CHIP_STYLE[cents] ?? 'bg-brand text-brand-fg ring-brand/40',
        onClick && 'hover:-translate-y-0.5',
        selected && '-translate-y-1 outline-3 outline-offset-2 outline-brand',
        className,
      )}
    >
      {chipLabel(cents)}
    </Tag>
  )
}
