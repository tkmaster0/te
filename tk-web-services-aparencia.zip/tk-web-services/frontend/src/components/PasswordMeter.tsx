import clsx from 'clsx'
import { passwordStrength } from '../lib/password'

const colors = ['bg-danger', 'bg-danger', 'bg-warning', 'bg-success', 'bg-success']
const text = ['text-danger', 'text-danger', 'text-warning', 'text-success', 'text-success']

export function PasswordMeter({ password, username, email }: { password: string; username?: string; email?: string }) {
  if (!password) return null
  const s = passwordStrength(password, { username, email })
  return (
    <div className="space-y-1.5" aria-live="polite">
      <div className="flex gap-1" aria-hidden>
        {[0, 1, 2, 3].map((i) => (
          <div key={i} className={clsx('h-1.5 flex-1 rounded-full', i < Math.max(1, s.score) ? colors[s.score] : 'bg-elevated')} />
        ))}
      </div>
      <p className="text-xs">
        <span className={clsx('font-semibold', text[s.score])}>Força: {s.label}</span>
        {s.hints[0] && <span className="text-muted"> · {s.hints[0]}</span>}
      </p>
    </div>
  )
}
