import type { ReactNode } from 'react'
import clsx from 'clsx'
import { Check } from 'lucide-react'
import type { Plan } from '../api/types'
import { formatMoney, perInterval } from '../lib/format'
import { planFeatureLines } from './planFeatures'
import { Badge } from './ui'

/**
 * Junta os destaques escritos pelo admin com as funcionalidades técnicas do plano sem repetir a mesma coisa
 * duas vezes (ex.: "Canais de TV em direto" + "TV em direto").
 */
const OVERLAP: Record<string, { re: RegExp; keep: 'feature' | 'highlight' }> = {
  jf: { re: /filmes|séries|jellyfin/i, keep: 'highlight' },
  livetv: { re: /tv em direto|canais/i, keep: 'highlight' },
  seerr: { re: /pedidos/i, keep: 'highlight' },
  dl: { re: /download|offline/i, keep: 'highlight' },
  streams: { re: /ecrã/i, keep: 'feature' },
  iptv: { re: /iptv/i, keep: 'feature' },
}

function mergePlanLines(plan: Plan) {
  let highlights = [...plan.highlights]
  const features = planFeatureLines(plan.features).filter((f) => {
    if (highlights.some((h) => h.toLowerCase() === f.label.toLowerCase())) return false
    const rule = OVERLAP[f.key]
    if (!rule) return true
    const hit = highlights.filter((h) => rule.re.test(h))
    if (!hit.length) return true
    if (rule.keep === 'highlight') return false
    highlights = highlights.filter((h) => !hit.includes(h))
    return true
  })
  return { highlights, features }
}

export function PlanCard({
  plan,
  highlight,
  current,
  action,
  footnote,
}: {
  plan: Plan
  highlight?: boolean
  current?: boolean
  action?: ReactNode
  footnote?: ReactNode
}) {
  const { highlights, features } = mergePlanLines(plan)
  const perMonth = plan.interval_unit === 'year' ? (plan.monthly_equivalent_cents ?? Math.round(plan.price_cents / 12)) : null
  return (
    <article
      className={clsx(
        'relative flex h-full flex-col rounded-2xl border bg-surface p-5 sm:p-6',
        current ? 'border-success/50' : highlight ? 'border-brand/60 shadow-[0_0_0_1px_var(--c-brand)_inset]' : 'border-border',
      )}
    >
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <h3 className="text-lg font-bold">{plan.name}</h3>
        {current ? <Badge tone="success">O teu plano</Badge> : highlight ? <Badge tone="brand">Mais completo</Badge> : null}
      </div>
      {plan.description && <p className="-mt-2 mb-4 text-sm text-muted">{plan.description}</p>}
      <div className="mb-5">
        <p className="text-3xl font-extrabold tracking-tight tabular-nums">
          {formatMoney(plan.price_cents, plan.currency)}
          <span className="text-base font-medium text-muted">{perInterval(plan.interval_unit, plan.interval_count)}</span>
        </p>
        {perMonth !== null && (
          <p className="mt-1 text-xs text-muted">equivale a {formatMoney(perMonth, plan.currency)}/mês</p>
        )}
      </div>
      <ul className="mb-6 flex-1 space-y-2.5 text-sm">
        {highlights.map((h) => (
          <li key={h} className="flex items-start gap-2.5">
            <Check className="mt-px size-4 shrink-0 text-brand-text" aria-hidden />
            <span className="font-medium">{h}</span>
          </li>
        ))}
        {features.map((f) => (
          <li key={f.key} className="flex items-start gap-2.5 text-muted">
            <span className="mt-px text-brand-text" aria-hidden>
              {f.icon}
            </span>
            <span>{f.label}</span>
          </li>
        ))}
      </ul>
      {action}
      {footnote && <p className="mt-2.5 text-center text-xs text-muted">{footnote}</p>}
    </article>
  )
}

/** Separa os planos de um produto por periodicidade (mensal/anual). */
export function splitByInterval(plans: Plan[]) {
  const units = Array.from(new Set(plans.map((p) => p.interval_unit)))
  return { units, has: (u: string) => units.includes(u) }
}
