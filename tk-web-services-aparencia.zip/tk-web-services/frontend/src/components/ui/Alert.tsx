import type { ReactNode } from 'react'
import clsx from 'clsx'
import { AlertTriangle, CheckCircle2, Info, XCircle } from 'lucide-react'

const styles = {
  info: { cls: 'border-info/30 bg-info-soft', icon: Info, iconCls: 'text-info' },
  success: { cls: 'border-success/30 bg-success-soft', icon: CheckCircle2, iconCls: 'text-success' },
  warning: { cls: 'border-warning/30 bg-warning-soft', icon: AlertTriangle, iconCls: 'text-warning' },
  danger: { cls: 'border-danger/30 bg-danger-soft', icon: XCircle, iconCls: 'text-danger' },
}

export function Alert({
  tone = 'info',
  title,
  children,
  action,
  className,
  icon,
}: {
  tone?: keyof typeof styles
  title?: ReactNode
  children?: ReactNode
  action?: ReactNode
  className?: string
  /** Ícone alternativo (herda a cor do tom). */
  icon?: ReactNode
}) {
  const s = styles[tone]
  const Icon = s.icon
  return (
    <div
      role={tone === 'danger' ? 'alert' : 'status'}
      className={clsx('flex flex-col gap-3 rounded-xl border p-4 text-sm sm:flex-row sm:items-start', s.cls, className)}
    >
      <div className="flex min-w-0 flex-1 gap-3">
        {icon ? (
          <span className={clsx('mt-0.5 shrink-0 [&>svg]:size-5', s.iconCls)} aria-hidden>
            {icon}
          </span>
        ) : (
          <Icon className={clsx('mt-0.5 size-5 shrink-0', s.iconCls)} aria-hidden />
        )}
        <div className="min-w-0 flex-1">
          {title && <p className="font-semibold text-fg">{title}</p>}
          {children && <div className={clsx('text-fg/85', title && 'mt-0.5')}>{children}</div>}
        </div>
      </div>
      {action && <div className="flex shrink-0 gap-2 pl-8 sm:pl-0">{action}</div>}
    </div>
  )
}
