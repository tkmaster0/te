import { formatMoney, perInterval } from '../../lib/format'

export function Money({ cents, currency = 'EUR', className }: { cents: number | null | undefined; currency?: string; className?: string }) {
  return <span className={className ? `tabular-nums ${className}` : 'tabular-nums'}>{formatMoney(cents, currency)}</span>
}

export function Price({ cents, currency, unit, count = 1 }: { cents: number; currency: string; unit: string; count?: number }) {
  return (
    <span className="tabular-nums">
      {formatMoney(cents, currency)}
      <span className="text-muted font-normal">{perInterval(unit, count)}</span>
    </span>
  )
}
