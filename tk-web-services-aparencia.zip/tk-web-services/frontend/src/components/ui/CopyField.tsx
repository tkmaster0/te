import { useState } from 'react'
import clsx from 'clsx'
import { Check, Copy, Eye, EyeOff } from 'lucide-react'
import { useToast } from './Toast'

export async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text)
    return true
  } catch {
    try {
      const ta = document.createElement('textarea')
      ta.value = text
      ta.setAttribute('readonly', '')
      ta.style.position = 'fixed'
      ta.style.opacity = '0'
      document.body.appendChild(ta)
      ta.select()
      const ok = document.execCommand('copy')
      document.body.removeChild(ta)
      return ok
    } catch {
      return false
    }
  }
}

export function useCopy() {
  const toast = useToast()
  const [copied, setCopied] = useState<string | null>(null)
  const copy = async (text: string, label = 'Copiado') => {
    const ok = await copyText(text)
    if (ok) {
      setCopied(text)
      toast.success(label)
      window.setTimeout(() => setCopied((c) => (c === text ? null : c)), 1800)
    } else toast.error('Não foi possível copiar', 'Seleciona o texto e copia manualmente.')
  }
  return { copy, copied }
}

export function CopyButton({ value, label = 'Copiar', className }: { value: string; label?: string; className?: string }) {
  const { copy, copied } = useCopy()
  const done = copied === value
  return (
    <button
      type="button"
      onClick={() => copy(value)}
      className={clsx('grid size-9 shrink-0 place-items-center rounded-lg text-muted hover:bg-hover hover:text-fg', className)}
      aria-label={label}
      title={label}
    >
      {done ? <Check className="size-4 text-success" /> : <Copy className="size-4" />}
    </button>
  )
}

/** Valor só de leitura com botão copiar (e, opcionalmente, mostrar/esconder para segredos). */
export function CopyField({
  label,
  value,
  secret,
  mono = true,
  hint,
}: {
  label?: string
  value: string | null | undefined
  secret?: boolean
  mono?: boolean
  hint?: string
}) {
  const [reveal, setReveal] = useState(false)
  const v = value ?? ''
  const shown = secret && !reveal ? '•'.repeat(Math.min(Math.max(v.length, 8), 16)) : v
  return (
    <div className="min-w-0">
      {label && <p className="mb-1.5 text-xs font-medium text-muted">{label}</p>}
      <div className="flex min-w-0 items-center gap-1 rounded-xl border border-border bg-bg py-1 pl-3.5 pr-1">
        <span
          className={clsx('min-w-0 flex-1 truncate text-sm', mono && 'font-mono text-[13px]', !v && 'text-subtle')}
          title={secret && !reveal ? undefined : v}
        >
          {v ? shown : '—'}
        </span>
        {secret && v && (
          <button
            type="button"
            onClick={() => setReveal((r) => !r)}
            className="grid size-9 shrink-0 place-items-center rounded-lg text-muted hover:bg-hover hover:text-fg"
            aria-label={reveal ? `Esconder ${label ?? 'valor'}` : `Mostrar ${label ?? 'valor'}`}
            aria-pressed={reveal}
          >
            {reveal ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
          </button>
        )}
        {v && <CopyButton value={v} label={`Copiar ${label ?? ''}`.trim()} />}
      </div>
      {hint && <p className="mt-1 text-xs text-muted">{hint}</p>}
    </div>
  )
}
