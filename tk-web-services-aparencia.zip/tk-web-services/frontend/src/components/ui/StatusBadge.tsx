import { Badge } from './Badge'
import { FULFILLMENT_STATUS, INVOICE_STATUS, JOB_STATUS, PAYMENT_STATUS, PM_STATUS, SUB_STATUS, WEBHOOK_STATUS, type Tone } from '../../i18n/labels'
import { formatDayMonth } from '../../lib/format'

type Kind = 'subscription' | 'payment' | 'job' | 'webhook' | 'invoice' | 'method' | 'fulfillment'

const maps: Record<Kind, Record<string, { label: string; tone: Tone }>> = {
  subscription: SUB_STATUS,
  payment: PAYMENT_STATUS,
  job: JOB_STATUS,
  webhook: WEBHOOK_STATUS,
  invoice: INVOICE_STATUS,
  method: PM_STATUS,
  fulfillment: FULFILLMENT_STATUS,
}

export function StatusBadge({ status, kind = 'subscription', until }: { status: string | null | undefined; kind?: Kind; until?: string | null }) {
  if (!status) return <Badge tone="neutral">Sem subscrição</Badge>
  const entry = maps[kind][status] ?? { label: status, tone: 'neutral' as Tone }
  let label = entry.label
  if (kind === 'subscription' && status === 'canceling' && until) label = `Cancelada · até ${formatDayMonth(until)}`
  return (
    <Badge tone={entry.tone} dot title={label}>
      {label}
    </Badge>
  )
}
