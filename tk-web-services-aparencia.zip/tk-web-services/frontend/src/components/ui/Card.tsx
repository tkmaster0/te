import type { HTMLAttributes, ReactNode } from 'react'
import clsx from 'clsx'

export function Card({ className, children, ...rest }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={clsx('card', className)} {...rest}>
      {children}
    </div>
  )
}

interface CardHeaderProps {
  title: ReactNode
  description?: ReactNode
  icon?: ReactNode
  actions?: ReactNode
  className?: string
  id?: string
}

export function CardHeader({ title, description, icon, actions, className, id }: CardHeaderProps) {
  return (
    <div className={clsx('flex flex-wrap items-start gap-3 px-5 pt-5 sm:px-6 sm:pt-6', className)}>
      {icon && (
        <div className="grid size-10 shrink-0 place-items-center rounded-xl bg-brand-soft text-brand-text">{icon}</div>
      )}
      <div className="min-w-0 flex-1">
        <h2 id={id} className="text-base font-semibold leading-tight">
          {title}
        </h2>
        {description && <p className="mt-1 text-sm text-muted">{description}</p>}
      </div>
      {actions && <div className="flex shrink-0 flex-wrap items-center gap-2">{actions}</div>}
    </div>
  )
}

export function CardBody({ className, children }: { className?: string; children: ReactNode }) {
  return <div className={clsx('px-5 py-5 sm:px-6', className)}>{children}</div>
}

export function CardFooter({ className, children }: { className?: string; children: ReactNode }) {
  return (
    <div className={clsx('flex flex-wrap items-center justify-end gap-2 border-t border-border px-5 py-3.5 sm:px-6', className)}>
      {children}
    </div>
  )
}
