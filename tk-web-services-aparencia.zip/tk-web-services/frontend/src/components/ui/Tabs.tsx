import { useEffect, useId, useRef, type ReactNode } from 'react'
import clsx from 'clsx'

export interface TabItem {
  id: string
  label: ReactNode
  count?: number
}

/** Barra de separadores acessível (role=tablist, setas do teclado). */
export function Tabs({
  items,
  value,
  onChange,
  className,
  ariaLabel,
}: {
  items: TabItem[]
  value: string
  onChange: (id: string) => void
  className?: string
  ariaLabel?: string
}) {
  const refs = useRef<(HTMLButtonElement | null)[]>([])
  const base = useId()
  // Em ecrãs estreitos a barra faz scroll: garante que o separador ativo está visível.
  useEffect(() => {
    const el = refs.current[items.findIndex((t) => t.id === value)]
    const bar = el?.parentElement
    if (!el || !bar || bar.scrollWidth <= bar.clientWidth) return
    const left = el.getBoundingClientRect().left - bar.getBoundingClientRect().left + bar.scrollLeft
    if (left < bar.scrollLeft || left + el.offsetWidth > bar.scrollLeft + bar.clientWidth) bar.scrollLeft = left - 16
  }, [value, items])
  const onKey = (e: React.KeyboardEvent, idx: number) => {
    let next = -1
    if (e.key === 'ArrowRight') next = (idx + 1) % items.length
    else if (e.key === 'ArrowLeft') next = (idx - 1 + items.length) % items.length
    else if (e.key === 'Home') next = 0
    else if (e.key === 'End') next = items.length - 1
    if (next >= 0) {
      e.preventDefault()
      onChange(items[next].id)
      refs.current[next]?.focus()
    }
  }
  return (
    <div
      role="tablist"
      aria-label={ariaLabel}
      className={clsx('scrollbar-thin -mx-1 flex gap-1 overflow-x-auto border-b border-border px-1', className)}
    >
      {items.map((t, i) => {
        const active = t.id === value
        return (
          <button
            key={t.id}
            ref={(el) => {
              refs.current[i] = el
            }}
            id={`${base}-${t.id}`}
            role="tab"
            type="button"
            aria-selected={active}
            tabIndex={active ? 0 : -1}
            onClick={() => onChange(t.id)}
            onKeyDown={(e) => onKey(e, i)}
            className={clsx(
              '-mb-px flex shrink-0 items-center gap-2 border-b-2 px-3 py-2.5 text-sm font-medium transition-colors',
              active ? 'border-brand text-fg' : 'border-transparent text-muted hover:text-fg',
            )}
          >
            {t.label}
            {t.count !== undefined && (
              <span
                className={clsx(
                  'rounded-full px-1.5 py-px text-[11px] font-semibold tabular-nums',
                  active ? 'bg-brand text-brand-fg' : 'bg-elevated text-muted',
                )}
              >
                {t.count}
              </span>
            )}
          </button>
        )
      })}
    </div>
  )
}

/** Filtros em "pílulas" (para listas). */
export function Pills({
  items,
  value,
  onChange,
  className,
  ariaLabel,
}: {
  items: { value: string; label: ReactNode; count?: number }[]
  value: string
  onChange: (v: string) => void
  className?: string
  ariaLabel?: string
}) {
  return (
    <div role="group" aria-label={ariaLabel} className={clsx('scrollbar-thin -mx-1 flex gap-1.5 overflow-x-auto px-1 pb-1', className)}>
      {items.map((it) => {
        const active = it.value === value
        return (
          <button
            key={it.value || '_all'}
            type="button"
            aria-pressed={active}
            onClick={() => onChange(it.value)}
            className={clsx(
              'flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-1.5 text-[13px] font-medium transition-colors',
              active ? 'border-brand bg-brand text-brand-fg' : 'border-border bg-surface text-muted hover:border-border-strong hover:text-fg',
            )}
          >
            {it.label}
            {it.count !== undefined && <span className="tabular-nums opacity-70">{it.count}</span>}
          </button>
        )
      })}
    </div>
  )
}
