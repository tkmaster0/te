import type { ReactNode, TdHTMLAttributes, ThHTMLAttributes } from 'react'
import clsx from 'clsx'

export function Table({ children, className, minWidth }: { children: ReactNode; className?: string; minWidth?: number }) {
  return (
    <div className={clsx('scrollbar-thin relative w-full overflow-x-auto', className)}>
      <table className="w-full border-collapse text-sm" style={minWidth ? { minWidth } : undefined}>
        {children}
      </table>
    </div>
  )
}

export function THead({ children }: { children: ReactNode }) {
  return (
    <thead>
      <tr className="border-b border-border text-left text-xs font-semibold uppercase tracking-wide text-subtle">{children}</tr>
    </thead>
  )
}

export function Th({ className, children, ...rest }: ThHTMLAttributes<HTMLTableCellElement>) {
  return (
    <th scope="col" className={clsx('px-4 py-3 font-semibold whitespace-nowrap first:pl-5 last:pr-5 sm:first:pl-6 sm:last:pr-6', className)} {...rest}>
      {children}
    </th>
  )
}

export function Tr({ children, className, onClick }: { children: ReactNode; className?: string; onClick?: () => void }) {
  return (
    <tr
      onClick={onClick}
      className={clsx('border-b border-border last:border-0', onClick && 'cursor-pointer hover:bg-elevated/60', className)}
    >
      {children}
    </tr>
  )
}

export function Td({ className, children, ...rest }: TdHTMLAttributes<HTMLTableCellElement>) {
  return (
    <td className={clsx('px-4 py-3 align-middle first:pl-5 last:pr-5 sm:first:pl-6 sm:last:pr-6', className)} {...rest}>
      {children}
    </td>
  )
}
