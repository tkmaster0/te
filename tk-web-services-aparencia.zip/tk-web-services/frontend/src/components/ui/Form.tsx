import {
  cloneElement,
  forwardRef,
  isValidElement,
  useId,
  useState,
  type InputHTMLAttributes,
  type ReactElement,
  type ReactNode,
  type SelectHTMLAttributes,
  type TextareaHTMLAttributes,
} from 'react'
import clsx from 'clsx'
import { ChevronDown, Eye, EyeOff } from 'lucide-react'

export const controlClass =
  'block w-full min-w-0 rounded-xl border border-border bg-bg px-3.5 text-sm text-fg placeholder:text-subtle transition-colors hover:border-border-strong focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand/30 disabled:cursor-not-allowed disabled:opacity-60 aria-[invalid=true]:border-danger aria-[invalid=true]:focus:ring-danger/30'

interface FieldProps {
  label?: ReactNode
  hint?: ReactNode
  error?: ReactNode
  children: ReactElement<{ id?: string; 'aria-describedby'?: string; 'aria-invalid'?: boolean }>
  className?: string
  optional?: boolean
  labelAction?: ReactNode
}

/** Associa label, ajuda e erro a um controlo (acessibilidade). */
export function Field({ label, hint, error, children, className, optional, labelAction }: FieldProps) {
  const autoId = useId()
  const id = (isValidElement(children) && children.props.id) || autoId
  const hintId = hint ? `${id}-hint` : undefined
  const errId = error ? `${id}-err` : undefined
  const describedBy = [hintId, errId].filter(Boolean).join(' ') || undefined
  return (
    <div className={clsx('space-y-1.5', className)}>
      {label && (
        <div className="flex items-baseline justify-between gap-2">
          <label htmlFor={id} className="text-sm font-medium text-fg">
            {label}
            {optional && <span className="ml-1 font-normal text-subtle">(opcional)</span>}
          </label>
          {labelAction}
        </div>
      )}
      {cloneElement(children, { id, 'aria-describedby': describedBy, 'aria-invalid': error ? true : undefined })}
      {hint && !error && (
        <p id={hintId} className="text-xs text-muted">
          {hint}
        </p>
      )}
      {error && (
        <p id={errId} className="text-xs font-medium text-danger">
          {error}
        </p>
      )}
    </div>
  )
}

export const Input = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement>>(function Input({ className, ...rest }, ref) {
  return <input ref={ref} className={clsx(controlClass, 'h-11', className)} {...rest} />
})

export const PasswordInput = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement>>(function PasswordInput(
  { className, ...rest },
  ref,
) {
  const [show, setShow] = useState(false)
  return (
    <div className="relative">
      <input ref={ref} type={show ? 'text' : 'password'} className={clsx(controlClass, 'h-11 pr-11', className)} {...rest} />
      <button
        type="button"
        onClick={() => setShow((s) => !s)}
        className="absolute inset-y-0 right-0 grid w-11 place-items-center rounded-r-xl text-muted hover:text-fg"
        aria-label={show ? 'Esconder password' : 'Mostrar password'}
        aria-pressed={show}
      >
        {show ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
      </button>
    </div>
  )
})

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaHTMLAttributes<HTMLTextAreaElement>>(function Textarea(
  { className, rows = 4, ...rest },
  ref,
) {
  return <textarea ref={ref} rows={rows} className={clsx(controlClass, 'py-2.5 leading-relaxed', className)} {...rest} />
})

export const Select = forwardRef<HTMLSelectElement, SelectHTMLAttributes<HTMLSelectElement>>(function Select(
  { className, children, ...rest },
  ref,
) {
  return (
    <div className="relative">
      <select ref={ref} className={clsx(controlClass, 'h-11 appearance-none pr-10', className)} {...rest}>
        {children}
      </select>
      <ChevronDown className="pointer-events-none absolute right-3 top-1/2 size-4 -translate-y-1/2 text-muted" aria-hidden />
    </div>
  )
})

interface CheckboxProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'type'> {
  label: ReactNode
  description?: ReactNode
}

export function Checkbox({ label, description, className, id, ...rest }: CheckboxProps) {
  const autoId = useId()
  const cid = id ?? autoId
  return (
    <div className={clsx('flex items-start gap-3', className)}>
      <input
        id={cid}
        type="checkbox"
        className="mt-0.5 size-4.5 shrink-0 cursor-pointer rounded accent-[var(--c-brand)] disabled:cursor-not-allowed"
        {...rest}
      />
      <label htmlFor={cid} className="cursor-pointer text-sm leading-snug">
        <span className="font-medium">{label}</span>
        {description && <span className="mt-0.5 block text-xs text-muted">{description}</span>}
      </label>
    </div>
  )
}

interface SwitchProps {
  checked: boolean
  onChange: (v: boolean) => void
  label: ReactNode
  description?: ReactNode
  disabled?: boolean
  className?: string
}

export function Switch({ checked, onChange, label, description, disabled, className }: SwitchProps) {
  const id = useId()
  return (
    <div className={clsx('flex items-start justify-between gap-4', className)}>
      <div className="min-w-0">
        <label htmlFor={id} className="cursor-pointer text-sm font-medium">
          {label}
        </label>
        {description && <p className="mt-0.5 text-xs text-muted">{description}</p>}
      </div>
      <button
        id={id}
        type="button"
        role="switch"
        aria-checked={checked}
        disabled={disabled}
        onClick={() => onChange(!checked)}
        className={clsx(
          'relative inline-flex h-6 w-11 shrink-0 items-center rounded-full border transition-colors disabled:opacity-50',
          checked ? 'border-brand bg-brand' : 'border-border-strong bg-elevated',
        )}
      >
        <span
          className={clsx(
            'inline-block size-4.5 rounded-full shadow transition-transform',
            checked ? 'translate-x-[22px] bg-brand-fg' : 'translate-x-[3px] bg-muted',
          )}
        />
      </button>
    </div>
  )
}

export function FormGrid({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={clsx('grid gap-4 sm:grid-cols-2', className)}>{children}</div>
}
