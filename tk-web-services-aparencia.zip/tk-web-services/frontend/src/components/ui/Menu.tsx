import { useEffect, useId, useLayoutEffect, useRef, useState, type ReactNode } from 'react'
import { createPortal } from 'react-dom'
import clsx from 'clsx'
import { MoreHorizontal } from 'lucide-react'

export interface MenuItem {
  label: ReactNode
  icon?: ReactNode
  onSelect: () => void
  danger?: boolean
  disabled?: boolean
  hint?: ReactNode
}

/**
 * Menu de ações secundárias (⋯). Acessível: role=menu, setas/Home/End, ESC devolve o foco ao botão.
 * Renderizado num portal com posição fixa para não ser cortado por cartões com overflow escondido.
 */
export function Menu({
  items,
  label = 'Mais ações',
  trigger,
  className,
}: {
  items: (MenuItem | false | null | undefined)[]
  label?: string
  trigger?: ReactNode
  className?: string
}) {
  const list = items.filter(Boolean) as MenuItem[]
  const [open, setOpen] = useState(false)
  const [pos, setPos] = useState<{ top: number; left: number; up: boolean } | null>(null)
  const btn = useRef<HTMLButtonElement>(null)
  const menu = useRef<HTMLDivElement>(null)
  const id = useId()

  const close = (focus = true) => {
    setOpen(false)
    if (focus) btn.current?.focus()
  }

  useLayoutEffect(() => {
    if (!open || !btn.current) return
    const r = btn.current.getBoundingClientRect()
    const width = 240
    const left = Math.max(8, Math.min(window.innerWidth - width - 8, r.right - width))
    const estimated = list.length * 44 + 16
    const up = r.bottom + estimated > window.innerHeight - 8 && r.top > estimated
    setPos({ top: up ? r.top - 6 : r.bottom + 6, left, up })
  }, [open, list.length])

  useEffect(() => {
    if (!open) return
    const first = menu.current?.querySelector<HTMLButtonElement>('[role="menuitem"]:not([disabled])')
    first?.focus()
    const onDoc = (e: MouseEvent) => {
      const t = e.target as Node
      if (!menu.current?.contains(t) && !btn.current?.contains(t)) setOpen(false)
    }
    const onScroll = () => setOpen(false)
    document.addEventListener('mousedown', onDoc)
    window.addEventListener('scroll', onScroll, true)
    window.addEventListener('resize', onScroll)
    return () => {
      document.removeEventListener('mousedown', onDoc)
      window.removeEventListener('scroll', onScroll, true)
      window.removeEventListener('resize', onScroll)
    }
  }, [open])

  const onKey = (e: React.KeyboardEvent) => {
    const els = Array.from(menu.current?.querySelectorAll<HTMLButtonElement>('[role="menuitem"]:not([disabled])') ?? [])
    const idx = els.indexOf(document.activeElement as HTMLButtonElement)
    if (e.key === 'Escape') {
      e.preventDefault()
      close()
    } else if (e.key === 'ArrowDown') {
      e.preventDefault()
      els[(idx + 1) % els.length]?.focus()
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      els[(idx - 1 + els.length) % els.length]?.focus()
    } else if (e.key === 'Home') {
      e.preventDefault()
      els[0]?.focus()
    } else if (e.key === 'End') {
      e.preventDefault()
      els[els.length - 1]?.focus()
    } else if (e.key === 'Tab') {
      close(false)
    }
  }

  if (!list.length) return null

  return (
    <>
      <button
        ref={btn}
        type="button"
        aria-haspopup="menu"
        aria-expanded={open}
        aria-controls={open ? id : undefined}
        aria-label={trigger ? undefined : label}
        title={trigger ? undefined : label}
        onClick={() => setOpen((o) => !o)}
        onKeyDown={(e) => {
          if (e.key === 'ArrowDown' && !open) {
            e.preventDefault()
            setOpen(true)
          }
        }}
        className={clsx(
          trigger
            ? 'inline-flex h-8 items-center gap-1.5 rounded-xl border border-border bg-elevated px-3 text-[13px] font-semibold hover:border-border-strong hover:bg-hover'
            : 'grid size-9 shrink-0 place-items-center rounded-xl text-muted hover:bg-elevated hover:text-fg',
          className,
        )}
      >
        {trigger ?? <MoreHorizontal className="size-5" aria-hidden />}
      </button>
      {open &&
        pos &&
        createPortal(
          <div
            ref={menu}
            id={id}
            role="menu"
            aria-label={label}
            onKeyDown={onKey}
            style={{ top: pos.top, left: pos.left, transform: pos.up ? 'translateY(-100%)' : undefined }}
            className="animate-fade-in fixed z-[90] w-60 rounded-2xl border border-border bg-elevated p-1.5 shadow-[var(--shadow-pop)]"
          >
            {list.map((it, i) => (
              <button
                key={i}
                type="button"
                role="menuitem"
                disabled={it.disabled}
                onClick={() => {
                  close()
                  it.onSelect()
                }}
                className={clsx(
                  'flex w-full items-start gap-2.5 rounded-xl px-2.5 py-2 text-left text-sm outline-none disabled:cursor-not-allowed disabled:opacity-50',
                  it.danger ? 'text-danger hover:bg-danger-soft focus:bg-danger-soft' : 'hover:bg-hover focus:bg-hover',
                )}
              >
                {it.icon && <span className={clsx('mt-0.5 shrink-0 [&>svg]:size-4', !it.danger && 'text-muted')}>{it.icon}</span>}
                <span className="min-w-0 flex-1">
                  <span className="block font-medium">{it.label}</span>
                  {it.hint && <span className="mt-0.5 block text-xs text-muted">{it.hint}</span>}
                </span>
              </button>
            ))}
          </div>,
          document.body,
        )}
    </>
  )
}
