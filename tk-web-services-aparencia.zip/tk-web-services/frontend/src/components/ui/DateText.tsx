import { formatDate, formatDateTime, parseDate, relativeTime } from '../../lib/format'

export function DateText({
  value,
  withTime,
  relative,
  fallback = '—',
  className,
}: {
  value: string | null | undefined
  withTime?: boolean
  relative?: boolean
  fallback?: string
  className?: string
}) {
  const d = parseDate(value)
  if (!d) return <span className={className}>{fallback}</span>
  const text = relative ? relativeTime(d) : withTime ? formatDateTime(d) : formatDate(d)
  return (
    <time dateTime={d.toISOString()} title={formatDateTime(d)} className={className}>
      {text}
    </time>
  )
}
