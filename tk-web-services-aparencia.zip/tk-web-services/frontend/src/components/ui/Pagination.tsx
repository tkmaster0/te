import { ChevronLeft, ChevronRight } from 'lucide-react'
import { Button } from './Button'

export function Pagination({
  page,
  onPage,
  total,
  size,
  hasNext,
}: {
  page: number
  onPage: (p: number) => void
  total?: number
  size: number
  hasNext?: boolean
}) {
  const pages = total !== undefined ? Math.max(1, Math.ceil(total / size)) : undefined
  const next = pages !== undefined ? page < pages : !!hasNext
  if (page === 1 && !next) return null
  return (
    <nav className="flex items-center justify-between gap-3 border-t border-border px-5 py-3 text-sm text-muted sm:px-6" aria-label="Paginação">
      <span className="tabular-nums">
        Página {page}
        {pages !== undefined && ` de ${pages}`}
        {total !== undefined && <span className="hidden sm:inline"> · {total} resultados</span>}
      </span>
      <div className="flex gap-2">
        <Button variant="secondary" size="sm" disabled={page <= 1} onClick={() => onPage(page - 1)} icon={<ChevronLeft className="size-4" />}>
          Anterior
        </Button>
        <Button variant="secondary" size="sm" disabled={!next} onClick={() => onPage(page + 1)}>
          Seguinte
          <ChevronRight className="size-4" />
        </Button>
      </div>
    </nav>
  )
}
