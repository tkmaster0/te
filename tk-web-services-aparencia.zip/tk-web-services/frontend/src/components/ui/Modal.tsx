import { useEffect, useId, useRef, type ReactNode } from 'react'
import clsx from 'clsx'
import { X } from 'lucide-react'

interface ModalProps {
  open: boolean
  onClose: () => void
  title: ReactNode
  description?: ReactNode
  children?: ReactNode
  footer?: ReactNode
  size?: 'sm' | 'md' | 'lg' | 'xl'
  /** Impede fechar ao carregar fora / ESC (ex.: mostrar segredo uma única vez). */
  dismissible?: boolean
}

const widths = { sm: 'sm:max-w-md', md: 'sm:max-w-lg', lg: 'sm:max-w-2xl', xl: 'sm:max-w-4xl' }

/** Diálogo acessível baseado em <dialog> (focus trap, ESC e aria-modal nativos). */
export function Modal({ open, onClose, title, description, children, footer, size = 'md', dismissible = true }: ModalProps) {
  const ref = useRef<HTMLDialogElement>(null)
  const titleId = useId()
  const descId = useId()

  useEffect(() => {
    const d = ref.current
    if (!d) return
    if (open && !d.open) {
      d.showModal()
      // O showModal() foca o primeiro elemento focável (o botão Fechar), o que mostra um anel de foco
      // estranho ao abrir. Foca o próprio diálogo, exceto se algum campo pediu autoFocus.
      if (document.activeElement?.getAttribute('aria-label') === 'Fechar') d.focus()
      document.body.style.overflow = 'hidden'
    } else if (!open && d.open) {
      d.close()
    }
    return () => {
      if (!open) return
      document.body.style.overflow = ''
    }
  }, [open])

  // Devolve o foco ao elemento que abriu o diálogo quando este fecha.
  useEffect(() => {
    if (!open) return
    const prev = document.activeElement as HTMLElement | null
    return () => {
      if (prev && document.contains(prev)) window.setTimeout(() => prev.focus({ preventScroll: true }), 0)
    }
  }, [open])

  useEffect(() => {
    return () => {
      document.body.style.overflow = ''
    }
  }, [])

  if (!open) return null

  return (
    <dialog
      ref={ref}
      tabIndex={-1}
      aria-labelledby={titleId}
      aria-describedby={description ? descId : undefined}
      onCancel={(e) => {
        e.preventDefault()
        if (dismissible) onClose()
      }}
      onMouseDown={(e) => {
        if (dismissible && e.target === ref.current) onClose()
      }}
      className={clsx(
        'animate-dialog-in outline-none m-0 mt-auto w-full max-w-none rounded-t-2xl border border-border bg-surface p-0 text-fg shadow-[var(--shadow-pop)] backdrop:bg-black/60',
        'max-h-[92dvh] sm:m-auto sm:w-[calc(100%-2rem)] sm:rounded-2xl',
        widths[size],
      )}
    >
      <div className="flex max-h-[92dvh] flex-col">
        <div className="flex items-start gap-3 border-b border-border px-5 py-4 sm:px-6">
          <div className="min-w-0 flex-1">
            <h2 id={titleId} className="text-lg font-semibold leading-snug">
              {title}
            </h2>
            {description && (
              <p id={descId} className="mt-1 text-sm text-muted">
                {description}
              </p>
            )}
          </div>
          {dismissible && (
            <button
              type="button"
              onClick={onClose}
              className="-mr-2 grid size-9 shrink-0 place-items-center rounded-lg text-muted hover:bg-elevated hover:text-fg"
              aria-label="Fechar"
            >
              <X className="size-5" />
            </button>
          )}
        </div>
        {children && <div className="min-h-0 flex-1 overflow-y-auto px-5 py-5 sm:px-6">{children}</div>}
        {footer && (
          <div className="flex flex-col-reverse gap-2 border-t border-border px-5 py-4 sm:flex-row sm:justify-end sm:px-6">
            {footer}
          </div>
        )}
      </div>
    </dialog>
  )
}
