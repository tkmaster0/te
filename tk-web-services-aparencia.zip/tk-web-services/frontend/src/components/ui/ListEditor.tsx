import { useState } from 'react'
import { ArrowDown, ArrowUp, Plus, Trash2 } from 'lucide-react'
import { Button } from './Button'
import { Input } from './Form'

/** Editor de lista de strings (destaques, URIs, grupos…). */
export function StringListEditor({
  value,
  onChange,
  placeholder,
  addLabel = 'Adicionar',
  ariaLabel,
  inputType = 'text',
}: {
  value: string[]
  onChange: (v: string[]) => void
  placeholder?: string
  addLabel?: string
  ariaLabel?: string
  inputType?: string
}) {
  const [draft, setDraft] = useState('')
  const add = () => {
    const v = draft.trim()
    if (!v) return
    onChange([...value, v])
    setDraft('')
  }
  const move = (i: number, d: number) => {
    const j = i + d
    if (j < 0 || j >= value.length) return
    const next = [...value]
    ;[next[i], next[j]] = [next[j], next[i]]
    onChange(next)
  }
  return (
    <div className="space-y-2" role="group" aria-label={ariaLabel}>
      {value.map((item, i) => (
        <div key={i} className="flex items-center gap-1.5">
          <Input
            type={inputType}
            value={item}
            aria-label={`${ariaLabel ?? 'Item'} ${i + 1}`}
            onChange={(e) => onChange(value.map((x, k) => (k === i ? e.target.value : x)))}
            className="h-10"
          />
          <Button variant="ghost" size="icon-sm" onClick={() => move(i, -1)} disabled={i === 0} aria-label="Subir">
            <ArrowUp className="size-4" />
          </Button>
          <Button variant="ghost" size="icon-sm" onClick={() => move(i, 1)} disabled={i === value.length - 1} aria-label="Descer">
            <ArrowDown className="size-4" />
          </Button>
          <Button variant="ghost" size="icon-sm" onClick={() => onChange(value.filter((_, k) => k !== i))} aria-label="Remover">
            <Trash2 className="size-4" />
          </Button>
        </div>
      ))}
      <div className="flex items-center gap-1.5">
        <Input
          type={inputType}
          value={draft}
          placeholder={placeholder}
          aria-label={`Novo: ${ariaLabel ?? 'item'}`}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              e.preventDefault()
              add()
            }
          }}
          className="h-10"
        />
        <Button variant="secondary" size="sm" onClick={add} disabled={!draft.trim()} icon={<Plus className="size-4" />} className="h-10">
          {addLabel}
        </Button>
      </div>
    </div>
  )
}
