import type { ReactNode } from 'react'
import clsx from 'clsx'
import type { Tone } from '../../i18n/labels'

const tones: Record<Tone, string> = {
  success: 'bg-success-soft text-success',
  warning: 'bg-warning-soft text-warning',
  danger: 'bg-danger-soft text-danger',
  info: 'bg-info-soft text-info',
  neutral: 'bg-neutral-soft text-muted',
  brand: 'bg-brand-soft text-brand-text',
}

export function Badge({
  tone = 'neutral',
  children,
  className,
  dot,
  title,
}: {
  tone?: Tone
  children: ReactNode
  className?: string
  dot?: boolean
  title?: string
}) {
  return (
    <span
      title={title}
      className={clsx(
        'inline-flex max-w-full items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-semibold whitespace-nowrap',
        tones[tone],
        className,
      )}
    >
      {dot && <span className="size-1.5 rounded-full bg-current" aria-hidden />}
      <span className="truncate">{children}</span>
    </span>
  )
}
