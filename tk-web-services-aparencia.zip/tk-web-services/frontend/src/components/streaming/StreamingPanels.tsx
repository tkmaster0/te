import { useState, type FormEvent } from 'react'
import {
  Clapperboard,
  Download,
  ExternalLink,
  KeyRound,
  Loader2,
  Lock,
  MessageSquarePlus,
  MonitorSmartphone,
  Pause,
  Play,
  Radio,
  RefreshCw,
  Smartphone,
  Trash2,
  Tv,
} from 'lucide-react'
import { api, errorMessage } from '../../api/client'
import { keys } from '../../api/keys'
import { useAction } from '../../api/mutation'
import { useDevices, useNowPlaying } from '../../api/queries'
import type { Device, ServicesOut } from '../../api/types'
import {
  Alert,
  Badge,
  Button,
  ButtonAnchor,
  Card,
  CardHeader,
  CopyField,
  DateText,
  Field,
  Input,
  PasswordInput,
  Skeleton,
  useConfirm,
} from '../ui'
import { PlatformIcon } from '../PlatformIcon'
import { PLATFORM_LABEL } from '../../i18n/labels'

/** Dados de acesso ao Jellyfin (dentro do cartão do serviço de streaming). */
export function JellyfinAccess({ jf }: { jf: ServicesOut['jellyfin'] }) {
  if (!jf.enabled) return null
  return (
    <div className="space-y-4">
      {!jf.linked && (
        <Alert tone="info">A tua conta Jellyfin está a ser criada. Costuma demorar menos de um minuto — atualiza a página daqui a pouco.</Alert>
      )}
      {jf.last_error && <Alert tone="danger" title="Erro de sincronização (visível só para admins)">{jf.last_error}</Alert>}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <CopyField label="Endereço do servidor" value={jf.url} hint="Usa este endereço nas apps do Jellyfin." />
        <CopyField
          label="Username"
          value={jf.username}
          hint={jf.password_login === false ? 'Entra com o botão «Entrar com TK Web Services».' : 'A password é a mesma do portal.'}
        />
      </div>
      {jf.password_login === false && (
        <div className="flex items-start gap-3 rounded-xl border border-brand/30 bg-brand-soft p-3.5 text-sm">
          <KeyRound className="mt-0.5 size-4 shrink-0 text-brand-text" aria-hidden />
          <p>
            <strong>Uma conta para tudo.</strong> No Jellyfin (web), no Seerr e no TKGPT entras com a tua conta TK — carrega em{' '}
            <em>«Entrar com TK Web Services»</em>. Numa TV ou numa app sem esse botão, usa o <strong>Quick Connect</strong> (aqui em baixo).
          </p>
        </div>
      )}
      <dl className="grid grid-cols-3 gap-2 text-sm sm:gap-3">
        <div className="rounded-xl border border-border p-3">
          <dt className="text-xs text-muted">Ecrãs</dt>
          <dd className="mt-0.5 font-semibold">{jf.max_streams === 0 ? 'Ilimitado' : jf.max_streams}</dd>
        </div>
        <div className="rounded-xl border border-border p-3">
          <dt className="text-xs text-muted">TV em direto</dt>
          <dd className="mt-0.5 font-semibold">{jf.live_tv ? 'Incluída' : 'Não'}</dd>
        </div>
        <div className="rounded-xl border border-border p-3">
          <dt className="text-xs text-muted">Downloads</dt>
          <dd className="mt-0.5 font-semibold">{jf.downloads ? 'Sim' : 'Não'}</dd>
        </div>
      </dl>
    </div>
  )
}

function quotaText(n: number | null, days: number | null, what: string): string {
  if (n === null || n === undefined) return `${what}: limite geral do servidor`
  return `${n} ${what.toLowerCase()} a cada ${days ?? 7} dias`
}

export function PasswordSyncCard() {
  const [pw, setPw] = useState('')
  const sync = useAction((password: string) => api.post('/api/services/jellyfin/sync-password', { password }), {
    invalidate: [keys.me, keys.services],
    onSuccess: () => setPw(''),
  })
  return (
    <Card className="border-warning/40">
      <CardHeader
        icon={<KeyRound className="size-5" />}
        title="Sincroniza a tua password do Jellyfin"
        description="A password do Jellyfin ainda não está igual à do portal. Confirma a tua password do portal e passamos a usá-la também no Jellyfin."
      />
      <form
        className="flex flex-col gap-3 px-5 pb-5 pt-4 sm:flex-row sm:items-end sm:px-6 sm:pb-6"
        onSubmit={(e) => {
          e.preventDefault()
          if (pw) sync.mutate(pw)
        }}
      >
        <Field label="Password do portal" className="flex-1">
          <PasswordInput value={pw} onChange={(e) => setPw(e.target.value)} autoComplete="current-password" required />
        </Field>
        <Button type="submit" loading={sync.isPending} disabled={!pw}>
          Sincronizar
        </Button>
      </form>
    </Card>
  )
}

export function QuickConnectCard() {
  const [code, setCode] = useState('')
  const qc = useAction((c: string) => api.post('/api/services/jellyfin/quick-connect', { code: c }), {
    errorTitle: 'Não foi possível autorizar',
    onSuccess: () => setCode(''),
  })
  const submit = (e: FormEvent) => {
    e.preventDefault()
    const c = code.replace(/[^a-z0-9]/gi, '')
    if (c.length >= 4) qc.mutate(c)
  }
  return (
    <Card id="quick-connect" className="scroll-mt-24">
      <CardHeader
        icon={<MonitorSmartphone className="size-5" />}
        title="Entrar numa TV sem escrever a password"
        description="Na app do Jellyfin da TV escolhe “Quick Connect”. Aparece um código de 6 caracteres — escreve-o aqui."
      />
      <form onSubmit={submit} className="flex flex-col gap-3 px-5 pb-5 pt-4 sm:flex-row sm:items-end sm:px-6 sm:pb-6">
        <Field label="Código Quick Connect" className="flex-1">
          <Input
            value={code}
            onChange={(e) => setCode(e.target.value.toUpperCase().slice(0, 12))}
            placeholder="ABC123"
            autoComplete="off"
            autoCapitalize="characters"
            spellCheck={false}
            inputMode="text"
            className="font-mono text-lg tracking-[0.25em]"
          />
        </Field>
        <Button type="submit" loading={qc.isPending} disabled={code.replace(/[^a-z0-9]/gi, '').length < 4}>
          Autorizar dispositivo
        </Button>
      </form>
    </Card>
  )
}

export function NowPlayingCard({ enabled }: { enabled: boolean }) {
  const q = useNowPlaying(enabled)
  const items = (q.data ?? []).filter((s) => s.playing)
  if (!enabled || q.isError || !items.length) return null
  return (
    <Card>
      <CardHeader icon={<Play className="size-5" />} title="A ver agora" description="Sessões ativas na tua conta (atualiza a cada 30 segundos)." />
      <ul className="divide-y divide-border px-5 pb-3 pt-2 sm:px-6">
        {items.map((s, i) => (
          <li key={i} className="flex items-center gap-3 py-3 text-sm">
            <span className="grid size-9 shrink-0 place-items-center rounded-lg bg-elevated text-muted">
              {s.paused ? <Pause className="size-4" aria-label="Em pausa" /> : <Play className="size-4 text-success" aria-label="A reproduzir" />}
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate font-medium">
                {s.series ? `${s.series} — ` : ''}
                {s.title}
              </p>
              <p className="truncate text-xs text-muted">
                {[s.device, s.client].filter(Boolean).join(' · ')}
                {s.method === 'Transcode' && ' · a converter'}
              </p>
            </div>
          </li>
        ))}
      </ul>
    </Card>
  )
}

export function DevicesCard({ enabled }: { enabled: boolean }) {
  const q = useDevices(enabled)
  const confirm = useConfirm()
  const remove = useAction((id: string) => api.del(`/api/services/jellyfin/devices/${encodeURIComponent(id)}`), {
    invalidate: [keys.devices],
    errorTitle: 'Não foi possível remover',
  })
  const onRemove = async (d: Device) => {
    const ok = await confirm({
      title: 'Remover dispositivo?',
      message: `“${d.name ?? 'Dispositivo'}” vai terminar a sessão e terá de voltar a fazer login no Jellyfin.`,
      confirmLabel: 'Remover',
      danger: true,
    })
    if (ok) remove.mutate(d.id)
  }
  return (
    <Card>
      <CardHeader
        icon={<Smartphone className="size-5" />}
        title="Dispositivos"
        description="Aparelhos com sessão iniciada na tua conta Jellyfin. Remove os que não reconheces."
        actions={
          enabled && (
            <Button variant="ghost" size="icon-sm" onClick={() => q.refetch()} aria-label="Atualizar lista" disabled={q.isFetching}>
              <RefreshCw className={`size-4 ${q.isFetching ? 'animate-spin' : ''}`} />
            </Button>
          )
        }
      />
      <div className="px-5 pb-5 pt-3 sm:px-6 sm:pb-6">
        {!enabled ? (
          <p className="text-sm text-muted">A tua conta Jellyfin ainda não está criada. Assim que estiver pronta, os dispositivos aparecem aqui.</p>
        ) : q.isPending ? (
          <div className="space-y-2">
            <Skeleton className="h-12" />
            <Skeleton className="h-12" />
          </div>
        ) : q.isError ? (
          <Alert tone="warning">Não foi possível obter os dispositivos: {errorMessage(q.error)}</Alert>
        ) : !q.data?.length ? (
          <p className="text-sm text-muted">Ainda não tens dispositivos ligados.</p>
        ) : (
          <ul className="divide-y divide-border">
            {q.data.map((d) => (
              <li key={d.id} className="flex items-center gap-3 py-3">
                <span className="grid size-9 shrink-0 place-items-center rounded-lg bg-elevated text-muted">
                  <MonitorSmartphone className="size-4" aria-hidden />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{d.name ?? 'Dispositivo sem nome'}</p>
                  <p className="truncate text-xs text-muted">
                    {d.app ?? 'App desconhecida'}
                    {d.last_active && (
                      <>
                        {' · '}
                        <DateText value={d.last_active} relative />
                      </>
                    )}
                  </p>
                </div>
                <Button
                  variant="ghost"
                  size="icon-sm"
                  onClick={() => onRemove(d)}
                  disabled={remove.isPending && remove.variables === d.id}
                  aria-label={`Remover ${d.name ?? 'dispositivo'}`}
                >
                  {remove.isPending && remove.variables === d.id ? <Loader2 className="size-4 animate-spin" /> : <Trash2 className="size-4" />}
                </Button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </Card>
  )
}

export function SeerrCard({ seerr }: { seerr: ServicesOut['seerr'] }) {
  return (
    <Card>
      <CardHeader
        icon={<MessageSquarePlus className="size-5" />}
        title="Pedidos de conteúdo"
        description="Pede filmes e séries que ainda não estão na biblioteca. Entra com a tua conta TK Web Services."
      />
      <div className="space-y-4 px-5 pb-5 pt-4 sm:px-6 sm:pb-6">
        <ul className="space-y-1.5 text-sm">
          <li className="flex items-center gap-2">
            <Clapperboard className="size-4 text-subtle" aria-hidden />
            {quotaText(seerr.movie_quota, seerr.movie_quota_days, 'Filmes')}
          </li>
          <li className="flex items-center gap-2">
            <Tv className="size-4 text-subtle" aria-hidden />
            {quotaText(seerr.tv_quota, seerr.tv_quota_days, 'Temporadas')}
          </li>
        </ul>
        {seerr.url ? (
          <ButtonAnchor href={seerr.url} variant="secondary" icon={<ExternalLink className="size-4" />} className="w-full sm:w-auto">
            Abrir pedidos
          </ButtonAnchor>
        ) : (
          <p className="text-sm text-muted">Os pedidos ainda não estão disponíveis.</p>
        )}
      </div>
    </Card>
  )
}

/** O cliente vê a password da TV em texto e muda-a quando quiser (ou gera uma nova, simples). */
function IptvPasswordForm() {
  const [open, setOpen] = useState(false)
  const [pwd, setPwd] = useState('')
  const change = useAction((password: string) => api.post<{ password: string; message: string }>('/api/services/iptv/password', { password: password || null }), {
    invalidate: [keys.services],
    errorTitle: 'Não foi possível mudar a password',
    onSuccess: () => {
      setPwd('')
      setOpen(false)
    },
  })
  if (!open)
    return (
      <div className="flex flex-wrap gap-2">
        <Button size="sm" variant="secondary" icon={<KeyRound className="size-4" />} onClick={() => setOpen(true)}>
          Mudar password
        </Button>
        <Button size="sm" variant="ghost" icon={<RefreshCw className="size-4" />} loading={change.isPending} onClick={() => change.mutate('')}>
          Gerar outra
        </Button>
      </div>
    )
  return (
    <form
      className="flex flex-col gap-3 rounded-xl border border-border p-4 sm:flex-row sm:items-end"
      onSubmit={(e) => {
        e.preventDefault()
        change.mutate(pwd)
      }}
    >
      <Field label="Nova password da TV" hint="6 a 32 caracteres: letras, números, ponto, hífen ou _. Muda logo em todos os aparelhos." className="flex-1">
        <Input value={pwd} onChange={(e) => setPwd(e.target.value)} autoComplete="off" pattern="[A-Za-z0-9._-]{6,32}" maxLength={32} />
      </Field>
      <div className="flex gap-2">
        <Button type="submit" loading={change.isPending} disabled={pwd.length < 6}>
          Guardar
        </Button>
        <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
          Cancelar
        </Button>
      </div>
    </form>
  )
}

export function IptvCard({ iptv }: { iptv: ServicesOut['iptv'] }) {
  return (
    <Card id="iptv" className="scroll-mt-24">
      <CardHeader
        icon={<Radio className="size-5" />}
        title="TV / IPTV"
        description="Credenciais para usares os canais em apps IPTV (TiviMate, IPTV Smarters, VLC…)."
        actions={iptv.stream_limit !== undefined && iptv.stream_limit > 0 && <Badge tone="neutral">{iptv.stream_limit} {iptv.stream_limit === 1 ? 'ligação' : 'ligações'}</Badge>}
      />
      <div className="px-5 pb-5 pt-4 sm:px-6 sm:pb-6">
        {iptv.pending ? (
          <div className="flex items-center gap-3 rounded-xl bg-elevated p-4 text-sm text-muted">
            <Loader2 className="size-5 animate-spin text-brand-text" aria-hidden />A preparar as tuas credenciais…
          </div>
        ) : (
          <div className="space-y-4">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <CopyField label="Username" value={iptv.username} />
              <CopyField label="Password" value={iptv.password} />
            </div>
            {iptv.source === 'dispatcharr' && <IptvPasswordForm />}
            <CopyField label="Servidor" value={iptv.server} />
            {iptv.m3u_url && <CopyField label="Lista M3U" value={iptv.m3u_url} secret hint="Contém a tua password — não partilhes este link." />}
            {iptv.epg_url && <CopyField label="Guia de programação (EPG / XMLTV)" value={iptv.epg_url} secret />}
            <p className="flex items-start gap-2 text-xs text-muted">
              <Lock className="mt-px size-3.5 shrink-0" aria-hidden />
              Estas credenciais são pessoais. Partilhá-las pode levar à suspensão da conta.
            </p>
          </div>
        )}
      </div>
    </Card>
  )
}

export function AppsCard({ apps, passwordLogin }: { apps: ServicesOut['apps']; passwordLogin?: boolean }) {
  if (!apps.length) return null
  return (
    <Card>
      <CardHeader
        icon={<Download className="size-5" />}
        title="Apps"
        description={
          passwordLogin === false
            ? 'Instala a app do Jellyfin no teu aparelho e entra com o Quick Connect (sem escrever password).'
            : 'Instala a app do Jellyfin no teu aparelho e entra com o teu username e password.'
        }
      />
      <ul className="grid grid-cols-1 gap-2 px-5 pb-5 pt-4 sm:grid-cols-2 sm:px-6 sm:pb-6 xl:grid-cols-4">
        {apps.map((a) => (
          <li key={a.url + a.name}>
            <a
              href={a.url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-3 rounded-xl border border-border p-3 transition-colors hover:border-border-strong hover:bg-elevated"
            >
              <span className="grid size-10 shrink-0 place-items-center rounded-lg bg-elevated text-fg">
                <PlatformIcon platform={a.platform} />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-sm font-medium leading-snug">{a.name}</span>
                <span className="block text-xs text-muted">{PLATFORM_LABEL[a.platform] ?? a.platform}</span>
              </span>
              <ExternalLink className="size-4 shrink-0 text-subtle" aria-hidden />
            </a>
          </li>
        ))}
      </ul>
    </Card>
  )
}

