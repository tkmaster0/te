import { LifeBuoy, Receipt } from 'lucide-react'
import clsx from 'clsx'
import { Badge } from '../ui'
import type { Tone } from '../../i18n/labels'

export const AGENT_LABEL: Record<string, string> = { billing: 'Faturação', support: 'Suporte' }
export const AGENT_TONE: Record<string, Tone> = { billing: 'brand', support: 'info' }

export const CHANNEL_LABEL: Record<string, string> = { web: 'Portal', jellyfin: 'Jellyfin', whatsapp: 'WhatsApp', seerr: 'Seerr' }

export const CONV_STATUS: Record<string, { label: string; tone: Tone }> = {
  open: { label: 'Aberta', tone: 'info' },
  escalated: { label: 'Escalada', tone: 'warning' },
  resolved: { label: 'Resolvida', tone: 'success' },
  closed: { label: 'Fechada', tone: 'neutral' },
}

export const ACTION_STATUS: Record<string, { label: string; tone: Tone }> = {
  pending: { label: 'À espera de confirmação', tone: 'warning' },
  done: { label: 'Confirmada', tone: 'success' },
  cancelled: { label: 'Cancelada', tone: 'neutral' },
  expired: { label: 'Expirada', tone: 'neutral' },
  failed: { label: 'Falhou', tone: 'danger' },
}

export const KB_STATUS: Record<string, { label: string; tone: Tone }> = {
  active: { label: 'Ativo', tone: 'success' },
  draft: { label: 'Sugestão', tone: 'warning' },
  archived: { label: 'Arquivado', tone: 'neutral' },
}

export const KB_SOURCE: Record<string, string> = { manual: 'Manual', promoted: 'Resposta promovida', suggested: 'Sugestão automática' }

export function AgentIcon({ agent, className }: { agent: string; className?: string }) {
  const Icon = agent === 'billing' ? Receipt : LifeBuoy
  return <Icon className={clsx('size-3.5', className)} aria-hidden />
}

export function AgentBadge({ agent, className }: { agent: string; className?: string }) {
  return (
    <Badge tone={AGENT_TONE[agent] ?? 'neutral'} className={className}>
      <span className="inline-flex items-center gap-1">
        <AgentIcon agent={agent} className="size-3" />
        {AGENT_LABEL[agent] ?? agent}
      </span>
    </Badge>
  )
}

export function ConvStatusBadge({ status }: { status: string }) {
  const s = CONV_STATUS[status] ?? { label: status, tone: 'neutral' as Tone }
  return (
    <Badge tone={s.tone} dot>
      {s.label}
    </Badge>
  )
}
