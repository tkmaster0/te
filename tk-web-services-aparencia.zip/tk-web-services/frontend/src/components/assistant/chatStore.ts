/**
 * Estado do chat do portal, fora do React: sobrevive a fechar/abrir o painel e é partilhado entre o botão
 * flutuante e a página "Ajuda". Uma resposta que chegue com o painel fechado não se perde.
 */
import { useSyncExternalStore } from 'react'
import { api, ApiError, errorMessage } from '../../api/client'
import type { ActionStatus, ChatMessage, ChatResponse, ConversationWithMessages } from '../../api/assistant'

export interface LocalMessage extends ChatMessage {
  key: string
  /** Só nas mensagens do cliente ainda não confirmadas pelo servidor. */
  local?: 'sending' | 'failed'
}

export interface ChatError {
  kind: 'disabled' | 'rate' | 'network' | 'other'
  text: string
}

export interface ChatState {
  convId: string | null
  /** Canal da conversa aberta (web, whatsapp, jellyfin). Só as do portal continuam aqui. */
  channel: string | null
  messages: LocalMessage[]
  loading: boolean
  sending: boolean
  error: ChatError | null
  deciding: Record<string, boolean>
  /** Incrementa sempre que há mensagens novas do servidor (para anunciar / fazer scroll). */
  rev: number
}

const STORAGE_KEY = 'tk-assistant-conversation'
let seq = 0

function readId(): string | null {
  try {
    return window.sessionStorage.getItem(STORAGE_KEY)
  } catch {
    return null
  }
}

function writeId(id: string | null) {
  try {
    if (id) window.sessionStorage.setItem(STORAGE_KEY, id)
    else window.sessionStorage.removeItem(STORAGE_KEY)
  } catch {
    /* modo privado */
  }
}

function toLocal(m: ChatMessage): LocalMessage {
  return { ...m, key: `m${m.id}` }
}

export function classifyError(err: unknown): ChatError {
  if (err instanceof ApiError) {
    if (err.status === 503) return { kind: 'disabled', text: 'O assistente não está disponível neste momento. Tenta mais tarde.' }
    if (err.status === 429)
      return { kind: 'rate', text: 'Estás a enviar mensagens muito depressa. Espera um minuto e tenta de novo.' }
    if (err.status === 0) return { kind: 'network', text: 'Sem ligação ao servidor. Verifica a tua internet e tenta de novo.' }
  }
  return { kind: 'other', text: errorMessage(err) }
}

type Listener = () => void

class ChatStore {
  private state: ChatState = { convId: null, channel: null, messages: [], loading: false, sending: false, error: null, deciding: {}, rev: 0 }
  private listeners = new Set<Listener>()
  private started = false
  /** Chamado depois de cada troca com o servidor (ex.: atualizar a lista de conversas). */
  onServerChange: (() => void) | null = null

  subscribe = (l: Listener) => {
    this.listeners.add(l)
    return () => this.listeners.delete(l)
  }

  get = () => this.state

  private set(patch: Partial<ChatState>) {
    this.state = { ...this.state, ...patch }
    this.listeners.forEach((l) => l())
  }

  /** Na primeira utilização retoma a conversa desta sessão do browser. */
  start() {
    if (this.started) return
    this.started = true
    const id = readId()
    if (id) void this.open(id)
  }

  async open(id: string) {
    if (this.state.sending) return
    this.set({ convId: id, loading: true, error: null, messages: this.state.convId === id ? this.state.messages : [] })
    writeId(id)
    try {
      const conv = await api.get<ConversationWithMessages>(`/api/assistant/conversations/${encodeURIComponent(id)}`)
      if (this.state.convId !== id) return
      this.set({ messages: conv.messages.map(toLocal), channel: conv.channel, loading: false, rev: this.state.rev + 1 })
    } catch (err) {
      if (this.state.convId !== id) return
      if (err instanceof ApiError && err.status === 404) {
        writeId(null)
        this.set({ convId: null, channel: null, messages: [], loading: false })
      } else this.set({ loading: false, error: classifyError(err) })
    }
  }

  reset() {
    if (this.state.sending) return
    writeId(null)
    this.set({ convId: null, channel: null, messages: [], error: null, loading: false, deciding: {} })
  }

  clearError() {
    this.set({ error: null })
  }

  async send(text: string, retryKey?: string) {
    const body = text.trim()
    if (!body || this.state.sending) return
    const key = retryKey ?? `t${++seq}`
    const optimistic: LocalMessage = {
      key,
      id: -++seq,
      role: 'user',
      agent: '',
      content: body,
      ui: null,
      feedback: null,
      created_at: new Date().toISOString(),
      local: 'sending',
    }
    const messages = retryKey
      ? this.state.messages.map((m) => (m.key === retryKey ? { ...m, local: 'sending' as const } : m))
      : [...this.state.messages, optimistic]
    this.set({ messages, sending: true, error: null })
    try {
      // Conversas do WhatsApp/Jellyfin ficam só para leitura: escrever aqui começa uma conversa nova no portal.
      const continuing = this.state.channel === null || this.state.channel === 'web'
      const res = await api.post<ChatResponse>('/api/assistant/chat', {
        message: body,
        conversation_id: continuing ? this.state.convId : null,
      })
      writeId(res.conversation_id)
      const incoming = res.messages.map(toLocal)
      // Um pedido de confirmação novo substitui os anteriores ainda pendentes (o servidor já os cancelou).
      const hasNewConfirm = incoming.some((m) => m.ui?.type === 'confirm')
      const resolved = new Map<string, ActionStatus>()
      for (const m of incoming) if (m.ui?.type === 'action_result' && m.ui.action_id) resolved.set(m.ui.action_id, (m.ui.status as ActionStatus) ?? 'done')
      const prev = this.state.messages.map((m): LocalMessage => {
        if (m.key === key) return { ...m, local: undefined, agent: res.agent }
        if (m.ui?.type === 'confirm' && m.ui.action_id && m.ui.status === 'pending') {
          const st = resolved.get(m.ui.action_id) ?? (hasNewConfirm ? 'cancelled' : undefined)
          if (st) return { ...m, ui: { ...m.ui, status: st } }
        }
        return m
      })
      const fresh = this.state.convId !== null && this.state.convId !== res.conversation_id
      const base = fresh ? prev.filter((m) => m.key === key) : prev
      this.set({
        convId: res.conversation_id,
        channel: 'web',
        messages: [...base, ...incoming],
        sending: false,
        rev: this.state.rev + 1,
      })
      this.onServerChange?.()
    } catch (err) {
      this.set({
        messages: this.state.messages.map((m) => (m.key === key ? { ...m, local: 'failed' as const } : m)),
        sending: false,
        error: classifyError(err),
      })
    }
  }

  retry(key: string) {
    const m = this.state.messages.find((x) => x.key === key)
    if (m?.content) void this.send(m.content, key)
  }

  discard(key: string) {
    this.set({ messages: this.state.messages.filter((m) => m.key !== key), error: null })
  }

  async decide(actionId: string, confirm: boolean) {
    if (this.state.deciding[actionId]) return
    this.set({ deciding: { ...this.state.deciding, [actionId]: true }, error: null })
    const mark = (status: ActionStatus) =>
      this.state.messages.map((m) => (m.ui?.type === 'confirm' && m.ui.action_id === actionId ? { ...m, ui: { ...m.ui, status } } : m))
    try {
      const res = await api.post<{ message: ChatMessage | null }>(`/api/assistant/actions/${encodeURIComponent(actionId)}`, { confirm })
      const msg = res.message
      let status: ActionStatus = confirm ? 'done' : 'cancelled'
      if (msg?.ui?.type === 'action_result' && msg.ui.status) status = msg.ui.status
      else if (confirm && msg && !msg.ui) status = 'expired' // o servidor responde sem ui quando o pedido expirou
      const messages = mark(status)
      this.set({
        messages: msg ? [...messages, toLocal(msg)] : messages,
        deciding: { ...this.state.deciding, [actionId]: false },
        rev: this.state.rev + 1,
      })
      this.onServerChange?.()
    } catch (err) {
      const e = classifyError(err)
      // "Esta ação já foi tratada" → deixa de mostrar os botões.
      const already = err instanceof ApiError && err.status === 400
      this.set({
        messages: already ? mark('expired') : this.state.messages,
        deciding: { ...this.state.deciding, [actionId]: false },
        error: e,
      })
    }
  }

  async feedback(id: number, value: 1 | -1) {
    const current = this.state.messages.find((m) => m.id === id)?.feedback ?? null
    const next = current === value ? 0 : value
    const apply = (v: number | null) =>
      this.set({ messages: this.state.messages.map((m) => (m.id === id ? { ...m, feedback: v } : m)) })
    apply(next || null)
    try {
      await api.post(`/api/assistant/messages/${id}/feedback`, { value: next })
    } catch (err) {
      apply(current)
      this.set({ error: classifyError(err) })
    }
  }
}

export const chatStore = new ChatStore()

export function useChatState(): ChatState {
  return useSyncExternalStore(chatStore.subscribe, chatStore.get, chatStore.get)
}
