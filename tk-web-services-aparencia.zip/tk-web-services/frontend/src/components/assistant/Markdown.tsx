/**
 * Markdown mínimo e seguro para as respostas dos assistentes.
 *
 * Suporta: parágrafos, quebras de linha, listas (- * •, 1.), títulos simples (#), negrito (dois asteriscos), itálico (um asterisco ou sublinhado),
 * `código` e links ([texto](url) ou URLs soltos). Tudo é construído com elementos React — nunca há HTML cru.
 * Links relativos (/app/...) usam o react-router; http(s) abrem num separador novo; outros esquemas ficam texto.
 */
import { Fragment, type ReactNode } from 'react'
import { Link } from 'react-router-dom'
import clsx from 'clsx'

type Block =
  | { kind: 'p'; lines: string[] }
  | { kind: 'h'; text: string }
  | { kind: 'ul'; items: string[] }
  | { kind: 'ol'; items: string[]; start: number }

const UL = /^\s*[-*•]\s+(.*)$/
const OL = /^\s*(\d{1,3})[.)]\s+(.*)$/
const H = /^\s*#{1,4}\s+(.*)$/

function parseBlocks(text: string): Block[] {
  const blocks: Block[] = []
  let cur: Block | null = null
  const flush = () => {
    if (cur) blocks.push(cur)
    cur = null
  }
  for (const raw of text.replace(/\r\n?/g, '\n').split('\n')) {
    const line = raw.replace(/\s+$/, '')
    if (!line.trim()) {
      flush()
      continue
    }
    let m: RegExpMatchArray | null
    if ((m = line.match(H))) {
      flush()
      blocks.push({ kind: 'h', text: m[1] })
    } else if ((m = line.match(UL))) {
      if (cur?.kind !== 'ul') {
        flush()
        cur = { kind: 'ul', items: [] }
      }
      ;(cur as Extract<Block, { kind: 'ul' }>).items.push(m[1])
    } else if ((m = line.match(OL))) {
      if (cur?.kind !== 'ol') {
        flush()
        cur = { kind: 'ol', items: [], start: Number(m[1]) || 1 }
      }
      ;(cur as Extract<Block, { kind: 'ol' }>).items.push(m[2])
    } else if ((cur?.kind === 'ul' || cur?.kind === 'ol') && /^\s{2,}\S/.test(raw)) {
      // continuação indentada de um item
      const c = cur as Extract<Block, { kind: 'ul' | 'ol' }>
      c.items[c.items.length - 1] += ` ${line.trim()}`
    } else {
      if (cur?.kind !== 'p') {
        flush()
        cur = { kind: 'p', lines: [] }
      }
      ;(cur as Extract<Block, { kind: 'p' }>).lines.push(line)
    }
  }
  flush()
  return blocks
}

/** Link seguro: caminhos internos pelo router, http(s) externos, o resto como texto. */
function SafeLink({ href, children }: { href: string; children: ReactNode }) {
  const h = href.trim()
  const cls = 'font-semibold text-brand-text underline decoration-brand-text/40 underline-offset-2 hover:decoration-brand-text'
  if (/^\/(?![/\\])[^\s\\]*$/.test(h)) {  // nunca "//x" nem "/\\x" (o browser trata-os como externos)
    return (
      <Link to={h} className={cls}>
        {children}
      </Link>
    )
  }
  if (/^https?:\/\/[^\s]+$/i.test(h)) {
    // Links para o próprio portal em modo absoluto também ficam no router.
    try {
      const u = new URL(h)
      if (u.origin === window.location.origin && u.pathname.startsWith('/app')) {
        return (
          <Link to={u.pathname + u.search + u.hash} className={cls}>
            {children}
          </Link>
        )
      }
    } catch {
      /* URL inválido: segue como externo */
    }
    return (
      <a href={h} target="_blank" rel="noopener noreferrer nofollow" className={cls}>
        {children}
      </a>
    )
  }
  return <>{children}</>
}

// Ordem importa: links markdown, código, negrito, itálico, URL solto, caminho /app solto.
const INLINE =
  /\[([^\]\n]{1,200})\]\(([^)\s]{1,500})\)|`([^`\n]{1,200})`|\*\*([^*\n]+?)\*\*|__([^_\n]+?)__|(?<![\w*])\*(?!\s)([^*\n]+?)\*(?![\w*])|(?<![\w_])_(?!\s)([^_\n]+?)_(?![\w_])|(https?:\/\/[^\s<>()]+[^\s<>().,;:!?'"»])|(?<![\w/])(\/app(?:\/[\w\-./?=&#%]*)?[\w/])/g

function inline(text: string, keyBase: string, depth = 0): ReactNode[] {
  const out: ReactNode[] = []
  let last = 0
  let i = 0
  const re = new RegExp(INLINE.source, 'g')
  let m: RegExpExecArray | null
  while ((m = re.exec(text))) {
    if (m.index > last) out.push(text.slice(last, m.index))
    const k = `${keyBase}-${i++}`
    if (m[1] !== undefined) {
      out.push(
        <SafeLink key={k} href={m[2]}>
          {depth < 2 ? inline(m[1], k, depth + 1) : m[1]}
        </SafeLink>,
      )
    } else if (m[3] !== undefined) {
      out.push(
        <code key={k} className="rounded-md bg-bg/60 px-1 py-0.5 font-mono text-[0.85em]">
          {m[3]}
        </code>,
      )
    } else if (m[4] !== undefined || m[5] !== undefined) {
      const t = (m[4] ?? m[5]) as string
      out.push(
        <strong key={k} className="font-semibold text-fg">
          {depth < 2 ? inline(t, k, depth + 1) : t}
        </strong>,
      )
    } else if (m[6] !== undefined || m[7] !== undefined) {
      // No WhatsApp *x* é negrito; no portal tratamos *x* como ênfase (itálico).
      const t = (m[6] ?? m[7]) as string
      out.push(<em key={k}>{depth < 2 ? inline(t, k, depth + 1) : t}</em>)
    } else if (m[8] !== undefined) {
      out.push(
        <SafeLink key={k} href={m[8]}>
          {m[8].replace(/^https?:\/\//, '')}
        </SafeLink>,
      )
    } else if (m[9] !== undefined) {
      out.push(
        <SafeLink key={k} href={m[9]}>
          {m[9]}
        </SafeLink>,
      )
    }
    last = m.index + m[0].length
  }
  if (last < text.length) out.push(text.slice(last))
  return out
}

export function Markdown({ text, className }: { text: string; className?: string }) {
  const blocks = parseBlocks(text)
  return (
    <div className={clsx('space-y-2 break-words [overflow-wrap:anywhere]', className)}>
      {blocks.map((b, bi) => {
        const k = `b${bi}`
        if (b.kind === 'h') return <p key={k} className="font-semibold text-fg">{inline(b.text, k)}</p>
        if (b.kind === 'ul')
          return (
            <ul key={k} className="list-disc space-y-1 pl-5 marker:text-subtle">
              {b.items.map((it, ii) => (
                <li key={ii}>{inline(it, `${k}-${ii}`)}</li>
              ))}
            </ul>
          )
        if (b.kind === 'ol')
          return (
            <ol key={k} start={b.start} className="list-decimal space-y-1 pl-5 marker:text-subtle">
              {b.items.map((it, ii) => (
                <li key={ii}>{inline(it, `${k}-${ii}`)}</li>
              ))}
            </ol>
          )
        return (
          <p key={k}>
            {b.lines.map((ln, li) => (
              <Fragment key={li}>
                {li > 0 && <br />}
                {inline(ln, `${k}-${li}`)}
              </Fragment>
            ))}
          </p>
        )
      })}
    </div>
  )
}
