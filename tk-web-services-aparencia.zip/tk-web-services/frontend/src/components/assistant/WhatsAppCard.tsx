/** Conta → ligar o WhatsApp ao assistente (código de uso único enviado a partir do telemóvel). */
import { useEffect, useState } from 'react'
import { useQueryClient } from '@tanstack/react-query'
import { Clock, ExternalLink, MessageCircle, RefreshCw, Smartphone, Unlink } from 'lucide-react'
import { api } from '../../api/client'
import { akeys, useAssistantStatus, type WhatsAppLink } from '../../api/assistant'
import { useAction } from '../../api/mutation'
import { Badge, Button, ButtonAnchor, Card, CardHeader, CopyButton, useConfirm } from '../ui'

function useCountdown(until: number | null) {
  const [now, setNow] = useState(() => Date.now())
  useEffect(() => {
    if (!until) return
    const t = window.setInterval(() => setNow(Date.now()), 1000)
    return () => window.clearInterval(t)
  }, [until])
  return until ? Math.max(0, Math.round((until - now) / 1000)) : 0
}

function fmt(s: number) {
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`
}

export function WhatsAppCard() {
  const qc = useQueryClient()
  const confirm = useConfirm()
  const [link, setLink] = useState<(WhatsAppLink & { until: number }) | null>(null)
  const left = useCountdown(link?.until ?? null)
  const waiting = !!link && left > 0
  // Enquanto o código está ativo, verifica de 5 em 5 segundos se o número já foi ligado.
  const status = useAssistantStatus()
  const wa = status.data?.whatsapp

  useEffect(() => {
    if (!waiting) return
    const t = window.setInterval(() => void qc.invalidateQueries({ queryKey: akeys.status }), 5000)
    return () => window.clearInterval(t)
  }, [waiting, qc])

  useEffect(() => {
    if (wa?.linked && link) setLink(null)
  }, [wa?.linked, link])

  const create = useAction(() => api.post<WhatsAppLink>('/api/assistant/whatsapp/link'), {
    success: false,
    errorTitle: 'Não foi possível gerar o código',
    onSuccess: (res) => setLink({ ...res, until: Date.now() + res.expires_in * 1000 }),
  })
  const unlink = useAction(() => api.del('/api/assistant/whatsapp'), {
    success: 'WhatsApp desligado.',
    invalidate: [akeys.status],
  })

  if (!wa?.enabled) return null
  const number = wa.number ? `+${wa.number}` : null

  return (
    <Card id="whatsapp">
      <CardHeader
        icon={<MessageCircle className="size-5" />}
        title={
          <span className="flex flex-wrap items-center gap-2">
            Assistente no WhatsApp
            {wa.linked ? (
              <Badge tone="success" dot>
                Ligado
              </Badge>
            ) : (
              <Badge>Não ligado</Badge>
            )}
          </span>
        }
        description="Fala com os assistentes de faturação e suporte pelo WhatsApp, com as mesmas regras de segurança do portal."
      />
      <div className="px-5 pb-5 pt-4 sm:px-6 sm:pb-6">
        {wa.linked ? (
          <div className="flex flex-col gap-4 rounded-xl border border-border bg-elevated/50 p-4 sm:flex-row sm:items-center">
            <div className="flex min-w-0 flex-1 items-start gap-3">
            <span className="grid size-10 shrink-0 place-items-center rounded-full bg-success-soft text-success">
              <Smartphone className="size-5" aria-hidden />
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold">
                Número ligado: <span className="font-mono">{wa.linked}</span>
              </p>
              <p className="mt-0.5 text-xs text-muted">
                {number ? (
                  <>
                    Escreve para <strong className="text-fg">{number}</strong>.{' '}
                  </>
                ) : null}
                Ações na tua conta pedem sempre que respondas <strong className="text-fg">SIM</strong>.
              </p>
            </div>
            </div>
            <Button
              variant="danger"
              size="sm"
              icon={<Unlink className="size-4" />}
              loading={unlink.isPending}
              onClick={async () => {
                if (
                  await confirm({
                    title: 'Desligar o WhatsApp?',
                    message: 'O assistente deixa de reconhecer este número. Podes voltar a ligá-lo quando quiseres.',
                    confirmLabel: 'Desligar',
                    danger: true,
                  })
                )
                  unlink.mutate()
              }}
            >
              Desligar
            </Button>
          </div>
        ) : link && waiting ? (
          <div className="space-y-4">
            <ol className="list-decimal space-y-1.5 pl-5 text-sm text-muted marker:font-semibold marker:text-brand-text">
              <li>Abre o WhatsApp no telemóvel que queres ligar.</li>
              <li>
                Envia este código {number ? <>para o número <strong className="text-fg">{number}</strong></> : 'para o número da TK Web Services'} (só o código, numa
                mensagem).
              </li>
              <li>Recebes uma confirmação no WhatsApp e esta página atualiza sozinha.</li>
            </ol>
            <div className="flex flex-col items-stretch gap-3 rounded-xl border border-brand/40 bg-brand-soft/50 p-4 sm:flex-row sm:items-center">
              <div className="min-w-0 flex-1">
                <p className="text-xs font-medium text-muted">O teu código</p>
                <p className="mt-0.5 font-mono text-2xl font-bold tracking-[0.12em] text-fg sm:text-3xl" aria-live="polite">
                  {link.code}
                </p>
                <p className="mt-1 flex items-center gap-1.5 text-xs text-muted">
                  <Clock className="size-3.5" aria-hidden /> Expira em <span className="font-semibold tabular-nums text-fg">{fmt(left)}</span>
                </p>
              </div>
              <div className="flex items-center gap-2">
                <CopyButton value={link.code} label="Copiar código" className="size-10 border border-border bg-surface" />
                {link.wa_link && (
                  <ButtonAnchor href={link.wa_link} icon={<ExternalLink className="size-4" />}>
                    Abrir WhatsApp
                  </ButtonAnchor>
                )}
              </div>
            </div>
            <p className="flex items-center gap-2 text-xs text-subtle">
              <RefreshCw className="size-3.5 animate-spin [animation-duration:3s]" aria-hidden /> À espera da tua mensagem…
            </p>
          </div>
        ) : (
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-sm text-muted">
              {link ? (
                <span className="text-warning">O código expirou. Gera um novo para tentar outra vez.</span>
              ) : (
                <>Geramos um código de uso único; envias esse código pelo WhatsApp e o teu número fica ligado a esta conta.</>
              )}
            </p>
            <Button icon={link ? <RefreshCw className="size-4" /> : <MessageCircle className="size-4" />} loading={create.isPending} onClick={() => create.mutate()} className="shrink-0">
              {link ? 'Gerar novo código' : 'Ligar WhatsApp'}
            </Button>
          </div>
        )}
      </div>
    </Card>
  )
}
