/** Botão flutuante "Ajuda" + painel de chat (ecrã inteiro no telemóvel). */
import { useEffect, useRef, useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import clsx from 'clsx'
import { Bot, History, MessageCircle, SquarePen, X } from 'lucide-react'
import { useAssistantStatus } from '../../api/assistant'
import { AssistantChat } from './AssistantChat'
import { chatStore, useChatState } from './chatStore'

const OPEN_EVENT = 'tk:assistant-open'

/** Abre o painel do assistente a partir de qualquer sítio (ex.: um botão "Falar com o assistente"). */
export function openAssistant() {
  window.dispatchEvent(new CustomEvent(OPEN_EVENT))
}

export function AssistantLauncher({ bottomNav = false }: { bottomNav?: boolean }) {
  const status = useAssistantStatus()
  const loc = useLocation()
  const [open, setOpen] = useState(false)
  const state = useChatState()
  const [seenRev, setSeenRev] = useState(state.rev)
  const panel = useRef<HTMLDivElement>(null)
  const launcher = useRef<HTMLButtonElement>(null)
  const onHelpPage = loc.pathname.startsWith('/app/ajuda')
  // Na administração o botão tapava conteúdo; o chat de cliente testa-se nas páginas /app.
  const hidden = onHelpPage || loc.pathname.startsWith('/admin')

  useEffect(() => {
    const on = () => setOpen(true)
    window.addEventListener(OPEN_EVENT, on)
    return () => window.removeEventListener(OPEN_EVENT, on)
  }, [])

  useEffect(() => {
    if (open) setSeenRev(state.rev)
  }, [open, state.rev])

  // Fecha ao navegar para a página Ajuda (lá a conversa está em página inteira).
  useEffect(() => {
    if (onHelpPage) setOpen(false)
  }, [onHelpPage])

  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== 'Escape' || e.defaultPrevented) return
      if (document.querySelector('dialog[open]')) return // um diálogo por cima trata o seu próprio ESC
      setOpen(false)
      window.setTimeout(() => launcher.current?.focus(), 0)
    }
    document.addEventListener('keydown', onKey)
    // No telemóvel o painel ocupa o ecrã: bloqueia o scroll da página por baixo.
    const mobile = window.matchMedia('(max-width: 639px)').matches
    if (mobile) document.body.style.overflow = 'hidden'
    return () => {
      document.removeEventListener('keydown', onKey)
      if (mobile) document.body.style.overflow = ''
    }
  }, [open])

  if (!status.data?.enabled || hidden) return null

  const unread = !open && state.rev > seenRev
  const close = () => {
    setOpen(false)
    window.setTimeout(() => launcher.current?.focus(), 0)
  }

  return (
    <>
      {!open && (
        <button
          ref={launcher}
          type="button"
          onClick={() => setOpen(true)}
          aria-haspopup="dialog"
          aria-expanded={false}
          className={clsx(
            'animate-fade-in fixed right-4 z-40 inline-flex h-12 items-center gap-2 rounded-full bg-brand pl-4 pr-5 text-sm font-bold text-brand-fg shadow-[var(--shadow-pop)] transition-transform hover:scale-[1.03] hover:bg-brand-hover focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand sm:right-6',
            bottomNav ? 'bottom-[calc(4.75rem+env(safe-area-inset-bottom))] lg:bottom-6' : 'bottom-5 sm:bottom-6',
          )}
        >
          <MessageCircle className="size-5" aria-hidden />
          Ajuda
          {(unread || state.sending) && (
            <span className="absolute -right-0.5 -top-0.5 flex size-3.5">
              {state.sending && <span className="absolute inline-flex size-full animate-ping rounded-full bg-info opacity-75" />}
              <span className="relative inline-flex size-3.5 rounded-full border-2 border-bg bg-info" />
              <span className="sr-only">{state.sending ? 'O assistente está a responder' : 'Nova resposta do assistente'}</span>
            </span>
          )}
        </button>
      )}

      {open && (
        <div
          ref={panel}
          role="dialog"
          aria-label="Assistente TK Web Services"
          className={clsx(
            'animate-chat-in fixed inset-0 z-[60] flex flex-col bg-surface',
            'sm:inset-auto sm:bottom-6 sm:right-6 sm:h-[min(680px,calc(100dvh-3rem))] sm:w-[400px] sm:overflow-hidden sm:rounded-2xl sm:border sm:border-border sm:shadow-[var(--shadow-pop)]',
          )}
        >
          <header className="flex items-center gap-2 border-b border-border px-3 pb-2.5 pt-[max(0.625rem,env(safe-area-inset-top))] sm:pt-2.5">
            <span className="grid size-9 shrink-0 place-items-center rounded-xl bg-brand-soft text-brand-text">
              <Bot className="size-5" aria-hidden />
            </span>
            <div className="min-w-0 flex-1">
              <h2 className="truncate text-sm font-semibold leading-tight">Assistente TK Web Services</h2>
              <p className="truncate text-xs text-muted">Faturação e suporte</p>
            </div>
            <button
              type="button"
              onClick={() => chatStore.reset()}
              disabled={state.sending || !state.messages.length}
              className="grid size-9 place-items-center rounded-lg text-muted hover:bg-elevated hover:text-fg disabled:opacity-40"
              aria-label="Nova conversa"
              title="Nova conversa"
            >
              <SquarePen className="size-[18px]" />
            </button>
            <Link
              to="/app/ajuda"
              className="grid size-9 place-items-center rounded-lg text-muted hover:bg-elevated hover:text-fg"
              aria-label="Histórico de conversas"
              title="Histórico de conversas"
            >
              <History className="size-[18px]" />
            </Link>
            <button type="button" onClick={close} className="grid size-9 place-items-center rounded-lg text-muted hover:bg-elevated hover:text-fg" aria-label="Fechar assistente" title="Fechar (Esc)">
              <X className="size-5" />
            </button>
          </header>
          <AssistantChat compact autoFocus className="pb-[env(safe-area-inset-bottom)] sm:pb-0" />
        </div>
      )}
    </>
  )
}
