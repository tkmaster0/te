/** Conversa com os assistentes (usada no painel flutuante e na página Ajuda). */
import { useEffect, useLayoutEffect, useRef, useState, type ReactNode } from 'react'
import { useQueryClient } from '@tanstack/react-query'
import clsx from 'clsx'
import {
  AlertTriangle,
  ArrowRightLeft,
  Bot,
  CheckCircle2,
  Clock,
  SendHorizontal,
  ShieldQuestion,
  ThumbsDown,
  ThumbsUp,
  XCircle,
} from 'lucide-react'
import { akeys } from '../../api/assistant'
import { useMe } from '../../auth/AuthProvider'
import { Button, Spinner } from '../ui'
import { Markdown } from './Markdown'
import { AGENT_LABEL, AgentBadge, AgentIcon, CHANNEL_LABEL } from './labels'
import { chatStore, useChatState, type LocalMessage } from './chatStore'

export const SUGGESTIONS = [
  'As legendas estão dessincronizadas',
  'Quando é a próxima cobrança?',
  'Como instalo a app na TV?',
  'Quero mudar de plano',
]

function timeOf(iso: string | null) {
  if (!iso) return ''
  const d = new Date(iso)
  return Number.isNaN(d.getTime()) ? '' : d.toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' })
}

// ------------------------------------------------------------------ mensagens
function UserBubble({ m }: { m: LocalMessage }) {
  return (
    <li className="flex flex-col items-end gap-1 pl-10">
      <div
        className={clsx(
          'max-w-full whitespace-pre-wrap break-words rounded-2xl rounded-br-md px-3.5 py-2 text-sm leading-relaxed [overflow-wrap:anywhere]',
          m.local === 'failed' ? 'border border-danger/40 bg-danger-soft text-fg' : 'bg-brand text-brand-fg',
          m.local === 'sending' && 'opacity-80',
        )}
      >
        {m.content}
      </div>
      {m.local === 'failed' ? (
        <div className="flex items-center gap-2 text-xs text-danger">
          <XCircle className="size-3.5" aria-hidden /> Não enviada
          <button type="button" className="font-semibold underline underline-offset-2 hover:no-underline" onClick={() => chatStore.retry(m.key)}>
            Tentar de novo
          </button>
          <button type="button" className="text-muted hover:text-fg" onClick={() => chatStore.discard(m.key)}>
            Descartar
          </button>
        </div>
      ) : (
        <span className="text-[11px] text-subtle">{m.local === 'sending' ? 'A enviar…' : timeOf(m.created_at)}</span>
      )}
    </li>
  )
}

function Avatar({ agent }: { agent: string }) {
  return (
    <span
      className={clsx(
        'mt-0.5 grid size-8 shrink-0 place-items-center rounded-full',
        agent === 'billing' ? 'bg-brand-soft text-brand-text' : 'bg-info-soft text-info',
      )}
      aria-hidden
    >
      <AgentIcon agent={agent} className="size-4" />
    </span>
  )
}

function FeedbackButtons({ m }: { m: LocalMessage }) {
  return (
    <div className="flex items-center gap-0.5" role="group" aria-label="Avaliar esta resposta">
      <button
        type="button"
        onClick={() => chatStore.feedback(m.id, 1)}
        aria-pressed={m.feedback === 1}
        aria-label="Resposta útil"
        title="Resposta útil"
        className={clsx('grid size-7 place-items-center rounded-lg transition-colors hover:bg-elevated', m.feedback === 1 ? 'text-success' : 'text-subtle hover:text-fg')}
      >
        <ThumbsUp className="size-3.5" fill={m.feedback === 1 ? 'currentColor' : 'none'} />
      </button>
      <button
        type="button"
        onClick={() => chatStore.feedback(m.id, -1)}
        aria-pressed={m.feedback === -1}
        aria-label="Resposta pouco útil"
        title="Resposta pouco útil"
        className={clsx('grid size-7 place-items-center rounded-lg transition-colors hover:bg-elevated', m.feedback === -1 ? 'text-danger' : 'text-subtle hover:text-fg')}
      >
        <ThumbsDown className="size-3.5" fill={m.feedback === -1 ? 'currentColor' : 'none'} />
      </button>
      {m.feedback === -1 && <span className="ml-1 text-[11px] text-muted">Obrigado — vamos rever esta resposta.</span>}
    </div>
  )
}

function AssistantBubble({ m, showAgent }: { m: LocalMessage; showAgent: boolean }) {
  const result = m.ui?.type === 'action_result' && (m.ui.status === 'done' || m.ui.status === 'failed')
  const failed = result && m.ui?.status === 'failed'
  return (
    <li className="flex gap-2.5 pr-6">
      <Avatar agent={m.agent} />
      <div className="min-w-0 flex-1">
        <div
          className={clsx(
            'rounded-2xl rounded-tl-md border px-3.5 py-2.5 text-sm leading-relaxed text-fg/90',
            result ? (failed ? 'border-danger/30 bg-danger-soft' : 'border-success/30 bg-success-soft') : 'border-border bg-elevated',
          )}
        >
          {result && (
            <p className={clsx('mb-1 flex items-center gap-1.5 text-xs font-semibold', failed ? 'text-danger' : 'text-success')}>
              {failed ? <XCircle className="size-3.5" aria-hidden /> : <CheckCircle2 className="size-3.5" aria-hidden />}
              {failed ? 'Não foi possível concluir' : 'Pedido tratado'}
            </p>
          )}
          <Markdown text={m.content ?? ''} />
        </div>
        <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1">
          <AgentBadge agent={m.agent} className={clsx('!px-2 !text-[11px]', !showAgent && 'opacity-70')} />
          <span className="text-[11px] text-subtle">{timeOf(m.created_at)}</span>
          {m.id > 0 && <FeedbackButtons m={m} />}
        </div>
      </div>
    </li>
  )
}

function SwitchDivider({ m }: { m: LocalMessage }) {
  const agent = m.ui?.agent ?? m.agent
  return (
    <li className="flex items-center gap-3 py-1" role="note">
      <span className="h-px flex-1 bg-border" aria-hidden />
      <span className="inline-flex items-center gap-1.5 text-xs font-medium text-muted">
        <ArrowRightLeft className="size-3.5" aria-hidden />
        A falar com o Agente de {AGENT_LABEL[agent] ?? agent}
      </span>
      <span className="h-px flex-1 bg-border" aria-hidden />
    </li>
  )
}

const RESOLVED: Record<string, { label: string; icon: ReactNode; cls: string }> = {
  done: { label: 'Confirmaste este pedido', icon: <CheckCircle2 className="size-4" aria-hidden />, cls: 'text-success' },
  failed: { label: 'Confirmado, mas não foi possível concluir', icon: <XCircle className="size-4" aria-hidden />, cls: 'text-danger' },
  cancelled: { label: 'Pedido cancelado — nada foi alterado', icon: <XCircle className="size-4" aria-hidden />, cls: 'text-muted' },
  expired: { label: 'Este pedido expirou — pede de novo se ainda quiseres', icon: <Clock className="size-4" aria-hidden />, cls: 'text-muted' },
}

function ConfirmCard({ m, deciding }: { m: LocalMessage; deciding: boolean }) {
  const id = m.ui?.action_id ?? ''
  const status = m.ui?.status ?? 'pending'
  const pending = status === 'pending'
  const r = RESOLVED[status]
  return (
    <li className="flex gap-2.5 pr-2">
      <Avatar agent={m.agent} />
      <div
        className={clsx(
          'min-w-0 flex-1 rounded-2xl border p-3.5',
          pending ? 'border-brand/50 bg-brand-soft/60' : 'border-border bg-surface',
        )}
        role="group"
        aria-label="Pedido de confirmação"
      >
        <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-brand-text">
          <ShieldQuestion className="size-4" aria-hidden /> {pending ? 'Confirmas este pedido?' : 'Pedido de confirmação'}
        </p>
        <p className={clsx('mt-1.5 text-sm font-medium leading-relaxed', !pending && 'text-muted')}>{m.ui?.summary ?? m.content}</p>
        {pending ? (
          <>
            <div className="mt-3 flex flex-wrap gap-2">
              <Button size="sm" loading={deciding} disabled={deciding} onClick={() => chatStore.decide(id, true)}>
                Confirmar
              </Button>
              <Button size="sm" variant="secondary" disabled={deciding} onClick={() => chatStore.decide(id, false)}>
                Cancelar
              </Button>
            </div>
            <p className="mt-2 text-[11px] text-subtle">Nada muda na tua conta sem confirmares. Válido durante 30 minutos.</p>
          </>
        ) : (
          r && (
            <p className={clsx('mt-2 flex items-center gap-1.5 text-xs font-semibold', r.cls)}>
              {r.icon}
              {r.label}
            </p>
          )
        )}
      </div>
    </li>
  )
}

function TypingIndicator() {
  const [slow, setSlow] = useState(false)
  useEffect(() => {
    const t = window.setTimeout(() => setSlow(true), 8000)
    return () => window.clearTimeout(t)
  }, [])
  return (
    <li className="flex items-center gap-2.5" aria-hidden>
      <span className="grid size-8 shrink-0 place-items-center rounded-full bg-elevated text-muted">
        <Bot className="size-4" />
      </span>
      <div className="flex items-center gap-2 rounded-2xl rounded-tl-md border border-border bg-elevated px-3.5 py-2.5">
        <span className="flex gap-1">
          {[0, 1, 2].map((i) => (
            <span key={i} className="tk-typing-dot size-1.5 rounded-full bg-muted" style={{ animationDelay: `${i * 160}ms` }} />
          ))}
        </span>
        {slow && <span className="text-xs text-muted">A consultar a tua conta — pode demorar até 30 segundos…</span>}
      </div>
    </li>
  )
}

function Welcome({ compact, onPick, disabled }: { compact?: boolean; onPick: (s: string) => void; disabled: boolean }) {
  const me = useMe()
  const first = (me.display_name || me.username).split(' ')[0]
  return (
    <div className={clsx('flex flex-col items-center text-center', compact ? 'px-2 py-6' : 'px-4 py-10')}>
      <span className="grid size-12 place-items-center rounded-2xl bg-brand-soft text-brand-text">
        <Bot className="size-6" aria-hidden />
      </span>
      <h3 className="mt-3 text-base font-semibold">Olá, {first}! Em que posso ajudar?</h3>
      <p className="mt-1 max-w-sm text-sm text-muted">
        Trato da <strong className="text-fg">faturação</strong> (cobranças, planos, pagamentos) e do <strong className="text-fg">suporte</strong> ao streaming (apps,
        legendas, reprodução, pedidos).
      </p>
      <div className="mt-4 flex max-w-md flex-wrap justify-center gap-2">
        {SUGGESTIONS.map((s) => (
          <button
            key={s}
            type="button"
            disabled={disabled}
            onClick={() => onPick(s)}
            className="rounded-full border border-border bg-surface px-3 py-1.5 text-[13px] font-medium text-fg/90 transition-colors hover:border-brand hover:text-fg disabled:opacity-50"
          >
            {s}
          </button>
        ))}
      </div>
    </div>
  )
}

// ------------------------------------------------------------------ composer
function Composer({ onSend, disabled, busy, autoFocus }: { onSend: (t: string) => void; disabled: boolean; busy: boolean; autoFocus?: boolean }) {
  const [text, setText] = useState('')
  const ref = useRef<HTMLTextAreaElement>(null)

  useLayoutEffect(() => {
    const el = ref.current
    if (!el) return
    el.style.height = 'auto'
    el.style.height = `${Math.min(el.scrollHeight, 140)}px`
  }, [text])

  useEffect(() => {
    if (autoFocus) ref.current?.focus({ preventScroll: true })
  }, [autoFocus])

  const submit = () => {
    const t = text.trim()
    if (!t || busy || disabled) return
    onSend(t)
    setText('')
    ref.current?.focus()
  }

  return (
    <form
      className="border-t border-border bg-surface p-3"
      onSubmit={(e) => {
        e.preventDefault()
        submit()
      }}
    >
      <div className="flex items-end gap-2 rounded-2xl border border-border bg-bg p-1.5 pl-3.5 transition-colors focus-within:border-brand focus-within:ring-2 focus-within:ring-brand/30">
        <label htmlFor="tk-assistant-input" className="sr-only">
          Mensagem para o assistente
        </label>
        <textarea
          id="tk-assistant-input"
          ref={ref}
          rows={1}
          value={text}
          maxLength={4000}
          disabled={disabled}
          placeholder={disabled ? 'O assistente não está disponível' : 'Escreve a tua mensagem…'}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
              e.preventDefault()
              submit()
            }
          }}
          className="scrollbar-thin max-h-36 min-h-9 flex-1 resize-none bg-transparent py-2 text-sm leading-snug text-fg placeholder:text-subtle focus:outline-none disabled:cursor-not-allowed"
        />
        <button
          type="submit"
          disabled={!text.trim() || busy || disabled}
          aria-label="Enviar"
          title="Enviar (Enter)"
          className="grid size-9 shrink-0 place-items-center rounded-xl bg-brand text-brand-fg transition-colors hover:bg-brand-hover disabled:cursor-not-allowed disabled:opacity-40"
        >
          {busy ? <Spinner className="size-4" /> : <SendHorizontal className="size-4" />}
        </button>
      </div>
      <p className="mt-1.5 px-1 text-[11px] text-subtle">O assistente pode enganar-se. Alterações na tua conta pedem sempre a tua confirmação.</p>
    </form>
  )
}

// ------------------------------------------------------------------ conversa
export function AssistantChat({ compact, autoFocus, disabled, className }: { compact?: boolean; autoFocus?: boolean; disabled?: boolean; className?: string }) {
  const state = useChatState()
  const qc = useQueryClient()
  const scroller = useRef<HTMLDivElement>(null)
  const [announce, setAnnounce] = useState('')

  useEffect(() => {
    chatStore.start()
    chatStore.onServerChange = () => void qc.invalidateQueries({ queryKey: akeys.conversations })
  }, [qc])

  useEffect(() => {
    if (state.error?.kind === 'disabled') void qc.invalidateQueries({ queryKey: akeys.status })
  }, [state.error, qc])

  // Scroll para o fim quando chegam mensagens (ou quando o cliente envia).
  useLayoutEffect(() => {
    const el = scroller.current
    if (el) el.scrollTop = el.scrollHeight
  }, [state.messages.length, state.sending, state.loading])

  // Anuncia a última resposta a leitores de ecrã (texto curto, sem markdown).
  useEffect(() => {
    if (!state.rev) return
    const last = [...state.messages].reverse().find((m) => m.role !== 'user')
    if (!last) return
    const txt =
      last.ui?.type === 'confirm'
        ? `Pedido de confirmação: ${last.ui.summary ?? ''}`
        : last.ui?.type === 'agent_switch'
          ? last.content ?? ''
          : `${AGENT_LABEL[last.agent] ?? 'Assistente'}: ${(last.content ?? '').replace(/[*_`#[\]()]/g, '').slice(0, 300)}`
    setAnnounce(txt)
  }, [state.rev]) // eslint-disable-line react-hooks/exhaustive-deps

  const empty = !state.messages.length && !state.loading
  // O servidor grava o pedido de confirmação antes da frase do agente que o explica; mostramos a frase primeiro.
  const ordered = [...state.messages]
  for (let i = 0; i < ordered.length - 1; i++) {
    const a = ordered[i]
    const b = ordered[i + 1]
    if (a.ui?.type === 'confirm' && b.role === 'assistant' && !b.ui && b.agent === a.agent) {
      ordered[i] = b
      ordered[i + 1] = a
      i++
    }
  }
  let lastAgent = ''

  return (
    <div className={clsx('flex min-h-0 flex-1 flex-col', className)}>
      <div ref={scroller} className="scrollbar-thin min-h-0 flex-1 overflow-y-auto px-3 py-4 sm:px-4">
        {state.loading && !state.messages.length ? (
          <div className="flex h-full items-center justify-center gap-2 text-sm text-muted">
            <Spinner className="size-4 text-brand" /> A carregar a conversa…
          </div>
        ) : empty ? (
          <Welcome compact={compact} onPick={(s) => void chatStore.send(s)} disabled={!!disabled || state.sending} />
        ) : (
          <ol className="space-y-4" aria-label="Mensagens">
            {ordered.map((m) => {
              if (m.role === 'user') return <UserBubble key={m.key} m={m} />
              if (m.role === 'event' && m.ui?.type === 'agent_switch') {
                lastAgent = m.ui.agent ?? m.agent
                return <SwitchDivider key={m.key} m={m} />
              }
              if (m.role === 'event' && m.ui?.type === 'confirm') return <ConfirmCard key={m.key} m={m} deciding={!!state.deciding[m.ui.action_id ?? '']} />
              if (m.role === 'event')
                return (
                  <li key={m.key} className="text-center text-xs text-muted">
                    {m.content}
                  </li>
                )
              const show = m.agent !== lastAgent
              lastAgent = m.agent
              return <AssistantBubble key={m.key} m={m} showAgent={show} />
            })}
            {state.sending && <TypingIndicator />}
          </ol>
        )}
      </div>

      {state.error && (
        <div
          role="alert"
          className={clsx(
            'mx-3 mb-2 flex items-start gap-2 rounded-xl border px-3 py-2 text-xs',
            state.error.kind === 'rate' ? 'border-warning/30 bg-warning-soft' : 'border-danger/30 bg-danger-soft',
          )}
        >
          <AlertTriangle className={clsx('mt-px size-4 shrink-0', state.error.kind === 'rate' ? 'text-warning' : 'text-danger')} aria-hidden />
          <p className="min-w-0 flex-1 text-fg/90">{state.error.text}</p>
          <button type="button" className="shrink-0 font-semibold text-muted hover:text-fg" onClick={() => chatStore.clearError()} aria-label="Fechar aviso">
            OK
          </button>
        </div>
      )}

      {state.channel && state.channel !== 'web' && state.messages.length > 0 && (
        <p className="mx-3 mb-2 rounded-xl bg-elevated px-3 py-2 text-xs text-muted">
          Esta conversa foi pelo {CHANNEL_LABEL[state.channel] ?? state.channel}. Se escreveres aqui, começas uma conversa nova no portal.
        </p>
      )}

      <div className="sr-only" aria-live="polite" aria-atomic="true">
        {state.sending ? 'O assistente está a escrever…' : announce}
      </div>

      <Composer onSend={(t) => void chatStore.send(t)} disabled={!!disabled || state.error?.kind === 'disabled'} busy={state.sending} autoFocus={autoFocus} />
    </div>
  )
}
