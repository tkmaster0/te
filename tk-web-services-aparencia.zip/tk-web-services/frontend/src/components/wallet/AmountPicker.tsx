import { useEffect, useState } from 'react'
import clsx from 'clsx'
import { formatMoney } from '../../lib/format'

/** "12,5" / "12.50" / "12" → cêntimos (null se inválido). */
export function parseEuros(value: string): number | null {
  const v = value.trim().replace(/\s|€/g, '').replace(',', '.')
  if (!v) return null
  if (!/^\d+(\.\d{0,2})?$/.test(v)) return null
  return Math.round(Number(v) * 100)
}

export function centsToInput(cents: number): string {
  return (cents / 100).toFixed(2).replace('.', ',').replace(/,00$/, '')
}

/** Escolha de montante: botões rápidos + valor livre em euros. */
export function AmountPicker({
  value,
  onChange,
  presets,
  min,
  max,
  label = 'Montante',
  suggested,
}: {
  value: number
  onChange: (cents: number) => void
  presets: number[]
  min: number
  max: number
  label?: string
  suggested?: number | null
}) {
  const [text, setText] = useState(centsToInput(value))
  useEffect(() => {
    if (parseEuros(text) !== value) setText(centsToInput(value))
  }, [value])
  const parsed = parseEuros(text)
  const error = parsed === null ? 'Indica um valor em euros.' : parsed < min ? `Mínimo ${formatMoney(min)}.` : parsed > max ? `Máximo ${formatMoney(max)}.` : null
  const list = Array.from(new Set([...(suggested ? [suggested] : []), ...presets])).sort((a, b) => a - b)
  return (
    <div className="space-y-3">
      <div role="group" aria-label={label} className="flex flex-wrap gap-2">
        {list.map((c) => {
          const active = c === value
          return (
            <button
              key={c}
              type="button"
              onClick={() => onChange(c)}
              aria-pressed={active}
              className={clsx(
                'relative rounded-xl border px-4 py-2.5 text-sm font-semibold tabular-nums transition-colors',
                active ? 'border-brand bg-brand text-brand-fg' : 'border-border bg-elevated hover:border-border-strong',
              )}
            >
              {formatMoney(c)}
              {suggested === c && (
                <span className={clsx('ml-1.5 text-[10px] font-bold uppercase tracking-wide', active ? 'text-brand-fg/70' : 'text-brand-text')}>
                  sugerido
                </span>
              )}
            </button>
          )
        })}
      </div>
      <div>
        <label className="sr-only" htmlFor="amount-free">
          Outro valor (€)
        </label>
        <div className="relative max-w-[12rem]">
          <input
            id="amount-free"
            inputMode="decimal"
            value={text}
            onChange={(e) => {
              setText(e.target.value)
              const c = parseEuros(e.target.value)
              if (c !== null && c >= min && c <= max) onChange(c)
            }}
            className="h-11 w-full rounded-xl border border-border bg-bg pl-3.5 pr-9 text-base font-semibold tabular-nums outline-none focus:border-brand"
            aria-invalid={!!error}
          />
          <span className="pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2 text-muted">€</span>
        </div>
        {error && <p className="mt-1.5 text-xs font-medium text-danger">{error}</p>}
      </div>
    </div>
  )
}
