import { Link } from 'react-router-dom'
import { ArrowRight, Dices, PiggyBank, Plus, Wallet } from 'lucide-react'
import type { WalletSummary } from '../../api/types'
import { formatLongDate, formatMoney } from '../../lib/format'

/** Resumo da carteira no início: saldo, carregamento (mensal, se ligado) e atalho para jogar. */
export function WalletStrip({ w }: { w: WalletSummary }) {
  if (!w.enabled) return null
  return (
    <Link
      to="/app/carteira"
      className="group flex flex-col gap-4 rounded-2xl border border-border bg-gradient-to-r from-brand-soft via-surface to-surface p-5 transition-colors hover:border-brand/50 sm:flex-row sm:items-center sm:p-6"
    >
      <span className="grid size-12 shrink-0 place-items-center rounded-2xl bg-brand text-brand-fg">
        <Wallet className="size-6" aria-hidden />
      </span>
      <span className="min-w-0 flex-1">
        <span className="block text-sm text-muted">Carteira</span>
        <span className="block text-2xl font-extrabold tabular-nums">{formatMoney(w.balance_cents)}</span>
      </span>
      <span className="flex flex-wrap items-center gap-2 text-sm">
        {!w.monthly_enabled ? (
          <span className="inline-flex items-center gap-1.5 rounded-full bg-elevated px-3 py-1 text-muted">
            <Plus className="size-4" aria-hidden /> Carregar
          </span>
        ) : w.monthly_topup_cents ? (
          <span className="inline-flex items-center gap-1.5 rounded-full bg-success-soft px-3 py-1 font-semibold text-success">
            <PiggyBank className="size-4" aria-hidden /> {formatMoney(w.monthly_topup_cents)}/mês · {formatLongDate(w.next_billing_at)}
          </span>
        ) : (
          <span className="inline-flex items-center gap-1.5 rounded-full bg-brand-soft px-3 py-1 font-semibold text-brand-text">
            <PiggyBank className="size-4" aria-hidden /> Ativar créditos mensais
          </span>
        )}
        {w.games_enabled && (
          <span className="inline-flex items-center gap-1.5 rounded-full bg-elevated px-3 py-1 text-muted">
            <Dices className="size-4" aria-hidden /> Jogos
          </span>
        )}
        <ArrowRight className="size-5 text-muted transition-transform group-hover:translate-x-0.5" aria-hidden />
      </span>
    </Link>
  )
}
