import { useState } from 'react'
import { Megaphone, MailWarning, X } from 'lucide-react'
import { useConfig } from '../api/queries'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { Link, useLocation } from 'react-router-dom'
import { api, errorMessage } from '../api/client'
import { useAction } from '../api/mutation'
import { readStorage, writeStorage } from '../lib/storage'
import { Button } from './ui'
import type { Me } from '../api/types'

function hash(s: string): string {
  let h = 0
  for (let i = 0; i < s.length; i++) h = (Math.imul(31, h) + s.charCodeAt(i)) | 0
  return String(h)
}

export function AnnouncementBanner() {
  const { data } = useConfig()
  const text = data?.site.announcement?.trim()
  const key = text ? `tk-ann-${hash(text)}` : ''
  const [dismissed, setDismissed] = useState(() => (key ? readStorage(key) === '1' : false))
  const [dismissedKey, setDismissedKey] = useState(key)
  if (key !== dismissedKey) {
    setDismissedKey(key)
    setDismissed(key ? readStorage(key) === '1' : false)
  }
  if (!text || dismissed) return null
  return (
    <div className="border-b border-brand/30 bg-brand-soft">
      <div className="mx-auto flex max-w-7xl items-start gap-3 px-4 py-2.5 text-sm sm:items-center">
        <Megaphone className="mt-0.5 size-4 shrink-0 text-brand-text sm:mt-0" aria-hidden />
        <p className="min-w-0 flex-1 whitespace-pre-line text-fg">{text}</p>
        <button
          type="button"
          onClick={() => {
            writeStorage(key, '1')
            setDismissed(true)
          }}
          className="grid size-7 shrink-0 place-items-center rounded-md text-muted hover:bg-brand-soft hover:text-fg"
          aria-label="Fechar aviso"
        >
          <X className="size-4" />
        </button>
      </div>
    </div>
  )
}

export function EmailVerifyBanner({ me }: { me: Me }) {
  const { data } = useConfig()
  const qc = useQueryClient()
  const [code, setCode] = useState('')
  const resend = useAction(() => api.post('/api/auth/resend-verification'), { success: 'Enviámos um novo código.' })
  const verify = useAction((c: string) => api.post('/api/auth/verify-code', { code: c }), {
    errorTitle: false,
    onSuccess: () => qc.invalidateQueries(),
  })
  if (me.email_verified || data?.require_email_verification === false) return null
  const submit = (c: string) => {
    if (c.length === 6 && !verify.isPending) verify.mutate(c)
  }
  return (
    <div className="border-b border-warning/30 bg-warning-soft">
      <form
        className="mx-auto flex max-w-6xl flex-wrap items-center gap-x-3 gap-y-2 px-4 py-2.5 text-sm sm:px-6 lg:px-8"
        onSubmit={(e) => {
          e.preventDefault()
          submit(code)
        }}
      >
        <MailWarning className="size-4 shrink-0 text-warning" aria-hidden />
        <p className="min-w-0 flex-1">
          <span className="font-semibold">Confirma o teu email.</span>{' '}
          <span className="text-fg/80">
            Enviámos um código de 6 dígitos para <strong className="break-all">{me.email}</strong>.
          </span>
          {verify.isError && <span className="ml-2 font-medium text-danger">{errorMessage(verify.error)}</span>}
        </p>
        <label htmlFor="otp-code" className="sr-only">
          Código de confirmação
        </label>
        <input
          id="otp-code"
          value={code}
          onChange={(e) => {
            const v = e.target.value.replace(/\D/g, '').slice(0, 6)
            setCode(v)
            if (v.length === 6) submit(v)
          }}
          inputMode="numeric"
          autoComplete="one-time-code"
          placeholder="000000"
          className="h-9 w-28 rounded-lg border border-border bg-bg px-3 text-center font-mono text-base tracking-[0.3em] outline-none focus:border-brand"
        />
        <Button size="sm" type="submit" loading={verify.isPending} disabled={code.length !== 6}>
          Confirmar
        </Button>
        <Button size="sm" variant="ghost" loading={resend.isPending} onClick={() => resend.mutate()}>
          Reenviar
        </Button>
      </form>
    </div>
  )
}


/** Para o administrador: lembra a configuração inicial (assistente) enquanto não estiver concluída. */
export function SetupBanner({ me }: { me: Me }) {
  const q = useQuery({
    queryKey: ['admin', 'setup'],
    queryFn: () => api.get<{ completed: boolean }>('/api/admin/setup'),
    enabled: !!me.is_admin,
    staleTime: 60_000,
  })
  const { pathname } = useLocation()
  if (!me.is_admin || !q.data || q.data.completed || pathname.startsWith('/admin/configurar')) return null
  return (
    <div className="border-b border-brand/30 bg-brand-soft">
      <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-3 px-4 py-2.5 text-sm sm:px-6">
        <span className="font-semibold text-brand-text">Configuração inicial por concluir.</span>
        <span className="text-fg/80">Endereço, túnel, pagamentos e integrações — tudo por web.</span>
        <Link to="/admin/configurar" className="ml-auto font-semibold text-brand-text underline-offset-2 hover:underline">
          Continuar →
        </Link>
      </div>
    </div>
  )
}
