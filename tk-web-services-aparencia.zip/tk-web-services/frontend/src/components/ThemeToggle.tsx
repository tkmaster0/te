import { Monitor, Moon, Sun } from 'lucide-react'
import clsx from 'clsx'
import { useTheme, type ThemePref } from '../lib/theme'

const options: { value: ThemePref; label: string; icon: typeof Sun }[] = [
  { value: 'dark', label: 'Escuro', icon: Moon },
  { value: 'light', label: 'Claro', icon: Sun },
  { value: 'system', label: 'Sistema', icon: Monitor },
]

/** Seletor de tema em 3 posições (escuro / claro / sistema). */
export function ThemeSegmented({ className }: { className?: string }) {
  const { pref, setPref } = useTheme()
  return (
    <div role="radiogroup" aria-label="Tema" className={clsx('inline-flex rounded-xl border border-border bg-bg p-0.5', className)}>
      {options.map((o) => {
        const Icon = o.icon
        const active = pref === o.value
        return (
          <button
            key={o.value}
            type="button"
            role="radio"
            aria-checked={active}
            onClick={() => setPref(o.value)}
            title={o.label}
            className={clsx(
              'flex items-center gap-1.5 rounded-[10px] px-2.5 py-1.5 text-xs font-medium transition-colors',
              active ? 'bg-elevated text-fg shadow-sm' : 'text-muted hover:text-fg',
            )}
          >
            <Icon className="size-3.5" aria-hidden />
            <span>{o.label}</span>
          </button>
        )
      })}
    </div>
  )
}

/** Botão compacto que alterna escuro/claro. */
export function ThemeToggleButton({ className }: { className?: string }) {
  const { resolved, setPref } = useTheme()
  const next = resolved === 'dark' ? 'light' : 'dark'
  return (
    <button
      type="button"
      onClick={() => setPref(next)}
      className={clsx('grid size-10 place-items-center rounded-xl text-muted hover:bg-elevated hover:text-fg', className)}
      aria-label={resolved === 'dark' ? 'Mudar para tema claro' : 'Mudar para tema escuro'}
      title={resolved === 'dark' ? 'Tema claro' : 'Tema escuro'}
    >
      {resolved === 'dark' ? <Sun className="size-5" /> : <Moon className="size-5" />}
    </button>
  )
}
