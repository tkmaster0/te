import { useEffect, useRef, useState } from 'react'
import { api } from '../../api/client'
import { useAction } from '../../api/mutation'
import { keys } from '../../api/keys'
import type { AdminPlan, AdminProduct } from '../../api/types'
import { formatMoney, perInterval } from '../../lib/format'
import { Alert, Button, Checkbox, Field, Modal, Select, Textarea } from '../ui'

const INVALIDATE = [['admin', 'products'], keys.catalog, keys.products]

/** Move todos os subscritores de um plano para outro do mesmo produto (com simulação primeiro). */
export function MigrateDialog({ plan, product, onClose }: { plan: AdminPlan; product: AdminProduct; onClose: () => void }) {
  const others = product.plans.filter((p) => p.id !== plan.id)
  const [to, setTo] = useState<number | ''>(others.find((p) => p.is_active)?.id ?? others[0]?.id ?? '')
  const [when, setWhen] = useState<'renewal' | 'now'>('renewal')
  const [keepPrice, setKeepPrice] = useState(false)
  const [notify, setNotify] = useState(true)
  const [note, setNote] = useState('')
  const [dry, setDry] = useState<number | null>(null)
  const dryRef = useRef<HTMLDivElement>(null)
  // Mostra o resultado da simulação (fica no fim do formulário, muitas vezes fora de vista).
  useEffect(() => {
    if (dry !== null) dryRef.current?.scrollIntoView({ block: 'nearest', behavior: 'smooth' })
  }, [dry])
  const [result, setResult] = useState<{ affected: number; errors?: { user: string; error: string }[] } | null>(null)
  const body = (dry_run: boolean) => ({ from_plan_id: plan.id, to_plan_id: to, when, keep_price: when === 'renewal' && keepPrice, notify, note: note.trim() || null, dry_run })
  const simulate = useAction(() => api.post<{ affected: number }>('/api/admin/migrations/plan', body(true)), {
    success: false,
    errorTitle: 'A simulação falhou',
    onSuccess: (r) => setDry(r.affected),
  })
  const run = useAction(() => api.post<{ affected: number; errors?: { user: string; error: string }[] }>('/api/admin/migrations/plan', body(false)), {
    invalidate: INVALIDATE,
    success: false,
    errorTitle: 'A migração falhou',
    onSuccess: (r) => setResult(r),
  })
  const reset = () => setDry(null)
  const target = others.find((p) => p.id === to)

  if (result)
    return (
      <Modal open onClose={onClose} title="Migração concluída" size="sm" footer={<Button onClick={onClose}>OK</Button>}>
        <div className="space-y-3">
          <Alert tone="success">
            {result.affected} {result.affected === 1 ? 'subscritor' : 'subscritores'} {when === 'now' ? 'migrados agora' : 'migram na próxima renovação'}.
          </Alert>
          {!!result.errors?.length && (
            <Alert tone="warning" title={`${result.errors.length} com erro`}>
              <ul className="list-disc pl-4">
                {result.errors.map((e) => (
                  <li key={e.user}>
                    {e.user}: {e.error}
                  </li>
                ))}
              </ul>
            </Alert>
          )}
        </div>
      </Modal>
    )

  return (
    <Modal
      open
      onClose={onClose}
      title={`Migrar subscritores de ${plan.name}`}
      description="Move todos os subscritores deste plano para outro do mesmo produto (ex.: para retirar um plano antigo)."
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancelar
          </Button>
          {dry === null ? (
            <Button loading={simulate.isPending} disabled={!to} onClick={() => simulate.mutate()}>
              Simular
            </Button>
          ) : (
            <Button variant="danger" loading={run.isPending} disabled={!dry} onClick={() => run.mutate()}>
              Migrar {dry} {dry === 1 ? 'subscritor' : 'subscritores'}
            </Button>
          )}
        </>
      }
    >
      {!others.length ? (
        <Alert tone="info">Este produto não tem outros planos. Cria primeiro o plano de destino.</Alert>
      ) : (
        <div className="space-y-5">
          <Field label="Para o plano">
            <Select
              value={to}
              onChange={(e) => {
                setTo(e.target.value ? Number(e.target.value) : '')
                reset()
              }}
            >
              {others.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} — {formatMoney(p.price_cents, p.currency)}
                  {perInterval(p.interval_unit, p.interval_count)}
                  {!p.is_active ? ' (inativo)' : ''}
                </option>
              ))}
            </Select>
          </Field>
          <fieldset>
            <legend className="mb-2 text-sm font-medium">Quando?</legend>
            <div className="space-y-2">
              {(
                [
                  ['renewal', 'Na próxima renovação', 'Sem acertos: cada cliente muda no seu dia de faturação. Pode receber um email a avisar.'],
                  ['now', 'Agora', 'Muda já, com crédito/diferença pro-rata na próxima cobrança de cada cliente.'],
                ] as const
              ).map(([v, t, d]) => (
                <label key={v} className={`flex cursor-pointer items-start gap-3 rounded-xl border p-3.5 ${when === v ? 'border-brand bg-brand-soft' : 'border-border hover:border-border-strong'}`}>
                  <input
                    type="radio"
                    name="migrate-when"
                    checked={when === v}
                    onChange={() => {
                      setWhen(v)
                      reset()
                    }}
                    className="mt-1 size-4 accent-[var(--c-brand)]"
                  />
                  <span>
                    <span className="block text-sm font-semibold">{t}</span>
                    <span className="mt-0.5 block text-xs text-muted">{d}</span>
                  </span>
                </label>
              ))}
            </div>
          </fieldset>
          {when === 'renewal' && (
            <Checkbox
              checked={keepPrice}
              onChange={(e) => {
                setKeepPrice(e.target.checked)
                reset()
              }}
              label="Manter o preço que cada cliente paga hoje"
              description={target ? `Senão passam a ${formatMoney(target.price_cents, target.currency)}${perInterval(target.interval_unit, target.interval_count)}.` : undefined}
            />
          )}
          <Checkbox checked={notify} onChange={(e) => setNotify(e.target.checked)} label="Avisar os clientes por email" />
          {notify && (
            <Field label="Mensagem no email" optional>
              <Textarea value={note} onChange={(e) => setNote(e.target.value)} rows={2} maxLength={255} />
            </Field>
          )}
          {dry !== null && (
            <div ref={dryRef}>
            <Alert tone={dry ? 'warning' : 'info'} title={dry ? (dry === 1 ? '1 subscritor vai ser migrado' : `${dry} subscritores vão ser migrados`) : 'Ninguém para migrar'}>
              {dry ? 'Confirma para aplicar. Isto não se desfaz automaticamente.' : 'Não há subscrições ativas neste plano.'}
            </Alert>
            </div>
          )}
        </div>
      )}
    </Modal>
  )
}

