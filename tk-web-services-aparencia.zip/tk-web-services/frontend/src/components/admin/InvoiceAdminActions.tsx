import { useState } from 'react'
import type { QueryKey } from '@tanstack/react-query'
import { Ban, CheckCircle2, RotateCw } from 'lucide-react'
import { api } from '../../api/client'
import { useAction } from '../../api/mutation'
import type { Invoice } from '../../api/types'
import { formatMoney } from '../../lib/format'
import { Button, Field, Input, Modal, useConfirm } from '../ui'

/** Ações de admin sobre uma cobrança: tentar de novo, marcar como paga, anular. */
export function InvoiceAdminActions({ inv, invalidate }: { inv: Invoice; invalidate: QueryKey[] }) {
  const confirm = useConfirm()
  const [markOpen, setMarkOpen] = useState(false)
  const [note, setNote] = useState('')
  const unpaid = inv.status === 'open' || inv.status === 'failed'
  const retry = useAction(() => api.post(`/api/admin/invoices/${inv.id}/retry`), { invalidate, errorTitle: 'Não foi possível cobrar' })
  const markPaid = useAction(() => api.post(`/api/admin/invoices/${inv.id}/mark-paid`, { note: note.trim() }), {
    invalidate,
    errorTitle: 'Não foi possível marcar',
    onSuccess: () => {
      setMarkOpen(false)
      setNote('')
    },
  })
  const voidInv = useAction(() => api.post(`/api/admin/invoices/${inv.id}/void`), { invalidate, errorTitle: 'Não foi possível anular' })

  if (!unpaid && inv.status !== 'processing') return null
  return (
    <>
      {unpaid && (
        <Button size="sm" variant="secondary" loading={retry.isPending} onClick={() => retry.mutate()} icon={<RotateCw className="size-4" />}>
          Cobrar de novo
        </Button>
      )}
      <Button size="sm" variant="secondary" onClick={() => setMarkOpen(true)} icon={<CheckCircle2 className="size-4" />}>
        Marcar como paga
      </Button>
      {unpaid && (
        <Button
          size="sm"
          variant="danger"
          loading={voidInv.isPending}
          icon={<Ban className="size-4" />}
          onClick={async () => {
            const ok = await confirm({
              title: `Anular a cobrança ${inv.number}?`,
              danger: true,
              confirmLabel: 'Anular',
              message: (
                <>
                  <p>
                    O cliente deixa de dever <strong className="text-fg">{formatMoney(inv.total_cents, inv.currency)}</strong> e não voltamos a tentar cobrar.
                  </p>
                  <p>Se não tiver mais nada em atraso, os serviços suspensos voltam a ficar ativos.</p>
                </>
              ),
            })
            if (ok) voidInv.mutate()
          }}
        >
          Anular
        </Button>
      )}
      <Modal
        open={markOpen}
        onClose={() => setMarkOpen(false)}
        title="Marcar como paga"
        description={`${inv.number} · ${formatMoney(inv.total_cents, inv.currency)}`}
        size="sm"
        footer={
          <>
            <Button variant="secondary" onClick={() => setMarkOpen(false)}>
              Cancelar
            </Button>
            <Button loading={markPaid.isPending} disabled={note.trim().length < 3} onClick={() => markPaid.mutate()}>
              Marcar como paga
            </Button>
          </>
        }
      >
        <form
          onSubmit={(e) => {
            e.preventDefault()
            if (note.trim().length >= 3) markPaid.mutate()
          }}
        >
          <Field label="Como foi pago?" hint="Fica registado na cobrança e na auditoria.">
            <Input value={note} onChange={(e) => setNote(e.target.value)} placeholder="ex.: MB Way a 12/10" maxLength={200} autoFocus />
          </Field>
        </form>
      </Modal>
    </>
  )
}
