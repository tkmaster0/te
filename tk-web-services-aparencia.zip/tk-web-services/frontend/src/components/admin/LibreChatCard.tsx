import { useQuery } from '@tanstack/react-query'
import { Bot } from 'lucide-react'
import { api } from '../../api/client'
import { Alert, Card, CardBody, CardHeader, CopyButton } from '../ui'

interface Snippets {
  configured: boolean
  librechat_url: string | null
  client_exists: boolean
  env: string
  yaml: string
}

function Block({ label, value }: { label: string; value: string }) {
  return (
    <div className="min-w-0">
      <div className="mb-1.5 flex items-center justify-between gap-2">
        <p className="text-xs font-medium text-muted">{label}</p>
        <CopyButton value={value} label={`Copiar ${label}`} />
      </div>
      <pre className="overflow-auto rounded-xl border border-border bg-bg p-3 font-mono text-[12px] leading-relaxed">{value}</pre>
    </div>
  )
}

/** O que pôr no LibreChat (TKGPT): login com a conta TKWS e o limite mensal. */
export function LibreChatCard() {
  const q = useQuery({ queryKey: ['admin', 'librechat'], queryFn: () => api.get<Snippets>('/api/admin/apps/librechat') })
  const d = q.data
  if (!d) return null
  return (
    <Card>
      <CardHeader icon={<Bot className="size-5" />} title="TKGPT (LibreChat)" description="Login só com a conta TKWS e a subscrição ativa; limite renovado todos os meses." />
      <CardBody className="space-y-4">
        {!d.configured && <Alert tone="info">Define o endereço do LibreChat em Definições → SSO e apps e carrega em “Criar / atualizar” os clientes SSO.</Alert>}
        <div className="grid gap-4 lg:grid-cols-2">
          <Block label=".env do LibreChat" value={d.env} />
          <Block label="librechat.yaml (limite mensal)" value={d.yaml} />
        </div>
        <Alert tone="warning" title="Créditos do LibreChat ≠ tokens">
          O saldo do LibreChat é em créditos (1 000 créditos = 0,001 $) e cada mensagem gasta tokens × preço do modelo. 2 500 000 créditos são 2,5 milhões de tokens só em
          modelos com taxa 1 (ex.: um endpoint personalizado com <code>tokenConfig</code> a 1); nos outros modelos ajusta o <code>refillAmount</code> ao preço.
        </Alert>
      </CardBody>
    </Card>
  )
}
