import { Plus, Trash2 } from 'lucide-react'
import { Button, Input } from '../ui'

export type KV = { key: string; value: string }

export function toRows(d: Record<string, string> | null | undefined): KV[] {
  const rows = Object.entries(d ?? {}).map(([key, value]) => ({ key, value }))
  return rows.length ? rows : [{ key: '', value: '' }]
}

export function fromRows(rows: KV[]): Record<string, string> {
  const out: Record<string, string> = {}
  for (const r of rows) if (r.key.trim()) out[r.key.trim()] = r.value
  return out
}

const SUGGESTIONS = ['Utilizador', 'Password', 'Endereço', 'Servidor', 'Chave', 'Código de ativação']

/** Editor chave → valor dos dados de acesso de um produto manual/webhook. */
export function AccessDetailsEditor({ rows, onChange }: { rows: KV[]; onChange: (rows: KV[]) => void }) {
  const set = (i: number, patch: Partial<KV>) => onChange(rows.map((r, k) => (k === i ? { ...r, ...patch } : r)))
  return (
    <div className="space-y-2" role="group" aria-label="Dados de acesso">
      <datalist id="access-keys">
        {SUGGESTIONS.map((s) => (
          <option key={s} value={s} />
        ))}
      </datalist>
      {rows.map((r, i) => (
        <div key={i} className="grid grid-cols-[minmax(0,2fr)_minmax(0,3fr)_auto] items-center gap-1.5">
          <Input value={r.key} onChange={(e) => set(i, { key: e.target.value })} placeholder="Campo" aria-label={`Campo ${i + 1}`} list="access-keys" className="h-10" maxLength={60} />
          <Input
            value={r.value}
            onChange={(e) => set(i, { value: e.target.value })}
            placeholder="Valor"
            aria-label={`Valor ${i + 1}`}
            className="h-10 font-mono text-[13px]"
            maxLength={500}
            autoComplete="off"
          />
          <Button variant="ghost" size="icon-sm" aria-label={`Remover campo ${i + 1}`} onClick={() => onChange(rows.length > 1 ? rows.filter((_, k) => k !== i) : [{ key: '', value: '' }])}>
            <Trash2 className="size-4" />
          </Button>
        </div>
      ))}
      <Button variant="secondary" size="sm" onClick={() => onChange([...rows, { key: '', value: '' }])} icon={<Plus className="size-4" />}>
        Adicionar campo
      </Button>
      <p className="text-xs text-muted">Campos com “password”, “chave”, “token” ou “PIN” no nome aparecem escondidos ao cliente (com botão para mostrar).</p>
    </div>
  )
}
