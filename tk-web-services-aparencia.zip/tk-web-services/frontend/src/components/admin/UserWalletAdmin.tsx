import { useConfig } from '../../api/queries'
import { useEffect, useState } from 'react'
import clsx from 'clsx'
import { KeyRound, PiggyBank, Wallet } from 'lucide-react'
import { api } from '../../api/client'
import { useAction } from '../../api/mutation'
import type { WalletSummary, WalletTx } from '../../api/types'
import { WALLET_TX } from '../../i18n/labels'
import { formatDateTime, formatMoney, formatSignedMoney } from '../../lib/format'
import { parseEuros } from '../wallet/AmountPicker'
import { Badge, Button, Card, CardHeader, Field, Input, Select, Switch } from '../ui'

export type AdminWallet = WalletSummary & { transactions: WalletTx[] }

/** Carteira do cliente no painel admin: saldo, ajustes manuais, conversão para créditos mensais e movimentos. */
export function UserWalletAdmin({ userId, wallet, invalidate }: { userId: string; wallet: AdminWallet; invalidate: unknown[][] }) {
  const [amount, setAmount] = useState('')
  const [reason, setReason] = useState('')
  const cents = parseEuros(amount.replace(/^-/, ''))
  const signed = cents === null ? null : amount.trim().startsWith('-') ? -cents : cents
  const adjust = useAction(() => api.post(`/api/admin/users/${userId}/wallet/adjust`, { amount_cents: signed, reason }), {
    invalidate,
    success: 'Carteira atualizada.',
    onSuccess: () => {
      setAmount('')
      setReason('')
    },
  })
  const convert = useAction(() => api.post<{ result: string }>(`/api/admin/users/${userId}/wallet/convert`), {
    invalidate,
    success: (res) => `Conversão: ${res.result}`,
  })
  return (
    <Card className="overflow-hidden">
      <CardHeader
        icon={<Wallet className="size-5" />}
        title={
          <span className="flex flex-wrap items-center gap-2">
            Carteira{' '}
            {wallet.monthly_enabled && (
              <Badge tone={wallet.billing_mode === 'wallet' ? 'brand' : 'neutral'}>{wallet.billing_mode === 'wallet' ? 'Só carteira' : 'Método autorizado'}</Badge>
            )}
          </span>
        }
        actions={
          wallet.monthly_enabled &&
          !wallet.monthly_topup_cents &&
          wallet.has_services && (
            <Button size="sm" variant="secondary" icon={<PiggyBank className="size-4" />} loading={convert.isPending} onClick={() => convert.mutate()}>
              Passar para créditos mensais
            </Button>
          )
        }
      />
      <div className="grid gap-4 px-5 pb-5 pt-4 sm:px-6 lg:grid-cols-[220px_1fr]">
        <div className="space-y-2">
          <p className={clsx('text-3xl font-extrabold tabular-nums', wallet.balance_cents < 0 && 'text-danger')}>{formatMoney(wallet.balance_cents)}</p>
          <p className="text-sm text-muted">
            {!wallet.monthly_enabled
              ? 'Usada antes de cada cobrança'
              : wallet.monthly_topup_cents
                ? `Carregamento mensal de ${formatMoney(wallet.monthly_topup_cents)}`
                : 'Sem carregamento mensal'}
            {wallet.pending_topup_cents > 0 && ` · ${formatMoney(wallet.pending_topup_cents)} a confirmar`}
          </p>
          <p className="text-xs text-subtle">Serviços: {formatMoney(wallet.recurring_cents)}/mês</p>
        </div>
        <form
          className="grid gap-3 sm:grid-cols-[140px_1fr_auto] sm:items-end"
          onSubmit={(e) => {
            e.preventDefault()
            if (signed && reason.trim()) adjust.mutate()
          }}
        >
          <Field label="Valor (€)" hint="Negativo para retirar">
            <Input inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="5,00" />
          </Field>
          <Field label="Motivo">
            <Input value={reason} onChange={(e) => setReason(e.target.value)} maxLength={200} placeholder="Compensação, oferta…" />
          </Field>
          <Button type="submit" loading={adjust.isPending} disabled={!signed || !reason.trim()}>
            Ajustar
          </Button>
        </form>
      </div>
      {wallet.transactions.length > 0 && (
        <ul className="max-h-80 divide-y divide-border overflow-y-auto border-t border-border">
          {wallet.transactions.map((t) => (
            <li key={t.id} className="flex items-center gap-3 px-5 py-2.5 text-sm sm:px-6">
              <div className="min-w-0 flex-1">
                <p className="truncate">{t.description}</p>
                <p className="text-xs text-subtle">
                  {WALLET_TX[t.kind] ?? t.kind} · {formatDateTime(t.created_at)}
                </p>
              </div>
              <span className={clsx('font-semibold tabular-nums', t.amount_cents > 0 && 'text-success')}>{formatSignedMoney(t.amount_cents)}</span>
              <span className="w-20 text-right text-xs text-subtle tabular-nums">{formatMoney(t.balance_after_cents)}</span>
            </li>
          ))}
        </ul>
      )}
    </Card>
  )
}

/** Modo de login no Jellyfin, modo de faturação e produtos em beta desbloqueados. */
export function UserAccessMode({
  userId,
  jellyfinPasswordLogin,
  billingMode,
  unlocked,
  gated,
  invalidate,
}: {
  userId: string
  jellyfinPasswordLogin: boolean
  billingMode: string
  unlocked: string[]
  gated: { code: string; name: string }[]
  invalidate: unknown[][]
}) {
  const monthlyEnabled = useConfig().data?.wallet?.monthly_enabled === true
  const [set, setSet] = useState(new Set(unlocked))
  useEffect(() => setSet(new Set(unlocked)), [unlocked])
  const patch = useAction((body: Record<string, unknown>) => api.patch(`/api/admin/users/${userId}`, body), { invalidate, success: 'Guardado.' })
  return (
    <div className="space-y-5 px-5 pb-5 sm:px-6">
      <Switch
        checked={jellyfinPasswordLogin}
        onChange={(v) => patch.mutate({ jellyfin_password_login: v })}
        disabled={patch.isPending}
        label={
          <span className="flex items-center gap-1.5">
            <KeyRound className="size-4" aria-hidden /> Login antigo no Jellyfin
          </span>
        }
        description="Ligado: mesma password do portal no Jellyfin (clientes migrados). Desligado: só SSO e Quick Connect."
      />
      {monthlyEnabled && (
        <Field label="Faturação">
          <Select value={billingMode} onChange={(e) => patch.mutate({ billing_mode: e.target.value })}>
            <option value="wallet">Só carteira (contas novas)</option>
            <option value="legacy">Método autorizado (cada serviço cobrado diretamente)</option>
          </Select>
        </Field>
      )}
      {gated.length > 0 && (
        <div className="space-y-2">
          <p className="text-sm font-medium">Produtos em beta desbloqueados</p>
          {gated.map((p) => (
            <label key={p.code} className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                className="size-4 accent-[var(--c-brand)]"
                checked={set.has(p.code)}
                onChange={(e) => {
                  const next = new Set(set)
                  if (e.target.checked) next.add(p.code)
                  else next.delete(p.code)
                  setSet(next)
                  patch.mutate({ unlocked_products: Array.from(next) })
                }}
              />
              {p.name}
            </label>
          ))}
        </div>
      )}
    </div>
  )
}
