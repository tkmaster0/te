import clsx from 'clsx'
import { Gift, MinusCircle, PiggyBank, RefreshCw, Scale, SplitSquareHorizontal, Undo2, Wallet } from 'lucide-react'
import { formatMoney, formatSignedMoney } from '../../lib/format'
import { LINE_KIND } from '../../i18n/labels'

const KIND_ICON = {
  renewal: RefreshCw,
  proration: SplitSquareHorizontal,
  credit: MinusCircle,
  bonus: Gift,
  adjustment: Scale,
  carry: Undo2,
  wallet: Wallet,
  mtopup: PiggyBank,
  topup: PiggyBank,
  topup_use: Wallet,
} as const

/** Linhas de uma cobrança / pré-visualização, com valores com sinal e total opcional. */
export function ChargeLines({
  lines,
  total,
  totalLabel = 'Total',
  currency = 'EUR',
  className,
}: {
  lines: { description: string; amount_cents: number; kind: string }[]
  total?: number
  totalLabel?: string
  currency?: string
  className?: string
}) {
  return (
    <div className={className}>
      {lines.length === 0 ? (
        <p className="py-2 text-sm text-muted">Sem linhas.</p>
      ) : (
        <ul className="divide-y divide-border">
          {lines.map((ln, i) => {
            const Icon = KIND_ICON[ln.kind as keyof typeof KIND_ICON] ?? RefreshCw
            const negative = ln.amount_cents < 0
            return (
              <li key={i} className="flex items-start gap-3 py-2.5 text-sm">
                <Icon className={clsx('mt-0.5 size-4 shrink-0', negative ? 'text-success' : 'text-subtle')} aria-hidden />
                <div className="min-w-0 flex-1">
                  <p className="break-words">{ln.description}</p>
                  <p className="text-xs text-subtle">{LINE_KIND[ln.kind] ?? 'Outro'}</p>
                </div>
                <span className={clsx('shrink-0 font-medium tabular-nums', negative && 'text-success')}>
                  {ln.kind === 'renewal' ? formatMoney(ln.amount_cents, currency) : formatSignedMoney(ln.amount_cents, currency)}
                </span>
              </li>
            )
          })}
        </ul>
      )}
      {total !== undefined && (
        <div className="mt-1 flex items-baseline justify-between gap-3 border-t border-border-strong pt-3">
          <span className="text-sm font-semibold">{totalLabel}</span>
          <span className="text-lg font-bold tabular-nums">{formatMoney(total, currency)}</span>
        </div>
      )}
    </div>
  )
}
