import { useId, useState } from 'react'
import clsx from 'clsx'
import { AlertTriangle, ChevronDown, Layers } from 'lucide-react'
import type { BillingSummary } from '../../api/types'
import { daysUntil, formatLongDate, formatMoney } from '../../lib/format'
import { Card, Skeleton } from '../ui'
import { ChargeLines } from './ChargeLines'
import { MethodIcon } from './PaymentModals'

function whenText(iso: string | null): string {
  const d = daysUntil(iso)
  if (d === null) return ''
  if (d <= 0) return 'hoje'
  if (d === 1) return 'amanhã'
  return `daqui a ${d} dias`
}

export function servicesInUpcoming(summary: BillingSummary): number {
  const ids = new Set<number>()
  for (const ln of summary.upcoming.lines) if (ln.product_id !== null && (ln.kind === 'renewal' || ln.kind === 'proration')) ids.add(ln.product_id)
  return ids.size
}

export function NextChargeSkeleton() {
  return (
    <div className="card space-y-4 p-6" aria-busy="true" aria-label="A carregar">
      <Skeleton className="h-4 w-32" />
      <Skeleton className="h-12 w-40" />
      <Skeleton className="h-4 w-2/3" />
    </div>
  )
}

/** Cartão principal "Próximo pagamento": quanto, quando, com que método, e o detalhe expansível. */
export function NextChargeCard({ summary, defaultOpen = false, explain, className }: { summary: BillingSummary; defaultOpen?: boolean; explain?: boolean; className?: string }) {
  const [open, setOpen] = useState(defaultOpen)
  const panelId = useId()
  const up = summary.upcoming
  const at = up.at ?? summary.next_billing_at
  const method = summary.payment_methods.find((m) => m.id === summary.default_payment_method_id)
  const n = servicesInUpcoming(summary)
  const nothing = !at || up.lines.length === 0

  return (
    <Card className={clsx('hero-glow relative overflow-hidden', className)}>
      <div className="p-5 sm:p-7">
        <p className="text-xs font-semibold uppercase tracking-wider text-brand-text">Próximo pagamento</p>
        {nothing ? (
          <>
            <p className="mt-2 text-3xl font-extrabold tracking-tight sm:text-4xl">Nada agendado</p>
            <p className="mt-1.5 text-sm text-muted">Não tens cobranças previstas. Quando adicionares um serviço, a próxima cobrança aparece aqui.</p>
          </>
        ) : (
          <>
            <p className="mt-2 text-4xl font-extrabold tracking-tight tabular-nums sm:text-5xl">{formatMoney(up.total_cents)}</p>
            <p className="mt-2 text-sm sm:text-base">
              a <strong className="font-semibold">{formatLongDate(at)}</strong> <span className="text-muted">· {whenText(at)}</span>
            </p>
            <div className="mt-4 flex flex-wrap gap-2 text-sm">
              {method ? (
                <span className="inline-flex max-w-full items-center gap-2 rounded-full border border-border bg-surface/70 px-3 py-1.5">
                  <MethodIcon kind={method.kind} className="size-4 shrink-0 text-muted" />
                  <span className="truncate">{method.label}</span>
                </span>
              ) : (
                <span className="inline-flex items-center gap-2 rounded-full border border-danger/40 bg-danger-soft px-3 py-1.5 font-medium text-danger">
                  <AlertTriangle className="size-4" aria-hidden /> Sem método de pagamento válido
                </span>
              )}
              {n > 0 && (
                <span className="inline-flex items-center gap-2 rounded-full border border-border bg-surface/70 px-3 py-1.5">
                  <Layers className="size-4 text-muted" aria-hidden />
                  Uma só cobrança para {n} {n === 1 ? 'serviço' : 'serviços'}
                </span>
              )}
            </div>
          </>
        )}
        {explain && summary.anchor_day && (
          <p className="mt-5 max-w-xl text-sm text-muted">
            Todos os teus serviços renovam no <strong className="text-fg">dia {summary.anchor_day}</strong> de cada mês e são cobrados juntos, numa só
            cobrança: pagas menos taxas e vês uma só linha no extrato. Planos anuais renovam no dia {summary.anchor_day} do mês respetivo.
          </p>
        )}
      </div>
      {!nothing && (
        <div className="border-t border-border/80 bg-surface/60">
          <button
            type="button"
            onClick={() => setOpen((o) => !o)}
            aria-expanded={open}
            aria-controls={panelId}
            className="flex w-full items-center gap-2 px-5 py-3 text-sm font-medium text-muted hover:text-fg sm:px-7"
          >
            {open ? 'Esconder detalhe' : 'Ver o que está incluído'}
            <ChevronDown className={clsx('ml-auto size-4 transition-transform', open && 'rotate-180')} aria-hidden />
          </button>
          {open && (
            <div id={panelId} className="px-5 pb-5 sm:px-7">
              <ChargeLines lines={up.lines} total={up.total_cents} totalLabel={`Total a ${formatLongDate(at)}`} />
            </div>
          )}
        </div>
      )}
    </Card>
  )
}
