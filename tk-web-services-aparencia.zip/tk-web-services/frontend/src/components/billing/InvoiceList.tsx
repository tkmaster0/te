import { useId, useState, type ReactNode } from 'react'
import clsx from 'clsx'
import { AlertCircle, CheckCircle2, ChevronDown, Clock, FileText, RotateCw, Wallet } from 'lucide-react'
import type { Invoice } from '../../api/types'
import { formatDate, formatDayMonth, formatLongDate, formatMoney } from '../../lib/format'
import { Badge, Button } from '../ui'
import { ChargeLines } from './ChargeLines'
import { INVOICE_STATUS } from '../../i18n/labels'

export const UNPAID = new Set(['open', 'failed'])

const KIND_TITLE: Record<string, string> = {
  cycle: 'Cobrança mensal',
  immediate: 'Cobrança imediata',
  manual: 'Cobrança avulsa',
}

export function invoiceStatusNote(inv: Invoice): string | null {
  if (inv.status === 'processing') return 'Débito direto demora 2–5 dias úteis a confirmar'
  if (inv.status === 'failed') return inv.next_attempt_at ? `Nova tentativa a ${formatDayMonth(inv.next_attempt_at)}` : 'Sem nova tentativa automática'
  if (inv.status === 'paid' && inv.paid_at) return `Pago a ${formatDate(inv.paid_at)}`
  if (inv.status === 'open') return 'Aguarda pagamento'
  return null
}

function StatusIcon({ status }: { status: string }) {
  const cls = 'size-5'
  if (status === 'paid') return <CheckCircle2 className={clsx(cls, 'text-success')} aria-hidden />
  if (status === 'processing') return <Clock className={clsx(cls, 'text-info')} aria-hidden />
  if (status === 'failed' || status === 'open') return <AlertCircle className={clsx(cls, status === 'failed' ? 'text-danger' : 'text-warning')} aria-hidden />
  return <FileText className={clsx(cls, 'text-subtle')} aria-hidden />
}

export function InvoiceStatusBadge({ status }: { status: string }) {
  const s = INVOICE_STATUS[status] ?? { label: 'Outro', tone: 'neutral' as const }
  return (
    <Badge tone={s.tone} dot>
      {s.label}
    </Badge>
  )
}

function InvoiceRow({ inv, onPay, extra, actions }: { inv: Invoice; onPay?: (i: Invoice) => void; extra?: ReactNode; actions?: ReactNode }) {
  const [open, setOpen] = useState(false)
  const id = useId()
  const unpaid = UNPAID.has(inv.status)
  const note = invoiceStatusNote(inv)
  return (
    <li className={clsx(unpaid && 'bg-danger-soft/40')}>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        aria-controls={id}
        className="flex w-full items-center gap-3 px-4 py-3.5 text-left hover:bg-elevated/50 sm:px-6"
      >
        <StatusIcon status={inv.status} />
        <span className="min-w-0 flex-1">
          <span className="block text-sm font-medium">
            {KIND_TITLE[inv.kind] ?? 'Cobrança'} · {formatLongDate(inv.created_at)}
          </span>
          <span className="block text-xs text-muted">
            {extra}
            {inv.number}
            {note && ` · ${note}`}
          </span>
        </span>
        <span className="hidden shrink-0 sm:block">
          <InvoiceStatusBadge status={inv.status} />
        </span>
        <span className="w-20 shrink-0 text-right text-sm font-semibold tabular-nums">{formatMoney(inv.total_cents, inv.currency)}</span>
        <ChevronDown className={clsx('size-4 shrink-0 text-subtle transition-transform', open && 'rotate-180')} aria-hidden />
      </button>
      {open && (
        <div id={id} className="space-y-3 border-t border-border/70 px-4 pb-4 pt-2 sm:px-6 sm:pl-14">
          <div className="sm:hidden">
            <InvoiceStatusBadge status={inv.status} />
          </div>
          <ChargeLines lines={inv.lines} total={inv.total_cents} currency={inv.currency} />
          <dl className="grid grid-cols-1 gap-x-6 gap-y-1 text-xs text-muted sm:grid-cols-2">
            {inv.payment_method && (
              <div>
                <dt className="inline">Método: </dt>
                <dd className="inline text-fg/90">{inv.payment_method}</dd>
              </div>
            )}
            {inv.paid_at && (
              <div>
                <dt className="inline">Pago a: </dt>
                <dd className="inline text-fg/90">{formatDate(inv.paid_at)}</dd>
              </div>
            )}
            {inv.attempt_count > 0 && inv.status !== 'paid' && (
              <div>
                <dt className="inline">Tentativas: </dt>
                <dd className="inline text-fg/90">{inv.attempt_count}</dd>
              </div>
            )}
            {inv.next_attempt_at && UNPAID.has(inv.status) && (
              <div className="inline-flex items-center gap-1">
                <RotateCw className="size-3" aria-hidden />
                <dt className="inline">Nova tentativa: </dt>
                <dd className="inline text-fg/90">{formatDate(inv.next_attempt_at)}</dd>
              </div>
            )}
          </dl>
          {inv.last_error && unpaid && <p className="rounded-lg bg-danger-soft px-3 py-2 text-xs text-danger">Motivo: {inv.last_error}</p>}
          {(actions || (unpaid && onPay)) && (
            <div className="flex flex-wrap gap-2">
              {unpaid && onPay && (
                <Button size="sm" onClick={() => onPay(inv)} icon={<Wallet className="size-4" />}>
                  Pagar agora
                </Button>
              )}
              {actions}
            </div>
          )}
        </div>
      )}
      {!open && unpaid && onPay && (
        <div className="-mt-1 px-4 pb-3.5 pl-12 sm:px-6 sm:pl-14">
          <Button size="sm" onClick={() => onPay(inv)} icon={<Wallet className="size-4" />}>
            Pagar agora
          </Button>
        </div>
      )}
    </li>
  )
}

/** Histórico de cobranças (expansível, com "Pagar agora" nas que estão por pagar). */
export function InvoiceList({
  invoices,
  onPay,
  renderExtra,
  renderActions,
}: {
  invoices: Invoice[]
  onPay?: (i: Invoice) => void
  renderExtra?: (i: Invoice) => ReactNode
  renderActions?: (i: Invoice) => ReactNode
}) {
  return (
    <ul className="divide-y divide-border">
      {invoices.map((inv) => (
        <InvoiceRow key={inv.id} inv={inv} onPay={onPay} extra={renderExtra?.(inv)} actions={renderActions?.(inv)} />
      ))}
    </ul>
  )
}

export function NotAnInvoiceNote() {
  return (
    <p className="flex items-start gap-2 text-xs text-muted">
      <FileText className="mt-px size-3.5 shrink-0" aria-hidden />
      Documentos de cobrança — não são faturas certificadas.
    </p>
  )
}
