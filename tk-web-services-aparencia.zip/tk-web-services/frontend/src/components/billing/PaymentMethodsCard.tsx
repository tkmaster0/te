import clsx from 'clsx'
import { AlertTriangle, CreditCard, Plus, Star, Trash2 } from 'lucide-react'
import { api } from '../../api/client'
import { BILLING_INVALIDATE } from '../../api/keys'
import { useAction } from '../../api/mutation'
import type { PaymentMethod } from '../../api/types'
import { formatDate } from '../../lib/format'
import { Badge, Button, Card, CardHeader, EmptyState, Menu, useConfirm } from '../ui'
import { MethodIcon } from './PaymentModals'

function MethodRow({ m, onlyUsable }: { m: PaymentMethod; onlyUsable: boolean }) {
  const confirm = useConfirm()
  const setDefault = useAction(() => api.post(`/api/billing/payment-methods/${m.id}/default`), { invalidate: BILLING_INVALIDATE, errorTitle: 'Não foi possível alterar' })
  const remove = useAction(() => api.del(`/api/billing/payment-methods/${m.id}`), { invalidate: BILLING_INVALIDATE, errorTitle: 'Não foi possível remover' })
  const bad = m.status === 'unusable'
  const onRemove = async () => {
    const ok = await confirm({
      title: 'Remover este método?',
      danger: true,
      confirmLabel: 'Remover',
      message: (
        <>
          <p>
            <strong className="text-fg">{m.label}</strong> deixa de ser usado nas tuas cobranças.
          </p>
          {onlyUsable && <p className="text-warning">É o teu único método válido: sem ele, a próxima cobrança não pode ser feita e os serviços podem ser suspensos.</p>}
        </>
      ),
    })
    if (ok) remove.mutate()
  }
  return (
    <li className={clsx('flex items-start gap-3 px-5 py-4 sm:px-6', bad && 'bg-danger-soft/50')}>
      <span className={clsx('grid size-10 shrink-0 place-items-center rounded-xl', bad ? 'bg-danger-soft text-danger' : 'bg-elevated')}>
        <MethodIcon kind={m.kind} />
      </span>
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-2">
          <p className="min-w-0 break-words font-semibold">{m.label}</p>
          {m.is_default && !bad && <Badge tone="brand">Predefinido</Badge>}
          {m.status === 'pending' && <Badge tone="info">A confirmar</Badge>}
          {bad && <Badge tone="danger">Não pode ser usado</Badge>}
        </div>
        <p className="mt-0.5 text-xs text-muted">
          {m.provider_label}
          {m.expires_at && m.kind === 'card' && ` · expira a ${formatDate(m.expires_at)}`}
          {` · adicionado a ${formatDate(m.created_at)}`}
        </p>
        {bad && (
          <p className="mt-1.5 flex items-start gap-1.5 text-sm font-medium text-danger">
            <AlertTriangle className="mt-0.5 size-4 shrink-0" aria-hidden />
            {m.status_reason ?? 'Este método deixou de funcionar. Adiciona um novo.'}
          </p>
        )}
      </div>
      <Menu
        label={`Ações para ${m.label}`}
        items={[
          !m.is_default && !bad && { label: 'Tornar predefinido', icon: <Star />, onSelect: () => setDefault.mutate(), hint: 'Passa a ser usado nas próximas cobranças.' },
          { label: 'Remover', icon: <Trash2 />, danger: true, onSelect: onRemove },
        ]}
      />
    </li>
  )
}

export function PaymentMethodsCard({ methods, onAdd, id }: { methods: PaymentMethod[]; onAdd: () => void; id?: string }) {
  const usable = methods.filter((m) => m.status === 'active' || m.status === 'pending')
  return (
    <Card id={id} className="scroll-mt-24 overflow-hidden">
      <CardHeader
        icon={<CreditCard className="size-5" />}
        title="Métodos de pagamento"
        description="O predefinido paga todas as cobranças; se falhar, tentamos os outros."
      />
      <div className="pt-4">
        {methods.length === 0 ? (
          <EmptyState
            compact
            icon={<CreditCard className="size-6" />}
            title="Ainda não tens métodos de pagamento"
            description="Adiciona um quando subscreveres o primeiro serviço — ou já agora."
            action={
              <Button onClick={onAdd} icon={<Plus className="size-4" />}>
                Adicionar método
              </Button>
            }
          />
        ) : (
          <>
            <ul className="divide-y divide-border border-y border-border">
              {methods.map((m) => (
                <MethodRow key={m.id} m={m} onlyUsable={usable.length === 1 && usable[0].id === m.id} />
              ))}
            </ul>
            <div className="px-5 py-3.5 sm:px-6">
              <Button
                size="sm"
                variant={usable.length ? 'secondary' : 'primary'}
                onClick={onAdd}
                icon={<Plus className="size-4" />}
                className="w-full"
              >
                {usable.length ? 'Adicionar outro método' : 'Adicionar método de pagamento'}
              </Button>
            </div>
          </>
        )}
      </div>
    </Card>
  )
}
