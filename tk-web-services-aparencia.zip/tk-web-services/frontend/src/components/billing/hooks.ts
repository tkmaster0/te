import { useAuth } from '../../auth/AuthProvider'

/** Sessão aberta a partir do Jellyfin: só pode gerir o streaming. */
export function useIsScoped(): boolean {
  const { me } = useAuth()
  return me?.session_scope === 'streaming'
}

/** Navegação completa para a página alojada do fornecedor de pagamento. */
export function goToProvider(url: string) {
  window.location.assign(url)
}

export const LIVE_STATUSES = new Set(['active', 'past_due', 'canceling', 'bonus', 'suspended', 'pending'])
