import { CalendarClock, CreditCard, LogIn, Wallet } from 'lucide-react'
import type { BillingAction } from '../../api/types'
import { daysUntil, formatDayMonth } from '../../lib/format'
import { Alert, Button, ButtonLink } from '../ui'

function deadlineText(deadline: string | null): string | null {
  if (!deadline) return null
  const d = daysUntil(deadline)
  const date = formatDayMonth(deadline)
  if (d === null) return null
  if (d < 0) return `Prazo: ${date} (já passou)`
  if (d === 0) return `Prazo: hoje (${date})`
  if (d === 1) return `Prazo: amanhã (${date})`
  return `Prazo: ${date} · faltam ${d} dias`
}

/**
 * Avisos prioritários da faturação (método inválido, cobrança por pagar, risco de suspensão),
 * cada um com UMA ação clara.
 */
export function ActionBanners({
  actions,
  scoped,
  onAddMethod,
  onPayInvoice,
  firstUnpaidId,
  className,
}: {
  actions: BillingAction[]
  scoped?: boolean
  onAddMethod?: () => void
  onPayInvoice?: (invoiceId: string) => void
  firstUnpaidId?: string | null
  className?: string
}) {
  if (!actions.length) return null
  // Evita dois botões iguais: o aviso de "risco de suspensão" só leva ação se não houver já um "Pagar agora".
  const hasInvoiceAction = actions.some((a) => a.type === 'invoice')
  return (
    <section aria-label="Ações necessárias" className={className}>
      <div className="space-y-2.5">
        {actions.map((a, i) => {
          const tone = a.severity === 'high' ? 'danger' : a.severity === 'medium' ? 'warning' : 'info'
          const dl = deadlineText(a.deadline)
          let action: React.ReactNode = null
          if (scoped && (a.type === 'payment_method' || a.type === 'invoice' || a.type === 'grace')) {
            action = (
              <ButtonLink to="/login?next=/app/faturacao" size="sm" variant="secondary" icon={<LogIn className="size-4" />}>
                Entrar com password
              </ButtonLink>
            )
          } else if (a.type === 'payment_method' && onAddMethod) {
            action = (
              <Button size="sm" onClick={onAddMethod} icon={<CreditCard className="size-4" />}>
                Adicionar método
              </Button>
            )
          } else if (a.type === 'invoice' && a.invoice_id && onPayInvoice) {
            action = (
              <Button size="sm" onClick={() => onPayInvoice(a.invoice_id!)} icon={<Wallet className="size-4" />}>
                Pagar agora
              </Button>
            )
          } else if (a.type === 'grace' && !hasInvoiceAction && firstUnpaidId && onPayInvoice) {
            action = (
              <Button size="sm" onClick={() => onPayInvoice(firstUnpaidId)} icon={<Wallet className="size-4" />}>
                Regularizar
              </Button>
            )
          }
          return (
            <Alert key={`${a.type}-${a.invoice_id ?? a.subscription_id ?? i}`} tone={tone} title={a.title} action={action}>
              <p>{a.message}</p>
              {dl && (
                <p className="mt-1.5 inline-flex items-center gap-1.5 text-xs font-semibold">
                  <CalendarClock className="size-3.5" aria-hidden /> {dl}
                </p>
              )}
              {scoped && a.type === 'payment_method' && (
                <p className="mt-1.5 text-xs">Para atualizar o método de pagamento entra com a tua password.</p>
              )}
            </Alert>
          )
        })}
      </div>
    </section>
  )
}
