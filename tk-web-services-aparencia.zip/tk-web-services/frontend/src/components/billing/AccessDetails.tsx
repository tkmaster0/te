import { Hourglass, Info } from 'lucide-react'
import { CopyField } from '../ui'

const SECRET_KEY = /pass|senha|palavra|secret|segredo|token|chave|key|pin|código|codigo/i

export function isSecretKey(key: string): boolean {
  return SECRET_KEY.test(key)
}

/** Dados de acesso de um produto manual/webhook (chave → valor), com cópia e valores sensíveis escondidos. */
export function AccessDetails({
  details,
  instructions,
  fulfillmentStatus,
}: {
  details: Record<string, string>
  instructions: string | null
  fulfillmentStatus: string | null
}) {
  const entries = Object.entries(details ?? {})
  if (fulfillmentStatus === 'pending' && !entries.length)
    return (
      <div className="flex items-start gap-3 rounded-xl border border-info/30 bg-info-soft p-4 text-sm">
        <Hourglass className="mt-0.5 size-5 shrink-0 text-info" aria-hidden />
        <div>
          <p className="font-semibold">Estamos a preparar o teu acesso</p>
          <p className="mt-0.5 text-fg/80">Assim que estiver pronto, os dados aparecem aqui e recebes um email. Normalmente demora menos de um dia.</p>
        </div>
      </div>
    )
  if (!entries.length && !instructions) return null
  return (
    <div className="space-y-4">
      {instructions && (
        <p className="flex items-start gap-2.5 whitespace-pre-line rounded-xl bg-elevated p-3.5 text-sm text-fg/90">
          <Info className="mt-0.5 size-4 shrink-0 text-brand-text" aria-hidden />
          <span className="min-w-0 break-words">{instructions}</span>
        </p>
      )}
      {entries.length > 0 && (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          {entries.map(([k, v]) => (
            <CopyField key={k} label={k} value={v} secret={isSecretKey(k)} />
          ))}
        </div>
      )}
      {fulfillmentStatus === 'error' && (
        <p className="text-xs text-warning">Houve um problema a atualizar o teu acesso. Já fomos avisados e vamos resolver.</p>
      )}
    </div>
  )
}
