import clsx from 'clsx'
import {
  BookOpen,
  Bot,
  Cloud,
  Film,
  Gamepad2,
  Globe,
  HardDrive,
  Headphones,
  KeyRound,
  Mail,
  MonitorPlay,
  Music,
  Package,
  Radio,
  Server,
  Sparkles,
  Shield,
  Tv,
  Wifi,
  type LucideIcon,
} from 'lucide-react'

/** O backend envia um nome de ícone lucide como sugestão (`product.icon`); mapeamos os mais comuns. */
const ICONS: Record<string, LucideIcon> = {
  bot: Bot,
  ia: Bot,
  ai: Sparkles,
  sparkles: Sparkles,
  cdn: Globe,
  tv: Tv,
  television: Tv,
  streaming: MonitorPlay,
  film: Film,
  clapperboard: Film,
  movie: Film,
  cloud: Cloud,
  storage: HardDrive,
  'hard-drive': HardDrive,
  harddrive: HardDrive,
  shield: Shield,
  vpn: Shield,
  lock: KeyRound,
  key: KeyRound,
  radio: Radio,
  iptv: Radio,
  music: Music,
  headphones: Headphones,
  gamepad: Gamepad2,
  'gamepad-2': Gamepad2,
  games: Gamepad2,
  server: Server,
  globe: Globe,
  web: Globe,
  wifi: Wifi,
  mail: Mail,
  book: BookOpen,
  'book-open': BookOpen,
}

export function productIcon(name: string | null | undefined, fulfillment?: string): LucideIcon {
  const key = (name ?? '').trim().toLowerCase()
  if (key && ICONS[key]) return ICONS[key]
  if (fulfillment === 'streaming') return Tv
  return Package
}

export function ProductIcon({
  icon,
  fulfillment,
  image,
  size = 'md',
  className,
}: {
  icon: string | null | undefined
  fulfillment?: string
  /** Imagem do produto (Admin → Produtos); se existir, substitui o ícone. */
  image?: string | null
  size?: 'sm' | 'md' | 'lg'
  className?: string
}) {
  const Icon = productIcon(icon, fulfillment)
  const box = size === 'lg' ? 'size-14 rounded-2xl' : size === 'sm' ? 'size-9 rounded-lg' : 'size-11 rounded-xl'
  const ic = size === 'lg' ? 'size-7' : size === 'sm' ? 'size-4' : 'size-5'
  if (image)
    return (
      <span className={clsx('grid shrink-0 place-items-center overflow-hidden bg-elevated', box, className)} aria-hidden>
        <img src={image} alt="" className="size-full object-cover" loading="lazy" />
      </span>
    )
  return (
    <span className={clsx('grid shrink-0 place-items-center bg-brand-soft text-brand-text', box, className)} aria-hidden>
      <Icon className={ic} />
    </span>
  )
}
