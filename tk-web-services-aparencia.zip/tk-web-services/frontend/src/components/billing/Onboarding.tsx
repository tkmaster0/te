import { ArrowRight, Check, Gift, Layers, MousePointerClick, ShieldCheck } from 'lucide-react'
import type { BonusStatus } from '../../api/types'
import { ButtonLink, Card, ProgressBar } from '../ui'

const STEPS = [
  { icon: MousePointerClick, title: 'Escolhe o serviço', text: 'Streaming, cloud, VPN… adiciona o que quiseres, quando quiseres.' },
  { icon: ShieldCheck, title: 'Autoriza o pagamento uma vez', text: 'Débito direto SEPA ou cartão, na página segura do fornecedor.' },
  { icon: Layers, title: 'Paga tudo numa só cobrança', text: 'Todos os serviços renovam no mesmo dia do mês. Uma linha no extrato.' },
]

/** "Como funciona" em 3 passos (para quem ainda não tem serviços). */
export function HowItWorks({ cta = true, compact }: { cta?: boolean; compact?: boolean }) {
  return (
    <Card className={compact ? 'p-5' : 'hero-glow p-6 sm:p-8'}>
      {!compact && (
        <>
          <p className="text-xs font-semibold uppercase tracking-wider text-brand-text">Como funciona</p>
          <h2 className="mt-1 text-xl font-bold sm:text-2xl">Três passos e está feito</h2>
        </>
      )}
      <ol className={`grid gap-4 sm:grid-cols-3 ${compact ? '' : 'mt-6'}`}>
        {STEPS.map((s, i) => (
          <li key={s.title} className="flex gap-3 sm:flex-col">
            <span className="relative grid size-11 shrink-0 place-items-center rounded-xl bg-brand-soft text-brand-text">
              <s.icon className="size-5" aria-hidden />
              <span className="absolute -right-1.5 -top-1.5 grid size-5 place-items-center rounded-full bg-brand text-[11px] font-bold text-brand-fg">{i + 1}</span>
            </span>
            <span>
              <span className="block font-semibold">{s.title}</span>
              <span className="mt-0.5 block text-sm text-muted">{s.text}</span>
            </span>
          </li>
        ))}
      </ol>
      {cta && (
        <ButtonLink to="/app/planos" size="lg" className="mt-7 w-full sm:w-auto" icon={<ArrowRight className="size-5" />}>
          Ver serviços na loja
        </ButtonLink>
      )}
    </Card>
  )
}

/** Progresso do bónus: "X de N convidados a pagar". */
export function BonusProgress({ bonus, compact, showLink = true }: { bonus: BonusStatus; compact?: boolean; showLink?: boolean }) {
  if (!bonus.enabled) return null
  const n = bonus.threshold
  const x = Math.min(bonus.active_invitees, n)
  const missing = Math.max(0, n - bonus.active_invitees)
  return (
    <Card className={bonus.eligible ? 'border-brand/50' : undefined}>
      <div className={compact ? 'p-5' : 'p-5 sm:p-6'}>
        <div className="flex items-start gap-3">
          <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-brand text-brand-fg">
            <Gift className="size-5" aria-hidden />
          </span>
          <div className="min-w-0">
            <h2 className="font-semibold leading-tight">{bonus.eligible ? 'O teu streaming está pago pelo bónus' : 'Convida amigos, deixa de pagar'}</h2>
            <p className="mt-1 text-sm text-muted">
              {bonus.eligible
                ? 'Enquanto mantiveres os convidados a pagar, o streaming não é cobrado.'
                : `Com ${n} convidados a pagar, o teu streaming deixa de ser cobrado.`}
            </p>
          </div>
        </div>
        <div className="mt-4">
          <div className="mb-1.5 flex items-baseline justify-between gap-3 text-sm">
            <span className="font-medium">
              <span className="tabular-nums">
                {x} de {n}
              </span>{' '}
              convidados a pagar
            </span>
            <span className="text-xs text-muted">{bonus.eligible ? <Check className="inline size-4 text-success" aria-label="Objetivo atingido" /> : missing === 1 ? 'falta 1' : `faltam ${missing}`}</span>
          </div>
          <ProgressBar value={x} max={n} label="Convidados a pagar" />
        </div>
        {showLink && (
          <ButtonLink to="/app/convites" variant="secondary" size="sm" className="mt-4">
            {bonus.eligible ? 'Ver convidados' : 'Convidar amigos'}
          </ButtonLink>
        )}
      </div>
    </Card>
  )
}
