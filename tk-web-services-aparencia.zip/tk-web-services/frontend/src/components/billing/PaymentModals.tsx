import { useEffect, useState } from 'react'
import { useQueryClient } from '@tanstack/react-query'
import clsx from 'clsx'
import { ChevronDown, CreditCard, Landmark, Plus } from 'lucide-react'
import { api, errorMessage } from '../../api/client'
import { BILLING_INVALIDATE } from '../../api/keys'
import { useAction } from '../../api/mutation'
import { useBillingSummary } from '../../api/queries'
import type { Invoice, PayInvoiceOut, PaymentMethod, Provider, RedirectOut } from '../../api/types'
import { formatDate, formatMoney } from '../../lib/format'
import { Alert, Button, Modal, useToast } from '../ui'
import { ChargeLines } from './ChargeLines'
import { firstAvailable, ProviderChoice, SecureRedirectNote } from './ProviderChoice'
import { goToProvider } from './hooks'

export function MethodIcon({ kind, className }: { kind: string; className?: string }) {
  return kind === 'card' ? <CreditCard className={className ?? 'size-5'} aria-hidden /> : <Landmark className={className ?? 'size-5'} aria-hidden />
}

/** Adicionar um método de pagamento: escolher fornecedor → página alojada → volta a /app/pagamento/retorno. */
export function AddMethodModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const summary = useBillingSummary()
  const providers = summary.data?.providers ?? []
  const [provider, setProvider] = useState<Provider | null>(null)
  const chosen = provider && providers.some((p) => p.name === provider && p.available) ? provider : firstAvailable(providers)
  const add = useAction((p: Provider) => api.post<RedirectOut>('/api/billing/payment-methods', { provider: p }), {
    success: false,
    errorTitle: false,
    onSuccess: (res) => goToProvider(res.redirect_url),
  })
  const redirecting = add.isSuccess
  return (
    <Modal
      open={open}
      onClose={add.isPending || redirecting ? () => undefined : onClose}
      title="Adicionar método de pagamento"
      description="Fica como predefinido e passa a ser usado em todas as cobranças."
      footer={
        <>
          <Button variant="secondary" onClick={onClose} disabled={add.isPending || redirecting}>
            Cancelar
          </Button>
          <Button onClick={() => chosen && add.mutate(chosen)} loading={add.isPending || redirecting} disabled={!chosen}>
            {redirecting ? 'A redirecionar…' : 'Continuar'}
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        <ProviderChoice providers={providers} value={chosen} onChange={setProvider} name="add-provider" />
        <SecureRedirectNote />
        {add.isError && <Alert tone="danger">{errorMessage(add.error)}</Alert>}
      </div>
    </Modal>
  )
}

/** Pagar já uma cobrança em atraso: com um método guardado (cobra logo) ou num fornecedor (redireciona). */
export function PayInvoiceModal({ invoice, open, onClose }: { invoice: Invoice | null; open: boolean; onClose: () => void }) {
  const qc = useQueryClient()
  const toast = useToast()
  const summary = useBillingSummary()
  const usable = (summary.data?.payment_methods ?? []).filter((m) => m.status === 'active')
  const providers = summary.data?.providers ?? []
  const [choice, setChoice] = useState<string>('')

  useEffect(() => {
    if (!open) return
    const def = usable.find((m) => m.id === summary.data?.default_payment_method_id) ?? usable[0]
    setChoice(def ? `pm:${def.id}` : `prov:${firstAvailable(providers) ?? ''}`)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, summary.data?.default_payment_method_id])

  const pay = useAction((body: { payment_method_id?: string; provider?: Provider }) => api.post<PayInvoiceOut>(`/api/billing/invoices/${invoice!.id}/pay`, body), {
    success: false,
    errorTitle: false,
    onSuccess: async (res) => {
      if (res.redirect_url) {
        goToProvider(res.redirect_url)
        return
      }
      await Promise.all(BILLING_INVALIDATE.map((k) => qc.invalidateQueries({ queryKey: k })))
      const msg = res.message ?? 'Pagamento submetido.'
      if (res.status === 'failed') toast.error('O pagamento falhou', msg)
      else toast.success(msg)
      onClose()
    },
  })

  if (!invoice) return null
  const redirecting = pay.isSuccess && !!pay.data?.redirect_url
  const isPm = choice.startsWith('pm:')
  const provider = !isPm ? (choice.slice(5) as Provider) : null
  const method: PaymentMethod | undefined = isPm ? usable.find((m) => `pm:${m.id}` === choice) : undefined

  const submit = () => {
    if (method) pay.mutate({ payment_method_id: method.id })
    else if (provider) pay.mutate({ provider })
  }

  return (
    <Modal
      open={open}
      onClose={pay.isPending || redirecting ? () => undefined : onClose}
      title={`Pagar ${formatMoney(invoice.total_cents, invoice.currency)}`}
      description={`Cobrança ${invoice.number} de ${formatDate(invoice.created_at)}`}
      footer={
        <>
          <Button variant="secondary" onClick={onClose} disabled={pay.isPending || redirecting}>
            Agora não
          </Button>
          <Button onClick={submit} loading={pay.isPending || redirecting} disabled={!method && !provider}>
            {redirecting ? 'A redirecionar…' : method ? `Pagar ${formatMoney(invoice.total_cents, invoice.currency)}` : 'Continuar para o pagamento'}
          </Button>
        </>
      }
    >
      <div className="space-y-5">
        {invoice.last_error && (
          <Alert tone="warning" title="Porque falhou">
            {invoice.last_error}
          </Alert>
        )}
        <details className="group rounded-xl border border-border px-4 py-2">
          <summary className="flex cursor-pointer items-center justify-between gap-3 py-1 text-sm font-medium">
            <span>
              O que estás a pagar <span className="text-muted">· {invoice.lines.length} {invoice.lines.length === 1 ? 'linha' : 'linhas'}</span>
            </span>
            <ChevronDown className="size-4 shrink-0 text-muted transition-transform group-open:rotate-180" aria-hidden />
          </summary>
          <ChargeLines lines={invoice.lines} total={invoice.total_cents} currency={invoice.currency} className="pb-2" />
        </details>

        {usable.length > 0 && (
          <fieldset>
            <legend className="mb-2 text-sm font-medium">Com um método guardado</legend>
            <div className="space-y-2">
              {usable.map((m) => {
                const active = choice === `pm:${m.id}`
                return (
                  <label
                    key={m.id}
                    className={clsx(
                      'flex cursor-pointer items-center gap-3 rounded-xl border p-3.5 transition-colors',
                      active ? 'border-brand bg-brand-soft' : 'border-border hover:border-border-strong',
                    )}
                  >
                    <input type="radio" name="pay-with" checked={active} onChange={() => setChoice(`pm:${m.id}`)} className="size-4 accent-[var(--c-brand)]" />
                    <MethodIcon kind={m.kind} />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm font-semibold">{m.label}</span>
                      <span className="block text-xs text-muted">
                        {m.kind === 'sepa' ? 'Débito direto — confirma em 2 a 5 dias úteis' : 'Confirmado na hora'}
                      </span>
                    </span>
                  </label>
                )
              })}
            </div>
          </fieldset>
        )}

        <fieldset>
          <legend className="mb-2 flex items-center gap-1.5 text-sm font-medium">
            {usable.length ? (
              <>
                <Plus className="size-4" aria-hidden /> Ou com um método novo
              </>
            ) : (
              'Escolhe como pagar'
            )}
          </legend>
          <ProviderChoice
            providers={providers}
            value={provider}
            onChange={(p) => setChoice(`prov:${p}`)}
            name="pay-provider"
          />
        </fieldset>
        {!method && provider && <SecureRedirectNote />}
        {pay.isError && <Alert tone="danger">{errorMessage(pay.error)}</Alert>}
      </div>
    </Modal>
  )
}
