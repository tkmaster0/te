import clsx from 'clsx'
import { CreditCard, Landmark, Lock } from 'lucide-react'
import type { Provider, ProviderOption } from '../../api/types'
import { Badge } from '../ui'

export const PROVIDER_INFO: Record<string, { title: string; desc: string; icon: typeof Landmark; recommended?: boolean }> = {
  gocardless: {
    title: 'Débito direto SEPA',
    desc: 'Autorizas uma vez com o teu IBAN. Sem comissões de cartão — é o que nos fica mais barato.',
    icon: Landmark,
    recommended: true,
  },
  stripe: {
    title: 'Cartão / Apple Pay / Google Pay',
    desc: 'Cartão de débito ou crédito. A cobrança é confirmada na hora.',
    icon: CreditCard,
  },
}

/** Escolha do fornecedor para criar um método de pagamento novo (redireciona para a página segura dele). */
export function ProviderChoice({
  providers,
  value,
  onChange,
  name = 'provider',
}: {
  providers: ProviderOption[]
  value: Provider | null
  onChange: (p: Provider) => void
  name?: string
}) {
  if (!providers.length)
    return <p className="rounded-xl bg-elevated p-4 text-sm text-muted">De momento não há métodos de pagamento disponíveis. Tenta mais tarde.</p>
  return (
    <fieldset>
      <legend className="sr-only">Método de pagamento</legend>
      <div className="space-y-2.5">
        {providers.map((p) => {
          const info = PROVIDER_INFO[p.name] ?? { title: p.label, desc: p.provider_label, icon: CreditCard }
          const Icon = info.icon
          const active = value === p.name
          return (
            <label
              key={p.name}
              className={clsx(
                'flex items-start gap-3.5 rounded-xl border p-4 transition-colors',
                !p.available ? 'cursor-not-allowed opacity-55' : 'cursor-pointer',
                active ? 'border-brand bg-brand-soft' : 'border-border hover:border-border-strong',
              )}
            >
              <input
                type="radio"
                name={name}
                value={p.name}
                checked={active}
                disabled={!p.available}
                onChange={() => onChange(p.name)}
                className="mt-1 size-4 shrink-0 accent-[var(--c-brand)]"
              />
              <span className="grid size-10 shrink-0 place-items-center rounded-lg bg-elevated text-fg">
                <Icon className="size-5" aria-hidden />
              </span>
              <span className="min-w-0 flex-1">
                <span className="flex flex-wrap items-center gap-2 font-semibold">
                  {info.title}
                  {info.recommended && p.available && <Badge tone="brand">Recomendado</Badge>}
                </span>
                <span className="mt-0.5 block text-sm text-muted">
                  {p.available ? info.desc : 'Temporariamente indisponível para novos métodos.'}
                </span>
              </span>
            </label>
          )
        })}
      </div>
    </fieldset>
  )
}

export function SecureRedirectNote() {
  return (
    <p className="flex items-start gap-2 text-xs text-muted">
      <Lock className="mt-px size-3.5 shrink-0" aria-hidden />
      Vais para a página segura do fornecedor de pagamento e voltas aqui no fim. Não guardamos o teu IBAN nem os dados do cartão.
    </p>
  )
}

/** Primeiro fornecedor disponível (preferência do backend: SEPA primeiro). */
export function firstAvailable(providers: ProviderOption[] | undefined): Provider | null {
  return providers?.find((p) => p.available)?.name ?? null
}
