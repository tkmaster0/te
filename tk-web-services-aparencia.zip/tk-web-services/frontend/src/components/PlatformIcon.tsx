import { Apple, Globe, Monitor, MonitorSmartphone, Smartphone, Tv, Download } from 'lucide-react'

export function PlatformIcon({ platform, className = 'size-5' }: { platform: string; className?: string }) {
  const p = platform.toLowerCase()
  if (p === 'ios' || p === 'macos') return <Apple className={className} aria-hidden />
  if (p === 'tvos' || p === 'androidtv' || p === 'tv' || p === 'firetv' || p === 'roku') return <Tv className={className} aria-hidden />
  if (p === 'android') return <Smartphone className={className} aria-hidden />
  if (p === 'desktop' || p === 'windows' || p === 'linux') return <Monitor className={className} aria-hidden />
  if (p === 'web') return <Globe className={className} aria-hidden />
  if (p === 'multi') return <MonitorSmartphone className={className} aria-hidden />
  return <Download className={className} aria-hidden />
}
