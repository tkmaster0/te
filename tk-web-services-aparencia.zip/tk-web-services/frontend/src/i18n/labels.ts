/** Etiquetas pt-PT para estados e códigos vindos da API. */

export type Tone = 'success' | 'warning' | 'danger' | 'info' | 'neutral' | 'brand'

export const SUB_STATUS: Record<string, { label: string; tone: Tone }> = {
  active: { label: 'Ativa', tone: 'success' },
  past_due: { label: 'Pagamento em atraso', tone: 'warning' },
  canceling: { label: 'Cancelada', tone: 'warning' },
  bonus: { label: 'Grátis pelo bónus', tone: 'brand' },
  suspended: { label: 'Suspensa', tone: 'danger' },
  ended: { label: 'Terminada', tone: 'neutral' },
  pending: { label: 'Pendente', tone: 'info' },
}

export const PAYMENT_STATUS: Record<string, { label: string; tone: Tone }> = {
  paid: { label: 'Pago', tone: 'success' },
  confirmed: { label: 'Pago', tone: 'success' },
  paid_out: { label: 'Pago', tone: 'success' },
  pending: { label: 'Pendente', tone: 'info' },
  pending_submission: { label: 'Pendente', tone: 'info' },
  submitted: { label: 'Em processamento', tone: 'info' },
  failed: { label: 'Falhado', tone: 'danger' },
  refunded: { label: 'Reembolsado', tone: 'neutral' },
  charged_back: { label: 'Estornado', tone: 'danger' },
  cancelled: { label: 'Cancelado', tone: 'neutral' },
}

/** Estado das cobranças consolidadas (documentos de cobrança). */
export const INVOICE_STATUS: Record<string, { label: string; tone: Tone }> = {
  paid: { label: 'Pago', tone: 'success' },
  processing: { label: 'A processar', tone: 'info' },
  open: { label: 'Por pagar', tone: 'warning' },
  failed: { label: 'Falhou', tone: 'danger' },
  void: { label: 'Anulada', tone: 'neutral' },
}

/** Tipos de linha de uma cobrança. */
export const LINE_KIND: Record<string, string> = {
  renewal: 'Renovação',
  proration: 'Pro-rata',
  credit: 'Crédito',
  bonus: 'Bónus',
  adjustment: 'Acerto',
  carry: 'Transitado',
  wallet: 'Carteira',
  mtopup: 'Carregamento mensal',
  topup: 'Carregamento',
  topup_use: 'Usado nesta cobrança',
}

/** Movimentos da carteira. */
export const WALLET_TX: Record<string, string> = {
  topup: 'Carregamento',
  monthly_topup: 'Carregamento mensal',
  invoice: 'Pagamento de serviços',
  refund: 'Devolução',
  reversal: 'Estorno',
  game_bet: 'Aposta',
  game_win: 'Prémio',
  bonus: 'Bónus',
  adjustment: 'Acerto',
  debt: 'Saldo negativo acertado',
}

export const PM_STATUS: Record<string, { label: string; tone: Tone }> = {
  active: { label: 'Ativo', tone: 'success' },
  pending: { label: 'A confirmar', tone: 'info' },
  unusable: { label: 'Inutilizável', tone: 'danger' },
  revoked: { label: 'Removido', tone: 'neutral' },
}

export const FULFILLMENT_STATUS: Record<string, { label: string; tone: Tone }> = {
  pending: { label: 'Por entregar', tone: 'warning' },
  done: { label: 'Entregue', tone: 'success' },
  error: { label: 'Erro', tone: 'danger' },
  pending_removal: { label: 'Por remover', tone: 'info' },
}

export const FULFILLMENT_TYPE: Record<string, { label: string; description: string }> = {
  streaming: { label: 'Streaming (automático)', description: 'Jellyfin, pedidos e IPTV são criados e atualizados automaticamente.' },
  manual: { label: 'Manual', description: 'Tu preenches os dados de acesso (ex.: utilizador e password) em Entregas; o cliente vê-os no portal.' },
  webhook: { label: 'Webhook', description: 'O portal avisa um serviço externo (POST assinado) sempre que a subscrição muda. Os dados de acesso podem ser devolvidos ou preenchidos à mão.' },
  none: { label: 'Só faturação', description: 'Nada a entregar — apenas cobra (ex.: donativo, serviço presencial).' },
}

export const PROVIDER_LABEL: Record<string, string> = {
  portal: 'Cobrança do portal',
  gocardless: 'Débito direto SEPA',
  stripe: 'Cartão (Stripe)',
  manual: 'Manual',
  legacy: 'Site antigo',
  grant: 'Oferta',
}

export const PROVIDER_SHORT: Record<string, string> = {
  gocardless: 'GoCardless',
  stripe: 'Stripe',
  manual: 'Manual',
}

export const JOB_STATUS: Record<string, { label: string; tone: Tone }> = {
  pending: { label: 'Pendente', tone: 'info' },
  running: { label: 'A correr', tone: 'brand' },
  done: { label: 'Concluído', tone: 'success' },
  failed: { label: 'Falhado', tone: 'danger' },
}

export const WEBHOOK_STATUS: Record<string, { label: string; tone: Tone }> = {
  received: { label: 'Recebido', tone: 'info' },
  processed: { label: 'Processado', tone: 'success' },
  ignored: { label: 'Ignorado', tone: 'neutral' },
  failed: { label: 'Falhado', tone: 'danger' },
}

export const INTEGRATION_LABEL: Record<string, string> = {
  jellyfin: 'Jellyfin',
  seerr: 'Seerr (pedidos)',
  dispatcharr: 'Dispatcharr (IPTV)',
  bazarr: 'Bazarr (legendas)',
  gocardless: 'GoCardless',
  stripe: 'Stripe',
  smtp: 'Email (SMTP)',
  whatsapp: 'WhatsApp',
  assistant: 'Assistentes de IA',
}

export const SERVICE_LABEL: Record<string, string> = {
  jellyfin: 'Jellyfin',
  seerr: 'Seerr',
  dispatcharr: 'Dispatcharr',
  iptv: 'IPTV (manual)',
}

export const ACTION_LABEL: Record<string, string> = {
  'auth.login': 'Início de sessão',
  'auth.login_failed': 'Tentativa de login falhada',
  'auth.2fa_failed': 'Código 2FA errado',
  'auth.recovery_code_used': 'Código de recuperação usado',
  'auth.reset_requested': 'Pedido de recuperação de password',
  'auth.password_reset': 'Password redefinida',
  'account.password_changed': 'Password alterada',
  'account.email_changed': 'Email alterado',
  'account.2fa_enabled': '2FA ativada',
  'account.2fa_disabled': '2FA desativada',
  'account.recovery_codes_regenerated': 'Novos códigos de recuperação',
  'user.register': 'Registo',
  'user.email_verified': 'Email confirmado',
  'subscription.created': 'Subscrição criada',
  'subscription.cancel': 'Subscrição cancelada',
  'subscription.resume': 'Subscrição retomada',
  'subscription.plan_changed': 'Mudança de plano',
  'subscription.status': 'Estado da subscrição alterado',
  'checkout.start': 'Checkout iniciado',
  'invite.create': 'Convite criado',
  'invite.email': 'Convite enviado por email',
  'bonus.on': 'Bónus ativado',
  'bonus.off': 'Bónus terminado',
  'jellyfin.device_removed': 'Dispositivo removido',
  'jellyfin.quick_connect': 'Quick Connect autorizado',
  'oidc.token': 'Login numa app (SSO)',
  'oidc.denied': 'Acesso a app recusado (SSO)',
  'admin.user_updated': 'Utilizador editado (admin)',
  'admin.grant_added': 'Oferta adicionada',
  'admin.grant_revoked': 'Oferta revogada',
  'admin.invite_created': 'Convite de admin criado',
  'admin.iptv_manual': 'Credenciais IPTV manuais',
  'admin.oidc_client_created': 'Cliente OIDC criado',
  'admin.oidc_client_updated': 'Cliente OIDC editado',
  'admin.oidc_client_deleted': 'Cliente OIDC apagado',
  'admin.oidc_client_secret_rotated': 'Segredo OIDC rodado',
  'admin.oidc_keys_rotated': 'Chaves OIDC rodadas',
  'admin.password_reset_sent': 'Reset de password enviado (admin)',
  'admin.plan_created': 'Plano criado',
  'admin.plan_updated': 'Plano editado',
  'admin.product_created': 'Produto criado',
  'admin.product_updated': 'Produto editado',
  'admin.service_unlinked': 'Serviço desassociado',
  'admin.sessions_revoked': 'Sessões terminadas (admin)',
  'admin.settings_updated': 'Definições alteradas',
  'admin.subscription_cancel': 'Subscrição cancelada (admin)',
}

export function actionLabel(action: string): string {
  return ACTION_LABEL[action] ?? action
}

export const AUDIT_PREFIXES: { value: string; label: string }[] = [
  { value: '', label: 'Todas as ações' },
  { value: 'auth.', label: 'Autenticação' },
  { value: 'account.', label: 'Conta' },
  { value: 'user.', label: 'Registo / email' },
  { value: 'subscription.', label: 'Subscrições' },
  { value: 'checkout.', label: 'Checkout' },
  { value: 'invite.', label: 'Convites' },
  { value: 'bonus.', label: 'Bónus' },
  { value: 'jellyfin.', label: 'Jellyfin' },
  { value: 'oidc.', label: 'SSO / OIDC' },
  { value: 'admin.', label: 'Administração' },
]

export const PLATFORM_LABEL: Record<string, string> = {
  android: 'Android',
  androidtv: 'Android TV',
  ios: 'iPhone / iPad',
  tvos: 'Apple TV',
  desktop: 'Computador',
  windows: 'Windows',
  macos: 'macOS',
  linux: 'Linux',
  web: 'Navegador',
  tv: 'Smart TV',
  roku: 'Roku',
  firetv: 'Fire TV',
  other: 'Outro',
}

export const USER_FILTERS: { value: string; label: string }[] = [
  { value: '', label: 'Todos' },
  { value: 'active', label: 'Ativos' },
  { value: 'past_due', label: 'Em atraso' },
  { value: 'canceling', label: 'Cancelados (a expirar)' },
  { value: 'bonus', label: 'Bónus' },
  { value: 'suspended', label: 'Suspensos' },
  { value: 'no_subscription', label: 'Sem subscrição' },
  { value: 'blocked', label: 'Bloqueados' },
  { value: 'admin', label: 'Administradores' },
]

export const REQUIRED_ACCESS_OPTIONS: { value: string; label: string }[] = [
  { value: '', label: 'Qualquer utilizador com conta' },
  { value: 'any_active', label: 'Qualquer subscrição ativa' },
  { value: 'feature:jellyfin', label: 'Acesso ao Jellyfin' },
  { value: 'feature:livetv', label: 'TV em direto' },
  { value: 'feature:seerr', label: 'Pedidos (Seerr)' },
  { value: 'feature:iptv', label: 'IPTV' },
  { value: 'product:tkgpt', label: 'TKGPT (LibreChat)' },
  { value: 'admin', label: 'Só administradores' },
  { value: '__custom', label: 'Personalizado (group:… / plan:… / product:…)' },
]

export const OIDC_SCOPES = ['openid', 'profile', 'email', 'groups', 'offline_access']
