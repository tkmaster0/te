import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import clsx from 'clsx'
import {
  ArrowLeft,
  ArrowRight,
  Check,
  CheckCircle2,
  Circle,
  Cloud,
  CreditCard,
  Globe,
  Import,
  KeyRound,
  Mail,
  Package,
  PartyPopper,
  PlaySquare,
  ShieldCheck,
  Tv,
} from 'lucide-react'
import { api, errorMessage } from '../../api/client'
import { useAction } from '../../api/mutation'
import type { ConfigOut, SetupStatus } from '../../api/types'
import { useAuth } from '../../auth/AuthProvider'
import { CONFIG_KEY, ConfigSectionForm } from '../../components/admin/ConfigSection'
import { LibreChatCard } from '../../components/admin/LibreChatCard'
import { Alert, Badge, Button, ButtonLink, Card, CardBody, CardHeader, Field, PasswordInput, SkeletonCard } from '../../components/ui'

interface Step {
  id: string
  title: string
  subtitle: string
  icon: typeof Globe
  sections?: string[]
}

const STEPS: Step[] = [
  { id: 'conta', title: 'A tua conta', subtitle: 'Password própria para o administrador', icon: ShieldCheck },
  { id: 'geral', title: 'Endereço público', subtitle: 'Domínio, registo e sessão', icon: Globe, sections: ['geral'] },
  { id: 'tunel', title: 'Túnel Cloudflare', subtitle: 'Publicar sem abrir portas', icon: Cloud, sections: ['tunel'] },
  { id: 'email', title: 'Email', subtitle: 'Códigos e avisos', icon: Mail, sections: ['email'] },
  { id: 'pagamentos', title: 'Pagamentos', subtitle: 'Débito direto e cartão', icon: CreditCard, sections: ['gocardless', 'stripe', 'faturacao'] },
  { id: 'tkflix', title: 'Jellyfin, Seerr e TV', subtitle: 'Serviços do TKFLIX', icon: Tv, sections: ['jellyfin', 'seerr', 'tv', 'bazarr', 'acesso'] },
  { id: 'sso', title: 'SSO e Jellyfin', subtitle: 'Login único e integrações', icon: KeyRound, sections: ['sso'] },
  { id: 'servicos', title: 'Serviços e planos', subtitle: 'O que vendes', icon: Package },
  { id: 'migracao', title: 'Clientes antigos', subtitle: 'Importar o site antigo', icon: Import },
  { id: 'fim', title: 'Concluir', subtitle: 'Rever e terminar', icon: PartyPopper },
]

function AccountStep({ weak, onDone }: { weak: boolean; onDone: () => void }) {
  const { me } = useAuth()
  const qc = useQueryClient()
  const [cur, setCur] = useState('')
  const [pwd, setPwd] = useState('')
  const change = useAction(() => api.post('/api/account/password', { current_password: cur, new_password: pwd, logout_others: false }), {
    success: 'Password atualizada.',
    errorTitle: 'Não foi possível mudar a password',
    onSuccess: () => {
      setCur('')
      setPwd('')
      void qc.invalidateQueries({ queryKey: ['admin', 'setup'] })
      onDone()
    },
  })
  return (
    <div className="space-y-5">
      {weak ? (
        <Alert tone="warning" title="A conta pré-carregada ainda usa a password conhecida">
          Entraste como <b>{me?.username}</b> com a password de origem. Antes de abrir o portal ao público, define uma password tua — demora 10 segundos.
        </Alert>
      ) : (
        <Alert tone="success" title="Password própria definida">
          A conta {me?.username} já não usa a password de origem.
        </Alert>
      )}
      <form
        className="grid gap-4 sm:grid-cols-2"
        onSubmit={(e) => {
          e.preventDefault()
          change.mutate()
        }}
      >
        <Field label="Password atual">
          <PasswordInput value={cur} onChange={(e) => setCur(e.target.value)} autoComplete="current-password" />
        </Field>
        <Field label="Nova password" hint="Pelo menos 8 caracteres.">
          <PasswordInput value={pwd} onChange={(e) => setPwd(e.target.value)} autoComplete="new-password" />
        </Field>
        <div className="sm:col-span-2">
          <Button type="submit" loading={change.isPending} disabled={!cur || pwd.length < 8}>
            Mudar password
          </Button>
        </div>
      </form>
      <p className="text-sm text-muted">
        Email da conta: <b className="text-fg">{me?.email}</b> — podes mudá-lo em <Link to="/app/conta" className="link">Conta</Link>.
      </p>
    </div>
  )
}

function SsoStep() {
  const presets = useAction(() => api.post<{ clients: { client_id: string; status: string; client_secret?: string; redirect_uris: string[] }[] }>('/api/admin/oidc-clients/presets'), {
    success: 'Clientes SSO criados/atualizados.',
  })
  return (
    <div className="space-y-4">
      <Alert
        tone="info"
        title="Clientes SSO (Jellyfin, Seerr, LibreChat)"
        action={
          <Button size="sm" onClick={() => presets.mutate()} loading={presets.isPending} icon={<KeyRound className="size-4" />}>
            Criar / atualizar
          </Button>
        }
      >
        Cria os clientes OIDC com os endereços que definiste. Os segredos aparecem só uma vez — copia-os para os plugins.
      </Alert>
      {presets.data?.clients.some((c) => c.client_secret) && (
        <div className="space-y-2 rounded-xl border border-border p-4 text-sm">
          {presets.data.clients
            .filter((c) => c.client_secret)
            .map((c) => (
              <p key={c.client_id} className="break-all">
                <b>{c.client_id}</b>: <code className="rounded bg-elevated px-1.5 py-0.5">{c.client_secret}</code>
              </p>
            ))}
        </div>
      )}
      <div className="flex flex-wrap gap-2">
        <ButtonLink to="/admin/jellyfin" variant="secondary" icon={<PlaySquare className="size-4" />}>
          O que colar no Jellyfin (Custom Pages, JS Injector, SSO)
        </ButtonLink>
        <ButtonLink to="/admin/sso" variant="ghost">
          Gerir clientes SSO
        </ButtonLink>
      </div>
    </div>
  )
}

export default function AdminSetup() {
  const navigate = useNavigate()
  const qc = useQueryClient()
  const [i, setI] = useState(0)
  const cfg = useQuery({ queryKey: CONFIG_KEY, queryFn: () => api.get<ConfigOut>('/api/admin/config'), refetchInterval: (q) => (q.state.data?.tunnel.running && !q.state.data.tunnel.connected ? 4000 : false) })
  const setup = useQuery({ queryKey: ['admin', 'setup'], queryFn: () => api.get<SetupStatus>('/api/admin/setup') })
  const finish = useAction(() => api.post('/api/admin/setup/complete'), {
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['admin', 'setup'] })
      navigate('/admin')
    },
  })
  const step = STEPS[i]
  const check = (id: string) => setup.data?.checklist.find((c) => c.id === id)
  const doneOf = (s: Step) => {
    if (s.id === 'tkflix') return check('jellyfin')?.done
    return check(s.id)?.done
  }
  const next = () => {
    void qc.invalidateQueries({ queryKey: ['admin', 'setup'] })
    setI((n) => Math.min(n + 1, STEPS.length - 1))
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  return (
    <div className="mx-auto max-w-6xl">
      <div className="mb-8 overflow-hidden rounded-3xl border border-border bg-gradient-to-br from-brand-soft via-surface to-surface p-6 sm:p-8">
        <p className="text-xs font-semibold uppercase tracking-wider text-brand-text">Configuração inicial</p>
        <h1 className="mt-1 text-2xl font-black tracking-tight sm:text-3xl">Vamos pôr o portal a funcionar</h1>
        <p className="mt-2 max-w-2xl text-muted">
          Tudo é definido aqui, no browser — sem ficheiros nem linha de comandos. Cada passo grava logo; podes saltar o que não usas e mudar tudo mais tarde em{' '}
          <Link to="/admin/definicoes" className="link">
            Definições
          </Link>
          .
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-[260px_1fr]">
        <nav aria-label="Passos" className="lg:sticky lg:top-20 lg:self-start">
          <ol className="flex gap-2 overflow-x-auto pb-2 lg:flex-col lg:overflow-visible">
            {STEPS.map((s, n) => {
              const done = doneOf(s)
              const Icon = s.icon
              return (
                <li key={s.id} className="shrink-0">
                  <button
                    type="button"
                    onClick={() => setI(n)}
                    className={clsx(
                      'flex w-full items-center gap-3 rounded-2xl border px-3 py-2.5 text-left transition-colors',
                      n === i ? 'border-brand/50 bg-brand-soft' : 'border-transparent hover:bg-hover',
                    )}
                    aria-current={n === i ? 'step' : undefined}
                  >
                    <span className={clsx('grid size-9 shrink-0 place-items-center rounded-xl', n === i ? 'bg-brand text-brand-fg' : 'bg-elevated text-muted')}>
                      <Icon className="size-4" aria-hidden />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm font-semibold">{s.title}</span>
                      <span className="hidden truncate text-xs text-muted lg:block">{s.subtitle}</span>
                    </span>
                    {done ? <CheckCircle2 className="size-4 shrink-0 text-success" aria-label="feito" /> : <Circle className="hidden size-4 shrink-0 text-border-strong lg:block" aria-hidden />}
                  </button>
                </li>
              )
            })}
          </ol>
        </nav>

        <div className="min-w-0 space-y-6">
          {cfg.isError && <Alert tone="danger">{errorMessage(cfg.error)}</Alert>}
          {!cfg.data || !setup.data ? (
            <SkeletonCard lines={8} />
          ) : step.id === 'conta' ? (
            <Card>
              <CardHeader icon={<ShieldCheck className="size-5" />} title={step.title} description={step.subtitle} />
              <CardBody>
                <AccountStep weak={!check('conta')?.done} onDone={() => undefined} />
              </CardBody>
            </Card>
          ) : step.id === 'servicos' ? (
            <Card>
              <CardHeader icon={<Package className="size-5" />} title="Serviços e planos" description="Cria e edita os serviços que vendes, os preços e as automações (webhooks)." />
              <CardBody className="space-y-4">
                <Alert tone="info" title="Não é preciso criar preços na GoCardless nem no Stripe">
                  O cliente autoriza o pagamento uma vez (mandato ou cartão) e é o portal que calcula e cobra o valor de cada mês. Os preços vivem só aqui — mudas um preço e
                  o portal trata do resto (com aviso aos clientes atuais).
                </Alert>
                <p className="text-sm text-muted">{check('servicos')?.hint}</p>
                <ButtonLink to="/admin/planos" icon={<Package className="size-4" />}>
                  Abrir Produtos &amp; planos
                </ButtonLink>
              </CardBody>
            </Card>
          ) : step.id === 'migracao' ? (
            <Card>
              <CardHeader icon={<Import className="size-5" />} title="Clientes do site antigo" description="Carregas o users.db antigo e ligas as subscrições GoCardless — os clientes não fazem nada." />
              <CardBody className="space-y-4">
                <ul className="space-y-2 text-sm text-muted">
                  <li className="flex gap-2"><Check className="mt-0.5 size-4 shrink-0 text-success" /> Mesmo username, email e password; email já confirmado.</li>
                  <li className="flex gap-2"><Check className="mt-0.5 size-4 shrink-0 text-success" /> A subscrição continua na GoCardless como estava.</li>
                  <li className="flex gap-2"><Check className="mt-0.5 size-4 shrink-0 text-success" /> Na primeira alteração (aderir, mudar, cancelar) passa sozinha para o portal, com o mesmo mandato.</li>
                </ul>
                <p className="text-sm">{check('migracao')?.hint}</p>
                <ButtonLink to="/admin/migracao" icon={<Import className="size-4" />}>
                  Abrir a migração
                </ButtonLink>
              </CardBody>
            </Card>
          ) : step.id === 'fim' ? (
            <Card>
              <CardHeader icon={<PartyPopper className="size-5" />} title="Quase pronto" description="Revê o que falta. O que é opcional pode ficar para depois." />
              <CardBody className="space-y-4">
                <ul className="divide-y divide-border rounded-2xl border border-border">
                  {setup.data.checklist.map((c) => (
                    <li key={c.id} className="flex items-center gap-3 px-4 py-3">
                      {c.done ? <CheckCircle2 className="size-5 shrink-0 text-success" /> : <Circle className="size-5 shrink-0 text-border-strong" />}
                      <span className="min-w-0 flex-1">
                        <span className="block text-sm font-medium">{c.label}</span>
                        <span className="block truncate text-xs text-muted">{c.hint}</span>
                      </span>
                      {!c.done && <Badge tone={c.optional ? 'neutral' : 'warning'}>{c.optional ? 'opcional' : 'por fazer'}</Badge>}
                    </li>
                  ))}
                </ul>
                <Button onClick={() => finish.mutate()} loading={finish.isPending} icon={<PartyPopper className="size-4" />}>
                  Concluir configuração
                </Button>
              </CardBody>
            </Card>
          ) : (
            (step.sections ?? []).map((id) => {
              const sec = cfg.data.sections.find((s) => s.id === id)
              if (!sec) return null
              return (
                <Card key={sec.id}>
                  <CardHeader title={sec.title} description={sec.description} />
                  <CardBody>
                    <ConfigSectionForm section={sec} tunnel={cfg.data.tunnel} publicUrl={setup.data.public_url} onSaved={() => void qc.invalidateQueries({ queryKey: ['admin', 'setup'] })} />
                  </CardBody>
                </Card>
              )
            })
          )}
          {step.id === 'sso' && (
            <>
              <Card>
                <CardHeader title="Clientes e plugins" />
                <CardBody>
                  <SsoStep />
                </CardBody>
              </Card>
              <LibreChatCard />
            </>
          )}

          <div className="flex items-center justify-between gap-3">
            <Button variant="secondary" onClick={() => setI((n) => Math.max(n - 1, 0))} disabled={i === 0} icon={<ArrowLeft className="size-4" />}>
              Anterior
            </Button>
            {i < STEPS.length - 1 && (
              <Button onClick={next} icon={<ArrowRight className="size-4" />} className="flex-row-reverse">
                {doneOf(step) ? 'Seguinte' : 'Saltar / seguinte'}
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
