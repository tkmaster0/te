import { useEffect, useState } from 'react'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import { keepPreviousData, useQuery } from '@tanstack/react-query'
import { Search, ShieldCheck, Users as UsersIcon, Ban, MailWarning, ChevronRight } from 'lucide-react'
import { api, errorMessage, qs } from '../../api/client'
import type { AdminUserRow, Paged } from '../../api/types'
import {
  Alert,
  Badge,
  Card,
  DateText,
  EmptyState,
  Input,
  PageHeader,
  Pagination,
  Pills,
  SkeletonRows,
  StatusBadge,
  Table,
  THead,
  Th,
  Tr,
  Td,
} from '../../components/ui'
import { USER_FILTERS } from '../../i18n/labels'

const SIZE = 25

function Flags({ u }: { u: AdminUserRow }) {
  return (
    <span className="inline-flex flex-wrap gap-1">
      {u.is_admin && (
        <Badge tone="brand" title="Administrador">
          <ShieldCheck className="inline size-3" /> Admin
        </Badge>
      )}
      {!u.is_active && (
        <Badge tone="danger" title="Bloqueado">
          <Ban className="inline size-3" /> Bloqueado
        </Badge>
      )}
      {!u.email_verified && (
        <Badge tone="warning" title="Email por confirmar">
          <MailWarning className="inline size-3" /> Email
        </Badge>
      )}
    </span>
  )
}

export default function AdminUsers() {
  const [params, setParams] = useSearchParams()
  const navigate = useNavigate()
  const status = params.get('status') ?? ''
  const page = Math.max(1, Number(params.get('page') ?? 1) || 1)
  const q = params.get('q') ?? ''
  const [search, setSearch] = useState(q)

  useEffect(() => {
    const t = window.setTimeout(() => {
      if (search.trim() === q) return
      const p = new URLSearchParams(params)
      if (search.trim()) p.set('q', search.trim())
      else p.delete('q')
      p.delete('page')
      setParams(p, { replace: true })
    }, 350)
    return () => window.clearTimeout(t)
  }, [search, q, params, setParams])

  const users = useQuery({
    queryKey: ['admin', 'users', { q, status, page }],
    queryFn: () => api.get<Paged<AdminUserRow>>(`/api/admin/users${qs({ q, status, page, size: SIZE })}`),
    placeholderData: keepPreviousData,
  })

  const setFilter = (key: string, value: string | number | null) => {
    const p = new URLSearchParams(params)
    if (value === null || value === '' || value === 1) p.delete(key)
    else p.set(key, String(value))
    if (key !== 'page') p.delete('page')
    setParams(p)
  }

  return (
    <div>
      <PageHeader eyebrow="Administração" title="Utilizadores" description={users.data ? `${users.data.total} utilizadores encontrados.` : undefined} />
      <div className="mb-4 space-y-3">
        <div className="relative">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-subtle" aria-hidden />
          <Input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Procurar por username, email ou nome…"
            aria-label="Procurar utilizadores"
            className="pl-10"
          />
        </div>
        <Pills ariaLabel="Filtrar por estado" items={USER_FILTERS} value={status} onChange={(v) => setFilter('status', v)} />
      </div>

      <Card className="overflow-hidden">
        {users.isPending ? (
          <SkeletonRows rows={8} />
        ) : users.isError ? (
          <div className="p-5">
            <Alert tone="danger">{errorMessage(users.error)}</Alert>
          </div>
        ) : !users.data.items.length ? (
          <EmptyState icon={<UsersIcon className="size-6" />} title="Nenhum utilizador encontrado" description="Experimenta outra pesquisa ou filtro." />
        ) : (
          <div className={users.isFetching ? 'opacity-70 transition-opacity' : undefined}>
            <div className="hidden md:block">
              <Table>
                <THead>
                  <Th>Utilizador</Th>
                  <Th>Subscrição</Th>
                  <Th>Registo</Th>
                  <Th>Último login</Th>
                  <Th>
                    <span className="sr-only">Indicadores</span>
                  </Th>
                </THead>
                <tbody>
                  {users.data.items.map((u) => (
                    <Tr key={u.id} onClick={() => navigate(`/admin/utilizadores/${u.id}`)}>
                      <Td>
                        <Link to={`/admin/utilizadores/${u.id}`} className="font-semibold hover:underline" onClick={(e) => e.stopPropagation()}>
                          {u.display_name || u.username}
                        </Link>
                        <p className="max-w-[18rem] truncate text-xs text-muted">
                          @{u.username} · {u.email}
                        </p>
                      </Td>
                      <Td>
                        {u.subscription ? (
                          <div className="space-y-1">
                            <StatusBadge status={u.subscription.status} />
                            <p className="text-xs text-muted">{u.subscription.plan}</p>
                          </div>
                        ) : (
                          <span className="text-sm text-subtle">—</span>
                        )}
                      </Td>
                      <Td className="whitespace-nowrap text-muted">
                        <DateText value={u.created_at} />
                      </Td>
                      <Td className="whitespace-nowrap text-muted">
                        <DateText value={u.last_login_at} relative fallback="Nunca" />
                      </Td>
                      <Td>
                        <Flags u={u} />
                      </Td>
                    </Tr>
                  ))}
                </tbody>
              </Table>
            </div>
            <ul className="divide-y divide-border md:hidden">
              {users.data.items.map((u) => (
                <li key={u.id}>
                  <Link to={`/admin/utilizadores/${u.id}`} className="flex items-center gap-3 px-4 py-3.5 hover:bg-elevated/60">
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-semibold">{u.display_name || u.username}</p>
                      <p className="truncate text-xs text-muted">
                        @{u.username} · {u.email}
                      </p>
                      <div className="mt-1.5 flex flex-wrap gap-1.5">
                        {u.subscription && <StatusBadge status={u.subscription.status} />}
                        <Flags u={u} />
                      </div>
                    </div>
                    <ChevronRight className="size-4 shrink-0 text-subtle" aria-hidden />
                  </Link>
                </li>
              ))}
            </ul>
            {(users.data.total > SIZE || page > 1) && (
              <Pagination page={page} size={SIZE} total={users.data.total} onPage={(p) => setFilter('page', p)} />
            )}
          </div>
        )}
      </Card>
    </div>
  )
}
