import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { AlertTriangle, BookOpen, KeyRound, Pencil, Plus, RotateCw, Sparkles, Trash2 } from 'lucide-react'
import { api, errorMessage } from '../../api/client'
import { useAction } from '../../api/mutation'
import type { OidcClient, OidcClientsOut } from '../../api/types'
import {
  Alert,
  Badge,
  Button,
  Card,
  CardHeader,
  Checkbox,
  CopyField,
  EmptyState,
  Field,
  Input,
  Modal,
  PageHeader,
  Select,
  SkeletonCard,
  StringListEditor,
  Switch,
  useConfirm,
} from '../../components/ui'
import { OIDC_SCOPES, REQUIRED_ACCESS_OPTIONS } from '../../i18n/labels'
import { useAdminProducts } from '../../api/admin'
import { LibreChatCard } from '../../components/admin/LibreChatCard'

const KEY = ['admin', 'oidc']

function accessLabel(v: string | null): string {
  if (!v) return 'Qualquer utilizador'
  return REQUIRED_ACCESS_OPTIONS.find((o) => o.value === v)?.label ?? v
}

function SecretModal({ secret, clientId, onClose }: { secret: string | null; clientId: string; onClose: () => void }) {
  const [ack, setAck] = useState(false)
  return (
    <Modal
      open={!!secret}
      onClose={onClose}
      dismissible={false}
      title="Segredo do cliente"
      description={`Cliente “${clientId}”`}
      footer={
        <Button
          disabled={!ack}
          onClick={() => {
            setAck(false)
            onClose()
          }}
        >
          Já guardei o segredo
        </Button>
      }
    >
      <div className="space-y-4">
        <Alert tone="warning" title="Só mostramos este segredo uma vez">
          Copia-o agora para a configuração da aplicação. Se o perderes, terás de gerar um novo.
        </Alert>
        <CopyField label="client_id" value={clientId} />
        <CopyField label="client_secret" value={secret} />
        <Checkbox checked={ack} onChange={(e) => setAck(e.target.checked)} label="Copiei o segredo para um sítio seguro" />
      </div>
    </Modal>
  )
}

interface FormState {
  client_id: string
  name: string
  redirect_uris: string[]
  post_logout_redirect_uris: string[]
  allowed_scopes: string[]
  access: string
  custom: string
  public: boolean
  require_pkce: boolean
  is_active: boolean
}

function toForm(c: OidcClient | null): FormState {
  const ra = c?.required_access ?? ''
  const known = ra.startsWith('product:') || REQUIRED_ACCESS_OPTIONS.some((o) => o.value === ra && o.value !== '__custom')
  return {
    client_id: c?.client_id ?? '',
    name: c?.name ?? '',
    redirect_uris: c?.redirect_uris ?? [],
    post_logout_redirect_uris: c?.post_logout_redirect_uris ?? [],
    allowed_scopes: c?.allowed_scopes ?? ['openid', 'profile', 'email', 'groups'],
    access: known ? ra : '__custom',
    custom: known ? '' : ra,
    public: c?.public ?? false,
    require_pkce: c?.require_pkce ?? false,
    is_active: c?.is_active ?? true,
  }
}

function ClientModal({ client, open, onClose, onCreated }: { client: OidcClient | null; open: boolean; onClose: () => void; onCreated: (id: string, secret: string | null) => void }) {
  const isNew = !client
  const products = useAdminProducts()
  const [f, setF] = useState<FormState>(() => toForm(client))
  const set = <K extends keyof FormState>(k: K, v: FormState[K]) => setF((s) => ({ ...s, [k]: v }))
  const required = f.access === '__custom' ? f.custom.trim() || null : f.access || null
  const save = useAction(
    () => {
      const body = {
        client_id: f.client_id,
        name: f.name.trim(),
        redirect_uris: f.redirect_uris.map((u) => u.trim()).filter(Boolean),
        post_logout_redirect_uris: f.post_logout_redirect_uris.map((u) => u.trim()).filter(Boolean),
        allowed_scopes: Array.from(new Set(['openid', ...f.allowed_scopes])),
        required_access: required,
        public: f.public,
        require_pkce: f.require_pkce,
        is_active: f.is_active,
      }
      return isNew
        ? api.post<OidcClient & { client_secret: string | null }>('/api/admin/oidc-clients', body)
        : api.put(`/api/admin/oidc-clients/${encodeURIComponent(client!.client_id)}`, body)
    },
    {
      invalidate: [KEY],
      success: isNew ? 'Cliente criado.' : 'Cliente guardado.',
      errorTitle: 'Não foi possível guardar',
      onSuccess: (res) => {
        onClose()
        if (isNew) onCreated(f.client_id, (res as { client_secret: string | null }).client_secret)
      },
    },
  )
  const valid = /^[a-z0-9_.-]{3,64}$/.test(f.client_id) && f.name.trim() && f.redirect_uris.some((u) => u.trim())
  return (
    <Modal
      open={open}
      onClose={onClose}
      size="lg"
      title={isNew ? 'Novo cliente OIDC' : `Editar ${client?.name}`}
      description="Uma aplicação que usa o portal para autenticar utilizadores (Jellyfin, Seerr, Grafana…)."
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancelar
          </Button>
          <Button loading={save.isPending} disabled={!valid} onClick={() => save.mutate()}>
            {isNew ? 'Criar cliente' : 'Guardar'}
          </Button>
        </>
      }
    >
      <div className="space-y-5">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Field label="Nome" hint="Mostrado ao utilizador.">
            <Input value={f.name} onChange={(e) => set('name', e.target.value)} maxLength={120} placeholder="Jellyfin" />
          </Field>
          <Field label="Client ID" hint={isNew ? 'Minúsculas, números, “.”, “_”, “-”.' : 'Não pode ser alterado.'}>
            <Input
              value={f.client_id}
              disabled={!isNew}
              onChange={(e) => set('client_id', e.target.value.toLowerCase().replace(/[^a-z0-9_.-]/g, ''))}
              className="font-mono"
              placeholder="jellyfin"
              maxLength={64}
            />
          </Field>
        </div>
        <Field label="Redirect URIs" hint="Endereços de retorno autorizados (têm de coincidir exatamente).">
          <div>
            <StringListEditor
              value={f.redirect_uris}
              onChange={(v) => set('redirect_uris', v)}
              placeholder="https://app.exemplo.pt/oauth/callback"
              ariaLabel="Redirect URIs"
              inputType="url"
            />
          </div>
        </Field>
        <Field label="Post-logout redirect URIs" optional>
          <div>
            <StringListEditor
              value={f.post_logout_redirect_uris}
              onChange={(v) => set('post_logout_redirect_uris', v)}
              placeholder="https://app.exemplo.pt/"
              ariaLabel="Post-logout redirect URIs"
              inputType="url"
            />
          </div>
        </Field>
        <fieldset>
          <legend className="mb-2 text-sm font-medium">Scopes</legend>
          <div className="flex flex-wrap gap-x-5 gap-y-2">
            {OIDC_SCOPES.map((s) => (
              <Checkbox
                key={s}
                label={<span className="font-mono text-xs">{s}</span>}
                checked={s === 'openid' || f.allowed_scopes.includes(s)}
                disabled={s === 'openid'}
                onChange={(e) => set('allowed_scopes', e.target.checked ? [...f.allowed_scopes, s] : f.allowed_scopes.filter((x) => x !== s))}
              />
            ))}
          </div>
        </fieldset>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Field label="Quem pode entrar">
            <Select value={f.access} onChange={(e) => set('access', e.target.value)}>
              {REQUIRED_ACCESS_OPTIONS.filter((o) => o.value !== '__custom' && !o.value.startsWith('product:')).map((o) => (
                <option key={o.value} value={o.value}>
                  {o.label}
                </option>
              ))}
              {(products.data ?? []).length > 0 && (
                <optgroup label="Subscrição ativa de um serviço">
                  {(products.data ?? []).map((p) => (
                    <option key={p.code} value={`product:${p.code}`}>
                      {p.name}
                    </option>
                  ))}
                </optgroup>
              )}
              <option value="__custom">Personalizado (group:… / plan:… / product:…)</option>
            </Select>
          </Field>
          {f.access === '__custom' && (
            <Field label="Requisito personalizado" hint="ex.: group:tkflix-vip ou plan:tkflix-tv-mensal">
              <Input value={f.custom} onChange={(e) => set('custom', e.target.value)} className="font-mono" />
            </Field>
          )}
        </div>
        <p className="-mt-2 text-xs text-muted">Administradores têm sempre acesso. Quem não cumprir o requisito vê a página “Sem acesso”.</p>
        <div className="space-y-3 rounded-xl border border-border p-4">
          <Switch
            checked={f.public}
            onChange={(v) => set('public', v)}
            disabled={!isNew}
            label="Cliente público (sem segredo)"
            description={isNew ? 'Para apps no navegador ou telemóvel. Usa PKCE obrigatoriamente.' : 'Só pode ser definido na criação.'}
          />
          <Switch checked={f.require_pkce || f.public} onChange={(v) => set('require_pkce', v)} disabled={f.public} label="Exigir PKCE" />
          <Switch checked={f.is_active} onChange={(v) => set('is_active', v)} label="Ativo" />
        </div>
      </div>
    </Modal>
  )
}

function HelpPanel({ issuer }: { issuer: string }) {
  const base = issuer.replace(/\/$/, '')
  return (
    <Card>
      <CardHeader icon={<BookOpen className="size-5" />} title="Guia rápido" description="Configurações prontas a copiar para a tua pilha." />
      <div className="space-y-6 px-5 pb-6 pt-4 sm:px-6">
        <section className="space-y-3">
          <h3 className="font-semibold">Jellyfin — plugin SSO 9p4 (opcional, em paralelo)</h3>
          <ol className="list-decimal space-y-1 pl-5 text-sm text-muted">
            <li>Cria aqui um cliente com o ID <code className="kbd">jellyfin</code> e o redirect abaixo (troca pelo teu domínio do Jellyfin).</li>
            <li>No plugin, adiciona um provider OID chamado <code className="kbd">tkflix</code> com estes valores.</li>
            <li>Em “Roles”, usa o claim <code className="kbd">groups</code> para mapear administradores.</li>
          </ol>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <CopyField label="Redirect URI" value="https://<jellyfin>/sso/OID/redirect/tkflix" />
            <CopyField label="OID Endpoint" value={base} />
            <CopyField label="Scopes" value="openid profile email groups" />
            <CopyField label="Link do botão de login" value="https://<jellyfin>/sso/OID/start/tkflix" />
          </div>
        </section>
        <section className="space-y-3">
          <h3 className="font-semibold">Jellyfin — plugin Jellyfin Security (recomendado)</h3>
          <ol className="list-decimal space-y-1 pl-5 text-sm text-muted">
            <li>Fornecedor OIDC com o nome <code className="kbd">tkws</code>, Client ID <code className="kbd">jellyfin</code> e o segredo do cliente.</li>
            <li>Username claim <code className="kbd">preferred_username</code>, ligação por username ligada, auto-create e admin elevation desligados.</li>
            <li>Pode correr ao mesmo tempo que o 9p4 — o cliente <code className="kbd">jellyfin</code> tem os redirects dos dois.</li>
          </ol>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <CopyField label="Discovery / Issuer" value={base} />
            <CopyField label="Redirect URI" value="https://<jellyfin>/TwoFactorAuth/Oidc/Callback/tkws" />
          </div>
        </section>
        <section className="space-y-3">
          <h3 className="font-semibold">Seerr — OpenID Connect nativo</h3>
          <p className="text-sm text-muted">
            O Seerr liga a conta pelo <strong>email</strong> (o portal mantém o email do Seerr igual ao da conta TK). Usa o botão «Clientes predefinidos»
            para criar o cliente <code className="kbd">seerr</code> e, no <code className="kbd">settings.json</code> do Seerr, adiciona o provider:
          </p>
          <CopyField
            label="settings.json → oidc.providers"
            value={`{"slug":"tkws","name":"TK Web Services","issuerUrl":"${base}","clientId":"seerr","clientSecret":"<segredo>","newUserLogin":true,"requiredClaims":["email_verified"]}`}
          />
        </section>
        <section className="space-y-3">
          <h3 className="font-semibold">LibreChat (TKGPT) — OpenID</h3>
          <p className="text-sm text-muted">
            Só entra quem tem o TKGPT ativo. Com <code className="kbd">OPENID_REUSE_TOKENS=true</code> a sessão termina quando a subscrição acaba.
          </p>
          <CopyField
            label=".env do LibreChat"
            value={`OPENID_ISSUER=${base}\nOPENID_CLIENT_ID=librechat\nOPENID_CLIENT_SECRET=<segredo>\nOPENID_SCOPE="openid profile email offline_access"\nOPENID_CALLBACK_URL=/oauth/openid/callback\nOPENID_BUTTON_LABEL="Entrar com TK Web Services"\nOPENID_USE_PKCE=true\nOPENID_REUSE_TOKENS=true\nALLOW_SOCIAL_LOGIN=true\nALLOW_SOCIAL_REGISTRATION=true`}
          />
        </section>
        <section className="space-y-3">
          <h3 className="font-semibold">Forward-auth (Traefik / Caddy) para a pilha DUMB</h3>
          <p className="text-sm text-muted">
            Protege qualquer app atrás do proxy com a sessão do portal. Muda <code className="kbd">require</code> para <code className="kbd">any_active</code>,{' '}
            <code className="kbd">feature:jellyfin</code>, <code className="kbd">group:…</code> ou <code className="kbd">admin</code>.
          </p>
          <CopyField label="URL de verificação" value={`${base}/auth/verify?require=admin`} />
          <CopyField
            label="Traefik (labels)"
            value={`traefik.http.middlewares.tkflix-auth.forwardauth.address=${base}/auth/verify?require=admin`}
          />
          <CopyField label="Caddy" value={`forward_auth ${base} { uri /auth/verify?require=admin copy_headers Remote-User Remote-Email Remote-Groups }`} />
        </section>
      </div>
    </Card>
  )
}

export default function AdminSso() {
  const confirm = useConfirm()
  const q = useQuery({ queryKey: KEY, queryFn: () => api.get<OidcClientsOut>('/api/admin/oidc-clients') })
  const [modal, setModal] = useState<{ client: OidcClient | null } | null>(null)
  const [secret, setSecret] = useState<{ id: string; secret: string } | null>(null)
  const rotate = useAction((id: string) => api.post<{ client_secret: string }>(`/api/admin/oidc-clients/${encodeURIComponent(id)}/rotate-secret`), {
    success: false,
    errorTitle: 'Não foi possível rodar o segredo',
    onSuccess: (res, id) => setSecret({ id, secret: res.client_secret }),
  })
  const del = useAction((id: string) => api.del(`/api/admin/oidc-clients/${encodeURIComponent(id)}`), { invalidate: [KEY], success: 'Cliente apagado.' })
  const rotateKeys = useAction(() => api.post('/api/admin/oidc/rotate-keys'), {})
  const [presetOut, setPresetOut] = useState<{ client_id: string; status: string; client_secret: string | null; redirect_uris: string[] }[] | null>(null)
  const presets = useAction(
    () => api.post<{ clients: { client_id: string; status: string; client_secret: string | null; redirect_uris: string[] }[] }>('/api/admin/oidc-clients/presets'),
    { invalidate: [KEY], success: false, errorTitle: 'Não foi possível criar os clientes', onSuccess: (res) => setPresetOut(res.clients) },
  )

  return (
    <div className="space-y-4">
      <PageHeader
        eyebrow="Administração"
        title="SSO / OIDC"
        description="O portal é um fornecedor de identidade: as tuas apps podem usar “Entrar com TK Web Services”."
        actions={
          <>
            <Button
              variant="secondary"
              icon={<KeyRound className="size-4" />}
              loading={rotateKeys.isPending}
              onClick={async () => {
                if (
                  await confirm({
                    title: 'Rodar chaves de assinatura?',
                    message: 'É gerada uma nova chave para assinar tokens. A anterior continua publicada durante 2 dias, por isso as sessões atuais não são afetadas.',
                    confirmLabel: 'Rodar chaves',
                  })
                )
                  rotateKeys.mutate()
              }}
            >
              Rodar chaves de assinatura
            </Button>
            <Button variant="secondary" icon={<Sparkles className="size-4" />} loading={presets.isPending} onClick={() => presets.mutate()}>
              Clientes predefinidos
            </Button>
            <Button icon={<Plus className="size-4" />} onClick={() => setModal({ client: null })}>
              Novo cliente
            </Button>
          </>
        }
      />
      {q.isPending ? (
        <SkeletonCard lines={4} />
      ) : q.isError ? (
        <Alert tone="danger">{errorMessage(q.error)}</Alert>
      ) : (
        <>
          <Card>
            <div className="grid grid-cols-1 gap-4 p-5 sm:grid-cols-2 sm:p-6">
              <CopyField label="Issuer" value={q.data.issuer} />
              <CopyField label="Discovery (/.well-known/openid-configuration)" value={q.data.discovery} />
            </div>
          </Card>

          {!q.data.clients.length ? (
            <Card>
              <EmptyState
                icon={<KeyRound className="size-6" />}
                title="Sem clientes"
                description="Cria um cliente para cada aplicação que deve usar o login do portal."
                action={<Button onClick={() => setModal({ client: null })}>Novo cliente</Button>}
              />
            </Card>
          ) : (
            <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
              {q.data.clients.map((c) => (
                <Card key={c.client_id} className="flex flex-col">
                  <div className="flex flex-wrap items-start gap-3 px-5 pt-5 sm:px-6">
                    <div className="min-w-0 flex-1">
                      <h2 className="font-semibold">{c.name}</h2>
                      <p className="font-mono text-xs text-muted">{c.client_id}</p>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {c.is_active ? <Badge tone="success">Ativo</Badge> : <Badge tone="neutral">Inativo</Badge>}
                      {c.public ? <Badge tone="info">Público</Badge> : <Badge tone="neutral">Confidencial</Badge>}
                      {c.require_pkce && <Badge tone="neutral">PKCE</Badge>}
                    </div>
                  </div>
                  <dl className="flex-1 space-y-2 px-5 py-4 text-sm sm:px-6">
                    <div>
                      <dt className="text-xs text-muted">Quem pode entrar</dt>
                      <dd className="font-medium">{accessLabel(c.required_access)}</dd>
                    </div>
                    <div>
                      <dt className="text-xs text-muted">Redirect URIs</dt>
                      <dd className="space-y-0.5">
                        {c.redirect_uris.map((u) => (
                          <p key={u} className="break-all font-mono text-xs">
                            {u}
                          </p>
                        ))}
                      </dd>
                    </div>
                    <div>
                      <dt className="text-xs text-muted">Scopes</dt>
                      <dd className="font-mono text-xs">{c.allowed_scopes.join(' ')}</dd>
                    </div>
                  </dl>
                  <div className="flex flex-wrap gap-2 border-t border-border px-5 py-3 sm:px-6">
                    <Button size="sm" variant="secondary" icon={<Pencil className="size-3.5" />} onClick={() => setModal({ client: c })}>
                      Editar
                    </Button>
                    {!c.public && (
                      <Button
                        size="sm"
                        variant="secondary"
                        icon={<RotateCw className="size-3.5" />}
                        loading={rotate.isPending && rotate.variables === c.client_id}
                        onClick={async () => {
                          if (
                            await confirm({
                              title: 'Gerar novo segredo?',
                              message: 'O segredo atual deixa de funcionar imediatamente. Vais ter de atualizar a configuração da aplicação.',
                              confirmLabel: 'Gerar novo segredo',
                              danger: true,
                            })
                          )
                            rotate.mutate(c.client_id)
                        }}
                      >
                        Rodar segredo
                      </Button>
                    )}
                    <Button
                      size="sm"
                      variant="ghost"
                      className="ml-auto"
                      icon={<Trash2 className="size-3.5" />}
                      onClick={async () => {
                        if (
                          await confirm({
                            title: `Apagar “${c.name}”?`,
                            message: (
                              <span className="flex gap-2">
                                <AlertTriangle className="size-4 shrink-0 text-warning" />A aplicação deixa de conseguir autenticar utilizadores através do portal.
                              </span>
                            ),
                            confirmLabel: 'Apagar',
                            danger: true,
                          })
                        )
                          del.mutate(c.client_id)
                      }}
                    >
                      Apagar
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          )}
          <HelpPanel issuer={q.data.issuer} />
        </>
      )}
      {modal && (
        <ClientModal client={modal.client} open onClose={() => setModal(null)} onCreated={(id, s) => s && setSecret({ id, secret: s })} />
      )}
      <SecretModal secret={secret?.secret ?? null} clientId={secret?.id ?? ''} onClose={() => setSecret(null)} />
      <Modal
        open={!!presetOut}
        onClose={() => setPresetOut(null)}
        title="Clientes do Jellyfin, Seerr e LibreChat"
        description="Criados a partir dos URLs do .env (JELLYFIN_PUBLIC_URL, SEERR_PUBLIC_URL, LIBRECHAT_URL). Os segredos novos só aparecem agora."
        dismissible={false}
        footer={<Button onClick={() => setPresetOut(null)}>Já guardei</Button>}
      >
        {!presetOut?.length ? (
          <p className="text-sm text-muted">Nenhum URL configurado no .env — define JELLYFIN_PUBLIC_URL, SEERR_PUBLIC_URL e/ou LIBRECHAT_URL.</p>
        ) : (
          <div className="space-y-4">
            {presetOut.map((c) => (
              <div key={c.client_id} className="space-y-2 rounded-xl border border-border p-3">
                <p className="text-sm font-semibold">
                  {c.client_id} <span className="font-normal text-muted">· {c.status}</span>
                </p>
                {c.client_secret ? <CopyField label="client_secret" value={c.client_secret} /> : <p className="text-xs text-muted">Segredo mantido (usa «Rodar segredo» para gerar outro).</p>}
              </div>
            ))}
          </div>
        )}
      </Modal>
      <LibreChatCard />
    </div>
  )
}
