import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Code2, ExternalLink, FileCode2, LogIn, PackagePlus, PlaySquare, QrCode, RefreshCw } from 'lucide-react'
import { api, errorMessage } from '../../api/client'
import type { JellyfinHelpStatus, JellyfinSnippets } from '../../api/types'
import {
  Alert,
  Badge,
  Button,
  ButtonLink,
  Card,
  CardBody,
  CardHeader,
  CopyButton,
  CopyField,
  DateText,
  PageHeader,
  SkeletonCard,
  Table,
  Td,
  Th,
  THead,
  Tr,
  useToast,
} from '../../components/ui'

function Code({ value, label, rows = 8 }: { value: string; label: string; rows?: number }) {
  return (
    <div className="relative min-w-0">
      <div className="mb-1.5 flex items-center justify-between gap-2">
        <p className="text-xs font-medium text-muted">{label}</p>
        <span className="flex items-center gap-1 text-xs text-muted">
          copiar <CopyButton value={value} label={`Copiar ${label}`} />
        </span>
      </div>
      <pre className="overflow-auto rounded-xl border border-border bg-bg p-3 font-mono text-[12px] leading-relaxed" style={{ maxHeight: `${rows * 1.6}rem` }}>
        {value}
      </pre>
    </div>
  )
}

function Ext({ href, children }: { href?: string | null; children: React.ReactNode }) {
  if (!href) return null
  return (
    <a href={href} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-sm text-brand-text hover:underline">
      {children} <ExternalLink className="size-3" aria-hidden />
    </a>
  )
}

const CLIENTS: { name: string; how: 'widget' | 'tv' | 'native'; note: string }[] = [
  { name: 'Jellyfin no browser (jellyfin-web)', how: 'widget', note: 'Botão “Ajuda” no canto + página “A minha conta”.' },
  { name: 'Jellyfin para Android e iOS', how: 'widget', note: 'As apps móveis usam o jellyfin-web por dentro: o mesmo botão; os links abrem no browser do telemóvel.' },
  { name: 'Jellyfin Desktop / Media Player', how: 'widget', note: 'jellyfin-web por dentro: o mesmo botão.' },
  { name: 'Jellyfin para Samsung (Tizen) e LG (webOS)', how: 'tv', note: 'jellyfin-web em modo TV: botão maior e navegável com o comando + coleção “Ajuda”.' },
  { name: 'Jellyfin Android TV / Fire TV', how: 'native', note: 'App nativa: coleção “Ajuda” com QR (abre o chat no telemóvel) e WhatsApp.' },
  { name: 'Swiftfin (iOS, iPadOS, tvOS)', how: 'native', note: 'App nativa: coleção “Ajuda” com QR e WhatsApp.' },
  { name: 'Moonfin (Android, Android TV, iOS, tvOS, web, desktop, Tizen/webOS, Roku)', how: 'native', note: 'Cliente próprio (Flutter), não corre plugins de JavaScript: coleção “Ajuda” com QR e WhatsApp.' },
  { name: 'Roku, Kodi, Findroid, Streamyfin e outros', how: 'native', note: 'Coleção “Ajuda” com QR e WhatsApp.' },
]

const HOW = {
  widget: <Badge tone="success">botão Ajuda</Badge>,
  tv: <Badge tone="success">botão (modo TV)</Badge>,
  native: <Badge tone="brand">coleção + QR</Badge>,
}

/** Apps que não correm o jellyfin-web: coleção “Ajuda” com QR para o chat no telemóvel. */
function NativeApps() {
  const qc = useQueryClient()
  const toast = useToast()
  const [v, setV] = useState(0)
  const q = useQuery({ queryKey: ['admin', 'jellyfin-help'], queryFn: () => api.get<JellyfinHelpStatus>('/api/admin/jellyfin/help') })
  const publish = useMutation({
    mutationFn: () => api.post<{ id: string; created: boolean; item_url: string | null }>('/api/admin/jellyfin/help'),
    onSuccess: (r) => {
      toast.success(r.created ? 'Coleção “Ajuda” criada no Jellyfin' : 'Coleção “Ajuda” atualizada')
      setV((x) => x + 1)
      qc.invalidateQueries({ queryKey: ['admin', 'jellyfin-help'] })
    },
    onError: (e) => toast.error('Não foi possível publicar', errorMessage(e)),
  })
  const d = q.data
  return (
    <Card>
      <CardHeader
        icon={<QrCode className="size-5" />}
        title="5. Apps de TV e apps nativas (Android TV, Swiftfin, Moonfin…)"
        description="Estas apps não correm JavaScript do servidor. O portal cria no Jellyfin uma coleção “Ajuda” com um QR code: o cliente aponta o telemóvel e fala com o mesmo assistente (com a mesma memória)."
        actions={d?.id ? <Badge tone="success">publicada</Badge> : <Badge tone="neutral">por criar</Badge>}
      />
      <CardBody className="space-y-5">
        <Table minWidth={620}>
          <THead>
            <Tr>
              <Th>App</Th>
              <Th>Ajuda</Th>
              <Th>Como</Th>
            </Tr>
          </THead>
          <tbody>
            {CLIENTS.map((c) => (
              <Tr key={c.name}>
                <Td className="font-medium">{c.name}</Td>
                <Td>{HOW[c.how]}</Td>
                <Td className="text-muted">{c.note}</Td>
              </Tr>
            ))}
          </tbody>
        </Table>

        <div className="grid gap-4 sm:grid-cols-[minmax(0,180px)_minmax(0,1fr)]">
          <img src={`/api/admin/jellyfin/help/poster.png?v=${v}`} alt="Cartaz da coleção Ajuda com o QR code" className="w-full max-w-[180px] rounded-lg border border-border" />
          <div className="min-w-0 space-y-3">
            <img src={`/api/admin/jellyfin/help/backdrop.png?v=${v}`} alt="Imagem de fundo da coleção Ajuda" className="w-full max-w-md rounded-lg border border-border" />
            {d && (
              <p className="text-sm text-muted">
                O QR abre <b className="text-fg">{d.help_url}</b> (entra com a conta TKWS e cai no chat).{' '}
                {d.whatsapp ? <>Inclui o WhatsApp do assistente.</> : <>Com o WhatsApp configurado (Definições → WhatsApp) o número aparece também no cartaz.</>}
                {d.updated_at && (
                  <>
                    {' '}Última publicação: <DateText value={d.updated_at} />.
                  </>
                )}
              </p>
            )}
          </div>
        </div>

        {d && !d.jellyfin_ready && <Alert tone="warning">Configura primeiro o Jellyfin (endereço interno e chave de API) em Definições → Jellyfin.</Alert>}
        {d?.stale && <Alert tone="warning">O endereço do portal mudou desde a última publicação — atualiza a coleção para o QR apontar para o sítio certo.</Alert>}
        <div className="flex flex-wrap items-center gap-3">
          <Button icon={<RefreshCw className="size-4" />} loading={publish.isPending} disabled={!d?.jellyfin_ready} onClick={() => publish.mutate()}>
            {d?.id ? 'Atualizar a coleção “Ajuda”' : 'Criar a coleção “Ajuda” no Jellyfin'}
          </Button>
          <Ext href={d?.item_url}>Ver no Jellyfin</Ext>
        </div>
        <p className="text-xs text-muted">
          Não aparece a alguém? Confirma que essa conta tem acesso às Coleções (Painel do Jellyfin → Utilizadores → Acesso). Também podes descarregar o cartaz e usá-lo noutro sítio (ex.: ecrã
          de arranque no Branding).
        </p>
      </CardBody>
    </Card>
  )
}

/** Admin → Jellyfin: o que instalar e colar nos plugins, com o endereço do portal já preenchido. */
export default function AdminJellyfin() {
  const q = useQuery({ queryKey: ['admin', 'jellyfin-snippets'], queryFn: () => api.get<JellyfinSnippets>('/api/admin/jellyfin/snippets') })
  const [full, setFull] = useState(false)
  const s = q.data
  return (
    <div>
      <PageHeader
        eyebrow="Administração"
        title="Jellyfin"
        description="O ícone de ajuda (assistente) em todas as páginas, a página “A minha conta” e o botão de login com a conta TK — tudo pronto a copiar."
      />
      {q.isError ? (
        <Alert tone="danger">{errorMessage(q.error)}</Alert>
      ) : !s ? (
        <SkeletonCard lines={10} />
      ) : (
        <div className="space-y-5">
          {!s.jellyfin_url && (
            <Alert tone="warning" title="Falta o endereço público do Jellyfin" action={<ButtonLink size="sm" to="/admin/definicoes?s=jellyfin">Definir</ButtonLink>}>
              O widget e a página só falam com o portal a partir desse endereço (é a origem autorizada). Define-o em Definições → Jellyfin.
            </Alert>
          )}
          <Card>
            <CardHeader icon={<PackagePlus className="size-5" />} title="1. Repositórios de plugins" description="Painel do Jellyfin → Plugins → Repositórios → + (um de cada vez). Depois instala os plugins no Catálogo e reinicia o Jellyfin." />
            <CardBody className="space-y-3">
              {s.repositories.map((r) => (
                <CopyField key={r.url} label={r.name} value={r.url} />
              ))}
              <div className="flex flex-wrap gap-4">
                <Ext href={s.links.repositories}>Abrir Repositórios</Ext>
                <Ext href={s.links.catalog}>Abrir Catálogo</Ext>
              </div>
            </CardBody>
          </Card>

          <Card>
            <CardHeader
              icon={<Code2 className="size-5" />}
              title="2. Ícone de ajuda (JavaScript Injector)"
              description="Mostra o botão “Ajuda” no canto de todas as páginas do Jellyfin, com o assistente (suporte, legendas, subscrição)."
              actions={<Badge tone="brand">recomendado</Badge>}
            />
            <CardBody className="space-y-4">
              <ol className="list-decimal space-y-1 pl-5 text-sm text-muted">
                <li>Painel → Plugins → <b className="text-fg">JavaScript Injector</b> → Add Script.</li>
                <li>
                  Name: <b className="text-fg">TK — Ajuda</b> · Requires authentication: <b className="text-fg">ligado</b> · Enabled: <b className="text-fg">ligado</b>.
                </li>
                <li>Cola o código abaixo e guarda. Atualiza a página do Jellyfin (Ctrl+F5).</li>
              </ol>
              <Code label={full ? 'Código completo (não carrega nada do portal)' : 'Código a colar (carrega o widget sempre atualizado do portal)'} value={full ? s.js_full : s.js_loader} rows={full ? 14 : 8} />
              <Button size="sm" variant="ghost" onClick={() => setFull((f) => !f)}>
                {full ? 'Usar a versão curta (recomendada)' : 'Prefiro colar o código completo'}
              </Button>
              <Alert tone="info">O botão só aparece com o assistente ligado (Definições → Assistente de IA) e nunca para contas de administrador do Jellyfin.</Alert>
            </CardBody>
          </Card>

          <Card>
            <CardHeader icon={<FileCode2 className="size-5" />} title="3. Página “A minha conta” (Custom Pages)" description="Subscrição de streaming dentro do Jellyfin: estado, próxima cobrança, mudar de plano, cancelar e ajuda." />
            <CardBody className="space-y-4">
              <ol className="list-decimal space-y-1 pl-5 text-sm text-muted">
                <li>Painel → Plugins → <b className="text-fg">Custom Pages</b> → nova página.</li>
                <li>
                  Slug: <b className="text-fg">conta</b> · Title: <b className="text-fg">A minha conta</b> · Visibility: <b className="text-fg">User</b> · Mode: <b className="text-fg">Single file</b> · Allow
                  system access: <b className="text-fg">ligado</b>.
                </li>
                <li>Cola o HTML abaixo (ou descarrega o ficheiro) e guarda.</li>
              </ol>
              <Code label="HTML da página" value={s.custom_page} rows={12} />
              <a href="/jellyfin/conta.html" download="conta.html" className="inline-flex items-center gap-1 text-sm text-brand-text hover:underline">
                Descarregar conta.html
              </a>
            </CardBody>
          </Card>

          <Card>
            <CardHeader icon={<LogIn className="size-5" />} title="4. Botão “Entrar com a conta TK” (opcional)" description="Para o plugin 9p4 SSO. Com o Jellyfin Security o botão já aparece sozinho." />
            <CardBody className="grid gap-4 lg:grid-cols-2">
              <Code label="Branding → Login disclaimer" value={s.sso_button_html} rows={6} />
              <Code label="Branding → Custom CSS" value={s.sso_css} rows={6} />
              <div className="flex flex-wrap gap-4 lg:col-span-2">
                <Ext href={s.links.branding}>Abrir Branding</Ext>
                <ButtonLink to="/admin/sso" size="sm" variant="ghost" icon={<PlaySquare className="size-4" />}>
                  Clientes SSO
                </ButtonLink>
              </div>
            </CardBody>
          </Card>

          <NativeApps />
        </div>
      )}
    </div>
  )
}
