import { useEffect, useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { keepPreviousData, useQuery } from '@tanstack/react-query'
import { ScrollText, Search } from 'lucide-react'
import { api, errorMessage, qs } from '../../api/client'
import type { AuditRow } from '../../api/types'
import { Alert, Card, DateText, EmptyState, Input, PageHeader, Pagination, Select, SkeletonRows, Table, THead, Th, Tr, Td } from '../../components/ui'
import { AUDIT_PREFIXES, actionLabel } from '../../i18n/labels'

export default function AdminAudit() {
  const [params, setParams] = useSearchParams()
  const action = params.get('action') ?? ''
  const q = params.get('q') ?? ''
  const page = Math.max(1, Number(params.get('page') ?? 1) || 1)
  const [search, setSearch] = useState(q)

  const update = (next: Record<string, string | number>) => {
    const p = new URLSearchParams(params)
    for (const [k, v] of Object.entries(next)) {
      if (v === '' || v === 1) p.delete(k)
      else p.set(k, String(v))
    }
    setParams(p, { replace: true })
  }

  useEffect(() => {
    const t = window.setTimeout(() => {
      if (search.trim() !== q) update({ q: search.trim(), page: 1 })
    }, 400)
    return () => window.clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search])

  const rows = useQuery({
    queryKey: ['admin', 'audit', { action, q, page }],
    queryFn: () => api.get<AuditRow[]>(`/api/admin/audit${qs({ action, q, page })}`),
    placeholderData: keepPreviousData,
  })

  return (
    <div>
      <PageHeader eyebrow="Administração" title="Auditoria" description="Registo de todas as ações sensíveis: logins, alterações de conta, pagamentos e administração." />
      <div className="mb-4 flex flex-col gap-3 sm:flex-row">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-subtle" aria-hidden />
          <Input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Filtrar por autor ou ID do alvo…"
            aria-label="Filtrar por autor ou ID do alvo"
            className="pl-10"
          />
        </div>
        <div className="sm:w-64">
          <Select aria-label="Tipo de ação" value={action} onChange={(e) => update({ action: e.target.value, page: 1 })}>
            {AUDIT_PREFIXES.map((a) => (
              <option key={a.value} value={a.value}>
                {a.label}
              </option>
            ))}
          </Select>
        </div>
      </div>
      <Card className="overflow-hidden">
        {rows.isPending ? (
          <SkeletonRows rows={8} />
        ) : rows.isError ? (
          <div className="p-5">
            <Alert tone="danger">{errorMessage(rows.error)}</Alert>
          </div>
        ) : !rows.data.length ? (
          <EmptyState icon={<ScrollText className="size-6" />} title="Sem registos" description="Nenhuma ação corresponde aos filtros." />
        ) : (
          <div className={rows.isFetching ? 'opacity-70' : undefined}>
            <Table minWidth={820}>
              <THead>
                <Th>Data</Th>
                <Th>Ação</Th>
                <Th>Autor</Th>
                <Th>Alvo</Th>
                <Th>Detalhes</Th>
              </THead>
              <tbody>
                {rows.data.map((a) => (
                  <Tr key={a.id}>
                    <Td className="whitespace-nowrap text-muted">
                      <DateText value={a.created_at} withTime />
                    </Td>
                    <Td>
                      <p className={a.action.includes('failed') || a.action.includes('denied') ? 'font-medium text-danger' : 'font-medium'}>{actionLabel(a.action)}</p>
                      <p className="font-mono text-[11px] text-subtle">{a.action}</p>
                    </Td>
                    <Td>
                      {a.actor ?? <span className="text-subtle">sistema</span>}
                      {a.ip && <span className="block font-mono text-[11px] text-subtle">{a.ip}</span>}
                    </Td>
                    <Td className="max-w-[12rem]">
                      {a.target_type === 'user' && a.target_id ? (
                        <Link to={`/admin/utilizadores/${a.target_id}`} className="link text-xs">
                          utilizador
                        </Link>
                      ) : (
                        <span className="text-xs text-muted">{a.target_type ?? '—'}</span>
                      )}
                      {a.target_id && (
                        <span className="block truncate font-mono text-[11px] text-subtle" title={a.target_id}>
                          {a.target_id}
                        </span>
                      )}
                    </Td>
                    <Td className="max-w-[18rem]">
                      {a.details && Object.keys(a.details).length ? (
                        <p className="truncate font-mono text-xs text-muted" title={JSON.stringify(a.details)}>
                          {JSON.stringify(a.details)}
                        </p>
                      ) : (
                        <span className="text-subtle">—</span>
                      )}
                    </Td>
                  </Tr>
                ))}
              </tbody>
            </Table>
            <Pagination page={page} size={100} hasNext={rows.data.length === 100} onPage={(p) => update({ page: p })} />
          </div>
        )}
      </Card>
    </div>
  )
}
