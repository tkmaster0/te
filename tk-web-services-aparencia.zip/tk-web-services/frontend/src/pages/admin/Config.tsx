import { useSearchParams } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import clsx from 'clsx'
import { Rocket } from 'lucide-react'
import { api, errorMessage } from '../../api/client'
import type { ConfigOut, SetupStatus } from '../../api/types'
import { CONFIG_KEY, ConfigSectionForm } from '../../components/admin/ConfigSection'
import { Alert, ButtonLink, Card, CardBody, CardHeader, PageHeader, SkeletonCard, Tabs } from '../../components/ui'
import AdminSettings from './Settings'

/** Admin → Definições: tudo o que é configurável por web (instalação + conteúdo do site). */
export default function AdminConfig() {
  const [params, setParams] = useSearchParams()
  const tab = params.get('tab') === 'site' ? 'site' : 'instalacao'
  const cfg = useQuery({ queryKey: CONFIG_KEY, queryFn: () => api.get<ConfigOut>('/api/admin/config') })
  const setup = useQuery({ queryKey: ['admin', 'setup'], queryFn: () => api.get<SetupStatus>('/api/admin/setup') })
  const sections = cfg.data?.sections ?? []
  const current = sections.find((s) => s.id === params.get('s')) ?? sections[0]
  const go = (p: Record<string, string>) => setParams({ ...Object.fromEntries(params), ...p }, { replace: true })

  return (
    <div>
      <PageHeader
        eyebrow="Administração"
        title="Definições"
        description="Endereços, chaves, pagamentos, túnel e integrações — tudo por web, aplicado na hora (sem reiniciar)."
        actions={
          <ButtonLink to="/admin/configurar" variant="secondary" icon={<Rocket className="size-4" />}>
            Assistente de configuração
          </ButtonLink>
        }
      />
      <Tabs
        className="mb-6"
        ariaLabel="Definições"
        value={tab}
        onChange={(id) => go({ tab: id })}
        items={[
          { id: 'instalacao', label: 'Instalação e integrações' },
          { id: 'site', label: 'Conteúdo do site' },
        ]}
      />
      {tab === 'site' ? (
        <AdminSettings embedded />
      ) : cfg.isError ? (
        <Alert tone="danger">{errorMessage(cfg.error)}</Alert>
      ) : !cfg.data || !current ? (
        <SkeletonCard lines={8} />
      ) : (
        <div className="grid gap-6 lg:grid-cols-[230px_1fr]">
          <nav aria-label="Secções" className="lg:sticky lg:top-20 lg:self-start">
            <ul className="flex gap-1.5 overflow-x-auto pb-2 lg:flex-col lg:overflow-visible">
              {sections.map((s) => (
                <li key={s.id} className="shrink-0">
                  <button
                    type="button"
                    onClick={() => go({ s: s.id })}
                    className={clsx(
                      'w-full rounded-xl px-3 py-2 text-left text-sm transition-colors',
                      s.id === current.id ? 'bg-brand-soft font-semibold text-brand-text' : 'text-muted hover:bg-hover hover:text-fg',
                    )}
                    aria-current={s.id === current.id ? 'page' : undefined}
                  >
                    {s.title}
                  </button>
                </li>
              ))}
            </ul>
          </nav>
          <Card>
            <CardHeader title={current.title} description={current.description} />
            <CardBody>
              <ConfigSectionForm key={current.id} section={current} tunnel={cfg.data.tunnel} publicUrl={setup.data?.public_url} />
            </CardBody>
          </Card>
        </div>
      )}
    </div>
  )
}
