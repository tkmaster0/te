import { useRef, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { ArrowRightLeft, CalendarClock, Clapperboard, Euro, KeyRound, MessageSquarePlus, Package, Pencil, Plus, Radio, Tags, Trash2, Upload } from 'lucide-react'
import { api, errorMessage } from '../../api/client'
import { useAction } from '../../api/mutation'
import { useAdminProducts } from '../../api/admin'
import type { AdminPlan, AdminProduct, JellyfinLibrary, Ok, PlanFeatures } from '../../api/types'
import { ProductIcon, productIcon } from '../../components/billing/ProductIcon'
import { MigrateDialog } from '../../components/admin/MigrateDialog'
import { FULFILLMENT_TYPE } from '../../i18n/labels'
import {
  Alert,
  Badge,
  Button,
  Card,
  Checkbox,
  EmptyState,
  Field,
  Input,
  Menu,
  Modal,
  PageHeader,
  PasswordInput,
  Select,
  SkeletonCard,
  StringListEditor,
  Switch,
  Table,
  THead,
  Th,
  Tr,
  Td,
  Textarea,
  useConfirm,
} from '../../components/ui'
import { formatDate, formatMoney, perInterval } from '../../lib/format'
import { keys } from '../../api/keys'

const INVALIDATE = [['admin', 'products'], keys.catalog, keys.products]

const EMPTY_FEATURES: PlanFeatures = {
  jellyfin: { enabled: false, all_libraries: true, libraries: [], max_streams: 0, live_tv: false, downloads: true, remote_bitrate_mbps: 0 },
  seerr: { enabled: false, movie_quota: null, movie_quota_days: null, tv_quota: null, tv_quota_days: null },
  iptv: { enabled: false, stream_limit: 1, channel_profiles: [] },
  groups: [],
}

function intOrNull(v: string): number | null {
  if (v.trim() === '') return null
  const n = Number.parseInt(v, 10)
  return Number.isFinite(n) && n >= 0 ? n : null
}
function intOrZero(v: string): number {
  return intOrNull(v) ?? 0
}
function parseEuros(v: string): number | null {
  const s = v.replace(/\s|€/g, '').replace(',', '.')
  if (!s) return null
  const n = Number(s)
  if (!Number.isFinite(n) || n < 0) return null
  return Math.round(n * 100)
}

// ------------------------------------------------------------------ Produto
const ICON_OPTIONS = ['bot', 'sparkles', 'cloud', 'server', 'globe', 'shield', 'tv', 'film', 'radio', 'music', 'gamepad', 'wifi', 'key', 'book', 'mail', 'package']

/** Ligar a app de um serviço ao SSO: cliente OIDC com o código do produto, só para quem o tem ativo. */
function ProductSso({ product }: { product: AdminProduct }) {
  const [open, setOpen] = useState(false)
  const [uris, setUris] = useState<string[]>([])
  const [out, setOut] = useState<{ client_id: string; client_secret: string | null; discovery: string; issuer: string } | null>(null)
  const go = useAction(
    (rotate: boolean) => api.post<{ client_id: string; client_secret: string | null; discovery: string; issuer: string }>(`/api/admin/products/${product.id}/sso`, { redirect_uris: uris, rotate }),
    { success: 'Cliente SSO pronto.', errorTitle: 'Não foi possível ligar ao SSO', onSuccess: setOut },
  )
  if (!open)
    return (
      <div className="sm:col-span-2">
        <Button type="button" size="sm" variant="secondary" icon={<KeyRound className="size-4" />} onClick={() => setOpen(true)}>
          Ligar a app ao SSO (login com a conta TKWS)
        </Button>
      </div>
    )
  return (
    <div className="space-y-3 rounded-xl border border-border p-4 sm:col-span-2">
      <p className="text-sm font-semibold">SSO da app “{product.name}”</p>
      <p className="text-xs text-muted">
        Cria (ou atualiza) o cliente OIDC <code>{product.code}</code>: só quem tem este serviço ativo consegue entrar na app. Indica o(s) redirect URI(s) da app.
      </p>
      <StringListEditor value={uris} onChange={setUris} placeholder="https://app.exemplo.pt/oauth/callback" />
      <div className="flex flex-wrap gap-2">
        <Button type="button" size="sm" disabled={!uris.length} loading={go.isPending && go.variables === false} onClick={() => go.mutate(false)}>
          Guardar
        </Button>
        <Button type="button" size="sm" variant="ghost" disabled={!uris.length} loading={go.isPending && go.variables === true} onClick={() => go.mutate(true)}>
          Gerar segredo novo
        </Button>
      </div>
      {out && (
        <div className="space-y-1 rounded-lg bg-elevated p-3 text-xs">
          <p>
            Issuer / discovery: <code className="break-all">{out.discovery}</code>
          </p>
          <p>
            Client ID: <code>{out.client_id}</code>
          </p>
          {out.client_secret ? (
            <p className="break-all">
              Client secret: <code>{out.client_secret}</code> <span className="text-warning">(só aparece agora — copia-o)</span>
            </p>
          ) : (
            <p className="text-muted">O segredo atual mantém-se (usa “Gerar segredo novo” se o perdeste).</p>
          )}
        </div>
      )}
    </div>
  )
}

/** Imagem do produto (substitui o ícone na loja, nos serviços e na página inicial). */
function ProductImage({ product: initial }: { product: AdminProduct }) {
  // Lê o produto da lista (atualizada depois do upload) — o do modal é uma cópia de quando abriu.
  const products = useAdminProducts()
  const product = products.data?.find((p) => p.id === initial.id) ?? initial
  const input = useRef<HTMLInputElement>(null)
  const inv = [['admin', 'products'], keys.catalog, keys.products]
  const upload = useAction(
    (file: File) => {
      const fd = new FormData()
      fd.append('file', file)
      return api.upload(`/api/admin/appearance/products/${product.id}/image`, fd, 'PUT')
    },
    { invalidate: inv, success: 'Imagem do produto atualizada.' },
  )
  const remove = useAction(() => api.del(`/api/admin/appearance/products/${product.id}/image`), { invalidate: inv })
  return (
    <Field label="Imagem" optional hint="Substitui o ícone (quadrada, PNG/JPG/WebP/SVG até 2 MB)." className="sm:col-span-2">
      <div className="flex flex-wrap items-center gap-3">
        <ProductIcon icon={product.icon} fulfillment={product.fulfillment} image={product.image_url} size="lg" />
        <input
          ref={input}
          type="file"
          accept="image/png,image/jpeg,image/webp,image/gif,image/svg+xml"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0]
            e.target.value = ''
            if (f) upload.mutate(f)
          }}
        />
        <Button size="sm" variant="secondary" icon={<Upload className="size-4" />} loading={upload.isPending} onClick={() => input.current?.click()}>
          {product.image_url ? 'Trocar imagem' : 'Carregar imagem'}
        </Button>
        {product.image_url && (
          <Button size="sm" variant="ghost" icon={<Trash2 className="size-4" />} loading={remove.isPending} onClick={() => remove.mutate()}>
            Usar o ícone
          </Button>
        )}
      </div>
    </Field>
  )
}

function ProductModal({ product, open, onClose }: { product: AdminProduct | null; open: boolean; onClose: () => void }) {
  const isNew = !product
  const [form, setForm] = useState(() => ({
    code: product?.code ?? '',
    name: product?.name ?? '',
    description: product?.description ?? '',
    kind: product?.kind ?? 'streaming',
    fulfillment: (product?.fulfillment as string) ?? 'manual',
    webhook_url: product?.webhook_url ?? '',
    access_instructions: product?.access_instructions ?? '',
    app_url: product?.app_url ?? '',
    icon: product?.icon ?? '',
    bonus_eligible: product?.bonus_eligible ?? false,
    jellyfin_managed: product?.jellyfin_managed ?? false,
    requires_invite: product?.requires_invite ?? false,
    locked_name: product?.locked_name ?? '',
    locked_description: product?.locked_description ?? '',
    is_active: product?.is_active ?? true,
    sort_order: String(product?.sort_order ?? 0),
  }))
  const [secret, setSecret] = useState('')
  const [clearSecret, setClearSecret] = useState(false)
  const save = useAction(
    () => {
      const body = {
        ...form,
        description: form.description.trim() || null,
        webhook_url: form.fulfillment === 'webhook' ? form.webhook_url.trim() || null : form.webhook_url.trim() || null,
        // null = manter o segredo; '' = apagar; texto = substituir
        webhook_secret: clearSecret ? '' : secret ? secret : null,
        access_instructions: form.access_instructions.trim() || null,
        app_url: form.app_url.trim() || null,
        icon: form.icon.trim() || null,
        sort_order: Number(form.sort_order) || 0,
        locked_name: form.locked_name.trim() || null,
        locked_description: form.locked_description.trim() || null,
      }
      return isNew ? api.post('/api/admin/products', body) : api.put(`/api/admin/products/${product!.id}`, body)
    },
    { invalidate: INVALIDATE, success: isNew ? 'Produto criado.' : 'Produto guardado.', errorTitle: 'Não foi possível guardar', onSuccess: onClose },
  )
  const set = <K extends keyof typeof form>(k: K, v: (typeof form)[K]) => setForm((f) => ({ ...f, [k]: v }))
  const webhookInvalid = form.fulfillment === 'webhook' && !/^https?:\/\//.test(form.webhook_url.trim())
  const IconPreview = productIcon(form.icon, form.fulfillment)
  return (
    <Modal
      open={open}
      onClose={onClose}
      size="lg"
      title={isNew ? 'Novo produto' : `Editar ${product?.name}`}
      description="Um produto agrupa planos (ex.: streaming, cloud, VPN) e define como o acesso é entregue."
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancelar
          </Button>
          <Button loading={save.isPending} disabled={!form.code || !form.name || webhookInvalid} onClick={() => save.mutate()}>
            Guardar
          </Button>
        </>
      }
    >
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Field label="Nome">
          <Input value={form.name} onChange={(e) => set('name', e.target.value)} maxLength={120} />
        </Field>
        <Field label="Código" hint="Minúsculas, números, “-” ou “_”.">
          <Input value={form.code} onChange={(e) => set('code', e.target.value.toLowerCase().replace(/[^a-z0-9_-]/g, ''))} maxLength={48} className="font-mono" />
        </Field>
        <Field label="Descrição" optional className="sm:col-span-2">
          <Textarea value={form.description} onChange={(e) => set('description', e.target.value)} rows={2} />
        </Field>

        <fieldset className="sm:col-span-2">
          <legend className="mb-2 text-sm font-medium">Como é entregue</legend>
          <div className="grid gap-2 sm:grid-cols-2">
            {Object.entries(FULFILLMENT_TYPE).map(([value, info]) => (
              <label
                key={value}
                className={`flex cursor-pointer items-start gap-3 rounded-xl border p-3.5 transition-colors ${form.fulfillment === value ? 'border-brand bg-brand-soft' : 'border-border hover:border-border-strong'}`}
              >
                <input type="radio" name="fulfillment" checked={form.fulfillment === value} onChange={() => set('fulfillment', value)} className="mt-1 size-4 accent-[var(--c-brand)]" />
                <span className="min-w-0">
                  <span className="block text-sm font-semibold">{info.label}</span>
                  <span className="mt-0.5 block text-xs text-muted">{info.description}</span>
                </span>
              </label>
            ))}
          </div>
        </fieldset>

        {form.fulfillment === 'webhook' && (
          <>
            <Field label="URL do webhook" error={form.webhook_url && webhookInvalid ? 'Tem de começar por http:// ou https://' : undefined} className="sm:col-span-2">
              <Input value={form.webhook_url} onChange={(e) => set('webhook_url', e.target.value)} placeholder="https://vpn.exemplo.pt/tkportal" className="font-mono text-[13px]" inputMode="url" />
            </Field>
            <Field
              label="Segredo de assinatura"
              optional
              className="sm:col-span-2"
              hint={product?.has_webhook_secret ? 'Já está definido. Deixa vazio para manter; escreve um novo para substituir.' : 'Usado para assinar os pedidos (HMAC). Só de escrita — nunca é mostrado.'}
            >
              <PasswordInput value={secret} onChange={(e) => setSecret(e.target.value)} disabled={clearSecret} autoComplete="new-password" placeholder={product?.has_webhook_secret ? '•••••••• (definido)' : ''} />
            </Field>
            {product?.has_webhook_secret && (
              <Checkbox className="sm:col-span-2" checked={clearSecret} onChange={(e) => setClearSecret(e.target.checked)} label="Apagar o segredo atual" description="Os pedidos deixam de ser assinados." />
            )}
          </>
        )}

        <Field
          label="Endereço da app"
          optional
          hint="Botão “Abrir” em “Os meus serviços” para quem tem o serviço ativo (ex.: o LibreChat do TKGPT)."
          error={form.app_url.trim() && !/^https?:\/\//.test(form.app_url.trim()) ? 'Tem de começar por https://' : undefined}
          className="sm:col-span-2"
        >
          <Input value={form.app_url} onChange={(e) => set('app_url', e.target.value)} placeholder="https://chat.exemplo.pt" inputMode="url" className="font-mono text-[13px]" />
        </Field>
        {!isNew && <ProductSso product={product!} />}

        {(form.fulfillment === 'manual' || form.fulfillment === 'webhook' || form.fulfillment === 'none') && (
          <Field label="Instruções para o cliente" optional hint="Aparecem junto ao serviço em “Os meus serviços”." className="sm:col-span-2">
            <Textarea value={form.access_instructions} onChange={(e) => set('access_instructions', e.target.value)} rows={3} maxLength={5000} placeholder="ex.: Instala a app X e entra com os dados abaixo." />
          </Field>
        )}

        <Field label="Ícone" optional hint="Nome de um ícone (tv, cloud, shield…).">
          <div className="flex items-center gap-2">
            <span className="grid size-11 shrink-0 place-items-center rounded-xl bg-brand-soft text-brand-text">
              <IconPreview className="size-5" aria-hidden />
            </span>
            <Input value={form.icon} onChange={(e) => set('icon', e.target.value.toLowerCase().trim())} list="product-icons" maxLength={32} placeholder="tv" />
          </div>
        </Field>
        {!isNew && <ProductImage product={product!} />}
        <datalist id="product-icons">
          {ICON_OPTIONS.map((i) => (
            <option key={i} value={i} />
          ))}
        </datalist>
        <Field label="Tipo (categoria livre)">
          <Input value={form.kind} onChange={(e) => set('kind', e.target.value)} list="product-kinds" />
        </Field>
        <datalist id="product-kinds">
          <option value="streaming" />
          <option value="armazenamento" />
          <option value="vpn" />
          <option value="outro" />
        </datalist>
        <Field label="Ordem">
          <Input type="number" value={form.sort_order} onChange={(e) => set('sort_order', e.target.value)} />
        </Field>
        <div className="space-y-4 sm:col-span-2">
          <Switch checked={form.jellyfin_managed} onChange={(v) => set('jellyfin_managed', v)} label="É o produto de streaming (Jellyfin)" description="Pode ser gerido a partir do Jellyfin (sessões limitadas) e usa os direitos Jellyfin/Seerr/IPTV dos planos." />
          <Switch checked={form.bonus_eligible} onChange={(v) => set('bonus_eligible', v)} label="Coberto pelo bónus de convites" description="Com convidados suficientes a pagar, este produto deixa de ser cobrado." />
          <Switch checked={form.is_active} onChange={(v) => set('is_active', v)} label="Ativo" description="Produtos inativos não aparecem na loja." />
          <Switch
            checked={form.requires_invite}
            onChange={(v) => set('requires_invite', v)}
            label="Beta fechado (só com convite)"
            description="Quem não tem convite vê um nome genérico, desativado, com um campo para meter o código. Os convites de clientes que já o têm desbloqueiam-no."
          />
          {form.requires_invite && (
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Nome sem convite" hint="Ex.: TK CDN">
                <Input value={form.locked_name} onChange={(e) => set('locked_name', e.target.value)} maxLength={120} placeholder="TK CDN" />
              </Field>
              <Field label="Descrição sem convite">
                <Input value={form.locked_description} onChange={(e) => set('locked_description', e.target.value)} maxLength={255} placeholder="Beta testing fechado" />
              </Field>
            </div>
          )}
        </div>
      </div>
    </Modal>
  )
}

// ------------------------------------------------------------------ Direitos (features)
function NumberField({ label, value, onChange, hint, placeholder }: { label: string; value: string; onChange: (v: string) => void; hint?: string; placeholder?: string }) {
  return (
    <Field label={label} hint={hint}>
      <Input type="number" min={0} inputMode="numeric" value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} />
    </Field>
  )
}

function FeatureBlock({ icon, title, enabled, onToggle, children }: { icon: React.ReactNode; title: string; enabled: boolean; onToggle: (v: boolean) => void; children: React.ReactNode }) {
  return (
    <div className={`rounded-xl border ${enabled ? 'border-border-strong' : 'border-border'} p-4`}>
      <div className="flex items-center gap-3">
        <span className={`grid size-9 place-items-center rounded-lg ${enabled ? 'bg-brand-soft text-brand-text' : 'bg-elevated text-subtle'}`}>{icon}</span>
        <Switch className="flex-1" checked={enabled} onChange={onToggle} label={title} />
      </div>
      {enabled && <div className="mt-4 space-y-4 border-t border-border pt-4">{children}</div>}
    </div>
  )
}

function LibraryPicker({ value, onChange }: { value: string[]; onChange: (v: string[]) => void }) {
  const libs = useQuery({
    queryKey: ['admin', 'jellyfin-libraries'],
    queryFn: () => api.get<JellyfinLibrary[]>('/api/admin/jellyfin/libraries'),
    retry: false,
    staleTime: 5 * 60_000,
  })
  if (libs.isPending) return <p className="text-sm text-muted">A carregar bibliotecas do Jellyfin…</p>
  if (libs.isError || !libs.data?.length)
    return (
      <div className="space-y-2">
        <Alert tone="warning">
          {libs.isError ? `Não foi possível obter as bibliotecas (${errorMessage(libs.error)}).` : 'O Jellyfin não devolveu bibliotecas.'} Introduz os IDs
          manualmente.
        </Alert>
        <StringListEditor value={value} onChange={onChange} placeholder="ID da biblioteca" ariaLabel="IDs de bibliotecas" />
      </div>
    )
  const known = new Set(libs.data.map((l) => l.id))
  const unknown = value.filter((v) => !known.has(v))
  return (
    <div className="space-y-2">
      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
        {libs.data.map((l) => (
          <Checkbox
            key={l.id}
            checked={value.includes(l.id)}
            onChange={(e) => onChange(e.target.checked ? [...value, l.id] : value.filter((x) => x !== l.id))}
            label={l.name}
            description={l.type ?? undefined}
          />
        ))}
      </div>
      {unknown.length > 0 && <p className="text-xs text-warning">IDs desconhecidos mantidos: {unknown.join(', ')}</p>}
    </div>
  )
}

function FeaturesEditor({ value, onChange }: { value: PlanFeatures; onChange: (f: PlanFeatures) => void }) {
  const jf = value.jellyfin
  const se = value.seerr
  const ip = value.iptv
  const setJf = (p: Partial<PlanFeatures['jellyfin']>) => onChange({ ...value, jellyfin: { ...jf, ...p } })
  const setSe = (p: Partial<PlanFeatures['seerr']>) => onChange({ ...value, seerr: { ...se, ...p } })
  const setIp = (p: Partial<PlanFeatures['iptv']>) => onChange({ ...value, iptv: { ...ip, ...p } })
  const str = (n: number | null) => (n === null || n === undefined ? '' : String(n))

  return (
    <div className="space-y-3">
      <FeatureBlock icon={<Clapperboard className="size-4" />} title="Jellyfin" enabled={jf.enabled} onToggle={(v) => setJf({ enabled: v })}>
        <Switch checked={jf.all_libraries} onChange={(v) => setJf({ all_libraries: v })} label="Todas as bibliotecas" />
        {!jf.all_libraries && <LibraryPicker value={jf.libraries} onChange={(v) => setJf({ libraries: v })} />}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <NumberField label="Ecrãs em simultâneo" hint="0 = ilimitado" value={String(jf.max_streams)} onChange={(v) => setJf({ max_streams: intOrZero(v) })} />
          <NumberField label="Bitrate remoto máximo (Mbps)" hint="0 = sem limite" value={String(jf.remote_bitrate_mbps)} onChange={(v) => setJf({ remote_bitrate_mbps: intOrZero(v) })} />
        </div>
        <Switch checked={jf.live_tv} onChange={(v) => setJf({ live_tv: v })} label="TV em direto" />
        <Switch checked={jf.downloads} onChange={(v) => setJf({ downloads: v })} label="Permitir downloads" />
      </FeatureBlock>

      <FeatureBlock icon={<MessageSquarePlus className="size-4" />} title="Seerr (pedidos)" enabled={se.enabled} onToggle={(v) => setSe({ enabled: v })}>
        <p className="text-xs text-muted">Deixa vazio para usar o limite global configurado no Seerr.</p>
        <div className="grid grid-cols-2 gap-4">
          <NumberField label="Filmes" placeholder="global" value={str(se.movie_quota)} onChange={(v) => setSe({ movie_quota: intOrNull(v) })} />
          <NumberField label="… a cada (dias)" placeholder="global" value={str(se.movie_quota_days)} onChange={(v) => setSe({ movie_quota_days: intOrNull(v) })} />
          <NumberField label="Temporadas" placeholder="global" value={str(se.tv_quota)} onChange={(v) => setSe({ tv_quota: intOrNull(v) })} />
          <NumberField label="… a cada (dias)" placeholder="global" value={str(se.tv_quota_days)} onChange={(v) => setSe({ tv_quota_days: intOrNull(v) })} />
        </div>
      </FeatureBlock>

      <FeatureBlock icon={<Radio className="size-4" />} title="IPTV (Dispatcharr)" enabled={ip.enabled} onToggle={(v) => setIp({ enabled: v })}>
        <NumberField label="Ligações simultâneas" hint="0 = ilimitado" value={String(ip.stream_limit)} onChange={(v) => setIp({ stream_limit: intOrZero(v) })} />
        <Field label="Channel profiles (IDs)" hint="IDs dos perfis de canais no Dispatcharr. Vazio = todos.">
          <div>
            <StringListEditor
              value={ip.channel_profiles.map(String)}
              onChange={(v) => setIp({ channel_profiles: v.map((x) => Number.parseInt(x, 10)).filter((n) => Number.isFinite(n)) })}
              placeholder="ex.: 3"
              inputType="number"
              ariaLabel="Channel profiles"
            />
          </div>
        </Field>
      </FeatureBlock>

      <div className="rounded-xl border border-border p-4">
        <div className="mb-3 flex items-center gap-3">
          <span className="grid size-9 place-items-center rounded-lg bg-elevated text-subtle">
            <Tags className="size-4" />
          </span>
          <div>
            <p className="text-sm font-medium">Grupos extra</p>
            <p className="text-xs text-muted">Expostos via OIDC e forward-auth (ex.: para dar acesso a outras apps).</p>
          </div>
        </div>
        <StringListEditor value={value.groups} onChange={(g) => onChange({ ...value, groups: g })} placeholder="ex.: tkflix-vip" ariaLabel="Grupos" />
      </div>
    </div>
  )
}

// ------------------------------------------------------------------ Plano
function PlanModal({
  plan,
  productId,
  products,
  open,
  onClose,
  onPriceChange,
}: {
  plan: AdminPlan | null
  productId: number
  products: AdminProduct[]
  open: boolean
  onClose: () => void
  onPriceChange: (plan: AdminPlan) => void
}) {
  const isNew = !plan
  // Com subscritores, o preço muda-se no diálogo "Alterar preço" (decide quem é afetado e quando).
  const locked = !!plan && plan.active_subscriptions > 0
  const [form, setForm] = useState(() => ({
    product_id: plan?.product_id ?? productId,
    code: plan?.code ?? '',
    name: plan?.name ?? '',
    description: plan?.description ?? '',
    price: plan ? (plan.price_cents / 100).toFixed(2).replace('.', ',') : '',
    currency: plan?.currency ?? 'EUR',
    interval_unit: plan?.interval_unit ?? 'month',
    interval_count: String(plan?.interval_count ?? 1),
    highlights: plan?.highlights ?? [],
    is_active: plan?.is_active ?? true,
    is_public: plan?.is_public ?? true,
    sort_order: String(plan?.sort_order ?? 0),
    features: plan?.features ?? EMPTY_FEATURES,
  }))
  const [resultMsg, setResultMsg] = useState<string | null>(null)
  const set = <K extends keyof typeof form>(k: K, v: (typeof form)[K]) => setForm((f) => ({ ...f, [k]: v }))
  const cents = parseEuros(form.price)
  const selectedProduct = products.find((p) => p.id === form.product_id)
  const streamingProduct = !!selectedProduct && (selectedProduct.jellyfin_managed || selectedProduct.fulfillment === 'streaming')

  const save = useAction(
    () => {
      const body = {
        product_id: form.product_id,
        code: form.code,
        name: form.name.trim(),
        description: form.description.trim() || null,
        price_cents: cents ?? 0,
        currency: form.currency.toUpperCase(),
        interval_unit: form.interval_unit,
        interval_count: Number(form.interval_count) || 1,
        features: form.features,
        highlights: form.highlights.map((h) => h.trim()).filter(Boolean),
        is_active: form.is_active,
        is_public: form.is_public,
        sort_order: Number(form.sort_order) || 0,
      }
      return isNew
        ? api.post<{ id?: number; message?: string }>('/api/admin/plans', body)
        : api.put<{ id?: number; message?: string }>(`/api/admin/plans/${plan!.id}`, body)
    },
    {
      invalidate: INVALIDATE,
      success: isNew ? 'Plano criado.' : false,
      errorTitle: 'Não foi possível guardar o plano',
      onSuccess: (res) => {
        const msg = (res as { message?: string }).message
        if (!isNew && msg) setResultMsg(msg)
        else onClose()
      },
    },
  )

  const valid = form.code.length >= 2 && form.name.trim() && cents !== null

  return (
    <>
      <Modal
        open={open && !resultMsg}
        onClose={onClose}
        size="xl"
        title={isNew ? 'Novo plano' : `Editar ${plan?.name}`}
        description={plan ? `${plan.active_subscriptions} subscrições ativas neste plano.` : undefined}
        footer={
          <>
            <Button variant="secondary" onClick={onClose}>
              Cancelar
            </Button>
            <Button loading={save.isPending} disabled={!valid} onClick={() => save.mutate()}>
              Guardar plano
            </Button>
          </>
        }
      >
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <div className="space-y-4">
            <h3 className="text-sm font-semibold uppercase tracking-wider text-subtle">Geral</h3>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <Field label="Nome">
                <Input value={form.name} onChange={(e) => set('name', e.target.value)} maxLength={120} />
              </Field>
              <Field label="Código" hint={isNew ? 'Único. Minúsculas, números, “-”.' : undefined}>
                <Input value={form.code} onChange={(e) => set('code', e.target.value.toLowerCase().replace(/[^a-z0-9_-]/g, ''))} maxLength={48} className="font-mono" />
              </Field>
              <Field label="Produto" className="sm:col-span-2">
                <Select value={form.product_id} onChange={(e) => set('product_id', Number(e.target.value))}>
                  {products.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name}
                    </option>
                  ))}
                </Select>
              </Field>
              <Field label="Descrição" optional className="sm:col-span-2">
                <Textarea value={form.description} onChange={(e) => set('description', e.target.value)} rows={2} />
              </Field>
            </div>

            <h3 className="pt-2 text-sm font-semibold uppercase tracking-wider text-subtle">Preço</h3>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
              <Field label="Valor (€)" error={form.price && cents === null ? 'Valor inválido' : undefined} className="col-span-2 sm:col-span-1">
                <Input value={form.price} onChange={(e) => set('price', e.target.value)} inputMode="decimal" placeholder="5,00" disabled={locked} />
              </Field>
              <Field label="Moeda">
                <Input value={form.currency} onChange={(e) => set('currency', e.target.value.toUpperCase().slice(0, 3))} maxLength={3} disabled={locked} />
              </Field>
              <Field label="A cada">
                <Input type="number" min={1} max={12} value={form.interval_count} onChange={(e) => set('interval_count', e.target.value)} disabled={locked} />
              </Field>
              <Field label="Período">
                <Select value={form.interval_unit} onChange={(e) => set('interval_unit', e.target.value)} disabled={locked}>
                  <option value="month">mês</option>
                  <option value="year">ano</option>
                  <option value="week">semana</option>
                </Select>
              </Field>
            </div>
            {locked ? (
              <div className="-mt-1 flex flex-col gap-2 rounded-xl border border-border bg-elevated/60 p-3 text-xs text-muted sm:flex-row sm:items-center">
                <span className="flex-1">
                  Este plano tem {plan!.active_subscriptions} subscritores: o preço muda-se em “Alterar preço” (escolhes se afeta só novos clientes ou também os
                  atuais, com aviso). A periodicidade não pode mudar — cria um plano novo e usa “Migrar subscritores”.
                </span>
                <Button size="sm" variant="secondary" onClick={() => onPriceChange(plan!)} icon={<Euro className="size-4" />}>
                  Alterar preço
                </Button>
              </div>
            ) : (
              cents !== null && (
                <p className="-mt-2 text-xs text-muted">
                  Vai aparecer como{' '}
                  <strong className="text-fg">
                    {formatMoney(cents, form.currency)}
                    {perInterval(form.interval_unit, Number(form.interval_count) || 1)}
                  </strong>
                  .
                </p>
              )
            )}

            <h3 className="pt-2 text-sm font-semibold uppercase tracking-wider text-subtle">Visibilidade</h3>
            <Switch checked={form.is_active} onChange={(v) => set('is_active', v)} label="Ativo" description="Planos inativos não aceitam novas subscrições." />
            <Switch checked={form.is_public} onChange={(v) => set('is_public', v)} label="Público" description="Aparece no catálogo. Planos privados podem ser usados em ofertas." />
            <Field label="Ordem">
              <Input type="number" value={form.sort_order} onChange={(e) => set('sort_order', e.target.value)} />
            </Field>

            <h3 className="pt-2 text-sm font-semibold uppercase tracking-wider text-subtle">Destaques</h3>
            <StringListEditor value={form.highlights} onChange={(v) => set('highlights', v)} placeholder="ex.: Legendas PT e EN" ariaLabel="Destaques" />
          </div>
          <div className="space-y-4">
            <h3 className="text-sm font-semibold uppercase tracking-wider text-subtle">Direitos</h3>
            {streamingProduct ? (
              <FeaturesEditor value={form.features} onChange={(f) => set('features', f)} />
            ) : (
              <p className="rounded-xl border border-dashed border-border p-4 text-sm text-muted">
                Este produto não é o streaming, por isso não dá acesso ao Jellyfin/Seerr/IPTV. O acesso é entregue como definido no produto (
                {FULFILLMENT_TYPE[selectedProduct?.fulfillment ?? '']?.label ?? '—'}). Usa os destaques para descrever o plano.
              </p>
            )}
          </div>
        </div>
      </Modal>
      <Modal
        open={!!resultMsg}
        onClose={() => {
          setResultMsg(null)
          onClose()
        }}
        title="Plano guardado"
        size="sm"
        footer={
          <Button
            onClick={() => {
              setResultMsg(null)
              onClose()
            }}
          >
            OK
          </Button>
        }
      >
        <Alert tone={resultMsg?.includes('Atenção') ? 'warning' : 'success'}>{resultMsg}</Alert>
      </Modal>
    </>
  )
}

// ------------------------------------------------------------------ Alterar preço
function isoDay(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
}

function PriceChangeDialog({ plan, onClose }: { plan: AdminPlan; onClose: () => void }) {
  const minDate = new Date(Date.now() + 30 * 86400000)
  const [price, setPrice] = useState((plan.price_cents / 100).toFixed(2).replace('.', ','))
  const [applyTo, setApplyTo] = useState<'existing' | 'new_only'>('existing')
  const [date, setDate] = useState(isoDay(minDate))
  const [note, setNote] = useState('')
  const [result, setResult] = useState<string | null>(null)
  const cents = parseEuros(price)
  const per = perInterval(plan.interval_unit, plan.interval_count)
  const increase = cents !== null && cents > plan.price_cents
  const pct = cents !== null && plan.price_cents > 0 ? Math.round(((cents - plan.price_cents) / plan.price_cents) * 100) : null
  const tooSoon = applyTo === 'existing' && increase && date < isoDay(new Date(Date.now() + 30 * 86400000 - 3600000))
  const change = useAction(
    () =>
      api.post<Ok>(`/api/admin/plans/${plan.id}/price-change`, {
        new_price_cents: cents,
        apply_to: applyTo,
        effective_at: applyTo === 'existing' && date ? new Date(`${date}T00:00:00`).toISOString() : null,
        note: note.trim() || null,
      }),
    { invalidate: INVALIDATE, success: false, errorTitle: 'Não foi possível alterar o preço', onSuccess: (res) => setResult(res.message ?? 'Preço alterado.') },
  )
  const same = cents === plan.price_cents
  if (result)
    return (
      <Modal open onClose={onClose} title="Preço alterado" size="sm" footer={<Button onClick={onClose}>OK</Button>}>
        <Alert tone="success">{result}</Alert>
      </Modal>
    )
  return (
    <Modal
      open
      onClose={onClose}
      title={`Alterar preço — ${plan.name}`}
      description={`Preço atual: ${formatMoney(plan.price_cents, plan.currency)}${per} · ${plan.active_subscriptions} subscritores`}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancelar
          </Button>
          <Button loading={change.isPending} disabled={cents === null || (same && applyTo === 'new_only') || tooSoon} onClick={() => change.mutate()}>
            {applyTo === 'existing' ? 'Agendar e avisar clientes' : 'Mudar para novos clientes'}
          </Button>
        </>
      }
    >
      <div className="space-y-5">
        <Field label="Novo preço (€)" error={price && cents === null ? 'Valor inválido' : undefined}>
          <Input value={price} onChange={(e) => setPrice(e.target.value)} inputMode="decimal" autoFocus />
        </Field>
        {cents !== null && !same && (
          <p className="-mt-3 text-sm">
            {formatMoney(plan.price_cents, plan.currency)} → <strong>{formatMoney(cents, plan.currency)}</strong>
            {per}
            {pct !== null && <span className={increase ? 'text-warning' : 'text-success'}> ({pct > 0 ? '+' : ''}{pct}%)</span>}
          </p>
        )}
        <fieldset>
          <legend className="mb-2 text-sm font-medium">A quem se aplica?</legend>
          <div className="space-y-2">
            {(
              [
                [
                  'new_only',
                  'Só a novos clientes',
                  `Os ${plan.active_subscriptions} subscritores atuais mantêm o preço que pagam hoje, para sempre (até mudarem de plano). Não há emails.`,
                ],
                [
                  'existing',
                  'Também aos subscritores atuais',
                  'Recebem um email de aviso e passam ao novo preço na primeira renovação a partir da data escolhida. Aumentos exigem pelo menos 30 dias de aviso.',
                ],
              ] as const
            ).map(([v, t, d]) => (
              <label key={v} className={`flex cursor-pointer items-start gap-3 rounded-xl border p-3.5 ${applyTo === v ? 'border-brand bg-brand-soft' : 'border-border hover:border-border-strong'}`}>
                <input type="radio" name="apply-to" checked={applyTo === v} onChange={() => setApplyTo(v)} className="mt-1 size-4 accent-[var(--c-brand)]" />
                <span>
                  <span className="block text-sm font-semibold">{t}</span>
                  <span className="mt-0.5 block text-xs text-muted">{d}</span>
                </span>
              </label>
            ))}
          </div>
        </fieldset>
        {applyTo === 'existing' && (
          <>
            <Field
              label="A partir de"
              hint={increase ? `Mínimo: ${formatDate(minDate)} (30 dias de aviso).` : 'Descidas podem aplicar-se mais cedo.'}
              error={tooSoon ? 'Um aumento precisa de pelo menos 30 dias de aviso.' : undefined}
            >
              <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} min={increase ? isoDay(minDate) : isoDay(new Date())} />
            </Field>
            <Field label="Mensagem no email" optional hint="Explica o porquê — os clientes agradecem.">
              <Textarea value={note} onChange={(e) => setNote(e.target.value)} rows={2} maxLength={255} placeholder="ex.: Aumento do custo do servidor." />
            </Field>
          </>
        )}
      </div>
    </Modal>
  )
}

// ------------------------------------------------------------------ Lista
function ScheduledChanges({ plan }: { plan: AdminPlan }) {
  const confirm = useConfirm()
  const cancel = useAction((id: number) => api.del(`/api/admin/price-changes/${id}`), { invalidate: INVALIDATE, errorTitle: 'Não foi possível cancelar' })
  const future = plan.price_changes.filter((c) => new Date(c.effective_at).getTime() > Date.now())
  if (!future.length) return null
  return (
    <ul className="mt-2 space-y-1.5">
      {future.map((c) => (
        <li key={c.id} className="flex flex-wrap items-center gap-x-2 gap-y-1 rounded-lg bg-info-soft px-2.5 py-1.5 text-xs">
          <CalendarClock className="size-3.5 text-info" aria-hidden />
          <span>
            {formatMoney(c.old_price_cents, plan.currency)} → <strong>{formatMoney(c.new_price_cents, plan.currency)}</strong> a {formatDate(c.effective_at)}
            {c.notified_at && <span className="text-muted"> · avisados a {formatDate(c.notified_at)}</span>}
          </span>
          <button
            type="button"
            className="ml-auto font-semibold text-danger hover:underline"
            onClick={async () => {
              if (
                await confirm({
                  title: 'Cancelar esta mudança de preço?',
                  message: 'Os subscritores atuais mantêm o preço que pagam hoje. O preço para novos clientes não volta atrás automaticamente.',
                  confirmLabel: 'Cancelar mudança',
                  cancelLabel: 'Manter',
                  danger: true,
                })
              )
                cancel.mutate(c.id)
            }}
          >
            Cancelar
          </button>
        </li>
      ))}
    </ul>
  )
}

function PlanBadges({ pl }: { pl: AdminPlan }) {
  return (
    <div className="flex flex-wrap gap-1">
      {pl.is_active ? <Badge tone="success">Ativo</Badge> : <Badge tone="danger">Inativo</Badge>}
      {!pl.is_public && <Badge tone="neutral">Privado</Badge>}
      {pl.features.jellyfin.enabled && <Badge tone="brand">Jellyfin {pl.features.jellyfin.max_streams === 0 ? '∞' : `×${pl.features.jellyfin.max_streams}`}</Badge>}
      {pl.features.jellyfin.live_tv && <Badge tone="brand">TV</Badge>}
      {pl.features.seerr.enabled && <Badge tone="brand">Seerr</Badge>}
      {pl.features.iptv.enabled && <Badge tone="brand">IPTV</Badge>}
    </div>
  )
}

function PlanPrice({ pl }: { pl: AdminPlan }) {
  return (
    <>
      <span className="whitespace-nowrap font-medium tabular-nums">
        {formatMoney(pl.price_cents, pl.currency)}
        <span className="text-muted">{perInterval(pl.interval_unit, pl.interval_count)}</span>
      </span>
      {pl.subscribers_on_other_price > 0 && (
        <span className="mt-0.5 block text-xs text-warning">
          {pl.subscribers_on_other_price} {pl.subscribers_on_other_price === 1 ? 'paga' : 'pagam'} outro preço
        </span>
      )}
    </>
  )
}

export default function AdminPlans() {
  const q = useAdminProducts()
  const [productModal, setProductModal] = useState<{ product: AdminProduct | null } | null>(null)
  const [planModal, setPlanModal] = useState<{ plan: AdminPlan | null; productId: number } | null>(null)
  const [priceFor, setPriceFor] = useState<AdminPlan | null>(null)
  const [migrateFor, setMigrateFor] = useState<{ plan: AdminPlan; product: AdminProduct } | null>(null)

  const planMenu = (pl: AdminPlan, p: AdminProduct) => (
    <Menu
      label={`Ações para ${pl.name}`}
      items={[
        { label: 'Editar plano', icon: <Pencil />, onSelect: () => setPlanModal({ plan: pl, productId: p.id }) },
        { label: 'Alterar preço', icon: <Euro />, onSelect: () => setPriceFor(pl), hint: 'Só novos clientes ou também os atuais.' },
        { label: 'Migrar subscritores', icon: <ArrowRightLeft />, onSelect: () => setMigrateFor({ plan: pl, product: p }), disabled: p.plans.length < 2 },
      ]}
    />
  )

  return (
    <div>
      <PageHeader
        eyebrow="Administração"
        title="Produtos & planos"
        description="O que os clientes veem na loja. Cada produto define como é entregue; cada plano define o preço e os direitos."
        actions={
          <Button onClick={() => setProductModal({ product: null })} icon={<Plus className="size-4" />}>
            Novo produto
          </Button>
        }
      />
      <Alert tone="info" className="mb-6" title="Preços só aqui — nada a criar na GoCardless nem no Stripe">
        O cliente autoriza o pagamento uma vez (mandato SEPA ou cartão) e o portal calcula e cobra o valor certo em cada mês, com pro-rata. Para automatizar a entrega de
        um serviço novo, escolhe “Webhook” no produto: o portal chama o teu URL (assinado com HMAC) quando o cliente adere, muda ou cancela. Chaves e webhooks dos
        pagamentos: <a href="/admin/definicoes?s=gocardless" className="link">GoCardless</a> · <a href="/admin/definicoes?s=stripe" className="link">Stripe</a>.
      </Alert>
      {q.isPending ? (
        <SkeletonCard lines={5} />
      ) : q.isError ? (
        <Alert tone="danger">{errorMessage(q.error)}</Alert>
      ) : !q.data.length ? (
        <Card>
          <EmptyState icon={<Package className="size-6" />} title="Sem produtos" description="Cria o primeiro produto para adicionares planos." />
        </Card>
      ) : (
        <div className="space-y-6">
          {q.data.map((p) => (
            <Card key={p.id} className="overflow-hidden">
              <div className="flex flex-col gap-3 border-b border-border px-5 py-4 sm:flex-row sm:items-start sm:px-6">
                <div className="flex min-w-0 flex-1 items-start gap-3">
                  <ProductIcon icon={p.icon} fulfillment={p.fulfillment} image={p.image_url} />
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <h2 className="text-lg font-bold">{p.name}</h2>
                      <Badge tone="neutral">{FULFILLMENT_TYPE[p.fulfillment]?.label ?? p.fulfillment}</Badge>
                      {p.jellyfin_managed && <Badge tone="brand">Jellyfin</Badge>}
                      {p.requires_invite && <Badge tone="warning">Beta fechado · {p.locked_name || 'TK CDN'}</Badge>}
                      {p.bonus_eligible && <Badge tone="brand">Bónus</Badge>}
                      {!p.is_active && <Badge tone="danger">Inativo</Badge>}
                    </div>
                    <p className="mt-0.5 text-sm text-muted">
                      <span className="font-mono text-xs">{p.code}</span>
                      {p.description && ` · ${p.description}`}
                    </p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="secondary" onClick={() => setProductModal({ product: p })} icon={<Pencil className="size-3.5" />}>
                    Editar
                  </Button>
                  <Button size="sm" onClick={() => setPlanModal({ plan: null, productId: p.id })} icon={<Plus className="size-3.5" />}>
                    Novo plano
                  </Button>
                </div>
              </div>
              {!p.plans.length ? (
                <EmptyState compact title="Sem planos" description="Adiciona um plano a este produto." />
              ) : (
                <>
                  <div className="hidden md:block">
                    <Table minWidth={720}>
                      <THead>
                        <Th>Plano</Th>
                        <Th>Preço</Th>
                        <Th>Estado e direitos</Th>
                        <Th className="text-right">Subscritores</Th>
                        <Th>
                          <span className="sr-only">Ações</span>
                        </Th>
                      </THead>
                      <tbody>
                        {p.plans.map((pl) => (
                          <Tr key={pl.id}>
                            <Td>
                              <p className="font-semibold">{pl.name}</p>
                              <p className="font-mono text-xs text-muted">{pl.code}</p>
                              <ScheduledChanges plan={pl} />
                            </Td>
                            <Td>
                              <PlanPrice pl={pl} />
                            </Td>
                            <Td>
                              <PlanBadges pl={pl} />
                            </Td>
                            <Td className="text-right font-semibold tabular-nums">{pl.active_subscriptions}</Td>
                            <Td className="w-px text-right">{planMenu(pl, p)}</Td>
                          </Tr>
                        ))}
                      </tbody>
                    </Table>
                  </div>
                  <ul className="divide-y divide-border md:hidden">
                    {p.plans.map((pl) => (
                      <li key={pl.id} className="px-5 py-4">
                        <div className="flex items-start gap-3">
                          <div className="min-w-0 flex-1">
                            <p className="font-semibold">{pl.name}</p>
                            <p className="font-mono text-xs text-muted">{pl.code}</p>
                            <p className="mt-1 text-sm">
                              <PlanPrice pl={pl} />
                              <span className="text-muted"> · {pl.active_subscriptions} subscritores</span>
                            </p>
                            <div className="mt-2">
                              <PlanBadges pl={pl} />
                            </div>
                          </div>
                          {planMenu(pl, p)}
                        </div>
                        <ScheduledChanges plan={pl} />
                      </li>
                    ))}
                  </ul>
                </>
              )}
            </Card>
          ))}
        </div>
      )}
      {productModal && <ProductModal product={productModal.product} open onClose={() => setProductModal(null)} />}
      {planModal && q.data && (
        <PlanModal
          plan={planModal.plan}
          productId={planModal.productId}
          products={q.data}
          open
          onClose={() => setPlanModal(null)}
          onPriceChange={(pl) => {
            setPlanModal(null)
            setPriceFor(pl)
          }}
        />
      )}
      {priceFor && <PriceChangeDialog plan={priceFor} onClose={() => setPriceFor(null)} />}
      {migrateFor && <MigrateDialog plan={migrateFor.plan} product={migrateFor.product} onClose={() => setMigrateFor(null)} />}
    </div>
  )
}
