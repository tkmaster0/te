import { useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { CheckCircle2, CircleSlash, Download, Eye, Mail, RefreshCw, RotateCcw, Users, XCircle } from 'lucide-react'
import { api, errorMessage, qs } from '../../api/client'
import { useAction } from '../../api/mutation'
import type { IntegrationHealth, Job, WebhookDetail, WebhookRow } from '../../api/types'
import {
  Alert,
  Badge,
  Button,
  Card,
  CardHeader,
  DateText,
  EmptyState,
  Modal,
  PageHeader,
  Pagination,
  Pills,
  Select,
  SkeletonRows,
  StatusBadge,
  Table,
  Tabs,
  THead,
  Th,
  Tr,
  Td,
  useConfirm,
} from '../../components/ui'
import { INTEGRATION_LABEL, JOB_STATUS, WEBHOOK_STATUS } from '../../i18n/labels'

function JobsPanel({ status, setStatus }: { status: string; setStatus: (s: string) => void }) {
  const [page, setPage] = useState(1)
  const [open, setOpen] = useState<Job | null>(null)
  const q = useQuery({
    queryKey: ['admin', 'jobs', status, page],
    queryFn: () => api.get<{ counts: Record<string, number>; items: Job[] }>(`/api/admin/jobs${qs({ status, page })}`),
    refetchInterval: 15_000,
  })
  const retry = useAction((id: number) => api.post(`/api/admin/jobs/${id}/retry`), { invalidate: [['admin', 'jobs']], success: 'Tarefa reagendada.' })
  const counts = q.data?.counts ?? {}
  const total = Object.values(counts).reduce((a, b) => a + b, 0)
  return (
    <Card className="overflow-hidden">
      <div className="px-5 pt-5 sm:px-6">
        <Pills
          ariaLabel="Estado das tarefas"
          value={status}
          onChange={(v) => {
            setStatus(v)
            setPage(1)
          }}
          items={[
            { value: '', label: 'Todas', count: total },
            ...['failed', 'pending', 'running', 'done'].map((s) => ({ value: s, label: JOB_STATUS[s].label, count: counts[s] ?? 0 })),
          ]}
        />
      </div>
      <div className="mt-3">
        {q.isPending ? (
          <SkeletonRows rows={6} />
        ) : q.isError ? (
          <div className="p-5">
            <Alert tone="danger">{errorMessage(q.error)}</Alert>
          </div>
        ) : !q.data.items.length ? (
          <EmptyState compact icon={<CheckCircle2 className="size-6" />} title="Sem tarefas" description={status === 'failed' ? 'Nenhuma tarefa falhou. 👌' : undefined} />
        ) : (
          <>
            <Table minWidth={760}>
              <THead>
                <Th>#</Th>
                <Th>Tipo</Th>
                <Th>Estado</Th>
                <Th>Tentativas</Th>
                <Th>Criada</Th>
                <Th>Erro</Th>
                <Th>
                  <span className="sr-only">Ações</span>
                </Th>
              </THead>
              <tbody>
                {q.data.items.map((j) => (
                  <Tr key={j.id}>
                    <Td className="font-mono text-xs text-muted">{j.id}</Td>
                    <Td className="font-mono text-xs">{j.kind}</Td>
                    <Td>
                      <StatusBadge kind="job" status={j.status} />
                    </Td>
                    <Td className="tabular-nums text-muted">
                      {j.attempts}/{j.max_attempts}
                    </Td>
                    <Td className="whitespace-nowrap text-muted">
                      <DateText value={j.created_at} withTime />
                    </Td>
                    <Td className="max-w-[16rem]">
                      {j.last_error ? <p className="truncate font-mono text-xs text-danger" title={j.last_error}>{j.last_error}</p> : <span className="text-subtle">—</span>}
                    </Td>
                    <Td className="whitespace-nowrap text-right">
                      <Button size="icon-sm" variant="ghost" aria-label={`Ver tarefa ${j.id}`} onClick={() => setOpen(j)}>
                        <Eye className="size-4" />
                      </Button>
                      {(j.status === 'failed' || j.status === 'pending') && (
                        <Button
                          size="sm"
                          variant="ghost"
                          icon={<RotateCcw className="size-3.5" />}
                          loading={retry.isPending && retry.variables === j.id}
                          onClick={() => retry.mutate(j.id)}
                        >
                          {j.status === 'failed' ? 'Repetir' : 'Correr já'}
                        </Button>
                      )}
                    </Td>
                  </Tr>
                ))}
              </tbody>
            </Table>
            <Pagination page={page} size={100} hasNext={q.data.items.length === 100} onPage={setPage} />
          </>
        )}
      </div>
      <Modal open={!!open} onClose={() => setOpen(null)} title={`Tarefa #${open?.id} · ${open?.kind}`} size="lg">
        {open && (
          <div className="space-y-3">
            {open.last_error && <Alert tone="danger">{open.last_error}</Alert>}
            <pre className="scrollbar-thin max-h-96 overflow-auto rounded-xl border border-border bg-bg p-3 font-mono text-xs">{JSON.stringify(open.payload, null, 2)}</pre>
            <p className="text-xs text-muted">
              Próxima execução: <DateText value={open.run_after} withTime /> · Terminada: <DateText value={open.finished_at} withTime />
            </p>
          </div>
        )}
      </Modal>
    </Card>
  )
}

function WebhooksPanel({ status, setStatus }: { status: string; setStatus: (s: string) => void }) {
  const [provider, setProvider] = useState('')
  const [page, setPage] = useState(1)
  const [viewId, setViewId] = useState<number | null>(null)
  const q = useQuery({
    queryKey: ['admin', 'webhooks', status, provider, page],
    queryFn: () => api.get<WebhookRow[]>(`/api/admin/webhooks${qs({ status, provider, page })}`),
  })
  const detail = useQuery({
    queryKey: ['admin', 'webhook', viewId],
    queryFn: () => api.get<WebhookDetail>(`/api/admin/webhooks/${viewId}`),
    enabled: viewId !== null,
  })
  const replay = useAction((id: number) => api.post(`/api/admin/webhooks/${id}/replay`), { invalidate: [['admin', 'webhooks']] })
  return (
    <Card className="overflow-hidden">
      <div className="flex flex-col gap-3 px-5 pt-5 sm:flex-row sm:items-center sm:px-6">
        <Pills
          ariaLabel="Estado"
          className="flex-1"
          value={status}
          onChange={(v) => {
            setStatus(v)
            setPage(1)
          }}
          items={[{ value: '', label: 'Todos' }, ...Object.entries(WEBHOOK_STATUS).map(([k, v]) => ({ value: k, label: v.label }))]}
        />
        <div className="sm:w-48">
          <Select
            aria-label="Fornecedor"
            value={provider}
            onChange={(e) => {
              setProvider(e.target.value)
              setPage(1)
            }}
          >
            <option value="">Todos os fornecedores</option>
            <option value="gocardless">GoCardless</option>
            <option value="stripe">Stripe</option>
          </Select>
        </div>
      </div>
      <div className="mt-3">
        {q.isPending ? (
          <SkeletonRows rows={6} />
        ) : q.isError ? (
          <div className="p-5">
            <Alert tone="danger">{errorMessage(q.error)}</Alert>
          </div>
        ) : !q.data.length ? (
          <EmptyState compact title="Sem eventos" />
        ) : (
          <>
            <Table minWidth={760}>
              <THead>
                <Th>Recebido</Th>
                <Th>Fornecedor</Th>
                <Th>Evento</Th>
                <Th>Estado</Th>
                <Th>Erro</Th>
                <Th>
                  <span className="sr-only">Ações</span>
                </Th>
              </THead>
              <tbody>
                {q.data.map((w) => (
                  <Tr key={w.id}>
                    <Td className="whitespace-nowrap text-muted">
                      <DateText value={w.received_at} withTime />
                    </Td>
                    <Td>{w.provider}</Td>
                    <Td>
                      <p className="font-mono text-xs">{w.event_type ?? '—'}</p>
                      <p className="font-mono text-[11px] text-subtle">{w.event_id}</p>
                    </Td>
                    <Td>
                      <StatusBadge kind="webhook" status={w.status} />
                    </Td>
                    <Td className="max-w-[14rem]">
                      {w.error ? <p className="truncate font-mono text-xs text-danger" title={w.error}>{w.error}</p> : <span className="text-subtle">—</span>}
                    </Td>
                    <Td className="whitespace-nowrap text-right">
                      <Button size="icon-sm" variant="ghost" aria-label="Ver payload" onClick={() => setViewId(w.id)}>
                        <Eye className="size-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        icon={<RotateCcw className="size-3.5" />}
                        loading={replay.isPending && replay.variables === w.id}
                        onClick={() => replay.mutate(w.id)}
                      >
                        Reprocessar
                      </Button>
                    </Td>
                  </Tr>
                ))}
              </tbody>
            </Table>
            <Pagination page={page} size={100} hasNext={q.data.length === 100} onPage={setPage} />
          </>
        )}
      </div>
      <Modal open={viewId !== null} onClose={() => setViewId(null)} title={detail.data ? `${detail.data.provider} · ${detail.data.event_type ?? 'evento'}` : 'Evento'} size="lg">
        {detail.isPending ? (
          <SkeletonRows rows={4} />
        ) : detail.isError ? (
          <Alert tone="danger">{errorMessage(detail.error)}</Alert>
        ) : (
          <div className="space-y-3">
            {detail.data.error && <Alert tone="danger">{detail.data.error}</Alert>}
            <pre className="scrollbar-thin max-h-[60vh] overflow-auto rounded-xl border border-border bg-bg p-3 font-mono text-xs">{JSON.stringify(detail.data.payload, null, 2)}</pre>
          </div>
        )}
      </Modal>
    </Card>
  )
}

function IntegrationsPanel() {
  const confirm = useConfirm()
  const q = useQuery({ queryKey: ['admin', 'integrations'], queryFn: () => api.get<IntegrationHealth[]>('/api/admin/integrations'), staleTime: 0 })
  const testEmail = useAction(() => api.post('/api/admin/test-email'), { errorTitle: 'Falhou' })
  const importGc = useAction(() => api.post('/api/admin/gocardless/import'), { errorTitle: 'A importação falhou' })
  const reconcileAll = useAction(() => api.post('/api/admin/reconcile-all'), { invalidate: [['admin', 'jobs']] })
  return (
    <div className="space-y-4">
      <Card>
        <CardHeader
          title="Estado das integrações"
          description="Teste de ligação a cada serviço externo."
          actions={
            <Button size="sm" variant="secondary" onClick={() => q.refetch()} loading={q.isFetching} icon={<RefreshCw className="size-4" />}>
              Testar de novo
            </Button>
          }
        />
        <div className="px-5 pb-5 pt-4 sm:px-6">
          {q.isPending ? (
            <SkeletonRows rows={3} />
          ) : q.isError ? (
            <Alert tone="danger">{errorMessage(q.error)}</Alert>
          ) : (
            <ul className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {q.data.map((i) => (
                <li key={i.name} className="rounded-xl border border-border p-4">
                  <div className="flex items-center gap-2">
                    {!i.configured ? (
                      <CircleSlash className="size-5 text-subtle" aria-hidden />
                    ) : i.ok ? (
                      <CheckCircle2 className="size-5 text-success" aria-hidden />
                    ) : (
                      <XCircle className="size-5 text-danger" aria-hidden />
                    )}
                    <span className="font-semibold">{INTEGRATION_LABEL[i.name] ?? i.name}</span>
                    <span className="ml-auto">
                      {!i.configured ? <Badge tone="neutral">Não configurado</Badge> : i.ok ? <Badge tone="success">OK</Badge> : <Badge tone="danger">Erro</Badge>}
                    </span>
                  </div>
                  {i.info && (
                    <dl className="mt-2 space-y-0.5 text-xs text-muted">
                      {Object.entries(i.info).map(([k, v]) => (
                        <div key={k} className="flex justify-between gap-2">
                          <dt>{k}</dt>
                          <dd className="truncate font-mono">{typeof v === 'boolean' ? (v ? 'sim' : 'não') : String(v ?? '—')}</dd>
                        </div>
                      ))}
                    </dl>
                  )}
                  {i.error && <p className="mt-2 break-words font-mono text-xs text-danger">{i.error}</p>}
                </li>
              ))}
            </ul>
          )}
        </div>
      </Card>
      <Card>
        <CardHeader title="Ações de manutenção" />
        <div className="grid grid-cols-1 gap-3 px-5 pb-5 pt-4 sm:grid-cols-3 sm:px-6">
          <div className="rounded-xl border border-border p-4">
            <p className="font-semibold">Reconciliar todos</p>
            <p className="mt-1 text-xs text-muted">Volta a aplicar os direitos de todos os utilizadores no Jellyfin, Seerr e Dispatcharr.</p>
            <Button
              size="sm"
              variant="secondary"
              className="mt-3"
              icon={<Users className="size-4" />}
              loading={reconcileAll.isPending}
              onClick={async () => {
                if (await confirm({ title: 'Reconciliar todos os utilizadores?', message: 'Pode demorar alguns minutos, conforme o número de utilizadores.', confirmLabel: 'Reconciliar' }))
                  reconcileAll.mutate()
              }}
            >
              Reconciliar todos
            </Button>
          </div>
          <div className="rounded-xl border border-border p-4">
            <p className="font-semibold">Email de teste</p>
            <p className="mt-1 text-xs text-muted">Envia um email para o teu endereço para confirmar o SMTP.</p>
            <Button size="sm" variant="secondary" className="mt-3" icon={<Mail className="size-4" />} loading={testEmail.isPending} onClick={() => testEmail.mutate()}>
              Enviar email de teste
            </Button>
          </div>
          <div className="rounded-xl border border-border p-4">
            <p className="font-semibold">Importar GoCardless</p>
            <p className="mt-1 text-xs text-muted">Associa subscrições GoCardless existentes (ex.: do site antigo) aos utilizadores.</p>
            <Button
              size="sm"
              variant="secondary"
              className="mt-3"
              icon={<Download className="size-4" />}
              loading={importGc.isPending}
              onClick={async () => {
                if (await confirm({ title: 'Importar subscrições GoCardless?', message: 'Vai consultar a GoCardless para cada utilizador com cliente ou mandato associado.', confirmLabel: 'Importar' }))
                  importGc.mutate()
              }}
            >
              Importar subscrições
            </Button>
          </div>
        </div>
      </Card>
    </div>
  )
}

export default function AdminOperations() {
  const [params, setParams] = useSearchParams()
  const tab = ['jobs', 'webhooks', 'integracoes'].includes(params.get('tab') ?? '') ? (params.get('tab') as string) : 'jobs'
  const status = params.get('status') ?? ''
  const set = (next: Record<string, string>) => {
    const p = new URLSearchParams(params)
    for (const [k, v] of Object.entries(next)) {
      if (v) p.set(k, v)
      else p.delete(k)
    }
    setParams(p, { replace: true })
  }
  return (
    <div>
      <PageHeader eyebrow="Administração" title="Operações" description="Fila de tarefas, webhooks dos pagamentos e saúde das integrações." />
      <Tabs
        className="mb-6"
        ariaLabel="Secções"
        value={tab}
        onChange={(id) => set({ tab: id, status: '' })}
        items={[
          { id: 'jobs', label: 'Tarefas' },
          { id: 'webhooks', label: 'Webhooks' },
          { id: 'integracoes', label: 'Integrações' },
        ]}
      />
      {tab === 'jobs' && <JobsPanel status={status} setStatus={(s) => set({ status: s })} />}
      {tab === 'webhooks' && <WebhooksPanel status={status} setStatus={(s) => set({ status: s })} />}
      {tab === 'integracoes' && <IntegrationsPanel />}
    </div>
  )
}
