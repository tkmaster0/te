import { useMemo, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Ban, Plus, Search, Ticket } from 'lucide-react'
import { api, errorMessage } from '../../api/client'
import { useAction } from '../../api/mutation'
import { useAdminProducts } from '../../api/admin'
import type { AdminInvite } from '../../api/types'
import {
  Alert,
  Badge,
  Button,
  Card,
  CardHeader,
  CopyButton,
  CopyField,
  DateText,
  EmptyState,
  Field,
  Input,
  Modal,
  PageHeader,
  Select,
  Pills,
  SkeletonRows,
  Table,
  THead,
  Th,
  Tr,
  Td,
  useConfirm,
} from '../../components/ui'
import { parseDate } from '../../lib/format'
import type { Tone } from '../../i18n/labels'

function stateOf(i: AdminInvite): { key: string; label: string; tone: Tone } {
  if (i.disabled) return { key: 'disabled', label: 'Desativado', tone: 'neutral' }
  if (i.uses >= i.max_uses) return { key: 'used', label: 'Esgotado', tone: 'success' }
  const exp = parseDate(i.expires_at)
  if (exp && exp.getTime() < Date.now()) return { key: 'expired', label: 'Expirado', tone: 'neutral' }
  return { key: 'open', label: 'Disponível', tone: 'brand' }
}

export default function AdminInvites() {
  const confirm = useConfirm()
  const q = useQuery({ queryKey: ['admin', 'invites'], queryFn: () => api.get<AdminInvite[]>('/api/admin/invites') })
  const products = useAdminProducts()
  const [maxUses, setMaxUses] = useState('1')
  const [days, setDays] = useState('')
  const [note, setNote] = useState('')
  const [code, setCode] = useState('')
  const [unlocks, setUnlocks] = useState('all')
  const [created, setCreated] = useState<{ code: string; link: string } | null>(null)
  const [filter, setFilter] = useState('open')
  const [search, setSearch] = useState('')

  const create = useAction(
    () =>
      api.post<{ id: number; code: string; link: string }>('/api/admin/invites', {
        max_uses: Number(maxUses) || 1,
        days: days ? Number(days) : null,
        note: note.trim() || null,
        code: code.trim() || null,
        unlocks: unlocks === 'all' ? null : unlocks === 'none' ? [] : [unlocks],
      }),
    {
      invalidate: [['admin', 'invites']],
      success: false,
      errorTitle: 'Não foi possível criar o convite',
      onSuccess: (res) => {
        setCreated({ code: res.code, link: res.link })
        setNote('')
        setCode('')
      },
    },
  )
  const disable = useAction((id: number) => api.del(`/api/admin/invites/${id}`), { invalidate: [['admin', 'invites']], success: 'Convite desativado.' })

  const rows = useMemo(() => {
    const s = search.trim().toLowerCase()
    return (q.data ?? []).filter((i) => {
      if (filter && stateOf(i).key !== filter) return false
      if (!s) return true
      return i.code.toLowerCase().includes(s) || (i.created_by ?? '').toLowerCase().includes(s) || (i.note ?? '').toLowerCase().includes(s)
    })
  }, [q.data, filter, search])

  const counts = useMemo(() => {
    const c: Record<string, number> = { '': q.data?.length ?? 0 }
    for (const i of q.data ?? []) c[stateOf(i).key] = (c[stateOf(i).key] ?? 0) + 1
    return c
  }, [q.data])

  const origin = window.location.origin

  return (
    <div className="space-y-4">
      <PageHeader eyebrow="Administração" title="Convites" description="Cria códigos de convite de administrador (com várias utilizações) e acompanha todos os códigos." />

      <Card>
        <CardHeader icon={<Plus className="size-5" />} title="Novo convite de administrador" description="Quem se registar com um convite teu precisa de menos convidados para ganhar o bónus." />
        <form
          className="grid grid-cols-1 gap-4 px-5 pb-5 pt-4 sm:grid-cols-2 sm:px-6 lg:grid-cols-3 xl:grid-cols-6"
          onSubmit={(e) => {
            e.preventDefault()
            create.mutate()
          }}
        >
          <Field label="Utilizações">
            <Input type="number" min={1} max={1000} value={maxUses} onChange={(e) => setMaxUses(e.target.value)} />
          </Field>
          <Field label="Validade (dias)" optional>
            <Input type="number" min={1} max={365} value={days} onChange={(e) => setDays(e.target.value)} placeholder="sem fim" />
          </Field>
          <Field label="Código personalizado" optional>
            <Input
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase().replace(/[^A-Z0-9-]/g, ''))}
              placeholder="automático"
              maxLength={32}
              className="font-mono"
            />
          </Field>
          <Field label="Nota" optional>
            <Input value={note} onChange={(e) => setNote(e.target.value)} maxLength={200} placeholder="ex.: Família" />
          </Field>
          <Field label="Desbloqueia" hint="Produtos em beta fechado">
            <Select value={unlocks} onChange={(e) => setUnlocks(e.target.value)}>
              <option value="all">Todos os produtos em beta</option>
              <option value="none">Nenhum (só a conta)</option>
              {(products.data ?? [])
                .filter((p) => p.requires_invite)
                .map((p) => (
                  <option key={p.code} value={p.code}>
                    Só {p.name}
                  </option>
                ))}
            </Select>
          </Field>
          <div className="flex items-end">
            <Button type="submit" className="w-full" loading={create.isPending} disabled={!!code && code.length < 4}>
              Criar convite
            </Button>
          </div>
        </form>
      </Card>

      <Card className="overflow-hidden">
        <div className="space-y-3 px-5 pt-5 sm:px-6">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-subtle" aria-hidden />
            <Input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Procurar por código, criador ou nota…"
              aria-label="Procurar convites"
              className="pl-10"
            />
          </div>
          <Pills
            ariaLabel="Estado"
            value={filter}
            onChange={setFilter}
            items={[
              { value: 'open', label: 'Disponíveis', count: counts.open ?? 0 },
              { value: 'used', label: 'Esgotados', count: counts.used ?? 0 },
              { value: 'expired', label: 'Expirados', count: counts.expired ?? 0 },
              { value: 'disabled', label: 'Desativados', count: counts.disabled ?? 0 },
              { value: '', label: 'Todos', count: counts[''] },
            ]}
          />
        </div>
        <div className="mt-3">
          {q.isPending ? (
            <SkeletonRows rows={5} />
          ) : q.isError ? (
            <div className="p-5">
              <Alert tone="danger">{errorMessage(q.error)}</Alert>
            </div>
          ) : !rows.length ? (
            <EmptyState compact icon={<Ticket className="size-6" />} title="Nenhum convite" />
          ) : (
            <Table minWidth={720}>
              <THead>
                <Th>Código</Th>
                <Th>Criado por</Th>
                <Th>Utilizações</Th>
                <Th>Expira</Th>
                <Th>Estado</Th>
                <Th>
                  <span className="sr-only">Ações</span>
                </Th>
              </THead>
              <tbody>
                {rows.map((i) => {
                  const st = stateOf(i)
                  return (
                    <Tr key={i.id}>
                      <Td>
                        <div className="flex items-center gap-1">
                          <span className="font-mono font-semibold">{i.code}</span>
                          <CopyButton value={`${origin}/registar?convite=${i.code}`} label="Copiar link" className="size-7" />
                        </div>
                        {i.note && <p className="text-xs text-muted">{i.note}</p>}
                        {i.unlocks && (
                          <p className="text-xs text-subtle">{i.unlocks.length ? `Desbloqueia: ${i.unlocks.join(', ')}` : 'Só a conta'}</p>
                        )}
                      </Td>
                      <Td className="text-muted">
                        {i.created_by ?? 'sistema'}
                        <span className="block text-xs text-subtle">
                          <DateText value={i.created_at} />
                        </span>
                      </Td>
                      <Td className="tabular-nums">
                        {i.uses} / {i.max_uses}
                      </Td>
                      <Td className="text-muted">
                        <DateText value={i.expires_at} fallback="Nunca" />
                      </Td>
                      <Td>
                        <Badge tone={st.tone}>{st.label}</Badge>
                      </Td>
                      <Td className="text-right">
                        {st.key === 'open' && (
                          <Button
                            size="sm"
                            variant="ghost"
                            icon={<Ban className="size-3.5" />}
                            onClick={async () => {
                              if (await confirm({ title: 'Desativar convite?', message: `O código ${i.code} deixa de funcionar.`, confirmLabel: 'Desativar', danger: true }))
                                disable.mutate(i.id)
                            }}
                          >
                            Desativar
                          </Button>
                        )}
                      </Td>
                    </Tr>
                  )
                })}
              </tbody>
            </Table>
          )}
        </div>
      </Card>

      <Modal open={!!created} onClose={() => setCreated(null)} title="Convite criado" size="sm" footer={<Button onClick={() => setCreated(null)}>Fechar</Button>}>
        <div className="space-y-4">
          <CopyField label="Código" value={created?.code} />
          <CopyField label="Link de registo" value={created?.link} />
        </div>
      </Modal>
    </div>
  )
}
