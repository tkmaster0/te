import { useEffect, useState } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { ArrowDown, ArrowUp, HelpCircle, Link2, Megaphone, Plus, Smartphone, Trash2 } from 'lucide-react'
import { api, errorMessage } from '../../api/client'
import { keys } from '../../api/keys'
import { useAction } from '../../api/mutation'
import type { FaqItem, SiteApp, SiteSettings } from '../../api/types'
import { Alert, Button, Card, CardHeader, Field, Input, PageHeader, Select, SkeletonCard, Textarea } from '../../components/ui'
import { PlatformIcon } from '../../components/PlatformIcon'
import { PLATFORM_LABEL } from '../../i18n/labels'

function move<T>(list: T[], i: number, d: number): T[] {
  const j = i + d
  if (j < 0 || j >= list.length) return list
  const next = [...list]
  ;[next[i], next[j]] = [next[j], next[i]]
  return next
}

function RowActions({ i, n, onMove, onRemove, label }: { i: number; n: number; onMove: (d: number) => void; onRemove: () => void; label: string }) {
  return (
    <div className="flex shrink-0 gap-1">
      <Button variant="ghost" size="icon-sm" onClick={() => onMove(-1)} disabled={i === 0} aria-label={`Subir ${label}`}>
        <ArrowUp className="size-4" />
      </Button>
      <Button variant="ghost" size="icon-sm" onClick={() => onMove(1)} disabled={i === n - 1} aria-label={`Descer ${label}`}>
        <ArrowDown className="size-4" />
      </Button>
      <Button variant="ghost" size="icon-sm" onClick={onRemove} aria-label={`Remover ${label}`}>
        <Trash2 className="size-4" />
      </Button>
    </div>
  )
}

export default function AdminSettings({ embedded = false }: { embedded?: boolean }) {
  const qc = useQueryClient()
  const q = useQuery({ queryKey: ['admin', 'settings'], queryFn: () => api.get<SiteSettings>('/api/admin/settings') })
  const [form, setForm] = useState<SiteSettings | null>(null)
  useEffect(() => {
    if (q.data && !form) setForm({ ...q.data, apps: q.data.apps ?? [], faq: q.data.faq ?? [] })
  }, [q.data, form])

  const save = useAction(
    (body: SiteSettings) =>
      api.put('/api/admin/settings', {
        announcement: body.announcement?.trim() || null,
        support_url: body.support_url?.trim() || null,
        support_email: body.support_email?.trim() || null,
        terms_url: body.terms_url?.trim() || null,
        privacy_url: body.privacy_url?.trim() || null,
        apps: body.apps.filter((a) => a.name.trim() && a.url.trim()),
        faq: body.faq.filter((f) => f.q.trim() && f.a.trim()),
      }),
    {
      success: 'Definições guardadas.',
      errorTitle: 'Não foi possível guardar',
      onSuccess: () => {
        void qc.invalidateQueries({ queryKey: keys.config })
        void qc.invalidateQueries({ queryKey: ['admin', 'settings'] })
      },
    },
  )

  if (q.isPending || (!form && !q.isError))
    return (
      <div>
        <PageHeader eyebrow="Administração" title="Definições" />
        <SkeletonCard lines={6} />
      </div>
    )
  if (q.isError || !form)
    return (
      <div>
        <PageHeader eyebrow="Administração" title="Definições" />
        <Alert tone="danger">{errorMessage(q.error)}</Alert>
      </div>
    )

  const set = <K extends keyof SiteSettings>(k: K, v: SiteSettings[K]) => setForm((f) => (f ? { ...f, [k]: v } : f))
  const setApp = (i: number, p: Partial<SiteApp>) => set('apps', form.apps.map((a, k) => (k === i ? { ...a, ...p } : a)))
  const setFaq = (i: number, p: Partial<FaqItem>) => set('faq', form.faq.map((a, k) => (k === i ? { ...a, ...p } : a)))

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault()
        save.mutate(form)
      }}
    >
      {embedded ? (
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <p className="text-sm text-muted">Aviso no topo, links de suporte, apps recomendadas e perguntas frequentes.</p>
          <Button type="submit" loading={save.isPending}>
            Guardar alterações
          </Button>
        </div>
      ) : (
        <PageHeader
          eyebrow="Administração"
          title="Definições"
          description="Conteúdo do site público e do portal."
          actions={
            <Button type="submit" loading={save.isPending}>
              Guardar alterações
            </Button>
          }
        />
      )}
      <div className="space-y-4">
        <Card>
          <CardHeader icon={<Megaphone className="size-5" />} title="Aviso" description="Mostrado no topo de todas as páginas. Os utilizadores podem fechá-lo." />
          <div className="px-5 pb-5 pt-4 sm:px-6">
            <Field label="Texto do aviso" hint="Deixa vazio para não mostrar nenhum aviso.">
              <Textarea value={form.announcement ?? ''} onChange={(e) => set('announcement', e.target.value)} rows={2} placeholder="ex.: Manutenção programada no domingo às 03:00." />
            </Field>
          </div>
        </Card>

        <Card>
          <CardHeader icon={<Link2 className="size-5" />} title="Ligações e suporte" />
          <div className="grid grid-cols-1 gap-4 px-5 pb-5 pt-4 sm:grid-cols-2 sm:px-6">
            <Field label="URL de suporte" optional>
              <Input type="url" value={form.support_url ?? ''} onChange={(e) => set('support_url', e.target.value)} placeholder="https://" />
            </Field>
            <Field label="Email de suporte" optional>
              <Input type="email" value={form.support_email ?? ''} onChange={(e) => set('support_email', e.target.value)} />
            </Field>
            <Field label="Termos de utilização (URL)" optional hint="Se definido, o registo pede para aceitar.">
              <Input type="url" value={form.terms_url ?? ''} onChange={(e) => set('terms_url', e.target.value)} placeholder="https://" />
            </Field>
            <Field label="Política de privacidade (URL)" optional>
              <Input type="url" value={form.privacy_url ?? ''} onChange={(e) => set('privacy_url', e.target.value)} placeholder="https://" />
            </Field>
          </div>
        </Card>

        <Card>
          <CardHeader
            icon={<Smartphone className="size-5" />}
            title="Apps recomendadas"
            description="Mostradas na página Serviços."
            actions={
              <Button size="sm" variant="secondary" icon={<Plus className="size-4" />} onClick={() => set('apps', [...form.apps, { name: '', platform: 'android', url: '' }])}>
                Adicionar app
              </Button>
            }
          />
          <div className="space-y-3 px-5 pb-5 pt-4 sm:px-6">
            {!form.apps.length && <p className="text-sm text-muted">Sem apps.</p>}
            {form.apps.map((a, i) => (
              <div key={i} className="flex flex-col gap-3 rounded-xl border border-border p-3 lg:flex-row lg:items-end">
                <span className="hidden size-11 shrink-0 place-items-center rounded-lg bg-elevated lg:grid">
                  <PlatformIcon platform={a.platform} />
                </span>
                <Field label="Nome" className="lg:flex-1">
                  <Input value={a.name} onChange={(e) => setApp(i, { name: e.target.value })} />
                </Field>
                <Field label="Plataforma" className="lg:w-44">
                  <Select value={a.platform} onChange={(e) => setApp(i, { platform: e.target.value })}>
                    {Object.entries(PLATFORM_LABEL).map(([k, v]) => (
                      <option key={k} value={k}>
                        {v}
                      </option>
                    ))}
                  </Select>
                </Field>
                <Field label="Link" className="lg:flex-[1.5]">
                  <Input type="url" value={a.url} onChange={(e) => setApp(i, { url: e.target.value })} placeholder="https://" />
                </Field>
                <RowActions i={i} n={form.apps.length} label={a.name || 'app'} onMove={(d) => set('apps', move(form.apps, i, d))} onRemove={() => set('apps', form.apps.filter((_, k) => k !== i))} />
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <CardHeader
            icon={<HelpCircle className="size-5" />}
            title="Perguntas frequentes"
            description="Mostradas na página inicial. Se não houver nenhuma, são usadas perguntas genéricas."
            actions={
              <Button size="sm" variant="secondary" icon={<Plus className="size-4" />} onClick={() => set('faq', [...form.faq, { q: '', a: '' }])}>
                Adicionar pergunta
              </Button>
            }
          />
          <div className="space-y-3 px-5 pb-5 pt-4 sm:px-6">
            {!form.faq.length && <p className="text-sm text-muted">Sem perguntas personalizadas.</p>}
            {form.faq.map((f, i) => (
              <div key={i} className="flex flex-col gap-3 rounded-xl border border-border p-3 sm:flex-row sm:items-start">
                <div className="flex-1 space-y-3">
                  <Field label="Pergunta">
                    <Input value={f.q} onChange={(e) => setFaq(i, { q: e.target.value })} />
                  </Field>
                  <Field label="Resposta">
                    <Textarea value={f.a} onChange={(e) => setFaq(i, { a: e.target.value })} rows={3} />
                  </Field>
                </div>
                <RowActions i={i} n={form.faq.length} label={f.q || 'pergunta'} onMove={(d) => set('faq', move(form.faq, i, d))} onRemove={() => set('faq', form.faq.filter((_, k) => k !== i))} />
              </div>
            ))}
          </div>
        </Card>

        <div className="flex justify-end">
          <Button type="submit" size="lg" loading={save.isPending}>
            Guardar alterações
          </Button>
        </div>
      </div>
    </form>
  )
}
