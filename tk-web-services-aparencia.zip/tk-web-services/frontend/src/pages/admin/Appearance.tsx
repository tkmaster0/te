import { useMemo, useRef, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import clsx from 'clsx'
import { Eye, ImageIcon, Mail, RotateCcw, Save, Search, Trash2, Type, Upload } from 'lucide-react'
import { api, errorMessage } from '../../api/client'
import { keys } from '../../api/keys'
import { useAction } from '../../api/mutation'
import { TEXTS, type TextKey } from '../../content/texts'
import { Alert, Badge, Button, ButtonLink, Card, CardBody, CardHeader, Field, Input, PageHeader, SkeletonCard, Tabs, Textarea } from '../../components/ui'
import { useSearchParams } from 'react-router-dom'

interface ImageSlot {
  key: string
  label: string
  help: string
  url: string | null
  size: number | null
  content_type: string | null
}
interface EmailTpl {
  id: string
  defaults: { subject: string; title: string; body: string; cta: string | null }
  override: Partial<Record<'subject' | 'title' | 'body' | 'cta', string>>
  variables: string[]
}
interface AppearanceOut {
  images: ImageSlot[]
  texts: Record<string, string>
  emails: EmailTpl[]
  max_image_bytes: number
}

const KEY = ['admin', 'appearance']
const INVALIDATE = [KEY, keys.config]

const EMAIL_LABELS: Record<string, string> = {
  verify_email: 'Confirmação de email (código)',
  reset_password: 'Recuperar password',
  change_email: 'Mudança de email',
  password_changed: 'Password alterada',
  subscription_active: 'Serviço ativo',
  payment_failed: 'Pagamento falhou',
  payment_method_needed: 'Falta autorizar o pagamento',
  payment_received: 'Pagamento recebido',
  price_change: 'Mudança de preço',
  plan_migration: 'Mudança de plano',
  subscription_canceled: 'Cancelamento pedido',
  subscription_ended: 'Serviço terminado',
  subscription_suspended: 'Serviço suspenso',
  bonus_on: 'Bónus ativo',
  bonus_off: 'Bónus terminou',
  iptv_ready: 'TV pronta',
  invite: 'Convite',
  admin_notice: 'Aviso ao administrador',
}

/* ------------------------------------------------------------------------------------------------ textos */
function TextsTab({ saved }: { saved: Record<string, string> }) {
  const [draft, setDraft] = useState<Record<string, string>>(saved)
  const [q, setQ] = useState('')
  const groups = useMemo(() => {
    const out = new Map<string, TextKey[]>()
    const needle = q.trim().toLowerCase()
    for (const k of Object.keys(TEXTS) as TextKey[]) {
      const d = TEXTS[k]
      const hay = `${k} ${d.label} ${d.default} ${draft[k] ?? ''}`.toLowerCase()
      if (needle && !hay.includes(needle)) continue
      out.set(d.group, [...(out.get(d.group) ?? []), k])
    }
    return out
  }, [q, draft])
  const changed = (Object.keys(TEXTS) as TextKey[]).filter((k) => (draft[k] ?? '') !== (saved[k] ?? ''))
  const save = useAction(
    () => {
      const texts: Record<string, string> = {}
      for (const [k, v] of Object.entries(draft)) {
        const def = TEXTS[k as TextKey]?.default
        if (v.trim() && v.trim() !== def) texts[k] = v
      }
      return api.put('/api/admin/appearance/texts', { texts })
    },
    { invalidate: INVALIDATE },
  )
  return (
    <div className="space-y-5">
      <div className="sticky top-16 z-10 -mx-1 flex flex-wrap items-center gap-3 rounded-2xl border border-border bg-bg/90 p-3 backdrop-blur">
        <div className="relative min-w-[220px] flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-subtle" aria-hidden />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Procurar um texto…" className="pl-9" aria-label="Procurar texto" />
        </div>
        {changed.length > 0 && <Badge tone="warning">{changed.length} por guardar</Badge>}
        <Button icon={<Save className="size-4" />} loading={save.isPending} disabled={!changed.length} onClick={() => save.mutate()}>
          Guardar textos
        </Button>
      </div>
      <p className="text-sm text-muted">
        Escreve por cima do texto atual. Vazio volta ao original. Onde aparece <code>{'{app}'}</code> ou <code>{'{empresa}'}</code>, é trocado pelo nome do portal ou da empresa.
      </p>
      {[...groups.entries()].map(([group, items]) => (
        <Card key={group}>
          <CardHeader title={group} />
          <CardBody className="space-y-4">
            {items.map((k) => {
              const d = TEXTS[k]
              const value = draft[k] ?? ''
              const custom = !!value && value !== d.default
              const props = {
                value: value || d.default,
                onChange: (e: { target: { value: string } }) => setDraft((x) => ({ ...x, [k]: e.target.value })),
                'aria-label': d.label,
              }
              return (
                <Field
                  key={k}
                  label={d.label}
                  hint={'vars' in d && d.vars ? `Variáveis: ${d.vars.map((v) => `{${v}}`).join(', ')}` : undefined}
                  labelAction={
                    custom ? (
                      <span className="flex items-center gap-2">
                        <Badge tone="brand">editado</Badge>
                        <button type="button" className="inline-flex items-center gap-1 text-xs text-muted hover:text-fg" onClick={() => setDraft((x) => ({ ...x, [k]: '' }))}>
                          <RotateCcw className="size-3" aria-hidden /> original
                        </button>
                      </span>
                    ) : undefined
                  }
                >
                  {'multiline' in d && d.multiline ? <Textarea rows={3} {...props} /> : <Input {...props} />}
                </Field>
              )
            })}
          </CardBody>
        </Card>
      ))}
      {!groups.size && <p className="text-center text-sm text-muted">Nenhum texto encontrado.</p>}
    </div>
  )
}

/* ----------------------------------------------------------------------------------------------- imagens */
function ImageCard({ slot, max }: { slot: ImageSlot; max: number }) {
  const input = useRef<HTMLInputElement>(null)
  const upload = useAction(
    (file: File) => {
      const fd = new FormData()
      fd.append('file', file)
      return api.upload(`/api/admin/appearance/images/${slot.key}`, fd, 'PUT')
    },
    { invalidate: INVALIDATE, success: 'Imagem atualizada.' },
  )
  const remove = useAction(() => api.del(`/api/admin/appearance/images/${slot.key}`), { invalidate: INVALIDATE })
  return (
    <Card className="flex flex-col">
      <div
        className={clsx(
          'grid h-40 place-items-center overflow-hidden rounded-t-2xl border-b border-border',
          'bg-[conic-gradient(var(--color-elevated)_25%,transparent_0_50%,var(--color-elevated)_0_75%,transparent_0)] bg-[length:16px_16px]',
        )}
      >
        {slot.url ? <img src={slot.url} alt={slot.label} className="max-h-36 max-w-[90%] object-contain" /> : <ImageIcon className="size-8 text-subtle" aria-hidden />}
      </div>
      <CardBody className="flex flex-1 flex-col gap-3">
        <div>
          <p className="font-semibold">{slot.label}</p>
          <p className="mt-0.5 text-sm text-muted">{slot.help}</p>
          {slot.size != null && <p className="mt-1 text-xs text-subtle">{Math.max(1, Math.round(slot.size / 1024))} KB · {slot.content_type}</p>}
        </div>
        <div className="mt-auto flex flex-wrap gap-2">
          <input
            ref={input}
            type="file"
            accept="image/png,image/jpeg,image/webp,image/gif,image/svg+xml,image/x-icon,.ico"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0]
              e.target.value = ''
              if (f) upload.mutate(f)
            }}
          />
          <Button size="sm" icon={<Upload className="size-4" />} loading={upload.isPending} onClick={() => input.current?.click()}>
            {slot.url ? 'Trocar' : 'Carregar'}
          </Button>
          {slot.url && (
            <Button size="sm" variant="ghost" icon={<Trash2 className="size-4" />} loading={remove.isPending} onClick={() => remove.mutate()}>
              Usar a original
            </Button>
          )}
        </div>
        <p className="text-xs text-subtle">PNG, JPG, WebP, GIF, SVG ou ICO, até {Math.round(max / 1024 / 1024)} MB.</p>
      </CardBody>
    </Card>
  )
}

/* ------------------------------------------------------------------------------------------------ emails */
function EmailsTab({ templates }: { templates: EmailTpl[] }) {
  const [sel, setSel] = useState(templates[0]?.id ?? '')
  const tpl = templates.find((t) => t.id === sel) ?? templates[0]
  return (
    <div className="grid gap-6 lg:grid-cols-[240px_1fr]">
      <nav aria-label="Emails" className="lg:sticky lg:top-20 lg:self-start">
        <ul className="flex gap-1.5 overflow-x-auto pb-2 lg:flex-col lg:overflow-visible">
          {templates.map((t) => (
            <li key={t.id} className="shrink-0">
              <button
                type="button"
                onClick={() => setSel(t.id)}
                className={clsx(
                  'flex w-full items-center justify-between gap-2 rounded-xl px-3 py-2 text-left text-sm',
                  t.id === tpl?.id ? 'bg-brand-soft font-semibold text-brand-text' : 'text-muted hover:bg-hover hover:text-fg',
                )}
              >
                {EMAIL_LABELS[t.id] ?? t.id}
                {Object.keys(t.override).length > 0 && <span className="size-1.5 rounded-full bg-brand" aria-label="editado" />}
              </button>
            </li>
          ))}
        </ul>
      </nav>
      {tpl && <EmailEditor key={tpl.id} tpl={tpl} all={templates} />}
    </div>
  )
}

function EmailEditor({ tpl, all }: { tpl: EmailTpl; all: EmailTpl[] }) {
  const fields = ['subject', 'title', 'body', 'cta'] as const
  const [draft, setDraft] = useState(() => Object.fromEntries(fields.map((f) => [f, tpl.override[f] ?? tpl.defaults[f] ?? ''])) as Record<(typeof fields)[number], string>)
  const [preview, setPreview] = useState<{ subject: string; html: string } | null>(null)
  const custom = () => {
    const out: Record<string, string> = {}
    for (const f of fields) if (draft[f].trim() && draft[f] !== (tpl.defaults[f] ?? '')) out[f] = draft[f]
    return out
  }
  const save = useAction(
    (reset: boolean) => {
      const emails: Record<string, Record<string, string>> = {}
      for (const t of all) if (t.id !== tpl.id && Object.keys(t.override).length) emails[t.id] = t.override
      if (!reset) {
        const c = custom()
        if (Object.keys(c).length) emails[tpl.id] = c
      }
      return api.put('/api/admin/appearance/emails', { emails })
    },
    {
      invalidate: [KEY],
      onSuccess: (_r, reset) => {
        if (reset) setDraft(Object.fromEntries(fields.map((f) => [f, tpl.defaults[f] ?? ''])) as typeof draft)
      },
    },
  )
  const doPreview = useAction(() => api.post<{ subject: string; html: string }>(`/api/admin/appearance/emails/${tpl.id}/preview`, custom()), {
    success: false,
    onSuccess: (r) => setPreview(r),
  })
  const label = { subject: 'Assunto', title: 'Título', body: 'Texto (HTML)', cta: 'Texto do botão' }
  return (
    <Card>
      <CardHeader
        icon={<Mail className="size-5" />}
        title={EMAIL_LABELS[tpl.id] ?? tpl.id}
        description="Os textos usam Jinja: {{ variavel }} e {% if variavel %}…{% endif %}. Vazio = original."
        actions={Object.keys(tpl.override).length ? <Badge tone="brand">editado</Badge> : undefined}
      />
      <CardBody className="space-y-4">
        {tpl.variables.length > 0 && (
          <p className="flex flex-wrap items-center gap-1.5 text-xs text-muted">
            Variáveis:
            {[...tpl.variables, 'app_name', 'portal_url'].map((v) => (
              <code key={v} className="rounded-md bg-elevated px-1.5 py-0.5">{`{{ ${v} }}`}</code>
            ))}
          </p>
        )}
        {fields.map((f) =>
          f === 'cta' && tpl.defaults.cta == null ? null : (
            <Field key={f} label={label[f]}>
              {f === 'body' ? (
                <Textarea rows={8} className="font-mono text-[13px]" value={draft[f]} onChange={(e) => setDraft((d) => ({ ...d, [f]: e.target.value }))} />
              ) : (
                <Input value={draft[f]} onChange={(e) => setDraft((d) => ({ ...d, [f]: e.target.value }))} />
              )}
            </Field>
          ),
        )}
        <div className="flex flex-wrap gap-2">
          <Button icon={<Save className="size-4" />} loading={save.isPending && save.variables === false} onClick={() => save.mutate(false)}>
            Guardar
          </Button>
          <Button variant="secondary" icon={<Eye className="size-4" />} loading={doPreview.isPending} onClick={() => doPreview.mutate()}>
            Pré-visualizar
          </Button>
          {Object.keys(tpl.override).length > 0 && (
            <Button variant="ghost" icon={<RotateCcw className="size-4" />} loading={save.isPending && save.variables === true} onClick={() => save.mutate(true)}>
              Voltar ao original
            </Button>
          )}
        </div>
        {preview && (
          <div className="space-y-2">
            <p className="text-sm">
              <span className="text-muted">Assunto:</span> <b>{preview.subject}</b>
            </p>
            {/* sandbox sem permissões: o HTML do email nunca corre scripts nem navega */}
            <iframe title="Pré-visualização do email" sandbox="" srcDoc={preview.html} className="h-[520px] w-full rounded-xl border border-border bg-white" />
          </div>
        )}
      </CardBody>
    </Card>
  )
}

/* ------------------------------------------------------------------------------------------------ página */
export default function AdminAppearance() {
  const [params, setParams] = useSearchParams()
  const tab = (['textos', 'imagens', 'emails'] as const).find((t) => t === params.get('tab')) ?? 'textos'
  const q = useQuery({ queryKey: KEY, queryFn: () => api.get<AppearanceOut>('/api/admin/appearance') })
  return (
    <div>
      <PageHeader
        eyebrow="Administração"
        title="Aparência"
        description="Os textos e as imagens do site e do portal, e os emails que os clientes recebem — sem mexer no código."
        actions={
          <ButtonLink to="/admin/definicoes?tab=site" variant="secondary">
            Anúncio, FAQ e links
          </ButtonLink>
        }
      />
      <Tabs
        className="mb-6"
        ariaLabel="Aparência"
        value={tab}
        onChange={(id) => setParams({ tab: id }, { replace: true })}
        items={[
          { id: 'textos', label: <span className="inline-flex items-center gap-1.5"><Type className="size-4" aria-hidden /> Textos</span> },
          { id: 'imagens', label: <span className="inline-flex items-center gap-1.5"><ImageIcon className="size-4" aria-hidden /> Imagens</span> },
          { id: 'emails', label: <span className="inline-flex items-center gap-1.5"><Mail className="size-4" aria-hidden /> Emails</span> },
        ]}
      />
      {q.isError ? (
        <Alert tone="danger">{errorMessage(q.error)}</Alert>
      ) : !q.data ? (
        <SkeletonCard lines={8} />
      ) : tab === 'textos' ? (
        <TextsTab saved={q.data.texts} />
      ) : tab === 'imagens' ? (
        <div className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
            {q.data.images.map((s) => (
              <ImageCard key={s.key} slot={s} max={q.data.max_image_bytes} />
            ))}
          </div>
          <Alert tone="info">As imagens de cada serviço carregam-se em Produtos &amp; planos → produto → Imagem.</Alert>
        </div>
      ) : (
        <EmailsTab templates={q.data.emails} />
      )}
    </div>
  )
}
