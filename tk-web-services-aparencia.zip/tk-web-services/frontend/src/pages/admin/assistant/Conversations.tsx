import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import { ChevronRight, MessagesSquare, ThumbsDown, X } from 'lucide-react'
import { errorMessage } from '../../../api/client'
import { useAdminConversations } from '../../../api/assistant'
import { Alert, Badge, Card, Checkbox, EmptyState, Pagination, Pills, Select, SkeletonRows, Table, Td, Th, THead, Tr } from '../../../components/ui'
import { AgentBadge, CHANNEL_LABEL, ConvStatusBadge } from '../../../components/assistant/labels'
import { relativeTime } from '../../../lib/format'
import { AssistantHeader } from './shared'

export default function AssistantConversationsPage() {
  const [params, setParams] = useSearchParams()
  const navigate = useNavigate()
  const status = params.get('status') ?? ''
  const agent = params.get('agent') ?? ''
  const channel = params.get('channel') ?? ''
  const negative = params.get('negative') === '1'
  const userId = params.get('user_id') ?? ''
  const page = Math.max(1, Number(params.get('page') ?? 1) || 1)
  const q = useAdminConversations({
    status: status || undefined,
    agent: agent || undefined,
    channel: channel || undefined,
    negative,
    user_id: userId || undefined,
    page,
  })

  const set = (k: string, v: string) => {
    const next = new URLSearchParams(params)
    if (v) next.set(k, v)
    else next.delete(k)
    if (k !== 'page') next.delete('page')
    setParams(next, { replace: true })
  }

  const rows = q.data ?? []
  const username = userId ? rows.find((r) => r.username)?.username : null

  return (
    <div>
      <AssistantHeader title="Conversas" description="Todas as conversas com os agentes, em todos os canais. Revê as escaladas e as respostas com 👎 para melhorar o conhecimento." />
      <Card className="overflow-hidden">
        <div className="space-y-3 px-5 pt-5 sm:px-6">
          <Pills
            ariaLabel="Estado"
            value={status}
            onChange={(v) => set('status', v)}
            items={[
              { value: '', label: 'Todas' },
              { value: 'escalated', label: 'Escaladas' },
              { value: 'open', label: 'Abertas' },
              { value: 'resolved', label: 'Resolvidas' },
              { value: 'closed', label: 'Fechadas' },
            ]}
          />
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
            <div className="grid flex-1 grid-cols-2 gap-3 sm:max-w-md">
              <Select aria-label="Agente" value={agent} onChange={(e) => set('agent', e.target.value)} className="h-10">
                <option value="">Todos os agentes</option>
                <option value="billing">Faturação</option>
                <option value="support">Suporte</option>
              </Select>
              <Select aria-label="Canal" value={channel} onChange={(e) => set('channel', e.target.value)} className="h-10">
                <option value="">Todos os canais</option>
                {Object.entries(CHANNEL_LABEL).map(([k, v]) => (
                  <option key={k} value={k}>
                    {v}
                  </option>
                ))}
              </Select>
            </div>
            <Checkbox label="Só com 👎" checked={negative} onChange={(e) => set('negative', e.target.checked ? '1' : '')} />
            {userId && (
              <button
                type="button"
                onClick={() => set('user_id', '')}
                className="inline-flex items-center gap-1.5 self-start rounded-full border border-brand bg-brand-soft px-3 py-1.5 text-[13px] font-medium text-brand-text hover:bg-brand/20 sm:ml-auto sm:self-auto"
              >
                Cliente: {username ?? userId.slice(0, 8)} <X className="size-3.5" aria-label="Remover filtro" />
              </button>
            )}
          </div>
        </div>
        <div className="mt-4 border-t border-border">
          {q.isError ? (
            <div className="p-5">
              <Alert tone="danger">{errorMessage(q.error)}</Alert>
            </div>
          ) : q.isLoading ? (
            <SkeletonRows rows={5} />
          ) : !rows.length ? (
            <EmptyState compact icon={<MessagesSquare className="size-6" />} title="Sem conversas" description="Nenhuma conversa corresponde a estes filtros." />
          ) : (
            <Table minWidth={860}>
              <THead>
                <Th>Conversa</Th>
                <Th>Cliente</Th>
                <Th>Canal</Th>
                <Th>Agente</Th>
                <Th>Estado</Th>
                <Th className="text-right">Msgs</Th>
                <Th>Atualizada</Th>
                <Th>
                  <span className="sr-only">Abrir</span>
                </Th>
              </THead>
              <tbody>
                {rows.map((c) => (
                  <Tr key={c.id} onClick={() => navigate(`/admin/assistente/conversas/${c.id}`)}>
                    <Td className="max-w-[22rem]">
                      <Link to={`/admin/assistente/conversas/${c.id}`} className="block truncate font-medium hover:underline" onClick={(e) => e.stopPropagation()}>
                        {c.title || 'Sem título'}
                      </Link>
                      {c.escalation ? (
                        <p className="mt-0.5 truncate text-xs text-warning">⚑ {c.escalation}</p>
                      ) : c.admin_note ? (
                        <p className="mt-0.5 truncate text-xs text-muted">Nota: {c.admin_note}</p>
                      ) : null}
                    </Td>
                    <Td className="whitespace-nowrap">{c.username ? <span className="font-medium">@{c.username}</span> : <span className="text-subtle">—</span>}</Td>
                    <Td>
                      <Badge>{CHANNEL_LABEL[c.channel] ?? c.channel}</Badge>
                    </Td>
                    <Td>
                      <AgentBadge agent={c.agent} />
                    </Td>
                    <Td>
                      <ConvStatusBadge status={c.status} />
                    </Td>
                    <Td className="text-right tabular-nums">
                      <span className="inline-flex items-center gap-2">
                        {c.negative > 0 && (
                          <span className="inline-flex items-center gap-0.5 text-xs font-semibold text-danger" title={`${c.negative} respostas com 👎`}>
                            <ThumbsDown className="size-3.5" aria-hidden /> {c.negative}
                          </span>
                        )}
                        {c.user_messages}
                      </span>
                    </Td>
                    <Td className="whitespace-nowrap text-muted">{relativeTime(c.updated_at ?? c.created_at)}</Td>
                    <Td className="w-8 text-subtle">
                      <ChevronRight className="size-4" aria-hidden />
                    </Td>
                  </Tr>
                ))}
              </tbody>
            </Table>
          )}
        </div>
        <Pagination page={page} size={50} hasNext={rows.length === 50} onPage={(p) => set('page', String(p))} />
      </Card>
    </div>
  )
}
