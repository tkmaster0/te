import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import clsx from 'clsx'
import {
  AlertTriangle,
  ArrowLeft,
  ArrowRightLeft,
  BookPlus,
  ChevronRight,
  Coins,
  EyeOff,
  ShieldQuestion,
  Sparkles,
  StickyNote,
  ThumbsDown,
  ThumbsUp,
  User,
  Wrench,
} from 'lucide-react'
import { api, errorMessage } from '../../../api/client'
import { akeys, useAdminConversation, type AdminChatMessage, type AdminConversationDetail, type KnowledgeItem } from '../../../api/assistant'
import { useAction } from '../../../api/mutation'
import { Alert, Badge, Button, Card, CardHeader, DateText, EmptyState, Field, Input, Modal, Select, Skeleton, Textarea, useToast } from '../../../components/ui'
import { ACTION_STATUS, AGENT_LABEL, AgentBadge, AgentIcon, CHANNEL_LABEL, ConvStatusBadge } from '../../../components/assistant/labels'
import { Markdown } from '../../../components/assistant/Markdown'
import { Code, formatTokens, Pre } from './shared'

function prettyJson(v: unknown): string {
  try {
    return JSON.stringify(v, null, 2)
  } catch {
    return String(v)
  }
}

function prettyToolResult(text: string | null): string {
  if (!text) return '—'
  try {
    return JSON.stringify(JSON.parse(text), null, 2)
  } catch {
    return text
  }
}

// ------------------------------------------------------------------ transcrição
function Meta({ m }: { m: AdminChatMessage }) {
  const bits = [m.model, m.tokens_in != null || m.tokens_out != null ? `${m.tokens_in ?? 0} → ${m.tokens_out ?? 0} tokens` : null].filter(Boolean)
  return (
    <p className="mt-1 flex flex-wrap items-center gap-x-2 text-[11px] text-subtle">
      <DateText value={m.created_at} withTime />
      {bits.map((b) => (
        <span key={b}>· {b}</span>
      ))}
    </p>
  )
}

function ToolCalls({ m }: { m: AdminChatMessage }) {
  if (!m.tool_calls?.length) return null
  return (
    <div className="mt-2 space-y-1.5">
      {m.tool_calls.map((c) => (
        <details key={c.id} className="group rounded-xl border border-border bg-bg/60">
          <summary className="flex cursor-pointer items-center gap-2 px-3 py-2 text-xs">
            <ChevronRight className="size-3.5 text-subtle transition-transform group-open:rotate-90" aria-hidden />
            <Wrench className="size-3.5 text-info" aria-hidden />
            <span className="text-muted">Chamou</span> <Code>{c.name}</Code>
          </summary>
          <Pre className="mx-3 mb-3 max-h-60">{prettyJson(c.arguments)}</Pre>
        </details>
      ))}
    </div>
  )
}

function ToolResult({ m }: { m: AdminChatMessage }) {
  const error = (m.content ?? '').startsWith('Erro')
  return (
    <li className="pl-10">
      <details className="group rounded-xl border border-border bg-surface">
        <summary className="flex cursor-pointer items-center gap-2 px-3 py-2 text-xs">
          <ChevronRight className="size-3.5 text-subtle transition-transform group-open:rotate-90" aria-hidden />
          <span className={clsx('size-1.5 rounded-full', error ? 'bg-danger' : 'bg-success')} aria-hidden />
          <span className="text-muted">Resultado de</span> <Code>{m.tool_name ?? 'ferramenta'}</Code>
          <span className="ml-auto truncate text-subtle">{(m.content ?? '').length.toLocaleString('pt-PT')} car.</span>
        </summary>
        <Pre className="mx-3 mb-3 max-h-80">{prettyToolResult(m.content)}</Pre>
      </details>
    </li>
  )
}

function Transcript({ conv, onPromote }: { conv: AdminConversationDetail; onPromote: (m: AdminChatMessage) => void }) {
  if (!conv.messages.length) return <EmptyState compact title="Sem mensagens" />
  return (
    <ol className="space-y-3">
      {conv.messages.map((m) => {
        if (m.role === 'tool') return <ToolResult key={m.id} m={m} />
        if (m.role === 'event' && m.ui?.type === 'agent_switch')
          return (
            <li key={m.id} className="flex items-center gap-3 py-1">
              <span className="h-px flex-1 bg-border" aria-hidden />
              <span className="inline-flex items-center gap-1.5 text-xs font-medium text-muted">
                <ArrowRightLeft className="size-3.5" aria-hidden /> {m.content}
                {m.ui.reason === 'transfer' ? ' (transferência)' : ' (encaminhamento automático)'}
              </span>
              <span className="h-px flex-1 bg-border" aria-hidden />
            </li>
          )
        if (m.role === 'event' && m.ui?.type === 'confirm') {
          const st = ACTION_STATUS[m.ui.status ?? 'pending'] ?? ACTION_STATUS.pending
          return (
            <li key={m.id} className="pl-10">
              <div className="rounded-xl border border-brand/40 bg-brand-soft/40 p-3">
                <p className="flex flex-wrap items-center gap-2 text-xs font-semibold text-brand-text">
                  <ShieldQuestion className="size-4" aria-hidden /> Pedido de confirmação ao cliente
                  <Badge tone={st.tone} dot>
                    {st.label}
                  </Badge>
                </p>
                <p className="mt-1 text-sm">{m.ui.summary ?? m.content}</p>
              </div>
            </li>
          )
        }
        if (m.role === 'event')
          return (
            <li key={m.id} className="text-center text-xs text-muted">
              {m.content}
            </li>
          )
        if (m.role === 'user') {
          const hidden = !!m.ui?.hidden
          return (
            <li key={m.id} className={clsx('flex gap-2.5', hidden && 'opacity-70')}>
              <span className="mt-0.5 grid size-8 shrink-0 place-items-center rounded-full bg-elevated text-muted" aria-hidden>
                {hidden ? <EyeOff className="size-4" /> : <User className="size-4" />}
              </span>
              <div className="min-w-0 flex-1">
                <p className="mb-1 text-xs font-semibold text-muted">
                  {hidden ? 'Nota interna (o cliente não vê)' : 'Cliente'} · <span className="font-normal">{AGENT_LABEL[m.agent] ?? m.agent}</span>
                </p>
                <div className={clsx('whitespace-pre-wrap break-words rounded-2xl rounded-tl-md px-3.5 py-2 text-sm [overflow-wrap:anywhere]', hidden ? 'border border-dashed border-border' : 'bg-brand-soft text-fg')}>
                  {m.content}
                </div>
                <Meta m={m} />
              </div>
            </li>
          )
        }
        // assistant
        return (
          <li key={m.id} className="flex gap-2.5">
            <span
              className={clsx('mt-0.5 grid size-8 shrink-0 place-items-center rounded-full', m.agent === 'billing' ? 'bg-brand-soft text-brand-text' : 'bg-info-soft text-info')}
              aria-hidden
            >
              <AgentIcon agent={m.agent} className="size-4" />
            </span>
            <div className="min-w-0 flex-1">
              <div className="mb-1 flex flex-wrap items-center gap-2">
                <AgentBadge agent={m.agent} />
                {m.feedback === 1 && (
                  <Badge tone="success">
                    <span className="inline-flex items-center gap-1">
                      <ThumbsUp className="size-3" aria-hidden /> Útil
                    </span>
                  </Badge>
                )}
                {m.feedback === -1 && (
                  <Badge tone="danger">
                    <span className="inline-flex items-center gap-1">
                      <ThumbsDown className="size-3" aria-hidden /> Pouco útil
                    </span>
                  </Badge>
                )}
                {m.ui?.type === 'action_result' && <Badge tone={m.ui.status === 'failed' ? 'danger' : 'success'}>Resultado da ação</Badge>}
              </div>
              {m.content ? (
                <div className={clsx('rounded-2xl rounded-tl-md border bg-elevated px-3.5 py-2.5 text-sm leading-relaxed', m.feedback === -1 ? 'border-danger/40' : 'border-border')}>
                  <Markdown text={m.content} />
                </div>
              ) : (
                <p className="text-xs italic text-subtle">(sem texto — só chamadas a ferramentas)</p>
              )}
              {m.feedback_note && <p className="mt-1 text-xs text-danger">Comentário do cliente: «{m.feedback_note}»</p>}
              <ToolCalls m={m} />
              <div className="flex flex-wrap items-center justify-between gap-2">
                <Meta m={m} />
                {m.content && (
                  <button type="button" onClick={() => onPromote(m)} className="mt-1 inline-flex items-center gap-1 text-xs font-semibold text-brand-text hover:underline">
                    <BookPlus className="size-3.5" aria-hidden /> Promover a conhecimento
                  </button>
                )}
              </div>
            </div>
          </li>
        )
      })}
    </ol>
  )
}

// ------------------------------------------------------------------ promover
function PromoteDialog({ conv, msg, onClose }: { conv: AdminConversationDetail; msg: AdminChatMessage | null; onClose: () => void }) {
  const [title, setTitle] = useState('')
  const [content, setContent] = useState('')
  useEffect(() => {
    if (!msg) return
    const idx = conv.messages.findIndex((x) => x.id === msg.id)
    const question = [...conv.messages.slice(0, idx)].reverse().find((x) => x.role === 'user' && !x.ui?.hidden)
    const qText = (question?.content ?? '').split('\n\n[Nota interna')[0].trim()
    setTitle(qText.slice(0, 200))
    setContent(qText ? `Pergunta: ${qText}\n\nResposta aprovada:\n${msg.content ?? ''}` : (msg.content ?? ''))
  }, [msg, conv.messages])
  const promote = useAction(() => api.post<KnowledgeItem>(`/api/admin/assistant/messages/${msg?.id}/promote`, { title: title.trim() || null, content: content.trim() || null }), {
    invalidate: [akeys.knowledge, akeys.agents, akeys.overview],
    success: 'Resposta promovida — o agente já a usa.',
    errorTitle: 'Não foi possível promover',
    onSuccess: onClose,
  })
  return (
    <Modal
      open={!!msg}
      onClose={onClose}
      size="lg"
      title="Promover a conhecimento"
      description={
        <>
          Cria um artigo ativo para o Agente de <strong className="text-fg">{AGENT_LABEL[msg?.agent ?? ''] ?? msg?.agent}</strong>. Corrige o texto se a resposta não estava
          perfeita e retira dados pessoais.
        </>
      }
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancelar
          </Button>
          <Button icon={<BookPlus className="size-4" />} loading={promote.isPending} disabled={content.trim().length < 3} onClick={() => promote.mutate()}>
            Promover
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        <Field label="Título">
          <Input value={title} onChange={(e) => setTitle(e.target.value)} maxLength={200} />
        </Field>
        <Field label="Conteúdo" hint={`${content.length.toLocaleString('pt-PT')} / 8000`}>
          <Textarea value={content} onChange={(e) => setContent(e.target.value)} rows={12} maxLength={8000} />
        </Field>
      </div>
    </Modal>
  )
}

// ------------------------------------------------------------------ lateral
function ManageCard({ conv }: { conv: AdminConversationDetail }) {
  const [status, setStatus] = useState(conv.status)
  const [note, setNote] = useState(conv.admin_note ?? '')
  useEffect(() => {
    setStatus(conv.status)
    setNote(conv.admin_note ?? '')
  }, [conv.status, conv.admin_note])
  const inv = [akeys.conv(conv.id), akeys.convs, akeys.overview]
  const patch = useAction((body: { status?: string; admin_note?: string }) => api.patch(`/api/admin/assistant/conversations/${conv.id}`, body), {
    invalidate: inv,
    success: (_r, b) => (b.status ? 'Estado atualizado.' : 'Nota guardada.'),
  })
  return (
    <Card>
      <CardHeader icon={<StickyNote className="size-5" />} title="Gestão" />
      <div className="space-y-4 px-5 pb-5 pt-4 sm:px-6">
        <div className="flex items-end gap-2">
          <Field label="Estado" className="flex-1">
            <Select value={status} onChange={(e) => setStatus(e.target.value)}>
              <option value="open">Aberta</option>
              <option value="escalated">Escalada</option>
              <option value="resolved">Resolvida</option>
              <option value="closed">Fechada</option>
            </Select>
          </Field>
          <Button variant="secondary" disabled={status === conv.status} loading={patch.isPending && !!patch.variables?.status} onClick={() => patch.mutate({ status })}>
            Aplicar
          </Button>
        </div>
        <Field label="Nota do administrador" hint="Fica só no painel. Uma nota nova volta a permitir gerar conhecimento desta conversa.">
          <Textarea value={note} onChange={(e) => setNote(e.target.value)} rows={4} maxLength={4000} placeholder="ex.: A resposta certa era pedir o Quick Connect na app da TV." />
        </Field>
        <div className="flex justify-end">
          <Button size="sm" disabled={note === (conv.admin_note ?? '')} loading={patch.isPending && patch.variables?.admin_note !== undefined} onClick={() => patch.mutate({ admin_note: note })}>
            Guardar nota
          </Button>
        </div>
      </div>
    </Card>
  )
}

function LearnCard({ conv }: { conv: AdminConversationDetail }) {
  const toast = useToast()
  const [created, setCreated] = useState<KnowledgeItem[] | null>(null)
  const suggest = useAction(() => api.post<KnowledgeItem[]>(`/api/admin/assistant/conversations/${conv.id}/suggest`), {
    invalidate: [akeys.knowledge, akeys.overview, akeys.conv(conv.id)],
    success: false,
    errorTitle: 'Não foi possível gerar a sugestão',
    onSuccess: (items) => {
      setCreated(items)
      if (!items.length) toast.info('Nada de reutilizável nesta conversa.', 'O modelo não encontrou conhecimento novo para sugerir.')
      else toast.success(items.length === 1 ? '1 sugestão criada.' : `${items.length} sugestões criadas.`)
    },
  })
  return (
    <Card className="p-5 sm:p-6">
      <p className="flex items-center gap-2 text-sm font-semibold">
        <Sparkles className="size-4 text-brand-text" aria-hidden /> Aprender com esta conversa
      </p>
      <p className="mt-1 text-xs text-muted">
        O modelo resume a conversa (e a tua nota) num rascunho por agente. Só entra em uso depois de o aprovares.
        {conv.reviewed && ' Esta conversa já foi analisada.'}
      </p>
      <Button className="mt-3 w-full" variant="secondary" icon={<Sparkles className="size-4" />} loading={suggest.isPending} onClick={() => suggest.mutate()}>
        Gerar sugestão de conhecimento
      </Button>
      {!!created?.length && (
        <ul className="mt-3 space-y-1.5">
          {created.map((k) => (
            <li key={k.id} className="flex items-center gap-2 text-xs">
              <AgentBadge agent={k.agent} />
              <Link to="/admin/assistente/conhecimento?status=draft" className="min-w-0 flex-1 truncate font-medium hover:underline">
                {k.title}
              </Link>
            </li>
          ))}
        </ul>
      )}
    </Card>
  )
}

export default function AssistantConversationPage() {
  const { id = '' } = useParams()
  const q = useAdminConversation(id)
  const [promoting, setPromoting] = useState<AdminChatMessage | null>(null)
  const c = q.data
  const tokens = (c?.messages ?? []).reduce((acc, m) => ({ in: acc.in + (m.tokens_in ?? 0), out: acc.out + (m.tokens_out ?? 0) }), { in: 0, out: 0 })
  const toolCalls = (c?.messages ?? []).reduce((n, m) => n + (m.tool_calls?.length ?? 0), 0)

  return (
    <div>
      <Link to="/admin/assistente/conversas" className="mb-4 inline-flex items-center gap-1.5 text-sm font-medium text-muted hover:text-fg">
        <ArrowLeft className="size-4" aria-hidden /> Conversas
      </Link>
      {q.isError ? (
        <Alert tone="danger" title="Não foi possível carregar a conversa">
          {errorMessage(q.error)}
        </Alert>
      ) : q.isLoading || !c ? (
        <Skeleton className="h-96 rounded-2xl" />
      ) : (
        <>
          <header className="mb-6">
            <p className="mb-1.5 text-xs font-semibold uppercase tracking-wider text-brand-text">Conversa · {CHANNEL_LABEL[c.channel] ?? c.channel}</p>
            <h1 className="text-xl font-bold tracking-tight sm:text-2xl">{c.title || 'Sem título'}</h1>
            <div className="mt-2 flex flex-wrap items-center gap-2 text-sm text-muted">
              <ConvStatusBadge status={c.status} />
              <AgentBadge agent={c.agent} />
              {c.user_id ? (
                <Link to={`/admin/utilizadores/${c.user_id}`} className="inline-flex items-center gap-1 font-medium text-fg hover:underline">
                  <User className="size-3.5" aria-hidden /> @{c.username ?? c.user_id.slice(0, 8)}
                </Link>
              ) : (
                <span>Sem conta associada</span>
              )}
              {c.external_ref && <span className="font-mono text-xs">{c.channel === 'seerr' ? `Issue #${c.external_ref}` : c.external_ref}</span>}
              <span>
                · iniciada <DateText value={c.created_at} withTime />
              </span>
            </div>
          </header>

          <div className="grid grid-cols-1 items-start gap-4 xl:grid-cols-[1fr_360px]">
            <Card className="min-w-0 p-4 sm:p-6">
              <Transcript conv={c} onPromote={setPromoting} />
            </Card>
            <div className="space-y-4">
              {c.meta?.escalation && (
                <Alert tone="warning" icon={<AlertTriangle />} title={`Escalada${c.meta.urgency === 'high' ? ' · urgente' : ''}`}>
                  {c.meta.escalation}
                </Alert>
              )}
              <ManageCard conv={c} />
              <Card className="overflow-hidden">
                <CardHeader icon={<ShieldQuestion className="size-5" />} title="Ações pedidas" description="Alterações que precisaram da confirmação do cliente." />
                {!c.actions.length ? (
                  <p className="px-5 pb-5 pt-3 text-sm text-muted sm:px-6">Nenhuma.</p>
                ) : (
                  <ul className="mt-4 divide-y divide-border border-t border-border">
                    {c.actions.map((a) => {
                      const st = ACTION_STATUS[a.status] ?? { label: a.status, tone: 'neutral' as const }
                      return (
                        <li key={a.id} className="px-5 py-3 sm:px-6">
                          <div className="flex flex-wrap items-center gap-2">
                            <Code>{a.tool}</Code>
                            <Badge tone={st.tone} dot>
                              {st.label}
                            </Badge>
                          </div>
                          <p className="mt-1 text-sm">{a.summary}</p>
                          {a.result && <p className="mt-1 text-xs text-muted">Resultado: {a.result}</p>}
                          <p className="mt-0.5 text-[11px] text-subtle">
                            <DateText value={a.created_at} withTime />
                          </p>
                        </li>
                      )
                    })}
                  </ul>
                )}
              </Card>
              <Card className="p-5 sm:p-6">
                <p className="flex items-center gap-2 text-sm font-semibold">
                  <Coins className="size-4 text-brand-text" aria-hidden /> Consumo
                </p>
                <dl className="mt-3 grid grid-cols-3 gap-3 text-sm">
                  <div>
                    <dt className="text-xs text-muted">Entrada</dt>
                    <dd className="font-semibold tabular-nums">{formatTokens(tokens.in)}</dd>
                  </div>
                  <div>
                    <dt className="text-xs text-muted">Saída</dt>
                    <dd className="font-semibold tabular-nums">{formatTokens(tokens.out)}</dd>
                  </div>
                  <div>
                    <dt className="text-xs text-muted">Ferramentas</dt>
                    <dd className="font-semibold tabular-nums">{toolCalls}</dd>
                  </div>
                </dl>
              </Card>
              <LearnCard conv={c} />
            </div>
          </div>
          <PromoteDialog conv={c} msg={promoting} onClose={() => setPromoting(null)} />
        </>
      )}
    </div>
  )
}
