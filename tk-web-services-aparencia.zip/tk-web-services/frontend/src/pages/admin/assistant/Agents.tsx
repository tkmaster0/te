import { useEffect, useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { BookOpen, ChevronDown, History, Lock, PencilLine, RotateCcw, ShieldQuestion, Wrench } from 'lucide-react'
import { api, errorMessage } from '../../../api/client'
import { akeys, useAssistantAgents, type AgentInfo } from '../../../api/assistant'
import { useAction } from '../../../api/mutation'
import { Alert, Badge, Button, Card, CardHeader, DateText, Field, Input, Skeleton, Tabs, Textarea, useConfirm } from '../../../components/ui'
import { AgentIcon, CHANNEL_LABEL } from '../../../components/assistant/labels'
import { AssistantHeader, Code, Pre } from './shared'

function RulesCard({ a }: { a: AgentInfo }) {
  return (
    <Card>
      <CardHeader
        icon={<Lock className="size-5" />}
        title={
          <span className="flex flex-wrap items-center gap-2">
            Regras fixas <Badge>Só de leitura</Badge>
          </span>
        }
        description={
          <>
            Vivem no código e são aplicadas <strong className="text-fg">sempre antes</strong> das tuas instruções. Garantem a separação: o Agente de {a.label} só trata do seu
            tema, só vê e usa as suas ferramentas e o seu conhecimento, e nunca altera a conta sem confirmação do cliente. Nem tu nem o cliente as conseguem mudar por
            engano.
          </>
        }
      />
      <div className="px-5 pb-5 pt-4 sm:px-6">
        <details className="group">
          <summary className="inline-flex cursor-pointer items-center gap-1.5 text-sm font-semibold text-brand-text">
            <ChevronDown className="size-4 transition-transform group-open:rotate-180" aria-hidden />
            <span className="group-open:hidden">Ver as regras</span>
            <span className="hidden group-open:inline">Esconder as regras</span>
          </summary>
          <Pre className="mt-3 max-h-96">{a.rules}</Pre>
        </details>
      </div>
    </Card>
  )
}

function InstructionsCard({ a }: { a: AgentInfo }) {
  const confirm = useConfirm()
  const [text, setText] = useState(a.instructions)
  const [note, setNote] = useState('')
  const active = a.versions.find((v) => v.active)
  useEffect(() => setText(a.instructions), [a.instructions])
  const dirty = text.trim() !== a.instructions.trim()

  const save = useAction(() => api.post<{ version: number }>(`/api/admin/assistant/agents/${a.name}/instructions`, { content: text.trim(), note: note.trim() || null }), {
    invalidate: [akeys.agents],
    success: (r) => `Instruções guardadas (versão ${r.version}).`,
    errorTitle: 'Não foi possível guardar',
    onSuccess: () => setNote(''),
  })
  const reset = useAction(() => api.post(`/api/admin/assistant/agents/${a.name}/instructions/reset`), {
    invalidate: [akeys.agents],
    success: 'Instruções repostas para a predefinição.',
  })

  return (
    <Card>
      <CardHeader
        icon={<PencilLine className="size-5" />}
        title={
          <span className="flex flex-wrap items-center gap-2">
            Instruções {active ? <Badge tone="brand">Versão {active.version} ativa</Badge> : <Badge>Predefinição</Badge>}
          </span>
        }
        description="Tom, procedimentos, exceções da casa. Cada gravação cria uma versão nova — podes voltar atrás a qualquer momento."
        actions={
          active && (
            <Button
              size="sm"
              variant="ghost"
              icon={<RotateCcw className="size-4" />}
              loading={reset.isPending}
              onClick={async () => {
                if (
                  await confirm({
                    title: 'Repor a predefinição?',
                    message: 'O agente volta a usar as instruções de origem. As tuas versões ficam no histórico.',
                    confirmLabel: 'Repor predefinição',
                  })
                )
                  reset.mutate()
              }}
            >
              Repor predefinição
            </Button>
          )
        }
      />
      <form
        className="space-y-4 px-5 pb-5 pt-4 sm:px-6"
        onSubmit={(e) => {
          e.preventDefault()
          save.mutate()
        }}
      >
        <Field label="Instruções do administrador" hint={`${text.length.toLocaleString('pt-PT')} / 20 000 caracteres`}>
          <Textarea value={text} onChange={(e) => setText(e.target.value)} rows={14} maxLength={20000} className="font-mono text-[13px]" />
        </Field>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
          <Field label="Nota da versão" optional className="flex-1">
            <Input value={note} onChange={(e) => setNote(e.target.value)} maxLength={200} placeholder="ex.: explicar melhor o Quick Connect" />
          </Field>
          <div className="flex gap-2">
            {dirty && (
              <Button variant="secondary" onClick={() => setText(a.instructions)}>
                Descartar
              </Button>
            )}
            <Button type="submit" loading={save.isPending} disabled={!dirty || !text.trim()}>
              Guardar nova versão
            </Button>
          </div>
        </div>
      </form>
    </Card>
  )
}

function VersionsCard({ a }: { a: AgentInfo }) {
  const confirm = useConfirm()
  const activate = useAction((id: number) => api.post(`/api/admin/assistant/agents/${a.name}/instructions/${id}/activate`), {
    invalidate: [akeys.agents],
    success: 'Versão ativada.',
  })
  return (
    <Card className="overflow-hidden">
      <CardHeader icon={<History className="size-5" />} title="Histórico de versões" description={a.versions.length ? `${a.versions.length} versões guardadas` : undefined} />
      {!a.versions.length ? (
        <p className="px-5 pb-5 pt-3 text-sm text-muted sm:px-6">Ainda não há versões — o agente usa as instruções predefinidas.</p>
      ) : (
        <ul className="mt-4 divide-y divide-border border-t border-border">
          {a.versions.map((v) => (
            <li key={v.id} className="px-5 py-3 sm:px-6">
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-mono text-sm font-semibold">v{v.version}</span>
                {v.active && (
                  <Badge tone="success" dot>
                    Ativa
                  </Badge>
                )}
                <span className="min-w-0 flex-1 truncate text-sm text-muted">{v.note || 'Sem nota'}</span>
                {!v.active && (
                  <Button
                    size="sm"
                    variant="secondary"
                    loading={activate.isPending && activate.variables === v.id}
                    onClick={async () => {
                      if (await confirm({ title: `Ativar a versão ${v.version}?`, message: 'O agente passa a usar estas instruções a partir da próxima mensagem.', confirmLabel: 'Ativar' }))
                        activate.mutate(v.id)
                    }}
                  >
                    Ativar
                  </Button>
                )}
              </div>
              <p className="mt-0.5 text-xs text-subtle">
                {v.created_by ?? '—'} · <DateText value={v.created_at} withTime />
              </p>
              <details className="mt-1.5">
                <summary className="cursor-pointer text-xs font-semibold text-brand-text">Ver conteúdo</summary>
                <Pre className="mt-2 max-h-64">{v.content}</Pre>
              </details>
            </li>
          ))}
        </ul>
      )}
    </Card>
  )
}

function ToolsCard({ a }: { a: AgentInfo }) {
  const confirmCount = a.tools.filter((t) => t.confirm).length
  return (
    <Card className="overflow-hidden">
      <CardHeader
        icon={<Wrench className="size-5" />}
        title="Ferramentas"
        description={`${a.tools.length} ferramentas · ${confirmCount === 1 ? '1 só avança' : `${confirmCount} só avançam`} com a confirmação do cliente`}
      />
      <ul className="mt-4 divide-y divide-border border-t border-border">
        {a.tools.map((t) => (
          <li key={t.name} className="px-5 py-3 sm:px-6">
            <div className="flex flex-wrap items-center gap-2">
              <Code>{t.name}</Code>
              {t.confirm && (
                <Badge tone="warning">
                  <span className="inline-flex items-center gap-1">
                    <ShieldQuestion className="size-3" aria-hidden /> pede confirmação
                  </span>
                </Badge>
              )}
              {t.channels && <Badge>só {t.channels.map((c) => CHANNEL_LABEL[c] ?? c).join(', ')}</Badge>}
            </div>
            <p className="mt-1 text-sm text-muted">{t.description}</p>
          </li>
        ))}
      </ul>
    </Card>
  )
}

export default function AssistantAgentsPage() {
  const q = useAssistantAgents()
  const [params, setParams] = useSearchParams()
  const agents = q.data ?? []
  const current = agents.find((a) => a.name === params.get('agente')) ?? agents[0]

  return (
    <div>
      <AssistantHeader title="Agentes" description="Cada agente tem regras fixas, instruções editáveis, ferramentas e conhecimento próprios — nada é partilhado entre eles." />
      {q.isError && <Alert tone="danger" title="Não foi possível carregar">{errorMessage(q.error)}</Alert>}
      {q.isLoading ? (
        <Skeleton className="h-96 rounded-2xl" />
      ) : (
        current && (
          <>
            <Tabs
              ariaLabel="Agente"
              className="mb-5"
              value={current.name}
              onChange={(id) => setParams({ agente: id }, { replace: true })}
              items={agents.map((a) => ({
                id: a.name,
                label: (
                  <span className="inline-flex items-center gap-1.5">
                    <AgentIcon agent={a.name} className="size-4" /> {a.label}
                  </span>
                ),
              }))}
            />
            <div className="grid grid-cols-1 items-start gap-4 xl:grid-cols-[1fr_400px]" role="tabpanel">
              <div className="min-w-0 space-y-4">
                <RulesCard a={current} />
                <InstructionsCard key={current.name} a={current} />
                <VersionsCard a={current} />
              </div>
              <div className="space-y-4">
                <Link to={`/admin/assistente/conhecimento?agent=${current.name}`} className="card flex items-center gap-3 p-4 transition-colors hover:border-border-strong hover:bg-elevated/40">
                  <span className="grid size-10 place-items-center rounded-xl bg-brand-soft text-brand-text">
                    <BookOpen className="size-5" aria-hidden />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-sm font-semibold">Conhecimento</span>
                    <span className="block text-xs text-muted">
                      {current.knowledge} {current.knowledge === 1 ? 'artigo ativo' : 'artigos ativos'} só deste agente
                    </span>
                  </span>
                </Link>
                <ToolsCard a={current} />
              </div>
            </div>
          </>
        )
      )}
    </div>
  )
}
