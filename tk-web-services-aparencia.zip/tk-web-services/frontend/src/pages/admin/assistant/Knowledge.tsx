import { useEffect, useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { Archive, BookOpen, Check, Database, MessagesSquare, Pencil, Plus, RefreshCw, Search, Sparkles, Trash2, Undo2 } from 'lucide-react'
import { api, errorMessage } from '../../../api/client'
import { akeys, useAssistantOverview, useKnowledge, type AgentName, type KnowledgeIn, type KnowledgeItem, type KnowledgeStatus } from '../../../api/assistant'
import { useAction } from '../../../api/mutation'
import {
  Alert,
  Badge,
  Button,
  Card,
  DateText,
  EmptyState,
  Field,
  FormGrid,
  Input,
  Menu,
  Modal,
  Pills,
  Select,
  SkeletonRows,
  Tabs,
  Textarea,
  useConfirm,
} from '../../../components/ui'
import { AgentBadge, KB_SOURCE, KB_STATUS } from '../../../components/assistant/labels'
import { Markdown } from '../../../components/assistant/Markdown'
import { AssistantHeader } from './shared'

type Draft = KnowledgeIn & { id?: number; /** estado original (para "aprovar" uma sugestão) */ from?: KnowledgeStatus }

const EMPTY: Draft = { agent: 'support', title: '', content: '', tags: [], status: 'active' }

export function KnowledgeDialog({ value, onClose, title }: { value: Draft | null; onClose: () => void; title?: string }) {
  const [d, setD] = useState<Draft>(value ?? EMPTY)
  const [tags, setTags] = useState('')
  useEffect(() => {
    if (value) {
      setD(value)
      setTags(value.tags.join(', '))
    }
  }, [value])
  const save = useAction(
    () => {
      const body: KnowledgeIn = {
        agent: d.agent,
        title: d.title.trim(),
        content: d.content.trim(),
        status: d.status,
        tags: tags
          .split(',')
          .map((t) => t.trim())
          .filter(Boolean)
          .slice(0, 12),
      }
      return d.id ? api.put<KnowledgeItem>(`/api/admin/assistant/knowledge/${d.id}`, body) : api.post<KnowledgeItem>('/api/admin/assistant/knowledge', body)
    },
    {
      invalidate: [akeys.knowledge, akeys.overview, akeys.agents],
      success: d.id ? 'Artigo guardado.' : 'Artigo criado.',
      errorTitle: 'Não foi possível guardar',
      onSuccess: onClose,
    },
  )
  const valid = d.title.trim().length >= 3 && d.content.trim().length >= 3
  return (
    <Modal
      open={!!value}
      onClose={onClose}
      size="lg"
      title={title ?? (d.from === 'draft' ? 'Rever e aprovar sugestão' : d.id ? 'Editar artigo' : 'Novo artigo')}
      description="Só o agente escolhido usa este artigo. Escreve como uma resposta pronta: passos concretos, sem dados pessoais."
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancelar
          </Button>
          <Button loading={save.isPending} disabled={!valid} onClick={() => save.mutate()}>
            {d.status === 'active' && d.from === 'draft' ? 'Aprovar e guardar' : 'Guardar'}
          </Button>
        </>
      }
    >
      <form
        className="space-y-4"
        onSubmit={(e) => {
          e.preventDefault()
          if (valid) save.mutate()
        }}
      >
        <FormGrid>
          <Field label="Agente" hint="O conhecimento nunca é partilhado entre agentes.">
            <Select value={d.agent} onChange={(e) => setD({ ...d, agent: e.target.value as AgentName })}>
              <option value="support">Suporte</option>
              <option value="billing">Faturação</option>
            </Select>
          </Field>
          <Field label="Estado">
            <Select value={d.status} onChange={(e) => setD({ ...d, status: e.target.value as KnowledgeStatus })}>
              <option value="active">Ativo (em uso)</option>
              <option value="draft">Sugestão (por aprovar)</option>
              <option value="archived">Arquivado</option>
            </Select>
          </Field>
        </FormGrid>
        <Field label="Título">
          <Input value={d.title} onChange={(e) => setD({ ...d, title: e.target.value })} maxLength={200} placeholder="ex.: Legendas dessincronizadas na app da TV" autoFocus />
        </Field>
        <Field label="Conteúdo" hint={`Markdown simples (negrito, listas). ${d.content.length.toLocaleString('pt-PT')} / 8000`}>
          <Textarea value={d.content} onChange={(e) => setD({ ...d, content: e.target.value })} rows={10} maxLength={8000} />
        </Field>
        <Field label="Etiquetas" optional hint="Separadas por vírgulas — ajudam a pesquisa por palavras-chave.">
          <Input value={tags} onChange={(e) => setTags(e.target.value)} placeholder="legendas, tv, sincronizar" />
        </Field>
      </form>
    </Modal>
  )
}

function ItemCard({ it, onEdit }: { it: KnowledgeItem; onEdit: (d: Draft) => void }) {
  const confirm = useConfirm()
  const inv = [akeys.knowledge, akeys.overview, akeys.agents]
  const setStatus = useAction((status: KnowledgeStatus) => api.put(`/api/admin/assistant/knowledge/${it.id}`, { agent: it.agent, title: it.title, content: it.content, tags: it.tags, status }), {
    invalidate: inv,
    success: (_r, s) => (s === 'active' ? (it.status === 'draft' ? 'Sugestão aprovada — já está em uso.' : 'Artigo reativado.') : 'Artigo arquivado.'),
  })
  const del = useAction(() => api.del(`/api/admin/assistant/knowledge/${it.id}`), { invalidate: inv, success: it.status === 'draft' ? 'Sugestão descartada.' : 'Artigo apagado.' })
  const draft = it.status === 'draft'
  const edit = (status?: KnowledgeStatus) =>
    onEdit({ id: it.id, agent: it.agent, title: it.title, content: it.content, tags: it.tags, status: status ?? it.status, from: it.status })
  const [open, setOpen] = useState(false)

  return (
    <li className={draft ? 'bg-warning-soft/30' : undefined}>
      <div className="px-5 py-4 sm:px-6">
        <div className="flex flex-wrap items-start gap-3">
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <AgentBadge agent={it.agent} />
              {it.status !== 'active' && !(draft && it.source === 'suggested') && (
                <Badge tone={KB_STATUS[it.status]?.tone} dot>
                  {KB_STATUS[it.status]?.label ?? it.status}
                </Badge>
              )}
              {it.source !== 'manual' && (
                <Badge tone={it.source === 'suggested' ? 'warning' : 'info'}>
                  <span className="inline-flex items-center gap-1">
                    {it.source === 'suggested' && <Sparkles className="size-3" aria-hidden />}
                    {KB_SOURCE[it.source] ?? it.source}
                  </span>
                </Badge>
              )}
            </div>
            <h3 className="mt-2 text-[15px] font-semibold leading-snug">{it.title}</h3>
          </div>
          <div className="flex shrink-0 items-center gap-2">
            {draft ? (
              <>
                <Button size="sm" icon={<Check className="size-4" />} loading={setStatus.isPending} onClick={() => setStatus.mutate('active')}>
                  Aprovar
                </Button>
                <Button size="sm" variant="secondary" icon={<Pencil className="size-4" />} onClick={() => edit('active')}>
                  Editar
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  loading={del.isPending}
                  onClick={async () => {
                    if (await confirm({ title: 'Descartar esta sugestão?', message: 'O rascunho é apagado e não volta a ser usado.', confirmLabel: 'Descartar', danger: true })) del.mutate()
                  }}
                >
                  Descartar
                </Button>
              </>
            ) : (
              <>
                <Button size="sm" variant="secondary" icon={<Pencil className="size-4" />} onClick={() => edit()}>
                  Editar
                </Button>
                <Menu
                  items={[
                    it.status === 'active'
                      ? { label: 'Arquivar', icon: <Archive className="size-4" />, onSelect: () => setStatus.mutate('archived'), hint: 'Deixa de ser usado, mas fica guardado.' }
                      : { label: 'Reativar', icon: <Undo2 className="size-4" />, onSelect: () => setStatus.mutate('active') },
                    {
                      label: 'Apagar',
                      danger: true,
                      icon: <Trash2 className="size-4" />,
                      onSelect: async () => {
                        if (await confirm({ title: 'Apagar este artigo?', message: `«${it.title}» é apagado definitivamente.`, confirmLabel: 'Apagar', danger: true })) del.mutate()
                      },
                    },
                  ]}
                />
              </>
            )}
          </div>
        </div>
        <div className={open ? 'mt-2 text-sm text-fg/85' : 'mt-2 line-clamp-3 text-sm text-muted'}>
          {open ? <Markdown text={it.content} /> : it.content}
        </div>
        <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-subtle">
          <button type="button" className="font-semibold text-brand-text hover:underline" onClick={() => setOpen((o) => !o)} aria-expanded={open}>
            {open ? 'Mostrar menos' : 'Ler tudo'}
          </button>
          {it.tags.length > 0 && <span>#{it.tags.join(' #')}</span>}
          <span>
            Usado {it.uses} {it.uses === 1 ? 'vez' : 'vezes'}
          </span>
          <span className="inline-flex items-center gap-1" title={it.embedded ? 'Com embedding (pesquisa semântica)' : 'Sem embedding (pesquisa por palavras)'}>
            <Database className={it.embedded ? 'size-3 text-success' : 'size-3'} aria-hidden />
            {it.embedded ? 'Indexado' : 'Sem embedding'}
          </span>
          <span>
            {it.created_by ?? (it.source === 'suggested' ? 'gerado automaticamente' : '—')} · <DateText value={it.updated_at ?? it.created_at} relative />
          </span>
          {it.source_conversation_id && (
            <Link to={`/admin/assistente/conversas/${it.source_conversation_id}`} className="inline-flex items-center gap-1 font-medium text-muted hover:text-fg">
              <MessagesSquare className="size-3" aria-hidden /> Ver conversa de origem
            </Link>
          )}
        </div>
      </div>
    </li>
  )
}

export default function AssistantKnowledgePage() {
  const [params, setParams] = useSearchParams()
  const agent = params.get('agent') ?? ''
  const status = params.get('status') ?? ''
  const q = params.get('q') ?? ''
  const [search, setSearch] = useState(q)
  const [editing, setEditing] = useState<Draft | null>(null)
  const ov = useAssistantOverview()
  const list = useKnowledge({ agent: agent || undefined, status: status || undefined, q: q || undefined })

  useEffect(() => {
    const t = window.setTimeout(() => {
      if (search.trim() === q) return
      const next = new URLSearchParams(params)
      if (search.trim()) next.set('q', search.trim())
      else next.delete('q')
      setParams(next, { replace: true })
    }, 300)
    return () => window.clearTimeout(t)
  }, [search]) // eslint-disable-line react-hooks/exhaustive-deps

  const setParam = (k: string, v: string) => {
    const next = new URLSearchParams(params)
    if (v) next.set(k, v)
    else next.delete(k)
    setParams(next, { replace: true })
  }

  const reindex = useAction(() => api.post<{ embedded: number }>('/api/admin/assistant/knowledge/reindex'), {
    invalidate: [akeys.knowledge],
    success: (r) => (r.embedded ? `${r.embedded} artigos indexados.` : 'Sem modelo de embeddings: a pesquisa continua por palavras-chave.'),
    errorTitle: 'Não foi possível reindexar',
  })

  return (
    <div>
      <AssistantHeader
        title="Conhecimento"
        description="Artigos que os agentes consultam antes de responder. As sugestões automáticas só entram em uso depois de aprovadas."
        actions={
          <>
            <Button variant="secondary" icon={<RefreshCw className="size-4" />} loading={reindex.isPending} onClick={() => reindex.mutate()}>
              Reindexar
            </Button>
            <Button icon={<Plus className="size-4" />} onClick={() => setEditing({ ...EMPTY, agent: (agent as AgentName) || 'support' })}>
              Novo artigo
            </Button>
          </>
        }
      />

      <Tabs
        ariaLabel="Agente"
        className="mb-4"
        value={agent || 'all'}
        onChange={(id) => setParam('agent', id === 'all' ? '' : id)}
        items={[
          { id: 'all', label: 'Todos' },
          { id: 'billing', label: 'Faturação' },
          { id: 'support', label: 'Suporte' },
        ]}
      />

      <Card className="overflow-hidden">
        <div className="space-y-3 px-5 pt-5 sm:px-6">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-subtle" aria-hidden />
            <Input type="search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Procurar no título, conteúdo ou etiquetas…" aria-label="Procurar artigos" className="pl-10" />
          </div>
          <Pills
            ariaLabel="Estado"
            value={status}
            onChange={(v) => setParam('status', v)}
            items={[
              { value: '', label: 'Em uso e sugestões' },
              { value: 'active', label: 'Ativos' },
              { value: 'draft', label: 'Sugestões', count: ov.data?.knowledge_drafts },
              { value: 'archived', label: 'Arquivados' },
            ]}
          />
        </div>
        {status === 'draft' && !!list.data?.length && (
          <div className="px-5 pt-3 sm:px-6">
            <Alert tone="info" icon={<Sparkles />}>
              Rascunhos gerados a partir de conversas escaladas, resolvidas ou com 👎. Revê o texto antes de aprovar — só depois o agente os usa.
            </Alert>
          </div>
        )}
        <div className="mt-4 border-t border-border">
          {list.isError ? (
            <div className="p-5">
              <Alert tone="danger">{errorMessage(list.error)}</Alert>
            </div>
          ) : list.isLoading ? (
            <SkeletonRows rows={4} />
          ) : !list.data?.length ? (
            <EmptyState
              compact
              icon={<BookOpen className="size-6" />}
              title={q ? 'Nada encontrado' : status === 'draft' ? 'Sem sugestões por aprovar' : 'Sem artigos'}
              description={
                q ? 'Tenta outras palavras.' : status === 'draft' ? 'Quando houver conversas úteis, as sugestões aparecem aqui.' : 'Cria o primeiro artigo ou promove uma boa resposta a partir de uma conversa.'
              }
            />
          ) : (
            <ul className="divide-y divide-border">
              {list.data.map((it) => (
                <ItemCard key={it.id} it={it} onEdit={setEditing} />
              ))}
            </ul>
          )}
        </div>
      </Card>
      <KnowledgeDialog value={editing} onClose={() => setEditing(null)} />
    </div>
  )
}
