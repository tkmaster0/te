import type { ReactNode } from 'react'
import { NavLink } from 'react-router-dom'
import clsx from 'clsx'
import { PageHeader } from '../../../components/ui'
import { useAssistantOverview } from '../../../api/assistant'

const TABS = [
  { to: '/admin/assistente', label: 'Visão geral', end: true },
  { to: '/admin/assistente/agentes', label: 'Agentes' },
  { to: '/admin/assistente/conhecimento', label: 'Conhecimento' },
  { to: '/admin/assistente/conversas', label: 'Conversas' },
]

/** Cabeçalho comum das páginas do assistente, com a navegação entre sub-páginas. */
export function AssistantHeader({ title, description, actions }: { title: string; description?: ReactNode; actions?: ReactNode }) {
  const ov = useAssistantOverview()
  const counts: Record<string, number | undefined> = {
    '/admin/assistente/conhecimento': ov.data?.knowledge_drafts,
    '/admin/assistente/conversas': ov.data?.escalated_open,
  }
  return (
    <>
      <PageHeader eyebrow="Administração · Assistente" title={title} description={description} actions={actions} className="!mb-4 sm:!mb-5" />
      <nav aria-label="Secções do assistente" className="scrollbar-thin -mx-1 mb-6 flex gap-1 overflow-x-auto border-b border-border px-1">
        {TABS.map((t) => {
          const n = counts[t.to]
          return (
            <NavLink
              key={t.to}
              to={t.to}
              end={t.end}
              className={({ isActive }) =>
                clsx(
                  '-mb-px flex shrink-0 items-center gap-2 border-b-2 px-3 py-2.5 text-sm font-medium transition-colors',
                  isActive ? 'border-brand text-fg' : 'border-transparent text-muted hover:text-fg',
                )
              }
            >
              {t.label}
              {!!n && <span className="rounded-full bg-warning-soft px-1.5 py-px text-[11px] font-semibold tabular-nums text-warning">{n}</span>}
            </NavLink>
          )
        })}
      </nav>
    </>
  )
}

export function Code({ children }: { children: ReactNode }) {
  return <code className="rounded-md border border-border bg-bg px-1.5 py-0.5 font-mono text-[12px] text-fg/90">{children}</code>
}

export function Pre({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <pre className={clsx('scrollbar-thin overflow-auto whitespace-pre-wrap break-words rounded-xl border border-border bg-bg p-3 font-mono text-xs leading-relaxed text-muted', className)}>
      {children}
    </pre>
  )
}

export function formatTokens(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toLocaleString('pt-PT', { maximumFractionDigits: 1 })} M`
  if (n >= 10_000) return `${Math.round(n / 1000).toLocaleString('pt-PT')} mil`
  return n.toLocaleString('pt-PT')
}
