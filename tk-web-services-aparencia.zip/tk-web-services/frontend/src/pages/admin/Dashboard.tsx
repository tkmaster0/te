import { useQuery } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { ListChecks, ArrowRight, Dices, Euro, Gift, PiggyBank, ReceiptText, TrendingUp, Truck, UserPlus, Users, Wallet, XCircle } from 'lucide-react'
import { api, errorMessage } from '../../api/client'
import { useConfig } from '../../api/queries'
import type { AdminStats } from '../../api/types'
import { Alert, Card, CardHeader, PageHeader, Skeleton } from '../../components/ui'
import { JOB_STATUS, PROVIDER_LABEL, SUB_STATUS } from '../../i18n/labels'
import { formatMoney, formatMonthShort, formatMonthYear } from '../../lib/format'

function Kpi({ icon, label, value, hint, tone, to }: { icon: React.ReactNode; label: string; value: React.ReactNode; hint?: string; tone?: 'danger' | 'warning'; to?: string }) {
  const body = (
    <>
      <div className="flex items-center gap-2 text-xs font-medium text-muted">
        <span className={tone === 'danger' ? 'text-danger' : 'text-brand-text'}>{icon}</span>
        {label}
      </div>
      <p className={`mt-2 text-2xl font-bold tracking-tight tabular-nums sm:text-3xl ${tone === 'danger' ? 'text-danger' : tone === 'warning' ? 'text-warning' : ''}`}>{value}</p>
      {hint && <p className="mt-0.5 text-xs text-subtle">{hint}</p>}
    </>
  )
  if (to)
    return (
      <Link to={to} className="card block p-4 transition-colors hover:border-border-strong hover:bg-elevated/40 sm:p-5">
        {body}
      </Link>
    )
  return <Card className="p-4 sm:p-5">{body}</Card>
}

const METHOD_STATUS_LABEL: Record<string, string> = { active: 'Ativos', pending: 'A confirmar', unusable: 'Inutilizáveis', revoked: 'Removidos' }

function MethodsCard({ data }: { data: Record<string, Record<string, number>> }) {
  const entries = Object.entries(data ?? {})
  return (
    <Card>
      <CardHeader title="Métodos de pagamento" description="Por fornecedor e estado" />
      <div className="px-5 pb-5 pt-4 sm:px-6">
        {!entries.length ? (
          <p className="text-sm text-muted">Ainda não há métodos guardados.</p>
        ) : (
          <ul className="space-y-4">
            {entries.map(([prov, st]) => {
              const total = Object.entries(st).filter(([k]) => k !== 'revoked').reduce((a, [, n]) => a + n, 0)
              const active = (st.active ?? 0) + (st.pending ?? 0)
              return (
                <li key={prov}>
                  <div className="mb-1 flex justify-between gap-3 text-sm">
                    <span className="truncate font-medium">{PROVIDER_LABEL[prov] ?? prov}</span>
                    <span className="font-semibold tabular-nums">{total}</span>
                  </div>
                  <div className="flex h-2 overflow-hidden rounded-full bg-elevated">
                    <div className="h-full bg-success" style={{ width: `${total ? (active / total) * 100 : 0}%` }} />
                    <div className="h-full bg-danger" style={{ width: `${total ? ((st.unusable ?? 0) / total) * 100 : 0}%` }} />
                  </div>
                  <p className="mt-1 text-xs text-muted">
                    {Object.entries(st)
                      .filter(([k, n]) => n > 0 && k !== 'revoked')
                      .map(([k, n]) => `${n} ${(METHOD_STATUS_LABEL[k] ?? k).toLowerCase()}`)
                      .join(' · ')}
                  </p>
                </li>
              )
            })}
          </ul>
        )}
      </div>
    </Card>
  )
}

function Breakdown({ title, data, labels }: { title: string; data: Record<string, number>; labels?: Record<string, string> }) {
  const entries = Object.entries(data).sort((a, b) => b[1] - a[1])
  const total = entries.reduce((s, [, n]) => s + n, 0)
  return (
    <Card>
      <CardHeader title={title} description={total ? `${total} no total` : undefined} />
      <div className="px-5 pb-5 pt-4 sm:px-6">
        {!entries.length ? (
          <p className="text-sm text-muted">Sem dados.</p>
        ) : (
          <ul className="space-y-3">
            {entries.map(([k, n]) => (
              <li key={k}>
                <div className="mb-1 flex justify-between gap-3 text-sm">
                  <span className="truncate">{labels?.[k] ?? k}</span>
                  <span className="font-semibold tabular-nums">{n}</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-elevated">
                  <div className="h-full rounded-full bg-brand" style={{ width: `${total ? (n / total) * 100 : 0}%` }} />
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </Card>
  )
}

function lastMonths(n: number): string[] {
  const out: string[] = []
  const d = new Date()
  d.setDate(1)
  for (let i = n - 1; i >= 0; i--) {
    const x = new Date(d.getFullYear(), d.getMonth() - i, 1)
    out.push(`${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}`)
  }
  return out
}

function MonthlyChart({ data }: { data: Record<string, number> }) {
  const months = lastMonths(12)
  const values = months.map((m) => data[m] ?? 0)
  const max = Math.max(1, ...values)
  const total = values.reduce((a, b) => a + b, 0)
  return (
    <Card>
      <CardHeader title="Novas subscrições por mês" description={`Últimos 12 meses · ${total} no total`} />
      <div className="px-5 pb-5 pt-6 sm:px-6">
        <div className="flex h-44 items-end gap-1 sm:gap-2" role="img" aria-label={`Novas subscrições nos últimos 12 meses: ${months.map((m, i) => `${formatMonthYear(m)} ${values[i]}`).join(', ')}`}>
          {months.map((m, i) => (
            <div key={m} className="group flex h-full min-w-0 flex-1 flex-col items-center justify-end gap-1.5">
              <span className="text-[10px] font-semibold tabular-nums text-muted sm:text-xs">{values[i] || ''}</span>
              <div
                className={`w-full max-w-12 rounded-t-md transition-colors ${values[i] ? 'bg-brand group-hover:bg-brand-hover' : 'bg-elevated'}`}
                style={{ height: `${Math.max(values[i] ? 6 : 3, (values[i] / max) * 100)}%` }}
                title={`${formatMonthYear(m)}: ${values[i]}`}
              />
            </div>
          ))}
        </div>
        <div className="mt-2 flex gap-1 sm:gap-2" aria-hidden>
          {months.map((m, i) => (
            <span key={m} className={`min-w-0 flex-1 text-center text-[10px] capitalize text-subtle sm:text-xs ${i % 2 ? 'hidden sm:block' : ''}`}>
              {formatMonthShort(m)}
            </span>
          ))}
        </div>
      </div>
    </Card>
  )
}

interface WalletStatsOut {
  total_balance_cents: number
  monthly_count: number
  monthly_sum_cents: number
  legacy_users: number
  topups_30d_cents: number
  games_enabled: boolean
  games_30d: Record<string, { rounds: number; wagered_cents: number; paid_cents: number; house_cents: number }>
}

/** Carteiras (saldo total, carregamentos mensais) e resultado dos jogos nos últimos 30 dias. */
function WalletStats() {
  const q = useQuery({ queryKey: ['admin', 'wallet-stats'], queryFn: () => api.get<WalletStatsOut>('/api/admin/wallet/stats') })
  const monthlyEnabled = useConfig().data?.wallet?.monthly_enabled === true
  const w = q.data
  if (!w) return null
  const games = Object.values(w.games_30d)
  const house = games.reduce((a, g) => a + g.house_cents, 0)
  const rounds = games.reduce((a, g) => a + g.rounds, 0)
  return (
    <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
      <Kpi icon={<Wallet className="size-4" />} label="Saldo em carteiras" value={formatMoney(w.total_balance_cents)} hint="Crédito já pago pelos clientes" />
      {monthlyEnabled && (
        <Kpi
          icon={<PiggyBank className="size-4" />}
          label="Carregamentos mensais"
          value={w.monthly_count}
          hint={`${formatMoney(w.monthly_sum_cents)}/mês · ${w.legacy_users} clientes antigos`}
          to="/admin/migracao"
        />
      )}
      <Kpi icon={<Euro className="size-4" />} label="Carregado (30 dias)" value={formatMoney(w.topups_30d_cents)} />
      <Kpi
        icon={<Dices className="size-4" />}
        label="Jogos (30 dias)"
        value={w.games_enabled ? formatMoney(house) : 'Desligados'}
        hint={w.games_enabled ? `${rounds} jogadas · resultado da casa` : 'GAMES_ENABLED no .env'}
      />
    </div>
  )
}

export default function AdminDashboard() {
  const q = useQuery({ queryKey: ['admin', 'stats'], queryFn: () => api.get<AdminStats>('/api/admin/stats') })

  if (q.isPending)
    return (
      <div>
        <PageHeader eyebrow="Administração" title="Painel" />
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <Skeleton key={i} className="h-28" />
          ))}
        </div>
      </div>
    )
  if (q.isError)
    return (
      <div>
        <PageHeader eyebrow="Administração" title="Painel" />
        <Alert tone="danger">{errorMessage(q.error)}</Alert>
      </div>
    )

  const s = q.data
  const failedJobs = s.jobs.failed ?? 0
  const statusLabels = Object.fromEntries(Object.entries(SUB_STATUS).map(([k, v]) => [k, v.label]))

  return (
    <div className="space-y-6">
      <PageHeader eyebrow="Administração" title="Painel" description="Visão geral do negócio e da saúde do sistema." />

      {(failedJobs > 0 || s.webhooks_failed > 0) && (
        <div className="space-y-2">
          {failedJobs > 0 && (
            <Alert
              tone="danger"
              title={`${failedJobs} ${failedJobs === 1 ? 'tarefa falhou' : 'tarefas falharam'}`}
              action={
                <Link to="/admin/operacoes?tab=jobs&status=failed" className="link inline-flex items-center gap-1 text-sm">
                  Ver tarefas <ArrowRight className="size-4" />
                </Link>
              }
            >
              Há sincronizações ou emails que não foram concluídos. Revê e volta a tentar.
            </Alert>
          )}
          {s.webhooks_failed > 0 && (
            <Alert
              tone="warning"
              title={`${s.webhooks_failed} ${s.webhooks_failed === 1 ? 'webhook falhado' : 'webhooks falhados'}`}
              action={
                <Link to="/admin/operacoes?tab=webhooks&status=failed" className="link inline-flex items-center gap-1 text-sm">
                  Ver webhooks <ArrowRight className="size-4" />
                </Link>
              }
            >
              Eventos de pagamento que não foram processados.
            </Alert>
          )}
        </div>
      )}

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Kpi
          icon={<ReceiptText className="size-4" />}
          label="Cobranças por pagar"
          value={s.invoices_unpaid ?? 0}
          hint={s.invoices_unpaid ? `${formatMoney(s.invoices_unpaid_cents)} em atraso` : 'Tudo em dia'}
          tone={s.invoices_unpaid ? 'danger' : undefined}
          to="/admin/cobrancas"
        />
        <Kpi
          icon={<Truck className="size-4" />}
          label="Entregas pendentes"
          value={s.fulfillment_pending ?? 0}
          hint={s.fulfillment_pending ? 'Dados de acesso por preencher' : 'Nada por entregar'}
          tone={s.fulfillment_pending ? 'warning' : undefined}
          to="/admin/entregas"
        />
        <Kpi icon={<Users className="size-4" />} label="Utilizadores" value={s.users} />
        <Kpi icon={<UserPlus className="size-4" />} label="Novos (30 dias)" value={s.new_users_30d} />
        <Kpi icon={<TrendingUp className="size-4" />} label="MRR" value={formatMoney(s.mrr_cents)} hint="Receita mensal recorrente" />
        <Kpi icon={<Euro className="size-4" />} label="Receita (30 dias)" value={formatMoney(s.revenue_30d_cents)} />
        <Kpi
          icon={<XCircle className="size-4" />}
          label="Pagamentos falhados (30 d)"
          value={s.failed_payments_30d}
          tone={s.failed_payments_30d > 0 ? 'danger' : undefined}
        />
        <Kpi icon={<Gift className="size-4" />} label="Ofertas ativas" value={s.active_grants} />
      </div>

      <WalletStats />

      <MonthlyChart data={s.new_subscriptions_by_month} />

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Breakdown title="Subscrições por estado" data={s.by_status} labels={statusLabels} />
        <Breakdown title="Por plano" data={s.by_plan} />
        <MethodsCard data={s.payment_methods} />
      </div>

      {Object.keys(s.jobs).length > 0 && (
        <p className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted">
          <ListChecks className="size-3.5" aria-hidden />
          Fila de tarefas:{' '}
          {Object.entries(s.jobs).map(([k, n]) => (
            <span key={k}>
              {JOB_STATUS[k]?.label ?? k}: <strong className="text-fg">{n}</strong>
            </span>
          ))}
          <Link to="/admin/operacoes" className="link">
            Operações
          </Link>
        </p>
      )}
    </div>
  )
}
