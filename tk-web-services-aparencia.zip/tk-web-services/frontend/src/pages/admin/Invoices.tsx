import { useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { ReceiptText, UserRound } from 'lucide-react'
import { api, errorMessage, qs } from '../../api/client'
import type { AdminInvoice } from '../../api/types'
import { InvoiceAdminActions } from '../../components/admin/InvoiceAdminActions'
import { InvoiceList, NotAnInvoiceNote } from '../../components/billing/InvoiceList'
import { Alert, Card, EmptyState, PageHeader, Pagination, Pills, SkeletonRows } from '../../components/ui'
import { formatMoney } from '../../lib/format'

const FILTERS = [
  { value: 'unpaid', label: 'Por pagar' },
  { value: 'failed', label: 'Falhadas' },
  { value: 'processing', label: 'A processar' },
  { value: 'paid', label: 'Pagas' },
  { value: '', label: 'Todas' },
]

export default function AdminInvoices() {
  const [params, setParams] = useSearchParams()
  const status = params.get('estado') ?? 'unpaid'
  const [page, setPage] = useState(1)
  const key = ['admin', 'invoices', status, page]
  const q = useQuery({
    queryKey: key,
    queryFn: () => api.get<AdminInvoice[]>(`/api/admin/invoices${qs({ status, page })}`),
  })
  const rows = q.data ?? []
  const total = rows.reduce((s, i) => s + i.total_cents, 0)
  const invalidate = [['admin', 'invoices'], ['admin', 'stats'], ['admin', 'user']]

  return (
    <div>
      <PageHeader
        eyebrow="Administração"
        title="Cobranças"
        description="Todas as cobranças consolidadas. Trata aqui as que falharam: tenta de novo, marca como pagas (MB Way, transferência…) ou anula."
      />
      <Pills
        ariaLabel="Filtrar por estado"
        className="mb-4"
        value={status}
        onChange={(v) => {
          setPage(1)
          if (v === 'unpaid') params.delete('estado')
          else params.set('estado', v)
          setParams(params, { replace: true })
        }}
        items={FILTERS}
      />
      <Card className="overflow-hidden">
        {q.isPending ? (
          <SkeletonRows rows={5} />
        ) : q.isError ? (
          <div className="p-5">
            <Alert tone="danger">{errorMessage(q.error)}</Alert>
          </div>
        ) : !rows.length ? (
          <EmptyState
            icon={<ReceiptText className="size-6" />}
            title={status === 'unpaid' ? 'Nada por pagar' : 'Sem cobranças'}
            description={status === 'unpaid' ? 'Todas as cobranças estão em dia.' : 'Não há cobranças com este estado.'}
          />
        ) : (
          <>
            <div className="flex flex-wrap items-baseline justify-between gap-2 border-b border-border px-4 py-3 text-sm sm:px-6">
              <span className="text-muted">
                {rows.length} {rows.length === 1 ? 'cobrança' : 'cobranças'}
                {page > 1 && ` (página ${page})`}
              </span>
              <span className="font-semibold tabular-nums">{formatMoney(total)}</span>
            </div>
            <InvoiceList
              invoices={rows}
              renderExtra={(i) => `${(i as AdminInvoice).username ?? '—'} · `}
              renderActions={(i) => (
                <>
                  <Link
                    to={`/admin/utilizadores/${(i as AdminInvoice).user_id}`}
                    className="inline-flex h-8 items-center gap-1.5 rounded-xl border border-border px-3 text-[13px] font-semibold hover:bg-elevated"
                  >
                    <UserRound className="size-4" aria-hidden /> {(i as AdminInvoice).username ?? 'Cliente'}
                  </Link>
                  <InvoiceAdminActions inv={i} invalidate={invalidate} />
                </>
              )}
            />
            <Pagination page={page} onPage={setPage} size={100} hasNext={rows.length === 100} />
          </>
        )}
      </Card>
      <div className="mt-3">
        <NotAnInvoiceNote />
      </div>
    </div>
  )
}
