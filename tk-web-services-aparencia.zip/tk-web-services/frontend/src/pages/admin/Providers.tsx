import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { BellRing, CreditCard, Landmark, PlugZap, ShieldAlert } from 'lucide-react'
import { api, errorMessage } from '../../api/client'
import { useAction } from '../../api/mutation'
import type { AdminProvider, Ok } from '../../api/types'
import { Alert, Badge, Button, Card, Checkbox, Field, Modal, PageHeader, SkeletonCard, Switch, Textarea } from '../../components/ui'

const INVALIDATE = [['admin', 'providers'], ['admin', 'stats'], ['billing']]

const METHOD_STATUS: Record<string, string> = { active: 'ativos', pending: 'a confirmar', unusable: 'inutilizáveis', revoked: 'removidos' }

function ResultModal({ message, onClose }: { message: string | null; onClose: () => void }) {
  return (
    <Modal open={!!message} onClose={onClose} title="Feito" size="sm" footer={<Button onClick={onClose}>OK</Button>}>
      <Alert tone="success">{message}</Alert>
    </Modal>
  )
}

function ProviderCard({ p, onResult }: { p: AdminProvider; onResult: (m: string) => void }) {
  const Icon = p.name === 'stripe' ? CreditCard : Landmark
  const [confirmDisable, setConfirmDisable] = useState(false)
  const [understood, setUnderstood] = useState(false)
  const [confirmStopNew, setConfirmStopNew] = useState(false)
  const [notifyOpen, setNotifyOpen] = useState(false)
  const [message, setMessage] = useState('')
  const update = useAction((body: { enabled?: boolean; accept_new?: boolean }) => api.put<Ok>(`/api/admin/providers/${p.name}`, body), {
    invalidate: INVALIDATE,
    success: false,
    errorTitle: 'Não foi possível guardar',
    onSuccess: (res) => {
      setConfirmDisable(false)
      setConfirmStopNew(false)
      setUnderstood(false)
      onResult(res.message ?? 'Guardado.')
    },
  })
  const notify = useAction(() => api.post<Ok>(`/api/admin/providers/${p.name}/notify`, { message: message.trim() || null }), {
    invalidate: INVALIDATE,
    success: false,
    errorTitle: 'Não foi possível avisar',
    onSuccess: (res) => {
      setNotifyOpen(false)
      setMessage('')
      onResult(res.message ?? 'Clientes avisados.')
    },
  })
  const counts = Object.entries(p.methods).filter(([, n]) => n > 0)
  const activeMethods = (p.methods.active ?? 0) + (p.methods.pending ?? 0)

  return (
    <Card className="overflow-hidden">
      <div className="flex flex-wrap items-start gap-3.5 p-5 sm:p-6">
        <span className="grid size-12 shrink-0 place-items-center rounded-2xl bg-elevated">
          <Icon className="size-6" aria-hidden />
        </span>
        <div className="min-w-0 flex-1">
          <h2 className="text-lg font-bold">{p.label}</h2>
          <p className="text-sm text-muted">{p.method_label}</p>
          <div className="mt-2 flex flex-wrap gap-1.5">
            {!p.configured ? (
              <Badge tone="danger">Não configurado</Badge>
            ) : p.enabled ? (
              <Badge tone="success" dot>
                Ativo
              </Badge>
            ) : (
              <Badge tone="danger" dot>
                Desativado
              </Badge>
            )}
            {p.enabled && (p.accept_new ? <Badge tone="info">Aceita novos métodos</Badge> : <Badge tone="warning">Não aceita novos</Badge>)}
          </div>
        </div>
      </div>
      <dl className="mx-5 grid grid-cols-2 gap-3 rounded-xl bg-elevated/60 p-4 text-sm sm:mx-6 sm:grid-cols-3">
        <div className="min-w-0">
          <dt className="text-xs text-muted">Conta</dt>
          <dd className="mt-0.5 truncate font-mono text-xs">{p.account_id ?? '—'}</dd>
        </div>
        <div>
          <dt className="text-xs text-muted">Métodos</dt>
          <dd className="mt-0.5 font-semibold">{counts.length ? counts.map(([k, n]) => `${n} ${METHOD_STATUS[k] ?? k}`).join(' · ') : 'nenhum'}</dd>
        </div>
        <div>
          <dt className="text-xs text-muted">Clientes só com este</dt>
          <dd className={`mt-0.5 font-semibold ${p.customers_only_on_this > 0 ? 'text-warning' : ''}`}>{p.customers_only_on_this}</dd>
        </div>
      </dl>
      <div className="space-y-4 p-5 sm:p-6">
        <Switch
          checked={p.accept_new}
          disabled={!p.enabled || update.isPending}
          onChange={(v) => (v ? update.mutate({ accept_new: true }) : setConfirmStopNew(true))}
          label="Aceitar novos métodos de pagamento"
          description="Desliga para deixar de oferecer este fornecedor a quem adiciona um método. Os métodos existentes continuam a ser cobrados."
        />
        <Switch
          checked={p.enabled}
          disabled={!p.configured || update.isPending}
          onChange={(v) => (v ? update.mutate({ enabled: true }) : setConfirmDisable(true))}
          label="Fornecedor ativo"
          description="Desativar deixa de cobrar TODOS os métodos deste fornecedor. Os clientes afetados são avisados para adicionarem outro."
        />
      </div>
      <div className="flex flex-wrap gap-2 border-t border-border bg-bg/40 px-5 py-3.5 sm:px-6">
        <Button variant="secondary" onClick={() => setNotifyOpen(true)} disabled={!activeMethods} icon={<BellRing className="size-4" />}>
          Avisar clientes para mudarem
        </Button>
      </div>

      <Modal
        open={confirmStopNew}
        onClose={() => setConfirmStopNew(false)}
        title={`Deixar de aceitar novos métodos ${p.label}?`}
        size="sm"
        footer={
          <>
            <Button variant="secondary" onClick={() => setConfirmStopNew(false)}>
              Cancelar
            </Button>
            <Button loading={update.isPending} onClick={() => update.mutate({ accept_new: false })}>
              Deixar de aceitar
            </Button>
          </>
        }
      >
        <p className="text-sm text-muted">
          Os clientes deixam de poder escolher <strong className="text-fg">{p.method_label}</strong> ao adicionar um método. Quem já o tem continua a ser
          cobrado normalmente — nada é cortado.
        </p>
      </Modal>

      <Modal
        open={confirmDisable}
        onClose={() => {
          setConfirmDisable(false)
          setUnderstood(false)
        }}
        title={`Desativar ${p.label}?`}
        footer={
          <>
            <Button
              variant="secondary"
              onClick={() => {
                setConfirmDisable(false)
                setUnderstood(false)
              }}
            >
              Cancelar
            </Button>
            <Button variant="danger" disabled={!understood} loading={update.isPending} onClick={() => update.mutate({ enabled: false })}>
              Desativar {p.label}
            </Button>
          </>
        }
      >
        <div className="space-y-4 text-sm">
          <Alert tone="danger" title="Isto afeta clientes já hoje">
            <ul className="mt-1 list-disc space-y-1 pl-4">
              <li>
                Os <strong>{activeMethods}</strong> métodos ativos deste fornecedor passam a <strong>inutilizáveis</strong>.
              </li>
              <li>
                <strong>{p.customers_only_on_this}</strong> {p.customers_only_on_this === 1 ? 'cliente fica' : 'clientes ficam'} sem nenhum método válido e{' '}
                {p.customers_only_on_this === 1 ? 'recebe' : 'recebem'} um email para adicionar outro.
              </li>
              <li>Se não o fizerem até à próxima cobrança, esta falha e começa o período de tolerância antes da suspensão.</li>
            </ul>
          </Alert>
          <p className="text-muted">Para trocar sem cortes, primeiro deixa de aceitar novos, avisa os clientes e só desativa depois do prazo.</p>
          <Checkbox checked={understood} onChange={(e) => setUnderstood(e.target.checked)} label="Percebo as consequências e quero desativar agora" />
        </div>
      </Modal>

      <Modal
        open={notifyOpen}
        onClose={() => setNotifyOpen(false)}
        title="Avisar clientes para mudarem"
        description={`Email aos clientes que só têm ${p.method_label} e têm serviços ativos.`}
        footer={
          <>
            <Button variant="secondary" onClick={() => setNotifyOpen(false)}>
              Cancelar
            </Button>
            <Button loading={notify.isPending} onClick={() => notify.mutate()} icon={<BellRing className="size-4" />}>
              Enviar aviso
            </Button>
          </>
        }
      >
        <Field label="Mensagem" optional hint="Vazio = mensagem padrão: “Vamos deixar de aceitar pagamentos por este meio em breve. Adiciona um novo método…”">
          <Textarea value={message} onChange={(e) => setMessage(e.target.value)} rows={4} maxLength={500} placeholder="ex.: A partir de 1 de dezembro deixamos de aceitar cartão…" />
        </Field>
      </Modal>
    </Card>
  )
}

export default function AdminProviders() {
  const q = useQuery({ queryKey: ['admin', 'providers'], queryFn: () => api.get<AdminProvider[]>('/api/admin/providers') })
  const [result, setResult] = useState<string | null>(null)
  return (
    <div>
      <PageHeader
        eyebrow="Administração"
        title="Fornecedores de pagamento"
        description="O fornecedor é só a forma de cobrar. Podes deixar de aceitar um, avisar os clientes e desligá-lo sem cortar serviços."
      />
      <div className="grid grid-cols-1 items-start gap-6 xl:grid-cols-[minmax(0,1fr)_22rem]">
        <div className="space-y-4">
          {q.isPending ? (
            <>
              <SkeletonCard lines={4} />
              <SkeletonCard lines={4} />
            </>
          ) : q.isError ? (
            <Alert tone="danger">{errorMessage(q.error)}</Alert>
          ) : !q.data.length ? (
            <Card className="p-6 text-sm text-muted">
              <PlugZap className="mb-2 size-5" aria-hidden /> Nenhum fornecedor disponível.
            </Card>
          ) : (
            q.data.map((p) => <ProviderCard key={p.name} p={p} onResult={setResult} />)
          )}
        </div>
        <Card className="p-5 sm:p-6">
          <div className="flex items-center gap-2">
            <ShieldAlert className="size-5 text-brand-text" aria-hidden />
            <h2 className="font-semibold">Como trocar de fornecedor sem cortes</h2>
          </div>
          <ol className="mt-4 space-y-4 text-sm">
            {[
              ['Deixa de aceitar novos', 'Desliga “Aceitar novos métodos”. Quem já paga continua a pagar; novos clientes escolhem o outro fornecedor.'],
              ['Avisa os clientes', '“Avisar clientes para mudarem” envia um email a quem só tem este fornecedor, com o link para adicionar outro.'],
              ['Desativa depois do prazo', 'Quando “Clientes só com este” chegar a 0 (ou o prazo acabar), desativa o fornecedor.'],
            ].map(([t, d], i) => (
              <li key={t} className="flex gap-3">
                <span className="grid size-6 shrink-0 place-items-center rounded-full bg-brand text-xs font-bold text-brand-fg">{i + 1}</span>
                <span>
                  <span className="block font-semibold">{t}</span>
                  <span className="text-muted">{d}</span>
                </span>
              </li>
            ))}
          </ol>
        </Card>
      </div>
      <ResultModal message={result} onClose={() => setResult(null)} />
    </div>
  )
}
