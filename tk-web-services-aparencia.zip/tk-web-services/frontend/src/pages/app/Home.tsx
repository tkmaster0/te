import { Link, useNavigate } from 'react-router-dom'
import { ArrowRight, Plus, Receipt, TrendingUp, ArrowLeftRight } from 'lucide-react'
import { useBillingSummary, useConfig, useInvoices, useSubscriptions } from '../../api/queries'
import { useMe } from '../../auth/AuthProvider'
import { errorMessage } from '../../api/client'
import { ActionBanners } from '../../components/billing/ActionBanners'
import { InvoiceList, NotAnInvoiceNote } from '../../components/billing/InvoiceList'
import { NextChargeCard, NextChargeSkeleton } from '../../components/billing/NextChargeCard'
import { BonusProgress, HowItWorks } from '../../components/billing/Onboarding'
import { ServiceTile } from '../../components/billing/SubscriptionCard'
import { WalletStrip } from '../../components/wallet/WalletStrip'
import { Alert, ButtonLink, Card, CardHeader, EmptyState, SectionTitle, Skeleton, SkeletonRows } from '../../components/ui'
import { formatDate, formatMoney, perInterval } from '../../lib/format'
import type { Subscription } from '../../api/types'
import { useText } from '../../lib/texts'

const LIVE = new Set(['active', 'past_due', 'canceling', 'bonus', 'suspended'])

function greeting(): string {
  const h = new Date().getHours()
  if (h < 6) return 'Boa noite'
  if (h < 13) return 'Bom dia'
  if (h < 20) return 'Boa tarde'
  return 'Boa noite'
}

/** Mudanças agendadas pela TK Web Services (novo preço, migração de plano) — o cliente deve sabê-lo com antecedência. */
function UpcomingChanges({ subs }: { subs: Subscription[] }) {
  const items = subs.filter((s) => s.status !== 'canceling' && (s.upcoming_price_change || s.pending_plan))
  if (!items.length) return null
  return (
    <section aria-label="Mudanças agendadas" className="space-y-2.5">
      {items.map((sub) => {
        const pc = sub.upcoming_price_change
        const per = perInterval(sub.plan.interval_unit, sub.plan.interval_count)
        return (
          <Alert
            key={sub.id}
            tone="info"
            icon={pc ? <TrendingUp className="size-5" /> : <ArrowLeftRight className="size-5" />}
            title={
              pc
                ? `O preço de ${sub.plan.name} vai mudar`
                : `${sub.product_name}: na próxima renovação passas para ${sub.pending_plan}`
            }
            action={
              <ButtonLink to="/app/servicos" size="sm" variant="secondary">
                Ver opções
              </ButtonLink>
            }
          >
            {pc ? (
              <p>
                A partir de <strong>{formatDate(pc.effective_at)}</strong> passas de {formatMoney(sub.price_cents)}
                {per} para <strong>{formatMoney(pc.new_price_cents)}{per}</strong> (na primeira renovação depois dessa data). Se preferires, podes
                mudar de plano ou cancelar antes.
              </p>
            ) : (
              <p>A mudança acontece a {formatDate(sub.current_period_end)}, sem nada a fazeres.</p>
            )}
          </Alert>
        )
      })}
    </section>
  )
}

export function HomePage() {
  const t = useText()
  const me = useMe()
  const navigate = useNavigate()
  const { data: config } = useConfig()
  const summary = useBillingSummary()
  const subs = useSubscriptions()
  const invoices = useInvoices()

  const live = (subs.data ?? []).filter((s) => LIVE.has(s.status)).sort((a, b) => Number(b.product.jellyfin_managed) - Number(a.product.jellyfin_managed))
  const grants = me.access.filter((a) => a.type === 'grant')
  const name = me.display_name?.split(' ')[0] || me.username
  const newcomer = !subs.isPending && live.length === 0 && grants.length === 0
  const s = summary.data
  const firstUnpaid = s?.unpaid_invoices[0]?.id ?? null

  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">
          {greeting()}, {name}
        </h1>
        <p className="mt-1 text-muted">
          {newcomer ? t('app.home.newcomer') : s?.actions.length ? t('app.home.attention') : t('app.home.ok')}
        </p>
      </header>

      {s && (
        <ActionBanners
          actions={s.actions}
          firstUnpaidId={firstUnpaid}
          onAddMethod={() => navigate('/app/faturacao?metodo=novo')}
          onPayInvoice={(id) => navigate(`/app/faturacao?pagar=${encodeURIComponent(id)}`)}
        />
      )}

      <UpcomingChanges subs={live} />

      {s?.wallet && s.session_scope !== 'streaming' && <WalletStrip w={s.wallet} />}

      {subs.isPending ? (
        <div className="grid gap-4 lg:grid-cols-3">
          <NextChargeSkeleton />
          <Skeleton className="h-48 lg:col-span-2" />
        </div>
      ) : subs.isError ? (
        <Alert tone="danger">{errorMessage(subs.error)}</Alert>
      ) : newcomer ? (
        <HowItWorks />
      ) : (
        <>
          <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
            <div className={s?.bonus.enabled ? 'lg:col-span-2' : 'lg:col-span-3'}>
              {summary.isPending ? <NextChargeSkeleton /> : summary.isError ? <Alert tone="danger">{errorMessage(summary.error)}</Alert> : s && <NextChargeCard summary={s} className="h-full" />}
            </div>
            {s?.bonus.enabled && <BonusProgress bonus={s.bonus} />}
          </div>

          <section aria-labelledby="svc-t">
            <SectionTitle
              id="svc-t"
              action={
                <Link to="/app/servicos" className="link inline-flex items-center gap-1 text-sm">
                  Ver detalhes <ArrowRight className="size-4" aria-hidden />
                </Link>
              }
            >
              Os teus serviços
            </SectionTitle>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
              {live.map((sub) => (
                <ServiceTile key={sub.id} sub={sub} jellyfinUrl={config?.jellyfin_url} />
              ))}
              <Link
                to="/app/planos"
                className="flex min-h-40 flex-col items-center justify-center gap-2 rounded-2xl border border-dashed border-border-strong p-5 text-center text-sm text-muted transition-colors hover:border-brand hover:text-fg"
              >
                <span className="grid size-10 place-items-center rounded-xl bg-elevated">
                  <Plus className="size-5" aria-hidden />
                </span>
                <span className="font-semibold text-fg">Adicionar serviço</span>
                <span>Entra na mesma cobrança mensal</span>
              </Link>
            </div>
          </section>

          <Card className="overflow-hidden">
            <CardHeader
              icon={<Receipt className="size-5" />}
              title="Últimas cobranças"
              actions={
                <Link to="/app/faturacao" className="link text-sm">
                  Ver todas
                </Link>
              }
            />
            <div className="mt-4 border-t border-border">
              {invoices.isPending ? (
                <SkeletonRows rows={3} />
              ) : invoices.isError ? (
                <div className="p-5">
                  <Alert tone="danger">{errorMessage(invoices.error)}</Alert>
                </div>
              ) : !invoices.data?.length ? (
                <EmptyState compact title="Ainda não há cobranças" description="A primeira aparece aqui depois de ser emitida." />
              ) : (
                <InvoiceList invoices={invoices.data.slice(0, 3)} onPay={(inv) => navigate(`/app/faturacao?pagar=${encodeURIComponent(inv.id)}`)} />
              )}
            </div>
            <div className="border-t border-border px-5 py-3 sm:px-6">
              <NotAnInvoiceNote />
            </div>
          </Card>
        </>
      )}
    </div>
  )
}
