import { useEffect, useState } from 'react'
import clsx from 'clsx'
import { ArrowLeft, Hand, Layers, Plus, ShieldQuestion, Split, Square } from 'lucide-react'
import { api, errorMessage } from '../../api/client'
import { keys } from '../../api/keys'
import { useAction } from '../../api/mutation'
import { useGames } from '../../api/queries'
import type { BlackjackState } from '../../api/types'
import { Chip } from '../../components/games/Chip'
import { PlayingCard } from '../../components/games/PlayingCard'
import { Alert, Button, ButtonLink, Skeleton } from '../../components/ui'
import { formatMoney } from '../../lib/format'
import { GameBar, GamesGate } from './Games'

const INVALIDATE = [keys.games, keys.wallet, keys.me, keys.billing]
const RESULT: Record<string, { label: string; cls: string }> = {
  blackjack: { label: 'Blackjack!', cls: 'bg-brand text-brand-fg' },
  win: { label: 'Ganhaste', cls: 'bg-success text-white' },
  push: { label: 'Empate', cls: 'bg-neutral-500 text-white' },
  lose: { label: 'Perdeste', cls: 'bg-neutral-800 text-white' },
  bust: { label: 'Rebentou', cls: 'bg-red-700 text-white' },
}

function Total({ value, soft }: { value: number; soft?: boolean }) {
  return (
    <span className="rounded-full bg-black/40 px-2.5 py-0.5 text-sm font-bold tabular-nums text-white">
      {soft && value <= 21 ? `${value - 10}/${value}` : value}
    </span>
  )
}

export function BlackjackPage() {
  const games = useGames()
  const g = games.data
  const [state, setState] = useState<BlackjackState | null>(null)
  const [bet, setBet] = useState(100)
  const [balance, setBalance] = useState<number | undefined>(undefined)

  useEffect(() => {
    if (g?.blackjack && !state) setState(g.blackjack)
  }, [g?.blackjack, state])

  const onState = (s: BlackjackState) => {
    setState(s)
    setBalance(s.balance_cents)
  }
  const start = useAction((bet_cents: number) => api.post<BlackjackState>('/api/games/blackjack/start', { bet_cents }), {
    success: false,
    invalidate: INVALIDATE,
    onSuccess: onState,
  })
  const act = useAction((action: string) => api.post<BlackjackState>('/api/games/blackjack/action', { action }), {
    success: false,
    invalidate: INVALIDATE,
    onSuccess: onState,
  })

  if (games.isPending) return <Skeleton className="h-[34rem]" />
  if (games.isError || !g) return <Alert tone="danger">{errorMessage(games.error)}</Alert>

  const playing = state && state.phase !== 'done'
  const busy = start.isPending || act.isPending
  const addChip = (c: number) => setBet((b) => Math.min(b + c, g.max_bet_cents))

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <ButtonLink to="/app/jogos" variant="ghost" size="icon" aria-label="Voltar aos jogos" icon={<ArrowLeft className="size-5" />} />
          <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">Blackjack</h1>
        </div>
        <GameBar g={g} balance={balance} />
      </div>
      <GamesGate g={g}>
        <section className="tk-felt relative overflow-hidden rounded-3xl border border-emerald-900 p-5 shadow-inner sm:p-8" aria-label="Mesa">
          <p className="pointer-events-none absolute inset-x-0 top-1/2 -translate-y-1/2 text-center text-xs font-bold uppercase tracking-[0.3em] text-white/15">
            Blackjack paga 3 para 2 · Dealer fica nos 17 · Seguro paga 2 para 1
          </p>
          <div className="relative flex min-h-36 flex-col items-center gap-3">
            <div className="flex items-center gap-2 text-sm font-semibold text-white/80">
              Dealer {state && <Total value={state.dealer_total} />}
            </div>
            <div className="flex -space-x-6 sm:-space-x-8">
              {state ? state.dealer.map((c, i) => <PlayingCard key={`${i}-${c}`} card={c} index={i} />) : <div className="h-24 sm:h-28" />}
            </div>
          </div>

          <div className="relative mt-10 flex min-h-44 flex-wrap items-end justify-center gap-6">
            {state ? (
              state.hands.map((h, hi) => (
                <div
                  key={hi}
                  className={clsx(
                    'flex flex-col items-center gap-2 rounded-2xl p-3 transition-colors',
                    h.active ? 'bg-white/10 ring-2 ring-brand' : 'bg-transparent',
                  )}
                >
                  <div className="flex -space-x-6 sm:-space-x-8">
                    {h.cards.map((c, i) => (
                      <PlayingCard key={`${i}-${c}`} card={c} index={i} />
                    ))}
                  </div>
                  <div className="flex items-center gap-2">
                    <Total value={h.total} soft={h.soft} />
                    <span className="rounded-full bg-black/40 px-2.5 py-0.5 text-xs font-semibold text-white/90 tabular-nums">
                      {formatMoney(h.bet_cents)}
                      {h.doubled && ' · dobrada'}
                    </span>
                  </div>
                  {h.result && RESULT[h.result.result] && (
                    <span className={clsx('animate-pop-in rounded-full px-3 py-1 text-sm font-bold', RESULT[h.result.result].cls)}>
                      {RESULT[h.result.result].label}
                      {h.result.payout_cents > 0 && ` · ${formatMoney(h.result.payout_cents)}`}
                    </span>
                  )}
                </div>
              ))
            ) : (
              <p className="self-center text-center text-white/70">Faz a tua aposta e carrega em «Dar cartas».</p>
            )}
          </div>

          {state?.phase === 'done' && state.payout_cents !== null && (
            <p className="relative mt-6 text-center text-lg font-bold text-white" aria-live="polite">
              {state.payout_cents > state.wager_cents
                ? `Ganhaste ${formatMoney(state.payout_cents - state.wager_cents)}!`
                : state.payout_cents === state.wager_cents
                  ? 'Recebes a aposta de volta.'
                  : 'A casa ganhou esta.'}
            </p>
          )}
        </section>

        <div className="rounded-2xl border border-border bg-surface p-4 sm:p-5">
          {playing ? (
            state.phase === 'insurance' ? (
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <p className="flex items-center gap-2 text-sm">
                  <ShieldQuestion className="size-5 text-brand-text" aria-hidden /> O dealer mostra um Ás. Queres seguro por{' '}
                  <strong>{formatMoney(state.insurance_cost_cents)}</strong>?
                </p>
                <div className="flex gap-2">
                  <Button variant="secondary" onClick={() => act.mutate('no_insurance')} disabled={busy}>
                    Não, obrigado
                  </Button>
                  <Button onClick={() => act.mutate('insurance')} loading={act.isPending}>
                    Fazer seguro
                  </Button>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                <Button size="lg" onClick={() => act.mutate('hit')} disabled={!state.can.hit || busy} icon={<Plus className="size-5" />}>
                  Pedir
                </Button>
                <Button size="lg" variant="secondary" onClick={() => act.mutate('stand')} disabled={!state.can.stand || busy} icon={<Hand className="size-5" />}>
                  Ficar
                </Button>
                <Button size="lg" variant="secondary" onClick={() => act.mutate('double')} disabled={!state.can.double || busy} icon={<Layers className="size-5" />}>
                  Dobrar
                </Button>
                <Button size="lg" variant="secondary" onClick={() => act.mutate('split')} disabled={!state.can.split || busy} icon={<Split className="size-5" />}>
                  Dividir
                </Button>
              </div>
            )
          ) : (
            <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
              <div className="flex flex-wrap items-center gap-2.5" role="group" aria-label="Juntar fichas à aposta">
                {g.chips_cents
                  .filter((c) => c >= 50)
                  .map((c) => (
                    <Chip key={c} cents={c} onClick={() => addChip(c)} />
                  ))}
                <Button variant="ghost" size="sm" onClick={() => setBet(g.min_bet_cents)} icon={<Square className="size-3.5" />}>
                  Mínimo
                </Button>
              </div>
              <div className="flex items-center justify-between gap-3 lg:justify-end">
                <p className="text-sm text-muted">
                  Aposta <strong className="text-lg text-fg tabular-nums">{formatMoney(bet)}</strong>
                </p>
                <Button
                  size="lg"
                  onClick={() => start.mutate(bet)}
                  loading={start.isPending}
                  disabled={bet < g.min_bet_cents || bet > g.max_bet_cents}
                  className="min-w-40"
                >
                  {state ? 'Nova mão' : 'Dar cartas'}
                </Button>
              </div>
            </div>
          )}
          {(start.isError || act.isError) && (
            <Alert tone="danger" className="mt-3">
              {errorMessage(start.error ?? act.error)}
            </Alert>
          )}
        </div>
        {state?.fair && (
          <p className="text-center text-xs text-subtle">
            Mão #{state.fair.nonce} · semente {state.fair.server_seed_hash.slice(0, 16)}… — verificável em Jogos → Resultados verificáveis.
          </p>
        )}
      </GamesGate>
    </div>
  )
}
