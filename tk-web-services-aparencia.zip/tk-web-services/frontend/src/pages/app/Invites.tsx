import { useState } from 'react'
import { Ban, Check, Copy, Gift, Mail, Plus, Share2, Ticket, Users } from 'lucide-react'
import { api } from '../../api/client'
import { keys } from '../../api/keys'
import { useAction } from '../../api/mutation'
import { useInvites } from '../../api/queries'
import type { Invite, Invite as InviteT } from '../../api/types'
import {
  Alert,
  Badge,
  Button,
  Card,
  CardHeader,
  DateText,
  EmptyState,
  Field,
  Input,
  Modal,
  PageHeader,
  ProgressBar,
  SkeletonCard,
  Table,
  THead,
  Th,
  Tr,
  Td,
  useConfirm,
  useCopy,
} from '../../components/ui'
import { errorMessage } from '../../api/client'
import { parseDate } from '../../lib/format'
import type { Tone } from '../../i18n/labels'
import { useText } from '../../lib/texts'

function inviteState(inv: InviteT): { label: string; tone: Tone; usable: boolean } {
  if (inv.disabled) return { label: 'Desativado', tone: 'neutral', usable: false }
  if (inv.uses >= inv.max_uses) return { label: 'Usado', tone: 'success', usable: false }
  const exp = parseDate(inv.expires_at)
  if (exp && exp.getTime() < Date.now()) return { label: 'Expirado', tone: 'neutral', usable: false }
  return { label: 'Disponível', tone: 'brand', usable: true }
}

function EmailInviteModal({ invite, onClose }: { invite: Invite | null; onClose: () => void }) {
  const [email, setEmail] = useState('')
  const send = useAction((v: { id: number; email: string }) => api.post(`/api/invites/${v.id}/email`, { email: v.email }), {
    success: 'Convite enviado.',
    errorTitle: 'Não foi possível enviar',
    onSuccess: () => {
      setEmail('')
      onClose()
    },
  })
  return (
    <Modal
      open={!!invite}
      onClose={onClose}
      title="Enviar convite por email"
      description={invite ? `Vamos enviar o código ${invite.code} com o link de registo.` : undefined}
      size="sm"
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancelar
          </Button>
          <Button
            loading={send.isPending}
            disabled={!email.includes('@')}
            onClick={() => invite && send.mutate({ id: invite.id, email: email.trim() })}
            icon={<Mail className="size-4" />}
          >
            Enviar
          </Button>
        </>
      }
    >
      <form
        onSubmit={(e) => {
          e.preventDefault()
          if (invite && email.includes('@')) send.mutate({ id: invite.id, email: email.trim() })
        }}
      >
        <Field label="Email do teu amigo">
          <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoFocus inputMode="email" autoComplete="off" required />
        </Field>
      </form>
    </Modal>
  )
}

function InviteRow({ inv, onEmail }: { inv: Invite; onEmail: (i: Invite) => void }) {
  const { copy, copied } = useCopy()
  const confirm = useConfirm()
  const st = inviteState(inv)
  const disable = useAction(() => api.del(`/api/invites/${inv.id}`), { invalidate: [keys.invites], success: 'Convite desativado.' })
  const canShare = typeof navigator !== 'undefined' && typeof navigator.share === 'function'
  const share = async () => {
    try {
      await navigator.share({
        title: 'Convite TK Web Services',
        text: `Tens aqui um convite para a TK Web Services (streaming TKFLIX e outros serviços)! Código: ${inv.code}`,
        url: inv.link,
      })
    } catch {
      /* partilha cancelada */
    }
  }
  return (
    <li className="flex flex-col gap-3 px-5 py-4 sm:flex-row sm:items-center sm:px-6">
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-2">
          <span className="font-mono text-base font-bold tracking-wider">{inv.code}</span>
          <Badge tone={st.tone}>{st.label}</Badge>
        </div>
        <p className="mt-0.5 text-xs text-muted">
          Criado a <DateText value={inv.created_at} />
          {inv.max_uses > 1 && ` · ${inv.uses}/${inv.max_uses} utilizações`}
          {inv.expires_at && (
            <>
              {' · expira a '}
              <DateText value={inv.expires_at} />
            </>
          )}
          {inv.note && ` · ${inv.note}`}
        </p>
      </div>
      {st.usable && (
        <div className="flex flex-wrap gap-1.5">
          <Button
            size="sm"
            variant="secondary"
            onClick={() => copy(inv.link, 'Link copiado')}
            icon={copied === inv.link ? <Check className="size-4 text-success" /> : <Copy className="size-4" />}
          >
            Copiar link
          </Button>
          {canShare && (
            <Button size="sm" variant="secondary" onClick={share} icon={<Share2 className="size-4" />}>
              Partilhar
            </Button>
          )}
          <Button size="sm" variant="secondary" onClick={() => onEmail(inv)} icon={<Mail className="size-4" />}>
            Email
          </Button>
          <Button
            size="icon-sm"
            variant="ghost"
            aria-label={`Desativar convite ${inv.code}`}
            title="Desativar"
            loading={disable.isPending}
            onClick={async () => {
              if (await confirm({ title: 'Desativar convite?', message: `O código ${inv.code} deixa de funcionar.`, confirmLabel: 'Desativar', danger: true }))
                disable.mutate()
            }}
          >
            {!disable.isPending && <Ban className="size-4" />}
          </Button>
        </div>
      )}
    </li>
  )
}

export function InvitesPage() {
  const t = useText()
  const q = useInvites()
  const [note, setNote] = useState('')
  const [emailFor, setEmailFor] = useState<Invite | null>(null)
  const create = useAction(() => api.post<Invite>('/api/invites', { note: note.trim() || null }), {
    invalidate: [keys.invites],
    success: (res) => `Convite ${res.code} criado.`,
    errorTitle: 'Não foi possível criar o convite',
    onSuccess: () => setNote(''),
  })

  if (q.isPending)
    return (
      <div>
        <PageHeader title={t('app.invites.title')} />
        <div className="space-y-4">
          <SkeletonCard lines={2} />
          <SkeletonCard lines={4} />
        </div>
      </div>
    )
  if (q.isError)
    return (
      <div>
        <PageHeader title={t('app.invites.title')} />
        <Alert tone="danger">{errorMessage(q.error)}</Alert>
      </div>
    )

  const { codes, invitees, bonus, can_create, reason, limit } = q.data
  const remaining = Math.max(0, bonus.threshold - bonus.active_invitees)

  return (
    <div>
      <PageHeader title={t('app.invites.title')} description={t('app.invites.description', { limite: limit })} />

      <div className="space-y-4">
        {bonus.enabled && (
          <Card className={bonus.eligible ? 'border-brand/50' : undefined}>
            <div className="flex flex-col gap-5 p-5 sm:flex-row sm:items-start sm:p-6">
              <div className="grid size-14 shrink-0 place-items-center rounded-2xl bg-brand text-brand-fg">
                <Gift className="size-7" aria-hidden />
              </div>
              <div className="min-w-0 flex-1">
                <h2 className="text-lg font-bold">{bonus.eligible ? 'O teu streaming está pago pelo bónus' : 'Convida amigos e deixa de pagar o streaming'}</h2>
                <p className="mt-1 text-sm text-muted">
                  {bonus.eligible ? (
                    <>
                      Tens <strong className="text-fg">{bonus.active_invitees} convidados a pagar</strong> — enquanto assim for, o streaming não entra na tua
                      cobrança mensal.
                    </>
                  ) : (
                    <>
                      Precisas de <strong className="text-fg">{bonus.threshold} convidados a pagar</strong> para o teu streaming deixar de ser cobrado
                      {bonus.threshold < 3 && ' (foste convidado diretamente pela TK Web Services, por isso bastam 2 em vez de 3)'}.
                    </>
                  )}
                </p>
                <div className="mt-4">
                  <div className="mb-1.5 flex items-baseline justify-between gap-3 text-sm">
                    <span className="font-semibold">
                      <span className="tabular-nums">
                        {Math.min(bonus.active_invitees, bonus.threshold)} de {bonus.threshold}
                      </span>{' '}
                      convidados a pagar
                    </span>
                    <span className="text-muted">{bonus.eligible ? 'Objetivo atingido' : remaining === 1 ? 'Falta 1' : `Faltam ${remaining}`}</span>
                  </div>
                  <ProgressBar value={bonus.active_invitees} max={bonus.threshold} label="Convidados a pagar" />
                </div>
                <ol className="mt-5 grid gap-3 text-sm sm:grid-cols-3">
                  {[
                    ['Convida', 'Partilha um código. Quem criar conta com ele fica ligado a ti.'],
                    [
                      'Eles pagam, tu não',
                      'Com 3 convidados a pagar (ou 2, se foste convidado diretamente pela TK Web Services), o streaming TKFLIX deixa de ser cobrado. Outros serviços continuam na cobrança.',
                    ],
                    [
                      'Se deixarem de pagar',
                      'A cobrança do streaming volta automaticamente na cobrança seguinte — avisamos-te por email. Não contam convidados em atraso nem com bónus próprio.',
                    ],
                  ].map(([t, d], i) => (
                    <li key={t} className="rounded-xl bg-elevated/60 p-3.5">
                      <p className="flex items-center gap-2 font-semibold">
                        <span className="grid size-5 place-items-center rounded-full bg-brand-soft text-[11px] font-bold text-brand-text">{i + 1}</span>
                        {t}
                      </p>
                      <p className="mt-1 text-xs leading-relaxed text-muted">{d}</p>
                    </li>
                  ))}
                </ol>
              </div>
            </div>
          </Card>
        )}

        <Card>
          <CardHeader icon={<Ticket className="size-5" />} title="Os teus códigos" description="Cada código serve para uma pessoa criar conta." />
          <div className="px-5 pb-4 pt-4 sm:px-6">
            {can_create ? (
              <form
                className="flex flex-col gap-2 sm:flex-row"
                onSubmit={(e) => {
                  e.preventDefault()
                  create.mutate()
                }}
              >
                <Input
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="Nota (opcional) — ex.: para o Rui"
                  aria-label="Nota do convite"
                  maxLength={200}
                  className="sm:flex-1"
                />
                <Button type="submit" loading={create.isPending} icon={<Plus className="size-4" />}>
                  Criar convite
                </Button>
              </form>
            ) : (
              <Alert tone="info">{reason ?? 'De momento não podes criar mais convites.'}</Alert>
            )}
          </div>
          {codes.length === 0 ? (
            <EmptyState compact icon={<Ticket className="size-6" />} title="Ainda não criaste convites" description="Cria um código e envia-o a quem quiseres convidar." />
          ) : (
            <ul className="divide-y divide-border border-t border-border">
              {codes.map((c) => (
                <InviteRow key={c.id} inv={c} onEmail={setEmailFor} />
              ))}
            </ul>
          )}
        </Card>

        <Card className="overflow-hidden">
          <CardHeader icon={<Users className="size-5" />} title="Pessoas que convidaste" description="Contam para o bónus os convidados que estão a pagar, em dia e sem bónus próprio." />
          <div className="pt-4">
            {invitees.length === 0 ? (
              <EmptyState compact title="Ainda ninguém usou os teus convites" description="Quando alguém se registar com o teu código, aparece aqui." />
            ) : (
              <>
              <div className="hidden md:block">
              <Table minWidth={460}>
                <THead>
                  <Th>Utilizador</Th>
                  <Th>Desde</Th>
                  <Th>Subscrição</Th>
                  <Th>Conta para o bónus</Th>
                </THead>
                <tbody>
                  {invitees.map((i) => (
                    <Tr key={i.username}>
                      <Td className="font-medium">{i.username}</Td>
                      <Td className="text-muted">
                        <DateText value={i.joined} />
                      </Td>
                      <Td>
                        <Badge tone={i.status === 'active' || i.status === 'bonus' ? 'success' : i.status === 'past_due' || i.status === 'canceling' ? 'warning' : 'neutral'}>
                          {i.status_label}
                        </Badge>
                      </Td>
                      <Td>
                        {i.counts_for_bonus ? (
                          <span className="inline-flex items-center gap-1 text-sm font-medium text-success">
                            <Check className="size-4" aria-hidden /> Sim
                          </span>
                        ) : (
                          <span className="text-sm text-muted">Não</span>
                        )}
                      </Td>
                    </Tr>
                  ))}
                </tbody>
              </Table>
              </div>
              <ul className="divide-y divide-border border-t border-border md:hidden">
                {invitees.map((i) => (
                  <li key={i.username} className="flex items-center gap-3 px-5 py-3.5">
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-medium">{i.username}</p>
                      <p className="mt-0.5 text-xs text-muted">
                        Desde <DateText value={i.joined} />
                      </p>
                      <div className="mt-1.5">
                        <Badge tone={i.status === 'active' || i.status === 'bonus' ? 'success' : i.status === 'past_due' || i.status === 'canceling' ? 'warning' : 'neutral'}>
                          {i.status_label}
                        </Badge>
                      </div>
                    </div>
                    {i.counts_for_bonus ? (
                      <span className="inline-flex shrink-0 items-center gap-1 text-sm font-medium text-success">
                        <Check className="size-4" aria-hidden /> Conta
                      </span>
                    ) : (
                      <span className="shrink-0 text-sm text-muted">Não conta</span>
                    )}
                  </li>
                ))}
              </ul>
              </>
            )}
          </div>
        </Card>
      </div>
      <EmailInviteModal invite={emailFor} onClose={() => setEmailFor(null)} />
    </div>
  )
}
