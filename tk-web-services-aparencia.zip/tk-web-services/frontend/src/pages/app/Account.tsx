import { useEffect, useState, type FormEvent } from 'react'
import { useSearchParams } from 'react-router-dom'
import {
  Activity as ActivityIcon,
  Download,
  KeyRound,
  LogOut,
  Mail,
  Monitor,
  ShieldCheck,
  ShieldOff,
  User,
  Copy,
} from 'lucide-react'
import { api } from '../../api/client'
import { keys } from '../../api/keys'
import { useAction } from '../../api/mutation'
import { useActivity, useSessions } from '../../api/queries'
import type { Me, Ok, TotpSetup } from '../../api/types'
import { useAuth, useMe } from '../../auth/AuthProvider'
import {
  Badge,
  Button,
  Card,
  CardHeader,
  Checkbox,
  CopyField,
  DateText,
  Field,
  Input,
  Modal,
  PageHeader,
  PasswordInput,
  SkeletonRows,
  Tabs,
  useConfirm,
  useCopy,
} from '../../components/ui'
import { PasswordMeter } from '../../components/PasswordMeter'
import { actionLabel } from '../../i18n/labels'
import { describeUserAgent } from '../../lib/format'
import { ThemeSegmented } from '../../components/ThemeToggle'
import { useAssistantStatus } from '../../api/assistant'
import { WhatsAppCard } from '../../components/assistant/WhatsAppCard'
import { useText } from '../../lib/texts'

// ------------------------------------------------------------------ Perfil
function ProfileCard({ me }: { me: Me }) {
  const { setMe } = useAuth()
  const [name, setName] = useState(me.display_name ?? '')
  const save = useAction((display_name: string) => api.patch<Me>('/api/account/profile', { display_name }), {
    success: 'Perfil atualizado.',
    onSuccess: (res) => setMe(res),
  })
  return (
    <Card>
      <CardHeader icon={<User className="size-5" />} title="Perfil" />
      <form
        className="space-y-4 px-5 pb-5 pt-4 sm:px-6 sm:pb-6"
        onSubmit={(e) => {
          e.preventDefault()
          save.mutate(name.trim())
        }}
      >
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Field label="Nome" hint="Como aparece no portal e nos emails.">
            <Input value={name} onChange={(e) => setName(e.target.value)} maxLength={120} autoComplete="name" />
          </Field>
          <Field label="Username" hint="O username não pode ser alterado.">
            <Input value={me.username} disabled readOnly />
          </Field>
        </div>
        {me.referred_by && <p className="text-sm text-muted">Foste convidado por <strong className="text-fg">{me.referred_by}</strong>.</p>}
        <div className="flex justify-end">
          <Button type="submit" loading={save.isPending} disabled={(me.display_name ?? '') === name.trim()}>
            Guardar
          </Button>
        </div>
      </form>
    </Card>
  )
}

function EmailCard({ me }: { me: Me }) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const change = useAction((v: { new_email: string; password: string }) => api.post<Ok>('/api/account/email', v), {
    errorTitle: 'Não foi possível alterar o email',
    onSuccess: () => {
      setEmail('')
      setPassword('')
    },
  })
  return (
    <Card>
      <CardHeader
        icon={<Mail className="size-5" />}
        title="Email"
        description={
          <>
            Email atual: <strong className="break-all text-fg">{me.email}</strong>{' '}
            {me.email_verified ? <Badge tone="success">Confirmado</Badge> : <Badge tone="warning">Por confirmar</Badge>}
          </>
        }
      />
      <form
        className="space-y-4 px-5 pb-5 pt-4 sm:px-6 sm:pb-6"
        onSubmit={(e) => {
          e.preventDefault()
          change.mutate({ new_email: email.trim(), password })
        }}
      >
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Field label="Novo email">
            <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" inputMode="email" required />
          </Field>
          <Field label="Password atual">
            <PasswordInput value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" required />
          </Field>
        </div>
        <p className="text-xs text-muted">Vamos enviar um link de confirmação para o novo endereço. O email só muda depois de o confirmares.</p>
        <div className="flex justify-end">
          <Button type="submit" loading={change.isPending} disabled={!email.includes('@') || !password}>
            Alterar email
          </Button>
        </div>
      </form>
    </Card>
  )
}

function AppearanceCard() {
  return (
    <Card>
      <CardHeader icon={<Monitor className="size-5" />} title="Aparência" description="Escolhe o tema do portal neste dispositivo." />
      <div className="px-5 pb-5 pt-4 sm:px-6 sm:pb-6">
        <ThemeSegmented />
      </div>
    </Card>
  )
}

// ------------------------------------------------------------------ Segurança
function PasswordCard({ me }: { me: Me }) {
  const [current, setCurrent] = useState('')
  const [next, setNext] = useState('')
  const [confirm, setConfirm] = useState('')
  const [logoutOthers, setLogoutOthers] = useState(true)
  const mismatch = confirm.length > 0 && confirm !== next
  const change = useAction(
    (v: { current_password: string; new_password: string; logout_others: boolean }) => api.post<Ok>('/api/account/password', v),
    {
      errorTitle: 'Não foi possível alterar a password',
      invalidate: [keys.sessions],
      onSuccess: () => {
        setCurrent('')
        setNext('')
        setConfirm('')
      },
    },
  )
  const submit = (e: FormEvent) => {
    e.preventDefault()
    if (mismatch) return
    change.mutate({ current_password: current, new_password: next, logout_others: logoutOthers })
  }
  return (
    <Card>
      <CardHeader icon={<KeyRound className="size-5" />} title="Password" description="A password do Jellyfin é atualizada automaticamente para a nova." />
      <form className="space-y-4 px-5 pb-5 pt-4 sm:px-6 sm:pb-6" onSubmit={submit}>
        <input type="text" name="username" autoComplete="username" value={me.username} readOnly hidden />
        <Field label="Password atual">
          <PasswordInput value={current} onChange={(e) => setCurrent(e.target.value)} autoComplete="current-password" required />
        </Field>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div className="space-y-2">
            <Field label="Nova password">
              <PasswordInput value={next} onChange={(e) => setNext(e.target.value)} autoComplete="new-password" minLength={8} required />
            </Field>
            <PasswordMeter password={next} username={me.username} email={me.email} />
          </div>
          <Field label="Confirmar nova password" error={mismatch ? 'As passwords não coincidem.' : undefined}>
            <PasswordInput value={confirm} onChange={(e) => setConfirm(e.target.value)} autoComplete="new-password" required />
          </Field>
        </div>
        <Checkbox
          checked={logoutOthers}
          onChange={(e) => setLogoutOthers(e.target.checked)}
          label="Terminar sessão noutros dispositivos"
          description="Recomendado se achas que alguém conhece a tua password."
        />
        <div className="flex justify-end">
          <Button type="submit" loading={change.isPending} disabled={!current || next.length < 8 || mismatch || !confirm}>
            Alterar password
          </Button>
        </div>
      </form>
    </Card>
  )
}

function RecoveryCodesModal({ codes, onClose }: { codes: string[] | null; onClose: () => void }) {
  const { copy } = useCopy()
  const [saved, setSaved] = useState(false)
  useEffect(() => {
    if (codes) setSaved(false)
  }, [codes])
  const text = codes ? `Códigos de recuperação TK Web Services\nGuarda-os num sítio seguro. Cada código só pode ser usado uma vez.\n\n${codes.join('\n')}\n` : ''
  const download = () => {
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'tk-web-services-codigos-recuperacao.txt'
    document.body.appendChild(a)
    a.click()
    a.remove()
    window.setTimeout(() => URL.revokeObjectURL(url), 1000)
    setSaved(true)
  }
  return (
    <Modal
      open={!!codes}
      onClose={onClose}
      dismissible={false}
      title="Guarda os teus códigos de recuperação"
      description="Se perderes o telemóvel, usa um destes códigos para entrar. Só os mostramos agora."
      footer={
        <Button onClick={onClose} disabled={!saved}>
          Já guardei os códigos
        </Button>
      }
    >
      <ul className="grid grid-cols-2 gap-2 rounded-xl border border-border bg-bg p-4 font-mono text-sm">
        {codes?.map((c) => (
          <li key={c} className="text-center tracking-wider">
            {c}
          </li>
        ))}
      </ul>
      <div className="mt-4 flex flex-col gap-2 sm:flex-row">
        <Button
          variant="secondary"
          className="flex-1"
          icon={<Copy className="size-4" />}
          onClick={() => {
            void copy(codes?.join('\n') ?? '', 'Códigos copiados')
            setSaved(true)
          }}
        >
          Copiar
        </Button>
        <Button variant="secondary" className="flex-1" icon={<Download className="size-4" />} onClick={download}>
          Descarregar .txt
        </Button>
      </div>
      <p className="mt-3 text-xs text-muted">Copia ou descarrega os códigos para poderes continuar.</p>
    </Modal>
  )
}

function TwoFactorCard({ me }: { me: Me }) {
  const { refresh } = useAuth()
  const [setup, setSetup] = useState<TotpSetup | null>(null)
  const [code, setCode] = useState('')
  const [codes, setCodes] = useState<string[] | null>(null)
  const [disableOpen, setDisableOpen] = useState(false)
  const [regenOpen, setRegenOpen] = useState(false)
  const [pw, setPw] = useState('')
  const [dcode, setDcode] = useState('')

  const start = useAction(() => api.post<TotpSetup>('/api/account/2fa/setup'), { success: false, onSuccess: (res) => setSetup(res) })
  const enable = useAction((c: string) => api.post<{ recovery_codes: string[] }>('/api/account/2fa/enable', { code: c }), {
    success: 'Autenticação de dois fatores ativada.',
    errorTitle: 'Código inválido',
    onSuccess: (res) => {
      setSetup(null)
      setCode('')
      setCodes(res.recovery_codes)
      void refresh()
    },
  })
  const disable = useAction((v: { password: string; code: string }) => api.post<Ok>('/api/account/2fa/disable', v), {
    errorTitle: 'Não foi possível desativar',
    onSuccess: () => {
      setDisableOpen(false)
      setPw('')
      setDcode('')
      void refresh()
    },
  })
  const regen = useAction((password: string) => api.post<{ recovery_codes: string[] }>('/api/account/2fa/recovery-codes', { password }), {
    success: false,
    errorTitle: 'Não foi possível gerar códigos',
    onSuccess: (res) => {
      setRegenOpen(false)
      setPw('')
      setCodes(res.recovery_codes)
    },
  })

  return (
    <Card>
      <CardHeader
        icon={me.totp_enabled ? <ShieldCheck className="size-5" /> : <ShieldOff className="size-5" />}
        title="Autenticação de dois fatores (2FA)"
        description="Protege a tua conta com um código gerado no telemóvel, além da password."
        actions={me.totp_enabled ? <Badge tone="success" dot>Ativa</Badge> : <Badge tone="neutral">Desativada</Badge>}
      />
      <div className="px-5 pb-5 pt-4 sm:px-6 sm:pb-6">
        {me.totp_enabled ? (
          <div className="flex flex-wrap gap-2">
            <Button variant="secondary" onClick={() => setRegenOpen(true)}>
              Gerar novos códigos de recuperação
            </Button>
            <Button variant="danger" onClick={() => setDisableOpen(true)}>
              Desativar 2FA
            </Button>
          </div>
        ) : !setup ? (
          <Button onClick={() => start.mutate()} loading={start.isPending} icon={<ShieldCheck className="size-4" />}>
            Ativar 2FA
          </Button>
        ) : (
          <div className="grid grid-cols-1 gap-6 md:grid-cols-[auto_1fr]">
            <div className="mx-auto w-48 rounded-2xl bg-white p-3 md:mx-0">
              <img
                src={`data:image/svg+xml;utf8,${encodeURIComponent(setup.qr_svg)}`}
                alt="Código QR para configurar a app de autenticação"
                className="aspect-square w-full"
              />
            </div>
            <div className="min-w-0 space-y-4">
              <ol className="list-decimal space-y-1.5 pl-5 text-sm text-muted">
                <li>Abre a app de autenticação (Google Authenticator, Authy, 1Password, Bitwarden…).</li>
                <li>Lê o código QR ou introduz a chave abaixo manualmente.</li>
                <li>Escreve o código de 6 dígitos que aparece na app.</li>
              </ol>
              <CopyField label="Chave (introdução manual)" value={setup.secret} />
              <form
                className="flex flex-col gap-2 sm:flex-row sm:items-end"
                onSubmit={(e) => {
                  e.preventDefault()
                  if (code.length === 6) enable.mutate(code)
                }}
              >
                <Field label="Código da app" className="sm:w-48">
                  <Input
                    value={code}
                    onChange={(e) => setCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                    inputMode="numeric"
                    autoComplete="one-time-code"
                    placeholder="123456"
                    className="text-center font-mono tracking-[0.3em]"
                  />
                </Field>
                <Button type="submit" loading={enable.isPending} disabled={code.length !== 6}>
                  Confirmar e ativar
                </Button>
                <Button variant="ghost" onClick={() => setSetup(null)}>
                  Cancelar
                </Button>
              </form>
            </div>
          </div>
        )}
      </div>

      <Modal
        open={disableOpen}
        onClose={() => setDisableOpen(false)}
        title="Desativar 2FA?"
        description="A tua conta fica protegida só pela password. Confirma com a password e um código da app (ou de recuperação)."
        size="sm"
        footer={
          <>
            <Button variant="secondary" onClick={() => setDisableOpen(false)}>
              Cancelar
            </Button>
            <Button variant="danger" loading={disable.isPending} disabled={!pw || dcode.length < 6} onClick={() => disable.mutate({ password: pw, code: dcode.trim() })}>
              Desativar
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          <Field label="Password">
            <PasswordInput value={pw} onChange={(e) => setPw(e.target.value)} autoComplete="current-password" />
          </Field>
          <Field label="Código 2FA ou de recuperação">
            <Input value={dcode} onChange={(e) => setDcode(e.target.value)} autoComplete="one-time-code" className="font-mono" />
          </Field>
        </div>
      </Modal>

      <Modal
        open={regenOpen}
        onClose={() => setRegenOpen(false)}
        title="Gerar novos códigos de recuperação"
        description="Os códigos antigos deixam de funcionar."
        size="sm"
        footer={
          <>
            <Button variant="secondary" onClick={() => setRegenOpen(false)}>
              Cancelar
            </Button>
            <Button loading={regen.isPending} disabled={!pw} onClick={() => regen.mutate(pw)}>
              Gerar códigos
            </Button>
          </>
        }
      >
        <Field label="Password">
          <PasswordInput value={pw} onChange={(e) => setPw(e.target.value)} autoComplete="current-password" />
        </Field>
      </Modal>

      <RecoveryCodesModal codes={codes} onClose={() => setCodes(null)} />
    </Card>
  )
}

// ------------------------------------------------------------------ Sessões
function SessionsCard() {
  const q = useSessions()
  const confirm = useConfirm()
  const revoke = useAction((id: string) => api.del(`/api/account/sessions/${id}`), { invalidate: [keys.sessions], success: 'Sessão terminada.' })
  const revokeOthers = useAction(() => api.post<Ok>('/api/account/sessions/revoke-others'), { invalidate: [keys.sessions] })
  const others = (q.data ?? []).filter((s) => !s.current).length
  return (
    <Card>
      <CardHeader
        icon={<Monitor className="size-5" />}
        title="Sessões ativas"
        description="Onde tens sessão iniciada no portal."
        actions={
          others > 0 && (
            <Button
              size="sm"
              variant="secondary"
              loading={revokeOthers.isPending}
              icon={<LogOut className="size-4" />}
              onClick={async () => {
                if (await confirm({ title: 'Terminar as outras sessões?', message: 'Todos os outros dispositivos vão ter de voltar a entrar.', confirmLabel: 'Terminar', danger: true }))
                  revokeOthers.mutate()
              }}
            >
              Terminar as outras
            </Button>
          )
        }
      />
      <div className="px-5 pb-4 pt-3 sm:px-6">
        {q.isPending ? (
          <SkeletonRows rows={2} />
        ) : !q.data?.length ? (
          <p className="py-3 text-sm text-muted">Sem sessões.</p>
        ) : (
          <ul className="divide-y divide-border">
            {q.data.map((s) => (
              <li key={s.id} className="flex items-center gap-3 py-3">
                <span className="grid size-9 shrink-0 place-items-center rounded-lg bg-elevated text-muted">
                  <Monitor className="size-4" aria-hidden />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="flex flex-wrap items-center gap-2 text-sm font-medium">
                    {describeUserAgent(s.user_agent)}
                    {s.current && <Badge tone="success">Esta sessão</Badge>}
                  </p>
                  <p className="truncate text-xs text-muted">
                    {s.ip ?? 'IP desconhecido'} · última atividade <DateText value={s.last_seen_at} relative />
                  </p>
                </div>
                {!s.current && (
                  <Button size="sm" variant="ghost" loading={revoke.isPending && revoke.variables === s.id} onClick={() => revoke.mutate(s.id)}>
                    Terminar
                  </Button>
                )}
              </li>
            ))}
          </ul>
        )}
      </div>
    </Card>
  )
}

function ActivityCard() {
  const q = useActivity()
  return (
    <Card>
      <CardHeader icon={<ActivityIcon className="size-5" />} title="Atividade de segurança recente" description="Logins, alterações de password e outras ações sensíveis." />
      <div className="px-5 pb-4 pt-3 sm:px-6">
        {q.isPending ? (
          <SkeletonRows rows={3} />
        ) : !q.data?.length ? (
          <p className="py-3 text-sm text-muted">Sem atividade registada.</p>
        ) : (
          <ul className="divide-y divide-border">
            {q.data.map((a, i) => (
              <li key={i} className="flex flex-wrap items-center justify-between gap-x-4 gap-y-0.5 py-2.5 text-sm">
                <span className={a.action.includes('failed') ? 'font-medium text-danger' : 'font-medium'}>{actionLabel(a.action)}</span>
                <span className="text-xs text-muted">
                  <DateText value={a.created_at} withTime />
                  {a.ip && ` · ${a.ip}`}
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </Card>
  )
}

const BASE_TABS = [
  { id: 'perfil', label: 'Perfil' },
  { id: 'seguranca', label: 'Segurança' },
  { id: 'sessoes', label: 'Sessões e atividade' },
]

export function AccountPage() {
  const t = useText()
  const me = useMe()
  const [params, setParams] = useSearchParams()
  const assistant = useAssistantStatus()
  const TABS = assistant.data?.whatsapp.enabled ? [...BASE_TABS, { id: 'whatsapp', label: 'WhatsApp' }] : BASE_TABS
  const tab = TABS.some((t) => t.id === params.get('tab')) ? (params.get('tab') as string) : 'perfil'
  return (
    <div>
      <PageHeader title={t('app.account.title')} description={t('app.account.description')} />
      <Tabs items={TABS} value={tab} onChange={(id) => setParams({ tab: id }, { replace: true })} className="mb-6" ariaLabel="Secções da conta" />
      <div role="tabpanel" className="space-y-4">
        {tab === 'perfil' && (
          <>
            <ProfileCard me={me} />
            <EmailCard me={me} />
            <AppearanceCard />
          </>
        )}
        {tab === 'seguranca' && (
          <>
            <PasswordCard me={me} />
            <TwoFactorCard me={me} />
          </>
        )}
        {tab === 'whatsapp' && <WhatsAppCard />}
        {tab === 'sessoes' && (
          <>
            <SessionsCard />
            <ActivityCard />
          </>
        )}
      </div>
    </div>
  )
}
