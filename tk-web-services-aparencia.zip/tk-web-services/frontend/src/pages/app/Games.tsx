import { useState, type ReactNode } from 'react'
import { Link } from 'react-router-dom'
import clsx from 'clsx'
import { ChevronRight, CircleDot, Dices, HeartHandshake, ShieldCheck, Spade, Wallet as WalletIcon } from 'lucide-react'
import { api, errorMessage } from '../../api/client'
import { keys } from '../../api/keys'
import { useAction } from '../../api/mutation'
import { useGames } from '../../api/queries'
import type { GamesOverview } from '../../api/types'
import { useMe } from '../../auth/AuthProvider'
import { AmountPicker } from '../../components/wallet/AmountPicker'
import { Alert, Badge, Button, ButtonLink, Card, CardBody, CardHeader, Checkbox, EmptyState, PageHeader, Select, Skeleton } from '../../components/ui'
import { formatDateTime, formatMoney, formatSignedMoney } from '../../lib/format'
import { useText } from '../../lib/texts'

const INVALIDATE = [keys.games, keys.wallet, keys.me, keys.billing]

/** Barra de saldo + resultado de hoje, comum às páginas de jogo. */
export function GameBar({ g, balance }: { g: GamesOverview; balance?: number }) {
  return (
    <div className="flex flex-wrap items-center gap-2 text-sm">
      <span className="inline-flex items-center gap-2 rounded-full border border-border bg-surface px-3.5 py-1.5 font-semibold tabular-nums">
        <WalletIcon className="size-4 text-brand-text" aria-hidden /> {formatMoney(balance ?? g.balance_cents)}
      </span>
      <span className={clsx('rounded-full px-3 py-1.5 text-xs font-semibold tabular-nums', g.net_today_cents >= 0 ? 'bg-success-soft text-success' : 'bg-danger-soft text-danger')}>
        Hoje {formatSignedMoney(g.net_today_cents)}
      </span>
      {g.daily_loss_limit_cents && (
        <span className="rounded-full bg-elevated px-3 py-1.5 text-xs text-muted">Limite diário {formatMoney(g.daily_loss_limit_cents)}</span>
      )}
    </div>
  )
}

/** Antes de jogar: maioridade e regras. */
export function GamesGate({ g, children }: { g: GamesOverview; children: ReactNode }) {
  const [ok, setOk] = useState(false)
  const accept = useAction(() => api.put('/api/games/settings', { accept: true }), { invalidate: INVALIDATE, success: 'Boa sorte!' })
  if (!g.enabled)
    return <EmptyState icon={<Dices className="size-6" />} title="Jogos indisponíveis" description="Os jogos não estão ativos de momento." />
  if (g.excluded_until)
    return (
      <EmptyState
        icon={<HeartHandshake className="size-6" />}
        title="Estás numa pausa"
        description={`Pediste uma pausa dos jogos até ${formatDateTime(g.excluded_until)}. Até lá não é possível apostar.`}
      />
    )
  if (!g.accepted)
    return (
      <Card className="mx-auto max-w-xl">
        <CardHeader icon={<ShieldCheck className="size-5" />} title="Antes de jogar" description="Os jogos usam os créditos da tua carteira. Joga com moderação." />
        <CardBody className="space-y-4 text-sm text-muted">
          <ul className="list-disc space-y-1.5 pl-5">
            <li>Só com créditos da carteira. Os prémios ficam na carteira e pagam os teus serviços — não são levantados.</li>
            <li>
              Aposta mínima de {formatMoney(g.min_bet_cents)} por jogada; máxima de {formatMoney(g.max_bet_cents)}.
            </li>
            <li>A casa tem sempre vantagem. Nunca carregues a carteira só para jogar nem tentes recuperar perdas.</li>
            <li>Podes definir um limite diário ou fazer uma pausa quando quiseres.</li>
            <li>Cada resultado é verificável (sementes "provably fair").</li>
          </ul>
          <Checkbox checked={ok} onChange={(e) => setOk(e.target.checked)} label={`Confirmo que tenho ${g.min_age} anos ou mais e aceito estas regras.`} />
          <Button onClick={() => accept.mutate()} disabled={!ok} loading={accept.isPending}>
            Começar a jogar
          </Button>
        </CardBody>
      </Card>
    )
  return <>{children}</>
}

function GameTile({ to, title, desc, icon, accent }: { to: string; title: string; desc: string; icon: ReactNode; accent: string }) {
  return (
    <Link
      to={to}
      className="group relative flex min-h-48 flex-col justify-between overflow-hidden rounded-3xl border border-border bg-surface p-6 transition-colors hover:border-brand/50"
    >
      <div className={clsx('pointer-events-none absolute -right-10 -top-10 size-44 rounded-full blur-3xl', accent)} aria-hidden />
      <span className="relative grid size-12 place-items-center rounded-2xl bg-elevated text-brand-text">{icon}</span>
      <div className="relative">
        <h2 className="flex items-center gap-1 text-xl font-bold">
          {title} <ChevronRight className="size-5 transition-transform group-hover:translate-x-0.5" aria-hidden />
        </h2>
        <p className="mt-1 text-sm text-muted">{desc}</p>
      </div>
    </Link>
  )
}

function Responsible({ g }: { g: GamesOverview }) {
  const [limit, setLimit] = useState(g.user_daily_loss_limit_cents ?? g.system_daily_loss_limit_cents ?? 2000)
  const [pause, setPause] = useState('1')
  const save = useAction((body: object) => api.put('/api/games/settings', body), { invalidate: INVALIDATE })
  return (
    <Card>
      <CardHeader icon={<HeartHandshake className="size-5" />} title="Jogo responsável" description="Baixar o limite é imediato; subir só conta a partir de amanhã." />
      <CardBody className="space-y-6">
        <div className="space-y-3">
          <p className="text-sm font-medium">Limite diário de perdas</p>
          <AmountPicker
            value={limit}
            onChange={setLimit}
            presets={[500, 1000, 2000, 5000]}
            min={100}
            max={g.system_daily_loss_limit_cents ?? 1_000_000}
            label="Limite diário"
          />
          <Button size="sm" variant="secondary" onClick={() => save.mutate({ daily_loss_limit_cents: limit })} loading={save.isPending}>
            Guardar limite
          </Button>
        </div>
        <div className="flex flex-wrap items-end gap-3 border-t border-border pt-5">
          <div className="min-w-40 flex-1">
            <p className="mb-1.5 text-sm font-medium">Fazer uma pausa</p>
            <Select value={pause} onChange={(e) => setPause(e.target.value)} aria-label="Duração da pausa">
              <option value="1">24 horas</option>
              <option value="7">7 dias</option>
              <option value="30">30 dias</option>
              <option value="180">6 meses</option>
            </Select>
          </div>
          <Button variant="danger" onClick={() => save.mutate({ exclude_days: Number(pause) })} loading={save.isPending}>
            Pausar jogos
          </Button>
        </div>
        {save.isError && <Alert tone="danger">{errorMessage(save.error)}</Alert>}
      </CardBody>
    </Card>
  )
}

function Fairness({ g }: { g: GamesOverview }) {
  const [seed, setSeed] = useState('')
  const [revealed, setRevealed] = useState<{ server_seed: string; server_seed_hash: string; client_seed: string; last_nonce: number } | null>(null)
  const rotate = useAction((client_seed: string) => api.post<{ revealed: typeof revealed }>('/api/games/seed', { client_seed }), {
    invalidate: INVALIDATE,
    success: 'Semente trocada — a anterior foi revelada.',
    onSuccess: (res) => setRevealed(res.revealed),
  })
  return (
    <Card>
      <CardHeader icon={<ShieldCheck className="size-5" />} title="Resultados verificáveis" description="O hash da semente do servidor é fixado antes de jogares. Ao trocá-la, a anterior é revelada." />
      <CardBody className="space-y-3 text-sm">
        <dl className="grid gap-2">
          <div>
            <dt className="text-xs text-subtle">Hash da semente do servidor (SHA-256)</dt>
            <dd className="break-all font-mono text-xs">{g.seed.server_seed_hash}</dd>
          </div>
          <div className="flex gap-6">
            <div>
              <dt className="text-xs text-subtle">A tua semente</dt>
              <dd className="font-mono text-xs">{g.seed.client_seed}</dd>
            </div>
            <div>
              <dt className="text-xs text-subtle">Jogadas com esta semente</dt>
              <dd className="font-mono text-xs">{g.seed.nonce}</dd>
            </div>
          </div>
        </dl>
        <div className="flex flex-wrap gap-2 pt-1">
          <input
            value={seed}
            onChange={(e) => setSeed(e.target.value.slice(0, 64))}
            placeholder="Nova semente (opcional)"
            className="h-9 min-w-0 flex-1 rounded-lg border border-border bg-bg px-3 font-mono text-xs outline-none focus:border-brand"
            aria-label="Nova semente do cliente"
          />
          <Button size="sm" variant="secondary" onClick={() => rotate.mutate(seed || Math.random().toString(36).slice(2, 12))} loading={rotate.isPending}>
            Trocar e revelar
          </Button>
        </div>
        {rotate.isError && <Alert tone="danger">{errorMessage(rotate.error)}</Alert>}
        {revealed && (
          <div className="rounded-xl bg-elevated p-3 text-xs">
            <p className="mb-1 font-semibold">Semente revelada</p>
            <p className="break-all font-mono">{revealed.server_seed}</p>
            <p className="mt-2 text-muted">
              Resultado de cada jogada = HMAC-SHA256(semente, "{revealed.client_seed}:nonce:jogo:contador"). Jogadas 0 a {revealed.last_nonce}.
            </p>
          </div>
        )}
      </CardBody>
    </Card>
  )
}

export function History({ g }: { g: GamesOverview }) {
  if (!g.history.length) return <p className="py-4 text-sm text-muted">Ainda não jogaste.</p>
  return (
    <ul className="divide-y divide-border">
      {g.history.map((h) => (
        <li key={h.id} className="flex items-center gap-3 py-2.5 text-sm">
          <span className="grid size-8 shrink-0 place-items-center rounded-full bg-elevated text-muted">
            {h.game === 'roulette' ? <CircleDot className="size-4" aria-hidden /> : <Spade className="size-4" aria-hidden />}
          </span>
          <div className="min-w-0 flex-1">
            <p className="font-medium">{h.game === 'roulette' ? 'Roleta' : 'Blackjack'} · <span className="text-muted">{h.summary}</span></p>
            <p className="text-xs text-subtle">
              {formatDateTime(h.settled_at)} · aposta {formatMoney(h.wager_cents)} · jogada #{h.nonce}
            </p>
          </div>
          <span className={clsx('font-semibold tabular-nums', h.net_cents > 0 ? 'text-success' : h.net_cents < 0 ? 'text-danger' : 'text-muted')}>
            {formatSignedMoney(h.net_cents)}
          </span>
        </li>
      ))}
    </ul>
  )
}

export function GamesPage() {
  const t = useText()
  const me = useMe()
  const games = useGames(me.email_verified)
  const g = games.data
  return (
    <div className="space-y-8">
      <PageHeader
        title={t('app.games.title')}
        description={t('app.games.description')}
        actions={g && <GameBar g={g} />}
      />
      {!me.email_verified ? (
        <Alert tone="warning">Confirma o teu email para poderes jogar.</Alert>
      ) : games.isPending ? (
        <div className="grid gap-4 md:grid-cols-2">
          <Skeleton className="h-48" />
          <Skeleton className="h-48" />
        </div>
      ) : games.isError || !g ? (
        <Alert tone="danger">{errorMessage(games.error)}</Alert>
      ) : (
        <GamesGate g={g}>
          {g.balance_cents < g.min_bet_cents && (
            <Alert
              tone="info"
              title="Sem saldo para jogar"
              action={
                <ButtonLink to="/app/carteira" size="sm">
                  Carregar
                </ButtonLink>
              }
            >
              A aposta mínima é de {formatMoney(g.min_bet_cents)}.
            </Alert>
          )}
          <div className="grid gap-4 md:grid-cols-2">
            <GameTile to="/app/jogos/roleta" title="Roleta europeia" desc="Um só zero. Fichas de 0,20 € a 10 €, aposta mínima de 1 € por jogada." icon={<CircleDot className="size-6" />} accent="bg-rose-500/20" />
            <GameTile
              to="/app/jogos/blackjack"
              title="Blackjack"
              desc={`Blackjack paga 3:2, dealer fica nos 17. Dobrar, dividir e seguro.${g.blackjack ? ' Tens uma mão a meio!' : ''}`}
              icon={<Spade className="size-6" />}
              accent="bg-emerald-500/20"
            />
          </div>
          <div className="grid gap-4 lg:grid-cols-2">
            <Card>
              <CardHeader title="Últimas jogadas" description={<Badge tone="neutral">Resultado de hoje {formatSignedMoney(g.net_today_cents)}</Badge>} />
              <CardBody className="pt-1">
                <History g={g} />
              </CardBody>
            </Card>
            <div className="space-y-4">
              <Responsible g={g} />
              <Fairness g={g} />
            </div>
          </div>
        </GamesGate>
      )}
    </div>
  )
}
