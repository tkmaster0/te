import { useMemo, useRef, useState } from 'react'
import clsx from 'clsx'
import { ArrowLeft, Eraser, Repeat, RotateCcw, Sparkles } from 'lucide-react'
import { api, errorMessage } from '../../api/client'
import { keys } from '../../api/keys'
import { useAction } from '../../api/mutation'
import { useGames } from '../../api/queries'
import type { RouletteBet, RouletteBetType, RouletteResult } from '../../api/types'
import { Chip } from '../../components/games/Chip'
import { Alert, Button, ButtonLink, Skeleton } from '../../components/ui'
import { formatMoney, formatSignedMoney } from '../../lib/format'
import { GameBar, GamesGate } from './Games'

const RED = new Set([1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36])
const WHEEL = [0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10, 5, 24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26]
const SEG = 360 / 37
const INVALIDATE = [keys.games, keys.wallet, keys.me, keys.billing]

const colorOf = (n: number) => (n === 0 ? 'green' : RED.has(n) ? 'red' : 'black')
const keyOf = (type: RouletteBetType, numbers: number[]) => `${type}:${[...numbers].sort((a, b) => a - b).join('-')}`
/** Número na linha r (0 = em cima: 3, 6, …) e coluna c (0–11) do tabuleiro horizontal. */
const numAt = (r: number, c: number) => 3 * (c + 1) - r

interface Zone {
  type: RouletteBetType
  numbers: number[]
  x: number // % da largura da área dos números
  y: number // % da altura
  label: string
}

/** Zonas de aposta interiores (cavalos, quadrados, transversais, seisenas e as do zero). */
function insideZones(): Zone[] {
  const z: Zone[] = []
  for (let c = 0; c < 12; c++) {
    for (let r = 0; r < 3; r++) {
      if (r < 2) z.push({ type: 'split', numbers: [numAt(r, c), numAt(r + 1, c)], x: ((c + 0.5) / 12) * 100, y: ((r + 1) / 3) * 100, label: 'Cavalo' })
      if (c < 11) z.push({ type: 'split', numbers: [numAt(r, c), numAt(r, c + 1)], x: ((c + 1) / 12) * 100, y: ((r + 0.5) / 3) * 100, label: 'Cavalo' })
      if (r < 2 && c < 11)
        z.push({
          type: 'corner',
          numbers: [numAt(r, c), numAt(r + 1, c), numAt(r, c + 1), numAt(r + 1, c + 1)],
          x: ((c + 1) / 12) * 100,
          y: ((r + 1) / 3) * 100,
          label: 'Quadrado',
        })
    }
    z.push({ type: 'street', numbers: [3 * c + 1, 3 * c + 2, 3 * c + 3], x: ((c + 0.5) / 12) * 100, y: 100, label: 'Transversal' })
    if (c < 11) z.push({ type: 'line', numbers: [3 * c + 1, 3 * c + 2, 3 * c + 3, 3 * c + 4, 3 * c + 5, 3 * c + 6], x: ((c + 1) / 12) * 100, y: 100, label: 'Seisena' })
  }
  for (let r = 0; r < 3; r++) z.push({ type: 'split', numbers: [0, numAt(r, 0)], x: 0, y: ((r + 0.5) / 3) * 100, label: 'Cavalo com o zero' })
  z.push({ type: 'street', numbers: [0, 2, 3], x: 0, y: 100 / 3, label: 'Trio 0-2-3' })
  z.push({ type: 'street', numbers: [0, 1, 2], x: 0, y: 200 / 3, label: 'Trio 0-1-2' })
  z.push({ type: 'corner', numbers: [0, 1, 2, 3], x: 0, y: 100, label: 'Primeiros quatro' })
  return z
}

const OUTSIDE: { type: RouletteBetType; numbers: number[]; label: string; cls?: string }[] = [
  { type: 'low', numbers: [], label: '1–18' },
  { type: 'even', numbers: [], label: 'Par' },
  { type: 'red', numbers: [], label: 'Vermelho', cls: 'bg-red-700/80' },
  { type: 'black', numbers: [], label: 'Preto', cls: 'bg-neutral-900' },
  { type: 'odd', numbers: [], label: 'Ímpar' },
  { type: 'high', numbers: [], label: '19–36' },
]

function Wheel({ rotation, spinning, result }: { rotation: number; spinning: boolean; result: number | null }) {
  const R = 100
  return (
    <div className="relative mx-auto aspect-square w-full max-w-[300px]">
      <div className="absolute left-1/2 top-0 z-10 -translate-x-1/2 -translate-y-1" aria-hidden>
        <div className="h-0 w-0 border-x-[10px] border-t-[18px] border-x-transparent border-t-brand drop-shadow" />
      </div>
      <svg
        viewBox="-110 -110 220 220"
        className="size-full drop-shadow-2xl"
        style={{ transform: `rotate(${rotation}deg)`, transition: spinning ? 'transform 4.4s cubic-bezier(0.15, 0.7, 0.1, 1)' : 'none' }}
        role="img"
        aria-label={result !== null && !spinning ? `Saiu o ${result}` : 'Roda da roleta'}
      >
        <circle r="108" fill="#3f2a14" />
        {WHEEL.map((n, i) => {
          const a0 = ((i - 0.5) * SEG - 90) * (Math.PI / 180)
          const a1 = ((i + 0.5) * SEG - 90) * (Math.PI / 180)
          const p = (a: number, r: number) => `${Math.cos(a) * r},${Math.sin(a) * r}`
          const fill = n === 0 ? '#15803d' : RED.has(n) ? '#b91c1c' : '#18181b'
          const mid = (i * SEG - 90) * (Math.PI / 180)
          return (
            <g key={n}>
              <path d={`M0,0 L${p(a0, R)} A${R},${R} 0 0 1 ${p(a1, R)} Z`} fill={fill} stroke="#d4af37" strokeWidth="0.6" />
              <text
                x={Math.cos(mid) * 86}
                y={Math.sin(mid) * 86}
                fill="#fff"
                fontSize="9"
                fontWeight="700"
                textAnchor="middle"
                dominantBaseline="middle"
                transform={`rotate(${i * SEG} ${Math.cos(mid) * 86} ${Math.sin(mid) * 86})`}
              >
                {n}
              </text>
            </g>
          )
        })}
        <circle r="62" fill="#27180a" stroke="#d4af37" strokeWidth="1.5" />
        <circle r="18" fill="#d4af37" />
      </svg>
      {result !== null && !spinning && (
        <div className="absolute inset-0 grid place-items-center" aria-live="polite">
          <span
            className={clsx(
              'animate-pop-in grid size-20 place-items-center rounded-full text-3xl font-black text-white shadow-2xl ring-4 ring-brand',
              colorOf(result) === 'red' ? 'bg-red-700' : colorOf(result) === 'black' ? 'bg-neutral-900' : 'bg-green-700',
            )}
          >
            {result}
          </span>
        </div>
      )}
    </div>
  )
}

function ChipStack({ cents }: { cents: number }) {
  return (
    <span className="pointer-events-none absolute left-1/2 top-1/2 z-20 -translate-x-1/2 -translate-y-1/2">
      <span className="grid size-7 place-items-center rounded-full border-2 border-dashed border-white/70 bg-brand text-[10px] font-black text-brand-fg shadow-lg tabular-nums">
        {cents >= 100 ? (cents / 100).toFixed(cents % 100 ? 1 : 0).replace('.', ',') : `${cents}c`}
      </span>
    </span>
  )
}

export function RoulettePage() {
  const games = useGames()
  const g = games.data
  const [chip, setChip] = useState(100)
  const [bets, setBets] = useState<Map<string, RouletteBet>>(new Map())
  const [historyStack, setHistoryStack] = useState<string[]>([])
  const [last, setLast] = useState<RouletteBet[]>([])
  const [rotation, setRotation] = useState(0)
  const [spinning, setSpinning] = useState(false)
  const [result, setResult] = useState<RouletteResult | null>(null)
  const [recent, setRecent] = useState<number[]>([])
  const [balance, setBalance] = useState<number | undefined>(undefined)
  const timer = useRef<number | null>(null)
  const zones = useMemo(insideZones, [])

  const total = Array.from(bets.values()).reduce((s, b) => s + b.amount_cents, 0)
  const winners = new Set(result && !spinning ? result.bets.filter((b) => b.won).map((b) => keyOf(b.type, b.numbers)) : [])

  const place = (type: RouletteBetType, numbers: number[]) => {
    if (spinning) return
    const k = keyOf(type, numbers)
    setBets((prev) => {
      const next = new Map(prev)
      const cur = next.get(k)
      next.set(k, { type, numbers: [...numbers].sort((a, b) => a - b), amount_cents: (cur?.amount_cents ?? 0) + chip })
      return next
    })
    setHistoryStack((h) => [...h, `${k}|${chip}`])
    setResult(null)
  }
  const undo = () => {
    const lastOp = historyStack[historyStack.length - 1]
    if (!lastOp) return
    const [k, c] = lastOp.split('|')
    setBets((prev) => {
      const next = new Map(prev)
      const cur = next.get(k)
      if (cur) {
        const amt = cur.amount_cents - Number(c)
        if (amt <= 0) next.delete(k)
        else next.set(k, { ...cur, amount_cents: amt })
      }
      return next
    })
    setHistoryStack((h) => h.slice(0, -1))
  }
  const loadBets = (list: RouletteBet[], factor = 1) => {
    const m = new Map<string, RouletteBet>()
    for (const b of list) m.set(keyOf(b.type, b.numbers), { ...b, amount_cents: b.amount_cents * factor })
    setBets(m)
    setHistoryStack([])
    setResult(null)
  }

  const spin = useAction((list: RouletteBet[]) => api.post<RouletteResult>('/api/games/roulette/spin', { bets: list }), {
    success: false,
    invalidate: INVALIDATE,
    onSuccess: (res) => {
      const idx = WHEEL.indexOf(res.number)
      setSpinning(true)
      setRotation((prev) => prev - (((prev % 360) + 360) % 360) + 360 * 5 + (360 - idx * SEG))
      setResult(res)
      setLast(Array.from(bets.values()))
      if (timer.current) window.clearTimeout(timer.current)
      timer.current = window.setTimeout(() => {
        setSpinning(false)
        setRecent((r) => [res.number, ...r].slice(0, 14))
        setBalance(res.balance_cents)
        setBets(new Map())
        setHistoryStack([])
      }, 4500)
    },
  })

  if (games.isPending) return <Skeleton className="h-[34rem]" />
  if (games.isError || !g) return <Alert tone="danger">{errorMessage(games.error)}</Alert>

  const numberCell = (n: number) => {
    const k = keyOf('straight', [n])
    const bet = bets.get(k)
    return (
      <button
        key={n}
        type="button"
        onClick={() => place('straight', [n])}
        className={clsx(
          'relative grid place-items-center border border-white/15 text-sm font-bold text-white transition-[filter] hover:brightness-125 sm:text-base',
          colorOf(n) === 'red' ? 'bg-red-700/90' : 'bg-neutral-900/90',
          result && !spinning && result.number === n && 'ring-4 ring-inset ring-brand',
          winners.has(k) && 'animate-pulse',
        )}
        aria-label={`Pleno no ${n}${bet ? `, ${formatMoney(bet.amount_cents)} apostados` : ''}`}
      >
        {n}
        {bet && <ChipStack cents={bet.amount_cents} />}
      </button>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <ButtonLink to="/app/jogos" variant="ghost" size="icon" aria-label="Voltar aos jogos" icon={<ArrowLeft className="size-5" />} />
          <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">Roleta europeia</h1>
        </div>
        <GameBar g={g} balance={balance} />
      </div>
      <GamesGate g={g}>
        <div className="grid gap-6 xl:grid-cols-[320px_1fr]">
          <div className="space-y-4">
            <Wheel rotation={rotation} spinning={spinning} result={result?.number ?? null} />
            {result && !spinning && (
              <div
                className={clsx(
                  'animate-pop-in rounded-2xl border p-4 text-center',
                  result.net_cents > 0 ? 'border-success/40 bg-success-soft' : 'border-border bg-surface',
                )}
                aria-live="polite"
              >
                <p className="text-sm text-muted">
                  Saiu o <strong className="text-fg">{result.number}</strong>{' '}
                  {result.color === 'red' ? 'vermelho' : result.color === 'black' ? 'preto' : '(zero)'}
                </p>
                <p className={clsx('mt-1 text-2xl font-extrabold tabular-nums', result.net_cents > 0 ? 'text-success' : result.net_cents < 0 && 'text-muted')}>
                  {result.payout_cents > 0 ? `Ganhaste ${formatMoney(result.payout_cents)}` : 'Não foi desta'}
                </p>
                <p className="text-xs text-subtle">
                  Apostaste {formatMoney(result.wager_cents)} · resultado {formatSignedMoney(result.net_cents)}
                </p>
              </div>
            )}
            {recent.length > 0 && (
              <div className="flex flex-wrap gap-1.5" aria-label="Últimos números">
                {recent.map((n, i) => (
                  <span
                    key={`${n}-${i}`}
                    className={clsx(
                      'grid size-7 place-items-center rounded-full text-xs font-bold text-white',
                      colorOf(n) === 'red' ? 'bg-red-700' : colorOf(n) === 'black' ? 'bg-neutral-800' : 'bg-green-700',
                    )}
                  >
                    {n}
                  </span>
                ))}
              </div>
            )}
          </div>

          <div className="min-w-0 space-y-4">
            <div className="tk-felt scrollbar-thin overflow-x-auto rounded-3xl border border-emerald-900 p-3 shadow-inner sm:p-5">
              <div className="min-w-[660px] select-none">
                <div className="grid grid-cols-[3.2rem_1fr_3.2rem] gap-0">
                  <button
                    type="button"
                    onClick={() => place('straight', [0])}
                    className={clsx(
                      'relative grid place-items-center rounded-l-2xl border border-white/15 bg-green-700/90 text-lg font-bold text-white hover:brightness-125',
                      result && !spinning && result.number === 0 && 'ring-4 ring-inset ring-brand',
                    )}
                    aria-label="Pleno no zero"
                  >
                    0{bets.get(keyOf('straight', [0])) && <ChipStack cents={bets.get(keyOf('straight', [0]))!.amount_cents} />}
                  </button>
                  <div className="relative">
                    <div className="grid h-[9.6rem] grid-cols-12 grid-rows-3">
                      {[0, 1, 2].map((r) => Array.from({ length: 12 }, (_, c) => numberCell(numAt(r, c))))}
                    </div>
                    <div className="pointer-events-none absolute inset-0">
                      {zones.map((z) => {
                        const k = keyOf(z.type, z.numbers)
                        const bet = bets.get(k)
                        return (
                          <button
                            key={k}
                            type="button"
                            onClick={() => place(z.type, z.numbers)}
                            title={`${z.label}: ${z.numbers.join(', ')}`}
                            aria-label={`${z.label} ${z.numbers.join(', ')}${bet ? `, ${formatMoney(bet.amount_cents)} apostados` : ''}`}
                            style={{ left: `${z.x}%`, top: `${z.y}%` }}
                            className={clsx(
                              'pointer-events-auto absolute z-10 size-4 -translate-x-1/2 -translate-y-1/2 rounded-full',
                              'hover:bg-brand/70 hover:ring-2 hover:ring-white/80 focus-visible:bg-brand/70',
                              winners.has(k) && 'ring-2 ring-brand',
                            )}
                          >
                            {bet && <ChipStack cents={bet.amount_cents} />}
                          </button>
                        )
                      })}
                    </div>
                  </div>
                  <div className="grid grid-rows-3">
                    {[3, 2, 1].map((col) => {
                      const k = keyOf('column', [col])
                      const bet = bets.get(k)
                      return (
                        <button
                          key={col}
                          type="button"
                          onClick={() => place('column', [col])}
                          className={clsx('relative border border-white/15 text-xs font-bold text-white/90 hover:bg-white/10', winners.has(k) && 'bg-brand/30')}
                          aria-label={`Coluna ${col} (paga 2 para 1)`}
                        >
                          2:1
                          {bet && <ChipStack cents={bet.amount_cents} />}
                        </button>
                      )
                    })}
                  </div>
                </div>
                <div className="ml-[3.2rem] mr-[3.2rem] grid grid-cols-3">
                  {[1, 2, 3].map((d) => {
                    const k = keyOf('dozen', [d])
                    const bet = bets.get(k)
                    return (
                      <button
                        key={d}
                        type="button"
                        onClick={() => place('dozen', [d])}
                        className={clsx('relative h-11 border border-white/15 text-sm font-semibold text-white hover:bg-white/10', winners.has(k) && 'bg-brand/30')}
                      >
                        {d === 1 ? '1.ª 12' : d === 2 ? '2.ª 12' : '3.ª 12'}
                        {bet && <ChipStack cents={bet.amount_cents} />}
                      </button>
                    )
                  })}
                </div>
                <div className="ml-[3.2rem] mr-[3.2rem] grid grid-cols-6">
                  {OUTSIDE.map((o) => {
                    const k = keyOf(o.type, o.numbers)
                    const bet = bets.get(k)
                    return (
                      <button
                        key={o.type}
                        type="button"
                        onClick={() => place(o.type, o.numbers)}
                        className={clsx(
                          'relative h-11 border border-white/15 text-sm font-semibold text-white hover:brightness-125',
                          o.cls,
                          winners.has(k) && 'ring-2 ring-inset ring-brand',
                        )}
                      >
                        {o.label}
                        {bet && <ChipStack cents={bet.amount_cents} />}
                      </button>
                    )
                  })}
                </div>
              </div>
            </div>

            <div className="flex flex-col gap-4 rounded-2xl border border-border bg-surface p-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex flex-wrap items-center gap-2.5" role="group" aria-label="Valor da ficha">
                {g.chips_cents.map((c) => (
                  <Chip key={c} cents={c} selected={chip === c} onClick={() => setChip(c)} />
                ))}
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <Button variant="ghost" size="icon" onClick={undo} disabled={!historyStack.length || spinning} aria-label="Desfazer" title="Desfazer">
                  <RotateCcw className="size-4" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => loadBets([])} disabled={!bets.size || spinning} aria-label="Limpar" title="Limpar">
                  <Eraser className="size-4" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => loadBets(last)} disabled={!last.length || spinning} aria-label="Repetir" title="Repetir a última">
                  <Repeat className="size-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => loadBets(Array.from(bets.values()), 2)}
                  disabled={!bets.size || spinning}
                  aria-label="Dobrar"
                  title="Dobrar tudo"
                >
                  <span className="text-sm font-bold">×2</span>
                </Button>
              </div>
            </div>

            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <p className="text-sm text-muted">
                Aposta total <strong className="text-lg text-fg tabular-nums">{formatMoney(total)}</strong>
                {total > 0 && total < g.min_bet_cents && <span className="ml-2 text-warning">mínimo {formatMoney(g.min_bet_cents)}</span>}
              </p>
              <Button
                size="lg"
                onClick={() => spin.mutate(Array.from(bets.values()))}
                disabled={total < g.min_bet_cents || total > g.max_bet_cents || spinning}
                loading={spin.isPending}
                icon={<Sparkles className="size-5" />}
                className="sm:min-w-44"
              >
                {spinning ? 'A girar…' : 'Girar'}
              </Button>
            </div>
            {spin.isError && <Alert tone="danger">{errorMessage(spin.error)}</Alert>}
            <details className="text-sm text-muted">
              <summary className="cursor-pointer hover:text-fg">Como apostar e quanto paga</summary>
              <ul className="mt-2 list-disc space-y-1 pl-5">
                <li>Escolhe a ficha e toca num número (pleno, 35:1).</li>
                <li>Toca na linha entre dois números para um cavalo (17:1), no cruzamento de quatro para um quadrado (8:1).</li>
                <li>Na borda de baixo: transversal de 3 números (11:1) ou, entre duas colunas, seisena de 6 (5:1).</li>
                <li>Colunas e dúzias pagam 2:1; vermelho/preto, par/ímpar, 1–18/19–36 pagam 1:1 (o zero faz perder estas).</li>
              </ul>
            </details>
          </div>
        </div>
      </GamesGate>
    </div>
  )
}
