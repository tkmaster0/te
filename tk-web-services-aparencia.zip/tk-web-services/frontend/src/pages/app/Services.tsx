import { useEffect, useState } from 'react'
import { useLocation } from 'react-router-dom'
import { ChevronDown, ExternalLink, Gift, History, Plus } from 'lucide-react'
import { useConfig, useServices, useSubscriptions } from '../../api/queries'
import type { ServicesOut, Subscription } from '../../api/types'
import { useMe } from '../../auth/AuthProvider'
import { errorMessage } from '../../api/client'
import { AccessDetails } from '../../components/billing/AccessDetails'
import { ChangePlanModal } from '../../components/billing/ChangePlanModal'
import { HowItWorks } from '../../components/billing/Onboarding'
import { ProductIcon } from '../../components/billing/ProductIcon'
import { SubscriptionCard } from '../../components/billing/SubscriptionCard'
import {
  AppsCard,
  DevicesCard,
  IptvCard,
  JellyfinAccess,
  NowPlayingCard,
  PasswordSyncCard,
  QuickConnectCard,
  SeerrCard,
} from '../../components/streaming/StreamingPanels'
import { Alert, Badge, ButtonAnchor, ButtonLink, Card, DateText, PageHeader, SectionTitle, SkeletonCard, StatusBadge } from '../../components/ui'
import { formatDate } from '../../lib/format'
import { useText } from '../../lib/texts'

const LIVE = new Set(['active', 'past_due', 'canceling', 'bonus', 'suspended'])

function StreamingTools({ services }: { services: ServicesOut }) {
  const jf = services.jellyfin
  if (!jf.enabled && !services.iptv.enabled) return null
  return (
    <section aria-labelledby="tools-t" className="space-y-4">
      <SectionTitle id="tools-t">Ferramentas do TKFLIX</SectionTitle>
      <div className="grid grid-cols-1 items-start gap-4 lg:grid-cols-2">
        <div className="space-y-4">
          {jf.enabled && jf.linked && <QuickConnectCard />}
          {services.seerr.enabled && <SeerrCard seerr={services.seerr} />}
          {services.iptv.enabled && <IptvCard iptv={services.iptv} />}
        </div>
        <div className="space-y-4">
          <NowPlayingCard enabled={jf.linked} />
          {jf.enabled && <DevicesCard enabled={jf.linked} />}
        </div>
      </div>
      <AppsCard apps={services.apps} passwordLogin={jf.password_login} />
    </section>
  )
}

export function ServicesPage() {
  const t = useText()
  const me = useMe()
  const subs = useSubscriptions()
  const services = useServices()
  const { data: config } = useConfig()
  const loc = useLocation()
  const [changing, setChanging] = useState<Subscription | null>(null)

  const all = subs.data ?? []
  const live = all
    .filter((s) => LIVE.has(s.status))
    .sort((a, b) => Number(b.product.jellyfin_managed) - Number(a.product.jellyfin_managed))
  const ended = all.filter((s) => !LIVE.has(s.status))
  const grants = me.access.filter((a) => a.type === 'grant')
  const hasStreamingSub = live.some((s) => s.product.jellyfin_managed)
  const jfUrl = services.data?.jellyfin.url || config?.jellyfin_url

  useEffect(() => {
    if (!subs.data || !loc.hash) return
    const el = document.getElementById(loc.hash.slice(1))
    el?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }, [subs.data, services.data, loc.hash])

  return (
    <div>
      <PageHeader
        title={t('app.services.title')}
        description={t('app.services.description')}
        actions={
          <ButtonLink to="/app/planos" variant="secondary" icon={<Plus className="size-4" />}>
            Adicionar serviço
          </ButtonLink>
        }
      />
      {subs.isPending ? (
        <div className="space-y-4">
          <SkeletonCard lines={5} />
          <SkeletonCard lines={3} />
        </div>
      ) : subs.isError ? (
        <Alert tone="danger">{errorMessage(subs.error)}</Alert>
      ) : (
        <div className="space-y-8">
          {me.needs_password_sync && <PasswordSyncCard />}

          {live.length === 0 && grants.length === 0 && (
            <div className="space-y-4">
              <Alert tone="info" title="Ainda não tens serviços ativos">
                Escolhe o primeiro na loja — fica ativo em segundos.
              </Alert>
              <HowItWorks />
            </div>
          )}

          {live.length > 0 && (
            <div className="space-y-4">
              {live.map((s) =>
                s.product.jellyfin_managed ? (
                  <SubscriptionCard
                    key={s.id}
                    id={`sub-${s.id}`}
                    sub={s}
                    onChangePlan={setChanging}
                    primary={
                      jfUrl &&
                      s.status !== 'suspended' && (
                        <ButtonAnchor href={jfUrl} icon={<ExternalLink className="size-4" />}>
                          Abrir TKFLIX
                        </ButtonAnchor>
                      )
                    }
                  >
                    {services.isPending ? (
                      <SkeletonCard lines={2} className="border-0 p-0 sm:p-0" />
                    ) : services.isError ? (
                      <Alert tone="warning">Não foi possível obter os dados do Jellyfin: {errorMessage(services.error)}</Alert>
                    ) : (
                      <JellyfinAccess jf={services.data.jellyfin} />
                    )}
                  </SubscriptionCard>
                ) : (
                  <SubscriptionCard
                    key={s.id}
                    id={`sub-${s.id}`}
                    sub={s}
                    onChangePlan={setChanging}
                    primary={
                      s.app_url &&
                      s.status !== 'suspended' && (
                        <ButtonAnchor href={s.app_url} icon={<ExternalLink className="size-4" />}>
                          Abrir {s.product_name}
                        </ButtonAnchor>
                      )
                    }
                  >
                    {(Object.keys(s.access_details).length > 0 || s.access_instructions || s.fulfillment_status === 'pending') && (
                      <AccessDetails details={s.access_details} instructions={s.access_instructions} fulfillmentStatus={s.fulfillment_status} />
                    )}
                  </SubscriptionCard>
                ),
              )}
            </div>
          )}

          {grants.length > 0 && (
            <section aria-labelledby="grants-t">
              <SectionTitle id="grants-t">Ofertas</SectionTitle>
              <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                {grants.map((g) => (
                  <Card key={g.plan_code + (g.until ?? '')} className="flex items-start gap-3.5 p-5">
                    <span className="grid size-11 shrink-0 place-items-center rounded-xl bg-brand-soft text-brand-text">
                      <Gift className="size-5" aria-hidden />
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <p className="font-bold">{g.plan}</p>
                        <Badge tone="brand">Oferta</Badge>
                      </div>
                      <p className="mt-1 text-sm text-muted">
                        {g.until ? <>Acesso gratuito até {formatDate(g.until)}.</> : 'Acesso gratuito, sem data de fim.'} Não é cobrado.
                      </p>
                    </div>
                  </Card>
                ))}
              </div>
              {!hasStreamingSub && services.data?.jellyfin.enabled && (
                <Card className="mt-4 p-5 sm:p-6">
                  <div className="mb-4 flex items-center gap-3">
                    <ProductIcon icon="tv" />
                    <p className="font-bold">Acesso ao TKFLIX</p>
                  </div>
                  <JellyfinAccess jf={services.data.jellyfin} />
                </Card>
              )}
            </section>
          )}

          {services.data && (hasStreamingSub || services.data.jellyfin.enabled) && <StreamingTools services={services.data} />}

          {ended.length > 0 && (
            <details className="group card overflow-hidden">
              <summary className="flex cursor-pointer items-center gap-3 px-5 py-4 text-sm font-medium sm:px-6">
                <History className="size-4 text-muted" aria-hidden />
                Serviços terminados ({ended.length})
                <ChevronDown className="ml-auto size-4 text-muted transition-transform group-open:rotate-180" aria-hidden />
              </summary>
              <ul className="divide-y divide-border border-t border-border">
                {ended.map((s) => (
                  <li key={s.id} className="flex flex-wrap items-center gap-x-4 gap-y-1 px-5 py-3 text-sm sm:px-6">
                    <span className="min-w-0 flex-1">
                      <span className="font-medium">{s.plan.name}</span> <span className="text-muted">· {s.product_name}</span>
                    </span>
                    <span className="text-muted">
                      <DateText value={s.started_at} /> – <DateText value={s.ended_at} />
                    </span>
                    <StatusBadge status={s.status} />
                  </li>
                ))}
              </ul>
            </details>
          )}
        </div>
      )}
      <ChangePlanModal sub={changing} open={!!changing} onClose={() => setChanging(null)} />
    </div>
  )
}
