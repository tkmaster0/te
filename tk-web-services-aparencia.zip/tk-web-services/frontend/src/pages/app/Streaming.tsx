import { useMemo, useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { AlertTriangle, ExternalLink, LogIn, Settings2 } from 'lucide-react'
import { useBillingSummary, useConfig, useProducts, useSubscriptions } from '../../api/queries'
import type { Plan, Product, Subscription } from '../../api/types'
import { errorMessage } from '../../api/client'
import { ActionBanners } from '../../components/billing/ActionBanners'
import { ChangePlanModal } from '../../components/billing/ChangePlanModal'
import { MethodIcon } from '../../components/billing/PaymentModals'
import { OWNED, ProductSection } from '../../components/billing/ProductSection'
import { SubscribeModal } from '../../components/billing/SubscribeModal'
import { SubscriptionCard } from '../../components/billing/SubscriptionCard'
import { useIsScoped } from '../../components/billing/hooks'
import { Alert, ButtonAnchor, ButtonLink, Card, PageHeader, SkeletonCard } from '../../components/ui'

/**
 * Página focada só no streaming. É a única página disponível numa sessão aberta a partir do Jellyfin
 * (sem password), mas também pode ser usada numa sessão normal.
 */
export function StreamingPage() {
  const scoped = useIsScoped()
  const [params, setParams] = useSearchParams()
  const { data: config } = useConfig()
  const summary = useBillingSummary()
  const subs = useSubscriptions()
  const products = useProducts()
  const [adding, setAdding] = useState<{ plan: Plan; product: Product } | null>(null)
  const [changing, setChanging] = useState<{ sub: Subscription; planId?: number } | null>(null)

  const streamingProduct = products.data?.find((p) => p.jellyfin_managed)
  const sub = (subs.data ?? []).find((s) => s.product.jellyfin_managed && OWNED.has(s.status))
  const suspended = (subs.data ?? []).find((s) => s.product.jellyfin_managed && s.status === 'suspended')
  const current = sub ?? suspended
  const s = summary.data
  const method = s?.payment_methods.find((m) => m.id === s.default_payment_method_id)
  const badMethod = s?.payment_methods.find((m) => m.status === 'unusable')

  const planParam = Number(params.get('plano')) || null
  const preselected = useMemo(() => {
    if (!planParam || !streamingProduct || subs.isPending) return null
    const plan = streamingProduct.plans.find((p) => p.id === planParam)
    return plan ? { plan, product: streamingProduct } : null
  }, [planParam, streamingProduct, subs.isPending])
  const clearParam = () => {
    if (!params.has('plano')) return
    params.delete('plano')
    setParams(params, { replace: true })
  }
  const subscribeTarget = adding ?? (preselected && !sub ? preselected : null)
  const changeTarget = changing ?? (preselected && sub?.can_change && sub.plan.id !== preselected.plan.id ? { sub, planId: preselected.plan.id } : null)
  const loading = subs.isPending || products.isPending || summary.isPending

  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader
        title="O teu streaming"
        description={sub ? 'Estado, próxima renovação e opções do teu plano TKFLIX.' : 'Escolhe um plano para veres filmes, séries e TV no Jellyfin.'}
      />

      {loading ? (
        <div className="space-y-4">
          <SkeletonCard lines={4} />
          <SkeletonCard lines={2} />
        </div>
      ) : subs.isError ? (
        <Alert tone="danger">{errorMessage(subs.error)}</Alert>
      ) : (
        <div className="space-y-6">
          {s && <ActionBanners actions={s.actions} scoped={scoped} />}

          {current ? (
            <>
              <SubscriptionCard
                sub={current}
                scoped={scoped}
                onChangePlan={(x) => setChanging({ sub: x })}
                primary={
                  config?.jellyfin_url &&
                  current.status !== 'suspended' && (
                    <ButtonAnchor href={config.jellyfin_url} icon={<ExternalLink className="size-4" />}>
                      Abrir TKFLIX
                    </ButtonAnchor>
                  )
                }
              />

              <Card className="p-5 sm:p-6">
                <h2 className="text-sm font-semibold">Pagamento</h2>
                {method ? (
                  <div className="mt-3 flex items-center gap-3">
                    <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-elevated">
                      <MethodIcon kind={method.kind} />
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-medium">{method.label}</p>
                      <p className="text-xs text-muted">
                        {s?.anchor_day ? `Cobrado junto com os teus outros serviços, no dia ${s.anchor_day}.` : 'Método predefinido.'}
                      </p>
                    </div>
                    {!scoped && (
                      <Link to="/app/faturacao" className="link shrink-0 text-sm">
                        Gerir
                      </Link>
                    )}
                  </div>
                ) : (
                  <div className="mt-3 flex items-start gap-3 rounded-xl border border-danger/40 bg-danger-soft p-4">
                    <AlertTriangle className="mt-0.5 size-5 shrink-0 text-danger" aria-hidden />
                    <div className="min-w-0 flex-1 text-sm">
                      <p className="font-semibold">{badMethod ? `${badMethod.label} já não pode ser usado` : 'Sem método de pagamento válido'}</p>
                      {badMethod?.status_reason && <p className="mt-0.5 text-fg/80">{badMethod.status_reason}</p>}
                      {scoped ? (
                        <>
                          <p className="mt-2 text-fg/80">Para atualizar o método de pagamento entra com a tua password.</p>
                          <ButtonLink to="/login?next=/app/faturacao" size="sm" className="mt-3" icon={<LogIn className="size-4" />}>
                            Entrar com password
                          </ButtonLink>
                        </>
                      ) : (
                        <ButtonLink to="/app/faturacao?metodo=novo" size="sm" className="mt-3">
                          Adicionar método
                        </ButtonLink>
                      )}
                    </div>
                  </div>
                )}
              </Card>
              {!scoped && (
                <p className="text-center text-sm text-muted">
                  <Link to="/app/servicos" className="link inline-flex items-center gap-1">
                    <Settings2 className="size-4" aria-hidden /> Dispositivos, Quick Connect, pedidos e IPTV
                  </Link>
                </p>
              )}
            </>
          ) : products.isError ? (
            <Alert tone="danger">{errorMessage(products.error)}</Alert>
          ) : streamingProduct ? (
            <ProductSection product={streamingProduct} owned={undefined} onAdd={(plan, product) => setAdding({ plan, product })} onChange={() => undefined} />
          ) : (
            <Alert tone="info">O streaming não está disponível de momento.</Alert>
          )}

          {scoped && (
            <p className="text-center text-xs text-muted">
              Para gerir outros serviços, a faturação ou a tua conta,{' '}
              <Link to="/login?next=/app" className="link">
                entra com a tua password
              </Link>
              .
            </p>
          )}
        </div>
      )}

      <SubscribeModal
        plan={subscribeTarget?.plan ?? null}
        product={subscribeTarget?.product ?? null}
        open={!!subscribeTarget}
        onClose={() => {
          setAdding(null)
          clearParam()
        }}
      />
      <ChangePlanModal
        sub={changeTarget?.sub ?? null}
        initialPlanId={changeTarget?.planId}
        open={!!changeTarget}
        onClose={() => {
          setChanging(null)
          clearParam()
        }}
      />
    </div>
  )
}
