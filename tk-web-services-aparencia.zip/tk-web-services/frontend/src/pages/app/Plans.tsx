import { useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { CalendarClock, LayoutGrid } from 'lucide-react'
import { useBillingSummary, useProducts, useSubscriptions } from '../../api/queries'
import type { Plan, Product, Subscription } from '../../api/types'
import { useMe } from '../../auth/AuthProvider'
import { errorMessage } from '../../api/client'
import { ChangePlanModal } from '../../components/billing/ChangePlanModal'
import { HowItWorks } from '../../components/billing/Onboarding'
import { OWNED, ProductSection } from '../../components/billing/ProductSection'
import { SubscribeModal } from '../../components/billing/SubscribeModal'
import { Alert, Button, EmptyState, PageHeader, Skeleton } from '../../components/ui'
import { useText } from '../../lib/texts'

export function PlansPage() {
  const t = useText()
  const me = useMe()
  const [params, setParams] = useSearchParams()
  const cancelled = params.get('cancelado') === '1'
  const products = useProducts()
  const subs = useSubscriptions()
  const summary = useBillingSummary()
  const [adding, setAdding] = useState<{ plan: Plan; product: Product } | null>(null)
  const [changing, setChanging] = useState<{ plan: Plan; sub: Subscription } | null>(null)

  const ownedByProduct = useMemo(() => {
    const m = new Map<number, Subscription>()
    for (const s of subs.data ?? []) if (OWNED.has(s.status) && !m.has(s.product.id)) m.set(s.product.id, s)
    return m
  }, [subs.data])

  // ?plano=<id> abre logo o passo certo (subscrever ou mudar)
  const planParam = Number(params.get('plano')) || null
  const fromParam = useMemo(() => {
    if (!planParam || !products.data || !subs.data) return null
    for (const p of products.data) {
      const plan = p.plans.find((x) => x.id === planParam)
      if (plan) return { plan, product: p, owned: ownedByProduct.get(p.id) }
    }
    return null
  }, [planParam, products.data, subs.data, ownedByProduct])
  const clearPlanParam = () => {
    if (!params.has('plano')) return
    params.delete('plano')
    setParams(params, { replace: true })
  }

  const subscribeTarget = adding ?? (fromParam && !fromParam.owned ? { plan: fromParam.plan, product: fromParam.product } : null)
  const changeTarget = changing ?? (fromParam?.owned && fromParam.owned.can_change && fromParam.owned.plan.id !== fromParam.plan.id ? { plan: fromParam.plan, sub: fromParam.owned } : null)
  const anchor = summary.data?.anchor_day
  const hasServices = ownedByProduct.size > 0

  return (
    <div>
      <PageHeader title={t('app.store.title')} description={t('app.store.description')} />

      <div className="space-y-6">
        {cancelled && (
          <Alert
            tone="info"
            title="Pagamento cancelado"
            action={
              <Button
                size="sm"
                variant="ghost"
                onClick={() => {
                  params.delete('cancelado')
                  setParams(params, { replace: true })
                }}
              >
                Fechar
              </Button>
            }
          >
            Não foi feita nenhuma cobrança. Podes tentar outra vez quando quiseres.
          </Alert>
        )}
        {!me.email_verified && (
          <Alert tone="warning" title="Confirma o teu email para poderes subscrever">
            Enviámos um link de confirmação para {me.email}.
          </Alert>
        )}

        {hasServices && anchor ? (
          <p className="flex items-start gap-2.5 rounded-xl border border-border bg-surface px-4 py-3 text-sm">
            <CalendarClock className="mt-0.5 size-4 shrink-0 text-brand-text" aria-hidden />
            <span>
              O que adicionares entra na tua cobrança do <strong>dia {anchor}</strong>. Até lá pagas só os dias que usares (pro-rata) — vês sempre o valor
              exato antes de confirmar.
            </span>
          </p>
        ) : (
          !subs.isPending && <HowItWorks compact cta={false} />
        )}
      </div>

      <div className="mt-10">
        {products.isPending || subs.isPending ? (
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <Skeleton className="h-[26rem]" />
            <Skeleton className="h-[26rem]" />
          </div>
        ) : products.isError ? (
          <Alert tone="danger">{errorMessage(products.error)}</Alert>
        ) : !products.data?.length ? (
          <EmptyState icon={<LayoutGrid className="size-6" />} title="Sem serviços disponíveis" description="Ainda não há nada publicado na loja. Volta mais tarde." />
        ) : (
          <div className="space-y-14">
            {products.data.map((product) => (
              <ProductSection
                key={product.id}
                product={product}
                owned={ownedByProduct.get(product.id)}
                onAdd={(plan, p) => setAdding({ plan, product: p })}
                onChange={(plan, sub) => setChanging({ plan, sub })}
              />
            ))}
          </div>
        )}
      </div>

      <SubscribeModal
        plan={subscribeTarget?.plan ?? null}
        product={subscribeTarget?.product ?? null}
        open={!!subscribeTarget}
        onClose={() => {
          setAdding(null)
          clearPlanParam()
        }}
      />
      <ChangePlanModal
        sub={changeTarget?.sub ?? null}
        initialPlanId={changeTarget?.plan.id}
        open={!!changeTarget}
        onClose={() => {
          setChanging(null)
          clearPlanParam()
        }}
      />
    </div>
  )
}
