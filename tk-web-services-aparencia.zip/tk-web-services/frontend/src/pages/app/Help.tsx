import { useEffect, useRef } from 'react'
import clsx from 'clsx'
import { Bot, Brain, LifeBuoy, Mail, MessageCircle, MessagesSquare, SquarePen } from 'lucide-react'
import { useQuery } from '@tanstack/react-query'
import { api } from '../../api/client'
import { useAction } from '../../api/mutation'
import { useAssistantStatus, useMyConversations } from '../../api/assistant'
import { useConfig } from '../../api/queries'
import { useMe } from '../../auth/AuthProvider'
import { AssistantChat } from '../../components/assistant/AssistantChat'
import { chatStore, useChatState } from '../../components/assistant/chatStore'
import { AgentBadge, CHANNEL_LABEL } from '../../components/assistant/labels'
import { Badge, Button, ButtonAnchor, ButtonLink, Card, EmptyState, PageHeader, Skeleton } from '../../components/ui'
import { relativeTime } from '../../lib/format'
import { useText } from '../../lib/texts'

function ConversationList({ onPick }: { onPick: () => void }) {
  const q = useMyConversations()
  const state = useChatState()
  return (
    <Card className="overflow-hidden">
      <div className="flex items-center justify-between gap-2 border-b border-border px-4 py-3">
        <h2 className="flex items-center gap-2 text-sm font-semibold">
          <MessagesSquare className="size-4 text-brand-text" aria-hidden /> Conversas anteriores
        </h2>
        {!!q.data?.length && <Badge>{q.data.length}</Badge>}
      </div>
      {q.isLoading ? (
        <div className="space-y-2 p-3">
          {[0, 1, 2].map((i) => (
            <Skeleton key={i} className="h-14 w-full" />
          ))}
        </div>
      ) : !q.data?.length ? (
        <p className="px-4 py-6 text-center text-sm text-muted">Ainda não falaste com o assistente.</p>
      ) : (
        <ul className="scrollbar-thin max-h-[26rem] divide-y divide-border overflow-y-auto">
          {q.data.map((c) => {
            const active = c.id === state.convId
            return (
              <li key={c.id}>
                <button
                  type="button"
                  onClick={() => {
                    void chatStore.open(c.id)
                    onPick()
                  }}
                  disabled={state.sending}
                  aria-current={active ? 'true' : undefined}
                  className={clsx(
                    'relative block w-full px-4 py-3 text-left transition-colors disabled:cursor-not-allowed',
                    active ? 'bg-elevated' : 'hover:bg-elevated/60',
                  )}
                >
                  {active && <span className="absolute inset-y-2 left-0 w-1 rounded-r-full bg-brand" aria-hidden />}
                  <p className="truncate text-sm font-medium">{c.title || 'Conversa sem título'}</p>
                  <div className="mt-1 flex flex-wrap items-center gap-1.5 text-xs text-muted">
                    <AgentBadge agent={c.agent} />
                    {c.channel !== 'web' && <Badge>{CHANNEL_LABEL[c.channel] ?? c.channel}</Badge>}
                    {c.status === 'escalated' && <Badge tone="warning">Com um administrador</Badge>}
                    <span className="ml-auto whitespace-nowrap text-subtle">{relativeTime(c.updated_at ?? c.created_at)}</span>
                  </div>
                </button>
              </li>
            )
          })}
        </ul>
      )}
    </Card>
  )
}

function OtherChannels() {
  const status = useAssistantStatus()
  const { data: config } = useConfig()
  const me = useMe()
  const wa = status.data?.whatsapp
  const support = config?.site.support_email
  const scoped = me.session_scope === 'streaming'
  if (!wa?.enabled && !support) return null
  return (
    <Card className="p-4">
      <h2 className="flex items-center gap-2 text-sm font-semibold">
        <LifeBuoy className="size-4 text-brand-text" aria-hidden /> Outras formas de ajuda
      </h2>
      <div className="mt-3 space-y-2">
        {wa?.enabled &&
          (wa.linked ? (
            <p className="text-sm text-muted">
              O teu WhatsApp está ligado — podes falar com o assistente pelo número <strong className="text-fg">+{wa.number}</strong>.
            </p>
          ) : (
            !scoped && (
              <ButtonLink to="/app/conta?tab=whatsapp" variant="secondary" size="sm" className="w-full" icon={<MessageCircle className="size-4" />}>
                Ligar o WhatsApp
              </ButtonLink>
            )
          ))}
        {support && (
          <ButtonAnchor href={`mailto:${support}`} external={false} variant="ghost" size="sm" className="w-full" icon={<Mail className="size-4" />}>
            {support}
          </ButtonAnchor>
        )}
      </div>
    </Card>
  )
}

/** O que cada assistente guarda sobre o cliente (separado por assistente) e o botão para esquecer. */
function Memory() {
  const q = useQuery({ queryKey: ['assistant', 'memory'], queryFn: () => api.get<{ agent: string; label: string; summary: string }[]>('/api/assistant/memory') })
  const forget = useAction(() => api.del<{ message: string }>('/api/assistant/memory'), { invalidate: [['assistant', 'memory']] })
  const notes = (q.data ?? []).filter((n) => n.summary)
  return (
    <Card className="p-5">
      <p className="flex items-center gap-2 font-semibold">
        <Brain className="size-4 text-brand-text" aria-hidden /> Memória
      </p>
      <p className="mt-1 text-sm text-muted">Cada assistente lembra-se das conversas anteriores contigo — em separado, e sem guardar passwords nem dados de pagamento.</p>
      {notes.map((n) => (
        <details key={n.agent} className="mt-3 rounded-xl bg-elevated px-3 py-2 text-sm">
          <summary className="cursor-pointer font-medium">{n.label}</summary>
          <p className="mt-2 whitespace-pre-line text-xs text-muted">{n.summary}</p>
        </details>
      ))}
      <Button size="sm" variant="ghost" className="mt-3" loading={forget.isPending} onClick={() => forget.mutate()}>
        Esquecer conversas anteriores
      </Button>
    </Card>
  )
}

export function HelpPage() {
  const t = useText()
  const status = useAssistantStatus()
  const state = useChatState()
  const chatRef = useRef<HTMLDivElement>(null)
  // No telemóvel a lista fica por baixo do chat: ao escolher uma conversa, volta a mostrar o chat.
  const showChat = () => {
    if (window.matchMedia('(max-width: 1023px)').matches) chatRef.current?.scrollIntoView({ block: 'start', behavior: 'smooth' })
  }

  useEffect(() => {
    chatStore.start()
  }, [])

  if (status.isLoading) return <Skeleton className="h-[70vh] w-full rounded-2xl" />

  if (!status.data?.enabled)
    return (
      <div>
        <PageHeader title={t('app.help.title')} description={t('app.help.description')} />
        <Card>
          <EmptyState
            icon={<Bot className="size-6" />}
            title="O assistente não está disponível"
            description="De momento o assistente automático está desligado. Se precisares de ajuda, contacta o suporte."
          />
        </Card>
      </div>
    )

  return (
    <div>
      <PageHeader
        title={t('app.help.title')}
        description={t('app.help.description')}
        actions={
          <Button variant="secondary" icon={<SquarePen className="size-4" />} onClick={() => chatStore.reset()} disabled={state.sending || (!state.convId && !state.messages.length)}>
            Nova conversa
          </Button>
        }
      />
      <div className="grid grid-cols-1 items-start gap-4 lg:grid-cols-[1fr_300px]">
        <div ref={chatRef} className="card flex scroll-mt-20 h-[calc(100dvh-15rem)] min-h-[30rem] flex-col overflow-hidden lg:h-[calc(100dvh-13rem)]">
          <AssistantChat autoFocus />
        </div>
        <div className="space-y-4">
          <ConversationList onPick={showChat} />
          <OtherChannels />
          <Memory />
        </div>
      </div>
    </div>
  )
}
