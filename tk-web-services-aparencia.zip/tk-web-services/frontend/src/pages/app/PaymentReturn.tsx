import { useEffect, useRef, useState, type ReactNode } from 'react'
import { useSearchParams } from 'react-router-dom'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { CheckCircle2, Clock, PartyPopper, XCircle } from 'lucide-react'
import { api, ApiError, errorMessage } from '../../api/client'
import { BILLING_INVALIDATE } from '../../api/keys'
import type { CheckoutStatus, Invoice } from '../../api/types'
import { useIsScoped } from '../../components/billing/hooks'
import { Alert, Button, ButtonLink, Card, Spinner } from '../../components/ui'
import { RotateCw } from 'lucide-react'
import { PROVIDER_LABEL } from '../../i18n/labels'

const MAX_MS = 60_000

function returnLabel(to: string): string {
  if (to.startsWith('/app/servicos')) return 'Ver os meus serviços'
  if (to.startsWith('/app/streaming')) return 'Voltar ao streaming'
  if (to.startsWith('/app/faturacao')) return 'Ir para Faturação'
  return 'Continuar'
}

function Result({ icon, title, text, children }: { icon: ReactNode; title: string; text: ReactNode; children?: ReactNode }) {
  return (
    <Card className="flex flex-col items-center px-6 py-10 text-center sm:px-10" aria-live="polite">
      <div className="mb-5">{icon}</div>
      <h1 className="text-2xl font-bold">{title}</h1>
      <div className="mt-2 max-w-md text-muted">{text}</div>
      {children && <div className="mt-7 flex w-full flex-col gap-2 sm:w-auto sm:flex-row">{children}</div>}
    </Card>
  )
}

/** Regresso da página alojada do fornecedor: acompanha o pedido até ficar concluído. */
export function PaymentReturnPage() {
  const [params] = useSearchParams()
  const id = params.get('checkout') ?? ''
  const qc = useQueryClient()
  const scoped = useIsScoped()
  const startedAt = useRef(Date.now())
  const [timedOut, setTimedOut] = useState(false)
  const [attempt, setAttempt] = useState(0)

  const q = useQuery({
    queryKey: ['checkout', id],
    queryFn: () => api.get<CheckoutStatus>(`/api/billing/checkout/${encodeURIComponent(id)}`),
    enabled: !!id,
    // Erros do servidor/fornecedor são transitórios (o webhook conclui o pedido de qualquer forma):
    // continua a tentar até ao limite; um 4xx (pedido inexistente) é definitivo.
    retry: (n, err) => (err instanceof ApiError && err.status < 500 ? false : n < 20 && Date.now() - startedAt.current < MAX_MS),
    retryDelay: 3000,
    refetchInterval: (query) => {
      const s = query.state.data?.status
      if (s && s !== 'pending') return false
      if (Date.now() - startedAt.current > MAX_MS) return false
      return 2000
    },
  })
  const co = q.data
  const status = co?.status

  const invoice = useQuery({
    queryKey: ['billing', 'invoice', co?.invoice_id],
    queryFn: () => api.get<Invoice>(`/api/billing/invoices/${co!.invoice_id}`),
    enabled: status === 'completed' && co?.purpose === 'pay_invoice' && !!co?.invoice_id && !scoped,
    retry: false,
  })

  useEffect(() => {
    const t = window.setTimeout(() => setTimedOut(true), MAX_MS + 500)
    return () => window.clearTimeout(t)
  }, [attempt])

  useEffect(() => {
    if (status && status !== 'pending') for (const k of BILLING_INVALIDATE) void qc.invalidateQueries({ queryKey: k })
  }, [status, qc])

  const back = co?.return_to ?? (scoped ? '/app/streaming' : '/app/faturacao')
  let body: ReactNode

  if (!id) {
    body = (
      <Result icon={<XCircle className="size-10 text-danger" />} title="Pedido desconhecido" text="Não encontrámos a referência deste pagamento.">
        <ButtonLink to={scoped ? '/app/streaming' : '/app/faturacao'}>Voltar</ButtonLink>
      </Result>
    )
  } else if (q.isError && !(q.error instanceof ApiError && q.error.status >= 500)) {
    body = (
      <Result icon={<XCircle className="size-10 text-danger" />} title="Não foi possível confirmar" text={errorMessage(q.error)}>
        <ButtonLink to={back}>{returnLabel(back)}</ButtonLink>
      </Result>
    )
  } else if (status === 'completed' && co) {
    let icon: ReactNode = <CheckCircle2 className="size-12 text-success" aria-hidden />
    let title = 'Concluído'
    let text: ReactNode = 'Está tudo tratado.'
    if (co.purpose === 'setup_pm' && co.subscription_id) {
      icon = <PartyPopper className="size-12 text-brand-text" aria-hidden />
      title = 'Serviço ativo!'
      text = 'O teu método de pagamento ficou guardado e o serviço já está a funcionar. As próximas cobranças são automáticas, todas juntas no teu dia de faturação.'
    } else if (co.purpose === 'setup_pm') {
      title = 'Método guardado'
      text = 'Passa a ser o teu método predefinido e é usado em todas as próximas cobranças.'
    } else if (co.purpose === 'pay_invoice') {
      const st = invoice.data?.status
      title = st === 'paid' ? 'Pagamento recebido' : st === 'processing' ? 'Pagamento a processar' : 'Pagamento recebido / a processar'
      text =
        st === 'paid'
          ? 'Obrigado! A cobrança está paga e os teus serviços continuam ativos.'
          : 'Obrigado! Com cartão fica confirmado na hora; por débito direto demora 2–5 dias úteis. Os serviços continuam ativos entretanto.'
      if (st === 'processing') icon = <Clock className="size-12 text-info" aria-hidden />
    }
    body = (
      <Result icon={icon} title={title} text={text}>
        {co.error && (
          <Alert tone="warning" className="text-left sm:max-w-md">
            {co.purpose === 'setup_pm' ? 'O método foi guardado, mas o serviço não foi ativado: ' : ''}
            {co.error}
          </Alert>
        )}
        <ButtonLink to={back}>{returnLabel(back)}</ButtonLink>
      </Result>
    )
  } else if (status === 'cancelled' || status === 'failed') {
    body = (
      <Result
        icon={<XCircle className="size-12 text-danger" aria-hidden />}
        title={status === 'cancelled' ? 'Cancelado' : 'Não foi possível concluir'}
        text={status === 'cancelled' ? 'Não foi feita nenhuma cobrança nem alteração. Podes tentar outra vez quando quiseres.' : co?.error ?? 'Tenta novamente ou escolhe outro método.'}
      >
        <ButtonLink to={back}>{returnLabel(back)}</ButtonLink>
      </Result>
    )
  } else if (timedOut || q.isError) {
    body = (
      <Result
        icon={<Clock className="size-12 text-warning" aria-hidden />}
        title="Ainda a processar"
        text={`${PROVIDER_LABEL[co?.provider ?? ''] ?? 'O fornecedor de pagamento'} ainda não confirmou. Pode demorar alguns minutos — avisamos-te por email quando estiver concluído.`}
      >
        <Button
          variant="secondary"
          icon={<RotateCw className="size-4" />}
          onClick={() => {
            startedAt.current = Date.now()
            setTimedOut(false)
            setAttempt((a) => a + 1)
            void q.refetch()
          }}
        >
          Verificar de novo
        </Button>
        <ButtonLink to={back}>{returnLabel(back)}</ButtonLink>
      </Result>
    )
  } else {
    body = (
      <Result
        icon={<Spinner className="size-12 text-brand" label="A confirmar" />}
        title="A confirmar com o fornecedor…"
        text="Isto demora normalmente poucos segundos. Não feches esta página."
      />
    )
  }

  return <div className="mx-auto max-w-lg pt-6 sm:pt-12">{body}</div>
}
