import { Compass } from 'lucide-react'
import { ButtonLink, EmptyState } from '../../components/ui'
import { Logo } from '../../components/Logo'
import { Link } from 'react-router-dom'

export function NotFoundPage({ inApp }: { inApp?: boolean }) {
  const body = (
    <EmptyState
      className={inApp ? 'min-h-[60vh] justify-center' : 'flex-1 justify-center'}
      icon={<Compass className="size-6" />}
      title="Página não encontrada"
      description="O endereço que abriste não existe ou mudou de sítio."
      action={<ButtonLink to={inApp ? '/app' : '/'}>{inApp ? 'Voltar ao início' : 'Ir para a página inicial'}</ButtonLink>}
    />
  )
  if (inApp) return body
  return (
    <div className="flex min-h-dvh flex-col">
      <header className="px-4 py-4 sm:px-6">
        <Link to="/" aria-label="TK Web Services — página inicial">
          <Logo />
        </Link>
      </header>
      {body}
    </div>
  )
}
