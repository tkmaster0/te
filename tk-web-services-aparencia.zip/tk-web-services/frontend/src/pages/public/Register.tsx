import { useEffect, useMemo, useState, type FormEvent } from 'react'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { Check, Gift, Loader2, UserPlus, X } from 'lucide-react'
import { api, errorMessage } from '../../api/client'
import type { LoginOut } from '../../api/types'
import { useConfig } from '../../api/queries'
import { useAuth } from '../../auth/AuthProvider'
import { AuthCard } from '../../layouts/PublicLayout'
import { Alert, Button, Checkbox, Field, FullPageSpinner, Input, PasswordInput } from '../../components/ui'
import { PasswordMeter } from '../../components/PasswordMeter'
import { isExternalTarget, safeNext } from '../../lib/redirect'
import { useText } from '../../lib/texts'

function useDebounced<T>(value: T, ms = 400): T {
  const [v, setV] = useState(value)
  useEffect(() => {
    const t = window.setTimeout(() => setV(value), ms)
    return () => window.clearTimeout(t)
  }, [value, ms])
  return v
}

const USERNAME_RE = /^[a-z0-9._-]{3,32}$/

export function RegisterPage() {
  const t = useText()
  const [params] = useSearchParams()
  const next = params.get('next')
  const navigate = useNavigate()
  const { me, loading, setMe } = useAuth()
  const { data: config } = useConfig()
  const inviteRequired = (config?.registration_mode ?? 'invite') === 'invite'

  const [invite, setInvite] = useState(params.get('convite') ?? '')
  const [displayName, setDisplayName] = useState('')
  const [username, setUsername] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [terms, setTerms] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const [done, setDone] = useState(false)

  const uname = username.trim().toLowerCase()
  const debUser = useDebounced(uname)
  const debInvite = useDebounced(invite.trim(), 500)

  const userCheck = useQuery({
    queryKey: ['check-username', debUser],
    queryFn: () => api.get<{ available: boolean; reason: string | null }>(`/api/auth/check-username?u=${encodeURIComponent(debUser)}`),
    enabled: debUser.length >= 3 && USERNAME_RE.test(debUser),
    staleTime: 30_000,
    retry: false,
  })
  const inviteCheck = useQuery({
    queryKey: ['check-invite', debInvite.toUpperCase()],
    queryFn: () => api.get<{ valid: boolean; inviter?: string | null; unlocks?: string[] }>(`/api/auth/invite/${encodeURIComponent(debInvite)}`),
    enabled: debInvite.length >= 4,
    staleTime: 60_000,
    retry: false,
  })

  useEffect(() => {
    if (!loading && me && !busy && !done) navigate('/app', { replace: true })
  }, [loading, me, busy, done, navigate])

  const usernameState = useMemo(() => {
    if (!uname) return null
    if (uname.length < 3) return { ok: false, msg: 'Mínimo 3 caracteres.' }
    if (!USERNAME_RE.test(uname)) return { ok: false, msg: "Só letras minúsculas, números, '.', '_' ou '-'." }
    if (debUser !== uname || userCheck.isFetching) return { ok: null, msg: 'A verificar…' }
    if (userCheck.data) return userCheck.data.available ? { ok: true, msg: 'Disponível' } : { ok: false, msg: userCheck.data.reason ?? 'Indisponível.' }
    return null
  }, [uname, debUser, userCheck.isFetching, userCheck.data])

  const inviteState = useMemo(() => {
    const code = invite.trim()
    if (code.length < 4) return null
    if (debInvite !== code || inviteCheck.isFetching) return { ok: null, msg: 'A verificar convite…' }
    if (inviteCheck.data?.valid) {
      const who = inviteCheck.data.inviter ? `Convidado por ${inviteCheck.data.inviter}` : 'Convite válido'
      const unlocks = inviteCheck.data.unlocks ?? []
      return { ok: true, msg: unlocks.length ? `${who} · desbloqueia ${unlocks.join(', ')}` : who }
    }
    if (inviteCheck.data && !inviteCheck.data.valid) return { ok: false, msg: 'Convite inválido, expirado ou já utilizado.' }
    return null
  }, [invite, debInvite, inviteCheck.isFetching, inviteCheck.data])

  const mismatch = confirm.length > 0 && confirm !== password
  const termsRequired = !!(config?.site.terms_url || config?.site.privacy_url)
  const canSubmit =
    uname.length >= 3 &&
    email.includes('@') &&
    password.length >= 8 &&
    !mismatch &&
    confirm.length > 0 &&
    (!inviteRequired || invite.trim().length >= 4) &&
    usernameState?.ok !== false &&
    (!termsRequired || terms)

  const submit = async (e: FormEvent) => {
    e.preventDefault()
    if (!canSubmit) return
    setError(null)
    setBusy(true)
    try {
      const res = await api.post<LoginOut>('/api/auth/register', {
        email: email.trim(),
        username: uname,
        password,
        invite_code: invite.trim() || undefined,
        display_name: displayName.trim() || undefined,
        accept_terms: true,
      })
      setDone(true)
      if (res.user) setMe(res.user)
      const dest = next ? safeNext(next, res.redirect || '/app') : res.redirect || '/app'
      if (isExternalTarget(dest)) window.location.href = dest
      else navigate(dest, { replace: true })
    } catch (err) {
      setError(errorMessage(err))
      setBusy(false)
      window.scrollTo({ top: 0, behavior: 'smooth' })
    }
  }

  if (loading) return <FullPageSpinner />

  const stateIcon = (s: { ok: boolean | null } | null) =>
    !s ? null : s.ok === null ? (
      <Loader2 className="size-3.5 animate-spin" aria-hidden />
    ) : s.ok ? (
      <Check className="size-3.5" aria-hidden />
    ) : (
      <X className="size-3.5" aria-hidden />
    )
  const stateCls = (s: { ok: boolean | null } | null) => (!s ? '' : s.ok === null ? 'text-muted' : s.ok ? 'text-success' : 'text-danger')

  return (
    <AuthCard
      title={t('auth.register.title')}
      description={inviteRequired ? t('auth.register.description_invite') : t('auth.register.description_open')}
    >
      <form onSubmit={submit} className="space-y-4" noValidate>
        {error && <Alert tone="danger">{error}</Alert>}

        <Field label="Código de convite" optional={!inviteRequired}>
          <Input
            value={invite}
            onChange={(e) => setInvite(e.target.value.toUpperCase())}
            autoCapitalize="characters"
            autoComplete="off"
            spellCheck={false}
            placeholder="TK-XXXX-XXXX"
            className="font-mono uppercase tracking-wider"
            required={inviteRequired}
          />
        </Field>
        {inviteState && (
          <p className={`-mt-2 flex items-center gap-1.5 text-xs font-medium ${stateCls(inviteState)}`} aria-live="polite">
            {inviteState.ok ? <Gift className="size-3.5" aria-hidden /> : stateIcon(inviteState)}
            {inviteState.msg}
          </p>
        )}

        <Field label="Nome" optional hint="Como te devemos tratar.">
          <Input value={displayName} onChange={(e) => setDisplayName(e.target.value)} autoComplete="name" maxLength={120} />
        </Field>

        <Field label="Username" hint={!usernameState ? 'É o nome com que entras no portal e nos serviços TKWS. Letras minúsculas, números, “.”, “_” ou “-”.' : undefined}>
          <Input
            value={username}
            onChange={(e) => setUsername(e.target.value.toLowerCase().replace(/\s/g, ''))}
            autoComplete="username"
            autoCapitalize="none"
            autoCorrect="off"
            spellCheck={false}
            maxLength={32}
            required
          />
        </Field>
        {usernameState && (
          <p className={`-mt-2 flex items-center gap-1.5 text-xs font-medium ${stateCls(usernameState)}`} aria-live="polite">
            {stateIcon(usernameState)}
            {usernameState.msg}
          </p>
        )}

        <Field label="Email">
          <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" inputMode="email" required />
        </Field>

        <Field label="Password">
          <PasswordInput value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="new-password" minLength={8} required />
        </Field>
        <PasswordMeter password={password} username={uname} email={email} />

        <Field label="Confirmar password" error={mismatch ? 'As passwords não coincidem.' : undefined}>
          <PasswordInput value={confirm} onChange={(e) => setConfirm(e.target.value)} autoComplete="new-password" required />
        </Field>

        {termsRequired && (
          <Checkbox
            checked={terms}
            onChange={(e) => setTerms(e.target.checked)}
            label={
              <>
                Li e aceito os{' '}
                {config?.site.terms_url ? (
                  <a className="link" href={config.site.terms_url} target="_blank" rel="noopener noreferrer">
                    termos de utilização
                  </a>
                ) : (
                  'termos de utilização'
                )}
                {config?.site.privacy_url && (
                  <>
                    {' '}e a{' '}
                    <a className="link" href={config.site.privacy_url} target="_blank" rel="noopener noreferrer">
                      política de privacidade
                    </a>
                  </>
                )}
                .
              </>
            }
          />
        )}

        <Button type="submit" size="lg" className="w-full" loading={busy} disabled={!canSubmit} icon={<UserPlus className="size-4" />}>
          Criar conta
        </Button>
        {config?.require_email_verification && (
          <p className="text-center text-xs text-muted">Vais receber um email para confirmar o teu endereço.</p>
        )}
      </form>
      <p className="mt-6 border-t border-border pt-5 text-center text-sm text-muted">
        Já tens conta?{' '}
        <Link to={next ? `/login?next=${encodeURIComponent(next)}` : '/login'} className="link">
          Entrar
        </Link>
      </p>
    </AuthCard>
  )
}
