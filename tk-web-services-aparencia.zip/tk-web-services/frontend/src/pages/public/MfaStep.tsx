import { useState, type FormEvent } from 'react'
import { ShieldCheck } from 'lucide-react'
import { api, errorMessage } from '../../api/client'
import type { LoginOut } from '../../api/types'
import { Alert, Button, Field, Input } from '../../components/ui'

/** Segundo passo do login: código TOTP ou código de recuperação. */
export function MfaStep({ next, onSuccess, onCancel }: { next?: string | null; onSuccess: (res: LoginOut) => void; onCancel?: () => void }) {
  const [code, setCode] = useState('')
  const [recovery, setRecovery] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  const submit = async (e: FormEvent) => {
    e.preventDefault()
    setError(null)
    setBusy(true)
    try {
      const res = await api.post<LoginOut>('/api/auth/2fa', { code: code.trim(), next: next || undefined })
      onSuccess(res)
    } catch (err) {
      setError(errorMessage(err))
      setBusy(false)
    }
  }

  return (
    <form onSubmit={submit} className="space-y-5" noValidate>
      <div className="flex items-start gap-3 rounded-xl border border-border bg-elevated p-4 text-sm">
        <ShieldCheck className="mt-0.5 size-5 shrink-0 text-brand-text" aria-hidden />
        <p className="text-muted">
          {recovery
            ? 'Introduz um dos códigos de recuperação que guardaste quando ativaste a 2FA (ex.: abcde-12345). Cada código só funciona uma vez.'
            : 'Abre a tua app de autenticação (Google Authenticator, Authy, 1Password…) e introduz o código de 6 dígitos.'}
        </p>
      </div>
      {error && <Alert tone="danger">{error}</Alert>}
      <Field label={recovery ? 'Código de recuperação' : 'Código de verificação'}>
        <Input
          value={code}
          onChange={(e) => setCode(recovery ? e.target.value : e.target.value.replace(/[^\d]/g, '').slice(0, 8))}
          inputMode={recovery ? 'text' : 'numeric'}
          autoComplete="one-time-code"
          autoFocus
          placeholder={recovery ? 'abcde-12345' : '123456'}
          className="text-center font-mono text-lg tracking-[0.3em]"
          maxLength={recovery ? 16 : 8}
          required
        />
      </Field>
      <Button type="submit" size="lg" className="w-full" loading={busy} disabled={code.trim().length < 6}>
        Verificar
      </Button>
      <div className="flex flex-wrap items-center justify-between gap-2 text-sm">
        <button
          type="button"
          className="link"
          onClick={() => {
            setRecovery((r) => !r)
            setCode('')
            setError(null)
          }}
        >
          {recovery ? 'Usar código da app' : 'Usar código de recuperação'}
        </button>
        {onCancel && (
          <button type="button" className="text-muted hover:text-fg" onClick={onCancel}>
            Voltar
          </button>
        )}
      </div>
    </form>
  )
}
