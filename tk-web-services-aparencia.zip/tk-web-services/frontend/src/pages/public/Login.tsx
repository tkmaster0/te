import { useEffect, useState, type FormEvent } from 'react'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import { LogIn } from 'lucide-react'
import { api, errorMessage } from '../../api/client'
import type { LoginOut } from '../../api/types'
import { useAuth } from '../../auth/AuthProvider'
import { useConfig } from '../../api/queries'
import { AuthCard } from '../../layouts/PublicLayout'
import { Alert, Button, Checkbox, Field, FullPageSpinner, Input, PasswordInput } from '../../components/ui'
import { portalName } from '../../lib/brand'
import { followRedirect, isExternalTarget, safeNext } from '../../lib/redirect'
import { MfaStep } from './MfaStep'
import { useText } from '../../lib/texts'

export function LoginPage() {
  const t = useText()
  const [params] = useSearchParams()
  const next = params.get('next')
  const loggedOut = params.get('saiu') === '1'
  const navigate = useNavigate()
  const { me, loading, setMe, refresh } = useAuth()
  const { data: config } = useConfig()

  const [login, setLogin] = useState('')
  const [password, setPassword] = useState('')
  const [remember, setRemember] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const [mfa, setMfa] = useState(false)

  // Uma sessão aberta a partir do Jellyfin é limitada: aqui mostramos o formulário para entrar com password.
  const fullSession = !!me && me.session_scope !== 'streaming'

  // Já tem sessão → segue logo para o destino (só destinos do próprio portal).
  useEffect(() => {
    if (loading || !fullSession || busy || mfa || loggedOut) return
    const dest = safeNext(next)
    if (isExternalTarget(dest)) window.location.href = dest
    else navigate(dest, { replace: true })
  }, [loading, fullSession, next, navigate, busy, mfa, loggedOut])

  const done = (res: LoginOut) => {
    if (res.user) setMe(res.user)
    else void refresh()
    followRedirect(res.redirect, navigate)
  }

  const submit = async (e: FormEvent) => {
    e.preventDefault()
    setError(null)
    setBusy(true)
    try {
      const res = await api.post<LoginOut>('/api/auth/login', { login: login.trim(), password, remember, next: next || undefined })
      if (res.status === 'mfa_required') {
        setMfa(true)
        setBusy(false)
        return
      }
      done(res)
    } catch (err) {
      setError(errorMessage(err))
      setBusy(false)
    }
  }

  if (loading || (fullSession && !busy && !mfa && !loggedOut)) return <FullPageSpinner label="A entrar…" />

  if (mfa)
    return (
      <AuthCard title="Verificação em dois passos" description="Falta só mais um passo para entrar.">
        <MfaStep
          next={next}
          onSuccess={done}
          onCancel={() => {
            setMfa(false)
            setPassword('')
          }}
        />
      </AuthCard>
    )

  return (
    <AuthCard title={t('auth.login.title')} description={t('auth.login.description', { app: portalName(config?.app_name) })}>
      <form onSubmit={submit} className="space-y-4" noValidate>
        {loggedOut && !error && <Alert tone="success">Terminaste a sessão. Até breve!</Alert>}
        {next && !loggedOut && !error && <Alert tone="info">Entra para continuar.</Alert>}
        {error && <Alert tone="danger">{error}</Alert>}
        <Field label="Email ou username">
          <Input
            value={login}
            onChange={(e) => setLogin(e.target.value)}
            autoComplete="username"
            autoCapitalize="none"
            autoCorrect="off"
            spellCheck={false}
            autoFocus
            required
          />
        </Field>
        <Field
          label="Password"
          labelAction={
            <Link to="/recuperar-password" className="link text-xs">
              Esqueceste-te?
            </Link>
          }
        >
          <PasswordInput value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" required />
        </Field>
        <Checkbox label="Manter sessão iniciada" checked={remember} onChange={(e) => setRemember(e.target.checked)} />
        <Button type="submit" size="lg" className="w-full" loading={busy} disabled={!login.trim() || !password} icon={<LogIn className="size-4" />}>
          Entrar
        </Button>
      </form>
      <p className="mt-6 border-t border-border pt-5 text-center text-sm text-muted">
        Ainda não tens conta?{' '}
        <Link to={next ? `/registar?next=${encodeURIComponent(next)}` : '/registar'} className="link">
          {config?.registration_mode === 'open' ? 'Regista-te' : 'Tenho um convite'}
        </Link>
      </p>
    </AuthCard>
  )
}
