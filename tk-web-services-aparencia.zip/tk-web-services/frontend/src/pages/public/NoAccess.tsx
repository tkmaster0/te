import { useSearchParams } from 'react-router-dom'
import { Lock, MailWarning } from 'lucide-react'
import { useAuth } from '../../auth/AuthProvider'
import { AuthCard } from '../../layouts/PublicLayout'
import { ButtonLink } from '../../components/ui'

export function NoAccessPage() {
  const [params] = useSearchParams()
  const app = params.get('app')?.slice(0, 80) || 'esta aplicação'
  const { me } = useAuth()
  if (params.get('motivo') === 'email')
    return (
      <AuthCard title="Confirma o teu email" icon={<MailWarning className="size-6" />}>
        <p className="text-sm text-muted">
          Para entrares em <strong className="text-fg">{app}</strong> com a tua conta TK, confirma primeiro o email — é por ele que a app te reconhece.
        </p>
        <div className="mt-6 flex flex-col gap-2">
          <ButtonLink to="/app/conta">Reenviar o email de confirmação</ButtonLink>
          <ButtonLink to="/app" variant="secondary">
            Ir para o portal
          </ButtonLink>
        </div>
      </AuthCard>
    )
  return (
    <AuthCard title="Sem acesso" icon={<Lock className="size-6" />}>
      <p className="text-sm text-muted">
        Precisas de uma subscrição ativa para usar <strong className="text-fg">{app}</strong>.
      </p>
      {me && (
        <p className="mt-2 text-sm text-muted">
          Tens sessão iniciada como <strong className="text-fg">{me.username}</strong>.
        </p>
      )}
      <div className="mt-6 flex flex-col gap-2">
        <ButtonLink to="/app/planos">Ver planos</ButtonLink>
        <ButtonLink to="/app" variant="secondary">
          Ir para o portal
        </ButtonLink>
      </div>
    </AuthCard>
  )
}
