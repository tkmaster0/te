import { useEffect, useRef, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { useQueryClient } from '@tanstack/react-query'
import { MailCheck, MailX } from 'lucide-react'
import { api, errorMessage } from '../../api/client'
import { keys } from '../../api/keys'
import type { Ok } from '../../api/types'
import { useAuth } from '../../auth/AuthProvider'
import { AuthCard } from '../../layouts/PublicLayout'
import { Alert, ButtonLink, Spinner } from '../../components/ui'

type State = { status: 'loading' } | { status: 'ok'; message: string } | { status: 'error'; message: string }

/** Consome um token de email uma única vez (a guarda por ref evita o duplo efeito do StrictMode). */
function useConsumeToken(path: string) {
  const [params] = useSearchParams()
  const token = params.get('token') ?? ''
  const [state, setState] = useState<State>(token ? { status: 'loading' } : { status: 'error', message: 'Link incompleto: falta o código.' })
  const started = useRef(false)
  const qc = useQueryClient()
  useEffect(() => {
    if (!token || started.current) return
    started.current = true
    api
      .post<Ok>(path, { token })
      .then((res) => {
        setState({ status: 'ok', message: res.message ?? 'Feito.' })
        void qc.invalidateQueries({ queryKey: keys.me })
      })
      .catch((err) => setState({ status: 'error', message: errorMessage(err) }))
  }, [token, path, qc])
  return state
}

function TokenResult({ state, okTitle, errTitle, loadingText }: { state: State; okTitle: string; errTitle: string; loadingText: string }) {
  const { me } = useAuth()
  if (state.status === 'loading')
    return (
      <AuthCard title={loadingText}>
        <div className="flex justify-center py-6">
          <Spinner className="size-8 text-brand" label={loadingText} />
        </div>
      </AuthCard>
    )
  if (state.status === 'error')
    return (
      <AuthCard title={errTitle} icon={<MailX className="size-6" />}>
        <Alert tone="danger">{state.message}</Alert>
        <p className="mt-3 text-sm text-muted">Os links de email expiram passado algum tempo e só podem ser usados uma vez.</p>
        <ButtonLink to={me ? '/app' : '/login'} className="mt-6 w-full" variant="secondary">
          {me ? 'Ir para o portal' : 'Ir para o login'}
        </ButtonLink>
      </AuthCard>
    )
  return (
    <AuthCard title={okTitle} icon={<MailCheck className="size-6" />}>
      <Alert tone="success">{state.message}</Alert>
      <ButtonLink to={me ? '/app' : '/login'} className="mt-6 w-full">
        {me ? 'Continuar para o portal' : 'Entrar'}
      </ButtonLink>
    </AuthCard>
  )
}

export function VerifyEmailPage() {
  const state = useConsumeToken('/api/auth/verify-email')
  return <TokenResult state={state} loadingText="A confirmar o teu email…" okTitle="Email confirmado" errTitle="Não foi possível confirmar" />
}

export function ConfirmEmailPage() {
  const state = useConsumeToken('/api/account/email/confirm')
  return <TokenResult state={state} loadingText="A confirmar o novo email…" okTitle="Email alterado" errTitle="Não foi possível alterar o email" />
}
