import { useEffect, useRef, useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { Clapperboard, TriangleAlert } from 'lucide-react'
import { api, errorMessage } from '../../api/client'
import type { LoginOut } from '../../api/types'
import { useAuth } from '../../auth/AuthProvider'
import { AuthCard } from '../../layouts/PublicLayout'
import { Alert, ButtonLink, Spinner } from '../../components/ui'
import { followRedirect } from '../../lib/redirect'
import { MfaStep } from './MfaStep'

/** Entrada a partir do Jellyfin (página Custom Pages) com token de uso único. */
export function MagicLoginPage() {
  const [params] = useSearchParams()
  const token = params.get('token') ?? ''
  const navigate = useNavigate()
  const { setMe, refresh } = useAuth()
  const [state, setState] = useState<'loading' | 'mfa' | 'error'>(token ? 'loading' : 'error')
  const [error, setError] = useState<string | null>(token ? null : 'Link incompleto.')
  const started = useRef(false)

  const done = (res: LoginOut) => {
    if (res.user) setMe(res.user)
    else void refresh()
    followRedirect(res.redirect, navigate)
  }

  useEffect(() => {
    if (!token || started.current) return
    started.current = true
    api
      .post<LoginOut>('/api/auth/magic', { token })
      .then((res) => {
        if (res.status === 'mfa_required') setState('mfa')
        else done(res)
      })
      .catch((err) => {
        setError(errorMessage(err))
        setState('error')
      })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token])

  if (state === 'loading')
    return (
      <AuthCard title="A entrar a partir do Jellyfin…" icon={<Clapperboard className="size-6" />}>
        <div className="flex justify-center py-6">
          <Spinner className="size-8 text-brand" label="A entrar" />
        </div>
      </AuthCard>
    )
  if (state === 'mfa')
    return (
      <AuthCard title="Verificação em dois passos" description="A tua conta tem 2FA ativa.">
        <MfaStep onSuccess={done} />
      </AuthCard>
    )
  return (
    <AuthCard title="Não foi possível entrar" icon={<TriangleAlert className="size-6" />}>
      <Alert tone="danger">{error}</Alert>
      <p className="mt-3 text-sm text-muted">Volta a abrir o portal a partir do Jellyfin ou entra com o teu username e password.</p>
      <ButtonLink to="/login" className="mt-6 w-full">
        Entrar com password
      </ButtonLink>
    </AuthCard>
  )
}
