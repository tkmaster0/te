import { useQuery } from '@tanstack/react-query'
import { api } from './client'
import type { AdminProduct } from './types'

export function useAdminProducts() {
  return useQuery({ queryKey: ['admin', 'products'], queryFn: () => api.get<AdminProduct[]>('/api/admin/products') })
}
