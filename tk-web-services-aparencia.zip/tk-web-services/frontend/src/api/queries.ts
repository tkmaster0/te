import { keepPreviousData, useQuery } from '@tanstack/react-query'
import { api, ApiError, qs } from './client'
import { keys } from './keys'
import type {
  Activity,
  BillingSummary,
  GamesOverview,
  Device,
  InvitesOut,
  Invoice,
  Me,
  NowPlaying,
  Product,
  PublicConfig,
  Quote,
  ServicesOut,
  SessionInfo,
  Subscription,
  WalletOut,
} from './types'

export async function fetchMe(): Promise<Me | null> {
  try {
    return await api.get<Me>('/api/auth/me')
  } catch (err) {
    if (err instanceof ApiError && err.status === 401) return null
    throw err
  }
}

export function useMeQuery() {
  return useQuery({ queryKey: keys.me, queryFn: fetchMe, staleTime: 60_000 })
}

export function useConfig() {
  return useQuery({
    queryKey: keys.config,
    queryFn: () => api.get<PublicConfig>('/api/auth/config'),
    staleTime: 5 * 60_000,
  })
}

/** Catálogo público (página inicial, sem sessão). */
export function useCatalog(convite?: string | null) {
  return useQuery({
    queryKey: [...keys.catalog, convite ?? null],
    queryFn: () => api.get<Product[]>(`/api/catalog${qs({ convite })}`),
    staleTime: 5 * 60_000,
  })
}

/** Produtos que este cliente pode subscrever (numa sessão do Jellyfin: só o streaming). */
export function useProducts() {
  return useQuery({ queryKey: keys.products, queryFn: () => api.get<Product[]>('/api/billing/products'), staleTime: 60_000 })
}

export function useBillingSummary() {
  return useQuery({ queryKey: keys.summary, queryFn: () => api.get<BillingSummary>('/api/billing/summary') })
}

export function useSubscriptions(enabled = true) {
  return useQuery({
    queryKey: keys.subscriptions,
    queryFn: () => api.get<Subscription[]>('/api/billing/subscriptions'),
    enabled,
  })
}

export function useInvoices(enabled = true) {
  return useQuery({ queryKey: keys.invoices, queryFn: () => api.get<Invoice[]>('/api/billing/invoices'), enabled })
}

/** Pré-visualização (sem gravar nada) do que se paga ao subscrever ou mudar de plano. */
export function useQuote(planId: number | null, subscriptionId?: string | null) {
  return useQuery({
    queryKey: keys.quote(planId ?? 0, subscriptionId),
    queryFn: () => api.get<Quote>(`/api/billing/quote${qs({ plan_id: planId, subscription_id: subscriptionId })}`),
    enabled: planId !== null,
    staleTime: 20_000,
    placeholderData: keepPreviousData,
  })
}

export function useServices(enabled = true) {
  return useQuery({ queryKey: keys.services, queryFn: () => api.get<ServicesOut>('/api/services'), enabled })
}

export function useDevices(enabled: boolean) {
  return useQuery({
    queryKey: keys.devices,
    queryFn: () => api.get<Device[]>('/api/services/jellyfin/devices'),
    enabled,
    retry: false,
  })
}

export function useNowPlaying(enabled: boolean) {
  return useQuery({
    queryKey: keys.nowPlaying,
    queryFn: () => api.get<NowPlaying[]>('/api/services/jellyfin/now-playing'),
    enabled,
    retry: false,
    refetchInterval: (q) => (q.state.status === 'error' ? false : 30_000),
  })
}

export function useInvites(enabled = true) {
  return useQuery({ queryKey: keys.invites, queryFn: () => api.get<InvitesOut>('/api/invites'), enabled })
}

export function useSessions() {
  return useQuery({ queryKey: keys.sessions, queryFn: () => api.get<SessionInfo[]>('/api/account/sessions') })
}

export function useActivity() {
  return useQuery({ queryKey: keys.activity, queryFn: () => api.get<Activity[]>('/api/account/activity') })
}

export function useWallet(enabled = true) {
  return useQuery({ queryKey: keys.wallet, queryFn: () => api.get<WalletOut>('/api/wallet'), enabled })
}

export function useGames(enabled = true) {
  return useQuery({ queryKey: keys.games, queryFn: () => api.get<GamesOverview>('/api/games'), enabled })
}
