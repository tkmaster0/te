export const keys = {
  me: ['me'] as const,
  config: ['config'] as const,
  catalog: ['catalog'] as const,
  billing: ['billing'] as const,
  summary: ['billing', 'summary'] as const,
  products: ['billing', 'products'] as const,
  subscriptions: ['billing', 'subscriptions'] as const,
  invoices: ['billing', 'invoices'] as const,
  quote: (planId: number, subId?: string | null) => ['billing', 'quote', planId, subId ?? null] as const,
  payments: ['payments'] as const,
  services: ['services'] as const,
  devices: ['services', 'devices'] as const,
  nowPlaying: ['services', 'now-playing'] as const,
  invites: ['invites'] as const,
  sessions: ['account', 'sessions'] as const,
  activity: ['account', 'activity'] as const,
  admin: ['admin'] as const,
  wallet: ['wallet'] as const,
  games: ['games'] as const,
}

/** Tudo o que muda depois de uma operação de faturação (subscrever, mudar plano, pagar…). */
export const BILLING_INVALIDATE = [keys.billing, keys.me, keys.services, keys.invites, keys.wallet]
