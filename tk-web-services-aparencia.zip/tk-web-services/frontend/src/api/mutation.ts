import { useMutation, useQueryClient, type QueryKey } from '@tanstack/react-query'
import { errorMessage } from './client'
import { useToast } from '../components/ui/Toast'

interface ActionOptions<TVars, TRes> {
  /** Mensagem de sucesso (se a resposta trouxer `message`, essa tem prioridade). `false` = sem toast. */
  success?: string | false | ((res: TRes, vars: TVars) => string | undefined)
  /** Título do toast de erro. `false` = não mostrar toast (a página trata o erro). */
  errorTitle?: string | false
  invalidate?: QueryKey[]
  onSuccess?: (res: TRes, vars: TVars) => void
  onError?: (err: unknown, vars: TVars) => void
}

/** useMutation + toasts + invalidação de queries — padrão de todas as ações da UI. */
export function useAction<TVars = void, TRes = unknown>(fn: (vars: TVars) => Promise<TRes>, opts: ActionOptions<TVars, TRes> = {}) {
  const qc = useQueryClient()
  const toast = useToast()
  return useMutation<TRes, unknown, TVars>({
    mutationFn: fn,
    onSuccess: async (res, vars) => {
      if (opts.invalidate) await Promise.all(opts.invalidate.map((k) => qc.invalidateQueries({ queryKey: k })))
      if (opts.success !== false) {
        const fromRes =
          res && typeof res === 'object' && 'message' in res && typeof (res as { message?: unknown }).message === 'string'
            ? ((res as { message: string }).message as string)
            : undefined
        const custom = typeof opts.success === 'function' ? opts.success(res, vars) : opts.success
        const msg = fromRes || custom
        if (msg) toast.success(msg)
      }
      opts.onSuccess?.(res, vars)
    },
    onError: (err, vars) => {
      if (opts.errorTitle !== false) {
        const detail = errorMessage(err)
        if (opts.errorTitle) toast.error(opts.errorTitle, detail)
        else toast.error(detail)
      }
      opts.onError?.(err, vars)
    },
  })
}
