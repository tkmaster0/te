import { Link, Outlet } from 'react-router-dom'
import type { ReactNode } from 'react'
import { useConfig } from '../api/queries'
import { Logo } from '../components/Logo'
import { ThemeToggleButton } from '../components/ThemeToggle'
import { AnnouncementBanner } from '../components/Banners'
import { useSiteImages, useText } from '../lib/texts'

export function SiteFooter() {
  const { data } = useConfig()
  const t = useText()
  const site = data?.site
  const links: { href: string; label: string }[] = []
  if (site?.terms_url) links.push({ href: site.terms_url, label: 'Termos' })
  if (site?.privacy_url) links.push({ href: site.privacy_url, label: 'Privacidade' })
  if (site?.support_url) links.push({ href: site.support_url, label: 'Suporte' })
  if (site?.support_email) links.push({ href: `mailto:${site.support_email}`, label: site.support_email })
  return (
    <footer className="border-t border-border">
      <div className="mx-auto flex max-w-6xl flex-col gap-4 px-4 py-8 text-sm text-muted sm:flex-row sm:items-center sm:justify-between sm:px-6">
        <div className="flex items-center gap-3">
          <Logo size="sm" />
          <span>
            © {new Date().getFullYear()} {t('brand.company')}
          </span>
        </div>
        {links.length > 0 && (
          <ul className="flex flex-wrap gap-x-5 gap-y-2">
            {links.map((l) => (
              <li key={l.href}>
                <a href={l.href} className="break-all hover:text-fg" target={l.href.startsWith('mailto:') ? undefined : '_blank'} rel="noopener noreferrer">
                  {l.label}
                </a>
              </li>
            ))}
          </ul>
        )}
      </div>
    </footer>
  )
}

/** Layout das páginas de autenticação: cartão centrado. */
export function AuthLayout({ children }: { children?: ReactNode }) {
  const images = useSiteImages()
  return (
    <div className="flex min-h-dvh flex-col">
      <AnnouncementBanner />
      {images.auth ? (
        // Fundo carregado em Admin → Aparência → Imagens, escurecido para o cartão continuar legível.
        <div className="pointer-events-none fixed inset-0 -z-10" aria-hidden>
          <img src={images.auth} alt="" className="size-full object-cover" />
          <div className="absolute inset-0 bg-bg/80 backdrop-blur-[2px]" />
        </div>
      ) : (
        <div className="hero-glow pointer-events-none fixed inset-0 -z-10" aria-hidden />
      )}
      <header className="mx-auto flex w-full max-w-6xl items-center justify-between px-4 py-4 sm:px-6">
        <Link to="/" aria-label="Página inicial">
          <Logo />
        </Link>
        <ThemeToggleButton />
      </header>
      <main id="conteudo" className="flex flex-1 items-start justify-center px-4 pb-16 pt-6 sm:items-center sm:pt-0">
        <div className="w-full max-w-md">{children ?? <Outlet />}</div>
      </main>
      <SiteFooter />
    </div>
  )
}

export function AuthCard({ title, description, children, icon }: { title: ReactNode; description?: ReactNode; children: ReactNode; icon?: ReactNode }) {
  return (
    <div className="card p-6 shadow-[var(--shadow-pop)] sm:p-8">
      {icon && <div className="mb-5 grid size-12 place-items-center rounded-2xl bg-brand-soft text-brand-text">{icon}</div>}
      <h1 className="text-2xl font-bold tracking-tight">{title}</h1>
      {description && <p className="mt-1.5 text-sm text-muted">{description}</p>}
      <div className="mt-6">{children}</div>
    </div>
  )
}
