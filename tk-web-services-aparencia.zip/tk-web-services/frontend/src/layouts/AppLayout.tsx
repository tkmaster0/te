import { useEffect, useRef, useState } from 'react'
import { Link, Navigate, NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom'
import { useQueryClient } from '@tanstack/react-query'
import clsx from 'clsx'
import { ChevronsUpDown, LifeBuoy, LogOut, Menu, Shield, UserCog, X } from 'lucide-react'
import { useMe } from '../auth/AuthProvider'
import { api, SCOPED_EVENT } from '../api/client'
import { keys } from '../api/keys'
import { useConfig } from '../api/queries'
import { Logo } from '../components/Logo'
import { ThemeSegmented, ThemeToggleButton } from '../components/ThemeToggle'
import { AnnouncementBanner, EmailVerifyBanner, SetupBanner } from '../components/Banners'
import { initials } from '../lib/format'
import { ADMIN_NAV, MOBILE_TABS, USER_NAV, type NavItem } from './nav'
import { ScopedLayout } from './ScopedLayout'
import { useText } from '../lib/texts'
import { useAssistantStatus } from '../api/assistant'
import { AssistantLauncher } from '../components/assistant/AssistantLauncher'

function NavList({ items, onNavigate }: { items: NavItem[]; onNavigate?: () => void }) {
  const t = useText()
  return (
    <ul className="space-y-0.5">
      {items.map((it) => {
        const Icon = it.icon
        return (
          <li key={it.to}>
            <NavLink
              to={it.to}
              end={it.end}
              onClick={onNavigate}
              className={({ isActive }) =>
                clsx(
                  'group flex items-center gap-3 rounded-xl px-3 py-2 text-sm font-medium transition-colors',
                  isActive ? 'bg-elevated text-fg' : 'text-muted hover:bg-elevated/60 hover:text-fg',
                )
              }
            >
              {({ isActive }) => (
                <>
                  <Icon className={clsx('size-[18px] shrink-0', isActive ? 'text-brand-text' : 'text-subtle group-hover:text-muted')} aria-hidden />
                  <span className="truncate">{it.textKey ? t(it.textKey) : it.label}</span>
                  {isActive && <span className="ml-auto h-4 w-1 rounded-full bg-brand" aria-hidden />}
                </>
              )}
            </NavLink>
          </li>
        )
      })}
    </ul>
  )
}

function SidebarContent({ onNavigate }: { onNavigate?: () => void }) {
  const me = useMe()
  const assistant = useAssistantStatus()
  const { data: config } = useConfig()
  const items = USER_NAV.filter(
    (it) =>
      (it.to !== '/app/ajuda' || assistant.data?.enabled) &&
      (it.to !== '/app/jogos' || !!me.games_available) &&
      (it.to !== '/app/carteira' || config?.wallet?.enabled !== false),
  )
  return (
    <nav aria-label="Navegação principal" className="space-y-6">
      <div>
        <NavList items={items} onNavigate={onNavigate} />
      </div>
      {me.is_admin && (
        <div>
          <p className="mb-2 flex items-center gap-2 px-3 text-[11px] font-semibold uppercase tracking-wider text-subtle">
            <Shield className="size-3.5" aria-hidden /> Administração
          </p>
          <NavList items={ADMIN_NAV} onNavigate={onNavigate} />
        </div>
      )}
    </nav>
  )
}

function useLogout() {
  return async () => {
    try {
      await api.post('/api/auth/logout')
    } catch {
      /* a sessão pode já ter expirado */
    }
    // Navegação completa: descarta todo o estado em memória da sessão anterior.
    window.location.replace('/login?saiu=1')
  }
}

function UserMenu() {
  const me = useMe()
  const { data: config } = useConfig()
  const [open, setOpen] = useState(false)
  const ref = useRef<HTMLDivElement>(null)
  const doLogout = useLogout()
  const name = me.display_name || me.username

  useEffect(() => {
    if (!open) return
    const onDoc = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false)
    }
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false)
    document.addEventListener('mousedown', onDoc)
    document.addEventListener('keydown', onKey)
    return () => {
      document.removeEventListener('mousedown', onDoc)
      document.removeEventListener('keydown', onKey)
    }
  }, [open])

  const support = config?.site.support_url || (config?.site.support_email ? `mailto:${config.site.support_email}` : null)

  return (
    <div ref={ref} className="relative">
      {open && (
        <div
          role="menu"
          className="animate-dialog-in absolute bottom-full left-0 right-0 mb-2 rounded-2xl border border-border bg-elevated p-2 shadow-[var(--shadow-pop)]"
        >
          <div className="px-2 pb-2 pt-1">
            <p className="mb-2 text-xs font-medium text-subtle">Tema</p>
            <ThemeSegmented className="w-full [&>button]:flex-1 [&>button]:justify-center" />
          </div>
          <div className="my-1 h-px bg-border" />
          <Link role="menuitem" to="/app/conta" onClick={() => setOpen(false)} className="flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm hover:bg-hover">
            <UserCog className="size-4 text-muted" /> Definições da conta
          </Link>
          {support && (
            <a role="menuitem" href={support} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm hover:bg-hover">
              <LifeBuoy className="size-4 text-muted" /> Suporte
            </a>
          )}
          <button role="menuitem" type="button" onClick={doLogout} className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm text-danger hover:bg-danger-soft">
            <LogOut className="size-4" /> Terminar sessão
          </button>
        </div>
      )}
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-haspopup="menu"
        aria-expanded={open}
        className="flex w-full items-center gap-3 rounded-xl p-2 text-left hover:bg-elevated"
      >
        <span className="grid size-9 shrink-0 place-items-center rounded-full bg-brand text-sm font-bold text-brand-fg">{initials(name)}</span>
        <span className="min-w-0 flex-1">
          <span className="block truncate text-sm font-semibold">{name}</span>
          <span className="block truncate text-xs text-muted">{me.email}</span>
        </span>
        <ChevronsUpDown className="size-4 shrink-0 text-subtle" aria-hidden />
      </button>
    </div>
  )
}

/** Páginas permitidas numa sessão aberta a partir do Jellyfin (âmbito "streaming"). */
const SCOPED_PATHS = ['/app/streaming', '/app/pagamento/retorno', '/app/ajuda']

/**
 * Se a API recusar um pedido por a sessão ser limitada (403 + X-TK-Session-Scope),
 * atualiza o utilizador e leva-o para a única página que pode usar.
 */
function useScopedRedirect() {
  const navigate = useNavigate()
  const qc = useQueryClient()
  useEffect(() => {
    const on = () => {
      void qc.invalidateQueries({ queryKey: keys.me })
      if (!window.location.pathname.startsWith('/app/streaming')) navigate('/app/streaming', { replace: true })
    }
    window.addEventListener(SCOPED_EVENT, on)
    return () => window.removeEventListener(SCOPED_EVENT, on)
  }, [navigate, qc])
}

export function AppLayout() {
  const me = useMe()
  const loc = useLocation()
  useScopedRedirect()
  if (me.session_scope === 'streaming') {
    if (!SCOPED_PATHS.some((p) => loc.pathname.startsWith(p))) return <Navigate to="/app/streaming" replace />
    return <ScopedLayout />
  }
  return <FullLayout />
}

function FullLayout() {
  const t = useText()
  const me = useMe()
  const loc = useLocation()
  const [drawer, setDrawer] = useState(false)
  const doLogout = useLogout()
  const mainRef = useRef<HTMLElement>(null)

  useEffect(() => {
    setDrawer(false)
    window.scrollTo({ top: 0 })
  }, [loc.pathname])

  useEffect(() => {
    document.body.style.overflow = drawer ? 'hidden' : ''
    if (!drawer) return
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setDrawer(false)
    document.addEventListener('keydown', onKey)
    return () => {
      document.removeEventListener('keydown', onKey)
      document.body.style.overflow = ''
    }
  }, [drawer])

  const name = me.display_name || me.username

  return (
    <div className="min-h-dvh">
      <a href="#conteudo" className="sr-only z-50 rounded-lg bg-brand px-3 py-2 font-semibold text-brand-fg focus:not-sr-only focus:fixed focus:left-3 focus:top-3">
        Saltar para o conteúdo
      </a>

      {/* Barra lateral (desktop) */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 flex-col border-r border-border bg-surface lg:flex">
        <div className="flex h-16 items-center px-5">
          <Link to="/app" aria-label="Início">
            <Logo />
          </Link>
        </div>
        <div className="scrollbar-thin flex-1 overflow-y-auto px-3 py-3">
          <SidebarContent />
        </div>
        <div className="border-t border-border p-3">
          <UserMenu />
        </div>
      </aside>

      {/* Barra superior (mobile) */}
      <header className="sticky top-0 z-30 flex h-14 items-center gap-2 border-b border-border bg-surface/90 px-3 backdrop-blur lg:hidden">
        <button
          type="button"
          onClick={() => setDrawer(true)}
          className="grid size-10 place-items-center rounded-xl text-muted hover:bg-elevated hover:text-fg"
          aria-label="Abrir menu"
          aria-expanded={drawer}
          aria-controls="menu-mobile"
        >
          <Menu className="size-5" />
        </button>
        <Link to="/app" className="mr-auto" aria-label="Início">
          <Logo size="sm" />
        </Link>
        <ThemeToggleButton />
        <Link to="/app/conta" aria-label="A minha conta" className="grid size-9 place-items-center rounded-full bg-brand text-xs font-bold text-brand-fg">
          {initials(name)}
        </Link>
      </header>

      {/* Menu lateral (mobile) */}
      {drawer && (
        <div className="fixed inset-0 z-50 lg:hidden" role="dialog" aria-modal="true" aria-label="Menu">
          <div className="animate-fade-in absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setDrawer(false)} />
          <div id="menu-mobile" className="animate-drawer-in absolute inset-y-0 left-0 flex w-[min(20rem,85vw)] flex-col border-r border-border bg-surface">
            <div className="flex h-14 items-center justify-between px-4">
              <Logo size="sm" />
              <button type="button" onClick={() => setDrawer(false)} className="grid size-10 place-items-center rounded-xl text-muted hover:bg-elevated" aria-label="Fechar menu">
                <X className="size-5" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto px-3 py-2">
              <SidebarContent onNavigate={() => setDrawer(false)} />
            </div>
            <div className="space-y-3 border-t border-border p-4">
              <ThemeSegmented className="w-full [&>button]:flex-1 [&>button]:justify-center" />
              <div className="flex items-center gap-3">
                <span className="grid size-9 shrink-0 place-items-center rounded-full bg-brand text-sm font-bold text-brand-fg">{initials(name)}</span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-semibold">{name}</span>
                  <span className="block truncate text-xs text-muted">{me.email}</span>
                </span>
                <button type="button" onClick={doLogout} className="grid size-10 place-items-center rounded-xl text-danger hover:bg-danger-soft" aria-label="Terminar sessão">
                  <LogOut className="size-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="lg:pl-64">
        <AnnouncementBanner />
        <EmailVerifyBanner me={me} />
        <SetupBanner me={me} />
        <main ref={mainRef} id="conteudo" tabIndex={-1} className="mx-auto w-full max-w-6xl px-4 pb-28 pt-6 outline-none sm:px-6 sm:pt-8 lg:px-8 lg:pb-16">
          <Outlet />
        </main>
      </div>

      <AssistantLauncher bottomNav />

      {/* Navegação inferior (mobile) */}
      <nav
        aria-label="Atalhos"
        className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-surface/95 pb-[env(safe-area-inset-bottom)] backdrop-blur lg:hidden"
      >
        <ul className="mx-auto grid max-w-md grid-cols-5">
          {MOBILE_TABS.map((it) => {
            const Icon = it.icon
            return (
              <li key={it.to}>
                <NavLink
                  to={it.to}
                  end={it.end}
                  className={({ isActive }) =>
                    clsx('flex flex-col items-center gap-1 py-2 text-[11px] font-medium', isActive ? 'text-brand-text' : 'text-subtle hover:text-fg')
                  }
                >
                  <Icon className="size-5" aria-hidden />
                  {it.textKey ? t(it.textKey) : it.label}
                </NavLink>
              </li>
            )
          })}
        </ul>
      </nav>
    </div>
  )
}
