import { Link, Outlet } from 'react-router-dom'
import { Clapperboard, LogIn, LogOut } from 'lucide-react'
import { api } from '../api/client'
import { Logo } from '../components/Logo'
import { ThemeToggleButton } from '../components/ThemeToggle'
import { AnnouncementBanner } from '../components/Banners'
import { AssistantLauncher } from '../components/assistant/AssistantLauncher'

/** Layout mínimo para sessões abertas a partir do Jellyfin: só o streaming, sem navegação. */
export function ScopedLayout() {
  const logout = async () => {
    try {
      await api.post('/api/auth/logout')
    } catch {
      /* a sessão pode já ter expirado */
    }
    window.location.replace('/login?saiu=1')
  }
  return (
    <div className="min-h-dvh">
      <a href="#conteudo" className="sr-only z-50 rounded-lg bg-brand px-3 py-2 font-semibold text-brand-fg focus:not-sr-only focus:fixed focus:left-3 focus:top-3">
        Saltar para o conteúdo
      </a>
      <header className="sticky top-0 z-30 border-b border-border bg-surface/90 backdrop-blur">
        <div className="mx-auto flex h-14 max-w-3xl items-center gap-2 px-4">
          <Link to="/app/streaming" className="mr-auto" aria-label="TK Web Services — streaming">
            <Logo size="sm" />
          </Link>
          <ThemeToggleButton />
          <button
            type="button"
            onClick={logout}
            className="grid size-10 place-items-center rounded-xl text-muted hover:bg-elevated hover:text-fg"
            aria-label="Terminar sessão"
            title="Terminar sessão"
          >
            <LogOut className="size-5" />
          </button>
        </div>
      </header>
      <div className="border-b border-info/30 bg-info-soft" role="note">
        <div className="mx-auto flex max-w-3xl flex-wrap items-center gap-x-3 gap-y-2 px-4 py-2.5 text-sm">
          <Clapperboard className="size-4 shrink-0 text-info" aria-hidden />
          <p className="min-w-0 flex-1">Sessão aberta a partir do Jellyfin — aqui só geres o streaming.</p>
          <Link to="/login?next=/app" className="inline-flex w-full items-center gap-1.5 pl-7 font-semibold text-info hover:underline sm:w-auto sm:pl-0">
            <LogIn className="size-4" aria-hidden /> Entrar com password
          </Link>
        </div>
      </div>
      <AnnouncementBanner />
      <main id="conteudo" tabIndex={-1} className="mx-auto w-full max-w-3xl px-4 pb-16 pt-6 outline-none sm:pt-8">
        <Outlet />
      </main>
      <AssistantLauncher />
    </div>
  )
}
