import {
  BarChart3,
  Dices,
  Wallet,
  Gift,
  Home,
  Import,
  MessageCircleQuestion,
  Bot,
  KeyRound,
  Package,
  Palette,
  PlaySquare,
  Rocket,
  Tv,
  PlugZap,
  Receipt,
  ReceiptText,
  ScrollText,
  Settings,
  Store,
  Ticket,
  Truck,
  UserCog,
  Users,
  Wrench,
} from 'lucide-react'
import type { TextKey } from '../content/texts'

export interface NavItem {
  to: string
  label: string
  icon: typeof Home
  end?: boolean
  /** Texto editável em Admin → Aparência → Textos (senão usa `label`). */
  textKey?: TextKey
}

export const USER_NAV: NavItem[] = [
  { to: '/app', label: 'Início', icon: Home, end: true, textKey: 'nav.app.home' },
  { to: '/app/servicos', label: 'Os meus serviços', icon: PlaySquare, textKey: 'nav.app.services' },
  { to: '/app/planos', label: 'Loja', icon: Store, textKey: 'nav.app.store' },
  { to: '/app/carteira', label: 'Carteira', icon: Wallet, textKey: 'nav.app.wallet' },
  { to: '/app/faturacao', label: 'Faturação', icon: Receipt, textKey: 'nav.app.billing' },
  { to: '/app/jogos', label: 'Jogos', icon: Dices, textKey: 'nav.app.games' },
  { to: '/app/convites', label: 'Convites', icon: Gift, textKey: 'nav.app.invites' },
  { to: '/app/conta', label: 'Conta', icon: UserCog, textKey: 'nav.app.account' },
  { to: '/app/ajuda', label: 'Ajuda', icon: MessageCircleQuestion, textKey: 'nav.app.help' },
]

export const MOBILE_TABS: NavItem[] = [
  { to: '/app', label: 'Início', icon: Home, end: true, textKey: 'nav.app.home' },
  { to: '/app/servicos', label: 'Serviços', icon: PlaySquare, textKey: 'nav.app.services_short' },
  { to: '/app/planos', label: 'Loja', icon: Store, textKey: 'nav.app.store' },
  { to: '/app/carteira', label: 'Carteira', icon: Wallet, textKey: 'nav.app.wallet' },
  { to: '/app/conta', label: 'Conta', icon: UserCog, textKey: 'nav.app.account' },
]

export const ADMIN_NAV: NavItem[] = [
  { to: '/admin', label: 'Painel', icon: BarChart3, end: true },
  { to: '/admin/utilizadores', label: 'Utilizadores', icon: Users },
  { to: '/admin/cobrancas', label: 'Cobranças', icon: ReceiptText },
  { to: '/admin/entregas', label: 'Entregas', icon: Truck },
  { to: '/admin/planos', label: 'Produtos & planos', icon: Package },
  { to: '/admin/fornecedores', label: 'Fornecedores', icon: PlugZap },
  { to: '/admin/migracao', label: 'Migração', icon: Import },
  { to: '/admin/convites', label: 'Convites', icon: Ticket },
  { to: '/admin/assistente', label: 'Assistente', icon: Bot },
  { to: '/admin/operacoes', label: 'Operações', icon: Wrench },
  { to: '/admin/sso', label: 'SSO / OIDC', icon: KeyRound },
  { to: '/admin/jellyfin', label: 'Jellyfin', icon: Tv },
  { to: '/admin/aparencia', label: 'Aparência', icon: Palette },
  { to: '/admin/auditoria', label: 'Auditoria', icon: ScrollText },
  { to: '/admin/definicoes', label: 'Definições', icon: Settings },
  { to: '/admin/configurar', label: 'Configuração inicial', icon: Rocket },
]
