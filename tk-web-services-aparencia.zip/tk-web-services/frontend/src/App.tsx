import { lazy, Suspense, useEffect, type ReactNode } from 'react'
import { createBrowserRouter, Navigate, Outlet, RouterProvider, useRouteError, useSearchParams } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { api } from './api/client'
import { AlertOctagon } from 'lucide-react'
import { AuthProvider, useMe } from './auth/AuthProvider'
import { RequireAdmin, RequireAuth } from './auth/guards'
import { ConfirmProvider, ToastProvider, FullPageSpinner, EmptyState, Button, ButtonLink } from './components/ui'
import { AppLayout } from './layouts/AppLayout'
import { useSiteImages, useText } from './lib/texts'
import { AuthLayout } from './layouts/PublicLayout'
import { LandingPage } from './pages/public/Landing'
import { LoginPage } from './pages/public/Login'
import { RegisterPage } from './pages/public/Register'
import { ForgotPasswordPage, ResetPasswordPage } from './pages/public/PasswordReset'
import { ConfirmEmailPage, VerifyEmailPage } from './pages/public/TokenPages'
import { MagicLoginPage } from './pages/public/MagicLogin'
import { NoAccessPage } from './pages/public/NoAccess'
import { NotFoundPage } from './pages/public/NotFound'
import { HomePage } from './pages/app/Home'
import { PlansPage } from './pages/app/Plans'
import { ServicesPage } from './pages/app/Services'
import { BillingPage } from './pages/app/Billing'
import { StreamingPage } from './pages/app/Streaming'
import { InvitesPage } from './pages/app/Invites'
import { AccountPage } from './pages/app/Account'
import { PaymentReturnPage } from './pages/app/PaymentReturn'
import { HelpPage } from './pages/app/Help'
import { WalletPage } from './pages/app/Wallet'

const GamesPage = lazy(() => import('./pages/app/Games').then((m) => ({ default: m.GamesPage })))
const RoulettePage = lazy(() => import('./pages/app/Roulette').then((m) => ({ default: m.RoulettePage })))
const BlackjackPage = lazy(() => import('./pages/app/Blackjack').then((m) => ({ default: m.BlackjackPage })))

const AdminDashboard = lazy(() => import('./pages/admin/Dashboard'))
const AdminUsers = lazy(() => import('./pages/admin/Users'))
const AdminUserDetail = lazy(() => import('./pages/admin/UserDetail'))
const AdminPlans = lazy(() => import('./pages/admin/Plans'))
const AdminInvoices = lazy(() => import('./pages/admin/Invoices'))
const AdminFulfillment = lazy(() => import('./pages/admin/Fulfillment'))
const AdminProviders = lazy(() => import('./pages/admin/Providers'))
const AdminMigration = lazy(() => import('./pages/admin/Migration'))
const AdminInvites = lazy(() => import('./pages/admin/Invites'))
const AdminOperations = lazy(() => import('./pages/admin/Operations'))
const AdminSso = lazy(() => import('./pages/admin/Sso'))
const AdminAudit = lazy(() => import('./pages/admin/Audit'))
const AdminConfig = lazy(() => import('./pages/admin/Config'))
const AdminSetup = lazy(() => import('./pages/admin/Setup'))
const AdminJellyfin = lazy(() => import('./pages/admin/Jellyfin'))
const AdminAppearance = lazy(() => import('./pages/admin/Appearance'))
const AdminAssistantOverview = lazy(() => import('./pages/admin/assistant/Overview'))
const AdminAssistantAgents = lazy(() => import('./pages/admin/assistant/Agents'))
const AdminAssistantKnowledge = lazy(() => import('./pages/admin/assistant/Knowledge'))
const AdminAssistantConversations = lazy(() => import('./pages/admin/assistant/Conversations'))
const AdminAssistantConversation = lazy(() => import('./pages/admin/assistant/ConversationDetail'))

function Lazy({ children }: { children: ReactNode }) {
  return <Suspense fallback={<FullPageSpinner />}>{children}</Suspense>
}

/** Os jogos só existem para quem tem o TKFLIX desbloqueado — para os outros a rota nem aparece. */
function GamesRoute({ children }: { children: ReactNode }) {
  const me = useMe()
  if (!me.games_available) return <NotFoundPage inApp />
  return <Lazy>{children}</Lazy>
}

function RouteError() {
  const err = useRouteError() as Error | undefined
  const chunk = err?.message?.includes('dynamically imported module') || err?.message?.includes('Failed to fetch')
  return (
    <EmptyState
      className="min-h-dvh justify-center"
      icon={<AlertOctagon className="size-6" />}
      title={chunk ? 'Há uma nova versão do portal' : 'Algo correu mal'}
      description={chunk ? 'Recarrega a página para continuar.' : 'Ocorreu um erro inesperado nesta página. Tenta recarregar.'}
      action={
        <>
          <Button onClick={() => window.location.reload()}>Recarregar</Button>
          <ButtonLink to="/app" variant="secondary">
            Ir para o início
          </ButtonLink>
        </>
      }
    />
  )
}

/** Links antigos /app/checkout/retorno?checkout=… passam para a nova página de regresso. */
function LegacyCheckoutReturn() {
  return <Navigate to={`/app/pagamento/retorno${window.location.search}`} replace />
}

/** Título do separador e favicon definidos em Admin → Aparência (o servidor já os põe no HTML; isto aplica as
 * mudanças feitas com a página aberta). */
function SiteHead() {
  const t = useText()
  const images = useSiteImages()
  const title = t('meta.title')
  useEffect(() => {
    document.title = title
  }, [title])
  useEffect(() => {
    if (!images.favicon) return
    let link = document.querySelector<HTMLLinkElement>('link[rel="icon"]')
    if (!link) {
      link = document.createElement('link')
      link.rel = 'icon'
      document.head.appendChild(link)
    }
    link.removeAttribute('type')
    link.href = images.favicon
  }, [images.favicon])
  return null
}

function Providers() {
  return (
    <ToastProvider>
      <ConfirmProvider>
        <AuthProvider>
          <SiteHead />
          <Outlet />
        </AuthProvider>
      </ConfirmProvider>
    </ToastProvider>
  )
}

const router = createBrowserRouter([
  {
    element: <Providers />,
    errorElement: <RouteError />,
    children: [
      { path: '/', element: <LandingPage /> },
      // Link curto do QR da coleção "Ajuda" no Jellyfin (apps de TV) e do widget: vai para o chat (pede login se preciso).
      { path: '/ajuda', element: <Navigate to="/app/ajuda" replace /> },
      {
        element: <AuthLayout />,
        children: [
          { path: '/login', element: <LoginPage /> },
          { path: '/entrar', element: <Navigate to="/login" replace /> },
          { path: '/registar', element: <RegisterPage /> },
          { path: '/recuperar-password', element: <ForgotPasswordPage /> },
          { path: '/redefinir-password', element: <ResetPasswordPage /> },
          { path: '/verificar-email', element: <VerifyEmailPage /> },
          { path: '/confirmar-email', element: <ConfirmEmailPage /> },
          { path: '/entrar-jellyfin', element: <MagicLoginPage /> },
          { path: '/sem-acesso', element: <NoAccessPage /> },
        ],
      },
      {
        element: (
          <RequireAuth>
            <AppLayout />
          </RequireAuth>
        ),
        children: [
          { path: '/app', element: <HomePage /> },
          { path: '/app/servicos', element: <ServicesPage /> },
          { path: '/app/planos', element: <PlansPage /> },
          { path: '/app/loja', element: <Navigate to="/app/planos" replace /> },
          { path: '/app/faturacao', element: <BillingPage /> },
          { path: '/app/carteira', element: <WalletPage /> },
          {
            path: '/app/jogos',
            element: (
              <GamesRoute>
                <GamesPage />
              </GamesRoute>
            ),
          },
          {
            path: '/app/jogos/roleta',
            element: (
              <GamesRoute>
                <RoulettePage />
              </GamesRoute>
            ),
          },
          {
            path: '/app/jogos/blackjack',
            element: (
              <GamesRoute>
                <BlackjackPage />
              </GamesRoute>
            ),
          },
          { path: '/app/streaming', element: <StreamingPage /> },
          { path: '/app/convites', element: <InvitesPage /> },
          { path: '/app/conta', element: <AccountPage /> },
          { path: '/app/ajuda', element: <HelpPage /> },
          { path: '/app/pagamento/retorno', element: <PaymentReturnPage /> },
          // Caminhos antigos
          { path: '/app/subscricoes', element: <Navigate to="/app/servicos" replace /> },
          { path: '/app/pagamentos', element: <Navigate to="/app/faturacao" replace /> },
          { path: '/app/checkout/retorno', element: <LegacyCheckoutReturn /> },
          {
            path: '/admin',
            element: (
              <RequireAdmin>
                <Lazy>
                  <Outlet />
                </Lazy>
              </RequireAdmin>
            ),
            children: [
              { index: true, element: <SetupGate><AdminDashboard /></SetupGate> },
              { path: 'utilizadores', element: <AdminUsers /> },
              { path: 'utilizadores/:id', element: <AdminUserDetail /> },
              { path: 'planos', element: <AdminPlans /> },
              { path: 'cobrancas', element: <AdminInvoices /> },
              { path: 'entregas', element: <AdminFulfillment /> },
              { path: 'fornecedores', element: <AdminProviders /> },
              { path: 'migracao', element: <AdminMigration /> },
              { path: 'convites', element: <AdminInvites /> },
              { path: 'operacoes', element: <AdminOperations /> },
              { path: 'sso', element: <AdminSso /> },
              { path: 'auditoria', element: <AdminAudit /> },
              { path: 'definicoes', element: <AdminConfig /> },
              { path: 'configurar', element: <AdminSetup /> },
              { path: 'jellyfin', element: <AdminJellyfin /> },
              { path: 'aparencia', element: <AdminAppearance /> },
              { path: 'assistente', element: <AdminAssistantOverview /> },
              { path: 'assistente/agentes', element: <AdminAssistantAgents /> },
              { path: 'assistente/conhecimento', element: <AdminAssistantKnowledge /> },
              { path: 'assistente/conversas', element: <AdminAssistantConversations /> },
              { path: 'assistente/conversas/:id', element: <AdminAssistantConversation /> },
            ],
          },
          { path: '/app/*', element: <NotFoundPage inApp /> },
        ],
      },
      { path: '*', element: <NotFoundPage /> },
    ],
  },
])

/** Primeiro acesso do administrador: abre o assistente de configuração em vez do painel (até ser concluído). */
function SetupGate({ children }: { children: ReactNode }) {
  const [params] = useSearchParams()
  const q = useQuery({ queryKey: ['admin', 'setup'], queryFn: () => api.get<{ completed: boolean }>('/api/admin/setup'), staleTime: 60_000 })
  if (q.data && !q.data.completed && params.get('painel') !== '1') return <Navigate to="/admin/configurar" replace />
  return <>{children}</>
}

export function App() {
  return <RouterProvider router={router} />
}
