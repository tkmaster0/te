import { useCallback, useEffect, useState } from 'react'
import { readStorage, writeStorage } from './storage'

export type ThemePref = 'dark' | 'light' | 'system'
const KEY = 'tk-theme'

function systemDark(): boolean {
  return typeof window !== 'undefined' && !!window.matchMedia?.('(prefers-color-scheme: dark)').matches
}

export function resolveTheme(pref: ThemePref): 'dark' | 'light' {
  if (pref === 'system') return systemDark() ? 'dark' : 'light'
  return pref
}

function apply(pref: ThemePref) {
  const t = resolveTheme(pref)
  document.documentElement.setAttribute('data-theme', t)
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', t === 'dark' ? '#0b0b0c' : '#f6f6f7')
}

const listeners = new Set<(p: ThemePref) => void>()

export function useTheme() {
  const [pref, setPrefState] = useState<ThemePref>(() => {
    const v = readStorage(KEY)
    return v === 'light' || v === 'system' || v === 'dark' ? v : 'dark'
  })

  useEffect(() => {
    const l = (p: ThemePref) => setPrefState(p)
    listeners.add(l)
    return () => {
      listeners.delete(l)
    }
  }, [])

  useEffect(() => {
    apply(pref)
    if (pref !== 'system' || !window.matchMedia) return
    const mq = window.matchMedia('(prefers-color-scheme: dark)')
    const onChange = () => apply('system')
    mq.addEventListener?.('change', onChange)
    return () => mq.removeEventListener?.('change', onChange)
  }, [pref])

  const setPref = useCallback((p: ThemePref) => {
    writeStorage(KEY, p)
    listeners.forEach((l) => l(p))
  }, [])

  return { pref, resolved: resolveTheme(pref), setPref }
}
