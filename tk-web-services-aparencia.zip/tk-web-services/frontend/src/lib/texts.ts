import { useCallback } from 'react'
import { useConfig } from '../api/queries'
import { TEXTS, type TextKey } from '../content/texts'

type Vars = Record<string, string | number | null | undefined>

export function fillText(template: string, vars: Vars): string {
  return template.replace(/\{([a-z_]+)\}/gi, (whole, name: string) => (vars[name] != null ? String(vars[name]) : whole))
}

/** `t('chave', {var})` → o texto editado em Admin → Aparência, ou o texto por omissão (content/texts.ts). */
export function useText() {
  const { data } = useConfig()
  const custom = data?.site?.texts
  const app = data?.app_name || 'TK Web Services'
  return useCallback(
    (key: TextKey, vars: Vars = {}) => {
      const company = custom?.['brand.company'] || TEXTS['brand.company'].default
      return fillText(custom?.[key] || TEXTS[key].default, { app, empresa: company, ...vars })
    },
    [custom, app],
  )
}

/** Imagens carregadas em Admin → Aparência (logo, favicon, hero, auth, share). */
export function useSiteImages(): Record<string, string> {
  const { data } = useConfig()
  return data?.site?.images ?? {}
}
