/** Estimativa simples da força da password (só para orientar — as regras reais estão no backend). */
export interface Strength {
  score: 0 | 1 | 2 | 3 | 4
  label: string
  hints: string[]
}

const COMMON = ['password', '12345678', '123456789', 'qwerty', 'tkflix', 'tkweb', 'tkwebservices', 'benfica', 'sporting', 'porto', 'portugal', 'abc123', '11111111']

export function passwordStrength(pw: string, ctx: { username?: string; email?: string } = {}): Strength {
  const hints: string[] = []
  if (!pw) return { score: 0, label: '', hints }
  let points = 0
  if (pw.length >= 8) points++
  if (pw.length >= 12) points++
  if (pw.length >= 16) points++
  const classes = [/[a-z]/, /[A-Z]/, /\d/, /[^A-Za-z0-9]/].filter((r) => r.test(pw)).length
  if (classes >= 2) points++
  if (classes >= 3) points++
  const lower = pw.toLowerCase()
  if (pw.length < 8) hints.push('Usa pelo menos 8 caracteres.')
  if (COMMON.some((c) => lower.includes(c))) {
    points -= 2
    hints.push('Evita palavras e sequências comuns.')
  }
  if (/^(.)\1+$/.test(pw)) points = 0
  if (ctx.username && ctx.username.length >= 3 && lower.includes(ctx.username.toLowerCase())) {
    points = Math.min(points, 1)
    hints.push('A password não pode conter o username.')
  }
  const local = ctx.email?.split('@')[0]
  if (local && local.length >= 4 && lower.includes(local.toLowerCase())) {
    points = Math.min(points, 1)
    hints.push('A password não pode conter o email.')
  }
  if (pw.length >= 8 && pw.length < 12 && classes < 3) hints.push('Uma frase longa é mais segura e fácil de lembrar.')
  const score = Math.max(0, Math.min(4, pw.length < 8 ? Math.min(points, 1) : points - 1)) as Strength['score']
  const labels = ['Muito fraca', 'Fraca', 'Razoável', 'Forte', 'Muito forte']
  return { score, label: labels[score], hints }
}
