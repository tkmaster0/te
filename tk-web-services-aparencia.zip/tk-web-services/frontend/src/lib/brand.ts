/** Marca do portal. O TKFLIX é só um dos produtos (o streaming) vendidos através dele. */
export const PORTAL_BRAND = 'TK Web Services'

/**
 * Nome do portal a mostrar: o `app_name` do backend, exceto se ainda vier o nome antigo ("TKFLIX"),
 * que agora é o nome do produto de streaming e não do portal.
 */
export function portalName(appName: string | null | undefined): string {
  const n = appName?.trim()
  return n && n.toUpperCase() !== 'TKFLIX' ? n : PORTAL_BRAND
}
