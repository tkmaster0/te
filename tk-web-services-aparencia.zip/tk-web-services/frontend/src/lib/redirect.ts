import type { NavigateFunction } from 'react-router-dom'

/** Destinos que têm de ser abertos com navegação completa (backend / OIDC / outros hosts). */
export function isExternalTarget(target: string): boolean {
  return /^(\/api\/|\/oidc\/|\/auth\/|\/\.well-known\/|https?:)/i.test(target)
}

/** Segue o `redirect` devolvido pelo backend (já validado lá). */
export function followRedirect(target: string | null | undefined, navigate: NavigateFunction, fallback = '/app') {
  const dest = target || fallback
  if (isExternalTarget(dest)) {
    window.location.href = dest
  } else {
    navigate(dest, { replace: true })
  }
}

/**
 * Para um utilizador que já tem sessão e chega a /login?next=… — só seguimos destinos do próprio portal:
 * caminhos relativos (não "//"), URLs da mesma origem ou o fluxo OIDC.
 */
export function safeNext(next: string | null | undefined, fallback = '/app'): string {
  if (!next) return fallback
  const n = next.trim()
  if (n.startsWith('/') && !n.startsWith('//') && !n.includes('\\')) return n
  try {
    const u = new URL(n)
    if (u.origin === window.location.origin) return u.pathname + u.search + u.hash
  } catch {
    /* URL inválido */
  }
  return fallback
}
