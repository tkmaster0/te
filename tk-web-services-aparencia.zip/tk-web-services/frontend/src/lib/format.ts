/** Formatação pt-PT: dinheiro, datas e intervalos. */

const moneyFormatters = new Map<string, Intl.NumberFormat>()

export function formatMoney(cents: number | null | undefined, currency = 'EUR'): string {
  if (cents === null || cents === undefined || Number.isNaN(cents)) return '—'
  const cur = (currency || 'EUR').toUpperCase()
  let f = moneyFormatters.get(cur)
  if (!f) {
    try {
      f = new Intl.NumberFormat('pt-PT', { style: 'currency', currency: cur })
    } catch {
      f = new Intl.NumberFormat('pt-PT', { style: 'currency', currency: 'EUR' })
    }
    moneyFormatters.set(cur, f)
  }
  return f.format(cents / 100)
}

export function parseDate(value: string | Date | null | undefined): Date | null {
  if (!value) return null
  if (value instanceof Date) return value
  // O backend envia ISO 8601 (normalmente com "Z"); sem fuso assume-se UTC.
  const v = /[zZ]|[+-]\d\d:?\d\d$/.test(value) || value.length <= 10 ? value : `${value}Z`
  const d = new Date(v)
  return Number.isNaN(d.getTime()) ? null : d
}

const dateFmt = new Intl.DateTimeFormat('pt-PT', { day: '2-digit', month: '2-digit', year: 'numeric' })
const dateTimeFmt = new Intl.DateTimeFormat('pt-PT', {
  day: '2-digit',
  month: '2-digit',
  year: 'numeric',
  hour: '2-digit',
  minute: '2-digit',
})
const monthFmt = new Intl.DateTimeFormat('pt-PT', { month: 'short' })
const monthYearFmt = new Intl.DateTimeFormat('pt-PT', { month: 'long', year: 'numeric' })

const dayMonthFmt = new Intl.DateTimeFormat('pt-PT', { day: '2-digit', month: '2-digit' })
const longDateFmt = new Intl.DateTimeFormat('pt-PT', { day: 'numeric', month: 'long' })
const longDateYearFmt = new Intl.DateTimeFormat('pt-PT', { day: 'numeric', month: 'long', year: 'numeric' })

/** "26/10" */
export function formatDayMonth(value: string | Date | null | undefined, fallback = '—'): string {
  const d = parseDate(value)
  return d ? dayMonthFmt.format(d) : fallback
}

/** "26 de outubro" (com o ano só se não for o ano corrente). */
export function formatLongDate(value: string | Date | null | undefined, fallback = '—'): string {
  const d = parseDate(value)
  if (!d) return fallback
  return d.getFullYear() === new Date().getFullYear() ? longDateFmt.format(d) : longDateYearFmt.format(d)
}

/** "+2,47 €" / "−1,00 €" */
export function formatSignedMoney(cents: number, currency = 'EUR'): string {
  if (cents === 0) return formatMoney(0, currency)
  return `${cents > 0 ? '+' : '−'}${formatMoney(Math.abs(cents), currency)}`
}

export function formatDate(value: string | Date | null | undefined, fallback = '—'): string {
  const d = parseDate(value)
  return d ? dateFmt.format(d) : fallback
}

export function formatDateTime(value: string | Date | null | undefined, fallback = '—'): string {
  const d = parseDate(value)
  return d ? dateTimeFmt.format(d).replace(',', ' às') : fallback
}

export function formatMonthShort(key: string): string {
  // key = "2026-09"
  const [y, m] = key.split('-').map(Number)
  if (!y || !m) return key
  return monthFmt.format(new Date(Date.UTC(y, m - 1, 15))).replace('.', '')
}

export function formatMonthYear(key: string): string {
  const [y, m] = key.split('-').map(Number)
  if (!y || !m) return key
  return monthYearFmt.format(new Date(Date.UTC(y, m - 1, 15)))
}

export function relativeTime(value: string | Date | null | undefined): string {
  const d = parseDate(value)
  if (!d) return '—'
  const diff = (d.getTime() - Date.now()) / 1000
  const rtf = new Intl.RelativeTimeFormat('pt-PT', { numeric: 'auto' })
  const abs = Math.abs(diff)
  if (abs < 60) return rtf.format(Math.round(diff), 'second')
  if (abs < 3600) return rtf.format(Math.round(diff / 60), 'minute')
  if (abs < 86400) return rtf.format(Math.round(diff / 3600), 'hour')
  if (abs < 86400 * 30) return rtf.format(Math.round(diff / 86400), 'day')
  if (abs < 86400 * 365) return rtf.format(Math.round(diff / (86400 * 30)), 'month')
  return rtf.format(Math.round(diff / (86400 * 365)), 'year')
}

export function daysUntil(value: string | Date | null | undefined): number | null {
  const d = parseDate(value)
  if (!d) return null
  return Math.ceil((d.getTime() - Date.now()) / 86400000)
}

export function intervalLabel(unit: string, count = 1): string {
  const one: Record<string, string> = { month: 'mês', year: 'ano', week: 'semana', day: 'dia' }
  const many: Record<string, string> = { month: 'meses', year: 'anos', week: 'semanas', day: 'dias' }
  if (count <= 1) return one[unit] ?? unit
  return `${count} ${many[unit] ?? unit}`
}

/** "/mês", "/ano", "a cada 3 meses" */
export function perInterval(unit: string, count = 1): string {
  if (count <= 1) return `/${intervalLabel(unit)}`
  return ` a cada ${intervalLabel(unit, count)}`
}

export function monthlyEquivalent(cents: number, unit: string, count = 1): number {
  if (unit === 'year') return cents / (12 * count)
  if (unit === 'week') return (cents * 52) / 12 / count
  return cents / count
}

export function pluralize(n: number, one: string, many: string): string {
  return `${n} ${n === 1 ? one : many}`
}

export function initials(name: string): string {
  const parts = name.trim().split(/[\s._-]+/).filter(Boolean)
  if (!parts.length) return '?'
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase()
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase()
}

export function describeUserAgent(ua: string | null | undefined): string {
  if (!ua) return 'Dispositivo desconhecido'
  const browser = /Edg\//.test(ua)
    ? 'Edge'
    : /OPR\//.test(ua)
      ? 'Opera'
      : /Firefox\//.test(ua)
        ? 'Firefox'
        : /Chrome\//.test(ua)
          ? 'Chrome'
          : /Safari\//.test(ua)
            ? 'Safari'
            : /curl|python|httpx/i.test(ua)
              ? 'Cliente de linha de comandos'
              : 'Navegador'
  const os = /Windows/.test(ua)
    ? 'Windows'
    : /iPhone|iPad/.test(ua)
      ? 'iOS'
      : /Android/.test(ua)
        ? 'Android'
        : /Mac OS X|Macintosh/.test(ua)
          ? 'macOS'
          : /Linux/.test(ua)
            ? 'Linux'
            : ''
  return os ? `${browser} em ${os}` : browser
}
