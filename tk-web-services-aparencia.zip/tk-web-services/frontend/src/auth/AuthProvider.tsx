import { createContext, useCallback, useContext, useMemo, type ReactNode } from 'react'
import { useQueryClient } from '@tanstack/react-query'
import { api } from '../api/client'
import { keys } from '../api/keys'
import { useMeQuery } from '../api/queries'
import type { Me } from '../api/types'

interface AuthContextValue {
  me: Me | null
  loading: boolean
  error: unknown
  setMe: (me: Me | null) => void
  refresh: () => Promise<void>
  logout: (beforeClear?: () => void | Promise<void>) => Promise<void>
}

const AuthContext = createContext<AuthContextValue | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const qc = useQueryClient()
  const q = useMeQuery()

  const setMe = useCallback((me: Me | null) => qc.setQueryData(keys.me, me), [qc])
  const refresh = useCallback(async () => {
    await qc.invalidateQueries({ queryKey: keys.me })
  }, [qc])
  const logout = useCallback(async (beforeClear?: () => void | Promise<void>) => {
    try {
      await api.post('/api/auth/logout')
    } finally {
      await beforeClear?.()
      qc.setQueryData(keys.me, null)
      // Limpa dados privados sem remover as queries 'me'/'config' (têm observadores ativos).
      qc.removeQueries({ predicate: (q) => q.queryKey[0] !== 'me' && q.queryKey[0] !== 'config' })
    }
  }, [qc])

  const value = useMemo<AuthContextValue>(
    () => ({ me: q.data ?? null, loading: q.isPending, error: q.error, setMe, refresh, logout }),
    [q.data, q.isPending, q.error, setMe, refresh, logout],
  )
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth fora do AuthProvider')
  return ctx
}

/** Utilizador autenticado (só usar dentro de <RequireAuth>). */
export function useMe(): Me {
  const { me } = useAuth()
  if (!me) throw new Error('useMe sem sessão')
  return me
}
