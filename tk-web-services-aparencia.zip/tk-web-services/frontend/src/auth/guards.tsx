import type { ReactNode } from 'react'
import { Navigate, useLocation } from 'react-router-dom'
import { ShieldAlert } from 'lucide-react'
import { useAuth } from './AuthProvider'
import { FullPageSpinner, EmptyState, ButtonLink, Button } from '../components/ui'
import { errorMessage } from '../api/client'

export function RequireAuth({ children }: { children: ReactNode }) {
  const { me, loading, error, refresh } = useAuth()
  const loc = useLocation()
  if (loading) return <FullPageSpinner />
  if (error && !me)
    return (
      <EmptyState
        className="min-h-[70vh] justify-center"
        icon={<ShieldAlert className="size-6" />}
        title="Não foi possível contactar o servidor"
        description={errorMessage(error)}
        action={<Button onClick={() => refresh()}>Tentar novamente</Button>}
      />
    )
  if (!me) {
    const next = loc.pathname + loc.search + loc.hash
    return <Navigate to={`/login?next=${encodeURIComponent(next)}`} replace />
  }
  return <>{children}</>
}

export function RequireAdmin({ children }: { children: ReactNode }) {
  const { me } = useAuth()
  if (!me?.is_admin)
    return (
      <EmptyState
        className="min-h-[60vh] justify-center"
        icon={<ShieldAlert className="size-6" />}
        title="Área reservada"
        description="Esta página é só para administradores."
        action={<ButtonLink to="/app">Voltar ao início</ButtonLink>}
      />
    )
  return <>{children}</>
}
