// Capturas de verificação dos assistentes. Uso:
//   (backend) python scripts/dev_seed.py && python scripts/dev_server_fake_llm.py
//   (frontend) npm run dev
//   BASE=http://localhost:5173 node scripts/screenshots-assistant.mjs [filtro]
import { chromium } from 'playwright'
import { existsSync, mkdirSync, readdirSync } from 'node:fs'

const BASE = process.env.BASE ?? 'http://localhost:5173'
const OUT = new URL('../screenshots/assistant/', import.meta.url).pathname
const filter = process.argv[2] ?? ''
mkdirSync(OUT, { recursive: true })

function findChromium() {
  const root = process.env.PLAYWRIGHT_BROWSERS_PATH ?? '/opt/pw-browsers'
  if (!existsSync(root)) return undefined
  const dirs = readdirSync(root).filter((d) => /^chromium-\d+$/.test(d)).sort().reverse()
  for (const d of dirs) {
    for (const sub of ['chrome-linux/chrome', 'chrome-linux64/chrome']) {
      const p = `${root}/${d}/${sub}`
      if (existsSync(p)) return p
    }
  }
  return undefined
}
const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH ?? findChromium() })
const VIEWPORTS = { desktop: { width: 1366, height: 860 }, mobile: { width: 390, height: 844 } }

async function login(user, password) {
  const ctx = await browser.newContext()
  const res = await ctx.request.post(`${BASE}/api/auth/login`, { data: { login: user, password }, headers: { 'X-Requested-With': 'tkportal' } })
  if (!res.ok()) throw new Error(`login ${user} falhou: ${res.status()} ${await res.text()}`)
  const state = await ctx.storageState()
  await ctx.close()
  return state
}

const issues = []

async function shoot(name, path, state, opts = {}) {
  for (const [vp, size] of Object.entries(VIEWPORTS)) {
    if (opts.only && opts.only !== vp) continue
    const file = `${name}-${vp}`
    if (filter && !file.includes(filter)) continue
    const ctx = await browser.newContext({ viewport: size, deviceScaleFactor: vp === 'mobile' ? 2 : 1, storageState: state, colorScheme: 'dark' })
    const page = await ctx.newPage()
    page.on('console', (m) => {
      if (m.type() === 'error') issues.push(`[${file}] console: ${m.text()}`)
    })
    page.on('pageerror', (e) => issues.push(`[${file}] pageerror: ${e.message}`))
    await page.goto(`${BASE}${path}`, { waitUntil: 'networkidle' })
    await page.waitForTimeout(400)
    if (opts.action) {
      try {
        await opts.action(page, vp)
      } catch (e) {
        issues.push(`[${file}] ação falhou: ${e.message}`)
      }
      await page.waitForTimeout(500)
    }
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth)
    if (overflow > 0) issues.push(`[${file}] overflow horizontal de ${overflow}px`)
    await page.screenshot({ path: `${OUT}${file}.png`, fullPage: !opts.viewportOnly })
    await ctx.close()
  }
}

async function send(page, text) {
  const box = page.locator('#tk-assistant-input')
  await box.fill(text)
  await box.press('Enter')
  // espera pelo fim do indicador "a escrever"
  await page.waitForFunction(() => !document.querySelector('.tk-typing-dot'), null, { timeout: 30000 })
}

const maria = await login('maria', 'Filmes-2026!')
const rita = await login('rita', 'Pipocas-2026!')
const admin = await login('admin', 'Admin-2026!')

// Painel vazio (sugestões)
await shoot('chat-painel-vazio', '/app', maria, {
  viewportOnly: true,
  action: async (page) => {
    await page.evaluate(() => sessionStorage.clear())
    await page.getByRole('button', { name: 'Ajuda' }).click()
    await page.waitForTimeout(300)
  },
})

// Painel com troca de agente + pedido de confirmação
await shoot('chat-painel-confirmar', '/app', maria, {
  viewportOnly: true,
  action: async (page) => {
    await page.getByRole('button', { name: 'Ajuda' }).click()
    await page.getByRole('button', { name: 'As legendas estão dessincronizadas' }).click()
    await page.waitForFunction(() => !document.querySelector('.tk-typing-dot'), null, { timeout: 30000 })
    await send(page, 'Quero cancelar a subscrição')
    await page.getByRole('button', { name: 'Confirmar' }).waitFor()
  },
})

// Painel com a confirmação decidida (cancelar) e feedback
await shoot('chat-painel-decidido', '/app', maria, {
  viewportOnly: true,
  only: 'desktop',
  action: async (page) => {
    await page.getByRole('button', { name: 'Ajuda' }).click()
    await send(page, 'Quando é a próxima cobrança?')
    await page.getByRole('button', { name: 'Resposta útil' }).last().click()
    await send(page, 'Quero cancelar a subscrição')
    await page.getByRole('button', { name: 'Cancelar', exact: true }).last().click()
    await page.waitForTimeout(800)
  },
})

// Página Ajuda com uma conversa antiga aberta
await shoot('ajuda', '/app/ajuda', maria, {
  action: async (page) => {
    await page.getByRole('button', { name: /The Bear/ }).first().click()
    await page.waitForTimeout(600)
  },
})

// Conta → WhatsApp: gerar código (maria) e número ligado (rita)
await shoot('conta-whatsapp-codigo', '/app/conta?tab=whatsapp', maria, {
  action: async (page) => {
    await page.getByRole('button', { name: 'Ligar WhatsApp' }).click()
    await page.getByText(/^TK-/).waitFor()
  },
})
await shoot('conta-whatsapp-ligado', '/app/conta?tab=whatsapp', rita)

// Admin
await shoot('admin-assistente', '/admin/assistente', admin)
await shoot('admin-agentes', '/admin/assistente/agentes?agente=support', admin, {
  action: async (page) => {
    await page.getByText('Ver as regras').click()
  },
})
await shoot('admin-agentes-faturacao', '/admin/assistente/agentes?agente=billing', admin, { only: 'desktop' })
await shoot('admin-conhecimento', '/admin/assistente/conhecimento', admin)
await shoot('admin-conhecimento-sugestoes', '/admin/assistente/conhecimento?status=draft', admin)
await shoot('admin-conhecimento-editar', '/admin/assistente/conhecimento?status=draft', admin, {
  only: 'desktop',
  viewportOnly: true,
  action: async (page) => {
    await page.getByRole('button', { name: 'Editar' }).first().click()
  },
})
await shoot('admin-conversas', '/admin/assistente/conversas', admin)
await shoot('admin-conversa', '/admin/assistente/conversas', admin, {
  action: async (page) => {
    await page.getByRole('link', { name: /The Bear/ }).first().click()
    await page.waitForLoadState('networkidle')
    for (const d of await page.locator('details').all()) await d.evaluate((el) => (el.open = true))
  },
})
await shoot('admin-conversa-escalada', '/admin/assistente/conversas?status=escalated', admin, {
  action: async (page) => {
    await page.getByRole('link', { name: /MB WAY/ }).first().click()
    await page.waitForLoadState('networkidle')
  },
})
await shoot('admin-conversa-promover', '/admin/assistente/conversas', admin, {
  only: 'desktop',
  viewportOnly: true,
  action: async (page) => {
    await page.getByRole('link', { name: /Samsung/ }).first().click()
    await page.waitForLoadState('networkidle')
    await page.getByRole('button', { name: 'Promover a conhecimento' }).first().click()
  },
})

await browser.close()
if (issues.length) {
  console.log('Problemas encontrados:')
  for (const i of issues) console.log(' -', i)
} else console.log('Sem problemas.')
