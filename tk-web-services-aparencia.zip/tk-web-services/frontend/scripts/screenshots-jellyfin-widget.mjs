// Captura do widget de suporte (deploy/jellyfin/tkflix-support-widget.js) numa página que imita o Jellyfin.
import { chromium } from 'playwright'
import { existsSync, mkdirSync, readdirSync, readFileSync } from 'node:fs'

const OUT = new URL('../screenshots/jellyfin/', import.meta.url).pathname
mkdirSync(OUT, { recursive: true })
const root = '/opt/pw-browsers'
const dir = readdirSync(root).filter((d) => /^chromium-\d+$/.test(d)).sort().reverse()[0]
const exe = [`${root}/${dir}/chrome-linux/chrome`, `${root}/${dir}/chrome-linux64/chrome`].find(existsSync)
const widget = readFileSync(new URL('../../deploy/jellyfin/tkflix-support-widget.js', import.meta.url), 'utf8')
  .replace('https://tkws.exemplo.pt', 'https://portal.test')
const page0 = `<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;background:#101010;color:#ddd;font-family:sans-serif">
<div style="padding:24px"><h2 style="margin:0 0 16px">Início</h2>
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:14px">
${Array.from({ length: 12 }, (_, i) => `<div style="aspect-ratio:2/3;border-radius:8px;background:linear-gradient(160deg,#333,#1a1a1a ${40 + i * 3}%)"></div>`).join('')}
</div></div></body></html>`
const chat = { conversation_id: 'c1', messages: [] }
const reply = { conversation_id: 'c1', agent: 'support', messages: [
  { id: 2, role: 'assistant', agent: 'support', content: 'Encontrei **Severance T2E3**. Sincronizei a legenda em português com o áudio — fecha e volta a abrir o episódio. 🙂' }] }

const browser = await chromium.launch({ executablePath: exe })
for (const [name, vp] of Object.entries({ desktop: { width: 1280, height: 800 }, mobile: { width: 390, height: 844 } })) {
  const page = await browser.newPage({ viewport: vp })
  page.on('pageerror', (e) => console.log('PAGEERROR', e.message))
  await page.route('https://jellyfin.test/web/', (r) => r.fulfill({ contentType: 'text/html', body: page0 }))
  await page.route('https://portal.test/**', (r) => {
    const body = JSON.parse(r.request().postData() || '{}')
    r.fulfill({ contentType: 'application/json', body: JSON.stringify(body.message ? reply : chat) })
  })
  await page.addInitScript(() => { window.ApiClient = { accessToken: () => 'jf-token-0123456789abcdef', getCurrentUser: () => Promise.resolve({ Policy: { IsAdministrator: false } }) } })
  await page.goto('https://jellyfin.test/web/')
  await page.addScriptTag({ content: widget })
  await page.waitForSelector('.tkw-btn')
  await page.screenshot({ path: `${OUT}widget-botao-${name}.png` })
  await page.click('.tkw-btn')
  await page.waitForTimeout(300)
  await page.screenshot({ path: `${OUT}widget-aberto-${name}.png` })
  await page.fill('.tkw-form textarea', 'As legendas do episódio 3 de Severance estão atrasadas')
  await page.keyboard.press('Enter')
  await page.waitForTimeout(400)
  await page.screenshot({ path: `${OUT}widget-conversa-${name}.png` })
  await page.close()
}
// administrador: o widget não aparece
const p = await browser.newPage()
await p.route('https://jellyfin.test/web/', (r) => r.fulfill({ contentType: 'text/html', body: page0 }))
await p.addInitScript(() => { window.ApiClient = { accessToken: () => 'x'.repeat(20), getCurrentUser: () => Promise.resolve({ Policy: { IsAdministrator: true } }) } })
await p.goto('https://jellyfin.test/web/')
await p.addScriptTag({ content: widget })
await p.waitForTimeout(600)
console.log('admin widget count:', await p.locator('.tkw-btn').count())
await browser.close()
