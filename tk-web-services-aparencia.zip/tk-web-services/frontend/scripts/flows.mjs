// Testes de fluxo rápidos (dev). BASE=http://localhost:5173 node scripts/flows.mjs
import { chromium } from 'playwright'
const BASE = process.env.BASE ?? 'http://localhost:5173'
const OUT = new URL('../screenshots/', import.meta.url).pathname
const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' })
const errors = []
async function newPage(vp = { width: 1366, height: 860 }) {
  const ctx = await browser.newContext({ viewport: vp })
  const page = await ctx.newPage()
  page.on('pageerror', (e) => errors.push(`pageerror: ${e.message}`))
  return page
}
const ok = (c, m) => { console.log(`${c ? 'OK  ' : 'FAIL'} ${m}`); if (!c) errors.push(m) }

// 1) Login pela UI com ?next=
let p = await newPage()
await p.goto(`${BASE}/login?next=/app/pagamentos`)
await p.getByLabel('Email ou username').fill('joao')
await p.getByLabel('Password', { exact: true }).fill('joao12345')
await p.getByRole('button', { name: 'Entrar' }).click()
await p.waitForURL((u) => u.pathname === '/app/pagamentos')
ok(true, 'login joao → /app/pagamentos')
await p.goto(`${BASE}/app/subscricoes`)
await p.getByText('Retomar subscrição').waitFor({ timeout: 8000 }).catch(async (e) => { await p.screenshot({ path: `${OUT}debug-fail.png` }); console.log(p.url()); throw e })
ok(true, 'joao vê "Retomar subscrição"')
await p.screenshot({ path: `${OUT}flow-joao-subscricoes.png`, fullPage: true })
// já autenticado + /login?next=//evil → /app
await p.goto(`${BASE}/login?next=//evil.example/x`)
await p.waitForURL((u) => u.pathname === '/app')
ok(true, 'next externo ignorado para utilizador autenticado')
// logout
await p.getByRole('button', { name: /joao/ }).first().click().catch(() => {})
await p.getByRole('menuitem', { name: 'Terminar sessão' }).click()
await p.waitForURL((u) => u.pathname === '/login' && u.searchParams.get('saiu') === '1')
await p.getByText('Terminaste a sessão').waitFor({ timeout: 5000 }).then(() => ok(true, 'logout mostra aviso'), async () => { ok(false, 'logout mostra aviso'); console.log(p.url()); await p.screenshot({ path: `${OUT}debug-logout.png` }) })

// 2) Login errado
await p.getByLabel('Email ou username').fill('joao')
await p.getByLabel('Password', { exact: true }).fill('errada123')
await p.getByRole('button', { name: 'Entrar' }).click()
await p.getByText(/Credenciais inválidas|Demasiados pedidos/).waitFor()
ok(true, 'erro de credenciais visível')

// 3) 2FA setup maria
p = await newPage()
await p.goto(`${BASE}/login`)
await p.getByLabel('Email ou username').fill('maria')
await p.getByLabel('Password', { exact: true }).fill('maria12345')
await p.getByRole('button', { name: 'Entrar' }).click()
await p.waitForURL((u) => u.pathname === '/app')
await p.goto(`${BASE}/app/conta?tab=seguranca`)
await p.getByRole('button', { name: 'Ativar 2FA' }).click()
await p.getByAltText(/Código QR/).waitFor()
const qrOk = await p.getByAltText(/Código QR/).evaluate((img) => img.complete && img.naturalWidth > 0)
ok(qrOk, 'QR 2FA renderizado')
await p.screenshot({ path: `${OUT}flow-2fa-setup.png` })
// checkout modal (sem fornecedores → botão desativado)
await p.goto(`${BASE}/app/planos?cancelado=1`)
await p.getByText('Pagamento cancelado').waitFor(); ok(true, 'aviso de pagamento cancelado')
ok(await p.getByRole('button', { name: /Indisponível com/ }).isDisabled(), 'mudar de plano indisponível sem fornecedor')

// 4) Admin: editor de plano + cliente OIDC
p = await newPage()
await p.goto(`${BASE}/login`)
await p.getByLabel('Email ou username').fill('admin')
await p.getByLabel('Password', { exact: true }).fill('admin12345')
await p.getByRole('button', { name: 'Entrar' }).click()
await p.waitForURL((u) => u.pathname === '/app')
await p.goto(`${BASE}/admin/planos`)
await p.getByRole('button', { name: 'Editar' }).nth(1).click()
await p.getByRole('heading', { name: 'Direitos' }).waitFor()
await p.getByRole('switch', { name: 'Todas as bibliotecas' }).click()
await p.waitForTimeout(800)
await p.screenshot({ path: `${OUT}flow-admin-plan-editor.png` })
await p.getByRole('button', { name: 'Guardar plano' }).click()
await p.getByRole('heading', { name: 'Plano guardado' }).waitFor()
ok(true, 'plano guardado com mensagem')
await p.screenshot({ path: `${OUT}flow-admin-plan-saved.png` })
await p.getByRole('button', { name: 'OK' }).click()

await p.goto(`${BASE}/admin/sso`)
await p.getByRole('button', { name: 'Novo cliente' }).first().click()
await p.getByLabel('Nome', { exact: true }).fill('Grafana')
await p.getByLabel('Client ID').fill(`grafana-${Date.now() % 100000}`)
await p.getByLabel('Novo: Redirect URIs').fill('https://grafana.tkflix.test/login/generic_oauth')
await p.getByRole('button', { name: 'Adicionar' }).first().click()
await p.getByRole('button', { name: 'Criar cliente' }).click()
await p.getByText('Só mostramos este segredo uma vez').waitFor()
ok(true, 'segredo OIDC mostrado')
await p.screenshot({ path: `${OUT}flow-admin-oidc-secret.png` })

await p.goto(`${BASE}/admin/operacoes?tab=jobs`)
await p.waitForTimeout(800)
await p.screenshot({ path: `${OUT}flow-admin-jobs.png`, fullPage: true })

// 5) Registo novo utilizador (mobile)
p = await newPage({ width: 390, height: 844 })
await p.goto(`${BASE}/registar?convite=TK-ADMN-0001`)
await p.getByText('Convidado por TK Master').waitFor()
await p.getByLabel('Username').fill(`teste${Date.now() % 100000}`)
await p.getByText('Disponível').waitFor()
await p.getByLabel('Email').fill(`teste${Date.now() % 100000}@tkflix.pt`)
await p.getByLabel('Password', { exact: true }).fill('Ronda-Azul-Farol-42')
await p.getByLabel('Confirmar password').fill('Ronda-Azul-Farol-42')
await p.getByRole('button', { name: 'Criar conta' }).click()
await p.waitForURL((u) => u.pathname === '/app', { timeout: 8000 }).catch(async (e) => { await p.screenshot({ path: `${OUT}debug-registo.png`, fullPage: true }); throw e })
await p.getByText('Confirma o teu email.').waitFor()
ok(true, 'registo → /app com banner de confirmação de email')
await p.screenshot({ path: `${OUT}flow-registo-app-mobile.png`, fullPage: true })

await browser.close()
console.log(errors.length ? `\nERROS:\n${errors.join('\n')}` : '\nTodos os fluxos OK.')
