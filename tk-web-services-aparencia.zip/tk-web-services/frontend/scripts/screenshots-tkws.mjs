// Capturas de verificação da marca TK Web Services. Uso:
//   BASE=http://localhost:5173 node scripts/screenshots-tkws.mjs [filtro]
// Requer o backend com dados de demonstração (scripts/dev_seed.py) e o Vite a correr.
// Opcional: MAGIC_TOKEN=<token magic_login> para capturar a sessão limitada (aberta a partir do Jellyfin).
import { chromium } from 'playwright'
import { existsSync, mkdirSync, readdirSync } from 'node:fs'

const BASE = process.env.BASE ?? 'http://localhost:5173'
const OUT = new URL('../screenshots/tkws/', import.meta.url).pathname
const filter = process.argv[2] ?? ''
mkdirSync(OUT, { recursive: true })

function findChromium() {
  const root = process.env.PLAYWRIGHT_BROWSERS_PATH ?? '/opt/pw-browsers'
  if (!existsSync(root)) return undefined
  const dirs = readdirSync(root).filter((d) => /^chromium-\d+$/.test(d)).sort().reverse()
  for (const d of dirs) {
    for (const sub of ['chrome-linux/chrome', 'chrome-linux64/chrome']) {
      const p = `${root}/${d}/${sub}`
      if (existsSync(p)) return p
    }
  }
  return undefined
}
const exe = process.env.CHROMIUM_PATH ?? findChromium()
const browser = await chromium.launch({ executablePath: exe })

const VIEWPORTS = {
  desktop: { width: 1366, height: 860 },
  mobile: { width: 390, height: 844 },
}

async function login(user, password) {
  const ctx = await browser.newContext()
  const res = await ctx.request.post(`${BASE}/api/auth/login`, {
    data: { login: user, password },
    headers: { 'X-Requested-With': 'tkportal' },
  })
  if (!res.ok()) throw new Error(`login ${user} falhou: ${res.status()} ${await res.text()}`)
  const state = await ctx.storageState()
  await ctx.close()
  return state
}

const issues = []

async function shoot(name, path, state, opts = {}) {
  for (const [vp, size] of Object.entries(VIEWPORTS)) {
    if (opts.only && opts.only !== vp) continue
    const file = `${name}-${vp}`
    if (filter && !file.includes(filter)) continue
    const ctx = await browser.newContext({
      viewport: size,
      deviceScaleFactor: vp === 'mobile' ? 2 : 1,
      storageState: state,
      colorScheme: opts.light ? 'light' : 'dark',
    })
    if (opts.light) await ctx.addInitScript(() => localStorage.setItem('tk-theme', 'light'))
    const page = await ctx.newPage()
    page.on('console', (m) => {
      if (m.type() === 'error') issues.push(`[${file}] console: ${m.text()}`)
    })
    page.on('pageerror', (e) => issues.push(`[${file}] pageerror: ${e.message}`))
    await page.goto(`${BASE}${path}`, { waitUntil: 'networkidle' })
    await page.waitForTimeout(500)
    if (opts.action) {
      try {
        await opts.action(page, vp)
      } catch (e) {
        issues.push(`[${file}] ação falhou: ${e.message}`)
      }
      await page.waitForTimeout(700)
    }
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth)
    if (overflow > 0) issues.push(`[${file}] overflow horizontal de ${overflow}px`)
    await page.screenshot({ path: `${OUT}${file}.png`, fullPage: !opts.viewportOnly })
    await ctx.close()
  }
}

await shoot('landing', '/', undefined)
await shoot('landing-top', '/', undefined, { viewportOnly: true })
await shoot('landing-light', '/', undefined, { light: true, only: 'mobile', viewportOnly: true })
await shoot('login', '/login', undefined)
await shoot('registar', '/registar', undefined)

const maria = await login('maria', 'Filmes-2026!')
await shoot('maria-inicio', '/app', maria)
await shoot('maria-streaming', '/app/streaming', maria)
await shoot('maria-convites', '/app/convites', maria, { only: 'desktop' })
await shoot('maria-menu', '/app', maria, {
  only: 'mobile',
  viewportOnly: true,
  action: (p) => p.getByRole('button', { name: 'Abrir menu' }).click(),
})

const nuno = await login('nuno', 'Novato-2026!')
await shoot('nuno-inicio', '/app', nuno, { only: 'mobile', viewportOnly: true })

const admin = await login('admin', 'Admin-2026!')
await shoot('admin-dashboard', '/admin', admin)

await browser.close()
if (issues.length) {
  console.log('Problemas:')
  for (const i of issues) console.log(' -', i)
} else console.log('Sem problemas detetados.')
