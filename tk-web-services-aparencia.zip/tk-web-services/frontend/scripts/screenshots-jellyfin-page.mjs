// Captura da Custom Page do Jellyfin (deploy/jellyfin/custom-page-conta.html) com respostas simuladas.
//   node scripts/screenshots-jellyfin-page.mjs
import { chromium } from 'playwright'
import { existsSync, mkdirSync, readdirSync, readFileSync } from 'node:fs'

const OUT = new URL('../screenshots/jellyfin/', import.meta.url).pathname
mkdirSync(OUT, { recursive: true })
const root = '/opt/pw-browsers'
const dir = readdirSync(root).filter((d) => /^chromium-\d+$/.test(d)).sort().reverse()[0]
const exe = [`${root}/${dir}/chrome-linux/chrome`, `${root}/${dir}/chrome-linux64/chrome`].find(existsSync)
const html = readFileSync(new URL('../../deploy/jellyfin/custom-page-conta.html', import.meta.url), 'utf8')
  .replace('https://tkws.exemplo.pt', 'https://portal.test')

const exchange = {
  linked: true, username: 'maria', display_name: 'Maria Silva', is_admin: false, portal_url: 'https://portal.test',
  subscriptions: [{ id: 's1', product_id: 1, plan_id: 1, plan: 'TKFLIX', status: 'active', status_label: 'Ativa',
    price: '5,00 €', interval: 'mês', renews_at: '26/10/2026', access_until: null, grace_until: null,
    can_change: true, can_cancel: true, can_resume: false }],
  plans: [
    { id: 1, product_id: 1, name: 'TKFLIX', price: '5,00 €', interval: 'mês', highlights: ['Filmes e séries', '2 ecrãs'] },
    { id: 2, product_id: 1, name: 'TKFLIX + TV', price: '7,50 €', interval: 'mês', highlights: ['Tudo do TKFLIX', 'Canais de TV em direto', '4 ecrãs'] },
    { id: 3, product_id: 1, name: 'TKFLIX Anual', price: '50,00 €', interval: 'ano', highlights: ['2 meses grátis'] },
  ],
  payment_method: 'Débito direto · CGD ••••4821', next_billing_at: '26/10/2026', has_unpaid: false, can_add_method: true,
}
const quote = { kind: 'change', lines: [
  { description: 'Crédito do tempo não usado de TKFLIX', amount_cents: -500, kind: 'credit' },
  { description: 'TKFLIX + TV (pro-rata) · 26/09–26/10', amount_cents: 750, kind: 'proration' }],
  due_now_cents: 0, next_invoice_cents: 250, next_billing_at: '2026-10-26T06:00:00+00:00', recurring_cents: 750,
  interval_unit: 'month', bonus_applies: false, needs_payment_method: false }
const chat = { conversation_id: 'c1', messages: [
  { id: 1, role: 'user', agent: 'support', content: 'As legendas do episódio 3 de Severance estão atrasadas' },
  { id: 2, role: 'assistant', agent: 'support', content: 'Encontrei **Severance T2E3**. Sincronizei a legenda em português com o áudio — fecha e volta a abrir o episódio. 🙂' },
  { id: 3, role: 'user', agent: 'billing', content: 'Obrigada! E quero passar para o plano com TV' },
  { id: 4, role: 'event', agent: 'billing', content: 'A falar com o Agente de Faturação.', ui: { type: 'agent_switch' } },
  { id: 5, role: 'event', agent: 'billing', content: 'x', ui: { type: 'confirm', action_id: 'a1', status: 'pending',
    summary: 'Mudar para TKFLIX + TV já — diferença de 2,50 € na próxima cobrança; depois 7,50 €/mês.' } },
  { id: 6, role: 'assistant', agent: 'billing', content: 'Preparei a mudança. Para avançar basta carregar em Confirmar.' },
] }

const browser = await chromium.launch({ executablePath: exe })
for (const [name, vp] of Object.entries({ desktop: { width: 1100, height: 900 }, mobile: { width: 390, height: 844 } })) {
  const page = await browser.newPage({ viewport: vp })
  await page.route('https://jellyfin.test/pages/conta', (r) => r.fulfill({ contentType: 'text/html', body: html.replace('<body>', '<body style="background:#101010;margin:0">') }))
  await page.route('https://portal.test/**', (r) => {
    const url = r.request().url()
    const body = JSON.parse(r.request().postData() || '{}')
    let data = {}
    if (url.endsWith('/exchange')) data = exchange
    else if (url.endsWith('/action')) data = quote
    else if (url.endsWith('/assistant')) data = chat
    r.fulfill({ contentType: 'application/json', body: JSON.stringify(data) })
  })
  await page.addInitScript(() => { window.ApiClient = { accessToken: () => 'jf-token-0123456789abcdef', getCurrentUser: () => Promise.resolve({ Policy: { IsAdministrator: false } }) } })
  page.on('pageerror', (e) => console.log('PAGEERROR', e.message))
  await page.goto('https://jellyfin.test/pages/conta')
  await page.waitForTimeout(600)
  await page.screenshot({ path: `${OUT}conta-${name}.png`, fullPage: true })
  await page.click('button[data-quote="2"]')
  await page.waitForTimeout(400)
  await page.screenshot({ path: `${OUT}conta-orcamento-${name}.png`, fullPage: true })
  await page.click('#tk-tab-help')
  await page.waitForTimeout(300)
  await page.screenshot({ path: `${OUT}ajuda-${name}.png`, fullPage: true })
  await page.close()
}
await browser.close()
console.log('ok')
