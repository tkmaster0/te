// Capturas da carteira, jogos e loja com beta fechado. Uso:
//   BASE=http://localhost:8000 OUT=/tmp/shots node scripts/screenshots-wallet.mjs
// Requer o backend com os dados de demonstração (scripts/dev_seed.py) e GAMES_ENABLED=true.
import { chromium } from 'playwright'
import { existsSync, mkdirSync, readdirSync } from 'node:fs'

const BASE = process.env.BASE ?? 'http://localhost:8000'
const OUT = process.env.OUT ?? new URL('../screenshots/wallet/', import.meta.url).pathname
mkdirSync(OUT, { recursive: true })

function findChromium() {
  const root = process.env.PLAYWRIGHT_BROWSERS_PATH ?? '/opt/pw-browsers'
  if (!existsSync(root)) return undefined
  for (const d of readdirSync(root).filter((x) => /^chromium-\d+$/.test(x)).sort().reverse())
    for (const sub of ['chrome-linux/chrome', 'chrome-linux64/chrome']) if (existsSync(`${root}/${d}/${sub}`)) return `${root}/${d}/${sub}`
  return undefined
}
const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH ?? findChromium() })

async function session(user, password, viewport) {
  const ctx = await browser.newContext({ viewport, deviceScaleFactor: 1 })
  const res = await ctx.request.post(`${BASE}/api/auth/login`, { data: { login: user, password }, headers: { 'X-Requested-With': 'tkportal' } })
  if (!res.ok()) throw new Error(`login ${user}: ${res.status()}`)
  return ctx
}

async function shot(ctx, path, name, act) {
  const page = await ctx.newPage()
  const errors = []
  page.on('pageerror', (e) => errors.push(String(e)))
  page.on('console', (m) => m.type() === 'error' && errors.push(m.text()))
  await page.goto(`${BASE}${path}`, { waitUntil: 'networkidle' })
  if (act) await act(page)
  await page.waitForTimeout(400)
  await page.screenshot({ path: `${OUT}/${name}.png`, fullPage: true })
  if (errors.length) console.log(`! ${name}:`, errors.slice(0, 3).join(' | '))
  await page.close()
}

const desktop = { width: 1366, height: 860 }
const mobile = { width: 390, height: 844 }
const maria = await session('maria', 'Filmes-2026!', desktop)
await shot(maria, '/app/carteira', 'wallet-maria')
await shot(maria, '/app', 'home-maria')
await shot(maria, '/app/jogos', 'games-maria')
await shot(maria, '/app/jogos/roleta', 'roulette-maria', async (p) => {
  await p.getByRole('button', { name: 'Pleno no 17' }).click()
  await p.getByRole('button', { name: 'Vermelho' }).click()
  await p.getByRole('button', { name: /^Cavalo 1[47], 1[47]/ }).first().click()
})
await shot(maria, '/app/jogos/roleta', 'roulette-spin', async (p) => {
  await p.getByRole('button', { name: 'Vermelho' }).click()
  await p.getByRole('button', { name: 'Girar' }).click()
  await p.waitForTimeout(5200)
})
await shot(maria, '/app/jogos/blackjack', 'blackjack-maria', async (p) => {
  await p.getByRole('button', { name: /Dar cartas|Nova mão/ }).click()
  await p.waitForTimeout(800)
})
const nuno = await session('nuno', 'Novato-2026!', desktop)
await shot(nuno, '/app/planos', 'store-nuno-locked')
await shot(nuno, '/app/carteira', 'wallet-nuno')
await shot(nuno, '/app/planos', 'store-nuno-unlocked', async (p) => {
  await p.getByLabel('Tens um código de convite?').fill('TKFLIX-NUNO')
  await p.getByRole('button', { name: 'Desbloquear' }).click()
  await p.waitForTimeout(1200)
})
await shot(nuno, '/app/planos', 'subscribe-nuno', async (p) => {
  await p.getByRole('button', { name: 'Adicionar' }).first().click()
  await p.getByRole('button', { name: 'Continuar' }).click()
  await p.waitForTimeout(600)
})
const mob = await session('maria', 'Filmes-2026!', mobile)
await shot(mob, '/app/carteira', 'wallet-mobile')
await shot(mob, '/app/jogos/roleta', 'roulette-mobile')
const anon = await browser.newContext({ viewport: desktop })
await shot(anon, '/', 'landing-anon')
await shot(anon, '/?convite=TKFLIX-NUNO', 'landing-invite')
const admin = await session('admin', 'Admin-2026!', desktop)
await shot(admin, '/admin', 'admin-dashboard')
await shot(admin, '/admin/migracao', 'admin-migration')
await browser.close()
console.log('ok')
