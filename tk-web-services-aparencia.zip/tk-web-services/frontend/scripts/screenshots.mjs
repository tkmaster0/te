// Capturas de ecrã de verificação (dev). Uso:
//   BASE=http://localhost:5173 node scripts/screenshots.mjs [filtro]
// Requer o backend com dados de demonstração (scripts/dev_seed.py) e o Vite a correr.
import { chromium } from 'playwright'
import { existsSync, mkdirSync } from 'node:fs'

const BASE = process.env.BASE ?? 'http://localhost:5173'
const OUT = new URL('../screenshots/', import.meta.url).pathname
const filter = process.argv[2] ?? ''
mkdirSync(OUT, { recursive: true })

const exe = ['/opt/pw-browsers/chromium-1194/chrome-linux/chrome'].find((p) => existsSync(p))
const browser = await chromium.launch({ executablePath: exe })

const VIEWPORTS = {
  desktop: { width: 1366, height: 860 },
  mobile: { width: 390, height: 844 },
}

async function login(user, password) {
  const ctx = await browser.newContext()
  const res = await ctx.request.post(`${BASE}/api/auth/login`, {
    data: { login: user, password },
    headers: { 'X-Requested-With': 'tkportal' },
  })
  if (!res.ok()) throw new Error(`login ${user} falhou: ${res.status()} ${await res.text()}`)
  const state = await ctx.storageState()
  await ctx.close()
  return state
}

const issues = []

async function shoot(name, path, state, opts = {}) {
  for (const [vp, size] of Object.entries(VIEWPORTS)) {
    const file = `${name}-${vp}`
    if (filter && !file.includes(filter)) continue
    const ctx = await browser.newContext({
      viewport: size,
      deviceScaleFactor: vp === 'mobile' ? 2 : 1,
      storageState: state,
      colorScheme: opts.light ? 'light' : 'dark',
    })
    if (opts.light) await ctx.addInitScript(() => localStorage.setItem('tk-theme', 'light'))
    const page = await ctx.newPage()
    page.on('console', (m) => {
      if (m.type() === 'error') issues.push(`[${file}] console: ${m.text()}`)
    })
    page.on('pageerror', (e) => issues.push(`[${file}] pageerror: ${e.message}`))
    await page.goto(`${BASE}${path}`, { waitUntil: 'networkidle' })
    await page.waitForTimeout(400)
    if (opts.action) await opts.action(page)
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth)
    if (overflow > 0) issues.push(`[${file}] overflow horizontal de ${overflow}px`)
    await page.screenshot({ path: `${OUT}${file}.png`, fullPage: true })
    await ctx.close()
  }
}

await shoot('landing', '/')
await shoot('login', '/login')
await shoot('registar', '/registar?convite=TK-DEMO-2026', undefined, { action: (p) => p.waitForTimeout(900) })

const maria = await login('maria', 'maria12345')
await shoot('app', '/app', maria)
await shoot('app-planos', '/app/planos', maria)
await shoot('app-subscricoes', '/app/subscricoes', maria)
await shoot('app-pagamentos', '/app/pagamentos', maria)
await shoot('app-servicos', '/app/servicos', maria)
await shoot('app-convites', '/app/convites', maria)
await shoot('app-conta', '/app/conta', maria)
await shoot('app-conta-light', '/app/conta?tab=seguranca', maria, { light: true })
await shoot('app-light', '/app', maria, { light: true })

const admin = await login('admin', 'admin12345')
const users = await (await (await browser.newContext({ storageState: admin })).request.get(`${BASE}/api/admin/users?q=maria`)).json()
const mariaId = users.items[0].id
await shoot('admin', '/admin', admin)
await shoot('admin-utilizadores', '/admin/utilizadores', admin)
await shoot('admin-utilizador', `/admin/utilizadores/${mariaId}`, admin)
await shoot('admin-planos', '/admin/planos', admin)
await shoot('admin-convites', '/admin/convites', admin)
await shoot('admin-operacoes', '/admin/operacoes?tab=integracoes', admin)
await shoot('admin-sso', '/admin/sso', admin)
await shoot('admin-auditoria', '/admin/auditoria', admin)
await shoot('admin-definicoes', '/admin/definicoes', admin)

await browser.close()
console.log(issues.length ? issues.join('\n') : 'Sem erros de consola nem overflow.')
