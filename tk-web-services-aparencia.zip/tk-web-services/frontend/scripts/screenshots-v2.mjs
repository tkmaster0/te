// Capturas de verificação da faturação consolidada (v2). Uso:
//   BASE=http://localhost:5173 node scripts/screenshots-v2.mjs [filtro]
// Requer o backend com dados de demonstração (scripts/dev_seed.py) e o Vite a correr.
// Opcional: MAGIC_TOKEN=<token magic_login> para capturar a sessão limitada (aberta a partir do Jellyfin).
import { chromium } from 'playwright'
import { existsSync, mkdirSync, readdirSync } from 'node:fs'

const BASE = process.env.BASE ?? 'http://localhost:5173'
const OUT = new URL('../screenshots/v2/', import.meta.url).pathname
const filter = process.argv[2] ?? ''
mkdirSync(OUT, { recursive: true })

function findChromium() {
  const root = process.env.PLAYWRIGHT_BROWSERS_PATH ?? '/opt/pw-browsers'
  if (!existsSync(root)) return undefined
  const dirs = readdirSync(root).filter((d) => /^chromium-\d+$/.test(d)).sort().reverse()
  for (const d of dirs) {
    for (const sub of ['chrome-linux/chrome', 'chrome-linux64/chrome']) {
      const p = `${root}/${d}/${sub}`
      if (existsSync(p)) return p
    }
  }
  return undefined
}
const exe = process.env.CHROMIUM_PATH ?? findChromium()
const browser = await chromium.launch({ executablePath: exe })

const VIEWPORTS = {
  desktop: { width: 1366, height: 860 },
  mobile: { width: 390, height: 844 },
}

async function login(user, password) {
  const ctx = await browser.newContext()
  const res = await ctx.request.post(`${BASE}/api/auth/login`, {
    data: { login: user, password },
    headers: { 'X-Requested-With': 'tkportal' },
  })
  if (!res.ok()) throw new Error(`login ${user} falhou: ${res.status()} ${await res.text()}`)
  const state = await ctx.storageState()
  await ctx.close()
  return state
}

const issues = []

async function shoot(name, path, state, opts = {}) {
  for (const [vp, size] of Object.entries(VIEWPORTS)) {
    if (opts.only && opts.only !== vp) continue
    const file = `${name}-${vp}`
    if (filter && !file.includes(filter)) continue
    const ctx = await browser.newContext({
      viewport: size,
      deviceScaleFactor: vp === 'mobile' ? 2 : 1,
      storageState: state,
      colorScheme: opts.light ? 'light' : 'dark',
    })
    if (opts.light) await ctx.addInitScript(() => localStorage.setItem('tk-theme', 'light'))
    const page = await ctx.newPage()
    page.on('console', (m) => {
      if (m.type() === 'error') issues.push(`[${file}] console: ${m.text()}`)
    })
    page.on('pageerror', (e) => issues.push(`[${file}] pageerror: ${e.message}`))
    await page.goto(`${BASE}${path}`, { waitUntil: 'networkidle' })
    await page.waitForTimeout(500)
    if (opts.action) {
      try {
        await opts.action(page, vp)
      } catch (e) {
        issues.push(`[${file}] ação falhou: ${e.message}`)
      }
      await page.waitForTimeout(700)
    }
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth)
    if (overflow > 0) issues.push(`[${file}] overflow horizontal de ${overflow}px`)
    await page.screenshot({ path: `${OUT}${file}.png`, fullPage: !opts.viewportOnly })
    await ctx.close()
  }
}

// ---------------------------------------------------------------- maria
const maria = await login('maria', 'Filmes-2026!')
await shoot('maria-inicio', '/app', maria)
await shoot('maria-servicos', '/app/servicos', maria)
await shoot('maria-loja', '/app/planos', maria)
// SubscribeModal passo 1 (VPN, plano 7) aberto via ?plano=
await shoot('maria-loja-vpn-modal', '/app/planos?plano=7', maria, {
  viewportOnly: true,
  action: async (p) => {
    await p.getByRole('dialog').waitFor()
    await p.getByText('Mensalidade').waitFor({ timeout: 5000 })
  },
})
await shoot('maria-loja-vpn-passo2', '/app/planos?plano=7', maria, {
  viewportOnly: true,
  action: async (p) => {
    await p.getByRole('dialog').getByRole('button', { name: 'Continuar' }).click()
  },
})
// ChangePlanModal com pré-visualização (TKFLIX + TV → TKFLIX)
await shoot('maria-mudar-plano', '/app/servicos', maria, {
  viewportOnly: true,
  action: async (p) => {
    await p.getByRole('button', { name: 'Mudar de plano' }).first().click()
    await p.getByRole('dialog').waitFor()
    await p.getByRole('dialog').getByText('TKFLIX', { exact: true }).click()
    await p.getByText('Como é calculado').waitFor({ timeout: 5000 })
  },
})
await shoot('maria-faturacao', '/app/faturacao', maria)
await shoot('maria-conta', '/app/conta', maria)
await shoot('maria-pagamento-concluido', '/app/pagamento/retorno?checkout=demo-checkout-concluido', maria)
await shoot('maria-adicionar-metodo', '/app/faturacao?metodo=novo', maria, {
  viewportOnly: true,
  action: async (p) => {
    await p.getByRole('dialog').waitFor()
  },
})
await shoot('maria-streaming', '/app/streaming', maria)
await shoot('maria-convites', '/app/convites', maria)
await shoot('maria-inicio-light', '/app', maria, { light: true, only: 'mobile' })
await shoot('maria-menu-cancelar', '/app/servicos', maria, {
  viewportOnly: true,
  only: 'desktop',
  action: async (p) => {
    await p.getByRole('button', { name: /Mais ações para TK Cloud/ }).click()
    await p.getByRole('menuitem', { name: /Cancelar serviço/ }).click()
  },
})

// ---------------------------------------------------------------- nuno (conta nova: onboarding)
const nuno = await login('nuno', 'Novato-2026!')
await shoot('nuno-inicio', '/app', nuno)
await shoot('nuno-servicos', '/app/servicos', nuno)
await shoot('nuno-faturacao', '/app/faturacao', nuno)
await shoot('nuno-convites', '/app/convites', nuno)
await shoot('nuno-loja-modal', '/app/planos?plano=1', nuno, {
  viewportOnly: true,
  action: async (p) => {
    await p.getByRole('dialog').getByRole('button', { name: 'Continuar' }).click()
  },
})
await shoot('nuno-pagamento-pendente', '/app/pagamento/retorno?checkout=demo-checkout-pendente', nuno)

// ---------------------------------------------------------------- rita (cobrança falhada + cartão inutilizável)
const rita = await login('rita', 'Pipocas-2026!')
await shoot('rita-inicio', '/app', rita)
await shoot('rita-faturacao', '/app/faturacao', rita)
await shoot('rita-pagar', '/app/faturacao', rita, {
  viewportOnly: true,
  action: async (p) => {
    await p.getByRole('button', { name: 'Pagar agora' }).first().click()
    await p.getByRole('dialog').waitFor()
  },
})

// ---------------------------------------------------------------- joao (cancelado)
const joao = await login('joao', 'Series-2026!')
await shoot('joao-servicos', '/app/servicos', joao)
// Gera uma entrega manual pendente (Cloud 1 TB) para a página de Entregas do admin
{
  const ctx = await browser.newContext({ storageState: joao })
  const r = await ctx.request.post(`${BASE}/api/billing/subscribe`, { data: { plan_id: 6 }, headers: { 'X-Requested-With': 'tkportal' } })
  if (!r.ok()) issues.push(`subscrever joao falhou: ${r.status()} ${await r.text()}`)
  await ctx.close()
}
await shoot('joao-servicos-cloud-pendente', '/app/servicos', joao, { only: 'mobile' })

// ---------------------------------------------------------------- sessão limitada (Jellyfin)
if (process.env.MAGIC_TOKEN) {
  const ctx = await browser.newContext()
  const res = await ctx.request.post(`${BASE}/api/auth/magic`, {
    data: { token: process.env.MAGIC_TOKEN },
    headers: { 'X-Requested-With': 'tkportal' },
  })
  if (res.ok()) {
    const scoped = await ctx.storageState()
    await shoot('scoped-streaming', '/app/streaming', scoped)
    await shoot('scoped-redirect', '/app/faturacao', scoped, { only: 'desktop' })
  } else issues.push(`magic login falhou: ${res.status()} ${await res.text()}`)
  await ctx.close()
}

// ---------------------------------------------------------------- admin
const admin = await login('admin', 'Admin-2026!')
const actx = await browser.newContext({ storageState: admin })
const users = await (await actx.request.get(`${BASE}/api/admin/users?q=maria`)).json()
const mariaId = users.items[0].id
await actx.close()

await shoot('admin-painel', '/admin', admin)
await shoot('admin-maria', `/admin/utilizadores/${mariaId}`, admin)
await shoot('admin-planos', '/admin/planos', admin)
await shoot('admin-planos-preco', '/admin/planos', admin, {
  viewportOnly: true,
  action: async (p) => {
    await p.getByRole('button', { name: 'Ações para TKFLIX', exact: true }).locator('visible=true').first().click()
    await p.getByRole('menuitem', { name: /Alterar preço/ }).click()
    await p.getByRole('dialog').waitFor()
  },
})
await shoot('admin-planos-migrar', '/admin/planos', admin, {
  viewportOnly: true,
  only: 'desktop',
  action: async (p) => {
    await p.getByRole('button', { name: 'Ações para TKFLIX', exact: true }).locator('visible=true').first().click()
    await p.getByRole('menuitem', { name: /Migrar subscritores/ }).click()
    await p.getByRole('dialog').getByRole('button', { name: 'Simular' }).click()
    await p.getByText(/vão ser migrados|vai ser migrado|Ninguém para migrar/).waitFor({ timeout: 5000 })
  },
})
await shoot('admin-produto', '/admin/planos', admin, {
  viewportOnly: true,
  only: 'desktop',
  action: async (p) => {
    await p.getByRole('button', { name: 'Editar', exact: true }).nth(2).click()
    await p.getByRole('dialog').waitFor()
  },
})
await shoot('admin-cobrancas', '/admin/cobrancas', admin, {
  action: async (p) => {
    await p.getByText('Cobrança mensal').first().click()
  },
})
await shoot('admin-cobrancas-todas', '/admin/cobrancas?estado=', admin, { only: 'desktop' })
await shoot('admin-entregas', '/admin/entregas', admin)
await shoot('admin-fornecedores', '/admin/fornecedores', admin)
await shoot('admin-migracao', '/admin/migracao', admin, {
  action: async (p) => {
    await p.getByRole('button', { name: 'Simular', exact: true }).click()
    await p.waitForTimeout(1500)
  },
})
await shoot('admin-migracao-planos', '/admin/migracao', admin, {
  viewportOnly: true,
  action: async (p) => {
    await p.getByLabel('Plano de origem').selectOption({ index: 1 })
    await p.getByRole('button', { name: 'Escolher destino' }).click()
    await p.getByRole('dialog').getByRole('button', { name: 'Simular' }).click()
    await p.getByText(/vão ser migrados|vai ser migrado|Ninguém para migrar/).waitFor({ timeout: 5000 })
  },
})
await shoot('admin-utilizadores', '/admin/utilizadores', admin)
await shoot('admin-convites', '/admin/convites', admin)
await shoot('admin-operacoes', '/admin/operacoes', admin)
await shoot('admin-sso', '/admin/sso', admin)
await shoot('admin-auditoria', '/admin/auditoria', admin)
await shoot('admin-definicoes', '/admin/definicoes', admin)

await browser.close()
console.log(issues.length ? issues.join('\n') : 'Sem erros de consola nem overflow.')
