// Aplica o tema antes do React arrancar (evita o "flash" de tema errado). Ficheiro externo por causa da CSP.
(function () {
  var pref = 'dark'
  try { pref = localStorage.getItem('tk-theme') || 'dark' } catch (e) { /* armazenamento indisponível */ }
  var dark = pref === 'dark' || (pref === 'system' && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches)
  document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light')
})()
