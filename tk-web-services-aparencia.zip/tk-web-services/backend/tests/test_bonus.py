"""Bónus de convites na faturação consolidada: com ≥3 convidados pagantes (≥2 se convidado por um admin) o
streaming não é cobrado — linha "bonus" negativa na cobrança do ciclo, subscrição no estado "bonus"."""
from __future__ import annotations

from datetime import timedelta

from conftest import (
    add_method,
    add_sub,
    create_user,
    cycle,
    dbs,
    drain,
    dt,
    emails,
    fetch,
    get,
    make_product,
    subscribe_api,
    update_row,
)
from sqlalchemy import select
from test_gocardless import gc_subscribe

from app.db import utcnow
from app.models import InvoiceLine, Subscription, SubStatus, User
from app.services.bonus import active_invitees, evaluate_user
from app.services.jobs import enqueue
from app.services.subscriptions import sweep


async def run_bonus() -> None:
    async with dbs() as db:
        await enqueue(db, "bonus_evaluate_all", {}, dedupe_key="bonus_evaluate_all")
        await db.commit()
    await drain()


async def lines_of(inv_id: str) -> list[InvoiceLine]:
    async with dbs() as db:
        return list((await db.scalars(select(InvoiceLine).where(InvoiceLine.invoice_id == inv_id)
                                      .order_by(InvoiceLine.id))).all())


async def test_bonus_waives_streaming_and_resumes_billing(client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    boss = await create_user("padrinho")
    sub = await gc_subscribe(client, svc, boss)
    invitees = []
    for i in range(3):
        inv = await create_user(f"afilhado{i}", referred_by=boss)
        invitees.append((inv, await add_sub(inv)))
    # um convidado sem subscrição e outro bloqueado não contam
    await create_user("semsub", referred_by=boss)
    blocked = await create_user("bloqueado", referred_by=boss, is_active=False)
    await add_sub(blocked)
    async with dbs() as db:
        assert await active_invitees(db, boss.id) == 3

    await run_bonus()
    sub = await get(Subscription, sub.id)
    assert sub.status == SubStatus.bonus
    assert await emails("bonus_on", to=boss.email) == []  # bónus ligado: sem email (vê-se no portal)
    assert (await client.get("/api/auth/me")).json()["has_access"] is True
    info = (await client.get("/api/invites")).json()
    assert info["bonus"] == {"active_invitees": 3, "threshold": 3, "eligible": True, "enabled": True}
    assert sum(r["counts_for_bonus"] for r in info["invitees"]) == 3
    upcoming = (await client.get("/api/billing/summary")).json()["upcoming"]
    assert upcoming["total_cents"] == 0 and upcoming["lines"][-1]["kind"] == "bonus"

    # correr outra vez não faz nada (nem emails repetidos)
    await run_bonus()
    assert len(await emails("bonus_on")) == 0

    # cobrança do ciclo: renovação + linha de bónus → 0, sem débito na GoCardless
    charges = len(svc.gc.charges())
    clock.set(dt(2026, 11, 5, 6))
    inv = await cycle(boss)
    assert inv.total_cents == 0 and inv.status == "paid"
    assert [(ln.kind, ln.amount_cents) for ln in await lines_of(inv.id)] == [("renewal", 500), ("bonus", -500)]
    assert len(svc.gc.charges()) == charges
    assert (await get(Subscription, sub.id)).period_amount_cents == 0  # base do crédito numa mudança de plano

    # um convidado cancela e o acesso dele termina → bónus retirado, cobrança retomada no ciclo seguinte
    inv0, inv0_sub = invitees[0]
    await update_row(Subscription, inv0_sub.id, status=SubStatus.canceling.value,
                     access_until=utcnow() - timedelta(minutes=1))
    async with dbs() as db:
        await sweep(db)
    await run_bonus()
    sub = await get(Subscription, sub.id)
    assert sub.status == SubStatus.active
    [off] = await emails("bonus_off", to=boss.email)
    assert off["ctx"]["threshold"] == 3 and off["ctx"]["when"] == "05/12/2026"
    assert (await client.get("/api/auth/me")).json()["has_access"] is True
    clock.set(dt(2026, 12, 5, 6))
    inv = await cycle(boss)
    assert inv.total_cents == 500 and inv.status == "processing"


async def test_bonus_only_waives_bonus_eligible_products(make_client, svc, clock, admin):
    clock.set(dt(2026, 10, 5, 12))
    await make_product("cloud", plans=[("cloud-m", 300, "month")], bonus_eligible=False)
    boss = await create_user("padrinho", referred_by=admin)
    await add_method(svc, boss, "stripe")
    c = make_client()
    await c.login_as(boss)
    await subscribe_api(c, "tkflix-mensal")
    await subscribe_api(c, "cloud-m")
    for i in range(2):
        await add_sub(await create_user(f"afilhado{i}", referred_by=boss))
    await run_bonus()
    clock.set(dt(2026, 11, 5, 6))
    inv = await cycle(boss)
    kinds = [(ln.kind, ln.amount_cents) for ln in await lines_of(inv.id)]
    cloud = sum(a for k, a in kinds if k in ("renewal", "proration")) - 500  # tudo menos o streaming
    assert ("bonus", -500) in kinds and ("renewal", 300) in kinds
    assert inv.total_cents == cloud and inv.status == "paid"


async def test_admin_referred_user_uses_lower_threshold(client, svc, admin):
    boss = await create_user("padrinho", referred_by=admin)
    sub = await gc_subscribe(client, svc, boss)
    for i in range(2):
        inv = await create_user(f"afilhado{i}", referred_by=boss)
        await add_sub(inv)
    await run_bonus()
    assert (await get(Subscription, sub.id)).status == SubStatus.bonus
    info = (await client.get("/api/invites")).json()["bonus"]
    assert info["threshold"] == 2


async def test_non_admin_referred_needs_full_threshold(client, svc):
    friend = await create_user("amigo")
    boss = await create_user("padrinho", referred_by=friend)
    sub = await gc_subscribe(client, svc, boss)
    for i in range(2):
        await add_sub(await create_user(f"afilhado{i}", referred_by=boss))
    await run_bonus()
    assert (await get(Subscription, sub.id)).status == SubStatus.active
    assert await emails("bonus_on") == []


async def test_bonus_disabled_setting(client, svc, settings):
    settings.set("bonus_enabled", False)
    boss = await create_user("padrinho")
    sub = await gc_subscribe(client, svc, boss)
    for i in range(3):
        await add_sub(await create_user(f"afilhado{i}", referred_by=boss))
    async with dbs() as db:
        assert await evaluate_user(db, await db.get(User, boss.id)) is None
    assert (await get(Subscription, sub.id)).status == SubStatus.active
    assert (await client.get("/api/billing/summary")).json()["upcoming"]["total_cents"] == 500


async def test_unpaid_invitees_do_not_count_for_bonus():
    """Contas convidadas sem nenhum pagamento confirmado, em atraso ou elas próprias em bónus não contam."""
    boss = await create_user("chefe")
    for i in range(3):
        inv = await create_user(f"falso{i}", referred_by=boss)
        await add_sub(inv, paid=False)
    late = await create_user("atrasado", referred_by=boss)
    await add_sub(late, status=SubStatus.past_due)
    free = await create_user("embonus", referred_by=boss)
    await add_sub(free, status=SubStatus.bonus)
    async with dbs() as db:
        assert await active_invitees(db, boss.id) == 0


async def test_invitee_only_counts_with_bonus_eligible_product(make_client, svc):
    _, plans = await make_product("cloud", plans=[("cloud-m", 300, "month")], bonus_eligible=False)
    boss = await create_user("chefe")
    for i in range(3):
        inv = await create_user(f"cloud{i}", referred_by=boss)
        await add_sub(inv, "cloud-m")
    async with dbs() as db:
        assert await active_invitees(db, boss.id) == 0
    # um convidado que pagou uma cobrança do portal (sem pagamentos antigos) conta
    v = await create_user("novo", referred_by=boss)
    await add_method(svc, v, "stripe")
    c = make_client()
    await c.login_as(v)
    await subscribe_api(c, "tkflix-mensal")
    async with dbs() as db:
        assert await active_invitees(db, boss.id) == 1
    assert len(await fetch(Subscription, user_id=v.id)) == 1
