"""SSO para as apps (Jellyfin, Seerr, LibreChat), beta fechado do TKFLIX, migração Stripe e retries do fornecedor."""
from __future__ import annotations

from conftest import (
    add_sub,
    create_user,
    customer,
    cycle,
    dbs,
    drain,
    dt,
    fetch,
    fetch_one,
    gc_event,
    get,
    plan_by_code,
    post_gc_webhook,
    subscribe_api,
    update_row,
)
from test_auth import register
from test_oidc import SECRET, basic, get_code

from app.models import (
    InviteCode,
    Invoice,
    OIDCClient,
    OIDCRefreshToken,
    Payment,
    PaymentMethod,
    Plan,
    Subscription,
    SubStatus,
    User,
)
from app.security import hash_password
from app.services import legacy_stripe  # noqa: F401 — carregado antes do relógio de teste
from app.services.subscriptions import set_status, sweep

LC_REDIRECT = "https://chat.test/oauth/openid/callback"


async def librechat_client():
    async with dbs() as db:
        db.add(OIDCClient(client_id="librechat", name="TKGPT", secret_hash=hash_password(SECRET),
                          redirect_uris=[LC_REDIRECT], required_access="product:tkgpt",
                          allowed_scopes=["openid", "profile", "email", "groups", "offline_access"]))
        await db.commit()


# --------------------------------------------------------------------------- SSO por produto
async def test_librechat_requires_active_tkgpt_and_revokes_on_end(make_client, svc):
    await librechat_client()
    # O TKGPT já vem criado na instalação (plano inativo até haver preço): acrescenta-se um plano ativo.
    from sqlalchemy import select

    from app.models import Plan, Product

    async with dbs() as db:
        p = await db.scalar(select(Product).where(Product.code == "tkgpt"))
        db.add(Plan(product_id=p.id, code="tkgpt-m", name="TKGPT", price_cents=1000, interval_unit="month"))
        await db.commit()
    u = await create_user("maria")
    c = make_client()
    await c.login_as(u)
    r = await c.get("/oidc/authorize", params={"response_type": "code", "client_id": "librechat",
                                               "redirect_uri": LC_REDIRECT, "scope": "openid email offline_access",
                                               "state": "st-123"})
    assert r.status_code == 302 and "/sem-acesso" in r.headers["location"]
    sub = await add_sub(u, "tkgpt-m")
    code = await get_code(c, client_id="librechat", redirect_uri=LC_REDIRECT,
                          scope="openid profile email groups offline_access")
    tok = await c.post("/oidc/token", data={"grant_type": "authorization_code", "code": code,
                                            "redirect_uri": LC_REDIRECT}, headers=basic("librechat", SECRET))
    assert tok.status_code == 200, tok.text
    at = tok.json()["access_token"]
    info = (await c.get("/oidc/userinfo", headers={"Authorization": f"Bearer {at}"})).json()
    assert info["email"] == u.email and info["email_verified"] is True and "product:tkgpt" in info["groups"]
    # subscrição termina → userinfo recusa e a reconciliação revoga os refresh tokens desta app
    async with dbs() as db:
        s = await db.get(Subscription, sub.id)
        await set_status(db, s, SubStatus.ended, reason="teste", notify=False)
        await db.commit()
    await drain()
    assert (await c.get("/oidc/userinfo", headers={"Authorization": f"Bearer {at}"})).status_code == 401
    [rt] = await fetch(OIDCRefreshToken, client_id="librechat")
    assert rt.revoked_at is not None


async def test_unverified_email_never_leaves_the_portal(make_client):
    await librechat_client()
    u = await create_user("maria", verified=False)
    c = make_client()
    await c.login_as(u)
    r = await c.get("/oidc/authorize", params={"response_type": "code", "client_id": "librechat",
                                               "redirect_uri": LC_REDIRECT, "scope": "openid email",
                                               "state": "x"})
    assert r.status_code == 302 and "motivo=email" in r.headers["location"]


async def test_oidc_presets_from_env(admin_client, settings):
    settings.set("jellyfin_public_url", "https://tkflix.test")
    settings.set("seerr_public_url", "https://pedidos.test")
    settings.set("librechat_url", "https://chat.test")
    r = await admin_client.post("/api/admin/oidc-clients/presets")
    assert r.status_code == 200
    out = {c["client_id"]: c for c in r.json()["clients"]}
    assert set(out) == {"jellyfin", "seerr", "librechat"}
    assert all(c["client_secret"] for c in out.values())
    assert out["jellyfin"]["required_access"] == "feature:jellyfin"
    assert "https://tkflix.test/sso/OID/r/tkflix" in out["jellyfin"]["redirect_uris"]
    assert "https://pedidos.test/login" in out["seerr"]["redirect_uris"]
    assert out["librechat"]["redirect_uris"] == ["https://chat.test/oauth/openid/callback"]
    # correr outra vez não troca os segredos (a não ser com rotate)
    again = {c["client_id"]: c for c in (await admin_client.post("/api/admin/oidc-clients/presets")).json()["clients"]}
    assert all(c["client_secret"] is None for c in again.values())


async def test_seerr_permissions_follow_subscription(make_client, svc):
    from test_provisioning import link_jf, reconcile

    u = await create_user("maria")
    await link_jf(svc, u)
    sub = await add_sub(u)
    await reconcile(u.id)
    seerr_id = int((await fetch_one(__import__("app.models", fromlist=["ServiceAccount"]).ServiceAccount,
                                    service="seerr")).external_id)
    svc.seerr.permissions[seerr_id] = 32
    async with dbs() as db:
        s = await db.get(Subscription, sub.id)
        await set_status(db, s, SubStatus.ended, reason="teste", notify=False)
        await db.commit()
    await reconcile(u.id)
    assert svc.seerr.permissions[seerr_id] == 0
    await add_sub(u)
    await reconcile(u.id)
    assert svc.seerr.permissions[seerr_id] == 32


# --------------------------------------------------------------------------- TKFLIX em beta fechado
async def test_account_without_tkflix_invite_sees_tk_cdn_and_unlocks_with_code(make_client, admin):
    async with dbs() as db:
        db.add(InviteCode(code="SO-REGISTO", created_by_id=admin.id, max_uses=5, unlocks=[]))
        db.add(InviteCode(code="TKFLIX-AMIGO", created_by_id=admin.id, max_uses=1, unlocks=["tkflix"]))
        await db.commit()
    c = make_client()
    r = await register(c, "novo", invite="SO-REGISTO")
    assert r.status_code == 200
    [p] = (await c.get("/api/billing/products")).json()
    assert p["locked"] is True and p["name"] == "TK CDN" and p["description"] == "Beta testing fechado"
    assert p["plans"] == []
    # Nada no catálogo denuncia o que é
    assert p["fulfillment"] == "none" and not p["jellyfin_managed"] and "tkflix" not in str(p).lower()
    plan = await plan_by_code("tkflix-mensal")
    r = await c.get("/api/billing/quote", params={"plan_id": plan.id})
    assert r.status_code == 404
    r = await c.post("/api/billing/unlock", json={"code": "errado"})
    assert r.status_code == 400
    r = await c.post("/api/billing/unlock", json={"code": "tkflix-amigo"})
    assert r.status_code == 200 and "TKFLIX" in r.json()["message"]
    [p] = (await c.get("/api/billing/products")).json()
    assert p["locked"] is False and p["code"] == "tkflix" and len(p["plans"]) == 4
    assert (await c.get("/api/auth/me")).json()["unlocked_products"] == ["tkflix"]
    # o código era de uso único
    c2 = make_client()
    await register(c2, "outro", email="outro@example.com", invite="SO-REGISTO")
    assert (await c2.post("/api/billing/unlock", json={"code": "TKFLIX-AMIGO"})).status_code == 400


async def test_tkflix_customer_invite_unlocks_tkflix(make_client):
    boss = await create_user("amigo")  # cliente antigo com o TKFLIX desbloqueado
    await add_sub(boss)
    async with dbs() as db:
        db.add(InviteCode(code="DO-AMIGO", created_by_id=boss.id, max_uses=1))
        await db.commit()
    c = make_client()
    r = await register(c, "novato", invite="DO-AMIGO")
    assert r.status_code == 200
    u = await fetch_one(User, username="novato")
    assert u.unlocked_products == ["tkflix"] and u.referred_by_id == boss.id


async def test_locked_product_cannot_be_subscribed(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, c, pm = await customer(make_client, svc, "maria", unlocked_products=[])
    r = await c.post("/api/billing/subscribe", json={"plan_id": (await plan_by_code("tkflix-mensal")).id})
    assert r.status_code == 404


# --------------------------------------------------------------------------- retries finais do fornecedor
async def test_gocardless_automatic_retry_is_not_a_final_failure(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, c, pm = await customer(make_client, svc, "maria", provider="gocardless")
    await subscribe_api(c, "tkflix-mensal")
    [p1] = svc.gc.charges()
    svc.gc.set_payment(p1["id"], "confirmed")
    await post_gc_webhook(c, [gc_event("payments", "confirmed", payment=p1["id"])])
    await drain()
    clock.set(dt(2026, 11, 5, 6))
    inv = await cycle(u)
    p2 = svc.gc.charges()[-1]
    svc.gc.set_payment(p2["id"], "failed")
    ev = gc_event("payments", "failed", payment=p2["id"])
    ev["details"] = {"will_attempt_retry": True, "description": "Saldo insuficiente"}
    await post_gc_webhook(c, [ev])
    await drain()
    inv = await get(Invoice, inv.id)
    assert inv.status == "processing" and "nova tentativa" in inv.last_error and inv.next_attempt_at is None
    sub = await fetch_one(Subscription, user_id=u.id)
    assert sub.status == SubStatus.active
    # desistência final → falha normal (tentativas do portal + tolerância)
    ev = gc_event("payments", "failed", payment=p2["id"])
    ev["details"] = {"will_attempt_retry": False, "description": "Saldo insuficiente"}
    await post_gc_webhook(c, [ev])
    await drain()
    inv = await get(Invoice, inv.id)
    assert inv.status == "failed" and inv.next_attempt_at is not None
    assert (await get(Subscription, sub.id)).status == SubStatus.past_due


async def test_no_suspension_while_retries_are_pending(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, c, pm = await customer(make_client, svc, "maria")
    await subscribe_api(c, "tkflix-mensal")
    svc.stripe.behavior[pm.provider_ref] = ("card_error", "insufficient_funds")
    clock.set(dt(2026, 11, 5, 6))
    inv = await cycle(u)
    sub = await fetch_one(Subscription, user_id=u.id)
    assert sub.status == SubStatus.past_due
    # tolerância acabou mas ainda há uma tentativa agendada → mantém o acesso
    await update_row(Subscription, sub.id, grace_until=dt(2026, 11, 6, 6))
    clock.set(dt(2026, 11, 7, 6))
    async with dbs() as db:
        counts = await sweep(db)
    assert counts.get("waiting_retry") == 1 and (await get(Subscription, sub.id)).status == SubStatus.past_due
    # sem mais tentativas → suspende
    await update_row(Invoice, inv.id, next_attempt_at=None)
    async with dbs() as db:
        await sweep(db)
    assert (await get(Subscription, sub.id)).status == SubStatus.suspended


# --------------------------------------------------------------------------- migração Stripe (TKGPT)
async def test_stripe_legacy_subscriptions_move_to_portal_without_customer_action(admin_client, svc, clock):
    clock.set(dt(2026, 10, 10, 12))
    existing = await create_user("joana", email="joana@example.com")
    s1 = svc.stripe.add_legacy_subscription(email="joana@example.com", amount=1000,
                                            period_start=int(dt(2026, 9, 20, 0).timestamp()),
                                            period_end=int(dt(2026, 10, 20, 0).timestamp()))
    s2 = svc.stripe.add_legacy_subscription(email="novo.cliente@example.com", amount=1000,
                                            period_start=int(dt(2026, 9, 25, 0).timestamp()),
                                            period_end=int(dt(2026, 10, 25, 0).timestamp()))
    r = await admin_client.post("/api/admin/stripe/import", json={"dry_run": True})
    assert r.json()["count"] == 2 and svc.stripe.subscriptions[s1["id"]]["status"] == "active"
    assert await fetch(Subscription) == []
    r = await admin_client.post("/api/admin/stripe/import", json={"dry_run": False})
    assert r.status_code == 200 and r.json()["count"] == 2, r.text
    assert svc.stripe.subscriptions[s1["id"]]["status"] == "canceled"
    assert svc.stripe.subscriptions[s2["id"]]["status"] == "canceled"
    plan = await fetch_one(Plan, stripe_price_id="price_1000_month")
    assert plan.price_cents == 1000 and plan.interval_unit == "month"
    sub = await fetch_one(Subscription, user_id=existing.id)
    assert sub.provider == "portal" and sub.status == SubStatus.active and sub.current_period_end == dt(2026, 10, 20, 6)
    pm = await fetch_one(PaymentMethod, user_id=existing.id)
    assert pm.provider == "stripe" and pm.is_default
    new = await fetch_one(User, email="novo.cliente@example.com")
    assert new.billing_mode == "legacy" and new.email_verified_at is not None
    assert await fetch(Payment, user_id=new.id)
    # idempotente
    r = await admin_client.post("/api/admin/stripe/import", json={"dry_run": False})
    assert all("já migrada" in x["result"] for x in r.json()["results"])
    assert len(await fetch(Subscription)) == 2
    # o portal cobra no dia em que o Stripe ia cobrar, com o cartão que já lá estava
    clock.set(dt(2026, 10, 20, 6))
    inv = await cycle(existing)
    assert inv.total_cents == 1000 and inv.status == "paid"
