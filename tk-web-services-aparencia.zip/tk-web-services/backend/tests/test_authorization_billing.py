"""Faturação por autorização (por omissão): aderir exige débito direto ou cartão; sem carregamento mensal.
Conta de administrador pré-carregada."""
from __future__ import annotations

from conftest import create_user, customer, dbs, dt, fetch, fetch_one, plan_by_code, subscribe_api

from app.models import Invoice, InvoiceLine, User
from app.seed import ensure_test_admin
from app.security import verify_password
from app.services import wallet as wallet_svc


async def test_subscribe_without_method_redirects_to_authorization_even_with_balance(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, c, _ = await customer(make_client, svc, "novo", provider=None)
    async with dbs() as db:
        await wallet_svc.post(db, u.id, 5000, "adjustment", "teste")
        await db.commit()
    plan = await plan_by_code("tkflix-mensal")
    r = await c.post("/api/billing/subscribe", json={"plan_id": plan.id})
    assert r.status_code == 400 and "pagar" in r.json()["detail"].lower()
    out = await subscribe_api(c, "tkflix-mensal", provider="stripe")
    assert out["status"] == "redirect"  # autorização no fornecedor (cartão guardado)
    assert await fetch(Invoice, user_id=u.id) == []


async def test_with_method_portal_charges_and_uses_balance_first(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, c, _ = await customer(make_client, svc, "maria")
    async with dbs() as db:
        await wallet_svc.post(db, u.id, 200, "adjustment", "teste")
        await db.commit()
    out = await subscribe_api(c, "tkflix-mensal")
    assert out["status"] == "active"
    plan_price = (await plan_by_code("tkflix-mensal")).price_cents
    [inv] = await fetch(Invoice, user_id=u.id)
    assert inv.status == "paid"
    kinds = {ln.kind for ln in await fetch(InvoiceLine, invoice_id=inv.id)}
    assert "wallet" in kinds and "mtopup" not in kinds
    assert inv.total_cents == plan_price - 200


async def test_monthly_topup_is_off(make_client, svc):
    u, c, _ = await customer(make_client, svc, "maria")
    r = await c.put("/api/wallet/monthly", json={"amount_cents": 1000, "skip_when_covered": True})
    assert r.status_code == 400
    w = (await c.get("/api/wallet")).json()
    assert w["monthly_enabled"] is False and w["monthly_topup_cents"] is None
    cfg = (await c.get("/api/auth/config")).json()
    assert cfg["billing"]["require_method"] is True and cfg["wallet"]["monthly_enabled"] is False
    plan = await plan_by_code("tkflix-mensal")
    q = (await c.get("/api/billing/quote", params={"plan_id": plan.id})).json()
    assert q["monthly_enabled"] is False and q["wallet_only"] is False


async def test_test_admin_is_created_once(settings):
    settings.set("test_admin_enabled", True)
    async with dbs() as db:
        assert await ensure_test_admin(db) is True
    u = await fetch_one(User, username="testews")
    assert u.is_admin and u.email == "testews@tkmasterproductions.eu" and u.email_verified_at is not None
    assert verify_password(u.password_hash, "testews")[0]
    async with dbs() as db:
        assert await ensure_test_admin(db) is False  # já existe: não mexe


async def test_test_admin_can_log_in(make_client, settings):
    settings.set("test_admin_enabled", True)
    async with dbs() as db:
        await ensure_test_admin(db)
    c = make_client()
    r = await c.login("testews", "testews")
    assert r.status_code == 200 and r.json()["status"] == "ok"
    me = (await c.get("/api/auth/me")).json()
    assert me["is_admin"] is True


async def test_test_admin_skipped_when_email_taken(settings):
    settings.set("test_admin_enabled", True)
    await create_user("outro", email="testews@tkmasterproductions.eu")
    async with dbs() as db:
        assert await ensure_test_admin(db) is False
