"""Jogos: roleta europeia e blackjack com os créditos da carteira."""
from __future__ import annotations

import pytest
from conftest import create_user, dbs, fetch, get

from app.games import blackjack as bj
from app.games import fair, roulette
from app.models import GameRound, WalletTransaction
from app.services import wallet as wallet_svc


@pytest.fixture
def games_on(settings):
    settings.set("games_enabled", True)
    return settings


async def player(make_client, balance: int = 5000, accept: bool = True):
    u = await create_user("jogador")
    async with dbs() as db:
        await wallet_svc.post(db, u.id, balance, "adjustment", "saldo inicial")
        await db.commit()
    c = make_client()
    await c.login_as(u)
    if accept:
        r = await c.put("/api/games/settings", json={"accept": True})
        assert r.status_code == 200
    return u, c


async def bal(u) -> int:
    async with dbs() as db:
        return await wallet_svc.balance(db, u.id)


# --------------------------------------------------------------------------- regras puras
def test_roulette_table_geometry():
    assert roulette.covered("split", [1, 2]) == {1, 2}
    assert roulette.covered("split", [1, 4]) == {1, 4}
    assert roulette.covered("split", [0, 2]) == {0, 2}
    with pytest.raises(roulette.BetError):
        roulette.covered("split", [3, 4])  # não são vizinhos (fim de uma linha e início da outra)
    assert roulette.covered("street", [4, 5, 6]) == {4, 5, 6}
    assert roulette.covered("corner", [1, 2, 4, 5]) == {1, 2, 4, 5}
    with pytest.raises(roulette.BetError):
        roulette.covered("corner", [2, 3, 4, 5])
    assert roulette.covered("line", list(range(31, 37))) == set(range(31, 37))
    assert roulette.covered("column", [1]) == set(range(1, 37, 3))
    assert roulette.covered("dozen", [3]) == set(range(25, 37))
    assert 0 not in roulette.covered("red", []) and len(roulette.covered("black", [])) == 18


def test_roulette_chips_and_minimum():
    assert roulette.chip_amount_ok(20) and roulette.chip_amount_ok(50) and roulette.chip_amount_ok(70)
    assert not roulette.chip_amount_ok(30) and not roulette.chip_amount_ok(10) and not roulette.chip_amount_ok(25)
    with pytest.raises(roulette.BetError):
        roulette.validate([{"type": "red", "numbers": [], "amount_cents": 50}], min_total=100, max_total=5000)
    # 0,20 + 0,50 + 0,50 em sítios diferentes = 1,20 € → chega à aposta mínima
    bets, total = roulette.validate([{"type": "straight", "numbers": [7], "amount_cents": 20},
                                     {"type": "red", "numbers": [], "amount_cents": 50},
                                     {"type": "odd", "numbers": [], "amount_cents": 50}],
                                    min_total=100, max_total=5000)
    assert total == 120
    pay, _ = roulette.settle(bets, 7)
    assert pay == 20 * 36 + 50 * 2 + 50 * 2
    pay0, _ = roulette.settle(bets, 0)
    assert pay0 == 0


def test_fair_rng_is_deterministic_and_uniformish():
    a = [fair.randbelow(fair.stream("s", "c", n, "roulette"), 37) for n in range(2000)]
    b = [fair.randbelow(fair.stream("s", "c", n, "roulette"), 37) for n in range(2000)]
    assert a == b and set(a) == set(range(37))
    assert fair.seed_hash("abc") == fair.seed_hash("abc") != fair.seed_hash("abd")


def _st(player: list[str], dealer: list[str], rest: list[str], bet: int = 100) -> dict:
    shoe = [player[0], dealer[0], player[1], dealer[1], *rest]
    return bj.new_round(shoe, bet)


def test_blackjack_rules():
    st = _st(["AS", "KH"], ["9C", "7D"], [])
    assert st["phase"] == "done" and bj.payout(st) == 250  # blackjack 3:2
    st = _st(["9S", "7H"], ["KC", "AD"], [])
    assert st["phase"] == "done" and bj.payout(st) == 0  # dealer tem blackjack (espreitou)
    st = _st(["9S", "7H"], ["AC", "KD"], [])
    assert st["phase"] == "insurance"
    bj.resolve_insurance(st, True)
    assert st["phase"] == "done" and bj.payout(st) == 50 * 3  # seguro paga 2:1, a mão perde
    st = _st(["9S", "2H"], ["6C", "TD".replace("T", "10")], ["10S", "8D"])
    extra = bj.double(st)
    assert extra == 100 and st["phase"] == "done"  # 21 contra 16+8=24 (rebenta)
    assert bj.payout(st) == 400
    st = _st(["8S", "8H"], ["10C", "7D"], ["3D", "10H", "2S", "10S"])
    bj.split(st)
    assert len(st["hands"]) == 2 and st["hands"][0]["cards"] == ["8S", "3D"]
    bj.stand(st)  # 11
    assert st["hands"][1]["cards"] == ["8H", "10H"]
    bj.stand(st)  # 18 contra 17
    assert st["phase"] == "done"
    assert [r["result"] for r in st["results"]] == ["lose", "win"]
    # dealer fica nos 17 suaves
    st = _st(["10S", "7H"], ["AC", "6D"], [])
    bj.resolve_insurance(st, False)
    bj.stand(st)
    assert st["dealer"] == ["AC", "6D"] and st["results"][0]["result"] == "push"


# --------------------------------------------------------------------------- API
async def test_games_disabled_by_default(make_client):
    u, c = await player(make_client, accept=False)
    r = await c.post("/api/games/roulette/spin", json={"bets": [{"type": "red", "amount_cents": 100}]})
    assert r.status_code == 404  # desligados: os jogos nem existem


async def test_must_accept_rules_first(make_client, games_on):
    u, c = await player(make_client, accept=False)
    r = await c.post("/api/games/roulette/spin", json={"bets": [{"type": "red", "amount_cents": 100}]})
    assert r.status_code == 400 and "18 anos" in r.json()["detail"]


async def test_roulette_spin_moves_wallet_and_is_verifiable(make_client, games_on):
    u, c = await player(make_client)
    seed_hash = (await c.get("/api/games")).json()["seed"]["server_seed_hash"]
    r = await c.post("/api/games/roulette/spin", json={"bets": [
        {"type": "red", "amount_cents": 100}, {"type": "straight", "numbers": [17], "amount_cents": 20}]})
    assert r.status_code == 200, r.text
    out = r.json()
    assert out["wager_cents"] == 120 and out["fair"]["server_seed_hash"] == seed_hash and out["fair"]["nonce"] == 0
    assert await bal(u) == 5000 - 120 + out["payout_cents"]
    # ao trocar de semente, a antiga é revelada e o resultado pode ser recalculado
    rev = (await c.post("/api/games/seed", json={"client_seed": "o-meu"})).json()
    server = rev["revealed"]["server_seed"]
    assert fair.seed_hash(server) == seed_hash
    number = fair.randbelow(fair.stream(server, rev["revealed"]["client_seed"], 0, "roulette"), 37)
    assert number == out["number"]
    assert rev["current"]["client_seed"] == "o-meu"
    kinds = [t.kind for t in await fetch(WalletTransaction, user_id=u.id)]
    assert "game_bet" in kinds


async def test_roulette_rejects_bad_bets_and_insufficient_balance(make_client, games_on):
    u, c = await player(make_client, balance=150)
    r = await c.post("/api/games/roulette/spin", json={"bets": [{"type": "red", "amount_cents": 60}]})
    assert r.status_code == 400 and "mínima" in r.json()["detail"]
    r = await c.post("/api/games/roulette/spin", json={"bets": [{"type": "split", "numbers": [3, 4],
                                                                 "amount_cents": 100}]})
    assert r.status_code == 400
    r = await c.post("/api/games/roulette/spin", json={"bets": [{"type": "red", "amount_cents": 200}]})
    assert r.status_code == 400 and "Saldo" in r.json()["detail"]
    assert await bal(u) == 150


async def test_daily_loss_limit_and_self_exclusion(make_client, games_on):
    games_on.set("games_daily_loss_limit_cents", 300)
    u, c = await player(make_client)
    lost = 0
    for _ in range(20):
        r = await c.post("/api/games/roulette/spin", json={"bets": [{"type": "straight", "numbers": [0],
                                                                     "amount_cents": 100}]})
        if r.status_code != 200:
            assert "limite diário" in r.json()["detail"]
            break
        lost += 100 - r.json()["payout_cents"]
    assert lost >= 300 or lost < 0
    # autoexclusão
    r = await c.put("/api/games/settings", json={"exclude_days": 7})
    assert r.status_code == 200
    r = await c.post("/api/games/blackjack/start", json={"bet_cents": 100})
    assert r.status_code == 400 and "Pausa" in r.json()["detail"]


async def test_blackjack_round_through_api(make_client, games_on):
    u, c = await player(make_client)
    r = await c.post("/api/games/blackjack/start", json={"bet_cents": 200})
    assert r.status_code == 200, r.text
    st = r.json()
    assert "shoe" not in st and (st["phase"] == "done" or st["dealer"][1] == "??")
    guard = 0
    while st["phase"] != "done" and guard < 20:
        guard += 1
        action = "no_insurance" if st["phase"] == "insurance" else "stand"
        st = (await c.post("/api/games/blackjack/action", json={"action": action})).json()
    assert st["phase"] == "done" and "??" not in st["dealer"]
    rnd = (await fetch(GameRound, user_id=u.id))[0]
    assert rnd.status == "settled" and rnd.wager_cents == 200
    assert await bal(u) == 5000 - 200 + rnd.payout_cents
    # nova mão só depois de acabar a anterior; sem mão ativa não há ações
    r = await c.post("/api/games/blackjack/action", json={"action": "hit"})
    assert r.status_code == 400
    hist = (await c.get("/api/games")).json()["history"]
    assert hist[0]["game"] == "blackjack"


async def test_winnings_pay_overdue_invoice(make_client, games_on, svc, clock):
    from conftest import customer, cycle, dt, subscribe_api

    from app.models import GameSeed, Invoice
    from app.security import encrypt

    clock.set(dt(2026, 10, 5, 12))
    u, c, pm = await customer(make_client, svc, "maria")
    await subscribe_api(c, "tkflix-mensal")
    svc.stripe.behavior[pm.provider_ref] = ("card_error", "insufficient_funds")
    clock.set(dt(2026, 11, 5, 6))
    inv = await cycle(u)
    assert inv.status == "failed"
    # semente conhecida → sabemos que número sai e apostamos nele (pleno paga 35:1)
    server, client_seed = "semente-de-teste", "cliente"
    number = fair.randbelow(fair.stream(server, client_seed, 0, "roulette"), 37)
    async with dbs() as db:
        await wallet_svc.post(db, u.id, 100, "adjustment", "saldo")
        db.add(GameSeed(user_id=u.id, server_seed_enc=encrypt(server), server_seed_hash=fair.seed_hash(server),
                        client_seed=client_seed, nonce=0, active=True))
        await db.commit()
    await c.put("/api/games/settings", json={"accept": True})
    r = await c.post("/api/games/roulette/spin", json={"bets": [{"type": "straight", "numbers": [number],
                                                                 "amount_cents": 100}]})
    assert r.status_code == 200 and r.json()["number"] == number and r.json()["payout_cents"] == 3600
    assert (await get(Invoice, inv.id)).status == "paid"  # os ganhos pagaram logo a cobrança em atraso
    assert await bal(u) == 3600 - 500
