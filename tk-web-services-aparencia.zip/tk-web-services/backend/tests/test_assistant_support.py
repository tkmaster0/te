"""Agente de Suporte: cada ferramenta contra os fakes do Jellyfin, Bazarr e Seerr."""
from __future__ import annotations

import base64
import json

import pytest
from asst import as_json, confirm_action, linked_user, run_tool
from conftest import add_sub, create_user, dbs, fetch
from fakes import BAZARR_HOST

from app.assistant.models import PendingAction
from app.models import AuditLog, SubStatus

MATRIX_PATH = "/data/movies/The Matrix (1999)/The.Matrix.1999.1080p.mkv"
STREAMS = [
    {"Type": "Video", "Codec": "hevc", "Width": 1920, "Height": 1080, "VideoRangeType": "HDR10",
     "BitRate": 8_000_000},
    {"Type": "Audio", "Language": "eng", "Codec": "eac3", "Channels": 6, "DisplayTitle": "English 5.1"},
    {"Type": "Subtitle", "Language": "por", "Codec": "subrip", "IsExternal": True, "IsForced": False,
     "DisplayTitle": "Português"},
]


@pytest.fixture
def library(svc):
    jf = svc.jf
    lib = {
        "matrix": jf.add_item("The Matrix", year=1999, provider_ids={"Imdb": "tt0133093", "Tmdb": "603"},
                              path=MATRIX_PATH, streams=STREAMS),
        "hidden": jf.add_item("Filme Privado", lib="lib-privada", provider_ids={"Imdb": "tt999"}),
        "dark": jf.add_item("Dark", "Series", provider_ids={"Tvdb": "334824", "Tmdb": "70523",
                                                             "Imdb": "tt5753856"}),
    }
    lib["s1e1"] = jf.add_item("Segredos", "Episode", series=lib["dark"], season=1, episode=1,
                              path="/data/tv/Dark/Season 01/Dark.S01E01.mkv")
    lib["s1e2"] = jf.add_item("Mentiras", "Episode", series=lib["dark"], season=1, episode=2,
                              path="/data/tv/Dark/Season 01/Dark.S01E02.mkv")
    return lib


@pytest.fixture
async def ana(svc):
    u, jf = await linked_user(svc, "ana", seerr_id=7, libs=["lib1"])
    return u


def opt(data: dict) -> str:
    return base64.urlsafe_b64encode(json.dumps(data, separators=(",", ":")).encode()).decode().rstrip("=")


# =========================================================================== conteúdos
async def test_find_title_only_sees_users_libraries(ana, library, svc):
    out, _ = await run_tool(ana, "find_title", query="matrix")
    rows = as_json(out)
    assert rows == [{"item_id": library["matrix"]["Id"], "type": "Movie", "title": "The Matrix (1999)"}]
    out, _ = await run_tool(ana, "find_title", query="privado")
    assert out.startswith("Não está na biblioteca") and "https://pedidos.test" in out
    # Episódios aparecem com série/temporada/episódio.
    out, _ = await run_tool(ana, "find_title", query="segredos", kind="episode")
    assert as_json(out)[0]["title"] == "Dark T1E1 — Segredos"
    # A pesquisa é feita com o utilizador do Jellyfin do cliente.
    req = svc.jf.find("GET", r"^/Items$")[0]
    assert req.url.params["userId"] == svc.jf.by_name("ana")["Id"]


async def test_find_title_errors(svc, library):
    sem_jf = await create_user("sem-jellyfin")
    out, _ = await run_tool(sem_jf, "find_title", query="matrix")
    assert out.startswith("Erro: Esta conta ainda não tem utilizador no Jellyfin")
    u, _ = await linked_user(svc, "bia")
    svc.jf.down = True
    out, _ = await run_tool(u, "find_title", query="matrix")
    assert out.startswith("Erro: Jellyfin indisponível")


async def test_find_episode(ana, library):
    out, _ = await run_tool(ana, "find_episode", series_item_id=library["dark"]["Id"], season=1, episode=2)
    assert as_json(out) == {"item_id": library["s1e2"]["Id"], "title": "Dark T1E2 — Mentiras"}
    out, _ = await run_tool(ana, "find_episode", series_item_id=library["dark"]["Id"], season=1, episode=9)
    assert "tem 2 episódios" in out
    out, _ = await run_tool(ana, "find_episode", series_item_id=library["dark"]["Id"], season="x", episode=1)
    assert out.startswith("Erro: Não consegui listar")


async def test_title_details_without_and_with_bazarr(ana, library, settings, svc):
    out, _ = await run_tool(ana, "title_details", item_id=library["matrix"]["Id"])
    d = as_json(out)
    assert d["video"] == {"resolution": "1920x1080", "codec": "hevc", "hdr": "HDR10", "bitrate_mbps": 8.0}
    assert d["audio"][0]["channels"] == 6 and d["subtitles"][0] == {
        "language": "por", "external": True, "forced": False, "hearing_impaired": False, "format": "subrip",
        "title": "Português"}
    assert d["container"] == "mkv" and "bazarr" not in d
    # Itens de bibliotecas a que o cliente não tem acesso não existem para ele (mesmo com o id certo).
    out, _ = await run_tool(ana, "title_details", item_id=library["hidden"]["Id"])
    assert out == "Erro: Não encontrei esse título na biblioteca deste cliente."
    out, _ = await run_tool(ana, "title_details", item_id="")
    assert out.startswith("Erro: Falta o item_id")


async def test_title_details_with_bazarr(ana, library, bazarr):
    bazarr.add_movie("The Matrix", imdb="tt0133093", path="/movies/x.mkv",
                     subtitles=[{"code2": "pt", "path": "/movies/x.pt.srt", "forced": False, "hi": False}],
                     missing=["en"])
    d = as_json((await run_tool(ana, "title_details", item_id=library["matrix"]["Id"]))[0])
    assert d["bazarr"] == "conhecido"
    assert d["bazarr_subtitles"] == [{"language": "pt", "forced": False, "hi": False, "has_file": True}]
    assert d["bazarr_missing"] == ["en"]


# =========================================================================== legendas (Bazarr)
async def test_search_and_download_subtitle_movie_via_bazarr(ana, library, bazarr, svc):
    movie = bazarr.add_movie("The Matrix", imdb="tt0133093", path="/movies/other-name.mkv")
    bazarr.search_results[("movie", movie["radarrId"])] = [
        {"provider": "opensubtitles", "subtitle": "SUBA", "language": "pt", "score": 80,
         "release_info": ["The.Matrix.1999.1080p"], "hearing_impaired": False, "forced": False},
        {"provider": "podnapisi", "subtitle": "SUBB", "language": "pt", "score": 95, "release_info": "WEB",
         "hearing_impaired": True, "forced": False},
        {"provider": "addic7ed", "subtitle": "SUBC", "language": "en", "score": 99},
    ]
    out, _ = await run_tool(ana, "search_subtitles", item_id=library["matrix"]["Id"], language="português")
    data = as_json(out)
    assert data["language"] == "pt" and data["title"] == "The Matrix (1999)"
    assert [o["provider"] for o in data["options"]] == ["podnapisi", "opensubtitles"]  # por pontuação, só pt
    assert data["options"][1]["release"] == "The.Matrix.1999.1080p"
    out, _ = await run_tool(ana, "download_subtitle", item_id=library["matrix"]["Id"],
                            option_id=data["options"][0]["option_id"])
    assert out.startswith("Legenda descarregada")
    assert bazarr.downloads == [{"kind": "movies", "radarrid": str(movie["radarrId"]), "provider": "podnapisi",
                                 "subtitle": "SUBB", "hi": "True", "forced": "False", "original_format": "False"}]
    assert svc.jf.refreshed == [library["matrix"]["Id"]]
    assert [a.action for a in await fetch(AuditLog)] == ["assistant.subtitle_download"]


async def test_bazarr_movie_matched_by_filename_when_ids_differ(ana, library, bazarr):
    bazarr.add_movie("Outro", imdb="tt0000001", path="/movies/outro.mkv")
    movie = bazarr.add_movie("Matrix (Radarr)", imdb=None, path="/radarr/Matrix/The.Matrix.1999.1080p.mkv")
    bazarr.search_results[("movie", movie["radarrId"])] = [{"provider": "p", "subtitle": "S", "language": "pt",
                                                             "score": 1}]
    data = as_json((await run_tool(ana, "search_subtitles", item_id=library["matrix"]["Id"]))[0])
    assert len(data["options"]) == 1
    assert bazarr.find("GET", r"/providers/movies")[0].url.params["radarrid"] == str(movie["radarrId"])


async def test_search_and_download_subtitle_episode_via_bazarr(ana, library, bazarr):
    series = bazarr.add_series("Dark", tvdb=334824)
    bazarr.add_episode(series, 1, 1, path="/tv/dark/s01e01.mkv")
    ep2 = bazarr.add_episode(series, 1, 2, path="/tv/dark/s01e02.mkv")
    bazarr.search_results[("episode", ep2["sonarrEpisodeId"])] = [
        {"provider": "opensubtitles", "subtitle": "E2", "language": "pt", "score": 50, "forced": True}]
    data = as_json((await run_tool(ana, "search_subtitles", item_id=library["s1e2"]["Id"], language="pt"))[0])
    assert data["title"] == "Dark T1E2 — Mentiras" and data["options"][0]["forced"] is True
    out, _ = await run_tool(ana, "download_subtitle", item_id=library["s1e2"]["Id"],
                            option_id=data["options"][0]["option_id"])
    assert out.startswith("Legenda descarregada")
    d = bazarr.downloads[0]
    assert (d["kind"], d["seriesid"], d["episodeid"], d["forced"]) == (
        "episodes", str(series["sonarrSeriesId"]), str(ep2["sonarrEpisodeId"]), "True")


async def test_download_subtitle_rejects_forged_option(ana, library, bazarr, svc):
    """O option_id vem do modelo: não pode apontar para um filme diferente do item (nem de outra biblioteca)."""
    bazarr.add_movie("The Matrix", imdb="tt0133093")
    other = bazarr.add_movie("Filme Privado", imdb="tt999")
    forged = opt({"b": "movie", "r": other["radarrId"], "p": "x", "i": "y", "hi": False, "f": False})
    out, _ = await run_tool(ana, "download_subtitle", item_id=library["matrix"]["Id"], option_id=forged)
    assert out.startswith("Erro:")
    assert bazarr.downloads == []
    out, _ = await run_tool(ana, "download_subtitle", item_id=library["matrix"]["Id"], option_id="%%%")
    assert out.startswith("Erro: option_id inválido")
    # Item de uma biblioteca escondida: nem chega ao Bazarr.
    out, _ = await run_tool(ana, "download_subtitle", item_id=library["hidden"]["Id"],
                            option_id=opt({"b": "movie", "r": other["radarrId"], "p": "x", "i": "y", "hi": False,
                                           "f": False}))
    assert out.startswith("Erro: Não encontrei") and bazarr.downloads == []


async def test_subtitle_actions_daily_quota(ana, library, bazarr):
    from app.assistant.agents import support

    async with dbs() as db:
        from app.services.audit import audit

        for _ in range(support.DAILY_SUBTITLE_ACTIONS):
            audit(db, "assistant.subtitle_download", actor=ana, target_type="jellyfin_item", target_id="x")
        await db.commit()
    out, _ = await run_tool(ana, "auto_download_subtitles", item_id=library["matrix"]["Id"])
    assert out.startswith("Erro: Limite diário")
    assert not bazarr.calls


async def test_auto_download_movie_and_episode(ana, library, bazarr, svc):
    movie = bazarr.add_movie("The Matrix", imdb="tt0133093")
    series = bazarr.add_series("Dark", imdb="tt5753856")
    ep = bazarr.add_episode(series, 1, 1)
    out, _ = await run_tool(ana, "auto_download_subtitles", item_id=library["matrix"]["Id"], language="en")
    assert "inglês" in out
    out, _ = await run_tool(ana, "auto_download_subtitles", item_id=library["s1e1"]["Id"], language="pt-br")
    assert bazarr.auto == [
        {"kind": "movies", "radarrid": str(movie["radarrId"]), "language": "en", "hi": "False", "forced": "False"},
        {"kind": "episodes", "seriesid": str(series["sonarrSeriesId"]), "episodeid": str(ep["sonarrEpisodeId"]),
         "language": "pb", "hi": "False", "forced": "False"}]
    assert svc.jf.refreshed == [library["matrix"]["Id"], library["s1e1"]["Id"]]
    # Título que o Bazarr não conhece.
    out, _ = await run_tool(ana, "auto_download_subtitles", item_id=library["s1e2"]["Id"])
    assert out.startswith("Erro: O Bazarr não conhece")


async def test_sync_subtitles(ana, library, bazarr, svc):
    movie = bazarr.add_movie("The Matrix", imdb="tt0133093", subtitles=[
        {"code2": "en", "path": "/m/x.en.srt", "forced": False, "hi": False},
        {"code2": "pt", "path": None, "forced": False, "hi": False},  # embutida: não sincroniza
        {"code2": "pt", "path": "/m/x.pt.srt", "forced": False, "hi": True}])
    out, _ = await run_tool(ana, "sync_subtitles", item_id=library["matrix"]["Id"], language="por")
    assert out.startswith("Legenda sincronizada")
    assert bazarr.syncs == [{"action": "sync", "language": "pt", "path": "/m/x.pt.srt", "type": "movie",
                             "id": str(movie["radarrId"]), "forced": "False", "hi": "True"}]
    out, _ = await run_tool(ana, "sync_subtitles", item_id=library["matrix"]["Id"], language="fr")
    assert out.startswith("Erro: Não há legenda externa em francês")
    bazarr.fail_paths["/api/subtitles"] = 500
    out, _ = await run_tool(ana, "sync_subtitles", item_id=library["matrix"]["Id"], language="pt")
    assert out.startswith("Erro: A sincronização falhou")
    assert [a.action for a in await fetch(AuditLog)] == ["assistant.subtitle_sync"]


async def test_sync_subtitles_episode_and_bazarr_down(ana, library, bazarr):
    series = bazarr.add_series("Dark", tvdb=334824)
    ep = bazarr.add_episode(series, 1, 1, subtitles=[{"code2": "pt", "path": "/tv/e1.pt.srt"}])
    await run_tool(ana, "sync_subtitles", item_id=library["s1e1"]["Id"])
    assert bazarr.syncs[0]["type"] == "episode" and bazarr.syncs[0]["id"] == str(ep["sonarrEpisodeId"])
    from app.integrations import bazarr as bz

    bz._cache.clear()
    bazarr.fail_paths["/api/series"] = 502
    out, _ = await run_tool(ana, "sync_subtitles", item_id=library["s1e1"]["Id"])
    assert out.startswith("Erro: O Bazarr não respondeu")


# =========================================================================== legendas (Jellyfin)
async def test_subtitles_via_jellyfin_providers_without_bazarr(ana, library, svc):
    iid = library["matrix"]["Id"]
    svc.jf.remote_subs[(iid, "por")] = [
        {"Id": "os-1", "ProviderName": "Open Subtitles", "Name": "Matrix.PT", "CommunityRating": 7.5},
        {"Id": "os-2", "ProviderName": "Open Subtitles", "Name": "Matrix.PT.HI", "CommunityRating": 9,
         "HearingImpaired": True}]
    data = as_json((await run_tool(ana, "search_subtitles", item_id=iid))[0])  # idioma por omissão: pt
    assert [o["release"] for o in data["options"]] == ["Matrix.PT.HI", "Matrix.PT"]
    out, _ = await run_tool(ana, "download_subtitle", item_id=iid, option_id=data["options"][1]["option_id"])
    assert out.startswith("Legenda descarregada") and svc.jf.downloaded_subs == [(iid, "os-1")]
    out, _ = await run_tool(ana, "search_subtitles", item_id=iid, language="en")
    assert out.startswith("Não há legendas em inglês")
    out, _ = await run_tool(ana, "auto_download_subtitles", item_id=iid)
    assert out.startswith("Erro: O Bazarr não conhece")


async def test_enable_auto_subtitles(ana, library, settings, svc):
    out, _ = await run_tool(ana, "enable_auto_subtitles", item_id=library["s1e1"]["Id"])
    assert out.startswith("Erro: A descarga automática por coleção não está configurada")
    settings.set("bazarr_auto_collection_id", "coll-1")
    out, _ = await run_tool(ana, "enable_auto_subtitles", item_id=library["s1e1"]["Id"])
    assert out.startswith("Ativado")
    assert svc.jf.collections == {"coll-1": [library["dark"]["Id"]]}  # a série inteira, não o episódio


# =========================================================================== reprodução / dispositivos / conta
async def test_playback_diagnostics(ana, library, svc):
    me = svc.jf.by_name("ana")["Id"]
    other = svc.jf.add_user("outro")
    svc.jf.sessions = [
        {"UserId": me, "DeviceName": "Sala", "Client": "Jellyfin Android TV", "ApplicationVersion": "0.17",
         "NowPlayingItem": {"Name": "The Matrix", "Type": "Movie", "ProductionYear": 1999},
         "PlayState": {"PlayMethod": "Transcode", "IsPaused": False},
         "TranscodingInfo": {"TranscodeReasons": ["VideoCodecNotSupported"], "VideoCodec": "h264",
                             "Bitrate": 12_500_000, "HardwareAccelerationType": "qsv"}},
        {"UserId": other["Id"], "DeviceName": "Do vizinho", "Client": "Web"},
    ]
    svc.jf.resume[me] = [library["s1e1"]["Id"]]
    d = as_json((await run_tool(ana, "playback_diagnostics"))[0])
    assert len(d["sessions_last_hour"]) == 1
    s = d["sessions_last_hour"][0]
    assert s["playing"] == "The Matrix (1999)" and s["transcode_reasons"] == ["VideoCodecNotSupported"]
    assert s["transcode_bitrate_mbps"] == 12.5 and s["app"] == "Jellyfin Android TV 0.17"
    assert d["recently_watched"] == ["Dark T1E1 — Segredos"]  # nada terminado → o que está a meio
    svc.jf.played[me] = [library["matrix"]["Id"], library["hidden"]["Id"]]
    d = as_json((await run_tool(ana, "playback_diagnostics"))[0])
    assert d["recently_watched"] == ["The Matrix (1999)"]
    svc.jf.sessions = []
    d = as_json((await run_tool(ana, "playback_diagnostics"))[0])
    assert d["sessions_last_hour"] == "nenhuma sessão ativa na última hora"


async def test_my_devices(ana, svc):
    me = svc.jf.by_name("ana")["Id"]
    svc.jf.devices[me] = [{"Id": "d1", "Name": "iPhone", "AppName": "Swiftfin", "AppVersion": "1.2",
                           "DateLastActivity": "2026-09-01T10:00:00Z"}]
    assert as_json((await run_tool(ana, "my_devices"))[0]) == [
        {"name": "iPhone", "app": "Swiftfin 1.2", "last_activity": "2026-09-01T10:00:00Z"}]
    svc.jf.devices[me] = []
    assert (await run_tool(ana, "my_devices"))[0] == "Sem dispositivos registados."


async def test_streaming_access_status_has_no_financial_data(ana):
    out, _ = await run_tool(ana, "streaming_access_status")
    assert out.startswith("O cliente não tem streaming ativo")
    await add_sub(ana)
    d = as_json((await run_tool(ana, "streaming_access_status"))[0])
    assert d["access"] == "ativo" and d["plan_name"] and "features" in d
    assert "€" not in json.dumps(d, ensure_ascii=False) and "price" not in json.dumps(d)


async def test_streaming_access_status_suspended(ana):
    await add_sub(ana, status=SubStatus.suspended)
    d = as_json((await run_tool(ana, "streaming_access_status"))[0])
    assert d["access"] == "sem acesso" and "transfer_to_billing" in d["reason"]


async def test_quick_connect_requires_confirmation(ana, svc):
    svc.jf.quick_connect_codes.add("ABC123")
    out, result = await run_tool(ana, "quick_connect_authorize", code="abc123")
    assert "NÃO está feita" in out and "carregar em Confirmar" in out
    assert svc.jf.quick_connect_authorized == []  # o modelo não executa nada
    event = result.messages[0]
    assert event.ui["type"] == "confirm" and "ABC123" in event.content
    content = await confirm_action(ana, event.ui["action_id"])
    assert content.startswith("Dispositivo autorizado")
    assert svc.jf.quick_connect_authorized == [("ABC123", svc.jf.by_name("ana")["Id"])]
    assert (await fetch(PendingAction))[0].status == "done"
    # Código errado (ou já usado).
    _, result = await run_tool(ana, "quick_connect_authorize", code="ABC123")
    content = await confirm_action(ana, result.messages[0].ui["action_id"])
    assert "não foi aceite" in content
    out, _ = await run_tool(ana, "quick_connect_authorize", code="X" * 20)
    assert out == "Erro: Código Quick Connect inválido."


# =========================================================================== Seerr
async def test_my_requests_and_issues_only_own(ana, svc):
    svc.seerr.requests[7] = [{"type": "movie", "status": 2, "media": {"tmdbId": 603, "status": 3},
                              "createdAt": "2026-09-01"}]
    assert as_json((await run_tool(ana, "my_requests"))[0]) == [
        {"type": "movie", "tmdb_id": 603, "request": "aprovado", "availability": "a processar/descarregar",
         "created": "2026-09-01"}]
    svc.seerr.add_issue({"id": 7}, "Legendas fora de tempo")
    svc.seerr.add_issue({"id": 99}, "Problema PRIVADO de outra pessoa")
    rows = as_json((await run_tool(ana, "my_issues"))[0])
    assert len(rows) == 1 and rows[0]["last_comment"] == "Legendas fora de tempo"
    # Mesmo que o Seerr ignore o filtro requestedBy, o cliente nunca vê issues de outros.
    svc.seerr.ignore_requested_by = True
    out, _ = await run_tool(ana, "my_issues")
    assert "PRIVADO" not in out and len(as_json(out)) == 1


async def test_seerr_tools_without_seerr_account(svc):
    u, _ = await linked_user(svc, "bia")
    out, _ = await run_tool(u, "my_requests")
    assert out.startswith("Erro: O cliente ainda não tem conta no Seerr")


async def test_report_issue_movie_and_episode(ana, library, svc):
    movie_media = svc.seerr.add_media("movie", 603)
    tv_media = svc.seerr.add_media("tv", 70523)
    d = as_json((await run_tool(ana, "report_issue", item_id=library["matrix"]["Id"], issue_type="audio",
                                message="Sem som no minuto 10"))[0])
    issue = svc.seerr.issues[d["issue_id"]]
    assert issue["issueType"] == 2 and issue["media"]["id"] == movie_media["id"]
    assert "Sem som" in issue["comments"][0]["message"] and "ana" in issue["comments"][0]["message"]
    d = as_json((await run_tool(ana, "report_issue", item_id=library["s1e2"]["Id"], issue_type="video",
                                message="Episódio cortado"))[0])
    issue = svc.seerr.issues[d["issue_id"]]
    assert (issue["media"]["id"], issue["problemSeason"], issue["problemEpisode"]) == (tv_media["id"], 1, 2)
    # Título sem TMDB / que o Seerr não conhece.
    no_tmdb = svc.jf.add_item("Caseiro", provider_ids={})
    out, _ = await run_tool(ana, "report_issue", item_id=no_tmdb["Id"], issue_type="other", message="x")
    assert out.startswith("Erro: Este título não tem id TMDB")
    unknown = svc.jf.add_item("Desconhecido", provider_ids={"Tmdb": "1234"})
    out, _ = await run_tool(ana, "report_issue", item_id=unknown["Id"], issue_type="other", message="x")
    assert out.startswith("Erro: O Seerr não conhece")


async def test_resolve_issue_only_in_seerr_channel(ana):
    extra = {"issue_id": 5}
    out, _ = await run_tool(None, "resolve_issue", channel="seerr", extra=extra)
    assert extra["resolve"] is True and "resolvida" in out
    out, _ = await run_tool(None, "resolve_issue", channel="seerr", extra={})
    assert out == "Erro: Sem issue associada."
    with pytest.raises(AssertionError, match="não disponível"):
        await run_tool(ana, "resolve_issue", channel="web")


async def test_seerr_channel_has_no_confirmation_or_transfer_tools(ana):
    from app.assistant.agents import AGENTS
    from app.assistant.models import AssistantConversation
    from asst import tool_ctx

    async with dbs() as db:
        conv = AssistantConversation(channel="seerr", agent="support")
        ctx = tool_ctx(db, ana, conv, channel="seerr")
        names = {t.name for t in AGENTS["support"].registry.available(ctx)}
        assert "resolve_issue" in names and "find_title" in names
        assert not {"quick_connect_authorize", "report_issue", "transfer_to_billing"} & names
        ctx = tool_ctx(db, None, conv, channel="seerr")  # issue de alguém sem conta: só ferramentas sem conta
        names = {t.name for t in AGENTS["support"].registry.available(ctx)}
        assert names == {"search_knowledge", "escalate_to_human", "resolve_issue"}


async def test_support_tools_never_touch_bazarr_when_unconfigured(ana, library, svc):
    await run_tool(ana, "title_details", item_id=library["matrix"]["Id"])
    assert not [c for c in svc.mock.calls if c.request.url.host == BAZARR_HOST]
