"""Ajuda nas apps nativas do Jellyfin (Android TV, Swiftfin, Moonfin…): coleção «Ajuda» com QR para o chat."""
from __future__ import annotations

import struct
import zlib

import qrcode

from app.services import jellyfin_help


def _png_pixels(png: bytes) -> tuple[int, int, bytes]:
    assert png[:8] == b"\x89PNG\r\n\x1a\n"
    pos, idat, w, h = 8, b"", 0, 0
    while pos < len(png):
        (n,), kind = struct.unpack(">I", png[pos:pos + 4]), png[pos + 4:pos + 8]
        data = png[pos + 8:pos + 8 + n]
        assert zlib.crc32(kind + data) & 0xFFFFFFFF == struct.unpack(">I", png[pos + 8 + n:pos + 12 + n])[0]
        if kind == b"IHDR":
            w, h, depth, color = struct.unpack(">IIBB", data[:10])
            assert (depth, color) == (8, 2)
        elif kind == b"IDAT":
            idat += data
        pos += 12 + n
    raw = zlib.decompress(idat)
    stride = w * 3 + 1
    assert len(raw) == stride * h and all(raw[y * stride] == 0 for y in range(h))
    return w, h, b"".join(raw[y * stride + 1:(y + 1) * stride] for y in range(h))


def test_poster_has_scannable_qr_for_the_help_page():
    w, h, px = _png_pixels(jellyfin_help.poster_png())
    assert (w, h) == (600, 900)
    # O QR desenhado bate certo com a matriz do qrcode para {public_url}/ajuda, módulo a módulo.
    q = qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_M, border=0)
    q.add_data("https://portal.test/ajuda")
    q.make(fit=True)
    matrix = q.get_matrix()
    n = len(matrix)
    mod = 380 // (n + 8)
    off = (380 - n * mod) // 2
    for r in range(n):
        for c in range(n):
            x, y = 110 + off + c * mod + mod // 2, 282 + off + r * mod + mod // 2
            dark = px[(y * w + x) * 3] == 0
            assert dark == matrix[r][c], (r, c)
    bw, bh, _ = _png_pixels(jellyfin_help.backdrop_png())
    assert (bw, bh) == (1280, 720)


def test_overview_includes_short_link_and_whatsapp(settings):
    assert "portal.test/ajuda" in jellyfin_help.overview()
    assert "WhatsApp" not in jellyfin_help.overview()
    settings.set("whatsapp_number", "+351 912 345 678")
    assert "+351 912 345 678" in jellyfin_help.overview() and "wa.me/351912345678" in jellyfin_help.overview()


async def test_admin_creates_then_updates_the_help_collection(admin_client, svc, settings):
    svc.jf.add_user("root", admin=True)
    st = (await admin_client.get("/api/admin/jellyfin/help")).json()
    assert st["id"] is None and st["jellyfin_ready"] and st["help_url"] == "https://portal.test/ajuda"

    r = await admin_client.post("/api/admin/jellyfin/help")
    assert r.status_code == 200, r.text
    out = r.json()
    assert out["created"] is True and out["item_url"] == f"https://tv.test/web/#/details?id={out['id']}"
    item = svc.jf.items[out["id"]]
    assert item["Type"] == "BoxSet" and item["Name"] == "Ajuda" and jellyfin_help.TAG in item["Tags"]
    assert "portal.test/ajuda" in item["Overview"] and item["LockData"] is True
    for kind in ("Primary", "Backdrop", "Thumb"):
        assert svc.jf.images[(out["id"], kind)][:8] == b"\x89PNG\r\n\x1a\n"

    # Segunda vez: atualiza a mesma coleção (não cria outra), com o endereço novo do portal.
    settings.set("public_url", "https://novo.test")
    st = (await admin_client.get("/api/admin/jellyfin/help")).json()
    assert st["id"] == out["id"] and st["stale"] is True
    again = (await admin_client.post("/api/admin/jellyfin/help")).json()
    assert again == {**again, "id": out["id"], "created": False}
    assert sum(1 for it in svc.jf.items.values() if it["Type"] == "BoxSet") == 1
    assert "novo.test/ajuda" in svc.jf.items[out["id"]]["Overview"]
    assert (await admin_client.get("/api/admin/jellyfin/help")).json()["stale"] is False


async def test_help_collection_requires_admin_and_jellyfin(client, admin_client, settings):
    assert (await client.post("/api/admin/jellyfin/help")).status_code in (401, 403)
    img = await admin_client.get("/api/admin/jellyfin/help/poster.png")
    assert img.status_code == 200 and img.headers["content-type"] == "image/png"
    assert (await admin_client.get("/api/admin/jellyfin/help/other.png")).status_code == 404
    settings.set("jellyfin_api_key", None)
    r = await admin_client.post("/api/admin/jellyfin/help")
    assert r.status_code == 502 and "Jellyfin" in r.json()["detail"]
