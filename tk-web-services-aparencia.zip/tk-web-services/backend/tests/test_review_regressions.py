"""Regressões da revisão de segurança (corridas em mudanças de plano/ações confirmadas, confirmações por texto)."""
from __future__ import annotations

import asyncio

import pytest
from asst import confirm_action
from conftest import fetch, get, plan_by_code
from test_assistant_billing import paying, propose  # noqa: F401 — fixture
from test_billing_subscribe import _monthly_customer, pending

from app.assistant.models import PendingAction
from app.assistant.runtime import NO, YES
from app.assistant.tools import ToolFailure
from app.models import InvoiceLine

from conftest import IS_PG  # noqa: E402


@pytest.mark.skipif(not IS_PG, reason="bloqueios de linha só em PostgreSQL")
async def test_concurrent_downgrade_applies_credit_once(make_client, svc, clock):
    u, c, sub = await _monthly_customer(make_client, svc, clock, plan="tkflix-tv-mensal")
    mensal = await plan_by_code("tkflix-mensal")
    rs = await asyncio.gather(*[c.post(f"/api/billing/subscriptions/{sub.id}/change", json={"plan_id": mensal.id})
                               for _ in range(3)])
    assert sorted(r.status_code for r in rs) == [200, 400, 400]
    kinds = [ln.kind for ln in await pending(u.id)]
    assert kinds.count("credit") == 1 and kinds.count("proration") == 1


async def test_confirmed_action_runs_once(paying):  # noqa: F811
    tv = await plan_by_code("tkflix-tv-mensal")
    _, action_id, _ = await propose(paying, "change_or_subscribe_plan", plan_id=tv.id)
    if IS_PG:
        res = await asyncio.gather(confirm_action(paying, action_id), confirm_action(paying, action_id),
                                   return_exceptions=True)
    else:
        res = [await confirm_action(paying, action_id)]
        with pytest.raises(ToolFailure):
            await confirm_action(paying, action_id)
    assert len([r for r in res if isinstance(r, str) and "Plano alterado" in r]) == 1
    lines = await fetch(InvoiceLine)
    assert len([ln for ln in lines if ln.kind == "credit"]) == 1
    assert (await get(PendingAction, action_id)).status == "done"


def test_text_confirmation_is_strict():
    for ok in ("sim", "SIM", "Sim!", "confirmo"):
        assert YES.match(ok)
    for bad in ("ok", "s", "yes", "pode ser", "sim, mas quanto custa?", "claro"):
        assert not YES.match(bad)
    assert NO.match("não") and NO.match("cancela")
