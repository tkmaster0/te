"""Assistentes: encaminhamento, separação entre agentes, ferramentas, confirmações e falhas do modelo."""
from __future__ import annotations

import json

from conftest import add_method, add_sub, create_user, fetch, get, make_product, update_row

from fakes import call

from app.assistant.llm import LLMError, LLMResponse
from app.assistant.models import AssistantConversation, AssistantMessage, PendingAction
from app.models import Subscription, SubStatus


async def chat(client, message, conversation_id=None, expect=200):
    r = await client.post("/api/assistant/chat", json={"message": message, "conversation_id": conversation_id})
    assert r.status_code == expect, r.text
    return r.json()


async def test_disabled_returns_503(client):
    u = await create_user("ana")
    await client.login_as(u)
    await chat(client, "olá", expect=503)
    r = await client.get("/api/assistant/status")
    assert r.json()["enabled"] is False


async def test_billing_question_uses_billing_agent_and_tools(client, llm, svc):
    u = await create_user("ana")
    await add_method(svc, u)
    await add_sub(u)
    await client.login_as(u)
    llm.script = [call("get_billing_overview"), LLMResponse("A tua próxima cobrança é de 5,00 €.")]
    out = await chat(client, "Quanto vou pagar na próxima cobrança?")
    assert out["agent"] == "billing"
    assert out["messages"][-1]["content"] == "A tua próxima cobrança é de 5,00 €."
    agent_calls = llm.agent_calls()
    # O modelo de faturação só recebeu ferramentas de faturação.
    assert "get_billing_overview" in agent_calls[0]["tools"]
    assert not {"find_title", "sync_subtitles", "search_subtitles"} & set(agent_calls[0]["tools"])
    assert "Agente de Faturação" in agent_calls[0]["messages"][0]["content"]
    # O resultado da ferramenta foi passado ao modelo na 2.ª volta.
    tool_msgs = [m for m in agent_calls[1]["messages"] if m["role"] == "tool"]
    assert tool_msgs and "subscriptions" in tool_msgs[0]["content"]


async def test_agent_cannot_call_other_agents_tools(client, llm, svc):
    u = await create_user("ana")
    await client.login_as(u)
    llm.script = [call("sync_subtitles", item_id="x"), LLMResponse("Não posso ajudar com isso aqui.")]
    out = await chat(client, "Quero mudar de plano e pagar com cartão")
    assert out["agent"] == "billing"
    tool_rows = [m for m in await fetch(AssistantMessage, role="tool")]
    assert tool_rows[0].content.startswith("Erro: ferramenta inexistente")
    assert not svc.jf.find("POST", r"/Items/")


async def test_transfer_passes_only_request_and_summary(client, llm, svc):
    u = await create_user("ana")
    await add_method(svc, u)
    await add_sub(u)
    await client.login_as(u)
    llm.script = [
        call("get_billing_overview"),  # a faturação consulta dados financeiros
        call("transfer_to_support", summary="Legendas fora de tempo no filme X"),
        LLMResponse("Vou ajudar-te com as legendas!"),
    ]
    out = await chat(client, "Paguei a fatura e o pagamento está ok, mas as legendas estão estranhas")
    assert out["agent"] == "support"
    assert [m["role"] for m in out["messages"]][-2:] == ["event", "assistant"]
    support_call = llm.agent_calls()[-1]
    assert "transfer_to_billing" in support_call["tools"] and "get_billing_overview" not in support_call["tools"]
    blob = json.dumps(support_call["messages"][1:], ensure_ascii=False)
    assert "Legendas fora de tempo" in blob
    assert "payment_methods" not in blob and "next_charge" not in blob  # nada do que a faturação consultou
    conv = (await fetch(AssistantConversation))[0]
    assert conv.agent == "support"
    # A nota interna não aparece ao cliente.
    r = await client.get(f"/api/assistant/conversations/{conv.id}")
    assert "Nota interna" not in r.text


async def test_sensitive_action_requires_confirmation(client, llm, svc):
    u = await create_user("ana")
    await add_method(svc, u)
    sub = await add_sub(u, current_period_end=None)
    from app.db import utcnow
    from datetime import timedelta
    await update_row(Subscription, sub.id, current_period_end=utcnow() + timedelta(days=20),
                     current_period_start=utcnow() - timedelta(days=10))
    await client.login_as(u)
    llm.script = [call("cancel_subscription", subscription_id=sub.id),
                  LLMResponse("Preparei o cancelamento — carrega em Confirmar.")]
    out = await chat(client, "quero cancelar a minha subscrição")
    confirm = next(m for m in out["messages"] if (m.get("ui") or {}).get("type") == "confirm")
    assert "Cancelar" in confirm["content"]
    assert (await get(Subscription, sub.id)).status == SubStatus.active  # nada feito ainda
    action_id = confirm["ui"]["action_id"]

    other = await create_user("intruso")
    from conftest import BASE_URL, CSRF  # noqa: F401
    r = await client.post(f"/api/assistant/actions/{action_id}", json={"confirm": True})
    assert r.status_code == 200, r.text
    assert "Cancelado" in r.json()["message"]["content"]
    assert (await get(Subscription, sub.id)).status == SubStatus.canceling
    # Não executa duas vezes.
    r = await client.post(f"/api/assistant/actions/{action_id}", json={"confirm": True})
    assert r.status_code == 400
    assert other.id != u.id


async def test_confirmation_by_text_and_other_user_cannot_confirm(make_client, llm, svc):
    u = await create_user("ana")
    await add_method(svc, u)
    from app.db import utcnow
    from datetime import timedelta
    sub = await add_sub(u, current_period_start=utcnow() - timedelta(days=3),
                        current_period_end=utcnow() + timedelta(days=27))
    c = make_client()
    await c.login_as(u)
    llm.script = [call("cancel_subscription", subscription_id=sub.id), LLMResponse("Confirma, por favor.")]
    out = await chat(c, "cancela o meu streaming")
    action = (await fetch(PendingAction))[0]
    intruder = make_client()
    await intruder.login_as(await create_user("intruso"))
    r = await intruder.post(f"/api/assistant/actions/{action.id}", json={"confirm": True})
    assert r.status_code == 404
    out = await chat(c, "não", out["conversation_id"])
    assert out["messages"][-1]["content"].startswith("Ok, não fiz nada")
    assert (await get(Subscription, sub.id)).status == SubStatus.active


async def test_streaming_scope_limits_billing_catalog(make_client, llm, svc):
    await make_product("cloud", plans=[("cloud-m", 300, "month")])
    u = await create_user("ana")
    c = make_client()
    await c.login_as(u, scope="streaming")
    llm.script = [call("get_catalog"), LLMResponse("Estes são os planos.")]
    await chat(c, "que planos há e quanto custam?")
    tool_msg = (await fetch(AssistantMessage, role="tool"))[0]
    assert "Cloud" not in tool_msg.content and "TKFLIX" in tool_msg.content


async def test_llm_failure_returns_friendly_message(client, llm):
    u = await create_user("ana")
    await client.login_as(u)
    llm.script = [LLMError("timeout")]
    out = await chat(client, "as legendas não aparecem no episódio")
    assert "indisponível" in out["messages"][-1]["content"]
    assert (await fetch(AssistantMessage, role="user"))  # a mensagem do cliente ficou gravada


async def test_escalation_marks_conversation(client, llm, settings):
    settings.set("admin_notify_email", "admin@example.com")
    u = await create_user("ana")
    await client.login_as(u)
    llm.script = [call("escalate_to_human", summary="Cliente pede reembolso"), LLMResponse("Passei a um humano.")]
    await chat(client, "quero um reembolso do mês passado")
    conv = (await fetch(AssistantConversation))[0]
    assert conv.status == "escalated"
    from conftest import emails
    assert await emails("admin_notice", "admin@example.com")


async def test_conversations_are_private(make_client, llm):
    a, b = await create_user("ana"), await create_user("bia")
    ca, cb = make_client(), make_client()
    await ca.login_as(a)
    await cb.login_as(b)
    out = await chat(ca, "olá, tenho um problema com o som")
    r = await cb.get(f"/api/assistant/conversations/{out['conversation_id']}")
    assert r.status_code == 404
    # Continuar a conversa de outra pessoa cria uma nova.
    out_b = await chat(cb, "olá", out["conversation_id"], expect=404)
    assert out_b


async def test_feedback_and_admin_promote(client, admin_client, llm):
    u = await create_user("ana")
    await client.login_as(u)
    llm.script = [LLMResponse("Para entrar na TV usa o Quick Connect.")]
    out = await chat(client, "como entro na app da TV sem escrever a password?")
    mid = out["messages"][-1]["id"]
    assert (await client.post(f"/api/assistant/messages/{mid}/feedback", json={"value": 1})).status_code == 200
    r = await admin_client.post(f"/api/admin/assistant/messages/{mid}/promote", json={})
    assert r.status_code == 200, r.text
    item = r.json()
    assert item["agent"] == "support" and item["status"] == "active" and "Quick Connect" in item["content"]
    # O artigo passa a ser injetado no contexto do agente certo.
    llm.script = [LLMResponse("Usa o Quick Connect.")]
    await chat(client, "não consigo entrar na televisão, como faço com a password?")
    assert "Quick Connect" in llm.agent_calls()[-1]["messages"][0]["content"]


async def test_admin_instructions_versioning(admin_client, llm, client):
    r = await admin_client.post("/api/admin/assistant/agents/billing/instructions",
                                json={"content": "Sê muito formal.", "note": "tom"})
    assert r.json()["version"] == 1
    r = await admin_client.get("/api/admin/assistant/agents")
    billing = next(a for a in r.json() if a["name"] == "billing")
    assert billing["instructions"] == "Sê muito formal." and billing["tools"]
    u = await create_user("ana")
    await client.login_as(u)
    llm.script = [LLMResponse("Com certeza.")]
    await chat(client, "quanto custa o plano anual?")
    system = llm.agent_calls()[-1]["messages"][0]["content"]
    assert "Sê muito formal." in system and "É PROIBIDO" in system  # as regras fixas ficam sempre
    await admin_client.post("/api/admin/assistant/agents/billing/instructions/reset")
    r = await admin_client.get("/api/admin/assistant/agents")
    assert "Sê muito formal." not in next(a for a in r.json() if a["name"] == "billing")["instructions"]


async def test_live_facts_include_new_products(client, llm):
    await make_product("vpn", plans=[("vpn-m", 250, "month")])
    u = await create_user("ana")
    await client.login_as(u)
    llm.script = [LLMResponse("Sim, temos VPN.")]
    await chat(client, "que serviços posso subscrever e qual o preço?")
    system = llm.agent_calls()[-1]["messages"][0]["content"]
    assert "Vpn" in system and "2,50 €" in system


async def test_rate_limit(client, llm, settings):
    settings.set("assistant_rate_limit_per_hour", 2)
    u = await create_user("ana")
    await client.login_as(u)
    out = await chat(client, "olá, o filme não carrega")
    await chat(client, "continua sem carregar", out["conversation_id"])
    out = await chat(client, "e agora?", out["conversation_id"])
    assert "muitas mensagens" in out["messages"][-1]["content"]
