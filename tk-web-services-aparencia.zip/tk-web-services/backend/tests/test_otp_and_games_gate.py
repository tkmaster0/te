"""Código de confirmação (OTP) na criação da conta e jogos só para quem tem o TKFLIX desbloqueado."""
from __future__ import annotations

from conftest import create_user, dbs, emails, fetch_one
from test_auth import make_invite, register

from app.models import InviteCode, User
from app.services import wallet as wallet_svc


async def test_registration_sends_otp_and_code_confirms_email(client):
    await make_invite()
    r = await register(client, "novato")
    assert r.status_code == 200
    [mail] = await emails("verify_email")
    code = mail["ctx"]["code"]
    assert len(code) == 6 and code.isdigit() and "token=" in mail["ctx"]["cta_url"]
    from app.services.mailer import render

    subject, html, text = render("verify_email", mail["ctx"])
    assert code in subject and code in html
    bad = "000000" if code != "000000" else "111111"
    r = await client.post("/api/auth/verify-code", json={"code": bad})
    assert r.status_code == 400
    r = await client.post("/api/auth/verify-code", json={"code": code})
    assert r.status_code == 200, r.text
    assert (await client.get("/api/auth/me")).json()["email_verified"] is True
    # o mesmo código não serve duas vezes (e já está confirmado)
    assert (await client.post("/api/auth/verify-code", json={"code": code})).json()["message"].startswith("O email já")


async def test_otp_dies_after_too_many_wrong_attempts(client):
    await make_invite()
    await register(client, "novato")
    [mail] = await emails("verify_email")
    code = mail["ctx"]["code"]
    wrong = f"{(int(code) + 1) % 1_000_000:06d}"
    for _ in range(5):
        assert (await client.post("/api/auth/verify-code", json={"code": wrong})).status_code == 400
    r = await client.post("/api/auth/verify-code", json={"code": code})
    assert r.status_code == 400  # o código foi invalidado
    # pedir um novo resolve
    assert (await client.post("/api/auth/resend-verification")).status_code == 200
    new = (await emails("verify_email"))[-1]["ctx"]["code"]
    assert (await client.post("/api/auth/verify-code", json={"code": new})).status_code == 200


async def test_games_hidden_until_tkflix_unlocked(make_client, settings, admin):
    settings.set("games_enabled", True)
    u = await create_user("sem-tkflix", unlocked_products=[])
    async with dbs() as db:
        await wallet_svc.post(db, u.id, 1000, "adjustment", "saldo")
        db.add(InviteCode(code="TKFLIX-JOGOS", created_by_id=admin.id, max_uses=1, unlocks=["tkflix"]))
        await db.commit()
    c = make_client()
    await c.login_as(u)
    assert (await c.get("/api/auth/me")).json()["games_available"] is False
    assert (await c.get("/api/games")).status_code == 404
    r = await c.post("/api/games/roulette/spin", json={"bets": [{"type": "red", "amount_cents": 100}]})
    assert r.status_code == 404
    assert (await c.get("/api/wallet")).json()["games_enabled"] is False
    # desbloqueia o TK CDN com um código → os jogos aparecem
    assert (await c.post("/api/billing/unlock", json={"code": "TKFLIX-JOGOS"})).status_code == 200
    assert (await c.get("/api/auth/me")).json()["games_available"] is True
    assert (await c.get("/api/games")).status_code == 200
    assert (await fetch_one(User, username="sem-tkflix")).unlocked_products == ["tkflix"]


async def test_games_visible_after_registering_with_tkflix_invite(client, settings):
    settings.set("games_enabled", True)
    boss = await create_user("amigo")  # cliente TKFLIX (desbloqueado)
    async with dbs() as db:
        db.add(InviteCode(code="DO-AMIGO-1", created_by_id=boss.id, max_uses=1))
        await db.commit()
    await register(client, "convidado", invite="DO-AMIGO-1")
    assert (await client.get("/api/auth/me")).json()["games_available"] is True
