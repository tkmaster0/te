"""Subscrever, mudar de plano, migrações de plano e mudanças de preço."""
from __future__ import annotations

import pytest
from conftest import (
    add_method,
    add_sub,
    create_user,
    customer,
    cycle,
    dbs,
    drain,
    dt,
    emails,
    fetch,
    fetch_one,
    get,
    jobs_of,
    make_product,
    plan_by_code,
    subscribe_api,
    update_row,
)
from sqlalchemy import select

from app.models import Invoice, InvoiceLine, Payment, PriceChange, Subscription, SubStatus, User
from app.services import billing, tasks


async def pending(user_id: str) -> list[InvoiceLine]:
    async with dbs() as db:
        return await billing.pending_lines(db, user_id)


async def lines_of(inv_id: str) -> list[InvoiceLine]:
    async with dbs() as db:
        return list((await db.scalars(select(InvoiceLine).where(InvoiceLine.invoice_id == inv_id)
                                      .order_by(InvoiceLine.id))).all())


# --------------------------------------------------------------------------- subscrever
async def test_fresh_customer_is_charged_immediately_by_direct_debit(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, c, pm = await customer(make_client, svc, "maria", provider="gocardless")
    q = (await c.get("/api/billing/quote", params={"plan_id": (await plan_by_code("tkflix-mensal")).id})).json()
    assert q["due_now_cents"] == 500 and q["next_invoice_cents"] == 0 and q["requires_payment_method"] is False
    out = await subscribe_api(c, "tkflix-mensal")
    assert out["status"] == "active" and "ativo" in out["message"]
    sub = await get(Subscription, out["subscription_id"])
    assert sub.status == SubStatus.active and sub.provider == "portal" and sub.price_cents == 500
    inv = await fetch_one(Invoice)
    assert inv.kind == "immediate" and inv.status == "processing" and inv.attempt_count == 1
    [charge] = svc.gc.charges()
    assert charge["amount"] == 500 and charge["links"]["mandate"] == pm.provider_ref
    assert charge["retry_if_possible"] is False and charge["idempotency_key"] == f"inv-{inv.id}-1"
    pay = await fetch_one(Payment)
    assert pay.status == "pending" and pay.invoice_id == inv.id and pay.provider_payment_id == charge["id"]
    user = await get(User, u.id)
    assert user.billing_anchor_day == 5 and user.next_billing_at == dt(2026, 11, 5, 6)
    assert not await emails("subscription_active", to=u.email)  # sem emails de confirmação (o cliente vê no portal)


async def test_existing_customer_add_on_goes_to_next_invoice(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    _, plans = await make_product("cloud")
    u, c, _ = await customer(make_client, svc, "maria")
    await subscribe_api(c, "tkflix-mensal")
    clock.set(dt(2026, 10, 20, 12))
    expected = billing.prorate(300, dt(2026, 10, 20, 12), dt(2026, 11, 5, 6), plans["cloud-m"])
    q = (await c.get("/api/billing/quote", params={"plan_id": plans["cloud-m"].id})).json()
    assert q["due_now_cents"] == 0 and q["next_invoice_cents"] == expected
    await subscribe_api(c, "cloud-m")
    [ln] = await pending(u.id)
    assert ln.kind == "proration" and ln.amount_cents == expected and ln.period_end == dt(2026, 11, 5, 6)
    assert len(await fetch(Invoice)) == 1 and len(svc.stripe.charges()) == 1
    summary = (await c.get("/api/billing/summary")).json()
    assert summary["upcoming"]["total_cents"] == 500 + 300 + expected


async def test_proration_charge_immediate(make_client, svc, clock, settings):
    settings.set("proration_charge", "immediate")
    clock.set(dt(2026, 10, 5, 12))
    _, plans = await make_product("cloud")
    u, c, _ = await customer(make_client, svc, "maria")
    await subscribe_api(c, "tkflix-mensal")
    clock.set(dt(2026, 10, 20, 12))
    expected = billing.prorate(300, dt(2026, 10, 20, 12), dt(2026, 11, 5, 6), plans["cloud-m"])
    await subscribe_api(c, "cloud-m")
    assert await pending(u.id) == []
    invs = sorted(await fetch(Invoice), key=lambda i: i.number)
    assert invs[1].kind == "immediate" and invs[1].total_cents == expected and invs[1].status == "paid"
    assert [pi["amount"] for pi in svc.stripe.charges()] == [500, expected]


async def test_first_purchase_card_decline_leaves_nothing_active(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, c, pm = await customer(make_client, svc, "maria")
    svc.stripe.behavior[pm.provider_ref] = ("card_error", "insufficient_funds")
    r = await c.post("/api/billing/subscribe", json={"plan_id": (await plan_by_code("tkflix-mensal")).id})
    assert r.status_code == 400 and "recusado" in r.json()["detail"]
    sub = await fetch_one(Subscription)
    assert sub.status == SubStatus.ended
    inv = await fetch_one(Invoice)
    assert inv.status == "void" and inv.voided_at is not None
    user = await get(User, u.id)
    assert user.next_billing_at is None and user.billing_anchor_day is None
    assert (await c.get("/api/auth/me")).json()["has_access"] is False
    assert await emails("payment_failed") == [] and await emails("subscription_active") == []
    assert (await get(type(pm), pm.id)).status == "active"  # recusa normal: o cartão continua guardado
    # sem cobrança em dívida: pode tentar de novo com outro cartão
    other = await add_method(svc, u, "stripe")
    out = await subscribe_api(c, "tkflix-mensal", payment_method_id=other.id)
    assert (await get(Subscription, out["subscription_id"])).status == SubStatus.active


@pytest.mark.parametrize("provider", ["stripe", "gocardless"])
async def test_provider_outage_defers_first_charge(make_client, svc, clock, provider):
    clock.set(dt(2026, 10, 5, 12))
    u, c, _ = await customer(make_client, svc, "maria", provider=provider)
    path = "/v1/payment_intents" if provider == "stripe" else "/payments"
    fake = svc.stripe if provider == "stripe" else svc.gc
    fake.fail_paths[path] = 503
    out = await subscribe_api(c, "tkflix-mensal")
    assert out["status"] == "active" and "processar" in out["message"]
    sub = await get(Subscription, out["subscription_id"])
    assert sub.status == SubStatus.pending
    assert (await c.get("/api/auth/me")).json()["has_access"] is False
    inv = await fetch_one(Invoice)
    assert inv.status == "open" and inv.attempt_count == 0
    [job] = await jobs_of("billing_charge", "pending")
    assert job.payload == {"invoice_id": inv.id}
    # ainda pendente: não pode subscrever outra vez
    r = await c.post("/api/billing/subscribe", json={"plan_id": (await plan_by_code("tkflix-mensal")).id})
    assert r.status_code == 400

    del fake.fail_paths[path]
    await drain()  # o job só corre daqui a 5 minutos
    assert (await get(Subscription, sub.id)).status == SubStatus.pending
    clock.advance(minutes=6)
    await drain()
    sub = await get(Subscription, sub.id)
    assert sub.status == SubStatus.active
    assert (await get(Invoice, inv.id)).status == ("paid" if provider == "stripe" else "processing")
    # a mesma chave de idempotência antes e depois da falha → nunca há cobrança dupla
    assert fake.keys_for(path) == [f"inv-{inv.id}-1"] * 2
    assert len(fake.charges()) == 1
    assert not await emails("subscription_active", to=u.email)  # sem emails de confirmação (o cliente vê no portal)
    assert (await get(User, u.id)).next_billing_at == dt(2026, 11, 5, 6)


async def test_cannot_subscribe_twice_or_with_unpaid_invoice(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    await make_product("cloud")
    u, c, _ = await customer(make_client, svc, "maria")
    await subscribe_api(c, "tkflix-mensal")
    r = await c.post("/api/billing/subscribe", json={"plan_id": (await plan_by_code("tkflix-tv-mensal")).id})
    assert r.status_code == 400 and "Mudar de plano" in r.json()["detail"]
    async with dbs() as db:
        db.add(Invoice(user_id=u.id, number="C2026-09999", status="failed", total_cents=300, subtotal_cents=300))
        await db.commit()
    r = await c.post("/api/billing/subscribe", json={"plan_id": (await plan_by_code("cloud-m")).id})
    assert r.status_code == 400 and "cobrança por pagar" in r.json()["detail"]
    assert len(await fetch(Subscription)) == 1


async def test_subscribe_requires_usable_method(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, c, _ = await customer(make_client, svc, "maria", provider=None)
    plan = await plan_by_code("tkflix-mensal")
    r = await c.post("/api/billing/subscribe", json={"plan_id": plan.id})
    assert r.status_code == 400 and "Escolhe como queres pagar" in r.json()["detail"]
    pm = await add_method(svc, u, "gocardless")
    async with dbs() as db:
        from app.payments import registry

        await registry.set_override(db, "gocardless", enabled=False)
        await db.commit()
    r = await c.post("/api/billing/subscribe", json={"plan_id": plan.id, "payment_method_id": pm.id})
    assert r.status_code == 400 and "não pode ser usado" in r.json()["detail"]
    assert await fetch(Subscription) == [] and svc.gc.charges() == []


async def test_streaming_scope_cannot_subscribe_other_products(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    _, plans = await make_product("cloud")
    u = await create_user("maria")
    await add_method(svc, u, "stripe")
    c = make_client()
    await c.login_as(u, scope="streaming")
    r = await c.post("/api/billing/subscribe", json={"plan_id": plans["cloud-m"].id})
    assert r.status_code == 403
    async with dbs() as db:
        with pytest.raises(billing.BillingError):
            await billing.subscribe(db, await db.get(User, u.id), plans["cloud-m"], scope="streaming")
    await subscribe_api(c, "tkflix-mensal")  # o streaming pode
    assert [s.product_id for s in await fetch(Subscription)] == [(await plan_by_code("tkflix-mensal")).product_id]


# --------------------------------------------------------------------------- mudar de plano
async def _monthly_customer(make_client, svc, clock, plan="tkflix-mensal", **kw):
    clock.set(dt(2026, 10, 5, 12))
    u, c, pm = await customer(make_client, svc, "maria", **kw)
    out = await subscribe_api(c, plan)
    clock.set(dt(2026, 10, 20, 12))
    return u, c, await get(Subscription, out["subscription_id"])


async def test_upgrade_quote_equals_persisted_lines(make_client, svc, clock):
    u, c, sub = await _monthly_customer(make_client, svc, clock)
    tv = await plan_by_code("tkflix-tv-mensal")
    q = (await c.get("/api/billing/quote", params={"plan_id": tv.id, "subscription_id": sub.id})).json()
    credit = round(500 * (15 * 24 + 18) / (30 * 24 + 18))
    new = round(750 * (15 * 24 + 18) / (31 * 24))
    assert [(ln["kind"], ln["amount_cents"]) for ln in q["lines"]] == [("credit", -credit), ("proration", new)]
    assert q["is_upgrade"] is True and q["next_invoice_cents"] == new - credit and q["due_now_cents"] == 0

    r = await c.post(f"/api/billing/subscriptions/{sub.id}/change", json={"plan_id": tv.id})
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["quote"]["lines"] == q["lines"] and "entra na próxima cobrança" in body["message"]
    assert [(ln.kind, ln.amount_cents) for ln in await pending(u.id)] == [("credit", -credit), ("proration", new)]
    s = await get(Subscription, sub.id)
    assert s.plan_id == tv.id and s.price_cents == 750 and s.period_amount_cents == new
    assert s.current_period_start == dt(2026, 10, 20, 12) and s.current_period_end == dt(2026, 11, 5, 6)
    assert len(await fetch(Invoice)) == 1  # nada cobrado agora

    clock.set(dt(2026, 11, 5, 6))
    inv = await cycle(u)
    assert inv.total_cents == 750 + new - credit


async def test_downgrade_gives_credit(make_client, svc, clock):
    u, c, sub = await _monthly_customer(make_client, svc, clock, plan="tkflix-tv-mensal")
    mensal = await plan_by_code("tkflix-mensal")
    r = await c.post(f"/api/billing/subscriptions/{sub.id}/change", json={"plan_id": mensal.id})
    assert r.status_code == 200
    q = r.json()["quote"]
    assert q["is_upgrade"] is False and q["next_invoice_cents"] < 0 and "crédito" in r.json()["message"]
    assert sum(ln.amount_cents for ln in await pending(u.id)) == q["next_invoice_cents"]


async def test_immediate_upgrade_charges_only_this_change(make_client, svc, clock, settings):
    u, c, sub = await _monthly_customer(make_client, svc, clock)
    tv = await plan_by_code("tkflix-tv-mensal")
    await c.post(f"/api/billing/subscriptions/{sub.id}/change", json={"plan_id": tv.id})
    earlier = [(ln.id, ln.amount_cents) for ln in await pending(u.id)]
    assert len(earlier) == 2

    settings.set("proration_charge", "immediate")
    base = await plan_by_code("tkflix-mensal")
    async with dbs() as db:
        from app.models import Plan

        premium = Plan(product_id=base.product_id, code="premium", name="Premium", price_cents=1500,
                       features=base.features)
        db.add(premium)
        await db.commit()
    clock.set(dt(2026, 10, 25, 12))
    q = (await c.get("/api/billing/quote", params={"plan_id": premium.id, "subscription_id": sub.id})).json()
    assert q["due_now_cents"] > 0
    r = await c.post(f"/api/billing/subscriptions/{sub.id}/change", json={"plan_id": premium.id})
    assert r.status_code == 200 and "Cobrámos" in r.json()["message"]
    inv = sorted(await fetch(Invoice), key=lambda i: i.number)[-1]
    assert inv.kind == "immediate" and inv.total_cents == q["due_now_cents"] and inv.status == "paid"
    assert [(ln.id, ln.amount_cents) for ln in await pending(u.id)] == earlier  # continuam para o ciclo


async def test_cannot_change_plan_when_past_due_or_to_private_plan(make_client, svc, clock):
    u, c, sub = await _monthly_customer(make_client, svc, clock)
    tv = await plan_by_code("tkflix-tv-mensal")
    await update_row(tv.__class__, tv.id, is_public=False)
    r = await c.post(f"/api/billing/subscriptions/{sub.id}/change", json={"plan_id": tv.id})
    assert r.status_code == 404
    await update_row(tv.__class__, tv.id, is_public=True)
    await update_row(Subscription, sub.id, status=SubStatus.past_due)
    r = await c.post(f"/api/billing/subscriptions/{sub.id}/change", json={"plan_id": tv.id})
    assert r.status_code == 400 and "em dia" in r.json()["detail"]
    r = await c.post(f"/api/billing/subscriptions/{sub.id}/change",
                     json={"plan_id": (await plan_by_code("tkflix-mensal")).id})
    assert r.status_code == 400
    other = await create_user("joao")
    oc = make_client()
    await oc.login_as(other)
    r = await oc.post(f"/api/billing/subscriptions/{sub.id}/change", json={"plan_id": tv.id})
    assert r.status_code == 404


async def test_change_plan_on_bonus_subscription_is_free_and_keeps_credit_rule(make_client, svc, clock, admin):
    clock.set(dt(2026, 10, 5, 12))
    u = await create_user("maria", referred_by=admin)  # convidada pelo admin → limite 2
    for name in ("ana", "bea"):
        inv_user = await create_user(name, referred_by=u)
        await add_sub(inv_user)
    await add_method(svc, u, "stripe")
    c = make_client()
    await c.login_as(u)
    q = (await c.get("/api/billing/quote", params={"plan_id": (await plan_by_code("tkflix-mensal")).id})).json()
    assert q["bonus_applies"] is True and q["due_now_cents"] == 0
    out = await subscribe_api(c, "tkflix-mensal")
    sub = await get(Subscription, out["subscription_id"])
    assert sub.status == SubStatus.bonus and sub.period_amount_cents == 0
    assert (await fetch_one(Invoice)).total_cents == 0 and svc.stripe.charges() == []
    assert not await emails("bonus_on", to=u.email)  # sem emails de confirmação (o cliente vê no portal)

    clock.set(dt(2026, 10, 20, 12))
    tv = await plan_by_code("tkflix-tv-mensal")
    r = await c.post(f"/api/billing/subscriptions/{sub.id}/change", json={"plan_id": tv.id})
    assert r.status_code == 200
    q = r.json()["quote"]
    assert q["bonus_applies"] is True and q["due_now_cents"] == 0 and q["next_invoice_cents"] == 0
    assert (await get(Subscription, sub.id)).period_amount_cents == 0
    clock.set(dt(2026, 11, 5, 6))
    inv = await cycle(u)
    assert inv.total_cents == 0 and inv.status == "paid"
    assert svc.stripe.charges() == []


# --------------------------------------------------------------------------- migração de planos (admin)
@pytest.mark.parametrize("keep_price,expected", [(True, 500), (False, 750)])
async def test_plan_migration_at_renewal(make_client, svc, clock, admin_client, keep_price, expected):
    clock.set(dt(2026, 10, 5, 12))
    u, c, _ = await customer(make_client, svc, "maria")
    out = await subscribe_api(c, "tkflix-mensal")
    src, dst = await plan_by_code("tkflix-mensal"), await plan_by_code("tkflix-tv-mensal")
    body = {"from_plan_id": src.id, "to_plan_id": dst.id, "when": "renewal", "keep_price": keep_price}
    r = await admin_client.post("/api/admin/migrations/plan", json={**body, "dry_run": True})
    assert r.json()["affected"] == 1 and (await get(Subscription, out["subscription_id"])).pending_plan_id is None
    r = await admin_client.post("/api/admin/migrations/plan", json=body)
    assert r.json() == {"affected": 1, "errors": []}
    sub = await get(Subscription, out["subscription_id"])
    assert sub.pending_plan_id == dst.id and sub.meta["pending_price_cents"] == expected
    [mail] = await emails("plan_migration", to=u.email)
    assert mail["ctx"]["new_plan"] == dst.name
    subs = (await c.get("/api/billing/subscriptions")).json()
    assert subs[0]["pending_plan"] == dst.name
    upcoming = (await c.get("/api/billing/summary")).json()["upcoming"]
    assert upcoming["lines"][0]["amount_cents"] == expected and dst.name in upcoming["lines"][0]["description"]

    clock.set(dt(2026, 11, 5, 6))
    inv = await cycle(u)
    assert inv.total_cents == expected
    sub = await get(Subscription, sub.id)
    assert sub.plan_id == dst.id and sub.price_cents == expected and sub.pending_plan_id is None
    assert "pending_price_cents" not in (sub.meta or {})


async def test_plan_migration_now_never_charges_inside_the_request(make_client, svc, clock, admin_client, settings):
    settings.set("proration_charge", "immediate")
    clock.set(dt(2026, 10, 5, 12))
    u, c, _ = await customer(make_client, svc, "maria")
    await subscribe_api(c, "tkflix-mensal")
    clock.set(dt(2026, 10, 20, 12))
    src, dst = await plan_by_code("tkflix-mensal"), await plan_by_code("tkflix-tv-mensal")
    r = await admin_client.post("/api/admin/migrations/plan", json={"from_plan_id": src.id, "to_plan_id": dst.id,
                                                                    "when": "now"})
    assert r.status_code == 200 and r.json()["affected"] == 1, r.text
    assert (await fetch_one(Subscription)).plan_id == dst.id
    assert len(await fetch(Invoice)) == 1 and len(svc.stripe.charges()) == 1
    assert sum(ln.amount_cents for ln in await pending(u.id)) > 0
    r = await admin_client.post("/api/admin/migrations/plan", json={"from_plan_id": src.id, "to_plan_id": dst.id,
                                                                    "when": "now", "keep_price": True})
    assert r.status_code == 400


# --------------------------------------------------------------------------- mudanças de preço
async def _two_subscribers(make_client, svc, clock, admin_client):
    clock.set(dt(2026, 10, 5, 12))
    a, ca, _ = await customer(make_client, svc, "ana")
    sa = (await subscribe_api(ca, "tkflix-mensal"))["subscription_id"]
    b, cb, _ = await customer(make_client, svc, "bea")
    sb = (await subscribe_api(cb, "tkflix-mensal"))["subscription_id"]
    r = await admin_client.patch(f"/api/admin/subscriptions/{sb}", json={"price_cents": 450})
    assert r.status_code == 200
    clock.set(dt(2026, 10, 10, 12))
    return (a, ca, sa), (b, cb, sb)


async def test_price_change_new_only_keeps_existing_prices(make_client, svc, clock, admin_client):
    (a, _, _), _ = await _two_subscribers(make_client, svc, clock, admin_client)
    plan = await plan_by_code("tkflix-mensal")
    r = await admin_client.post(f"/api/admin/plans/{plan.id}/price-change",
                                json={"new_price_cents": 600, "apply_to": "new_only"})
    assert r.status_code == 200
    assert (await plan_by_code("tkflix-mensal")).price_cents == 600 and await fetch(PriceChange) == []
    n, cn, _ = await customer(make_client, svc, "novo")
    await subscribe_api(cn, "tkflix-mensal")
    # a da Bea foi emitida antes do PATCH para 450 → 500; o novo cliente já paga 600
    assert sorted(i.total_cents for i in await fetch(Invoice)) == [500, 500, 600]
    clock.set(dt(2026, 11, 5, 6))
    assert (await cycle(a)).total_cents == 500
    r = await admin_client.post(f"/api/admin/plans/{plan.id}/price-change",
                                json={"new_price_cents": 600, "apply_to": "new_only"})
    assert r.status_code == 400


async def test_price_change_for_existing_applies_at_first_renewal_after_effective(make_client, svc, clock,
                                                                                admin_client):
    (a, ca, sa), (b, _, sb) = await _two_subscribers(make_client, svc, clock, admin_client)
    plan = await plan_by_code("tkflix-mensal")
    r = await admin_client.post(f"/api/admin/plans/{plan.id}/price-change", json={
        "new_price_cents": 600, "apply_to": "existing", "effective_at": "2026-11-20T00:00:00", "note": "Mais canais"})
    assert r.status_code == 200, r.text
    assert "1 subscritores" in r.json()["message"]  # a Bea tem outro preço fixado
    pc = await fetch_one(PriceChange)
    assert pc.old_price_cents == 500 and pc.effective_at == dt(2026, 11, 20, 0)

    async with dbs() as db:
        assert await tasks.send_price_notices(db) == 1
        assert await tasks.send_price_notices(db) == 0  # uma vez só
    [mail] = await emails("price_change")
    assert mail["to"] == a.email and mail["ctx"]["new_price"] == "6,00 €" and mail["ctx"]["note"] == "Mais canais"
    subs = (await ca.get("/api/billing/subscriptions")).json()
    assert subs[0]["upcoming_price_change"]["new_price_cents"] == 600

    clock.set(dt(2026, 11, 5, 6))
    assert (await cycle(a)).total_cents == 500   # antes da data: preço antigo
    assert (await cycle(b)).total_cents == 450
    clock.set(dt(2026, 11, 25))
    assert (await ca.get("/api/billing/summary")).json()["upcoming"]["total_cents"] == 600
    clock.set(dt(2026, 12, 5, 6))
    assert (await cycle(a)).total_cents == 600   # primeira renovação a partir da data
    assert (await cycle(b)).total_cents == 450   # preço fixado diferente: não muda
    assert (await get(Subscription, sa)).price_cents == 600


async def test_price_increase_requires_notice_and_decrease_does_not(make_client, svc, clock, admin_client):
    await _two_subscribers(make_client, svc, clock, admin_client)
    plan = await plan_by_code("tkflix-mensal")
    r = await admin_client.post(f"/api/admin/plans/{plan.id}/price-change", json={
        "new_price_cents": 700, "apply_to": "existing", "effective_at": "2026-10-20T00:00:00Z"})
    assert r.status_code == 400 and "30" in r.json()["detail"]
    assert (await plan_by_code("tkflix-mensal")).price_cents == 500 and await fetch(PriceChange) == []
    r = await admin_client.post(f"/api/admin/plans/{plan.id}/price-change", json={
        "new_price_cents": 400, "apply_to": "existing", "effective_at": "2026-10-11T00:00:00Z"})
    assert r.status_code == 200
    r = await admin_client.post(f"/api/admin/plans/{plan.id}/price-change", json={
        "new_price_cents": 450, "apply_to": "existing"})  # sem data → aviso mínimo
    assert r.status_code == 200
    latest = max(await fetch(PriceChange), key=lambda p: p.id)
    assert latest.effective_at >= dt(2026, 11, 9)


async def test_cancel_price_change_before_effective(make_client, svc, clock, admin_client):
    (a, _, sa), _ = await _two_subscribers(make_client, svc, clock, admin_client)
    plan = await plan_by_code("tkflix-mensal")
    await admin_client.post(f"/api/admin/plans/{plan.id}/price-change", json={
        "new_price_cents": 600, "apply_to": "existing", "effective_at": "2026-11-20T00:00:00Z"})
    pc = await fetch_one(PriceChange)
    r = await admin_client.delete(f"/api/admin/price-changes/{pc.id}")
    assert r.status_code == 200
    assert (await admin_client.delete(f"/api/admin/price-changes/{pc.id}")).status_code == 404
    async with dbs() as db:
        assert await tasks.send_price_notices(db) == 0
    clock.set(dt(2026, 12, 5, 6))
    await cycle(a)
    clock.set(dt(2027, 1, 5, 6))
    assert (await cycle(a)).total_cents == 500
    # depois de entrar em vigor já não se cancela
    await admin_client.post(f"/api/admin/plans/{plan.id}/price-change", json={
        "new_price_cents": 550, "apply_to": "existing", "effective_at": "2027-02-10T00:00:00Z"})
    pc2 = max(await fetch(PriceChange), key=lambda p: p.id)
    await update_row(PriceChange, pc2.id, effective_at=dt(2027, 1, 1))
    assert (await admin_client.delete(f"/api/admin/price-changes/{pc2.id}")).status_code == 400
