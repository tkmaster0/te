"""Convites, conta, catálogo, emails, segurança e direitos (features)."""
from __future__ import annotations

import pyotp
import pytest
from conftest import PASSWORD, add_sub, create_user, dbs, drain, emails, fetch, jobs_of, plan_by_code, update_row

from app.features import IptvFeature, JellyfinFeature, PlanFeatures, SeerrFeature, feature_flags, merge_features
from app.models import InviteCode, Plan
from app.security import (
    decrypt,
    encrypt,
    hash_recovery_code,
    new_invite_code,
    new_recovery_codes,
    password_problems,
    verify_password,
    verify_totp,
)
from app.services import mailer


# --------------------------------------------------------------------------- convites
async def test_invites_require_active_subscription_and_limit(client, settings):
    u = await create_user("maria")
    await client.login_as(u)
    info = (await client.get("/api/invites")).json()
    assert info["can_create"] is False and "subscrição ativa" in info["reason"]
    r = await client.post("/api/invites", json={"note": "Para a Ana"})
    assert r.status_code == 400
    await add_sub(u)
    for _ in range(5):
        r = await client.post("/api/invites", json={})
        assert r.status_code == 200
    out = r.json()
    assert out["code"].startswith("TK-") and out["link"] == f"https://portal.test/registar?convite={out['code']}"
    r = await client.post("/api/invites", json={})
    assert r.status_code == 400 and "máximo 5" in r.json()["detail"]
    # desativar um liberta espaço
    r = await client.delete(f"/api/invites/{out['id']}")
    assert r.status_code == 200
    assert (await client.post("/api/invites", json={})).status_code == 200
    # não é possível desativar convites de outro utilizador
    other = await create_user("joao")
    async with dbs() as db:
        inv = InviteCode(code="TK-OUTRO-0001", created_by_id=other.id)
        db.add(inv)
        await db.commit()
    assert (await client.delete(f"/api/invites/{inv.id}")).status_code == 404


async def test_invite_email_and_invitee_listing(client):
    u = await create_user("maria", display_name="Maria")
    await add_sub(u)
    await client.login_as(u)
    inv = (await client.post("/api/invites", json={})).json()
    r = await client.post(f"/api/invites/{inv['id']}/email", json={"email": "Amiga@Example.com"})
    assert r.status_code == 200
    [mail] = await emails("invite")
    assert mail["to"] == "amiga@example.com" and mail["ctx"]["inviter"] == "Maria" and mail["ctx"]["code"] == inv["code"]
    a = await create_user("ana", referred_by=u)
    await add_sub(a, status="past_due")
    await create_user("rui", referred_by=u)
    b = await create_user("bia", referred_by=u)
    await add_sub(b)
    rows = {r["username"]: r for r in (await client.get("/api/invites")).json()["invitees"]}
    # em atraso não conta para o bónus de quem convidou (só convidados a pagar em dia)
    assert rows["ana"]["status_label"] == "Em dívida" and rows["ana"]["counts_for_bonus"] is False
    assert rows["bia"]["counts_for_bonus"] is True
    assert rows["rui"]["status"] is None and rows["rui"]["status_label"] == "Sem subscrição"


async def test_admin_can_always_create_invites(client):
    u = await create_user("adm", admin=True)
    await client.login_as(u)
    for _ in range(7):
        assert (await client.post("/api/invites", json={})).status_code == 200


async def test_expired_invite_is_invalid(client):
    from datetime import timedelta

    from app.db import utcnow
    from conftest import dbs

    async with dbs() as db:
        db.add(InviteCode(code="TK-VELHO-0001", max_uses=5, expires_at=utcnow() - timedelta(minutes=1)))
        await db.commit()
    assert (await client.get("/api/auth/invite/TK-VELHO-0001")).json() == {"valid": False}


# --------------------------------------------------------------------------- conta
async def test_profile_and_activity(client):
    u = await create_user("maria")
    await client.login("maria")
    r = await client.patch("/api/account/profile", json={"display_name": "  Maria Silva ", "locale": "en"})
    assert r.status_code == 200 and r.json()["display_name"] == "Maria Silva"
    r = await client.patch("/api/account/profile", json={"display_name": ""})
    assert r.json()["display_name"] is None
    await client.login("maria", "errada-000")
    acts = (await client.get("/api/account/activity")).json()
    actions = [a["action"] for a in acts]
    assert "auth.login" in actions and "auth.login_failed" in actions
    assert all(a["details"] is None for a in acts)
    assert u.id


# --------------------------------------------------------------------------- catálogo
async def test_catalog(client):
    # Sem convite, o TKFLIX (beta fechado) aparece como "TK CDN", sem planos nem preços.
    [locked] = (await client.get("/api/catalog")).json()
    assert locked["locked"] is True and locked["name"] == "TK CDN" and locked["plans"] == []
    assert "tkflix" not in str(locked).lower()
    boss = await create_user("chefe")
    async with dbs() as db:
        db.add(InviteCode(code="VERCATALOGO", created_by_id=boss.id, max_uses=1))
        await db.commit()
    r = await client.get("/api/catalog?convite=vercatalogo")
    [product] = r.json()
    assert product["code"] == "tkflix" and len(product["plans"]) == 4
    mensal = next(p for p in product["plans"] if p["code"] == "tkflix-mensal")
    # os métodos de pagamento são por cliente (não por plano): todos os fornecedores que aceitam novos clientes
    assert mensal["providers"] == ["gocardless", "stripe"] and mensal["price_cents"] == 500
    assert mensal["features"]["jellyfin"]["max_streams"] == 2
    await update_row(Plan, (await plan_by_code("tkflix-anual")).id, is_active=False)
    async with dbs() as db:
        from app.payments import registry

        await registry.set_override(db, "stripe", accept_new=False)
        await db.commit()
    product = (await client.get("/api/catalog?convite=VERCATALOGO")).json()[0]
    assert len(product["plans"]) == 3
    assert next(p for p in product["plans"] if p["code"] == "tkflix-mensal")["providers"] == ["gocardless"]


async def test_health_and_security_headers(client):
    r = await client.get("/api/health")
    assert r.json() == {"ok": True}
    assert r.headers["x-content-type-options"] == "nosniff"
    assert r.headers["x-frame-options"] == "DENY"
    assert r.headers["cache-control"] == "no-store"
    assert "strict-transport-security" not in r.headers  # COOKIE_SECURE=false


# --------------------------------------------------------------------------- emails
TEMPLATE_CTX = {
    "verify_email": {"username": "maria", "cta_url": "https://portal.test/v?token=x"},
    "reset_password": {"username": "maria", "cta_url": "https://portal.test/r?token=x"},
    "change_email": {"username": "maria", "cta_url": "https://portal.test/c?token=x"},
    "password_changed": {"username": "maria", "when": "01/01/2026 10:00 UTC"},
    "subscription_active": {"username": "maria", "plan": "TKFLIX", "cta_url": "https://portal.test/app"},
    "payment_failed": {"amount": "5,00 €", "plan": "TKFLIX", "grace_until": "01/01/2026", "cta_url": "https://x"},
    "subscription_canceled": {"plan": "TKFLIX", "access_until": "01/01/2026", "cta_url": "https://x"},
    "subscription_ended": {"plan": "TKFLIX", "cta_url": "https://x"},
    "subscription_suspended": {"plan": "TKFLIX", "cta_url": "https://x"},
    "bonus_on": {"count": 3, "cta_url": "https://x"},
    "bonus_off": {"threshold": 3, "cta_url": "https://x"},
    "iptv_ready": {"cta_url": "https://x"},
    "invite": {"inviter": "Maria", "code": "TK-AAAA-BBBB", "cta_url": "https://x"},
    "admin_notice": {"subject": "Olá", "message": "Mensagem"},
    "payment_method_needed": {"reason": "O cartão expirou.", "grace_until": "01/01/2026", "amount": "", "plan": "",
                              "cta_url": "https://portal.test/app/faturacao"},
    "payment_received": {"amount": "5,00 €", "number": "C2026-00001", "cta_url": "https://portal.test/app/faturacao"},
    "price_change": {"plan": "TKFLIX", "effective": "01/02/2026", "old_price": "5,00 €", "new_price": "6,00 €",
                     "interval": "mês", "note": "Mais canais", "cta_url": "https://portal.test/app/servicos"},
    "plan_migration": {"old_plan": "TKFLIX", "new_plan": "TKFLIX + TV", "new_price": "7,50 €", "interval": "mês",
                       "when": "05/11/2026", "note": None, "cta_url": "https://portal.test/app/servicos"},
}


@pytest.mark.parametrize("template", sorted(mailer.TEMPLATES))
def test_every_template_renders(template):
    subject, html, text = mailer.render(template, TEMPLATE_CTX[template])
    assert subject and "<html" in html and text
    assert "{{" not in html and "{{" not in subject
    if "cta_url" in TEMPLATE_CTX[template] and mailer.TEMPLATES[template][3]:
        assert TEMPLATE_CTX[template]["cta_url"] in html


def test_email_html_is_escaped():
    _, html, _ = mailer.render("invite", {"inviter": "<script>x</script>", "code": "C", "cta_url": "https://x"})
    assert "<script>x</script>" not in html and "&lt;script&gt;" in html


async def test_email_job_sends_via_smtp(settings, monkeypatch):
    sent = []

    async def fake_send(msg, **kw):
        sent.append((msg, kw))

    monkeypatch.setattr(mailer.aiosmtplib, "send", fake_send)
    settings.set("smtp_host", "smtp.test")
    settings.set("smtp_port", 587)
    settings.set("smtp_tls_mode", "starttls")
    from conftest import dbs

    async with dbs() as db:
        await mailer.queue_email(db, "maria@example.com", "verify_email", username="maria",
                                 cta_url="https://portal.test/verificar-email?token=abc")
        await db.commit()
    await drain()
    [(msg, kw)] = sent
    assert msg["To"] == "maria@example.com" and msg["Subject"] == "Confirma o teu email"
    assert kw["hostname"] == "smtp.test" and kw["start_tls"] is True and kw["use_tls"] is False
    body = msg.get_body(("plain",)).get_content()
    assert "https://portal.test/verificar-email?token=abc" in body


async def test_email_smtp_failure_is_retried(settings, monkeypatch):
    import aiosmtplib

    async def failing(msg, **kw):
        raise aiosmtplib.SMTPConnectError("sem ligação")

    monkeypatch.setattr(mailer.aiosmtplib, "send", failing)
    settings.set("smtp_host", "smtp.test")
    from conftest import dbs

    async with dbs() as db:
        await mailer.queue_email(db, "x@example.com", "iptv_ready", cta_url="https://x")
        await db.commit()
    await drain()
    [job] = await jobs_of("send_email")
    assert job.status == "pending" and "SMTP" in job.last_error


# --------------------------------------------------------------------------- segurança
def test_encrypt_roundtrip_and_tamper():
    token = encrypt("olá mundo")
    assert token != "olá mundo" and decrypt(token) == "olá mundo"
    assert decrypt(token[:-4] + "AAAA") is None
    assert decrypt(None) is None and decrypt("") is None


def test_password_rules():
    assert password_problems("curta") == ["A password tem de ter pelo menos 8 caracteres."]
    assert password_problems("maria12345", username="maria")
    assert password_problems("joaquim-2026x", email="joaquim@example.com")
    assert password_problems("abc-2026-xyz", email="abc@example.com") == []  # parte local < 4 chars
    assert password_problems("Boa-Pass-2026", username="maria", email="maria@example.com") == []


def test_verify_password_unknown_format():
    assert verify_password("md5$abc$def", "x") == (False, False)
    assert verify_password("pbkdf2:sha256:1000$semhash", "x") == (False, False)
    assert verify_password("$argon2id$v=19$m=65536,t=3,p=4$lixo", "x") == (False, False)


def test_totp_and_recovery_codes():
    secret = pyotp.random_base32()
    totp = pyotp.TOTP(secret)
    assert verify_totp(secret, totp.now())
    assert verify_totp(secret, " ".join([totp.now()[:3], totp.now()[3:]]))
    assert not verify_totp(secret, "12345") and not verify_totp(secret, "abcdef")
    import time

    assert verify_totp(secret, totp.at(time.time() - 30))  # janela de ±1
    assert not verify_totp(secret, totp.at(time.time() - 120))
    codes = new_recovery_codes()
    assert len(set(codes)) == 10 and all(len(c) == 11 and c[5] == "-" for c in codes)
    assert hash_recovery_code(codes[0].upper() + " ") == hash_recovery_code(codes[0])


def test_invite_code_format():
    code = new_invite_code()
    assert code.startswith("TK-") and len(code) == 12 and "O" not in code[3:] and "I" not in code[3:]


# --------------------------------------------------------------------------- features
def test_merge_features():
    a = PlanFeatures(jellyfin=JellyfinFeature(enabled=True, all_libraries=False, libraries=["a"], max_streams=2),
                     seerr=SeerrFeature(enabled=True, movie_quota=5, movie_quota_days=7), groups=["x"])
    b = PlanFeatures(jellyfin=JellyfinFeature(enabled=True, all_libraries=False, libraries=["b"], max_streams=3,
                                              live_tv=True),
                     seerr=SeerrFeature(enabled=True, movie_quota=10, movie_quota_days=7),
                     iptv=IptvFeature(enabled=True, stream_limit=2, channel_profiles=[3, 1]), groups=["y"])
    m = merge_features([a, b])
    assert m.jellyfin.libraries == ["a", "b"] and not m.jellyfin.all_libraries
    assert m.jellyfin.max_streams == 3 and m.jellyfin.live_tv
    assert m.seerr.movie_quota == 10 and m.seerr.tv_quota is None
    assert m.iptv.channel_profiles == [1, 3] and m.groups == ["x", "y"]
    assert feature_flags(m) == ["jellyfin", "livetv", "seerr", "iptv"]
    unlimited = PlanFeatures(jellyfin=JellyfinFeature(enabled=True, max_streams=0))
    assert merge_features([a, unlimited]).jellyfin.max_streams == 0  # 0 = ilimitado ganha
    assert merge_features([]).jellyfin.enabled is False and feature_flags(merge_features([])) == []


async def test_combined_subscription_and_grant_features(client):
    from conftest import dbs

    from app.models import Grant

    u = await create_user("maria")
    await add_sub(u, "tkflix-mensal")
    tv = await plan_by_code("tkflix-tv-anual")
    async with dbs() as db:
        db.add(Grant(user_id=u.id, plan_id=tv.id))
        await db.commit()
    await client.login_as(u)
    me = (await client.get("/api/auth/me")).json()
    assert set(me["features"]) == {"jellyfin", "livetv", "seerr", "iptv"}
    assert {a["type"] for a in me["access"]} == {"subscription", "grant"}


def test_settings_csv_lists(monkeypatch):
    from app.config import Settings

    monkeypatch.setenv("ALLOWED_REDIRECT_HOSTS", " a.test , *.b.test ")
    monkeypatch.setenv("TRUSTED_PROXIES", '["10.0.0.0/8"]')
    s = Settings()
    assert s.allowed_redirect_hosts == ["a.test", "*.b.test"] and s.trusted_proxies == ["10.0.0.0/8"]
    monkeypatch.setenv("ALLOWED_REDIRECT_HOSTS", "")
    assert Settings().allowed_redirect_hosts == []


async def test_client_ip_from_trusted_proxy(client):
    await create_user("maria")
    await client.login("maria", headers={})
    r = await client.post("/api/auth/login", json={"login": "maria", "password": PASSWORD},
                          headers={"X-Forwarded-For": "203.0.113.9, 10.0.0.2"})
    assert r.status_code == 200
    from app.models import LoginSession

    ips = {s.ip for s in await fetch(LoginSession)}
    assert "203.0.113.9" in ips


async def test_garbage_forwarded_for_is_ignored(client):
    await create_user("maria")
    r = await client.post("/api/auth/login", json={"login": "maria", "password": PASSWORD},
                          headers={"X-Forwarded-For": "x" * 300 + ", 10.0.0.2"})
    assert r.status_code == 200
    r = await client.post("/api/auth/login", json={"login": "maria", "password": PASSWORD},
                          headers={"X-Real-IP": "<script>"})
    assert r.status_code == 200
    from app.models import LoginSession

    assert {s.ip for s in await fetch(LoginSession)} == {"127.0.0.1"}


async def test_stripe_webhook_without_secret(client, settings):
    settings.set("stripe_webhook_secret", None)
    r = await client.post("/api/webhooks/stripe", content=b"{}")
    assert r.status_code == 400
    settings.set("gocardless_webhook_secret", None)
    from conftest import post_gc_webhook

    assert (await post_gc_webhook(client, [])).status_code == 498
