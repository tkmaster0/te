"""Memória dos assistentes: cada agente lembra-se das conversas anteriores com o cliente — e só das suas."""
from __future__ import annotations

from asst import chat
from conftest import create_user, dbs, fetch

from app.assistant import memory
from app.assistant.llm import LLMResponse
from app.assistant.models import AssistantMemory


def system_of(call) -> str:
    return call["messages"][0]["content"]


async def test_new_conversation_remembers_previous_one_of_the_same_agent(client, llm):
    u = await create_user("ana")
    await client.login_as(u)
    llm.script = [LLMResponse("Experimenta desligar as legendas forçadas.")]
    await chat(client, "as legendas no jellyfin da sala estão dessincronizadas")
    # Nova conversa, mais tarde: o suporte tem o excerto da anterior
    llm.script = [LLMResponse("Na última vez falámos das legendas.")]
    await chat(client, "voltou a acontecer o problema do jellyfin")
    sysmsg = system_of(llm.agent_calls()[-1])
    assert "Memória" in sysmsg and "legendas no jellyfin da sala" in sysmsg


async def test_memory_is_separate_per_agent(client, llm):
    u = await create_user("rui")
    await client.login_as(u)
    llm.script = [LLMResponse("A tua fatura de março está paga.")]
    out = await chat(client, "quero saber da fatura e do pagamento com cartão")
    assert out["agent"] == "billing"
    llm.script = [LLMResponse("Vamos ver as legendas.")]
    out = await chat(client, "as legendas do episódio estão dessincronizadas no jellyfin")
    assert out["agent"] == "support"
    sysmsg = system_of(llm.agent_calls()[-1])
    assert "fatura de março" not in sysmsg and "pagamento com cartão" not in sysmsg  # nada da faturação


async def test_summary_job_and_forget(client, llm):
    u = await create_user("eva")
    await client.login_as(u)
    llm.script = [LLMResponse("Já está, usa a app Jellyfin na Android TV.")]
    await chat(client, "tenho uma android tv da sony e não sei que app instalar no jellyfin")
    llm.script = [LLMResponse("- Tem uma Android TV Sony\n- Usa a app Jellyfin")]
    async with dbs() as db:
        await memory.update_memory(db, {"user_id": u.id, "agent": "support"})
        await db.commit()
    [mem] = await fetch(AssistantMemory, user_id=u.id)
    assert "Android TV Sony" in mem.summary and mem.last_message_id > 0
    llm.script = [LLMResponse("Olá de novo!")]
    await chat(client, "olá, preciso de ajuda com o jellyfin outra vez")
    sysmsg = system_of(llm.agent_calls()[-1])
    assert "Android TV Sony" in sysmsg
    # o cliente vê e apaga
    notes = (await client.get("/api/assistant/memory")).json()
    assert any("Android TV Sony" in n["summary"] for n in notes)
    r = await client.delete("/api/assistant/memory")
    assert r.status_code == 200
    llm.script = [LLMResponse("Em que posso ajudar?")]
    await chat(client, "outra pergunta sobre o jellyfin")
    sysmsg = system_of(llm.agent_calls()[-1])
    assert "Android TV Sony" not in sysmsg and "android tv da sony" not in sysmsg
