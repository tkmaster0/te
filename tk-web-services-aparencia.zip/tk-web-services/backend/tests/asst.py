"""Utilitários comuns aos testes dos assistentes."""
from __future__ import annotations

import json
from datetime import timedelta

from conftest import create_user, dbs

from app.assistant import runtime
from app.assistant.agents import get_agent
from app.assistant.models import AssistantConversation, PendingAction
from app.assistant.tools import ToolContext
from app.db import utcnow
from app.models import ServiceAccount, User


async def chat(client, message, conversation_id=None, expect=200):
    r = await client.post("/api/assistant/chat", json={"message": message, "conversation_id": conversation_id})
    assert r.status_code == expect, r.text
    return r.json()


async def linked_user(svc, name: str, *, seerr_id: int | None = None, libs: list[str] | None = None, **kw):
    """Cliente do portal com utilizador no Jellyfin (e opcionalmente no Seerr). Devolve (user, jf_user)."""
    u = await create_user(name, **kw)
    policy = {"EnableAllFolders": False, "EnabledFolders": libs} if libs is not None else {}
    jf = svc.jf.add_user(name, **policy)
    async with dbs() as db:
        db.add(ServiceAccount(user_id=u.id, service="jellyfin", external_id=jf["Id"], external_username=name))
        if seerr_id is not None:
            db.add(ServiceAccount(user_id=u.id, service="seerr", external_id=str(seerr_id)))
        await db.commit()
    return u, jf


def tool_ctx(db, user, conv, *, agent="support", channel="web", scope=None, extra=None, confirmed=False):
    return ToolContext(db=db, user=user, conversation=conv, agent=agent, channel=channel, scope=scope,
                       extra=extra if extra is not None else {}, confirmed=confirmed)


async def run_tool(user: User | None, name: str, *, agent: str = "support", channel: str = "web",
                   scope: str | None = None, extra: dict | None = None, **args):
    """Executa uma ferramenta como o runtime (savepoint, ToolFailure → "Erro: ...", confirmações).

    Devolve (texto, TurnResult). O texto é o que o modelo receberia.
    """
    async with dbs() as db:
        u = await db.get(User, user.id) if user else None
        conv = AssistantConversation(user_id=u.id if u else None, channel=channel, scope=scope, agent=agent)
        db.add(conv)
        await db.flush()
        ctx = tool_ctx(db, u, conv, agent=agent, channel=channel, scope=scope, extra=extra)
        reg = get_agent(agent).registry
        available = {t.name for t in reg.available(ctx)}
        assert name in available, f"{name} não disponível para {agent}/{channel}: {sorted(available)}"
        result = runtime.TurnResult(agent=agent)
        out = await runtime._execute(ctx, reg.get(name), args, call_id="t1", result=result)
        await db.commit()
        return out, result


def as_json(text: str):
    return json.loads(text)


async def confirm_action(user: User, action_id: str, *, confirm: bool = True) -> str:
    async with dbs() as db:
        u = await db.get(User, user.id)
        action = await db.get(PendingAction, action_id)
        msg = await runtime.decide_action(db, action, u, confirm=confirm)
        return msg.content


async def expire_action(action_id: str) -> None:
    async with dbs() as db:
        a = await db.get(PendingAction, action_id)
        a.expires_at = utcnow() - timedelta(minutes=1)
        await db.commit()
