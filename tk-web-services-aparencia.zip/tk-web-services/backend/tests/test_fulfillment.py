"""Entrega de produtos que não são streaming: manual (fila do admin) e webhook assinado (HMAC-SHA256)."""
from __future__ import annotations

import hashlib
import hmac
import json

import httpx
from conftest import customer, drain, dt, emails, fetch, fetch_one, get, jobs_of, subscribe_api, update_row

from app.db import utcnow
from app.models import AuditLog, Job, Plan, Subscription, SubStatus
from app.services.fulfillment import access_details

HOOK = "https://hooks.test/tk"


async def create_product(admin_client, code: str, **body) -> int:
    r = await admin_client.post("/api/admin/products", json={"code": code, "name": code.title(), "kind": "other",
                                                             "bonus_eligible": False, **body})
    assert r.status_code == 200, r.text
    pid = r.json()["id"]
    r = await admin_client.post("/api/admin/plans", json={"product_id": pid, "code": f"{code}-m", "name": "Mensal",
                                                          "price_cents": 300})
    assert r.status_code == 200, r.text
    return pid


async def test_manual_fulfillment_queue(admin_client, make_client, svc, settings):
    settings.set("admin_notify_email", "chefe@portal.test")
    await create_product(admin_client, "cloud", fulfillment="manual", access_instructions="Entra em cloud.test")
    u, c, _ = await customer(make_client, svc, "maria")
    out = await subscribe_api(c, "cloud-m")
    sub = await get(Subscription, out["subscription_id"])
    assert sub.status == SubStatus.active and sub.fulfillment_status == "pending"
    notices = await emails("admin_notice", to="chefe@portal.test")
    assert any(n["ctx"]["subject"] == "Ativar Cloud — maria" for n in notices)
    queue = (await admin_client.get("/api/admin/fulfillment")).json()
    assert [(q["id"], q["username"], q["fulfillment_status"]) for q in queue] == [(sub.id, "maria", "pending")]

    r = await admin_client.patch(f"/api/admin/subscriptions/{sub.id}",
                                 json={"access_details": {"Utilizador": "maria", "Password": "s3gr3d0", " ": "x"}})
    assert r.status_code == 200
    sub = await get(Subscription, sub.id)
    assert sub.fulfillment_status == "done" and "s3gr3d0" not in (sub.access_details_enc or "")  # cifrado
    assert access_details(sub) == {"Utilizador": "maria", "Password": "s3gr3d0"}
    assert (await admin_client.get("/api/admin/fulfillment")).json() == []
    [mine] = (await c.get("/api/billing/subscriptions")).json()
    assert mine["access_details"] == {"Utilizador": "maria", "Password": "s3gr3d0"}
    assert mine["access_instructions"] == "Entra em cloud.test"

    # terminar → o admin tem de remover o acesso; o cliente deixa de ver os dados
    r = await admin_client.post(f"/api/admin/subscriptions/{sub.id}/cancel", json={"immediately": True})
    assert r.status_code == 200
    sub = await get(Subscription, sub.id)
    assert sub.fulfillment_status == "pending_removal"
    assert any(n["ctx"]["subject"] == "Desativar Cloud — maria" for n in await emails("admin_notice"))
    [mine] = (await c.get("/api/billing/subscriptions")).json()
    assert mine["access_details"] == {} and mine["access_instructions"] is None
    r = await admin_client.patch(f"/api/admin/subscriptions/{sub.id}", json={"fulfillment_status": "done"})
    assert (await admin_client.get("/api/admin/fulfillment")).json() == []


async def test_webhook_fulfillment_signed_and_stores_access_details(admin_client, make_client, svc):
    await create_product(admin_client, "vpn", fulfillment="webhook", webhook_url=HOOK, webhook_secret="hook-secret")
    route = svc.mock.post(HOOK).mock(return_value=httpx.Response(
        200, json={"access_details": {"Servidor": "vpn.test", "Chave": "abc123"}}))
    u, c, _ = await customer(make_client, svc, "maria")
    out = await subscribe_api(c, "vpn-m")
    assert (await get(Subscription, out["subscription_id"])).fulfillment_status == "pending"
    await drain()
    [call] = route.calls
    req = call.request
    body = req.content
    assert req.headers["x-tk-signature"] == "sha256=" + hmac.new(b"hook-secret", body, hashlib.sha256).hexdigest()
    assert req.headers["x-tk-event"] == "subscription.activated" and req.headers["content-type"] == "application/json"
    data = json.loads(body)
    assert data["event"] == "subscription.activated" and data["user"]["username"] == "maria"
    assert data["product"]["code"] == "vpn" and data["plan"]["code"] == "vpn-m"
    assert data["subscription"]["status"] == "active"
    sub = await get(Subscription, out["subscription_id"])
    assert sub.fulfillment_status == "done" and access_details(sub) == {"Servidor": "vpn.test", "Chave": "abc123"}

    # cancelar e terminar → subscription.deactivated
    route.mock(return_value=httpx.Response(204))
    await admin_client.post(f"/api/admin/subscriptions/{sub.id}/cancel", json={"immediately": True})
    await drain()
    assert json.loads(route.calls[-1].request.content)["event"] == "subscription.deactivated"
    assert route.calls[-1].request.headers["x-tk-event"] == "subscription.deactivated"
    assert (await get(Subscription, sub.id)).fulfillment_status == "done"


async def test_webhook_fulfillment_5xx_is_retried(admin_client, make_client, svc):
    await create_product(admin_client, "vpn", fulfillment="webhook", webhook_url=HOOK, webhook_secret="s")
    route = svc.mock.post(HOOK).mock(return_value=httpx.Response(503, text="em manutenção"))
    u, c, _ = await customer(make_client, svc, "maria")
    out = await subscribe_api(c, "vpn-m")
    await drain()
    [job] = await jobs_of("fulfillment_webhook")
    assert job.status == "pending" and job.attempts == 1 and "503" in job.last_error
    sub = await get(Subscription, out["subscription_id"])
    assert sub.fulfillment_status == "error"  # gravado apesar do rollback do job → aparece na fila do admin
    assert [q["id"] for q in (await admin_client.get("/api/admin/fulfillment")).json()] == [sub.id]

    route.mock(return_value=httpx.Response(200, json={}))
    await update_row(Job, job.id, run_after=utcnow())
    await drain()
    assert (await get(Job, job.id)).status == "done"
    assert (await get(Subscription, sub.id)).fulfillment_status == "done"


async def test_webhook_fulfillment_4xx_is_permanent(admin_client, make_client, svc):
    await create_product(admin_client, "vpn", fulfillment="webhook", webhook_url=HOOK, webhook_secret="s")
    route = svc.mock.post(HOOK).mock(return_value=httpx.Response(400, text="utilizador inválido"))
    u, c, _ = await customer(make_client, svc, "maria")
    out = await subscribe_api(c, "vpn-m")
    await drain()
    [job] = await jobs_of("fulfillment_webhook")
    assert job.status == "failed" and job.attempts == 1 and "utilizador inválido" in job.last_error
    assert len(route.calls) == 1
    assert (await get(Subscription, out["subscription_id"])).fulfillment_status == "error"
    assert await fetch(AuditLog, action="fulfillment.webhook_rejected")
    # o admin pode reenviar a partir da lista de jobs
    route.mock(return_value=httpx.Response(200))
    assert (await admin_client.post(f"/api/admin/jobs/{job.id}/retry")).status_code == 200
    await drain()
    assert (await get(Subscription, out["subscription_id"])).fulfillment_status == "done"


async def test_plan_change_sends_updated_event(admin_client, make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    pid = await create_product(admin_client, "vpn", fulfillment="webhook", webhook_url=HOOK, webhook_secret="s")
    await admin_client.post("/api/admin/plans", json={"product_id": pid, "code": "vpn-pro", "name": "Pro",
                                                      "price_cents": 600})
    route = svc.mock.post(HOOK).mock(return_value=httpx.Response(200))
    u, c, _ = await customer(make_client, svc, "maria")
    out = await subscribe_api(c, "vpn-m")
    await drain()
    clock.set(dt(2026, 10, 20, 12))
    pro = await fetch_one(Plan, code="vpn-pro")
    r = await c.post(f"/api/billing/subscriptions/{out['subscription_id']}/change", json={"plan_id": pro.id})
    assert r.status_code == 200, r.text
    await drain()
    assert [json.loads(x.request.content)["event"] for x in route.calls] == ["subscription.activated",
                                                                            "subscription.updated"]
    assert json.loads(route.calls[-1].request.content)["plan"]["code"] == "vpn-pro"


async def test_none_fulfillment_needs_nothing(admin_client, make_client, svc):
    await create_product(admin_client, "gorjeta", fulfillment="none")
    u, c, _ = await customer(make_client, svc, "maria")
    out = await subscribe_api(c, "gorjeta-m")
    await drain()
    assert (await get(Subscription, out["subscription_id"])).fulfillment_status is None
    assert await jobs_of("fulfillment_webhook") == []
