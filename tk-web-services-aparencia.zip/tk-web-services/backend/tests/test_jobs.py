from __future__ import annotations

from datetime import timedelta

import pytest
from conftest import dbs, drain, fetch, get, update_row

from app.db import utcnow
from app.models import Job
from app.services import jobs
from app.services.jobs import PermanentError, RetryLater, enqueue, recover_stale


@pytest.fixture
def handlers(monkeypatch):
    calls: list[dict] = []

    def register(kind, fn):
        async def wrapper(db, payload):
            calls.append(payload)
            await fn(db, payload)

        monkeypatch.setitem(jobs.HANDLERS, kind, wrapper)

    register.calls = calls
    return register


async def add_job(kind, payload=None, **kw) -> Job:
    async with dbs() as db:
        job = await enqueue(db, kind, payload or {}, **kw)
        await db.commit()
        return job


async def test_success_marks_done_and_scrubs_secrets(handlers):
    async def ok(db, payload):
        pass

    handlers("t_ok", ok)
    job = await add_job("t_ok", {"a": 1, "token_enc": "segredo"})
    assert await drain() == 1
    job = await get(Job, job.id)
    assert job.status == "done" and job.attempts == 1 and job.finished_at is not None
    assert job.payload == {"a": 1, "token_enc": "<removido>"}
    assert job.locked_by == jobs.WORKER_ID


async def test_retry_later_uses_given_delay(handlers):
    async def later(db, payload):
        raise RetryLater("ainda não", 90)

    handlers("t_later", later)
    job = await add_job("t_later", {"x_enc": "s"})
    await drain()
    job = await get(Job, job.id)
    assert job.status == "pending" and job.attempts == 1 and job.last_error == "RetryLater: ainda não"
    assert utcnow() + timedelta(seconds=80) < job.run_after <= utcnow() + timedelta(seconds=90)
    assert job.payload["x_enc"] == "s"  # mantém-se até terminar
    assert job.locked_at is None
    assert await drain() == 0  # ainda não é hora


async def test_exception_backoff_is_exponential_and_max_attempts_fails(handlers):
    async def boom(db, payload):
        raise ValueError("rebentou")

    handlers("t_boom", boom)
    job = await add_job("t_boom", {"p_enc": "segredo"}, max_attempts=3)
    delays = []
    for _ in range(3):
        await drain()
        j = await get(Job, job.id)
        if j.status == "pending":
            delays.append((j.run_after - utcnow()).total_seconds())
            await update_row(Job, job.id, run_after=utcnow())
    j = await get(Job, job.id)
    assert j.status == "failed" and j.attempts == 3 and j.finished_at is not None
    assert j.last_error == "ValueError: rebentou"
    assert j.payload == {"p_enc": "<removido>"}
    assert 25 < delays[0] <= 30 and 55 < delays[1] <= 60  # 30s, 60s, ...
    assert len(handlers.calls) == 3


def test_backoff_capped():
    assert jobs._backoff(1) == 30 and jobs._backoff(2) == 60 and jobs._backoff(3) == 120
    assert jobs._backoff(20) == 6 * 3600


async def test_permanent_error_and_unknown_handler(handlers):
    async def perm(db, payload):
        raise PermanentError("não vale a pena")

    handlers("t_perm", perm)
    j1 = await add_job("t_perm")
    j2 = await add_job("t_nao_existe")
    await drain()
    j1, j2 = await get(Job, j1.id), await get(Job, j2.id)
    assert j1.status == "failed" and j1.attempts == 1
    assert j2.status == "failed" and "Sem handler" in j2.last_error


async def test_failed_handler_changes_are_rolled_back(handlers):
    from app.models import SiteSetting

    async def partial(db, payload):
        db.add(SiteSetting(key="announcement", value="x"))
        await db.flush()
        raise ValueError("depois de escrever")

    handlers("t_partial", partial)
    await add_job("t_partial")
    await drain()
    assert await fetch(SiteSetting) == []


async def test_dedupe_key(handlers):
    async def ok(db, payload):
        pass

    handlers("t_dedupe", ok)
    a = await add_job("t_dedupe", {"n": 1}, dedupe_key="k1", delay_seconds=600)
    b = await add_job("t_dedupe", {"n": 2}, dedupe_key="k1")
    assert a.id == b.id
    rows = await fetch(Job, dedupe_key="k1")
    assert len(rows) == 1
    assert rows[0].run_after <= utcnow()  # o pedido mais urgente antecipa o existente
    c = await add_job("t_dedupe", {"n": 3}, dedupe_key="k2")
    assert c.id != a.id
    await drain()
    # depois de concluído, a mesma chave volta a criar um job novo
    d = await add_job("t_dedupe", {"n": 4}, dedupe_key="k1")
    assert d.id != a.id


async def test_dedupe_within_same_transaction():
    async with dbs() as db:
        a = await enqueue(db, "reconcile_user", {"user_id": "x"}, dedupe_key="reconcile:x")
        b = await enqueue(db, "reconcile_user", {"user_id": "x"}, dedupe_key="reconcile:x")
        assert a is b
        await db.commit()
    assert len(await fetch(Job)) == 1


async def test_stale_running_jobs_recovered(handlers):
    async def ok(db, payload):
        pass

    handlers("t_stale", ok)
    job = await add_job("t_stale")
    await update_row(Job, job.id, status="running", locked_at=utcnow() - timedelta(minutes=30), attempts=1)
    fresh = await add_job("t_stale")
    await update_row(Job, fresh.id, status="running", locked_at=utcnow() - timedelta(minutes=2), attempts=1)
    assert await drain() == 0
    async with dbs() as db:
        assert await recover_stale(db) == 1
    await drain()
    assert (await get(Job, job.id)).status == "done"
    assert (await get(Job, fresh.id)).status == "running"


async def test_jobs_run_in_order(handlers):
    order = []

    async def rec(db, payload):
        order.append(payload["n"])

    handlers("t_order", rec)
    for n in range(5):
        await add_job("t_order", {"n": n})
    await drain()
    assert order == [0, 1, 2, 3, 4]


async def test_periodic_tasks(handlers):
    from app.services import tasks

    await tasks.run_periodic("bonus")
    await tasks.run_periodic("bonus")
    assert len(await fetch(Job, kind="bonus_evaluate_all")) == 1
    await tasks.run_periodic("reconcile_all")
    await tasks.run_periodic("sweep")
    await tasks.run_periodic("recover_stale")
    await tasks.run_periodic("cleanup")
    await drain()
    assert {j.status for j in await fetch(Job)} == {"done"}
    # a limpeza apaga jobs concluídos há mais de 14 dias
    old = (await fetch(Job, kind="bonus_evaluate_all"))[0]
    await update_row(Job, old.id, finished_at=utcnow() - timedelta(days=15))
    await tasks.run_periodic("cleanup")
    assert await get(Job, old.id) is None
    async with dbs() as db:
        assert (await tasks.job_counts(db)) == {"done": 1}


async def test_concurrent_workers_claim_each_job_once(handlers):
    import asyncio

    seen: list[int] = []

    async def rec(db, payload):
        seen.append(payload["n"])
        await asyncio.sleep(0.01)

    handlers("t_conc", rec)
    for n in range(12):
        await add_job("t_conc", {"n": n})

    async def worker():
        while await jobs.run_one():
            pass

    await asyncio.gather(*[worker() for _ in range(4)])
    assert sorted(seen) == list(range(12))
    assert {j.status for j in await fetch(Job)} == {"done"}


async def test_concurrent_token_consumption_single_use():
    import asyncio

    from conftest import create_user

    from app.services import tokens

    u = await create_user("maria")
    async with dbs() as db:
        raw = await tokens.issue(db, u.id, "magic_login")
        await db.commit()

    async def consume():
        async with dbs() as db:
            tok = await tokens.consume(db, raw, "magic_login")
            await db.commit()
            return tok is not None

    results = await asyncio.gather(*[consume() for _ in range(5)])
    assert results.count(True) == 1
