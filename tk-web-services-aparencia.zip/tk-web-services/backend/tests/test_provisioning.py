from __future__ import annotations

from datetime import timedelta

from conftest import (
    PASSWORD,
    add_sub,
    create_user,
    dbs,
    drain,
    emails,
    fetch,
    fetch_one,
    get,
    jobs_of,
    plan_by_code,
    update_row,
)
from test_auth import make_invite, register

from app.db import utcnow
from app.models import Grant, Job, ServiceAccount, Subscription, SubStatus, User
from app.security import decrypt
from app.services.jobs import enqueue
from app.services.provisioning import queue_jellyfin_password
from app.services.subscriptions import request_reconcile, set_status


async def reconcile(user_id: str) -> int:
    async with dbs() as db:
        await request_reconcile(db, user_id)
        await db.commit()
    return await drain()


async def link_jf(svc, user: User, **policy) -> dict:
    jf_user = svc.jf.add_user(user.username, **policy)
    async with dbs() as db:
        db.add(ServiceAccount(user_id=user.id, service="jellyfin", external_id=jf_user["Id"],
                              external_username=user.username))
        await db.commit()
    return jf_user


async def change_status(sub: Subscription, status: SubStatus, **fields):
    async with dbs() as db:
        s = await db.get(Subscription, sub.id)
        await set_status(db, s, status, reason="teste", **fields)
        await db.commit()


# --------------------------------------------------------------------------- Jellyfin
async def test_registration_sso_account_gets_no_jellyfin_password(client, svc):
    """Conta nova (SSO): a password do portal nunca vai para o Jellyfin; a conta Jellyfin só é criada quando houver
    streaming, com uma password aleatória (entra por "Entrar com TK Web Services" ou Quick Connect)."""
    await make_invite()
    r = await register(client, "novato")
    assert r.status_code == 200
    assert await jobs_of("jellyfin_set_password") == []
    u = await fetch_one(User, username="novato")
    assert u.jellyfin_password_login is False and u.billing_mode == "legacy" and u.needs_password_sync is False
    await drain()
    assert svc.jf.by_name("novato") is None
    await add_sub(u)
    await reconcile(u.id)
    jf_user = svc.jf.by_name("novato")
    assert jf_user is not None and svc.jf.passwords[jf_user["Id"]] != PASSWORD
    assert (await get(User, u.id)).needs_password_sync is False
    assert (await client.get("/api/auth/me")).json()["jellyfin_password_login"] is False


async def test_registration_creates_disabled_hidden_jellyfin_account(client, svc, settings):
    settings.set("sso_only_for_new_users", False)  # modo antigo: mesma password no Jellyfin
    await make_invite()
    r = await register(client, "novato")
    assert r.status_code == 200
    [job] = await jobs_of("jellyfin_set_password")
    assert job.max_attempts == 10
    await drain()
    jf_user = svc.jf.by_name("novato")
    assert jf_user is not None
    assert svc.jf.passwords[jf_user["Id"]] == PASSWORD
    pol = jf_user["Policy"]
    assert pol["IsDisabled"] is True and pol["IsHidden"] is True and pol["IsAdministrator"] is False
    sa = await fetch_one(ServiceAccount, service="jellyfin")
    assert sa.external_id == jf_user["Id"] and sa.external_username == "novato"
    assert sa.applied_state["IsDisabled"] is True
    assert (await get(Job, job.id)).payload["password_enc"] == "<removido>"
    # sem direitos → nada no Seerr nem no Dispatcharr
    assert svc.seerr.calls == [] and svc.dc.calls == []
    assert (await client.get("/api/services")).json()["jellyfin"]["linked"] is True


async def test_jellyfin_calls_use_mediabrowser_authorization(client, svc):
    u = await create_user("hdr")
    await add_sub(u)
    await reconcile(u.id)
    assert svc.jf.calls
    for _, _, req in svc.jf.calls:
        auth = req.headers["authorization"]
        assert auth.startswith('MediaBrowser Client="TKPortal"') and auth.endswith('Token="jf-api-key-123"')
        assert "x-emby-token" not in req.headers


async def test_activation_applies_plan_features(client, svc):
    u = await create_user("maria")
    jf_user = await link_jf(svc, u, IsDisabled=True, IsHidden=True, EnableLiveTvAccess=False)
    sub = await add_sub(u, "tkflix-tv-mensal", status=SubStatus.pending)
    await change_status(sub, SubStatus.active)
    await drain()
    pol = svc.jf.users[jf_user["Id"]]["Policy"]
    assert pol["IsDisabled"] is False
    assert pol["EnableAllFolders"] is True and pol["EnabledFolders"] == []
    assert pol["MaxActiveSessions"] == 2
    assert pol["EnableLiveTvAccess"] is True
    assert pol["EnableContentDownloading"] is True
    assert pol["RemoteClientBitrateLimit"] == 0
    assert pol["IsHidden"] is True  # não gerido → preservado

    # Seerr: importado a partir do Jellyfin e definições principais (email + quotas) aplicadas
    [seerr_user] = svc.seerr.users.values()
    assert seerr_user["jellyfinUserId"] == jf_user["Id"]
    st = svc.seerr.settings[seerr_user["id"]]
    assert st["email"] == "maria@example.com"
    assert (st["movieQuotaLimit"], st["movieQuotaDays"], st["tvQuotaLimit"], st["tvQuotaDays"]) == (10, 7, 5, 7)
    assert st["locale"] == "pt"  # restantes definições preservadas

    # Dispatcharr: conta XC criada com password
    dc_user = svc.dc.by_name("maria")
    assert dc_user["user_level"] == 0 and dc_user["stream_limit"] == 1
    xc = dc_user["custom_properties"]["xc_password"]
    sa = await fetch_one(ServiceAccount, service="dispatcharr")
    assert decrypt(sa.secret_enc) == xc
    assert not await emails("iptv_ready", to="maria@example.com")  # sem emails de confirmação (o cliente vê no portal)
    assert not await emails("subscription_active", to="maria@example.com")

    c = client
    await c.login_as(u)
    data = (await c.get("/api/services")).json()
    assert data["jellyfin"]["enabled"] and data["jellyfin"]["live_tv"] and data["jellyfin"]["max_streams"] == 2
    assert data["seerr"]["linked"] is True and data["seerr"]["movie_quota"] == 10
    iptv = data["iptv"]
    assert iptv["source"] == "dispatcharr" and iptv["username"] == "maria" and iptv["password"] == xc
    assert iptv["m3u_url"].startswith("https://iptv.test/get.php?username=maria&password=")
    me = (await c.get("/api/auth/me")).json()
    assert me["has_access"] and set(me["features"]) == {"jellyfin", "livetv", "seerr", "iptv"}


async def test_reconcile_is_idempotent(svc):
    u = await create_user("maria")
    await link_jf(svc, u)
    await add_sub(u, "tkflix-tv-mensal")
    await reconcile(u.id)
    for f in (svc.jf, svc.seerr, svc.dc):
        f.reset()
    await reconcile(u.id)
    assert svc.jf.writes() == [] and svc.seerr.writes() == [] and svc.dc.writes() == []
    assert svc.jf.calls  # mas verificou o estado
    assert len(await emails("iptv_ready")) == 0


async def test_ending_subscription_disables_everything(svc):
    u = await create_user("maria")
    jf_user = await link_jf(svc, u)
    sub = await add_sub(u, "tkflix-tv-mensal")
    await reconcile(u.id)
    dc_user = svc.dc.by_name("maria")
    assert dc_user["custom_properties"].get("xc_password")
    svc.dc.reset()
    await change_status(sub, SubStatus.ended)
    await drain()
    assert svc.jf.users[jf_user["Id"]]["Policy"]["IsDisabled"] is True
    [patch] = svc.dc.find("PATCH", rf"/users/{dc_user['id']}/")
    import json

    assert json.loads(patch.content) == {"custom_properties": {"xc_password": None}}
    assert "xc_password" not in dc_user["custom_properties"]
    assert not await emails("subscription_ended")  # terminada à mão: sem email
    sa = await fetch_one(ServiceAccount, service="dispatcharr")
    assert sa.applied_state == {"enabled": False}

    # reativar → mesma password XC volta a ser aplicada
    old_pwd = decrypt(sa.secret_enc)
    await change_status(sub, SubStatus.active)
    await drain()
    assert svc.jf.users[jf_user["Id"]]["Policy"]["IsDisabled"] is False
    assert dc_user["custom_properties"]["xc_password"] == old_pwd


async def test_blocked_user_is_disabled_even_with_subscription(svc, admin_client):
    u = await create_user("maria")
    jf_user = await link_jf(svc, u)
    await add_sub(u)
    await reconcile(u.id)
    assert svc.jf.users[jf_user["Id"]]["Policy"]["IsDisabled"] is False
    r = await admin_client.patch(f"/api/admin/users/{u.id}", json={"is_active": False})
    assert r.status_code == 200
    await drain()
    assert svc.jf.users[jf_user["Id"]]["Policy"]["IsDisabled"] is True


async def test_jellyfin_admin_never_touched(svc):
    u = await create_user("dono")
    jf_user = await link_jf(svc, u, admin=True, IsDisabled=False)
    before = dict(jf_user["Policy"])
    await reconcile(u.id)  # sem subscrição → desativaria um utilizador normal
    assert svc.jf.policy_writes() == []
    assert svc.jf.users[jf_user["Id"]]["Policy"] == before
    sa = await fetch_one(ServiceAccount, service="jellyfin")
    assert sa.applied_state == {"admin": True}
    # nem a password
    async with dbs() as db:
        await queue_jellyfin_password(db, await db.get(User, u.id), "Nova-Pass-123")
        await db.commit()
    await drain()
    assert svc.jf.passwords[jf_user["Id"]] == "old-password"
    assert svc.jf.find("POST", r"^/Users/Password$") == []


async def test_existing_jellyfin_account_linked_by_name(svc):
    """Utilizador migrado cujo Jellyfin já existe: a password do portal passa a ser a do Jellyfin."""
    jf_user = svc.jf.add_user("Legado")
    u = await create_user("legado")
    async with dbs() as db:
        await queue_jellyfin_password(db, await db.get(User, u.id), "Portal-Pass-1")
        await db.commit()
    await drain()
    assert svc.jf.passwords[jf_user["Id"]] == "Portal-Pass-1"
    assert svc.jf.find("POST", r"^/Users/New$") == []
    sa = await fetch_one(ServiceAccount, service="jellyfin")
    assert sa.external_id == jf_user["Id"]


async def test_reconcile_without_password_marks_needs_sync(svc):
    u = await create_user("semsenha")
    await add_sub(u)
    await reconcile(u.id)
    jf_user = svc.jf.by_name("semsenha")
    assert jf_user and jf_user["Policy"]["IsDisabled"] is False
    assert (await get(User, u.id)).needs_password_sync is True


async def test_jellyfin_account_of_other_portal_user_is_not_hijacked(svc):
    a = await create_user("ana")
    jf_user = await link_jf(svc, a)
    b = await create_user("ana2")
    # alguém renomeou a conta no Jellyfin para o nome de outro utilizador do portal
    svc.jf.users[jf_user["Id"]]["Name"] = "ana2"
    async with dbs() as db:
        await queue_jellyfin_password(db, await db.get(User, b.id), "Pass-da-ana2")
        await db.commit()
    await drain()
    [job] = await jobs_of("jellyfin_set_password")
    assert job.status == "failed" and "outro utilizador" in job.last_error
    assert job.payload["password_enc"] == "<removido>"
    assert svc.jf.passwords[jf_user["Id"]] == "old-password"


async def test_jellyfin_down_retries_and_records_error(svc):
    u = await create_user("maria")
    await link_jf(svc, u)
    await add_sub(u)
    svc.jf.down = True
    await reconcile(u.id)
    [job] = await jobs_of("reconcile_user")
    assert job.status == "pending" and job.attempts == 1
    assert "jellyfin" in job.last_error and "503" in job.last_error
    assert job.run_after > utcnow() + timedelta(seconds=60)
    sa = await fetch_one(ServiceAccount, service="jellyfin")
    assert "503" in sa.last_error
    svc.jf.down = False
    await update_row(Job, job.id, run_after=utcnow())
    await drain()
    job = await get(Job, job.id)
    assert job.status == "done" and job.attempts == 2 and job.last_error is None
    assert (await fetch_one(ServiceAccount, service="jellyfin")).last_error is None


async def test_password_job_retries_when_jellyfin_down(svc):
    u = await create_user("maria")
    svc.jf.down = True
    async with dbs() as db:
        await queue_jellyfin_password(db, await db.get(User, u.id), "Pass-123456")
        await db.commit()
    await drain()
    [job] = await jobs_of("jellyfin_set_password")
    assert job.status == "pending" and job.payload["password_enc"] != "<removido>"
    assert job.run_after > utcnow() + timedelta(seconds=100)


async def test_seerr_import_failure_is_retried_but_jellyfin_applied(svc):
    u = await create_user("maria")
    jf_user = await link_jf(svc, u, IsDisabled=True)
    await add_sub(u)
    svc.seerr.import_returns_empty = True
    await reconcile(u.id)
    assert svc.jf.users[jf_user["Id"]]["Policy"]["IsDisabled"] is False
    [job] = await jobs_of("reconcile_user")
    assert job.status == "pending" and "seerr" in job.last_error
    assert await fetch(ServiceAccount, service="seerr") == []


async def test_seerr_existing_user_found_and_email_propagated(svc, client):
    u = await create_user("maria")
    jf_user = await link_jf(svc, u)
    svc.seerr.users[7] = {"id": 7, "jellyfinUserId": jf_user["Id"], "jellyfinUsername": "maria"}
    svc.seerr.settings[7] = {"email": "velho@example.com", "movieQuotaLimit": None}
    await add_sub(u)
    await reconcile(u.id)
    assert svc.seerr.find("POST", "import-from-jellyfin") == []
    assert svc.seerr.settings[7]["email"] == "maria@example.com"
    await update_row(User, u.id, email="novo@example.com")
    await reconcile(u.id)
    assert svc.seerr.settings[7]["email"] == "novo@example.com"


async def test_dispatcharr_existing_user_is_adopted_and_enabled(svc):
    u = await create_user("maria")
    svc.dc.users[5] = {"id": 5, "username": "maria", "custom_properties": {}, "stream_limit": 0}
    await add_sub(u, "tkflix-tv-mensal")
    await reconcile(u.id)
    assert svc.dc.find("POST", r"/users/$") == []
    assert svc.dc.users[5]["custom_properties"]["xc_password"]
    assert svc.dc.users[5]["stream_limit"] == 1
    sa = await fetch_one(ServiceAccount, service="dispatcharr")
    assert sa.external_id == "5" and decrypt(sa.secret_enc) == svc.dc.users[5]["custom_properties"]["xc_password"]


async def test_grant_gives_access_and_expiry_is_swept(svc):
    from app.services.subscriptions import sweep

    u = await create_user("amigo")
    jf_user = await link_jf(svc, u, IsDisabled=True)
    plan = await plan_by_code("tkflix-mensal")
    async with dbs() as db:
        g = Grant(user_id=u.id, plan_id=plan.id, ends_at=utcnow() + timedelta(days=1))
        db.add(g)
        await db.commit()
    await reconcile(u.id)
    assert svc.jf.users[jf_user["Id"]]["Policy"]["IsDisabled"] is False
    await update_row(Grant, g.id, ends_at=utcnow() - timedelta(minutes=5))
    async with dbs() as db:
        counts = await sweep(db)
    assert counts["grants"] == 1
    await drain()
    assert svc.jf.users[jf_user["Id"]]["Policy"]["IsDisabled"] is True


async def test_reconcile_all_enqueues_every_user(svc):
    for n in ("a1a", "b2b", "c3c"):
        await create_user(n)
    async with dbs() as db:
        await enqueue(db, "reconcile_all", {}, dedupe_key="reconcile_all")
        await db.commit()
    await drain()
    assert len(await jobs_of("reconcile_user", "done")) == 3


# --------------------------------------------------------------------------- endpoints de serviços
async def test_devices_quick_connect_and_now_playing(client, svc):
    u = await create_user("maria")
    jf_user = await link_jf(svc, u)
    svc.jf.devices[jf_user["Id"]] = [
        {"Id": "dev1", "Name": "TV Sala", "AppName": "Jellyfin Android TV", "AppVersion": "0.17",
         "DateLastActivity": "2026-09-01T10:00:00Z"},
    ]
    await client.login_as(u)
    r = await client.get("/api/services/jellyfin/devices")
    assert r.json() == [{"id": "dev1", "name": "TV Sala", "app": "Jellyfin Android TV 0.17",
                         "last_active": "2026-09-01T10:00:00Z"}]
    r = await client.delete("/api/services/jellyfin/devices/dev-de-outro")
    assert r.status_code == 404
    r = await client.delete("/api/services/jellyfin/devices/dev1")
    assert r.status_code == 200 and svc.jf.devices[jf_user["Id"]] == []

    r = await client.post("/api/services/jellyfin/quick-connect", json={"code": "123456"})
    assert r.status_code == 403  # sem subscrição
    await add_sub(u)
    svc.jf.quick_connect_codes.add("654321")
    r = await client.post("/api/services/jellyfin/quick-connect", json={"code": "111111"})
    assert r.status_code == 400
    r = await client.post("/api/services/jellyfin/quick-connect", json={"code": "654 321"})
    assert r.status_code == 200
    [req] = svc.jf.find("POST", "/QuickConnect/Authorize")[-1:]
    assert req.url.params["userId"] == jf_user["Id"] and req.url.params["code"] == "654321"
    assert (await client.get("/api/services/jellyfin/now-playing")).json() == []


async def test_sync_password_endpoint(client, svc):
    u = await create_user("maria")
    jf_user = await link_jf(svc, u)
    await client.login_as(u)
    r = await client.post("/api/services/jellyfin/sync-password", json={"password": "errada"})
    assert r.status_code == 400
    r = await client.post("/api/services/jellyfin/sync-password", json={"password": PASSWORD})
    assert r.status_code == 200
    await drain()
    assert svc.jf.passwords[jf_user["Id"]] == PASSWORD


async def test_services_without_jellyfin_account(client):
    u = await create_user("maria")
    await client.login_as(u)
    r = await client.get("/api/services/jellyfin/devices")
    assert r.status_code == 400


async def test_manual_iptv_credentials(admin_client, client):
    u = await create_user("maria")
    r = await admin_client.put(f"/api/admin/users/{u.id}/iptv-manual",
                               json={"username": "m123", "password": "p456", "host": "http://tv.example:8080"})
    assert r.status_code == 200
    await client.login_as(u)
    iptv = (await client.get("/api/services")).json()["iptv"]
    assert iptv == {"enabled": True, "source": "manual", "username": "m123", "password": "p456",
                    "server": "http://tv.example:8080"}
    r = await admin_client.put(f"/api/admin/users/{u.id}/iptv-manual", json={})
    assert r.status_code == 200
    assert (await client.get("/api/services")).json()["iptv"]["enabled"] is False


async def test_status_transitions_do_not_leak_between_users(svc):
    a = await create_user("ana")
    b = await create_user("bea")
    ja = await link_jf(svc, a, IsDisabled=True)
    jb = await link_jf(svc, b, IsDisabled=True)
    await add_sub(a)
    await reconcile(a.id)
    await reconcile(b.id)
    assert svc.jf.users[ja["Id"]]["Policy"]["IsDisabled"] is False
    assert svc.jf.users[jb["Id"]]["Policy"]["IsDisabled"] is True
    assert (await get(User, a.id)).needs_password_sync is False
