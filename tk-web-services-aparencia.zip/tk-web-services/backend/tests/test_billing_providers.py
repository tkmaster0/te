"""Fornecedores de pagamento: desligar / deixar de aceitar novos / troca de conta → métodos inutilizáveis, clientes
avisados e alternativa usada; cartões a expirar; concorrência (nunca cobrar duas vezes)."""
from __future__ import annotations

import asyncio
from datetime import timedelta

import pytest
from conftest import (
    IS_PG,
    add_method,
    create_user,
    customer,
    cycle,
    dbs,
    drain,
    dt,
    emails,
    fetch,
    fetch_one,
    get,
    plan_by_code,
    subscribe_api,
)

from app.models import Checkout, Invoice, Payment, PaymentMethod, Subscription, SubStatus, User
from app.payments import registry
from app.services import billing, tasks


async def set_provider(admin_client, name: str, **body) -> str:
    r = await admin_client.put(f"/api/admin/providers/{name}", json=body)
    assert r.status_code == 200, r.text
    return r.json()["message"]


async def test_disable_provider_marks_methods_unusable_notifies_and_falls_back(admin_client, make_client, svc,
                                                                              clock):
    clock.set(dt(2026, 10, 5, 12))
    only_gc, c_only, gc_pm = await customer(make_client, svc, "ana", provider="gocardless")
    await subscribe_api(c_only, "tkflix-mensal")
    both, c_both, _ = await customer(make_client, svc, "bea", provider="gocardless")
    card = await add_method(svc, both, "stripe", default=False)
    await subscribe_api(c_both, "tkflix-mensal")
    idle, _, _ = await customer(make_client, svc, "cat", provider="gocardless")  # sem serviços

    msg = await set_provider(admin_client, "gocardless", enabled=False)
    assert "3 métodos ficaram inutilizáveis" in msg and "1 clientes avisados" in msg
    for pm in await fetch(PaymentMethod, provider="gocardless"):
        assert pm.status == "unusable" and "descontinuado" in pm.status_reason
    [mail] = await emails("payment_method_needed")
    assert mail["to"] == only_gc.email and "descontinuado" in mail["ctx"]["reason"]
    summary = (await c_only.get("/api/billing/summary")).json()
    assert summary["default_payment_method_id"] is None
    assert summary["actions"][0]["type"] == "payment_method" and "descontinuado" in summary["actions"][0]["message"]
    assert [p for p in summary["providers"] if p["name"] == "gocardless"][0]["available"] is False
    assert (await c_both.get("/api/billing/summary")).json()["default_payment_method_id"] == card.id
    catalog = (await c_only.get("/api/billing/products")).json()
    assert catalog[0]["plans"][0]["providers"] == ["stripe"]
    r = await c_only.post("/api/billing/payment-methods", json={"provider": "gocardless"})
    assert r.status_code == 400
    providers = {p["name"]: p for p in (await admin_client.get("/api/admin/providers")).json()}
    assert providers["gocardless"]["enabled"] is False and providers["gocardless"]["methods"] == {"unusable": 3}
    assert providers["gocardless"]["customers_only_on_this"] == 2
    assert providers["stripe"]["account_id"] == svc.stripe.account_id

    # ciclo: quem tem alternativa paga com ela; quem não tem fica com a cobrança por pagar e tolerância maior
    clock.set(dt(2026, 11, 5, 6))
    inv_both = await cycle(both)
    assert inv_both.status == "paid" and inv_both.payment_method_id == card.id
    n_gc = len(svc.gc.charges())
    inv_only = await cycle(only_gc)
    assert inv_only.status == "failed" and inv_only.last_error == "Sem método de pagamento válido"
    assert len(svc.gc.charges()) == n_gc
    sub = await fetch_one(Subscription, user_id=only_gc.id)
    assert sub.status == SubStatus.past_due and sub.grace_until == dt(2026, 11, 19, 6)
    assert len(await emails("payment_method_needed", to=only_gc.email)) == 2

    # os webhooks de pagamentos em curso continuam a ser processados com o fornecedor desligado
    # e voltar a ligar recupera os métodos (mesma conta)
    msg = await set_provider(admin_client, "gocardless", enabled=True)
    assert "3 métodos voltaram" in msg
    assert (await get(PaymentMethod, gc_pm.id)).status == "active"
    # a cobrança por pagar é tentada na data da nova tentativa, já com o mandato
    clock.set(dt(2026, 11, 8, 6, 1))
    async with dbs() as db:
        assert await billing.schedule_due(db) == 1
    await drain()
    assert (await get(Invoice, inv_only.id)).status == "processing"


async def test_accept_new_false_keeps_charging_existing_customers(admin_client, make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, c, card = await customer(make_client, svc, "maria")
    await subscribe_api(c, "tkflix-mensal")
    msg = await set_provider(admin_client, "stripe", accept_new=False)
    assert "inutilizáveis" not in msg
    state = {p["name"]: p for p in (await c.get("/api/billing/summary")).json()["providers"]}
    assert state["stripe"]["available"] is False and state["gocardless"]["available"] is True
    assert (await c.post("/api/billing/payment-methods", json={"provider": "stripe"})).status_code == 400
    new, cn, _ = await customer(make_client, svc, "novo", provider=None)
    plan = await plan_by_code("tkflix-mensal")
    r = await cn.post("/api/billing/subscribe", json={"plan_id": plan.id, "provider": "stripe"})
    assert r.status_code == 400 and await fetch(Checkout) == []
    assert (await get(PaymentMethod, card.id)).status == "active"
    clock.set(dt(2026, 11, 5, 6))
    assert (await cycle(u)).status == "paid"


async def test_account_change_marks_methods_unusable_until_customer_adds_new_one(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, c, card = await customer(make_client, svc, "maria")
    out = await subscribe_api(c, "tkflix-mensal")
    assert (await get(PaymentMethod, card.id)).provider_account == "acct_1"

    svc.stripe.account_id = "acct_2"  # chaves de outra conta Stripe no .env
    registry.clear_cache()
    await tasks.run_periodic("check_methods")
    card = await get(PaymentMethod, card.id)
    assert card.status == "unusable" and "Mudámos de conta" in card.status_reason
    [mail] = await emails("payment_method_needed", to=u.email)
    assert "Mudámos de conta" in mail["ctx"]["reason"]
    await tasks.run_periodic("check_methods")
    assert len(await emails("payment_method_needed")) == 1  # avisado uma vez

    clock.set(dt(2026, 11, 5, 6))
    inv = await cycle(u)
    assert inv.status == "failed" and inv.last_error == "Sem método de pagamento válido"
    assert not [k for k in svc.stripe.keys_for("/v1/payment_intents") if k.startswith(f"inv-{inv.id}")]
    assert (await get(Subscription, out["subscription_id"])).status == SubStatus.past_due

    # o cliente guarda um cartão novo → a cobrança em atraso é tentada logo
    r = await c.post("/api/billing/payment-methods", json={"provider": "stripe"})
    co = await get(Checkout, r.json()["checkout_id"])
    svc.stripe.complete_setup(co.provider_ref, last4="0005")
    assert (await c.get(f"/api/billing/checkout/{co.id}")).json()["status"] == "completed"
    new = await get(PaymentMethod, (await get(Checkout, co.id)).payment_method_id)
    assert new.provider_account == "acct_2" and new.is_default
    await drain()
    assert (await get(Invoice, inv.id)).status == "paid"
    assert (await get(Subscription, out["subscription_id"])).status == SubStatus.active

    # sem rede não se sabe a conta: nada é reativado por engano
    svc.stripe.account_id = "acct_1"
    svc.stripe.fail_paths["/v1/account"] = 500
    registry.clear_cache()
    await tasks.run_periodic("check_methods")
    assert (await get(PaymentMethod, card.id)).status == "unusable"
    assert (await get(PaymentMethod, new.id)).status == "active"
    del svc.stripe.fail_paths["/v1/account"]
    registry.clear_cache()
    await tasks.run_periodic("check_methods")
    assert (await get(PaymentMethod, card.id)).status == "active"
    assert (await get(PaymentMethod, new.id)).status == "unusable"


async def test_admin_notify_customers_only_on_provider(admin_client, make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    a, ca, _ = await customer(make_client, svc, "ana", provider="gocardless")
    await subscribe_api(ca, "tkflix-mensal")
    b, cb, _ = await customer(make_client, svc, "bea", provider="gocardless")
    await add_method(svc, b, "stripe", default=False)
    await subscribe_api(cb, "tkflix-mensal")
    await customer(make_client, svc, "cat", provider="gocardless")  # sem serviços
    r = await admin_client.post("/api/admin/providers/gocardless/notify", json={"message": "Vamos mudar de banco."})
    assert r.status_code == 200 and r.json()["message"] == "1 clientes avisados."
    [mail] = await emails("payment_method_needed")
    assert mail["to"] == a.email and mail["ctx"]["reason"] == "Vamos mudar de banco."
    assert (await admin_client.post("/api/admin/providers/paypal/notify", json={})).status_code == 404
    assert (await admin_client.put("/api/admin/providers/paypal", json={"enabled": False})).status_code == 404


async def test_expiring_card_warns_and_expired_card_is_skipped(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, c, _ = await customer(make_client, svc, "maria", provider=None)
    card = await add_method(svc, u, "stripe", expires_at=dt(2026, 11, 1, 0))
    await subscribe_api(c, "tkflix-mensal")
    summary = (await c.get("/api/billing/summary")).json()
    assert any(a["title"] == "O teu cartão vai expirar" for a in summary["actions"])

    clock.set(dt(2026, 10, 20, 12))
    async with dbs() as db:
        counts = await billing.check_methods(db)
    assert counts["expired"] == 1 and counts["notified"] == 1
    assert (await get(PaymentMethod, card.id)).notified_at is not None
    assert len(await emails("payment_method_needed", to=u.email)) == 1

    sepa = await add_method(svc, u, "gocardless", default=False)
    clock.set(dt(2026, 11, 5, 6))
    inv = await cycle(u)
    assert inv.status == "processing" and inv.payment_method_id == sepa.id  # o cartão expirado é ignorado
    assert len(svc.stripe.charges()) == 1


# --------------------------------------------------------------------------- concorrência
async def test_charging_twice_never_double_charges(make_client, svc, clock):
    """Nova tentativa automática e "pagar agora" ao mesmo tempo: a mesma chave de idempotência e o bloqueio da
    cobrança garantem um só pagamento."""
    clock.set(dt(2026, 10, 5, 12))
    u, c, pm = await customer(make_client, svc, "maria")
    await subscribe_api(c, "tkflix-mensal")
    svc.stripe.behavior[pm.provider_ref] = ("card_error", "insufficient_funds")
    clock.set(dt(2026, 11, 5, 6))
    inv = await cycle(u)
    assert inv.status == "failed"
    svc.stripe.behavior[pm.provider_ref] = "succeeded"
    before = len(svc.stripe.charges())

    async def charge():
        async with dbs() as db:
            res = await billing.charge_invoice(db, await db.get(Invoice, inv.id))
            await db.commit()
            return res

    if IS_PG:
        results = await asyncio.gather(charge(), charge(), charge())
    else:  # SQLite (só desenvolvimento): um só escritor — em sequência
        results = [await charge(), await charge()]
    assert set(results) == {"paid"}
    assert len(svc.stripe.charges()) == before + 1
    assert set(svc.stripe.keys_for("/v1/payment_intents")[-1:]) == {f"inv-{inv.id}-2"}
    inv = await get(Invoice, inv.id)
    assert inv.status == "paid" and inv.attempt_count == 2
    assert len([p for p in await fetch(Payment, invoice_id=inv.id) if p.status == "paid"]) == 1
    assert len(await emails("payment_received", to=u.email)) == 0  # sem emails de confirmação (o cliente vê no portal)


@pytest.mark.skipif(not IS_PG, reason="bloqueios de linha só em PostgreSQL (SQLite: um só worker)")
async def test_concurrent_cycle_and_double_click_subscribe(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, c, _ = await customer(make_client, svc, "maria")
    plan = await plan_by_code("tkflix-mensal")
    rs = await asyncio.gather(*[c.post("/api/billing/subscribe", json={"plan_id": plan.id}) for _ in range(3)])
    assert sorted(r.status_code for r in rs) == [200, 400, 400]
    assert len(await fetch(Subscription)) == 1 and len(svc.stripe.charges()) == 1

    clock.set(dt(2026, 11, 5, 6))
    invs = await asyncio.gather(cycle(u), cycle(u), cycle(u))
    assert len([i for i in invs if i is not None]) == 1
    assert len(await fetch(Invoice)) == 2 and len(svc.stripe.charges()) == 2
    assert (await get(User, u.id)).next_billing_at == dt(2026, 12, 5, 6)


async def test_webhook_and_return_complete_checkout_once(make_client, svc):
    """O regresso do cliente e o webhook chegam juntos: um só método guardado e uma só subscrição."""
    u = await create_user("maria")
    c = make_client()
    await c.login_as(u)
    out = await subscribe_api(c, "tkflix-mensal", provider="stripe")
    co = await get(Checkout, out["checkout_id"])
    svc.stripe.complete_setup(co.provider_ref)
    async with dbs() as db:
        await billing.complete_checkout(db, await db.get(Checkout, co.id))
        await db.commit()
    assert (await c.get(f"/api/billing/checkout/{co.id}")).json()["status"] == "completed"
    async with dbs() as db:
        await billing.complete_checkout(db, await db.get(Checkout, co.id))
        await db.commit()
    assert len(await fetch(PaymentMethod)) == 1 and len(await fetch(Subscription)) == 1
    assert len(svc.stripe.charges()) == 1
    assert (await fetch_one(Subscription)).status == SubStatus.active
    assert (await fetch_one(Subscription)).current_period_end - (await fetch_one(Subscription)).started_at > \
        timedelta(days=27)
