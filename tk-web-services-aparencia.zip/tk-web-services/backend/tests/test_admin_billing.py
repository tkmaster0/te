"""Painel admin da faturação consolidada: cobranças (nova tentativa, marcar paga, anular), acertos/créditos,
ciclo forçado e fila de entregas."""
from __future__ import annotations

from conftest import (
    add_method,
    customer,
    cycle,
    dt,
    emails,
    fetch,
    get,
    subscribe_api,
)

from app.models import AuditLog, Invoice, InvoiceLine, Payment, Subscription, SubStatus, User


async def failed_cycle(make_client, svc, clock, name="maria"):
    """Cliente com a cobrança do ciclo recusada (cartão sem saldo)."""
    clock.set(dt(2026, 10, 5, 12))
    u, c, pm = await customer(make_client, svc, name)
    out = await subscribe_api(c, "tkflix-mensal")
    svc.stripe.behavior[pm.provider_ref] = ("card_error", "insufficient_funds")
    clock.set(dt(2026, 11, 5, 6))
    inv = await cycle(u)
    assert inv.status == "failed"
    return u, c, pm, await get(Subscription, out["subscription_id"]), inv


async def test_admin_invoice_listing_and_retry(admin_client, make_client, svc, clock):
    u, c, pm, sub, inv = await failed_cycle(make_client, svc, clock)
    rows = (await admin_client.get("/api/admin/invoices", params={"status": "unpaid"})).json()
    assert [r["id"] for r in rows] == [inv.id] and rows[0]["username"] == "maria"
    assert rows[0]["lines"][0]["kind"] == "renewal" and rows[0]["last_error"]
    assert len((await admin_client.get("/api/admin/invoices")).json()) == 2
    assert len((await admin_client.get("/api/admin/invoices", params={"status": "paid"})).json()) == 1

    svc.stripe.behavior[pm.provider_ref] = "succeeded"
    r = await admin_client.post(f"/api/admin/invoices/{inv.id}/retry")
    assert r.status_code == 200 and "paid" in r.json()["message"]
    inv = await get(Invoice, inv.id)
    assert inv.status == "paid" and inv.attempt_count == 2
    assert svc.stripe.keys_for("/v1/payment_intents")[-1] == f"inv-{inv.id}-2"
    assert (await get(Subscription, sub.id)).status == SubStatus.active
    assert (await admin_client.post(f"/api/admin/invoices/{inv.id}/retry")).status_code == 400

    # fornecedor em baixo → 502 (nada fica meio feito)
    u2, _, pm2, _, inv2 = await failed_cycle(make_client, svc, clock, "joao")
    svc.stripe.fail_paths["/v1/payment_intents"] = 503
    r = await admin_client.post(f"/api/admin/invoices/{inv2.id}/retry")
    assert r.status_code == 502
    assert (await get(Invoice, inv2.id)).attempt_count == 1


async def test_admin_mark_paid_restores_service(admin_client, make_client, svc, clock):
    u, c, pm, sub, inv = await failed_cycle(make_client, svc, clock)
    assert (await get(Subscription, sub.id)).status == SubStatus.past_due
    r = await admin_client.post(f"/api/admin/invoices/{inv.id}/mark-paid", json={"note": "MB Way"})
    assert r.status_code == 200
    inv = await get(Invoice, inv.id)
    assert inv.status == "paid" and inv.note == "MB Way" and inv.next_attempt_at is None
    assert (await get(Subscription, sub.id)).status == SubStatus.active
    assert not await emails("payment_received", to=u.email)  # sem emails de confirmação (o cliente vê no portal)
    assert await fetch(AuditLog, action="admin.invoice_mark_paid")
    assert (await admin_client.post(f"/api/admin/invoices/{inv.id}/mark-paid", json={"note": "outra"})
            ).status_code == 400
    assert (await admin_client.post(f"/api/admin/invoices/{inv.id}/mark-paid", json={"note": "x"})
            ).status_code == 422  # nota obrigatória


async def test_admin_void_invoice_clears_debt(admin_client, make_client, svc, clock):
    u, c, pm, sub, inv = await failed_cycle(make_client, svc, clock)
    r = await admin_client.post(f"/api/admin/invoices/{inv.id}/void")
    assert r.status_code == 200
    inv = await get(Invoice, inv.id)
    assert inv.status == "void" and inv.voided_at is not None and inv.next_attempt_at is None
    assert (await get(Subscription, sub.id)).status == SubStatus.active
    assert (await admin_client.post(f"/api/admin/invoices/{inv.id}/void")).status_code == 400
    # uma cobrança anulada não é cobrada nem aparece ao cliente
    ids = [i["id"] for i in (await c.get("/api/billing/invoices")).json()]
    assert len(ids) == 1 and inv.id not in ids
    assert (await c.post(f"/api/billing/invoices/{inv.id}/pay", json={})).status_code == 400


async def test_admin_adjustments_enter_next_invoice(admin_client, make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, c, _ = await customer(make_client, svc, "maria")
    await subscribe_api(c, "tkflix-mensal")
    r = await admin_client.post(f"/api/admin/users/{u.id}/adjustments",
                                json={"amount_cents": 250, "description": "Instalação da box"})
    assert r.status_code == 200
    r = await admin_client.post(f"/api/admin/users/{u.id}/adjustments",
                                json={"amount_cents": -100, "description": "Desconto de fidelidade"})
    assert r.status_code == 200
    assert (await admin_client.post(f"/api/admin/users/{u.id}/adjustments",
                                    json={"amount_cents": 0, "description": "zero"})).status_code == 400
    pending = await fetch(InvoiceLine, invoice_id=None)
    assert sorted((ln.kind, ln.amount_cents) for ln in pending) == [("adjustment", 250), ("credit", -100)]
    removable = next(ln for ln in pending if ln.kind == "credit")
    assert (await admin_client.delete(f"/api/admin/adjustments/{removable.id}")).status_code == 200
    summary = (await c.get("/api/billing/summary")).json()
    assert summary["upcoming"]["total_cents"] == 750

    clock.set(dt(2026, 11, 5, 6))
    inv = await cycle(u)
    assert inv.total_cents == 750 and inv.status == "paid"
    charged = next(ln for ln in await fetch(InvoiceLine, invoice_id=inv.id) if ln.kind == "adjustment")
    assert (await admin_client.delete(f"/api/admin/adjustments/{charged.id}")).status_code == 400


async def test_admin_run_billing_now(admin_client, make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, c, _ = await customer(make_client, svc, "maria")
    await subscribe_api(c, "tkflix-mensal")
    r = await admin_client.post(f"/api/admin/users/{u.id}/run-billing")
    assert r.status_code == 400  # ainda nada a vencer
    clock.set(dt(2026, 11, 5, 7))
    r = await admin_client.post(f"/api/admin/users/{u.id}/run-billing")
    assert r.status_code == 200 and "paid" in r.json()["message"]
    assert len(await fetch(Invoice)) == 2
    assert (await get(User, u.id)).next_billing_at == dt(2026, 12, 5, 6)


async def test_admin_user_detail_shows_billing(admin_client, make_client, svc, clock):
    u, c, pm, sub, inv = await failed_cycle(make_client, svc, clock)
    await add_method(svc, u, "gocardless", default=False)
    r = await admin_client.get(f"/api/admin/users/{u.id}")
    assert r.status_code == 200
    body = r.json()
    text = str(body)
    assert inv.number in text and pm.label in text
    assert len(await fetch(Payment, user_id=u.id)) == 2
