from __future__ import annotations

import base64

import pytest
from conftest import (
    add_sub,
    create_user,
    dbs,
    drain,
    emails,
    fetch,
    fetch_one,
    get,
    jobs_of,
    plan_by_code,
    post_gc_webhook,
    gc_event,
)
from test_provisioning import link_jf

from app.db import utcnow
from app.models import AuditLog, Grant, InviteCode, Job, OIDCClient, Payment, Plan, Subscription, SubStatus, User

ADMIN_GETS = ["/api/admin/stats", "/api/admin/users", "/api/admin/products", "/api/admin/invites",
              "/api/admin/jobs", "/api/admin/webhooks", "/api/admin/audit", "/api/admin/oidc-clients",
              "/api/admin/settings", "/api/admin/integrations"]


@pytest.mark.parametrize("path", ADMIN_GETS)
async def test_admin_endpoints_forbidden_for_non_admin(make_client, path):
    u = await create_user("maria")
    c = make_client()
    assert (await c.get(path)).status_code == 401
    await c.login_as(u)
    assert (await c.get(path)).status_code == 403


async def test_admin_mutations_forbidden_for_non_admin(client):
    u = await create_user("maria")
    await client.login_as(u)
    r = await client.patch(f"/api/admin/users/{u.id}", json={"is_admin": True})
    assert r.status_code == 403
    assert (await get(User, u.id)).is_admin is False
    r = await client.post(f"/api/admin/users/{u.id}/grants", json={"plan_id": 1})
    assert r.status_code == 403
    r = await client.post("/api/admin/oidc-clients", json={"client_id": "x1x", "name": "x", "redirect_uris": ["https://x"]})
    assert r.status_code == 403


async def test_admin_endpoints_smoke(admin_client, admin):
    for path in ADMIN_GETS:
        r = await admin_client.get(path)
        assert r.status_code == 200, (path, r.text)


async def test_grant_gives_access_and_reconciles(admin_client, make_client, svc):
    u = await create_user("amiga")
    jf_user = await link_jf(svc, u, IsDisabled=True)
    plan = await plan_by_code("tkflix-tv-mensal")
    r = await admin_client.post(f"/api/admin/users/{u.id}/grants",
                                json={"plan_id": plan.id, "days": 30, "reason": "Família"})
    assert r.status_code == 200
    g = await fetch_one(Grant)
    assert g.ends_at > utcnow() and g.reason == "Família"
    c = make_client()
    await c.login_as(u)
    me = (await c.get("/api/auth/me")).json()
    assert me["has_access"] and me["access"][0]["type"] == "grant" and me["access"][0]["plan_code"] == plan.code
    await drain()
    assert svc.jf.users[jf_user["Id"]]["Policy"]["IsDisabled"] is False
    assert svc.jf.users[jf_user["Id"]]["Policy"]["EnableLiveTvAccess"] is True
    detail = (await admin_client.get(f"/api/admin/users/{u.id}")).json()
    assert detail["grants"][0]["plan_id"] == plan.id
    assert detail["effective_features"]["jellyfin"]["enabled"] is True
    assert detail["service_accounts"][0]["service"] == "jellyfin"

    r = await admin_client.delete(f"/api/admin/grants/{g.id}")
    assert r.status_code == 200
    await drain()
    assert svc.jf.users[jf_user["Id"]]["Policy"]["IsDisabled"] is True
    assert (await c.get("/api/auth/me")).json()["has_access"] is False
    assert await fetch(AuditLog, action="admin.grant_added")


async def test_plan_update_reconciles_subscribers(admin_client, svc):
    u = await create_user("maria")
    jf_user = await link_jf(svc, u)
    await add_sub(u)
    other = await create_user("joao")  # sem subscrição: não é reconciliado
    await drain()
    plan = await plan_by_code("tkflix-mensal")
    body = {"product_id": plan.product_id, "code": plan.code, "name": "TKFLIX Plus", "price_cents": 600,
            "interval_unit": "month", "features": {**plan.features, "jellyfin": {
                **plan.features["jellyfin"], "max_streams": 4, "live_tv": True}},
            "highlights": ["4 ecrãs"]}
    r = await admin_client.put(f"/api/admin/plans/{plan.id}", json=body)
    assert r.status_code == 200
    assert "1 utilizadores a reconciliar" in r.json()["message"] and "novo preço" in r.json()["message"]
    reconcile_users = {j.payload["user_id"] for j in await jobs_of("reconcile_user", "pending")}
    assert reconcile_users == {u.id} and other.id not in reconcile_users
    await drain()
    pol = svc.jf.users[jf_user["Id"]]["Policy"]
    assert pol["MaxActiveSessions"] == 4 and pol["EnableLiveTvAccess"] is True
    assert (await get(Plan, plan.id)).name == "TKFLIX Plus"
    cat = (await admin_client.get("/api/billing/products")).json()
    names = [p["name"] for p in cat[0]["plans"]]
    assert "TKFLIX Plus" in names


async def test_create_product_and_plan(admin_client):
    r = await admin_client.post("/api/admin/products", json={"code": "cloud", "name": "Cloud", "kind": "other"})
    assert r.status_code == 200
    pid = r.json()["id"]
    r = await admin_client.post("/api/admin/products", json={"code": "cloud", "name": "Dup"})
    assert r.status_code == 400
    r = await admin_client.post("/api/admin/plans", json={
        "product_id": pid, "code": "cloud-1tb", "name": "1 TB", "price_cents": 300, "is_public": False,
        "features": {"groups": ["cloud"]}})
    assert r.status_code == 200
    plan = await get(Plan, r.json()["id"])
    assert plan.features["groups"] == ["cloud"] and plan.features["jellyfin"]["enabled"] is False
    # plano não público não aparece no catálogo (e o produto sem planos públicos também não)
    cat = (await admin_client.get("/api/catalog")).json()
    assert all(p["code"] != "cloud" for p in cat)
    r = await admin_client.post("/api/admin/plans", json={
        "product_id": 999, "code": "x-y", "name": "x", "price_cents": 1})
    assert r.status_code == 400


async def test_stats(admin_client):
    a = await create_user("ana")
    b = await create_user("bea")
    c = await create_user("cat")
    await add_sub(a, "tkflix-mensal", paid=False)           # 500/mês
    await add_sub(b, "tkflix-anual", paid=False)            # 5000/ano → 416.67
    await add_sub(c, "tkflix-mensal", status=SubStatus.suspended, paid=False)
    async with dbs() as db:
        product_id = (await db.get(Plan, 1)).product_id
        db.add(Plan(product_id=product_id, code="semanal", name="Semanal", price_cents=100, interval_unit="week"))
        db.add(Payment(user_id=a.id, provider="gocardless", provider_payment_id="P1", amount_cents=500,
                       status="paid", charge_date=utcnow()))
        db.add(Payment(user_id=a.id, provider="gocardless", provider_payment_id="P2", amount_cents=500,
                       status="failed", charge_date=utcnow()))
        await db.commit()
    d = await create_user("dan")
    await add_sub(d, "semanal", paid=False)                 # 100/semana → 433.33
    r = await admin_client.get("/api/admin/stats")
    s = r.json()
    assert s["users"] == 5  # 4 + admin
    assert s["mrr_cents"] == round(500 + 5000 / 12 + 100 * 52 / 12)
    assert s["revenue_30d_cents"] == 500 and s["failed_payments_30d"] == 1
    assert s["by_status"] == {"active": 3, "suspended": 1}
    assert s["by_plan"] == {"TKFLIX": 1, "TKFLIX Anual": 1, "Semanal": 1}
    assert s["by_provider"] == {"portal": 3}
    assert sum(s["new_subscriptions_by_month"].values()) == 4
    assert s["invoices_unpaid"] == 0 and s["payment_methods"] == {}
    # ofertas manuais aparecem à parte e não contam para o MRR; métodos e cobranças por pagar por fornecedor
    e = await create_user("eva")
    await add_sub(e, "tkflix-mensal", provider="manual", paid=False)
    async with dbs() as db:
        from app.models import Invoice, PaymentMethod

        db.add(PaymentMethod(user_id=a.id, provider="gocardless", provider_ref="MD1", label="SEPA", status="active"))
        db.add(PaymentMethod(user_id=b.id, provider="stripe", provider_ref="pm_1", label="Visa", status="unusable"))
        db.add(Invoice(user_id=a.id, number="C2026-00001", status="failed", total_cents=500, subtotal_cents=500))
        await db.commit()
    s = (await admin_client.get("/api/admin/stats")).json()
    assert s["by_provider"] == {"portal": 3, "manual": 1}
    assert s["mrr_cents"] == round(500 + 5000 / 12 + 100 * 52 / 12)
    assert s["payment_methods"] == {"gocardless": {"active": 1}, "stripe": {"unusable": 1}}
    assert s["invoices_unpaid"] == 1 and s["invoices_unpaid_cents"] == 500


async def test_users_list_filters_and_patch(admin_client, admin):
    a = await create_user("ana", email="ana@example.com")
    await create_user("bea", is_active=False)
    await add_sub(a)
    r = await admin_client.get("/api/admin/users", params={"q": "ANA"})
    assert [u["username"] for u in r.json()["items"]] == ["ana"]
    assert r.json()["items"][0]["subscription"]["status"] == "active"
    assert (await admin_client.get("/api/admin/users", params={"status": "blocked"})).json()["total"] == 1
    assert (await admin_client.get("/api/admin/users", params={"status": "active"})).json()["total"] == 1
    assert (await admin_client.get("/api/admin/users", params={"status": "admin"})).json()["total"] == 1
    assert (await admin_client.get("/api/admin/users", params={"status": "no_subscription"})).json()["total"] == 2

    r = await admin_client.patch(f"/api/admin/users/{a.id}", json={"email": "Nova-Ana@example.com"})
    assert r.status_code == 200
    r = await admin_client.patch(f"/api/admin/users/{a.id}", json={"email": "bea@example.com"})
    assert r.status_code == 400
    r = await admin_client.patch(f"/api/admin/users/{admin.id}", json={"is_admin": False})
    assert r.status_code == 400
    r = await admin_client.patch(f"/api/admin/users/{admin.id}", json={"is_active": False})
    assert r.status_code == 400
    r = await admin_client.patch(f"/api/admin/users/{a.id}", json={"admin_notes": "VIP", "email_verified": False})
    assert r.status_code == 200
    u = await get(User, a.id)
    assert u.admin_notes == "VIP" and u.email_verified_at is None and u.email == "nova-ana@example.com"
    assert (await admin_client.get("/api/admin/users/naoexiste")).status_code == 404


async def test_block_user_revokes_sessions(admin_client, make_client):
    u = await create_user("maria")
    c = make_client()
    await c.login_as(u)
    await admin_client.patch(f"/api/admin/users/{u.id}", json={"is_active": False})
    assert (await c.get("/api/auth/me")).status_code == 401


async def test_admin_password_reset_and_sessions(admin_client, make_client):
    u = await create_user("maria")
    c = make_client()
    await c.login_as(u)
    r = await admin_client.post(f"/api/admin/users/{u.id}/password-reset")
    assert r.status_code == 200 and "maria@example.com" in r.json()["message"]
    assert await emails("reset_password", to="maria@example.com")
    r = await admin_client.post(f"/api/admin/users/{u.id}/sessions/revoke")
    assert r.json()["message"] == "1 sessões terminadas."
    assert (await c.get("/api/auth/me")).status_code == 401


async def test_oidc_client_create_secret_once_and_usable(admin_client, make_client):
    r = await admin_client.post("/api/admin/oidc-clients", json={
        "client_id": "grafana", "name": "Grafana", "redirect_uris": ["https://grafana.portal.test/login/generic_oauth"],
        "required_access": "admin"})
    assert r.status_code == 200
    created = r.json()
    secret = created["client_secret"]
    assert secret and created["public"] is False
    listing = (await admin_client.get("/api/admin/oidc-clients")).json()
    assert listing["issuer"] == "https://portal.test"
    assert all("client_secret" not in c for c in listing["clients"])
    row = await fetch_one(OIDCClient, client_id="grafana")
    assert row.secret_hash != secret and row.secret_hash.startswith("$argon2")
    r = await admin_client.post("/api/admin/oidc-clients", json={
        "client_id": "grafana", "name": "Dup", "redirect_uris": ["https://x"]})
    assert r.status_code == 400

    # o admin (sessão do admin_client) faz o fluxo completo com o segredo devolvido
    r = await admin_client.get("/oidc/authorize", params={
        "response_type": "code", "client_id": "grafana", "scope": "openid profile",
        "redirect_uri": "https://grafana.portal.test/login/generic_oauth", "state": "s"})
    from urllib.parse import parse_qs, urlparse

    code = parse_qs(urlparse(r.headers["location"]).query)["code"][0]
    rp = make_client(csrf=False)
    auth = base64.b64encode(f"grafana:{secret}".encode()).decode()
    r = await rp.post("/oidc/token", data={"grant_type": "authorization_code", "code": code,
                                           "redirect_uri": "https://grafana.portal.test/login/generic_oauth"},
                      headers={"Authorization": f"Basic {auth}"})
    assert r.status_code == 200 and r.json()["id_token"]

    # rodar o segredo invalida o antigo
    r = await admin_client.post("/api/admin/oidc-clients/grafana/rotate-secret")
    new_secret = r.json()["client_secret"]
    assert new_secret != secret
    r = await rp.post("/oidc/token", data={"grant_type": "refresh_token", "refresh_token": "x",
                                           "client_id": "grafana", "client_secret": secret})
    assert r.status_code == 401

    # cliente público: sem segredo e PKCE obrigatório
    r = await admin_client.post("/api/admin/oidc-clients", json={
        "client_id": "spa", "name": "SPA", "redirect_uris": ["https://spa.portal.test/cb"], "public": True})
    assert r.json()["client_secret"] is None and r.json()["require_pkce"] is True
    r = await admin_client.post("/api/admin/oidc-clients/spa/rotate-secret")
    assert r.status_code == 400
    assert (await admin_client.delete("/api/admin/oidc-clients/spa")).status_code == 200


async def test_admin_invites(admin_client, make_client):
    r = await admin_client.post("/api/admin/invites", json={"max_uses": 3, "days": 7, "code": "amigos-2026"})
    assert r.status_code == 200 and r.json()["code"] == "AMIGOS-2026"
    assert r.json()["link"] == "https://portal.test/registar?convite=AMIGOS-2026"
    r = await admin_client.post("/api/admin/invites", json={"code": "Amigos-2026"})
    assert r.status_code == 400
    inv = await fetch_one(InviteCode)
    r = await make_client().post("/api/auth/register", json={
        "username": "convidado", "email": "c@example.com", "password": "Uma-Pass-Boa-1", "invite_code": "amigos-2026"})
    assert r.status_code == 200
    rows = (await admin_client.get("/api/admin/invites")).json()
    assert rows[0]["uses"] == 1 and rows[0]["created_by"] == "chefe"
    assert (await admin_client.delete(f"/api/admin/invites/{inv.id}")).status_code == 200
    r = await make_client().post("/api/auth/register", json={
        "username": "outro", "email": "o@example.com", "password": "Uma-Pass-Boa-1", "invite_code": "AMIGOS-2026"})
    assert r.status_code == 400


async def test_jobs_listing_hides_secrets_and_retry(admin_client, svc):
    from app.services.provisioning import queue_jellyfin_password

    u = await create_user("maria")
    svc.jf.down = True
    async with dbs() as db:
        await queue_jellyfin_password(db, await db.get(User, u.id), "Segredo-123")
        await db.commit()
    await drain()
    rows = (await admin_client.get("/api/admin/jobs", params={"kind": "jellyfin_set_password"})).json()
    [item] = rows["items"]
    assert "password_enc" not in item["payload"] and item["payload"]["user_id"] == u.id
    assert item["status"] == "pending" and item["attempts"] == 1
    svc.jf.down = False
    r = await admin_client.post(f"/api/admin/jobs/{item['id']}/retry")
    assert r.status_code == 200
    job = await get(Job, item["id"])
    assert job.attempts == 0 and job.run_after <= utcnow()
    await drain()
    assert (await get(Job, item["id"])).status == "done"
    assert svc.jf.by_name("maria") is not None


async def test_webhook_listing_and_replay(admin_client, svc, client):
    await post_gc_webhook(client, [gc_event("mandates", "created", mandate="MD1")])
    await drain()
    rows = (await admin_client.get("/api/admin/webhooks", params={"provider": "gocardless"})).json()
    assert rows[0]["status"] == "ignored"  # mandato que não é de nenhum cliente
    detail = (await admin_client.get(f"/api/admin/webhooks/{rows[0]['id']}")).json()
    assert detail["payload"]["resource_type"] == "mandates"
    r = await admin_client.post(f"/api/admin/webhooks/{rows[0]['id']}/replay")
    assert r.status_code == 200
    assert len(await jobs_of("process_webhook", "pending")) == 1
    await drain()


async def test_site_settings(admin_client, client):
    r = await admin_client.put("/api/admin/settings", json={"nao_existe": 1})
    assert r.status_code == 400
    r = await admin_client.put("/api/admin/settings", json={"announcement": "Manutenção às 3h",
                                                            "support_email": "ajuda@portal.test"})
    assert r.status_code == 200
    cfg = (await client.get("/api/auth/config")).json()
    assert cfg["site"]["announcement"] == "Manutenção às 3h" and cfg["site"]["support_email"] == "ajuda@portal.test"
    assert cfg["site"]["apps"]  # defaults mantidos
    r = await admin_client.put("/api/admin/settings", json={"announcement": None})
    assert (await client.get("/api/auth/config")).json()["site"]["announcement"] is None


async def test_admin_cancel_manual_subscription(admin_client, svc):
    u = await create_user("maria")
    sub = await add_sub(u, provider="manual")
    r = await admin_client.post(f"/api/admin/subscriptions/{sub.id}/cancel", json={})
    assert r.status_code == 200
    assert (await get(Subscription, sub.id)).status == SubStatus.ended


async def test_admin_reconcile_now(admin_client, svc):
    u = await create_user("maria")
    await add_sub(u)
    r = await admin_client.post(f"/api/admin/users/{u.id}/reconcile")
    assert r.json()["ok"] is True and r.json()["result"]["jellyfin"] == "updated"
    svc.jf.down = True
    r = await admin_client.post(f"/api/admin/users/{u.id}/reconcile")
    assert r.json()["ok"] is False and "503" in r.json()["error"]
    assert await jobs_of("reconcile_user", "pending")


async def test_integrations_health(admin_client, svc):
    rows = {x["name"]: x for x in (await admin_client.get("/api/admin/integrations")).json()}
    assert rows["jellyfin"]["ok"] and rows["jellyfin"]["info"]["version"] == "12.0.0"
    assert rows["seerr"]["ok"] and rows["dispatcharr"]["ok"] and rows["gocardless"]["ok"]
    assert rows["stripe"]["ok"] and rows["stripe"]["info"]["live"] is False
    assert rows["smtp"] == {"name": "smtp", "configured": False}
    svc.jf.down = True
    rows = {x["name"]: x for x in (await admin_client.get("/api/admin/integrations")).json()}
    assert rows["jellyfin"]["ok"] is False


async def test_audit_log(admin_client):
    u = await create_user("maria")
    await admin_client.patch(f"/api/admin/users/{u.id}", json={"admin_notes": "segredo"})
    rows = (await admin_client.get("/api/admin/audit", params={"action": "admin."})).json()
    assert rows[0]["action"] == "admin.user_updated" and rows[0]["actor"] == "chefe"
    assert "admin_notes" not in rows[0]["details"]["changes"]


async def test_admin_unlink_and_libraries(admin_client, svc):
    u = await create_user("maria")
    jf_user = await link_jf(svc, u)
    libs = (await admin_client.get("/api/admin/jellyfin/libraries")).json()
    assert libs == [{"id": "lib1", "name": "Filmes", "type": "movies"}]

    r = await admin_client.post(f"/api/admin/users/{u.id}/unlink/jellyfin")
    assert r.status_code == 200
    assert (await admin_client.post(f"/api/admin/users/{u.id}/unlink/jellyfin")).status_code == 404
    assert jf_user["Id"] in svc.jf.users  # só desliga no portal


async def test_admin_cancel_immediately_and_at_period_end(admin_client, svc, client):
    from test_gocardless import gc_subscribe

    u = await create_user("maria")
    jf_user = await link_jf(svc, u)
    sub = await gc_subscribe(client, svc, u)
    r = await admin_client.post(f"/api/admin/subscriptions/{sub.id}/cancel", json={})
    assert r.status_code == 200
    s = await get(Subscription, sub.id)
    assert s.status == SubStatus.canceling and s.access_until == s.current_period_end
    r = await admin_client.post(f"/api/admin/subscriptions/{sub.id}/cancel", json={"immediately": True})
    assert r.status_code == 200
    assert (await get(Subscription, sub.id)).status == SubStatus.ended
    await drain()
    assert svc.jf.users[jf_user["Id"]]["Policy"]["IsDisabled"] is True
    assert (await admin_client.post("/api/admin/subscriptions/nope/cancel", json={})).status_code == 404


async def test_admin_update_product_and_oidc_client(admin_client):
    r = await admin_client.put("/api/admin/products/1", json={"code": "tkflix", "name": "TKFLIX Novo",
                                                              "is_active": False})
    assert r.status_code == 200
    assert (await admin_client.get("/api/catalog")).json() == []
    assert (await admin_client.put("/api/admin/products/999", json={"code": "x1", "name": "x"})).status_code == 404
    r = await admin_client.post("/api/admin/plans", json={"product_id": 1, "code": "moeda", "name": "x",
                                                          "price_cents": 1, "currency": "EURO"})
    assert r.status_code == 422
    r = await admin_client.post("/api/admin/plans", json={"product_id": 1, "code": "moeda", "name": "x",
                                                          "price_cents": 1, "currency": "usd"})
    assert (await get(Plan, r.json()["id"])).currency == "USD"

    await admin_client.post("/api/admin/oidc-clients", json={
        "client_id": "app1", "name": "App", "redirect_uris": ["https://a.portal.test/cb"]})
    r = await admin_client.put("/api/admin/oidc-clients/app1", json={
        "client_id": "app1", "name": "App 2", "redirect_uris": ["https://b.portal.test/cb"],
        "required_access": "feature:jellyfin", "is_active": False})
    assert r.status_code == 200
    c = await fetch_one(OIDCClient, client_id="app1")
    assert c.name == "App 2" and c.redirect_uris == ["https://b.portal.test/cb"] and not c.is_active
    assert c.required_access == "feature:jellyfin"
    assert (await admin_client.delete("/api/admin/oidc-clients/app1")).status_code == 200
    assert (await admin_client.delete("/api/admin/oidc-clients/app1")).status_code == 404
