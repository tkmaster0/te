from __future__ import annotations

import hashlib
import secrets
from urllib.parse import parse_qs, urlparse

import pyotp
import pytest
from conftest import (
    PASSWORD,
    create_user,
    drain,
    emails,
    fetch,
    fetch_one,
    get,
    jobs_of,
)

from app.deps import reset_rate_limits
from app.models import InviteCode, Job, LoginSession, User
from app.security import decrypt


async def make_invite(code="TK-TEST-0001", max_uses=1, creator: User | None = None, **kw) -> InviteCode:
    from conftest import dbs

    async with dbs() as db:
        inv = InviteCode(code=code, max_uses=max_uses, created_by_id=creator.id if creator else None, **kw)
        db.add(inv)
        await db.commit()
        return inv


def token_from(cta_url: str) -> str:
    return parse_qs(urlparse(cta_url).query)["token"][0]


async def register(client, username="novato", email=None, password=PASSWORD, invite="TK-TEST-0001", **kw):
    return await client.post("/api/auth/register", json={
        "username": username, "email": email or f"{username}@example.com", "password": password,
        "invite_code": invite, **kw})


# --------------------------------------------------------------------------- registo
async def test_register_requires_valid_invite(client):
    r = await register(client, invite=None)
    assert r.status_code == 400
    assert "convite" in r.json()["detail"].lower()
    r = await register(client, invite="NAO-EXISTE")
    assert r.status_code == 400


async def test_first_user_becomes_admin_and_invite_uses_counted(make_client):
    await make_invite(max_uses=2)
    c1, c2, c3 = make_client(), make_client(), make_client()
    r = await register(c1, "primeiro")
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["status"] == "ok" and body["user"]["is_admin"] is True
    assert body["user"]["email_verified"] is False
    r = await register(c2, "segundo", invite="tk-test-0001")  # case-insensitive
    assert r.status_code == 200, r.text
    assert r.json()["user"]["is_admin"] is False
    inv = await fetch_one(InviteCode, code="TK-TEST-0001")
    assert inv.uses == 2
    r = await register(c3, "terceiro")
    assert r.status_code == 400  # convite esgotado


async def test_register_links_referrer(client, admin):
    await make_invite(creator=admin)
    r = await register(client, "afilhado")
    assert r.status_code == 200
    assert r.json()["user"]["referred_by"] == admin.username
    u = await fetch_one(User, username="afilhado")
    assert u.referred_by_id == admin.id and u.invite_code_id is not None


async def test_invite_of_blocked_creator_is_invalid(client):
    creator = await create_user("bloqueado", is_active=False)
    await make_invite(creator=creator)
    r = await client.get("/api/auth/invite/TK-TEST-0001")
    assert r.json() == {"valid": False}
    assert (await register(client)).status_code == 400


async def test_check_invite_shows_inviter(client, admin):
    await make_invite(creator=admin)
    r = await client.get("/api/auth/invite/tk-test-0001")
    assert r.json() == {"valid": True, "inviter": "chefe", "unlocks": ["TKFLIX Streaming"]}


@pytest.mark.parametrize("username,expected", [
    ("a b", 400), ("-abc", 400), ("admin", 400), ("jellyfin", 400), ("ok_nome.1", 200), ("MAIUSC", 200),
])
async def test_username_rules(client, username, expected):
    await make_invite()
    r = await register(client, username, email="x@example.com")
    assert r.status_code == expected, r.text
    if expected == 200:
        assert r.json()["user"]["username"] == username.lower()


async def test_username_too_short_is_validation_error(client):
    await make_invite()
    r = await register(client, "ab")
    assert r.status_code == 422


async def test_duplicate_username_and_email(client):
    await create_user("existente", email="existe@example.com")
    await make_invite(max_uses=5)
    r = await register(client, "existente", email="outro@example.com")
    assert r.status_code == 400 and "uso" in r.json()["detail"]
    r = await register(client, "novo", email="EXISTE@example.com")
    assert r.status_code == 400 and "email" in r.json()["detail"]
    inv = await fetch_one(InviteCode, code="TK-TEST-0001")
    assert inv.uses == 0


async def test_username_taken_in_jellyfin(client, svc):
    svc.jf.add_user("Zeca")
    r = await client.get("/api/auth/check-username", params={"u": "zeca"})
    assert r.json()["available"] is False
    r = await client.get("/api/auth/check-username", params={"u": "zeca2"})
    assert r.json() == {"available": True, "reason": None}
    await make_invite()
    r = await register(client, "zeca")
    assert r.status_code == 400


async def test_register_refused_when_jellyfin_unreachable(client, svc):
    """Sem confirmar no Jellyfin, um registo poderia apropriar-se de uma conta Jellyfin existente."""
    svc.jf.add_user("antigo")
    svc.jf.down = True
    await make_invite()
    r = await register(client, "antigo")
    assert r.status_code == 503
    assert (await fetch_one(InviteCode, code="TK-TEST-0001")).uses == 0
    r = await client.get("/api/auth/check-username", params={"u": "antigo"})
    assert r.json()["available"] is False


async def test_weak_password_rejected(client):
    await make_invite()
    r = await register(client, "fraco", password="fraco123456")
    assert r.status_code == 400 and "username" in r.json()["detail"]
    r = await register(client, "fraco", password="password1")
    assert r.status_code == 400


async def test_open_registration_mode(client, settings):
    settings.set("registration_mode", "open")
    r = await register(client, "livre", invite=None)
    assert r.status_code == 200


# --------------------------------------------------------------------------- verificação de email
async def test_email_verification_token_single_use(client):
    await make_invite()
    await register(client, "verifica")
    [mail] = await emails("verify_email")
    assert mail["to"] == "verifica@example.com"
    tok = token_from(mail["ctx"]["cta_url"])
    assert (await client.get("/api/auth/me")).json()["email_verified"] is False
    r = await client.post("/api/auth/verify-email", json={"token": tok})
    assert r.status_code == 200
    assert (await client.get("/api/auth/me")).json()["email_verified"] is True
    r = await client.post("/api/auth/verify-email", json={"token": tok})
    assert r.status_code == 400


async def test_unverified_user_cannot_subscribe_or_add_payment_method(client):
    u = await create_user("naoverif", verified=False)
    await client.login_as(u)
    r = await client.post("/api/billing/subscribe", json={"plan_id": 1, "provider": "gocardless"})
    assert r.status_code == 403
    r = await client.post("/api/billing/payment-methods", json={"provider": "stripe"})
    assert r.status_code == 403
    r = await client.post("/api/billing/invoices/x/pay", json={})
    assert r.status_code == 403


async def test_resend_verification_invalidates_previous(client):
    u = await create_user("reenvio", verified=False)
    await client.login_as(u)
    assert (await client.post("/api/auth/resend-verification")).status_code == 200
    assert (await client.post("/api/auth/resend-verification")).status_code == 200
    first, second = await emails("verify_email")
    r = await client.post("/api/auth/verify-email", json={"token": token_from(first["ctx"]["cta_url"])})
    assert r.status_code == 400
    r = await client.post("/api/auth/verify-email", json={"token": token_from(second["ctx"]["cta_url"])})
    assert r.status_code == 200


# --------------------------------------------------------------------------- login
async def test_login_by_email_or_username(make_client):
    await create_user("maria", email="maria@example.com")
    c = make_client()
    r = await c.login("maria")
    assert r.status_code == 200 and r.json()["status"] == "ok" and r.json()["redirect"] == "/app"
    assert "tk_session" in r.headers["set-cookie"] and "httponly" in r.headers["set-cookie"].lower()
    assert (await c.get("/api/auth/me")).json()["username"] == "maria"
    c2 = make_client()
    r = await c2.login("  MARIA@example.com ")
    assert r.status_code == 200
    u = await fetch_one(User, username="maria")
    assert u.last_login_at is not None


async def test_wrong_password_and_unknown_user(client):
    await create_user("maria")
    r = await client.login("maria", "errada-123")
    assert r.status_code == 401 and r.json()["detail"] == "Credenciais inválidas."
    r = await client.login("ninguem", "errada-123")
    assert r.status_code == 401
    assert (await client.get("/api/auth/me")).status_code == 401


async def test_blocked_user_cannot_login(client):
    await create_user("bloq", is_active=False)
    r = await client.login("bloq")
    assert r.status_code == 403


async def test_login_rate_limited(client):
    await create_user("maria")
    codes = [(await client.login("maria", "errada-123")).status_code for _ in range(11)]
    assert codes[:10] == [401] * 10
    assert codes[10] == 429
    r = await client.login("maria")
    assert r.status_code == 429 and "Retry-After" in r.headers


async def test_csrf_header_required(make_client):
    await create_user("maria")
    c = make_client(csrf=False)
    r = await c.login("maria")
    assert r.status_code == 403 and "CSRF" in r.json()["detail"]
    # GET não precisa
    assert (await c.get("/api/auth/config")).status_code == 200
    # webhooks e integrações estão isentos (autenticam-se de outra forma)
    r = await c.post("/api/webhooks/gocardless", content=b"{}")
    assert r.status_code == 498


async def test_logout(client):
    await create_user("maria")
    await client.login("maria")
    assert (await client.get("/api/auth/me")).status_code == 200
    r = await client.post("/api/auth/logout")
    assert r.status_code == 200
    assert (await client.get("/api/auth/me")).status_code == 401
    sess = await fetch_one(LoginSession)
    assert sess.revoked_at is not None


async def test_session_listing_and_revoke(make_client):
    await create_user("maria")
    a, b = make_client(), make_client()
    await a.login("maria")
    await b.login("maria")
    rows = (await a.get("/api/account/sessions")).json()
    assert len(rows) == 2
    current = [r for r in rows if r["current"]]
    other = [r for r in rows if not r["current"]]
    assert len(current) == 1 and len(other) == 1
    r = await a.delete(f"/api/account/sessions/{other[0]['id']}")
    assert r.status_code == 200
    assert (await b.get("/api/auth/me")).status_code == 401
    assert (await a.get("/api/auth/me")).status_code == 200
    # não é possível revogar sessões de outro utilizador
    await create_user("joao")
    c = make_client()
    await c.login("joao")
    r = await c.delete(f"/api/account/sessions/{current[0]['id']}")
    assert r.status_code == 404


async def test_revoke_other_sessions(make_client):
    await create_user("maria")
    a, b, c = make_client(), make_client(), make_client()
    for x in (a, b, c):
        await x.login("maria")
    r = await a.post("/api/account/sessions/revoke-others")
    assert r.json()["message"] == "2 sessões terminadas."
    assert (await b.get("/api/auth/me")).status_code == 401
    assert (await a.get("/api/auth/me")).status_code == 200


async def test_session_expired_or_idle(client):
    from datetime import timedelta

    from app.db import utcnow

    u = await create_user("maria")
    token = await client.login_as(u)
    from app.security import token_hash
    from conftest import update_row

    await update_row(LoginSession, token_hash(token), last_seen_at=utcnow() - timedelta(days=4))
    assert (await client.get("/api/auth/me")).status_code == 401


# --------------------------------------------------------------------------- 2FA
async def _enable_2fa(client) -> tuple[str, list[str]]:
    r = await client.post("/api/account/2fa/setup")
    assert r.status_code == 200
    data = r.json()
    assert data["otpauth_uri"].startswith("otpauth://totp/") and "<svg" in data["qr_svg"]
    secret = data["secret"]
    r = await client.post("/api/account/2fa/enable", json={"code": "000000"})
    assert r.status_code == 400
    r = await client.post("/api/account/2fa/enable", json={"code": pyotp.TOTP(secret).now()})
    assert r.status_code == 200, r.text
    codes = r.json()["recovery_codes"]
    assert len(codes) == 10
    return secret, codes


async def test_2fa_login_flow_with_totp_and_recovery(make_client):
    await create_user("segura")
    c = make_client()
    await c.login("segura")
    secret, codes = await _enable_2fa(c)
    assert (await c.get("/api/auth/me")).json()["totp_enabled"] is True

    d = make_client()
    r = await d.login("segura", next="/app/conta")
    assert r.json() == {"status": "mfa_required", "redirect": None, "user": None}
    assert (await d.get("/api/auth/me")).status_code == 401  # sessão pendente não dá acesso
    assert (await d.post("/api/auth/2fa", json={"code": "123456"})).status_code == 401
    r = await d.post("/api/auth/2fa", json={"code": pyotp.TOTP(secret).now(), "next": "/app/conta"})
    assert r.status_code == 200 and r.json()["redirect"] == "/app/conta"
    assert (await d.get("/api/auth/me")).status_code == 200

    # código de recuperação: uso único
    e = make_client()
    await e.login("segura")
    r = await e.post("/api/auth/2fa", json={"code": codes[0].upper()})
    assert r.status_code == 200
    f = make_client()
    await f.login("segura")
    r = await f.post("/api/auth/2fa", json={"code": codes[0]})
    assert r.status_code == 401
    u = await fetch_one(User, username="segura")
    assert len(u.recovery_codes) == 9


async def test_2fa_endpoint_requires_pending_session(client):
    u = await create_user("maria")
    await client.login_as(u)
    r = await client.post("/api/auth/2fa", json={"code": "123456"})
    assert r.status_code == 401


async def test_2fa_bruteforce_rate_limited(make_client):
    await create_user("segura")
    c = make_client()
    await c.login("segura")
    await _enable_2fa(c)
    d = make_client()
    await d.login("segura")
    statuses = [(await d.post("/api/auth/2fa", json={"code": "000000"})).status_code for _ in range(7)]
    assert statuses[:6] == [401] * 6 and statuses[6] == 429


async def test_2fa_disable_and_regenerate(client):
    await create_user("segura")
    await client.login("segura")
    secret, codes = await _enable_2fa(client)
    r = await client.post("/api/account/2fa/recovery-codes", json={"password": "errada"})
    assert r.status_code == 400
    r = await client.post("/api/account/2fa/recovery-codes", json={"password": PASSWORD})
    new_codes = r.json()["recovery_codes"]
    assert set(new_codes).isdisjoint(codes)
    r = await client.post("/api/account/2fa/disable", json={"password": PASSWORD, "code": codes[0]})
    assert r.status_code == 400  # os antigos já não valem
    r = await client.post("/api/account/2fa/disable", json={"password": PASSWORD, "code": new_codes[0]})
    assert r.status_code == 200
    u = await fetch_one(User, username="segura")
    assert not u.totp_enabled and u.totp_secret_enc is None and u.recovery_codes is None


# --------------------------------------------------------------------------- reset de password
async def test_password_reset_flow(make_client, svc):
    u = await create_user("esquecido")
    jf_user = svc.jf.add_user("esquecido")
    from conftest import dbs

    from app.models import ServiceAccount

    async with dbs() as db:
        db.add(ServiceAccount(user_id=u.id, service="jellyfin", external_id=jf_user["Id"],
                              external_username="esquecido"))
        await db.commit()
    logged = make_client()
    await logged.login("esquecido")
    anon = make_client()
    r = await anon.post("/api/auth/forgot", json={"email": "ESQUECIDO@example.com"})
    assert r.status_code == 200
    r = await anon.post("/api/auth/forgot", json={"email": "naoexiste@example.com"})
    assert r.status_code == 200  # não revela se o email existe
    [mail] = await emails("reset_password")
    tok = token_from(mail["ctx"]["cta_url"])

    r = await anon.post("/api/auth/reset", json={"token": tok, "password": "curta"})
    assert r.status_code == 422
    r = await anon.post("/api/auth/reset", json={"token": tok, "password": "esquecido-123"})
    assert r.status_code == 400  # contém o username → token continua válido
    new_pw = "Nova-Password-99"
    r = await anon.post("/api/auth/reset", json={"token": tok, "password": new_pw})
    assert r.status_code == 200, r.text
    r = await anon.post("/api/auth/reset", json={"token": tok, "password": "Outra-Password-99"})
    assert r.status_code == 400  # uso único

    assert (await logged.get("/api/auth/me")).status_code == 401  # sessões revogadas
    [job] = await jobs_of("jellyfin_set_password")
    assert new_pw not in str(job.payload)
    assert decrypt(job.payload["password_enc"]) == new_pw
    assert await emails("password_changed")
    await drain()
    job = await get(Job, job.id)
    assert job.status == "done"
    assert job.payload["password_enc"] == "<removido>"
    assert svc.jf.passwords[jf_user["Id"]] == new_pw
    assert (await anon.login("esquecido", new_pw)).status_code == 200
    assert (await make_client().login("esquecido")).status_code == 401


async def test_change_password_logs_out_others(make_client):
    await create_user("maria")
    a, b = make_client(), make_client()
    await a.login("maria")
    await b.login("maria")
    r = await a.post("/api/account/password", json={"current_password": "errada", "new_password": "Nova-Pass-123"})
    assert r.status_code == 400
    r = await a.post("/api/account/password", json={"current_password": PASSWORD, "new_password": "Nova-Pass-123"})
    assert r.status_code == 200
    assert (await a.get("/api/auth/me")).status_code == 200
    assert (await b.get("/api/auth/me")).status_code == 401
    assert await jobs_of("jellyfin_set_password")


# --------------------------------------------------------------------------- alteração de email
async def test_email_change_confirm(make_client, svc):
    u = await create_user("maria", email="maria@example.com")
    other = await create_user("joao", email="joao@example.com")
    c = make_client()
    await c.login_as(u)
    r = await c.post("/api/account/email", json={"new_email": "joao@example.com", "password": PASSWORD})
    assert r.status_code == 400
    r = await c.post("/api/account/email", json={"new_email": "maria@example.com", "password": PASSWORD})
    assert r.status_code == 400
    r = await c.post("/api/account/email", json={"new_email": "Nova@Example.com", "password": "errada"})
    assert r.status_code == 400
    r = await c.post("/api/account/email", json={"new_email": "Nova@Example.com", "password": PASSWORD})
    assert r.status_code == 429  # 3 pedidos por hora
    reset_rate_limits()
    r = await c.post("/api/account/email", json={"new_email": "Nova@Example.com", "password": PASSWORD})
    assert r.status_code == 200
    [mail] = await emails("change_email")
    assert mail["to"] == "nova@example.com"
    tok = token_from(mail["ctx"]["cta_url"])
    r = await make_client().post("/api/account/email/confirm", json={"token": tok})
    assert r.status_code == 200
    assert (await get(User, u.id)).email == "nova@example.com"
    notice = await emails("admin_notice", to="maria@example.com")
    assert notice and "nova@example.com" in notice[0]["ctx"]["message"]
    assert await jobs_of("reconcile_user")
    r = await make_client().post("/api/account/email/confirm", json={"token": tok})
    assert r.status_code == 400
    assert other.email == "joao@example.com"


async def test_email_change_race_other_account_took_email(make_client):
    u = await create_user("maria")
    c = make_client()
    await c.login_as(u)
    await c.post("/api/account/email", json={"new_email": "disputado@example.com", "password": PASSWORD})
    [mail] = await emails("change_email")
    await create_user("rapido", email="disputado@example.com")
    r = await c.post("/api/account/email/confirm", json={"token": token_from(mail["ctx"]["cta_url"])})
    assert r.status_code == 400


# --------------------------------------------------------------------------- passwords do site antigo
def werkzeug_pbkdf2(password: str, iterations: int = 600000) -> str:
    salt = secrets.token_hex(8)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), iterations)
    return f"pbkdf2:sha256:{iterations}${salt}${dk.hex()}"


def werkzeug_scrypt(password: str) -> str:
    salt = secrets.token_hex(8)
    dk = hashlib.scrypt(password.encode(), salt=salt.encode(), n=2**15, r=8, p=1, maxmem=132 * 1024 * 1024)
    return f"scrypt:32768:8:1${salt}${dk.hex()}"


@pytest.mark.parametrize("hasher", [werkzeug_pbkdf2, werkzeug_scrypt])
async def test_legacy_werkzeug_hash_login_and_rehash(make_client, hasher):
    from conftest import dbs

    async with dbs() as db:
        db.add(User(username="antigo", email="antigo@example.com", password_hash=hasher("velha-pass-1"),
                    email_verified_at=None))
        await db.commit()
    r = await make_client().login("antigo", "errada-000")
    assert r.status_code == 401
    assert not (await fetch_one(User, username="antigo")).password_hash.startswith("$argon2")
    r = await make_client().login("antigo", "velha-pass-1")
    assert r.status_code == 200
    u = await fetch_one(User, username="antigo")
    assert u.password_hash.startswith("$argon2")
    assert (await make_client().login("antigo", "velha-pass-1")).status_code == 200


async def test_needs_password_sync_queues_jellyfin_password_on_login(client):
    await create_user("sync", needs_password_sync=True)
    await client.login("sync")
    [job] = await jobs_of("jellyfin_set_password")
    assert decrypt(job.payload["password_enc"]) == PASSWORD
    assert not (await fetch_one(User, username="sync")).needs_password_sync


async def test_public_config(client):
    r = await client.get("/api/auth/config")
    body = r.json()
    assert body["registration_mode"] == "invite"
    assert body["providers"] == {"gocardless": True, "stripe": True}
    assert body["jellyfin_url"] == "https://tv.test"
    assert body["bonus"]["threshold"] == 3


async def test_single_use_invite_cannot_be_used_twice_concurrently(make_client):
    import asyncio

    await make_invite(max_uses=1)
    clients = [make_client() for _ in range(3)]
    results = await asyncio.gather(*[register(c, f"corrida{i}", email=f"corrida{i}@example.com")
                                     for i, c in enumerate(clients)])
    codes = sorted(r.status_code for r in results)
    assert codes == [200, 400, 400], [r.text for r in results]
    assert (await fetch_one(InviteCode, code="TK-TEST-0001")).uses == 1
    assert len(await fetch(User)) == 1
