"""Sessões limitadas ao streaming (abertas a partir do Jellyfin com o link mágico)."""
from __future__ import annotations

import pytest
from conftest import (
    add_method,
    add_sub,
    create_user,
    dt,
    fetch_one,
    get,
    make_product,
    plan_by_code,
    subscribe_api,
)
from test_oidc import auth_params, oidc_clients, qs  # noqa: F401 (fixture)

from app.models import Checkout, Subscription, SubStatus

FULL_ONLY = [
    ("GET", "/api/billing/invoices"), ("GET", "/api/billing/payments"), ("GET", "/api/billing/payment-methods/x"),
    ("POST", "/api/billing/payment-methods"), ("POST", "/api/billing/invoices/x/pay"),
    ("DELETE", "/api/billing/payment-methods/x"), ("GET", "/api/account/sessions"), ("POST", "/api/account/password"),
    ("POST", "/api/account/2fa/setup"), ("PATCH", "/api/account/profile"), ("GET", "/api/services"),
    ("GET", "/api/invites"), ("POST", "/api/invites"), ("GET", "/api/admin/stats"),
]


async def scoped(make_client, svc, name="maria", **kw):
    u = await create_user(name, **kw)
    c = make_client()
    await c.login_as(u, scope="streaming")
    return u, c


@pytest.mark.parametrize("method,path", FULL_ONLY)
async def test_scoped_session_refused_on_normal_endpoints(make_client, svc, method, path):
    _, c = await scoped(make_client, svc, admin=path.startswith("/api/admin"))
    r = await c.request(method, path, json={} if method != "GET" else None)
    assert r.status_code in (403, 405), (path, r.status_code)
    if r.status_code == 403:
        assert r.headers["x-tk-session-scope"] == "streaming"
        assert "Jellyfin" in r.json()["detail"]


async def test_scoped_session_manages_streaming_only(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    _, plans = await make_product("cloud")
    u, c = await scoped(make_client, svc)
    await add_method(svc, u, "stripe")
    cloud = await add_sub(u, "cloud-m")
    me = (await c.get("/api/auth/me")).json()
    assert me["session_scope"] == "streaming"
    assert [p["code"] for p in (await c.get("/api/billing/products")).json()] == ["tkflix"]
    q = await c.get("/api/billing/quote", params={"plan_id": plans["cloud-m"].id})
    assert q.status_code == 403
    q = await c.get("/api/billing/quote", params={"plan_id": (await plan_by_code("tkflix-mensal")).id})
    assert q.status_code == 200 and q.json()["due_now_cents"] == 500

    out = await subscribe_api(c, "tkflix-mensal")
    sub = await get(Subscription, out["subscription_id"])
    assert sub.status == SubStatus.active
    subs = (await c.get("/api/billing/subscriptions")).json()
    assert [s["id"] for s in subs] == [sub.id]  # o outro produto não aparece
    summary = (await c.get("/api/billing/summary")).json()
    assert summary["session_scope"] == "streaming"
    assert {ln["product_id"] for ln in summary["upcoming"]["lines"]} == {sub.product_id}

    # o outro produto não pode ser alterado
    for action in ("cancel", "resume"):
        r = await c.post(f"/api/billing/subscriptions/{cloud.id}/{action}")
        assert r.status_code == 403
    r = await c.post(f"/api/billing/subscriptions/{cloud.id}/change", json={"plan_id": plans["cloud-m"].id})
    assert r.status_code == 403
    assert (await get(Subscription, cloud.id)).status == SubStatus.active

    # o streaming sim
    clock.set(dt(2026, 10, 20, 12))
    tv = await plan_by_code("tkflix-tv-mensal")
    r = await c.post(f"/api/billing/subscriptions/{sub.id}/change", json={"plan_id": tv.id})
    assert r.status_code == 200
    assert (await c.post(f"/api/billing/subscriptions/{sub.id}/cancel")).status_code == 200
    assert (await c.post(f"/api/billing/subscriptions/{sub.id}/resume")).status_code == 200


async def test_scoped_session_subscribe_without_method_returns_to_streaming(make_client, svc):
    u, c = await scoped(make_client, svc)
    out = await subscribe_api(c, "tkflix-mensal", provider="stripe")
    co = await get(Checkout, out["checkout_id"])
    assert co.session_scope == "streaming"
    session = svc.stripe.sessions[co.provider_ref]
    assert session["cancel_url"] == "https://portal.test/app/streaming?cancelado=1"
    svc.stripe.complete_setup(co.provider_ref)
    r = await c.get(f"/api/billing/checkout/{co.id}")
    assert r.json()["status"] == "completed" and r.json()["return_to"] == "/app/streaming"
    assert (await fetch_one(Subscription)).status == SubStatus.active


async def test_scoped_session_not_usable_for_sso_or_forward_auth(make_client, svc, oidc_clients):  # noqa: F811
    u, c = await scoped(make_client, svc)
    await add_sub(u)
    r = await c.get("/oidc/authorize", params=auth_params())
    assert r.status_code == 302 and r.headers["location"].startswith("https://portal.test/login?")
    r = await c.get("/oidc/authorize", params=auth_params(prompt="none"))
    assert r.status_code == 302 and qs(r.headers["location"])["error"] == "login_required"
    r = await c.get("/auth/verify", params={"require": "any_active", "mode": "status"})
    assert r.status_code == 401
    r = await c.get("/auth/verify", params={"require": "any_active"})
    assert r.status_code == 302
    # a mesma pessoa com sessão completa entra
    full = make_client()
    await full.login_as(await get(type(u), u.id))
    assert (await full.get("/auth/verify", params={"require": "any_active", "mode": "status"})).status_code == 200


async def test_scoped_session_can_logout(make_client, svc):
    _, c = await scoped(make_client, svc)
    assert (await c.post("/api/auth/logout")).status_code == 200
    assert (await c.get("/api/auth/me")).status_code == 401
