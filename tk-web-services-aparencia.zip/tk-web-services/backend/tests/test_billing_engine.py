"""Motor de faturação consolidada: datas, pro-ratas e o ciclo mensal (uma cobrança por cliente)."""
from __future__ import annotations

from datetime import timedelta

import pytest
from conftest import (
    add_method,
    add_sub,
    create_user,
    customer,
    cycle,
    dbs,
    drain,
    dt,
    emails,
    fetch,
    fetch_one,
    get,
    jobs_of,
    make_product,
    plan_by_code,
    subscribe_api,
    update_row,
)
from sqlalchemy import select

from app.models import Invoice, InvoiceLine, Plan, Subscription, SubStatus, User
from app.services import billing


async def lines_of(inv_id: str) -> list[InvoiceLine]:
    async with dbs() as db:
        return list((await db.scalars(select(InvoiceLine).where(InvoiceLine.invoice_id == inv_id)
                                      .order_by(InvoiceLine.id))).all())


async def pending(user_id: str) -> list[InvoiceLine]:
    async with dbs() as db:
        return await billing.pending_lines(db, user_id)


# --------------------------------------------------------------------------- datas
def test_anchor_on_uses_billing_hour():
    assert billing.anchor_on(2026, 10, 5) == dt(2026, 10, 5, 6)


@pytest.mark.parametrize("day,after,expected", [
    (5, dt(2026, 10, 5, 5, 59), dt(2026, 10, 5, 6)),
    (5, dt(2026, 10, 5, 6), dt(2026, 11, 5, 6)),       # estritamente depois
    (5, dt(2026, 10, 20), dt(2026, 11, 5, 6)),
    (28, dt(2026, 12, 28, 7), dt(2027, 1, 28, 6)),     # passa o ano
    (28, dt(2027, 1, 30), dt(2027, 2, 28, 6)),
    (1, dt(2026, 12, 31, 23), dt(2027, 1, 1, 6)),
])
def test_next_anchor(day, after, expected):
    assert billing.next_anchor(day, after) == expected


# --------------------------------------------------------------------------- pro-ratas
MONTH = Plan(price_cents=500, interval_unit="month", interval_count=1)
YEAR = Plan(price_cents=1200, interval_unit="year", interval_count=1)
END = dt(2026, 11, 1, 6)
HALF = END - timedelta(days=15.5)  # outubro tem 31 dias → metade exata


def test_prorate_rounding_half_up():
    assert billing.prorate(500, HALF, END, MONTH) == 250
    assert billing.prorate(3, HALF, END, MONTH) == 2   # 1,5 → 2
    assert billing.prorate(1, HALF, END, MONTH) == 1   # 0,5 → 1
    assert billing.prorate(500, END, END, MONTH) == 0
    assert billing.prorate(0, HALF, END, MONTH) == 0
    # nunca mais do que um período completo
    assert billing.prorate(500, END - timedelta(days=90), END, MONTH) == 500
    # anual: 31 dias de 365
    assert billing.prorate(1200, dt(2026, 10, 1, 6), END, YEAR) == round(1200 * 31 / 365)


def test_unused_credit_rounding():
    sub = Subscription(period_amount_cents=500, current_period_start=dt(2026, 10, 1, 6), current_period_end=END)
    assert billing.unused_credit(sub, HALF) == 250
    sub.period_amount_cents = 5
    assert billing.unused_credit(sub, HALF) == 3  # 2,5 → 3
    assert billing.unused_credit(sub, END) == 0
    assert billing.unused_credit(sub, END + timedelta(days=1)) == 0
    sub.period_amount_cents = 0  # período isento (bónus): não há crédito
    assert billing.unused_credit(sub, HALF) == 0
    sub.period_amount_cents = 500
    assert billing.unused_credit(sub, dt(2026, 9, 1)) == 500  # antes do início: no máximo o que pagou


# --------------------------------------------------------------------------- primeira subscrição
async def test_first_purchase_on_day_29_or_later_anchors_on_28(make_client, svc, clock):
    clock.set(dt(2026, 10, 30, 12))
    u, c, pm = await customer(make_client, svc, "maria")
    out = await subscribe_api(c, "tkflix-mensal")
    sub = await get(Subscription, out["subscription_id"])
    user = await get(User, u.id)
    assert user.billing_anchor_day == 28
    assert sub.status == SubStatus.active and sub.current_period_end == dt(2026, 11, 28, 6)
    assert user.next_billing_at == dt(2026, 11, 28, 6)
    inv = await fetch_one(Invoice)
    assert inv.kind == "immediate" and inv.status == "paid" and inv.total_cents == 500
    assert inv.number == "C2026-00001"
    [ln] = await lines_of(inv.id)
    assert ln.kind == "renewal" and ln.period_start == dt(2026, 10, 30, 12) and ln.period_end == dt(2026, 11, 28, 6)
    [pi] = svc.stripe.charges()
    assert pi["amount"] == 500 and pi["payment_method"] == pm.provider_ref
    assert svc.stripe.keys_for("/v1/payment_intents") == [f"inv-{inv.id}-1"]


async def test_annual_plan_aligned_to_monthly_anchor(make_client, svc, clock):
    clock.set(dt(2026, 10, 10, 12))
    u, c, _ = await customer(make_client, svc, "maria")
    await subscribe_api(c, "tkflix-anual")
    annual = await fetch_one(Subscription)
    assert annual.current_period_end == dt(2027, 10, 10, 6)
    assert (await get(User, u.id)).next_billing_at == dt(2026, 11, 10, 6)  # a cobrança continua a ser mensal
    assert (await fetch_one(Invoice)).total_cents == 5000

    # Um segundo produto anual a meio do ciclo: pro-rata até ao dia de faturação e depois ano completo.
    _, plans = await make_product("cloud", plans=[("cloud-a", 1200, "year")])
    clock.set(dt(2026, 10, 25, 12))
    q = (await c.get("/api/billing/quote", params={"plan_id": plans["cloud-a"].id})).json()
    expected = billing.prorate(1200, dt(2026, 10, 25, 12), dt(2026, 11, 10, 6), plans["cloud-a"])
    assert expected == round(1200 * (15 * 24 + 18) / (365 * 24))
    assert q["due_now_cents"] == 0 and q["next_invoice_cents"] == expected
    assert q["period_end"].startswith("2026-11-10T06:00")
    out = await subscribe_api(c, "cloud-a")
    cloud = await get(Subscription, out["subscription_id"])
    assert cloud.status == SubStatus.active and cloud.current_period_end == dt(2026, 11, 10, 6)
    [ln] = await pending(u.id)
    assert ln.kind == "proration" and ln.amount_cents == expected
    assert len(await fetch(Invoice)) == 1  # nada cobrado agora

    clock.set(dt(2026, 11, 10, 6))
    inv = await cycle(u)
    rows = await lines_of(inv.id)
    assert sorted((r.kind, r.amount_cents) for r in rows) == sorted([("proration", expected), ("renewal", 1200)])
    assert inv.total_cents == 1200 + expected
    assert (await get(Subscription, cloud.id)).current_period_end == dt(2027, 11, 10, 6)
    assert (await get(Subscription, annual.id)).current_period_end == dt(2027, 10, 10, 6)  # não renova
    assert (await get(User, u.id)).next_billing_at == dt(2026, 12, 10, 6)


async def test_one_invoice_per_cycle_with_several_products(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, c, _ = await customer(make_client, svc, "maria")
    await make_product("cloud")
    await subscribe_api(c, "tkflix-mensal")
    clock.set(dt(2026, 10, 5, 13))
    await subscribe_api(c, "cloud-m")  # mesmo dia: pro-rata ≈ mês inteiro
    clock.set(dt(2026, 11, 5, 6))
    svc.stripe.reset()
    inv = await cycle(u)
    rows = await lines_of(inv.id)
    assert [r.kind for r in rows].count("renewal") == 2 and inv.kind == "cycle"
    assert inv.status == "paid" and inv.total_cents == sum(r.amount_cents for r in rows)
    assert len(svc.stripe.find("POST", r"^/v1/payment_intents$")) == 1  # uma só cobrança
    for s in await fetch(Subscription):
        assert s.current_period_end == dt(2026, 12, 5, 6)
    assert await cycle(u) is None  # correr outra vez no mesmo dia não cobra de novo


async def test_invoice_numbers_are_sequential_per_year(make_client, svc, clock):
    clock.set(dt(2026, 12, 20, 12))
    u, c, _ = await customer(make_client, svc, "maria")
    await subscribe_api(c, "tkflix-mensal")
    v, c2, _ = await customer(make_client, svc, "joao")
    await subscribe_api(c2, "tkflix-mensal")
    clock.set(dt(2027, 1, 20, 6))
    await cycle(u)
    numbers = sorted(i.number for i in await fetch(Invoice))
    assert numbers == ["C2026-00001", "C2026-00002", "C2027-00001"]


async def test_min_charge_is_carried_to_next_invoice(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    await make_product("gorjeta", plans=[("gorjeta-m", 60, "month")])
    u, c, _ = await customer(make_client, svc, "maria")
    await subscribe_api(c, "gorjeta-m")
    first = await fetch_one(Invoice)
    assert first.total_cents == 60 and first.status == "paid"  # a primeira compra cobra-se sempre
    svc.stripe.reset()

    clock.set(dt(2026, 11, 5, 6))
    inv = await cycle(u)
    assert inv.status == "paid" and inv.total_cents == 0 and inv.subtotal_cents == 60
    assert [(r.kind, r.amount_cents) for r in await lines_of(inv.id)] == [("renewal", 60), ("carry", -60)]
    [carried] = await pending(u.id)
    assert carried.kind == "adjustment" and carried.amount_cents == 60
    assert svc.stripe.find("POST", r"^/v1/payment_intents$") == []

    clock.set(dt(2026, 12, 5, 6))
    inv = await cycle(u)
    assert inv.total_cents == 120 and inv.status == "paid"
    assert await pending(u.id) == []


async def test_negative_total_is_carried_as_credit(make_client, svc, clock, admin_client):
    clock.set(dt(2026, 10, 5, 12))
    u, c, _ = await customer(make_client, svc, "maria")
    await subscribe_api(c, "tkflix-mensal")
    r = await admin_client.post(f"/api/admin/users/{u.id}/adjustments",
                                json={"amount_cents": -1000, "description": "Compensação pela avaria"})
    assert r.status_code == 200
    svc.stripe.reset()

    clock.set(dt(2026, 11, 5, 6))
    inv = await cycle(u)
    assert inv.total_cents == 0 and inv.status == "paid"
    assert ("carry", 500) in [(r.kind, r.amount_cents) for r in await lines_of(inv.id)]
    [credit] = await pending(u.id)
    assert credit.kind == "credit" and credit.amount_cents == -500

    clock.set(dt(2026, 12, 5, 6))
    inv = await cycle(u)
    assert inv.total_cents == 0 and await pending(u.id) == []
    assert svc.stripe.find("POST", r"^/v1/payment_intents$") == []

    clock.set(dt(2027, 1, 5, 6))
    inv = await cycle(u)
    assert inv.total_cents == 500 and inv.status == "paid"  # o crédito foi usado uma só vez


async def test_credit_alone_does_not_generate_empty_invoices(svc, clock, admin_client):
    """Um crédito sem serviços ativos fica guardado — não gera uma cobrança vazia todos os meses."""
    clock.set(dt(2026, 10, 5, 12))
    u = await create_user("maria")
    await admin_client.post(f"/api/admin/users/{u.id}/adjustments", json={"amount_cents": -300, "description": "Oferta"})
    user = await get(User, u.id)
    assert user.billing_anchor_day == 5 and user.next_billing_at == dt(2026, 11, 5, 6)
    clock.set(dt(2026, 11, 5, 6))
    assert await cycle(u) is None
    assert await fetch(Invoice) == []
    assert [ln.amount_cents for ln in await pending(u.id)] == [-300]


async def test_small_adjustment_without_services_is_charged_not_carried_forever(svc, clock, admin_client):
    clock.set(dt(2026, 10, 5, 12))
    u = await create_user("maria")
    await add_method(svc, u, "stripe")
    await admin_client.post(f"/api/admin/users/{u.id}/adjustments", json={"amount_cents": 50, "description": "Cabo"})
    clock.set(dt(2026, 11, 5, 6))
    inv = await cycle(u)
    assert inv.total_cents == 50 and inv.status == "paid"
    assert await pending(u.id) == [] and (await get(User, u.id)).next_billing_at is None


async def test_catch_up_when_worker_was_down(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, c, _ = await customer(make_client, svc, "maria")
    out = await subscribe_api(c, "tkflix-mensal")
    clock.set(dt(2026, 12, 20, 12))  # dois dias de faturação falhados
    inv = await cycle(u)
    rows = await lines_of(inv.id)
    assert [(r.period_start, r.period_end) for r in rows] == [
        (dt(2026, 11, 5, 6), dt(2026, 12, 5, 6)), (dt(2026, 12, 5, 6), dt(2027, 1, 5, 6))]
    assert inv.total_cents == 1000
    assert (await get(Subscription, out["subscription_id"])).current_period_end == dt(2027, 1, 5, 6)
    assert (await get(User, u.id)).next_billing_at == dt(2027, 1, 5, 6)


async def test_canceling_ends_at_period_end_without_charge(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, c, _ = await customer(make_client, svc, "maria")
    out = await subscribe_api(c, "tkflix-mensal")
    clock.set(dt(2026, 10, 20, 12))
    r = await c.post(f"/api/billing/subscriptions/{out['subscription_id']}/cancel")
    assert r.status_code == 200 and "05/11/2026" in r.json()["message"]
    sub = await get(Subscription, out["subscription_id"])
    assert sub.status == SubStatus.canceling and sub.access_until == dt(2026, 11, 5, 6)

    clock.set(dt(2026, 11, 5, 6, 1))
    async with dbs() as db:
        assert await billing.schedule_due(db) == 1
    await drain()
    assert (await get(Subscription, sub.id)).status == SubStatus.ended
    assert len(await fetch(Invoice)) == 1
    assert (await get(User, u.id)).next_billing_at is None
    assert not await emails("subscription_ended", to=u.email)  # sem emails de confirmação (o cliente vê no portal)


async def test_suspended_is_not_renewed_and_ends_after_suspended_end_days(svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u = await create_user("maria", billing_anchor_day=5, next_billing_at=dt(2026, 10, 5, 6))
    sub = await add_sub(u, status=SubStatus.suspended, price_cents=500, current_period_start=dt(2026, 9, 5, 6),
                        current_period_end=dt(2026, 10, 5, 6))
    await update_row(Subscription, sub.id, updated_at=dt(2026, 10, 1))
    assert await cycle(u) is None
    assert (await get(Subscription, sub.id)).status == SubStatus.suspended
    assert (await get(User, u.id)).next_billing_at == dt(2026, 11, 5, 6)

    clock.set(dt(2026, 11, 5, 6))  # suspensa há mais de 30 dias
    assert await cycle(u) is None
    s = await get(Subscription, sub.id)
    assert s.status == SubStatus.ended and s.current_period_end == dt(2026, 10, 5, 6)
    assert (await get(User, u.id)).next_billing_at is None
    assert await fetch(Invoice) == []


async def test_schedule_due_retries_orphaned_open_invoice(svc, clock):
    """Cobrança emitida mas nunca cobrada (ex.: o processo caiu depois do commit) volta a ser tentada."""
    clock.set(dt(2026, 10, 5, 12))
    u = await create_user("maria")
    await add_method(svc, u, "stripe")
    async with dbs() as db:
        inv = Invoice(user_id=u.id, number="C2026-09999", kind="cycle", status="open", total_cents=500,
                      subtotal_cents=500, created_at=dt(2026, 10, 5, 11, 30))
        db.add(inv)
        await db.commit()
    async with dbs() as db:
        await billing.schedule_due(db)
    assert len(await jobs_of("billing_charge", "pending")) == 1
    await drain()
    assert (await get(Invoice, inv.id)).status == "paid"
    assert svc.stripe.keys_for("/v1/payment_intents") == [f"inv-{inv.id}-1"]


async def test_cycle_via_worker_jobs(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, c, _ = await customer(make_client, svc, "maria")
    await subscribe_api(c, "tkflix-mensal")
    clock.set(dt(2026, 11, 5, 6, 5))
    async with dbs() as db:
        assert await billing.schedule_due(db) == 1
        assert await billing.schedule_due(db) == 1  # dedupe: continua a haver um só job pendente
    assert len(await jobs_of("billing_cycle", "pending")) == 1
    await drain()
    invs = sorted(await fetch(Invoice), key=lambda i: i.number)
    assert [i.kind for i in invs] == ["immediate", "cycle"] and invs[1].status == "paid"
    async with dbs() as db:
        assert await billing.schedule_due(db) == 0


async def test_plan_price_locked_per_subscription(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, c, _ = await customer(make_client, svc, "maria")
    await subscribe_api(c, "tkflix-mensal")
    plan = await plan_by_code("tkflix-mensal")
    await update_row(Plan, plan.id, price_cents=900)  # mudança direta na BD não afeta quem já subscreveu
    clock.set(dt(2026, 11, 5, 6))
    inv = await cycle(u)
    assert inv.total_cents == 500
