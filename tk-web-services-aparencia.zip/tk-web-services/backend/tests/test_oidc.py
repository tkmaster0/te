from __future__ import annotations

import base64
import hashlib
import secrets
import time
from urllib.parse import parse_qs, urlencode, urlparse

import jwt
import pytest
from conftest import PASSWORD, add_sub, create_user, dbs, fetch, pw_hash

from app.models import LoginSession, OIDCClient, OIDCRefreshToken

REDIRECT = "https://tv.test/sso/OID/redirect/tkflix"
SECRET = "segredo-do-cliente-123"


@pytest.fixture
async def oidc_clients():
    async with dbs() as db:
        db.add(OIDCClient(client_id="jellyfin", name="Jellyfin", secret_hash=pw_hash(SECRET),
                          redirect_uris=[REDIRECT], post_logout_redirect_uris=["https://tv.test/web/"],
                          allowed_scopes=["openid", "profile", "email", "groups"]))
        db.add(OIDCClient(client_id="jfsso", name="Jellyfin SSO", secret_hash=pw_hash(SECRET),
                          redirect_uris=[REDIRECT], required_access="feature:jellyfin"))
        db.add(OIDCClient(client_id="spa", name="SPA", secret_hash=None, require_pkce=True,
                          token_endpoint_auth_method="none", redirect_uris=["https://app.portal.test/cb"],
                          allowed_scopes=["openid", "profile", "email", "groups", "offline_access"]))
        await db.commit()


def pkce() -> tuple[str, str]:
    verifier = secrets.token_urlsafe(48)
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
    return verifier, challenge


def basic(client_id: str, secret: str) -> dict:
    return {"Authorization": "Basic " + base64.b64encode(f"{client_id}:{secret}".encode()).decode()}


def auth_params(client_id="jellyfin", redirect_uri=REDIRECT, **kw) -> dict:
    return {"response_type": "code", "client_id": client_id, "redirect_uri": redirect_uri,
            "scope": "openid profile email groups", "state": "st-123", "nonce": "n-456", **kw}


def qs(location: str) -> dict:
    return {k: v[0] for k, v in parse_qs(urlparse(location).query).items()}


async def get_code(client, **params) -> str:
    r = await client.get("/oidc/authorize", params=auth_params(**params))
    assert r.status_code == 302, r.text
    loc = r.headers["location"]
    q = qs(loc)
    assert "code" in q, loc
    assert q["state"] == "st-123" and q["iss"] == "https://portal.test"
    return q["code"]


async def verify_id_token(client, id_token: str, audience: str) -> dict:
    jwks = (await client.get("/oidc/jwks.json")).json()
    kid = jwt.get_unverified_header(id_token)["kid"]
    key = jwt.PyJWKSet.from_dict(jwks)[kid]
    return jwt.decode(id_token, key.key, algorithms=["RS256"], audience=audience, issuer="https://portal.test")


async def test_discovery(client):
    r = await client.get("/.well-known/openid-configuration")
    d = r.json()
    assert d["issuer"] == "https://portal.test"
    assert d["authorization_endpoint"] == "https://portal.test/oidc/authorize"
    assert d["token_endpoint"] == "https://portal.test/oidc/token"
    assert d["jwks_uri"] == "https://portal.test/oidc/jwks.json"
    assert d["code_challenge_methods_supported"] == ["S256"]
    jwks = (await client.get("/oidc/jwks.json")).json()
    assert len(jwks["keys"]) == 1 and jwks["keys"][0]["alg"] == "RS256"


async def test_full_code_flow_with_pkce_and_basic_auth(make_client, oidc_clients):
    u = await create_user("maria", display_name="Maria")
    await add_sub(u)
    browser = make_client()
    verifier, challenge = pkce()
    params = auth_params(code_challenge=challenge, code_challenge_method="S256")
    r = await browser.get("/oidc/authorize", params=params)
    assert r.status_code == 302
    loc = urlparse(r.headers["location"])
    assert f"{loc.scheme}://{loc.netloc}{loc.path}" == "https://portal.test/login"
    nxt = qs(r.headers["location"])["next"]
    assert nxt.startswith("https://portal.test/oidc/authorize?")
    # login com next → a app volta ao authorize
    r = await browser.login("maria", next=nxt)
    assert r.json()["redirect"] == nxt
    r = await browser.get(nxt.replace("https://portal.test", ""))
    assert r.status_code == 302
    q = qs(r.headers["location"])
    assert r.headers["location"].startswith(REDIRECT + "?")
    code = q["code"]

    rp = make_client(csrf=False)  # o relying party não é um browser
    r = await rp.post("/oidc/token", data={"grant_type": "authorization_code", "code": code,
                                           "redirect_uri": REDIRECT, "code_verifier": verifier},
                      headers=basic("jellyfin", SECRET))
    assert r.status_code == 200, r.text
    assert r.headers["cache-control"] == "no-store"
    tok = r.json()
    assert tok["token_type"] == "Bearer" and tok["refresh_token"] and tok["expires_in"] == 3600
    claims = await verify_id_token(rp, tok["id_token"], "jellyfin")
    assert claims["sub"] == u.id and claims["nonce"] == "n-456"
    assert claims["preferred_username"] == "maria" and claims["name"] == "Maria"
    assert claims["email"] == "maria@example.com" and claims["email_verified"] is True
    assert {"tkflix-user", "active", "feature:jellyfin", "feature:seerr", "plan:tkflix-mensal"} <= set(claims["groups"])
    assert "admin" not in claims["groups"]
    expected_at_hash = base64.urlsafe_b64encode(
        hashlib.sha256(tok["access_token"].encode()).digest()[:16]).rstrip(b"=").decode()
    assert claims["at_hash"] == expected_at_hash
    assert claims["azp"] == "jellyfin" and "auth_time" in claims

    r = await rp.get("/oidc/userinfo", headers={"Authorization": f"Bearer {tok['access_token']}"})
    assert r.status_code == 200
    info = r.json()
    assert info["sub"] == u.id and info["preferred_username"] == "maria" and "feature:jellyfin" in info["groups"]
    r = await rp.get("/oidc/userinfo", headers={"Authorization": f"Bearer {tok['id_token']}"})
    assert r.status_code == 401
    r = await rp.get("/oidc/userinfo")
    assert r.status_code == 401

    # código não pode ser reutilizado (e revoga os refresh tokens emitidos)
    r = await rp.post("/oidc/token", data={"grant_type": "authorization_code", "code": code,
                                           "redirect_uri": REDIRECT, "code_verifier": verifier},
                      headers=basic("jellyfin", SECRET))
    assert r.status_code == 400 and r.json()["error"] == "invalid_grant"
    r = await rp.post("/oidc/token", data={"grant_type": "refresh_token", "refresh_token": tok["refresh_token"]},
                      headers=basic("jellyfin", SECRET))
    assert r.status_code == 400


async def test_client_secret_post_and_refresh_rotation(make_client, oidc_clients):
    u = await create_user("maria")
    browser = make_client()
    await browser.login_as(u)
    code = await get_code(browser)
    rp = make_client(csrf=False)
    r = await rp.post("/oidc/token", data={"grant_type": "authorization_code", "code": code,
                                           "redirect_uri": REDIRECT, "client_id": "jellyfin",
                                           "client_secret": SECRET})
    assert r.status_code == 200, r.text
    rt1 = r.json()["refresh_token"]
    r = await rp.post("/oidc/token", data={"grant_type": "refresh_token", "refresh_token": rt1,
                                           "client_id": "jellyfin", "client_secret": SECRET})
    assert r.status_code == 200
    rt2 = r.json()["refresh_token"]
    assert rt2 != rt1
    claims = await verify_id_token(rp, r.json()["id_token"], "jellyfin")
    assert claims["sub"] == u.id and "nonce" not in claims
    # o antigo já não serve
    r = await rp.post("/oidc/token", data={"grant_type": "refresh_token", "refresh_token": rt1,
                                           "client_id": "jellyfin", "client_secret": SECRET})
    assert r.status_code == 400 and r.json()["error"] == "invalid_grant"
    # scope superior ao original é recusado
    r = await rp.post("/oidc/token", data={"grant_type": "refresh_token", "refresh_token": rt2,
                                           "client_id": "jellyfin", "client_secret": SECRET,
                                           "scope": "openid offline_access"})
    assert r.status_code == 400 and r.json()["error"] == "invalid_scope"
    # e esse pedido falhado não queimou o refresh token
    r = await rp.post("/oidc/token", data={"grant_type": "refresh_token", "refresh_token": rt2,
                                           "client_id": "jellyfin", "client_secret": SECRET, "scope": "openid"})
    assert r.status_code == 200 and r.json()["scope"] == "openid"
    # revoke
    rt3 = r.json()["refresh_token"]
    r = await rp.post("/oidc/revoke", data={"token": rt3}, headers=basic("jellyfin", SECRET))
    assert r.status_code == 200
    r = await rp.post("/oidc/token", data={"grant_type": "refresh_token", "refresh_token": rt3},
                      headers=basic("jellyfin", SECRET))
    assert r.status_code == 400


async def test_bad_client_credentials(make_client, oidc_clients):
    u = await create_user("maria")
    browser = make_client()
    await browser.login_as(u)
    code = await get_code(browser)
    rp = make_client(csrf=False)
    for headers, data in (
        (basic("jellyfin", "errado"), {}),
        ({}, {"client_id": "jellyfin"}),
        ({}, {"client_id": "naoexiste", "client_secret": "x"}),
        ({"Authorization": "Basic !!!"}, {}),
    ):
        r = await rp.post("/oidc/token", data={"grant_type": "authorization_code", "code": code,
                                               "redirect_uri": REDIRECT, **data}, headers=headers)
        assert r.status_code == 401 and r.json()["error"] == "invalid_client"
    # código de outro cliente
    r = await rp.post("/oidc/token", data={"grant_type": "authorization_code", "code": code,
                                           "redirect_uri": REDIRECT}, headers=basic("jfsso", SECRET))
    assert r.status_code == 400
    # redirect_uri diferente no token endpoint
    r = await rp.post("/oidc/token", data={"grant_type": "authorization_code", "code": code,
                                           "redirect_uri": REDIRECT + "x"}, headers=basic("jellyfin", SECRET))
    assert r.status_code == 400 and r.json()["error"] == "invalid_grant"
    r = await rp.post("/oidc/token", data={"grant_type": "password"}, headers=basic("jellyfin", SECRET))
    assert r.json()["error"] == "unsupported_grant_type"


async def test_public_client_requires_pkce(make_client, oidc_clients):
    u = await create_user("maria")
    browser = make_client()
    await browser.login_as(u)
    r = await browser.get("/oidc/authorize", params=auth_params("spa", "https://app.portal.test/cb"))
    assert r.status_code == 302
    q = qs(r.headers["location"])
    assert q["error"] == "invalid_request" and "code" not in q and q["state"] == "st-123"
    r = await browser.get("/oidc/authorize", params=auth_params("spa", "https://app.portal.test/cb",
                                                                code_challenge="abc", code_challenge_method="plain"))
    assert qs(r.headers["location"])["error"] == "invalid_request"
    r = await browser.get("/oidc/authorize", params=auth_params("spa", "https://app.portal.test/cb",
                                                                code_challenge="curto"))
    assert qs(r.headers["location"])["error"] == "invalid_request"

    verifier, challenge = pkce()
    code = await get_code(browser, client_id="spa", redirect_uri="https://app.portal.test/cb",
                          code_challenge=challenge, scope="openid profile offline_access")
    rp = make_client(csrf=False)
    base = {"grant_type": "authorization_code", "code": code, "redirect_uri": "https://app.portal.test/cb",
            "client_id": "spa"}
    r = await rp.post("/oidc/token", data=base)
    assert r.status_code == 400 and r.json()["error"] == "invalid_grant"
    r = await rp.post("/oidc/token", data={**base, "code_verifier": pkce()[0]})
    assert r.status_code == 400
    r = await rp.post("/oidc/token", data={**base, "code_verifier": verifier})
    assert r.status_code == 200, r.text
    assert "refresh_token" in r.json()  # offline_access pedido
    claims = await verify_id_token(rp, r.json()["id_token"], "spa")
    assert "email" not in claims  # scope email não pedido


async def test_public_client_without_offline_access_gets_no_refresh(make_client, oidc_clients):
    u = await create_user("maria")
    browser = make_client()
    await browser.login_as(u)
    verifier, challenge = pkce()
    code = await get_code(browser, client_id="spa", redirect_uri="https://app.portal.test/cb", code_challenge=challenge)
    r = await make_client(csrf=False).post("/oidc/token", data={
        "grant_type": "authorization_code", "code": code, "redirect_uri": "https://app.portal.test/cb",
        "client_id": "spa", "code_verifier": verifier})
    assert r.status_code == 200 and "refresh_token" not in r.json()


async def test_authorize_rejects_unregistered_redirect_without_redirecting(client, oidc_clients):
    u = await create_user("maria")
    await client.login_as(u)
    r = await client.get("/oidc/authorize", params=auth_params(redirect_uri="https://evil.com/cb"))
    assert r.status_code == 400 and "location" not in r.headers
    r = await client.get("/oidc/authorize", params=auth_params(client_id="naoexiste"))
    assert r.status_code == 400 and "location" not in r.headers
    r = await client.get("/oidc/authorize", params=auth_params(response_type="token"))
    assert qs(r.headers["location"])["error"] == "unsupported_response_type"
    r = await client.get("/oidc/authorize", params=auth_params(scope="profile"))
    assert qs(r.headers["location"])["error"] == "invalid_scope"
    r = await client.get("/oidc/authorize", params=auth_params(nonce="x" * 300))
    assert qs(r.headers["location"])["error"] == "invalid_request"


async def test_required_access_feature(make_client, oidc_clients):
    u = await create_user("semplano")
    c = make_client()
    await c.login_as(u)
    r = await c.get("/oidc/authorize", params=auth_params(client_id="jfsso"))
    assert r.status_code == 302
    assert r.headers["location"] == "https://portal.test/sem-acesso?" + urlencode({"app": "Jellyfin SSO"})
    r = await c.get("/oidc/authorize", params=auth_params(client_id="jfsso", prompt="none"))
    assert qs(r.headers["location"])["error"] == "access_denied"
    # refresh também respeita o requisito
    await add_sub(u)
    code = await get_code(c, client_id="jfsso")
    rp = make_client(csrf=False)
    r = await rp.post("/oidc/token", data={"grant_type": "authorization_code", "code": code,
                                           "redirect_uri": REDIRECT}, headers=basic("jfsso", SECRET))
    rt = r.json()["refresh_token"]
    from conftest import fetch_one
    from conftest import update_row as upd

    from app.models import Subscription, SubStatus

    sub = await fetch_one(Subscription)
    await upd(Subscription, sub.id, status=SubStatus.ended.value)
    r = await rp.post("/oidc/token", data={"grant_type": "refresh_token", "refresh_token": rt},
                      headers=basic("jfsso", SECRET))
    assert r.status_code == 400
    # admins entram sempre
    adm = await create_user("adm", admin=True)
    a = make_client()
    await a.login_as(adm)
    await get_code(a, client_id="jfsso")


async def test_prompt_none_without_session(client, oidc_clients):
    r = await client.get("/oidc/authorize", params=auth_params(prompt="none"))
    assert r.status_code == 302
    q = qs(r.headers["location"])
    assert r.headers["location"].startswith(REDIRECT)
    assert q["error"] == "login_required" and q["state"] == "st-123"


async def test_mfa_pending_session_is_not_logged_in(client, oidc_clients):
    u = await create_user("maria")
    await client.login_as(u, mfa_pending=True)
    r = await client.get("/oidc/authorize", params=auth_params())
    assert r.headers["location"].startswith("https://portal.test/login?")


async def test_code_expired(make_client, oidc_clients):
    from datetime import timedelta

    from app.db import utcnow
    from app.models import OIDCCode

    u = await create_user("maria")
    c = make_client()
    await c.login_as(u)
    code = await get_code(c)
    async with dbs() as db:
        row = (await db.scalars(__import__("sqlalchemy").select(OIDCCode))).one()
        row.expires_at = utcnow() - timedelta(seconds=1)
        await db.commit()
    r = await make_client(csrf=False).post("/oidc/token", data={
        "grant_type": "authorization_code", "code": code, "redirect_uri": REDIRECT},
        headers=basic("jellyfin", SECRET))
    assert r.status_code == 400


async def test_logout_with_post_logout_redirect(make_client, oidc_clients):
    u = await create_user("maria")
    c = make_client()
    await c.login_as(u)
    r = await c.get("/oidc/logout", params={"client_id": "jellyfin", "post_logout_redirect_uri": "https://tv.test/web/",
                                           "state": "abc"})
    assert r.status_code == 302 and r.headers["location"] == "https://tv.test/web/?state=abc"
    assert (await fetch(LoginSession))[0].revoked_at is not None
    assert (await c.get("/api/auth/me")).status_code == 401
    # URI não registado → volta ao login do portal
    r = await c.get("/oidc/logout", params={"client_id": "jellyfin", "post_logout_redirect_uri": "https://evil.com/"})
    assert r.headers["location"] == "https://portal.test/login?saiu=1"


async def test_logout_with_expired_id_token_hint(make_client, oidc_clients):
    from app.services import oidc_keys

    async with dbs() as db:
        now = int(time.time())
        hint = await oidc_keys.sign(db, {"iss": "https://portal.test", "aud": "jellyfin", "sub": "x",
                                         "iat": now - 7200, "exp": now - 3600})
        forged = jwt.encode({"iss": "https://portal.test", "aud": "jellyfin", "sub": "x", "exp": now + 60},
                            "segredo-hmac-bem-comprido-para-o-pyjwt-0123456789", algorithm="HS256")
    c = make_client()
    r = await c.get("/oidc/logout", params={"id_token_hint": hint, "post_logout_redirect_uri": "https://tv.test/web/"})
    assert r.headers["location"] == "https://tv.test/web/"
    r = await c.get("/oidc/logout", params={"id_token_hint": forged, "post_logout_redirect_uri": "https://tv.test/web/"})
    assert r.headers["location"] == "https://portal.test/login?saiu=1"


async def test_key_rotation_keeps_old_key_published(admin_client, oidc_clients):
    jwks1 = (await admin_client.get("/oidc/jwks.json")).json()
    r = await admin_client.post("/api/admin/oidc/rotate-keys")
    assert r.status_code == 200
    jwks2 = (await admin_client.get("/oidc/jwks.json")).json()
    kids2 = {k["kid"] for k in jwks2["keys"]}
    assert jwks1["keys"][0]["kid"] in kids2 and len(kids2) == 2


# --------------------------------------------------------------------------- forward-auth
async def test_forward_auth_without_session(client):
    r = await client.get("/auth/verify", headers={"X-Forwarded-Host": "sonarr.test", "X-Forwarded-Proto": "https",
                                                 "X-Forwarded-Uri": "/calendar?x=1"})
    assert r.status_code == 302
    assert r.headers["location"] == "https://portal.test/login?" + urlencode(
        {"next": "https://sonarr.test/calendar?x=1"})
    r = await client.get("/auth/verify", headers={"X-Forwarded-Host": "radarr.portal.test", "X-Forwarded-Uri": "/"})
    assert qs(r.headers["location"])["next"] == "https://radarr.portal.test/"
    # host não autorizado não é refletido no redirect
    r = await client.get("/auth/verify", headers={"X-Forwarded-Host": "evil.com", "X-Forwarded-Uri": "/x"})
    assert r.status_code == 302 and r.headers["location"] == "https://portal.test/login"
    r = await client.get("/auth/verify", headers={"X-Original-URL": "https://evil.portal.test.evil.com/"})
    assert r.headers["location"] == "https://portal.test/login"
    r = await client.get("/auth/verify", params={"mode": "status"})
    assert r.status_code == 401 and "location" not in r.headers


async def test_forward_auth_authorization(make_client):
    user = await create_user("maria", display_name="Maria")
    await add_sub(user)
    c = make_client()
    await c.login_as(user)
    r = await c.get("/auth/verify")
    assert r.status_code == 403  # require=admin por omissão
    r = await c.get("/auth/verify", params={"require": "admin", "mode": "status"})
    assert r.status_code == 403
    r = await c.get("/auth/verify", params={"require": "feature:jellyfin"})
    assert r.status_code == 200 and r.headers["remote-user"] == "maria"
    r = await c.get("/auth/verify", params={"require": "feature:iptv"})
    assert r.status_code == 403
    r = await c.get("/auth/verify", params={"require": "plan:tkflix-mensal"})
    assert r.status_code == 200
    r = await c.get("/auth/verify", params={"require": "group:active"})
    assert r.status_code == 200

    adm = await create_user("adm", admin=True)
    a = make_client()
    await a.login_as(adm)
    r = await a.get("/auth/verify")
    assert r.status_code == 200
    assert r.headers["remote-user"] == "adm" and r.headers["remote-email"] == "adm@example.com"
    groups = r.headers["remote-groups"].split(",")
    assert "admin" in groups and "tkflix-user" in groups
    assert r.headers["x-auth-request-user"] == "adm"
    assert r.headers["cache-control"] == "no-store"


async def test_forward_auth_blocked_user(make_client):
    u = await create_user("adm", admin=True, is_active=False)
    c = make_client()
    await c.login_as(u)
    r = await c.get("/auth/verify", params={"mode": "status"})
    assert r.status_code == 401


async def test_login_password_still_works_for_oidc_user(client, oidc_clients):
    await create_user("maria")
    r = await client.login("maria", PASSWORD, next="https://portal.test/oidc/authorize?client_id=jellyfin")
    assert r.json()["redirect"] == "https://portal.test/oidc/authorize?client_id=jellyfin"


async def test_refresh_tokens_stored_hashed(make_client, oidc_clients):
    u = await create_user("maria")
    c = make_client()
    await c.login_as(u)
    code = await get_code(c)
    r = await make_client(csrf=False).post("/oidc/token", data={
        "grant_type": "authorization_code", "code": code, "redirect_uri": REDIRECT}, headers=basic("jellyfin", SECRET))
    rt = r.json()["refresh_token"]
    [row] = await fetch(OIDCRefreshToken)
    assert row.token_hash != rt and len(row.token_hash) == 64
