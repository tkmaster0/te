"""Regressões da revisão de segurança (uma por problema corrigido)."""
from __future__ import annotations

import re
from datetime import timedelta
from pathlib import Path

import pyotp
import pytest
from conftest import (
    PASSWORD,
    add_sub,
    create_user,
    dbs,
    drain,
    emails,
    fetch,
    fetch_one,
    gc_event,
    get,
    jobs_of,
    plan_by_code,
    post_gc_webhook,
    update_row,
)
from test_gocardless import gc_subscribe
from test_oidc import REDIRECT, SECRET, get_code, oidc_clients  # noqa: F401 (fixture)

from app.config import get_settings
from app.db import utcnow
from app.models import InviteCode, Invoice, Plan, ServiceAccount, Subscription, SubStatus
from app.security import encrypt
from app.services import jobs
from app.services.provisioning import reconcile_user


# --------------------------------------------------------------------------- deploy
def test_uvicorn_does_not_trust_forwarded_headers_from_everyone():
    """Com --forwarded-allow-ips='*' o uvicorn punha o X-Forwarded-For do cliente como IP do socket."""
    entry = (Path(__file__).resolve().parents[2] / "deploy" / "entrypoint.sh").read_text()
    m = re.search(r'--forwarded-allow-ips="\$\{FORWARDED_ALLOW_IPS:-([^}]*)\}"', entry)
    assert m, "entrypoint sem --forwarded-allow-ips explícito"
    assert "*" not in m.group(1)


def test_example_secret_key_is_rejected():
    from pydantic import ValidationError

    from app.config import Settings

    # O .env.example não define uma SECRET_KEY ativa (é gerada no primeiro arranque): copiá-lo não pode deixar a
    # instalação com uma chave conhecida.
    example = (Path(__file__).resolve().parents[2] / ".env.example").read_text()
    assert re.search(r"^SECRET_KEY=\S", example, re.M) is None
    with pytest.raises(ValidationError):
        Settings(secret_key="troca-isto-por-openssl-rand-base64-48")
    assert Settings(secret_key="x" * 48).secret_key == "x" * 48


# --------------------------------------------------------------------------- autenticação
async def test_2fa_attempts_limited_per_user_across_sessions(make_client):
    """Abrir sessões mfa_pending novas não pode dar tentativas ilimitadas ao código TOTP."""
    u = await create_user("maria", totp_enabled=True, totp_secret_enc=encrypt(pyotp.random_base32()))
    statuses = []
    for _ in range(4):  # 4 sessões × 3 tentativas = 12 > limite por utilizador (10)
        c = make_client()
        await c.login_as(u, mfa_pending=True)
        for _ in range(3):
            statuses.append((await c.post("/api/auth/2fa", json={"code": "000000"})).status_code)
    assert statuses[:10] == [401] * 10
    assert statuses[10:] == [429, 429]


async def test_open_registration_does_not_make_first_user_admin(client, settings):
    settings.set("registration_mode", "open")
    r = await client.post("/api/auth/register", json={"username": "primeiro", "email": "primeiro@example.com",
                                                      "password": PASSWORD})
    assert r.status_code == 200, r.text
    assert r.json()["user"]["is_admin"] is False


async def test_invite_mode_first_user_still_admin(client):
    async with dbs() as db:
        db.add(InviteCode(code="TK-PRIM-0001", max_uses=1))
        await db.commit()
    r = await client.post("/api/auth/register", json={"username": "primeiro", "email": "primeiro@example.com",
                                                      "password": PASSWORD, "invite_code": "TK-PRIM-0001"})
    assert r.status_code == 200 and r.json()["user"]["is_admin"] is True


async def test_recovery_code_regeneration_is_rate_limited(client):
    u = await create_user("maria", totp_enabled=True, totp_secret_enc=encrypt(pyotp.random_base32()))
    await client.login_as(u)
    codes = [(await client.post("/api/account/2fa/recovery-codes", json={"password": "errada-123"})).status_code
             for _ in range(6)]
    assert codes == [400] * 5 + [429]


async def test_password_reset_revokes_oidc_refresh_tokens(make_client, oidc_clients):  # noqa: F811
    u = await create_user("maria")
    browser = make_client()
    await browser.login_as(u)
    code = await get_code(browser)
    rp = make_client(csrf=False)
    r = await rp.post("/oidc/token", data={"grant_type": "authorization_code", "code": code, "redirect_uri": REDIRECT,
                                           "client_id": "jellyfin", "client_secret": SECRET})
    rt = r.json()["refresh_token"]
    anon = make_client()
    assert (await anon.post("/api/auth/forgot", json={"email": u.email})).status_code == 200
    [mail] = await emails("reset_password")
    token = mail["ctx"]["cta_url"].split("token=")[1]
    assert (await anon.post("/api/auth/reset", json={"token": token, "password": "Outra-Pass-99"})).status_code == 200
    r = await rp.post("/oidc/token", data={"grant_type": "refresh_token", "refresh_token": rt,
                                           "client_id": "jellyfin", "client_secret": SECRET})
    assert r.status_code == 400 and r.json()["error"] == "invalid_grant"


# --------------------------------------------------------------------------- segredos
async def test_email_tokens_not_kept_in_job_payload_or_admin_listing(make_client, admin_client):
    u = await create_user("maria")
    anon = make_client()
    await anon.post("/api/auth/forgot", json={"email": u.email})
    [mail] = await emails("reset_password")
    token = mail["ctx"]["cta_url"].split("token=")[1]
    # ainda por enviar: o painel de jobs não mostra o token
    listing = (await admin_client.get("/api/admin/jobs", params={"kind": "send_email"})).json()
    assert token not in str(listing) and "token=<removido>" in str(listing)
    # depois de enviado, o payload guardado já não tem o token
    await drain()
    [job] = await jobs_of("send_email")
    assert job.status == "done" and token not in str(job.payload)
    # e o link continua válido (só a cópia no job foi apagada)
    r = await anon.post("/api/auth/reset", json={"token": token, "password": "Outra-Pass-99"})
    assert r.status_code == 200


def test_redact_tokens_helper():
    p = {"to": "a@b", "ctx": {"cta_url": "https://p/x?token=abc&y=1", "n": 3, "l": ["https://p/?a=1&token=zz"]}}
    out = jobs.redact_tokens(p)
    assert out["ctx"]["cta_url"] == "https://p/x?token=<removido>&y=1"
    assert out["ctx"]["l"] == ["https://p/?a=1&token=<removido>"] and out["ctx"]["n"] == 3


# --------------------------------------------------------------------------- pagamentos
async def test_private_plan_cannot_be_bought_or_switched_to(client, svc):
    u = await create_user("maria")
    base = await plan_by_code("tkflix-mensal")
    async with dbs() as db:
        private = Plan(product_id=base.product_id, code="familia", name="Família", price_cents=100,
                       is_public=False, features=base.features)
        db.add(private)
        await db.commit()
    await client.login_as(u)
    r = await client.post("/api/billing/subscribe", json={"plan_id": private.id, "provider": "gocardless"})
    assert r.status_code == 404
    r = await client.get("/api/billing/quote", params={"plan_id": private.id})
    assert r.status_code == 404
    sub = await gc_subscribe(client, svc, u)
    r = await client.post(f"/api/billing/subscriptions/{sub.id}/change", json={"plan_id": private.id})
    assert r.status_code == 404
    assert (await get(Subscription, sub.id)).plan_id == base.id
    assert "familia" not in str((await client.get("/api/catalog")).json())


async def test_legacy_migration_by_email_requires_verified_email(svc):
    """Quem se regista com o email de um cliente GoCardless antigo não fica com a subscrição (nem o mandato) dele."""
    from app.models import PaymentMethod
    from app.services import legacy

    await create_user("impostor", email="vitima@example.com", verified=False)
    cust = svc.gc.add_customer("vitima@example.com")
    mandate = svc.gc.add_mandate(cust["id"])
    gs = svc.gc.add_subscription(mandate["id"], amount=500, name="TKFLIX")
    async with dbs() as db:
        res = await legacy.migrate_gocardless_subscription(db, gs)
        await db.commit()
    assert res["result"].startswith("sem utilizador")
    assert await fetch(Subscription) == [] and await fetch(PaymentMethod) == []
    assert gs["status"] == "active"


async def test_failed_payment_after_plan_change_still_counts(client, svc):
    """Mudar de plano depois de o débito ser submetido não pode "apagar" a falha desse débito."""
    u = await create_user("maria")
    sub = await gc_subscribe(client, svc, u)
    pid = svc.gc.charges()[-1]["id"]
    svc.gc.set_payment(pid, "submitted")
    await post_gc_webhook(client, [gc_event("payments", "submitted", payment=pid)])
    await drain()
    tv = await plan_by_code("tkflix-tv-mensal")
    r = await client.post(f"/api/billing/subscriptions/{sub.id}/change", json={"plan_id": tv.id})
    assert r.status_code == 200
    assert (await get(Subscription, sub.id)).plan_id == tv.id

    svc.gc.set_payment(pid, "failed")
    await post_gc_webhook(client, [gc_event("payments", "failed", payment=pid)])
    await drain()
    sub = await get(Subscription, sub.id)
    assert sub.status == SubStatus.past_due and sub.grace_until is not None
    assert (await fetch_one(Invoice)).status == "failed"
    assert await emails("payment_failed", to=u.email)
    # em atraso já não se muda de plano (nem se foge à dívida)
    r = await client.post(f"/api/billing/subscriptions/{sub.id}/change",
                          json={"plan_id": (await plan_by_code("tkflix-mensal")).id})
    assert r.status_code == 400


async def test_failed_payment_after_cancel_shortens_access(client, svc):
    """Cancelar com o débito submetido dava o período todo de acesso mesmo que esse débito falhasse."""
    u = await create_user("maria")
    sub = await gc_subscribe(client, svc, u)
    pid = svc.gc.charges()[-1]["id"]
    r = await client.post(f"/api/billing/subscriptions/{sub.id}/cancel")
    assert r.status_code == 200
    sub = await get(Subscription, sub.id)
    assert sub.status == SubStatus.canceling and sub.access_until > utcnow() + timedelta(days=25)

    svc.gc.set_payment(pid, "failed")
    await post_gc_webhook(client, [gc_event("payments", "failed", payment=pid)])
    await drain()
    sub = await get(Subscription, sub.id)
    grace = get_settings().grace_period_days
    assert utcnow() + timedelta(days=grace - 1) < sub.access_until <= utcnow() + timedelta(days=grace)
    assert (await client.get("/api/auth/me")).json()["has_access"] is True
    # tolerância esgotada sem pagar → termina (não fica com o resto do mês)
    await update_row(Subscription, sub.id, access_until=utcnow() - timedelta(seconds=1))
    assert (await client.get("/api/auth/me")).json()["has_access"] is False
    # pagar a dívida devolve o acesso até ao fim do período
    inv = await fetch_one(Invoice)
    await update_row(Subscription, sub.id, access_until=utcnow() + timedelta(days=1))
    r = await client.post(f"/api/billing/invoices/{inv.id}/pay", json={})
    assert r.status_code == 200
    svc.gc.set_payment(svc.gc.charges()[-1]["id"], "confirmed")
    await post_gc_webhook(client, [gc_event("payments", "confirmed", payment=svc.gc.charges()[-1]["id"])])
    await drain()
    sub = await get(Subscription, sub.id)
    assert sub.access_until == sub.current_period_end


# --------------------------------------------------------------------------- provisionamento
async def test_dispatcharr_does_not_adopt_admin_user(svc):
    """Registar-se com o username de um admin do Dispatcharr não pode dar a password XC dele."""
    svc.dc.users[7] = {"id": 7, "username": "maria", "user_level": 10,
                       "custom_properties": {"xc_password": "do-admin"}, "stream_limit": 0}
    u = await create_user("maria")
    await add_sub(u, "tkflix-tv-mensal")
    async with dbs() as db:
        with pytest.raises(Exception):
            await reconcile_user(db, u.id)
    assert svc.dc.users[7]["custom_properties"] == {"xc_password": "do-admin"}
    assert not [sa for sa in await fetch(ServiceAccount) if sa.service == "dispatcharr"]


async def test_dispatcharr_does_not_adopt_user_linked_to_other_account(svc):
    svc.dc.users[8] = {"id": 8, "username": "maria", "user_level": 0, "custom_properties": {"xc_password": "x"}}
    other = await create_user("joao")
    async with dbs() as db:
        db.add(ServiceAccount(user_id=other.id, service="dispatcharr", external_id="8", external_username="Maria",
                              applied_state={"enabled": True}))
        await db.commit()
    u = await create_user("maria")
    await add_sub(u, "tkflix-tv-mensal")
    async with dbs() as db:
        with pytest.raises(Exception):
            await reconcile_user(db, u.id)
    assert svc.dc.users[8]["custom_properties"] == {"xc_password": "x"}
    sa = await fetch_one(ServiceAccount, service="dispatcharr")
    assert sa.user_id == other.id

