"""GoCardless na faturação consolidada: mandato guardado (billing request), pagamentos únicos por cobrança,
webhooks (pagamentos, mandatos, billing requests), novas tentativas / tolerância / suspensão e a migração das
subscrições GoCardless antigas."""
from __future__ import annotations

import json

from conftest import (
    add_method,
    add_sub,
    create_user,
    cycle,
    dbs,
    drain,
    dt,
    emails,
    fetch,
    fetch_one,
    gc_event,
    get,
    plan_by_code,
    post_gc_webhook,
    subscribe_api,
    update_row,
)
from test_provisioning import link_jf

from app.db import utcnow
from app.integrations.gocardless import GoCardlessClient
from app.models import Checkout, Invoice, Job, Payment, PaymentMethod, Subscription, SubStatus, User, WebhookEvent
from app.services import billing
from app.services.subscriptions import sweep


async def gc_subscribe(client, svc, user: User, plan_code: str = "tkflix-mensal") -> Subscription:
    """Cliente com mandato guardado que subscreve pelo portal (o débito fica submetido → serviço ativo)."""
    await add_method(svc, user, "gocardless")
    await client.login_as(user)
    out = await subscribe_api(client, plan_code)
    await drain()
    return await get(Subscription, out["subscription_id"])


async def gc_payment(client, svc, pid: str, status: str, action: str | None = None):
    """A GoCardless muda o estado do pagamento e envia o webhook correspondente."""
    svc.gc.set_payment(pid, status)
    r = await post_gc_webhook(client, [gc_event("payments", action or status, payment=pid)])
    assert r.status_code == 200
    await drain()


def last_charge(svc) -> dict:
    return svc.gc.charges()[-1]


# --------------------------------------------------------------------------- guardar o mandato (billing request)
async def test_add_mandate_redirects_then_completes_on_return(client, svc):
    u = await create_user("maria")
    await client.login_as(u)
    r = await client.post("/api/billing/payment-methods", json={"provider": "gocardless"})
    assert r.status_code == 200, r.text
    out = r.json()
    assert out["redirect_url"].startswith("https://pay-sandbox.gocardless.com/billing/static/flow?id=BRF")
    co_id = out["checkout_id"]
    [br_req] = svc.gc.find("POST", r"^/billing_requests$")
    assert br_req.headers["idempotency-key"] == f"br-{co_id}"
    body = json.loads(br_req.content)["billing_requests"]
    assert body["mandate_request"] == {"currency": "EUR", "scheme": "sepa_core",
                                       "metadata": {"portal_user_id": u.id, "checkout_id": co_id}}
    assert "payment_request" not in body and "links" not in body  # cliente novo na GoCardless
    [flow_req] = svc.gc.find("POST", r"^/billing_request_flows$")
    flow = json.loads(flow_req.content)["billing_request_flows"]
    assert flow["redirect_uri"] == f"https://portal.test/app/pagamento/retorno?checkout={co_id}"
    assert flow["exit_uri"] == "https://portal.test/app/faturacao?cancelado=1"
    assert flow["prefilled_customer"] == {"email": "maria@example.com"}
    co = await get(Checkout, co_id)
    assert co.status == "pending" and co.purpose == "setup_pm" and co.provider_ref.startswith("BRQ")

    # regresso antes de o billing request estar concluído
    r = await client.get(f"/api/billing/checkout/{co_id}")
    assert r.json()["status"] == "pending" and await fetch(PaymentMethod) == []

    svc.gc.fulfil(co.provider_ref, email="maria@example.com")
    r = await client.get(f"/api/billing/checkout/{co_id}")
    assert r.json()["status"] == "completed" and r.json()["return_to"] == "/app/faturacao"
    pm = await fetch_one(PaymentMethod)
    assert pm.provider == "gocardless" and pm.status == "active" and pm.is_default is True
    assert pm.kind == "sepa" and pm.label == "Débito direto · CGD ••••11"
    assert pm.provider_account == svc.gc.creditor_id
    user = await get(User, u.id)
    assert user.gocardless_mandate_id == pm.provider_ref and user.gocardless_customer_id == pm.provider_customer_id
    listing = (await client.get("/api/billing/payment-methods")).json()
    assert [m["label"] for m in listing] == [pm.label]

    # webhook do mesmo billing request depois do regresso: idempotente
    r = await post_gc_webhook(client, [gc_event("billing_requests", "fulfilled", billing_request=co.provider_ref)])
    assert r.status_code == 200
    await drain()
    assert len(await fetch(PaymentMethod)) == 1

    # segundo mandato do mesmo cliente reutiliza o cliente GoCardless
    await client.post("/api/billing/payment-methods", json={"provider": "gocardless"})
    br2 = json.loads(svc.gc.find("POST", r"^/billing_requests$")[-1].content)["billing_requests"]
    assert br2["links"] == {"customer": pm.provider_customer_id}


async def test_subscribe_without_method_redirects_and_subscribes_on_fulfilled_webhook(client, svc):
    u = await create_user("maria")
    jf_user = await link_jf(svc, u, IsDisabled=True)
    await client.login_as(u)
    plan = await plan_by_code("tkflix-anual")
    out = await subscribe_api(client, "tkflix-anual", provider="gocardless")
    assert out["status"] == "redirect" and out["subscription_id"] is None
    co = await get(Checkout, out["checkout_id"])
    assert co.intent == {"action": "subscribe", "plan_id": plan.id}
    assert await fetch(Subscription) == []

    svc.gc.fulfil(co.provider_ref)
    r = await post_gc_webhook(client, [gc_event("billing_requests", "fulfilled", billing_request=co.provider_ref)])
    assert r.json() == {"received": 1}
    await drain()
    co = await get(Checkout, co.id)
    assert co.status == "completed" and co.error is None
    sub = await get(Subscription, co.intent["subscription_id"])
    assert sub.status == SubStatus.active and sub.plan_id == plan.id and sub.provider == "portal"
    inv = await fetch_one(Invoice)
    assert inv.status == "processing" and inv.total_cents == 5000
    [charge] = svc.gc.charges()
    assert charge["links"]["mandate"] == (await fetch_one(PaymentMethod)).provider_ref
    assert charge["idempotency_key"] == f"inv-{inv.id}-1" and charge["retry_if_possible"] is False
    assert (await fetch_one(WebhookEvent)).status == "processed"
    # o regresso posterior do cliente é idempotente e leva-o aos serviços
    r = await client.get(f"/api/billing/checkout/{co.id}")
    assert r.json()["status"] == "completed" and r.json()["subscription_id"] == sub.id
    assert r.json()["return_to"] == "/app/servicos"
    assert len(svc.gc.charges()) == 1 and len(await fetch(Subscription)) == 1
    assert (await client.get("/api/auth/me")).json()["has_access"] is True
    assert svc.jf.users[jf_user["Id"]]["Policy"]["IsDisabled"] is False


async def test_billing_request_cancelled(client, svc):
    u = await create_user("maria")
    await client.login_as(u)
    out = await subscribe_api(client, "tkflix-mensal", provider="gocardless")
    co = await get(Checkout, out["checkout_id"])
    svc.gc.cancel_br(co.provider_ref)
    r = await client.get(f"/api/billing/checkout/{co.id}")
    assert r.json()["status"] == "cancelled"
    assert await fetch(Subscription) == [] and await fetch(PaymentMethod) == []


async def test_setup_provider_error_returns_502(client, svc):
    u = await create_user("maria")
    await client.login_as(u)
    svc.gc.fail_paths["/billing_requests"] = 500
    r = await client.post("/api/billing/payment-methods", json={"provider": "gocardless"})
    assert r.status_code == 502
    plan = await plan_by_code("tkflix-mensal")
    r = await client.post("/api/billing/subscribe", json={"plan_id": plan.id, "provider": "gocardless"})
    assert r.status_code == 502
    assert await fetch(Checkout) == []


async def test_subscribe_invalid_plan_or_provider(client):
    u = await create_user("maria")
    await client.login_as(u)
    r = await client.post("/api/billing/subscribe", json={"plan_id": 999, "provider": "gocardless"})
    assert r.status_code == 404
    plan = await plan_by_code("tkflix-mensal")
    r = await client.post("/api/billing/subscribe", json={"plan_id": plan.id, "provider": "paypal"})
    assert r.status_code == 422
    r = await client.post("/api/billing/subscribe", json={"plan_id": plan.id})
    assert r.status_code == 400 and "Escolhe" in r.json()["detail"]


async def test_create_payment_idempotency_conflict_returns_existing(svc):
    """Repetir a criação de um pagamento com a mesma chave devolve o pagamento já criado (sem cobrança dupla)."""
    cust = svc.gc.add_customer("maria@example.com")
    mandate = svc.gc.add_mandate(cust["id"])
    gc = GoCardlessClient()
    kw = dict(mandate_id=mandate["id"], amount_cents=500, currency="EUR", description="TKFLIX", metadata={},
              idempotency_key="inv-abc-1")
    first = await gc.create_payment(**kw)
    second = await gc.create_payment(**kw)
    assert first["id"] == second["id"] and len(svc.gc.charges()) == 1


# --------------------------------------------------------------------------- webhooks
async def test_webhook_signature_validation(client):
    body = json.dumps({"events": [gc_event("mandates", "created", mandate="MD1")]}).encode()
    r = await client.post("/api/webhooks/gocardless", content=body, headers={"Webhook-Signature": "0" * 64})
    assert r.status_code == 498
    r = await client.post("/api/webhooks/gocardless", content=body)
    assert r.status_code == 498
    r = await post_gc_webhook(client, [gc_event("mandates", "created", mandate="MD1")], secret="outro")
    assert r.status_code == 498
    assert await fetch(WebhookEvent) == []
    r = await post_gc_webhook(client, [gc_event("mandates", "created", mandate="MD1")])
    assert r.status_code == 200 and r.json() == {"received": 1}


async def test_webhook_duplicate_event_ignored(client):
    ev = gc_event("mandates", "created", event_id="EV-DUP", mandate="MD1")
    assert (await post_gc_webhook(client, [ev, ev])).json() == {"received": 1}
    assert (await post_gc_webhook(client, [ev])).json() == {"received": 0}
    assert len(await fetch(WebhookEvent)) == 1
    await drain()
    row = await fetch_one(WebhookEvent)
    # mandato desconhecido (não é de nenhum cliente do portal): registado como ignorado
    assert row.status == "ignored" and row.event_type == "mandates.created" and "desconhecido" in row.error


async def test_payment_confirmed_marks_invoice_paid(client, svc):
    u = await create_user("maria")
    sub = await gc_subscribe(client, svc, u)
    inv = await fetch_one(Invoice)
    assert inv.status == "processing" and sub.status == SubStatus.active
    pid = last_charge(svc)["id"]
    await gc_payment(client, svc, pid, "submitted")
    assert (await get(Invoice, inv.id)).status == "processing"
    await gc_payment(client, svc, pid, "confirmed")
    inv = await get(Invoice, inv.id)
    assert inv.status == "paid" and inv.paid_at is not None
    assert (await fetch_one(Payment)).status == "paid"
    await gc_payment(client, svc, pid, "paid_out")  # eventos seguintes não mudam nada
    assert (await get(Invoice, inv.id)).status == "paid"
    assert await emails("payment_received") == []  # só se envia depois de uma falha


async def test_payment_failed_retries_then_grace_then_suspended_then_recovered(client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u = await create_user("maria")
    jf_user = await link_jf(svc, u)
    sub = await gc_subscribe(client, svc, u)
    await gc_payment(client, svc, last_charge(svc)["id"], "confirmed")

    clock.set(dt(2026, 11, 5, 6))
    inv = await cycle(u)
    assert inv.status == "processing" and inv.attempt_count == 1
    p1 = last_charge(svc)
    assert p1["idempotency_key"] == f"inv-{inv.id}-1"
    await gc_payment(client, svc, p1["id"], "failed")
    inv = await get(Invoice, inv.id)
    assert inv.status == "failed" and inv.attempt_count == 1 and inv.next_attempt_at == dt(2026, 11, 8, 6)
    sub = await get(Subscription, sub.id)
    assert sub.status == SubStatus.past_due and sub.grace_until == dt(2026, 11, 15, 6)
    [mail] = await emails("payment_failed", to=u.email)
    assert mail["ctx"]["amount"] == "5,00 €" and mail["ctx"]["grace_until"] == "15/11/2026"
    assert inv.number in mail["ctx"]["plan"]
    summary = (await client.get("/api/billing/summary")).json()
    assert {a["type"] for a in summary["actions"]} >= {"invoice", "grace"}
    # durante a tolerância o acesso mantém-se
    await drain()
    assert svc.jf.users[jf_user["Id"]]["Policy"]["IsDisabled"] is False
    assert (await client.get("/api/auth/me")).json()["has_access"] is True

    # o mesmo pagamento notificado outra vez (novo id de evento) não duplica nada
    await post_gc_webhook(client, [gc_event("payments", "failed", payment=p1["id"])])
    await drain()
    assert len(await emails("payment_failed")) == 1 and (await get(Invoice, inv.id)).attempt_count == 1

    # 1.ª nova tentativa (3 dias depois): nova chave de idempotência
    clock.set(dt(2026, 11, 8, 6, 1))
    async with dbs() as db:
        assert await billing.schedule_due(db) == 1
    await drain()
    p2 = last_charge(svc)
    assert p2["id"] != p1["id"] and p2["idempotency_key"] == f"inv-{inv.id}-2"
    assert (await get(Invoice, inv.id)).status == "processing"
    await gc_payment(client, svc, p2["id"], "failed")
    inv = await get(Invoice, inv.id)
    assert inv.attempt_count == 2 and inv.next_attempt_at == dt(2026, 11, 12, 6, 1)

    # 2.ª nova tentativa (4 dias depois) e última
    clock.set(dt(2026, 11, 12, 6, 2))
    async with dbs() as db:
        await billing.schedule_due(db)
    await drain()
    p3 = last_charge(svc)
    assert p3["idempotency_key"] == f"inv-{inv.id}-3"
    await gc_payment(client, svc, p3["id"], "failed")
    inv = await get(Invoice, inv.id)
    assert inv.attempt_count == 3 and inv.next_attempt_at is None
    async with dbs() as db:
        assert await billing.schedule_due(db) == 0
    assert (await get(Subscription, sub.id)).grace_until == dt(2026, 11, 15, 6)  # a tolerância não se estende

    # tolerância esgotada → suspensa → Jellyfin desativado
    clock.set(dt(2026, 11, 15, 6, 1))
    async with dbs() as db:
        assert (await sweep(db))["suspended"] == 1
    await drain()
    assert (await get(Subscription, sub.id)).status == SubStatus.suspended
    assert svc.jf.users[jf_user["Id"]]["Policy"]["IsDisabled"] is True
    assert await emails("subscription_suspended", to=u.email)
    assert (await client.get("/api/auth/me")).json()["has_access"] is False

    # o cliente paga já com o mandato guardado → débito submetido; confirmado → volta a ficar ativo
    r = await client.post(f"/api/billing/invoices/{inv.id}/pay", json={})
    assert r.status_code == 200 and r.json()["status"] == "processing"
    assert (await get(Subscription, sub.id)).status == SubStatus.suspended  # só depois de confirmado
    p4 = last_charge(svc)
    assert p4["idempotency_key"] == f"inv-{inv.id}-4"
    await gc_payment(client, svc, p4["id"], "confirmed")
    sub = await get(Subscription, sub.id)
    assert sub.status == SubStatus.active and sub.grace_until is None
    assert (await get(Invoice, inv.id)).status == "paid"
    assert svc.jf.users[jf_user["Id"]]["Policy"]["IsDisabled"] is False
    assert not await emails("payment_received", to=u.email)  # sem emails de confirmação (o cliente vê no portal)
    rows = (await client.get("/api/billing/payments")).json()
    assert sorted(r["status"] for r in rows) == ["failed", "failed", "failed", "paid", "paid"]


async def test_past_due_recovers_before_grace(client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u = await create_user("maria")
    sub = await gc_subscribe(client, svc, u)
    pid = last_charge(svc)["id"]
    await gc_payment(client, svc, pid, "failed")
    assert (await get(Subscription, sub.id)).status == SubStatus.past_due
    clock.set(dt(2026, 10, 8, 12, 1))  # 3 dias depois da falha
    async with dbs() as db:
        assert await billing.schedule_due(db) == 1
    await drain()
    assert last_charge(svc)["id"] != pid
    await gc_payment(client, svc, last_charge(svc)["id"], "confirmed")
    sub = await get(Subscription, sub.id)
    assert sub.status == SubStatus.active and sub.grace_until is None
    inv = await fetch_one(Invoice)
    assert inv.status == "paid" and inv.attempt_count == 2


async def test_chargeback_reopens_invoice(client, svc):
    u = await create_user("maria")
    sub = await gc_subscribe(client, svc, u)
    pid = last_charge(svc)["id"]
    await gc_payment(client, svc, pid, "paid_out")
    assert (await fetch_one(Invoice)).status == "paid"
    await gc_payment(client, svc, pid, "charged_back", action="charged_back")
    inv = await fetch_one(Invoice)
    assert inv.status == "failed" and inv.paid_at is None and "estornado" in inv.last_error
    assert (await fetch_one(Payment)).status == "charged_back"
    assert (await get(Subscription, sub.id)).status == SubStatus.past_due
    assert await emails("payment_failed", to=u.email)
    # a GoCardless volta a mandar o estorno: nada muda
    await post_gc_webhook(client, [gc_event("payments", "charged_back", payment=pid)])
    await drain()
    assert len(await emails("payment_failed")) == 1


async def test_payment_webhook_for_unknown_payment_is_ignored(client, svc):
    cust = svc.gc.add_customer("x@example.com")
    md = svc.gc.add_mandate(cust["id"])
    pay = svc.gc.add_payment(None, "confirmed", "2026-01-01", amount=500, mandate_id=md["id"])
    await post_gc_webhook(client, [gc_event("payments", "confirmed", payment=pay["id"])])
    await drain()
    assert (await fetch_one(WebhookEvent)).status == "ignored"
    assert await fetch(Payment) == []


async def test_webhook_processing_failure_is_retried(client, svc):
    u = await create_user("maria")
    sub = await gc_subscribe(client, svc, u)
    pid = last_charge(svc)["id"]
    svc.gc.set_payment(pid, "failed")
    svc.gc.fail_paths[f"/payments/{pid}"] = 500
    await post_gc_webhook(client, [gc_event("payments", "failed", payment=pid)])
    await drain()
    ev = await fetch_one(WebhookEvent)
    assert ev.status == "failed" and "GoCardless" in ev.error
    [job] = await fetch(Job, kind="process_webhook")
    assert job.status == "pending" and job.attempts == 1 and job.run_after > utcnow()
    assert (await get(Subscription, sub.id)).status == SubStatus.active

    svc.gc.fail_paths.clear()
    await update_row(Job, job.id, run_after=utcnow())
    await drain()
    ev = await fetch_one(WebhookEvent)
    assert ev.status == "processed" and ev.error is None and ev.processed_at is not None
    assert (await get(Subscription, sub.id)).status == SubStatus.past_due


# --------------------------------------------------------------------------- mandatos
async def test_mandate_cancelled_revokes_method_and_falls_back(client, svc):
    u = await create_user("maria")
    sub = await gc_subscribe(client, svc, u)
    gc_pm = await fetch_one(PaymentMethod, provider="gocardless")
    card = await add_method(svc, u, "stripe", default=False)
    await post_gc_webhook(client, [gc_event("mandates", "cancelled", mandate=gc_pm.provider_ref,
                                            event_id="EV-MC1")])
    await drain()
    gc_pm = await get(PaymentMethod, gc_pm.id)
    assert gc_pm.status == "revoked" and gc_pm.is_default is False and "cancelled" in gc_pm.status_reason
    assert (await get(PaymentMethod, card.id)).is_default is True
    assert await emails("payment_method_needed") == []  # há alternativa
    # o método predefinido passa a ser o cartão
    assert (await client.get("/api/billing/summary")).json()["default_payment_method_id"] == card.id
    assert sub.status == SubStatus.active


async def test_mandate_cancelled_without_alternative_notifies(client, svc):
    u = await create_user("maria")
    await gc_subscribe(client, svc, u)
    gc_pm = await fetch_one(PaymentMethod)
    await post_gc_webhook(client, [gc_event("mandates", "expired", mandate=gc_pm.provider_ref)])
    await drain()
    assert (await get(PaymentMethod, gc_pm.id)).status == "revoked"
    [mail] = await emails("payment_method_needed", to=u.email)
    assert "expired" in mail["ctx"]["reason"]
    summary = (await client.get("/api/billing/summary")).json()
    assert summary["default_payment_method_id"] is None
    assert summary["actions"][0]["type"] == "payment_method" and summary["actions"][0]["severity"] == "high"
    # um mandato revogado não volta a ficar ativo por outro evento se o cliente o removeu
    await update_row(PaymentMethod, gc_pm.id, status_reason=billing.REMOVED_REASON)
    await post_gc_webhook(client, [gc_event("mandates", "reinstated", mandate=gc_pm.provider_ref)])
    await drain()
    assert (await get(PaymentMethod, gc_pm.id)).status == "revoked"


async def test_mandate_replaced_and_reinstated(client, svc):
    u = await create_user("maria")
    sub = await gc_subscribe(client, svc, u)
    pm = await fetch_one(PaymentMethod)
    new = svc.gc.add_mandate(pm.provider_customer_id)
    await post_gc_webhook(client, [gc_event("mandates", "replaced", mandate=pm.provider_ref,
                                            new_mandate=new["id"])])
    await drain()
    assert (await get(PaymentMethod, pm.id)).provider_ref == new["id"]
    # a cobrança seguinte usa o mandato novo
    async with dbs() as db:
        inv = await db.get(Invoice, (await fetch_one(Invoice)).id)
        await update_row(Invoice, inv.id, status="failed")
    async with dbs() as db:
        inv = await db.get(Invoice, inv.id)
        await billing.charge_invoice(db, inv)
        await db.commit()
    assert last_charge(svc)["links"]["mandate"] == new["id"]
    assert (await get(Subscription, sub.id)).status == SubStatus.active

    # mandato pendente (a ser submetido ao banco) → ativo quando a GoCardless o confirma
    await update_row(PaymentMethod, pm.id, status="pending")
    await post_gc_webhook(client, [gc_event("mandates", "active", mandate=new["id"])])
    await drain()
    assert (await get(PaymentMethod, pm.id)).status == "active"


async def test_charge_on_inactive_mandate_marks_method_unusable(client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u = await create_user("maria")
    sub = await gc_subscribe(client, svc, u)
    await gc_payment(client, svc, last_charge(svc)["id"], "confirmed")
    pm = await fetch_one(PaymentMethod)
    svc.gc.mandates[pm.provider_ref]["status"] = "cancelled"  # o webhook do mandato perdeu-se
    clock.set(dt(2026, 11, 5, 6))
    inv = await cycle(u)
    assert inv.status == "failed" and "not active" in inv.last_error
    assert (await get(PaymentMethod, pm.id)).status == "revoked"
    sub = await get(Subscription, sub.id)
    # sem método válido: tolerância maior (PAYMENT_METHOD_GRACE_DAYS) e o email pede um novo método
    assert sub.status == SubStatus.past_due and sub.grace_until == dt(2026, 11, 19, 6)
    assert await emails("payment_method_needed", to=u.email)


# --------------------------------------------------------------------------- pagar agora (billing request c/ pagamento)
async def test_pay_invoice_with_new_mandate(client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u = await create_user("maria")
    sub = await gc_subscribe(client, svc, u)
    old_pm = await fetch_one(PaymentMethod)
    await gc_payment(client, svc, last_charge(svc)["id"], "failed")
    inv = await fetch_one(Invoice)
    assert inv.status == "failed"

    r = await client.post(f"/api/billing/invoices/{inv.id}/pay", json={"provider": "gocardless"})
    assert r.status_code == 200, r.text
    co = await get(Checkout, r.json()["checkout_id"])
    assert co.purpose == "pay_invoice" and co.invoice_id == inv.id
    [req] = [q for q in svc.gc.find("POST", r"^/billing_requests$") if q.headers["idempotency-key"] == f"brpay-{co.id}"]
    body = json.loads(req.content)["billing_requests"]
    assert body["payment_request"]["amount"] == 500 and body["links"] == {"customer": old_pm.provider_customer_id}

    svc.gc.fulfil(co.provider_ref)
    r = await client.get(f"/api/billing/checkout/{co.id}")
    assert r.json()["status"] == "completed" and r.json()["invoice_id"] == inv.id
    inv = await get(Invoice, inv.id)
    assert inv.status == "processing" and inv.attempt_count == 2
    new_pm = await get(PaymentMethod, (await get(Checkout, co.id)).payment_method_id)
    assert new_pm.id != old_pm.id and new_pm.is_default is True
    pay = await fetch_one(Payment, invoice_id=inv.id, status="pending")
    await gc_payment(client, svc, pay.provider_payment_id, "confirmed")
    assert (await get(Invoice, inv.id)).status == "paid"
    assert (await get(Subscription, sub.id)).status == SubStatus.active
    # pagar outra vez uma cobrança já paga → recusado
    r = await client.post(f"/api/billing/invoices/{inv.id}/pay", json={"provider": "gocardless"})
    assert r.status_code == 400


# --------------------------------------------------------------------------- utilizador
async def test_non_portal_subscription_cannot_be_cancelled_by_user(client):
    u = await create_user("maria")
    manual = await add_sub(u, provider="manual")
    await client.login_as(u)
    r = await client.post(f"/api/billing/subscriptions/{manual.id}/cancel")
    assert r.status_code == 400
    assert (await get(Subscription, manual.id)).status == SubStatus.active
    other = await create_user("joao")
    sub2 = await add_sub(other)
    r = await client.post(f"/api/billing/subscriptions/{sub2.id}/cancel")
    assert r.status_code == 404


async def test_user_cancel_and_resume(client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u = await create_user("maria")
    sub = await gc_subscribe(client, svc, u)
    clock.set(dt(2026, 10, 20, 12))
    r = await client.post(f"/api/billing/subscriptions/{sub.id}/cancel")
    assert r.status_code == 200 and "05/11/2026" in r.json()["message"]
    sub = await get(Subscription, sub.id)
    assert sub.status == SubStatus.canceling and sub.access_until == dt(2026, 11, 5, 6)
    assert not await emails("subscription_canceled", to=u.email)  # sem emails de confirmação (o cliente vê no portal)
    assert (await client.post(f"/api/billing/subscriptions/{sub.id}/cancel")).status_code == 400
    listing = (await client.get("/api/billing/subscriptions")).json()[0]
    assert listing["can_resume"] is True and listing["can_cancel"] is False
    assert (await client.get("/api/billing/summary")).json()["upcoming"]["lines"] == []

    r = await client.post(f"/api/billing/subscriptions/{sub.id}/resume")
    assert r.status_code == 200
    sub = await get(Subscription, sub.id)
    assert sub.status == SubStatus.active and sub.access_until is None and sub.cancel_at_period_end is False
    assert (await client.post(f"/api/billing/subscriptions/{sub.id}/resume")).status_code == 400
    # depois do fim do período já não se reativa
    await client.post(f"/api/billing/subscriptions/{sub.id}/cancel")
    clock.set(dt(2026, 11, 5, 7))
    r = await client.post(f"/api/billing/subscriptions/{sub.id}/resume")
    assert r.status_code == 400 and "subscreve de novo" in r.json()["detail"]


async def test_resume_requires_payment_method(client, svc):
    u = await create_user("maria")
    sub = await gc_subscribe(client, svc, u)
    await client.post(f"/api/billing/subscriptions/{sub.id}/cancel")
    pm = await fetch_one(PaymentMethod)
    await update_row(PaymentMethod, pm.id, status="revoked")
    r = await client.post(f"/api/billing/subscriptions/{sub.id}/resume")
    assert r.status_code == 400 and "método de pagamento" in r.json()["detail"]


async def test_remove_last_method_with_active_service_is_refused(client, svc):
    u = await create_user("maria")
    await gc_subscribe(client, svc, u)
    pm = await fetch_one(PaymentMethod)
    r = await client.delete(f"/api/billing/payment-methods/{pm.id}")
    assert r.status_code == 400 and "Adiciona outro" in r.json()["detail"]
    card = await add_method(svc, u, "stripe", default=False)
    r = await client.delete(f"/api/billing/payment-methods/{pm.id}")
    assert r.status_code == 200
    pm = await get(PaymentMethod, pm.id)
    assert pm.status == "revoked" and pm.status_reason == billing.REMOVED_REASON
    assert (await get(PaymentMethod, card.id)).is_default is True
    assert svc.stripe.payment_methods[card.provider_ref]["customer"] is not None
    r = await client.post(f"/api/billing/payment-methods/{pm.id}/default")
    assert r.status_code == 400


# --------------------------------------------------------------------------- migração do sistema antigo
async def _legacy_customer(svc, name: str, **kw):
    cust = svc.gc.add_customer(f"{name}@example.com")
    md = svc.gc.add_mandate(cust["id"])
    u = await create_user(name, gocardless_customer_id=cust["id"], gocardless_mandate_id=md["id"], **kw)
    return u, md


async def test_admin_legacy_migration_dry_run_then_real(admin_client, make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, md = await _legacy_customer(svc, "antigo")
    gs = svc.gc.add_subscription(md["id"], amount=450, name="TKFLIX", next_charge="2026-10-20")
    svc.gc.add_payment(gs["id"], "paid_out", "2026-09-20")
    svc.gc.add_subscription(md["id"], amount=500, status="cancelled")
    v, md2 = await _legacy_customer(svc, "pausado")
    gp = svc.gc.add_subscription(md2["id"], amount=750, name="TKFLIX + TV", status="paused", day_of_month=12)

    r = await admin_client.post("/api/admin/gocardless/import", json={"dry_run": True, "keep": False})
    assert r.status_code == 200
    out = r.json()
    assert out["dry_run"] is True and out["count"] == 2
    by_sub = {x.get("gc_subscription"): x for x in out["results"]}
    assert by_sub[gs["id"]]["result"] == "seria migrada" and by_sub[gs["id"]]["price_cents"] == 450
    assert by_sub[gs["id"]]["paid_until"].startswith("2026-10-20T06:00")
    assert by_sub[gp["id"]]["bonus"] is True and by_sub[gp["id"]]["paid_until"].startswith("2026-10-12T06:00")
    assert await fetch(Subscription) == [] and await fetch(PaymentMethod) == []
    assert gs["status"] == "active"

    r = await admin_client.post("/api/admin/gocardless/import", json={"dry_run": False, "keep": False})
    assert r.json()["count"] == 2
    sub = await fetch_one(Subscription, user_id=u.id)
    assert sub.provider == "portal" and sub.status == SubStatus.active and sub.price_cents == 450
    assert sub.plan_id == (await plan_by_code("tkflix-mensal")).id and sub.provider_subscription_id == gs["id"]
    assert sub.current_period_end == dt(2026, 10, 20, 6) and sub.meta["migrated_from"] == "gocardless"
    pm = await fetch_one(PaymentMethod, user_id=u.id)
    assert pm.provider_ref == md["id"] and pm.is_default and pm.status == "active"
    user = await get(User, u.id)
    assert user.billing_anchor_day == 20 and user.next_billing_at == dt(2026, 10, 20, 6)
    assert gs["status"] == "cancelled"  # a partir de agora é o portal que cobra
    assert (await fetch_one(Payment, user_id=u.id)).status == "paid"  # histórico importado
    paused = await fetch_one(Subscription, user_id=v.id)
    assert paused.status == SubStatus.bonus and paused.period_amount_cents == 0 and gp["status"] == "cancelled"

    # correr outra vez não duplica nada; se a subscrição antiga ainda estiver ativa na GoCardless é cancelada
    gp["status"] = "paused"
    r = await admin_client.post("/api/admin/gocardless/import", json={"dry_run": False, "keep": False})
    by_sub = {x.get("gc_subscription"): x["result"] for x in r.json()["results"]}
    assert by_sub[gs["id"]] == "ignorada (não ativa)"
    assert by_sub[gp["id"]] == "já migrada (subscrição antiga cancelada agora)" and gp["status"] == "cancelled"
    assert len(await fetch(Subscription)) == 2 and len(await fetch(PaymentMethod)) == 2

    # no dia da cobrança antiga o portal cobra o mesmo valor no mesmo mandato
    clock.set(dt(2026, 10, 20, 6))
    inv = await cycle(u)
    assert inv.total_cents == 450 and inv.status == "processing"
    assert last_charge(svc)["links"]["mandate"] == md["id"]


async def test_legacy_submitted_payment_extends_period_and_can_still_fail(client, svc, clock):
    """Pagamento do próximo ciclo já submetido ao banco: o período estende-se, mas se falhar não é um mês grátis."""
    from app.services import legacy

    clock.set(dt(2026, 10, 18, 12))
    u, md = await _legacy_customer(svc, "antigo")
    gs = svc.gc.add_subscription(md["id"], amount=500, name="TKFLIX", next_charge="2026-10-20")
    submitted = svc.gc.add_payment(gs["id"], "submitted", "2026-10-20")
    # cancelar na GoCardless falha → nada fica gravado (a GoCardless continua a cobrar; corre-se de novo)
    svc.gc.fail_paths[f"/subscriptions/{gs['id']}/actions/cancel"] = 500
    async with dbs() as db:
        results = await legacy.migrate_all(db, keep=False)
    assert results[0]["result"].startswith("erro") and gs["status"] == "active"
    assert await fetch(Subscription) == [] and await fetch(Invoice) == [] and await fetch(PaymentMethod) == []
    del svc.gc.fail_paths[f"/subscriptions/{gs['id']}/actions/cancel"]
    async with dbs() as db:
        results = await legacy.migrate_all(db, keep=False)
    assert [r["result"] for r in results] == ["migrada"]
    assert gs["status"] == "cancelled"
    sub = await fetch_one(Subscription)
    assert sub.current_period_end == dt(2026, 11, 20, 6)
    inv = await fetch_one(Invoice)
    assert inv.status == "processing" and inv.total_cents == 500 and inv.kind == "manual"
    await gc_payment(client, svc, submitted["id"], "failed")
    assert (await get(Invoice, inv.id)).status == "failed"
    assert (await get(Subscription, sub.id)).status == SubStatus.past_due
