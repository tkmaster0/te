"""Infraestrutura de testes.

As variáveis de ambiente são definidas ANTES de importar a aplicação (get_settings() é cached).
Por omissão usa SQLite num ficheiro temporário; `TEST_DATABASE_URL=postgresql+asyncpg://...` corre a
mesma suite contra PostgreSQL.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import tempfile
import time
import types
from contextlib import asynccontextmanager
from datetime import timedelta
from pathlib import Path

_TMP = Path(tempfile.mkdtemp(prefix="tkportal-tests-"))
ENV = {
    "ENV": "test",
    "SECRET_KEY": "test-secret-key-0123456789-abcdefghijklmnopqrstuvwxyz",
    "DATABASE_URL": os.environ.get("TEST_DATABASE_URL") or f"sqlite+aiosqlite:///{_TMP / 'test.db'}",
    "PUBLIC_URL": "https://portal.test",
    "COOKIE_SECURE": "false",
    "JELLYFIN_URL": "http://jellyfin.test",
    "JELLYFIN_API_KEY": "jf-api-key-123",
    "JELLYFIN_PUBLIC_URL": "https://tv.test",
    "SEERR_URL": "http://seerr.test",
    "SEERR_PUBLIC_URL": "https://pedidos.test",
    "SEERR_API_KEY": "seerr-key-123",
    "DISPATCHARR_URL": "http://dispatcharr.test",
    "DISPATCHARR_PUBLIC_URL": "https://iptv.test",
    "DISPATCHARR_API_KEY": "dc-key-123",
    "GOCARDLESS_ACCESS_TOKEN": "gc-token",
    "GOCARDLESS_WEBHOOK_SECRET": "gc-webhook-secret",
    "GOCARDLESS_ENVIRONMENT": "sandbox",
    "STRIPE_SECRET_KEY": "sk_test_x",
    "STRIPE_WEBHOOK_SECRET": "whsec_test",
    "ALLOWED_REDIRECT_HOSTS": "*.portal.test,sonarr.test",
    "REQUIRE_EMAIL_VERIFICATION": "true",
    "REGISTRATION_MODE": "invite",
    "LOG_LEVEL": "WARNING",
    "TEST_ADMIN_ENABLED": "false",
}
os.environ.update(ENV)
for _k in ("COOKIE_DOMAIN", "SMTP_HOST", "ADMIN_NOTIFY_EMAIL", "RUN_WORKER_IN_API"):
    os.environ.pop(_k, None)
os.chdir(Path(__file__).resolve().parent.parent)  # garante que nenhum .env de outra pasta é lido

import httpx  # noqa: E402
import pytest  # noqa: E402
import respx  # noqa: E402
from httpx import ASGITransport  # noqa: E402
from sqlalchemy import select, text  # noqa: E402

from app.config import get_settings  # noqa: E402

get_settings.cache_clear()

from app.db import Base, get_engine, sessionmaker, utcnow  # noqa: E402
from app.deps import reset_rate_limits  # noqa: E402
from app.integrations import stripe_client  # noqa: E402
from app.main import app  # noqa: E402
from app.models import LoginSession, PaymentMethod, Plan, Subscription, SubStatus, User  # noqa: E402
from app.payments import registry  # noqa: E402
from app.routers import bridge  # noqa: E402
from app.security import hash_password, new_token, token_hash  # noqa: E402
from app.seed import seed_defaults  # noqa: E402
from app.services import jobs, oidc_keys  # noqa: E402
from fakes import (  # noqa: E402
    BAZARR_API_KEY,
    BAZARR_HOST,
    FakeBazarr,
    FakeDispatcharr,
    FakeGoCardless,
    FakeJellyfin,
    FakeLLM,
    FakeSeerr,
    FakeStripe,
)

IS_PG = get_settings().database_url.startswith("postgresql")
BASE_URL = "https://portal.test"
CSRF = {"X-Requested-With": "tkportal"}
PASSWORD = "Sup3r-Segura!"
PROGRAMMING_ERRORS = {"TypeError", "AttributeError", "KeyError", "NameError", "UnboundLocalError", "IndexError",
                      "AssertionError", "IntegrityError", "ProgrammingError", "DataError", "StatementError",
                      "MissingGreenlet", "DetachedInstanceError", "InvalidRequestError"}


# --------------------------------------------------------------------------- base de dados
@pytest.fixture(scope="session", autouse=True)
async def _schema():
    engine = get_engine()
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
        await conn.run_sync(Base.metadata.create_all)
    yield
    await engine.dispose()


async def _truncate() -> None:
    engine = get_engine()
    tables = list(Base.metadata.tables)
    async with engine.begin() as conn:
        if IS_PG:
            await conn.execute(text(f"TRUNCATE {', '.join(tables)} RESTART IDENTITY CASCADE"))
        else:
            await conn.execute(text("PRAGMA foreign_keys=OFF"))
            for t in tables:
                await conn.execute(text(f"DELETE FROM {t}"))


@pytest.fixture(autouse=True)
async def _clean_state(_schema):
    await _truncate()
    reset_rate_limits()
    oidc_keys._cache.clear()
    stripe_client.reset_client()
    registry.clear_cache()
    bridge._token_cache.clear()
    from app.assistant.channels import whatsapp as _wa
    from app.integrations import bazarr as _bz

    _wa._unlinked_notice.clear()
    _bz._cache.clear()
    async with sessionmaker()() as db:
        await seed_defaults(db)
    yield
    # Erros de programação dentro de jobs ficam "escondidos" (o job é só reagendado). Não os deixar passar.
    from app.models import Job

    async with sessionmaker()() as db:
        bad = [(j.kind, j.last_error) for j in (await db.scalars(select(Job))).all()
               if j.last_error and j.last_error.split(":")[0] in PROGRAMMING_ERRORS]
    assert not bad, f"Jobs falharam com erros de programação: {bad}"


@pytest.fixture
def settings(monkeypatch):
    """Permite alterar definições num teste: `settings.set("registration_mode", "open")`."""
    s = get_settings()

    class _S:
        def set(self, key, value):
            monkeypatch.setattr(s, key, value)

        def __getattr__(self, item):
            return getattr(s, item)

    return _S()


@asynccontextmanager
async def dbs():
    async with sessionmaker()() as db:
        yield db


async def fetch(model, **filters):
    async with dbs() as db:
        q = select(model)
        for k, v in filters.items():
            q = q.where(getattr(model, k) == v)
        return (await db.scalars(q)).all()


async def fetch_one(model, **filters):
    rows = await fetch(model, **filters)
    assert len(rows) == 1, f"esperado 1 {model.__name__}, obtidos {len(rows)}"
    return rows[0]


async def get(model, pk):
    async with dbs() as db:
        return await db.get(model, pk)


async def update_row(model, pk, **fields):
    async with dbs() as db:
        obj = await db.get(model, pk)
        for k, v in fields.items():
            setattr(obj, k, v)
        await db.commit()
        return obj


async def drain() -> int:
    return await jobs.drain()


async def jobs_of(kind: str, status: str | None = None):
    from app.models import Job

    rows = await fetch(Job, kind=kind)
    return [j for j in rows if status is None or j.status == status]


async def emails(template: str | None = None, to: str | None = None) -> list[dict]:
    out = []
    for j in await jobs_of("send_email"):
        p = j.payload
        if (template is None or p["template"] == template) and (to is None or p["to"] == to):
            out.append(p)
    return out


# --------------------------------------------------------------------------- dados
_HASHES: dict[str, str] = {}


def pw_hash(password: str) -> str:
    if password not in _HASHES:
        _HASHES[password] = hash_password(password)
    return _HASHES[password]


async def plan_by_code(code: str) -> Plan:
    return await fetch_one(Plan, code=code)


async def create_user(username: str, *, email: str | None = None, password: str = PASSWORD, admin: bool = False,
                      verified: bool = True, referred_by: User | None = None, **kw) -> User:
    # Por omissão, um cliente "antigo" (anterior à carteira e ao SSO) com o TKFLIX desbloqueado — é o que a maior
    # parte dos testes exercita. Os testes da carteira/SSO passam billing_mode="wallet" etc.
    kw.setdefault("billing_mode", "legacy")
    kw.setdefault("jellyfin_password_login", True)
    kw.setdefault("unlocked_products", ["tkflix"])
    async with dbs() as db:
        u = User(username=username, email=email or f"{username}@example.com", password_hash=pw_hash(password),
                 is_admin=admin, email_verified_at=utcnow() if verified else None,
                 referred_by_id=referred_by.id if referred_by else None, **kw)
        db.add(u)
        await db.commit()
        return u


async def add_sub(user: User, plan_code: str = "tkflix-mensal", *, provider: str = "portal",
                  status: SubStatus = SubStatus.active, provider_subscription_id: str | None = None,
                  paid: bool = True, **kw) -> Subscription:
    plan = await plan_by_code(plan_code)
    async with dbs() as db:
        sub = Subscription(user_id=user.id, plan_id=plan.id, product_id=plan.product_id, provider=provider,
                           provider_subscription_id=provider_subscription_id, status=status, **kw)
        db.add(sub)
        await db.flush()
        if paid:  # por omissão a subscrição já tem um pagamento confirmado
            import uuid

            from app.models import Payment
            db.add(Payment(user_id=user.id, subscription_id=sub.id, provider=provider,
                           provider_payment_id=f"PM-{uuid.uuid4().hex[:10]}", amount_cents=plan.price_cents,
                           status="paid", charge_date=utcnow()))
        await db.commit()
        return sub


# --------------------------------------------------------------------------- serviços externos (respx)
@pytest.fixture(autouse=True)
def svc():
    with respx.mock(assert_all_called=False, assert_all_mocked=True) as mock:
        jf = FakeJellyfin(mock)
        ns = types.SimpleNamespace(
            mock=mock, jf=jf, seerr=FakeSeerr(mock, jf), dc=FakeDispatcharr(mock), gc=FakeGoCardless(mock),
            stripe=FakeStripe(mock),
        )
        yield ns
        assert not jf.bad_auth_headers, f"Pedidos ao Jellyfin sem header MediaBrowser válido: {jf.bad_auth_headers}"


@pytest.fixture
def bazarr(svc, settings) -> FakeBazarr:
    """Bazarr falso ligado (por omissão os testes correm sem Bazarr configurado)."""
    settings.set("bazarr_url", f"http://{BAZARR_HOST}")
    settings.set("bazarr_api_key", BAZARR_API_KEY)
    svc.bazarr = FakeBazarr(svc.mock)
    return svc.bazarr


@pytest.fixture
def llm(settings):
    """Liga o assistente com um modelo falso (ver fakes.FakeLLM)."""
    from app.assistant.llm import set_llm_factory

    settings.set("assistant_enabled", True)
    settings.set("assistant_model", "fake/model")
    fake = FakeLLM()
    set_llm_factory(fake)
    yield fake
    set_llm_factory(None)


# --------------------------------------------------------------------------- clientes HTTP
class Client(httpx.AsyncClient):
    async def login_as(self, user: User, *, mfa_pending: bool = False, scope: str | None = None) -> str:
        """Cria diretamente uma sessão (sem passar pelo argon2) e guarda o cookie."""
        token = new_token(32)
        async with dbs() as db:
            db.add(LoginSession(id=token_hash(token), user_id=user.id, mfa_pending=mfa_pending, scope=scope,
                                expires_at=utcnow() + timedelta(days=1)))
            await db.commit()
        self.cookies.set(get_settings().session_cookie_name, token, domain="portal.test")
        return token

    async def login(self, login: str, password: str = PASSWORD, **extra) -> httpx.Response:
        return await self.post("/api/auth/login", json={"login": login, "password": password, **extra})


@pytest.fixture
async def make_client():
    clients: list[Client] = []

    def _make(csrf: bool = True, **kw) -> Client:
        c = Client(transport=ASGITransport(app=app, client=("127.0.0.1", 5000)), base_url=BASE_URL,
                   headers=CSRF if csrf else {}, **kw)
        clients.append(c)
        return c

    yield _make
    for c in clients:
        await c.aclose()


@pytest.fixture
async def client(make_client) -> Client:
    return make_client()


@pytest.fixture
async def admin() -> User:
    return await create_user("chefe", admin=True)


@pytest.fixture
async def admin_client(make_client, admin) -> Client:
    c = make_client()
    await c.login_as(admin)
    return c


# --------------------------------------------------------------------------- webhooks
def gc_signature(body: bytes, secret: str = "gc-webhook-secret") -> str:
    return hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()


async def post_gc_webhook(client: httpx.AsyncClient, events: list[dict], *, secret: str = "gc-webhook-secret"):
    body = json.dumps({"events": events}).encode()
    return await client.post("/api/webhooks/gocardless", content=body,
                             headers={"Webhook-Signature": gc_signature(body, secret),
                                      "Content-Type": "application/json"})


def stripe_signature(payload: bytes, secret: str = "whsec_test", ts: int | None = None) -> str:
    t = ts or int(time.time())
    mac = hmac.new(secret.encode(), f"{t}.".encode() + payload, hashlib.sha256).hexdigest()
    return f"t={t},v1={mac}"


_evt = iter(range(1, 10**9))


async def post_stripe_webhook(client: httpx.AsyncClient, etype: str, obj: dict, *, event_id: str | None = None,
                              secret: str = "whsec_test"):
    event = {"id": event_id or f"evt_{next(_evt)}", "object": "event", "type": etype, "api_version": "2025-03-31",
             "created": int(time.time()), "data": {"object": obj}, "livemode": False}
    body = json.dumps(event).encode()
    return await client.post("/api/webhooks/stripe", content=body,
                              headers={"Stripe-Signature": stripe_signature(body, secret),
                                       "Content-Type": "application/json"})


_gc_evt = iter(range(1, 10**9))


def gc_event(resource_type: str, action: str, event_id: str | None = None, **links) -> dict:
    return {"id": event_id or f"EV{next(_gc_evt):06d}", "resource_type": resource_type, "action": action,
            "links": links, "details": {"origin": "gocardless"}, "created_at": "2026-01-01T00:00:00Z"}


# --------------------------------------------------------------------------- faturação: relógio e métodos
_REAL_UTCNOW = utcnow
# Módulos cujo `utcnow` o relógio dos testes controla (sessões, tokens e OIDC ficam com a hora real).
CLOCK_MODULES = ("app.services.billing", "app.services.subscriptions", "app.services.bonus",
                 "app.services.fulfillment", "app.services.legacy", "app.services.tasks", "app.services.jobs",
                 "app.routers.admin", "app.routers.billing", "app.serializers", "app.payments.gocardless",
                 "app.payments.stripe", "app.services.wallet", "app.games.service", "app.services.legacy_stripe",
                 "app.services.oidc_presets", "app.services.catalog")


class Clock:
    """Hora controlada para o motor de faturação: `clock.set(datetime)` / `clock.advance(days=3)`."""

    def __init__(self, monkeypatch):
        import sys

        self.now = None
        for name in CLOCK_MODULES:
            mod = sys.modules.get(name)
            if mod is not None and getattr(mod, "utcnow", None) is _REAL_UTCNOW:
                monkeypatch.setattr(mod, "utcnow", self)

    def __call__(self):
        return self.now if self.now is not None else _REAL_UTCNOW()

    def set(self, dt):
        from datetime import timezone

        self.now = dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
        return self.now

    def advance(self, **delta):
        self.now = self() + timedelta(**delta)
        return self.now


@pytest.fixture
def clock(monkeypatch) -> Clock:
    return Clock(monkeypatch)


def dt(y: int, m: int, d: int, h: int = 12, mi: int = 0):
    from datetime import datetime, timezone

    return datetime(y, m, d, h, mi, tzinfo=timezone.utc)


async def add_method(svc, user: User, provider: str = "gocardless", *, default: bool = True, status: str = "active",
                     account: str | None = None, expires_at=None, **card) -> PaymentMethod:
    """Método de pagamento guardado, com o recurso correspondente criado no fake do fornecedor."""
    if provider == "gocardless":
        cust = svc.gc.add_customer(user.email)
        md = svc.gc.add_mandate(cust["id"])
        ref, customer, acct, kind, label = md["id"], cust["id"], account or svc.gc.creditor_id, "sepa", \
            "Débito direto · CGD ••••11"
    else:
        async with dbs() as db:
            u = await db.get(User, user.id)
            if not u.stripe_customer_id:
                cid = f"cus_{user.username}"
                svc.stripe.customers[cid] = {"id": cid, "object": "customer", "email": user.email}
                u.stripe_customer_id = cid
                await db.commit()
            customer = u.stripe_customer_id
        pm = svc.stripe.add_payment_method(customer, **card)
        ref, acct, kind, label = pm["id"], account or svc.stripe.account_id, "card", "Cartão Visa ••••4242"
    async with dbs() as db:
        if default:
            from sqlalchemy import update as sa_update

            await db.execute(sa_update(PaymentMethod).where(PaymentMethod.user_id == user.id).values(is_default=False))
        pm_row = PaymentMethod(user_id=user.id, provider=provider, provider_ref=ref, provider_customer_id=customer,
                               provider_account=acct, kind=kind, label=label, status=status, is_default=default,
                               expires_at=expires_at)
        db.add(pm_row)
        await db.commit()
        return pm_row


async def fresh_user(name: str) -> User:
    async with dbs() as db:
        return await db.scalar(select(User).where(User.username == name))


async def cycle(user: User, now=None):
    """Corre o ciclo de faturação do cliente (como o job `billing_cycle`) e devolve a cobrança emitida."""
    from app.services import billing

    async with dbs() as db:
        u = await db.get(User, user.id)
        inv = await billing.run_cycle(db, u, now=now)
        await db.commit()
        return inv


async def make_product(code: str, *, plans: list[tuple[str, int, str]] | None = None, fulfillment: str = "none",
                       bonus_eligible: bool = False, jellyfin_managed: bool = False, **kw):
    """Produto extra (ex.: "cloud") com planos [(código, preço, month|year)]. Devolve (produto, {código: plano})."""
    from app.models import Product

    async with dbs() as db:
        p = Product(code=code, name=code.title(), kind="other", fulfillment=fulfillment, bonus_eligible=bonus_eligible,
                    jellyfin_managed=jellyfin_managed, sort_order=5, **kw)
        db.add(p)
        await db.flush()
        out = {}
        for pcode, price, unit in plans or [(f"{code}-m", 300, "month")]:
            pl = Plan(product_id=p.id, code=pcode, name=pcode.replace("-", " ").title(), price_cents=price,
                      interval_unit=unit, features={})
            db.add(pl)
            out[pcode] = pl
        await db.commit()
        return p, out


async def subscribe_api(client, plan_code: str, *, expect: int = 200, **body) -> dict:
    plan = await plan_by_code(plan_code)
    r = await client.post("/api/billing/subscribe", json={"plan_id": plan.id, **body})
    assert r.status_code == expect, r.text
    return r.json()


async def customer(make_client, svc, name: str, *, provider: str | None = "stripe", **kw):
    """Cliente com sessão e um método de pagamento guardado. Devolve (user, client, método)."""
    u = await create_user(name, **kw)
    c = make_client()
    await c.login_as(u)
    pm = await add_method(svc, u, provider) if provider else None
    return u, c, pm
