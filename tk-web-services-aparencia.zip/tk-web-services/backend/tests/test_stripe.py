"""Stripe na faturação consolidada: método guardado via Checkout (setup), PaymentIntents fora de sessão por
cobrança, "pagar agora" (Checkout em modo payment) e webhooks (checkout, payment_intent, disputas, reembolsos,
métodos removidos)."""
from __future__ import annotations

import json
import time
from datetime import datetime, timezone

from conftest import (
    add_method,
    create_user,
    customer,
    cycle,
    drain,
    dt,
    emails,
    fetch,
    fetch_one,
    get,
    plan_by_code,
    post_stripe_webhook,
    stripe_signature,
    subscribe_api,
)

from app.integrations import stripe_client as sc
from app.models import Checkout, Invoice, Payment, PaymentMethod, Subscription, SubStatus, User, WebhookEvent


async def stripe_subscribe(client, svc, user: User, plan_code: str = "tkflix-mensal") -> Subscription:
    """Cliente com cartão guardado que subscreve (cobrança imediata paga)."""
    await add_method(svc, user, "stripe")
    await client.login_as(user)
    out = await subscribe_api(client, plan_code)
    await drain()
    return await get(Subscription, out["subscription_id"])


def session_form(svc, session_id: str) -> dict:
    return next(f for m, p, f in svc.stripe.form_log if p == "/v1/checkout/sessions" and m == "POST"
                and svc.stripe.sessions[session_id]["client_reference_id"] == f.get("client_reference_id"))


# --------------------------------------------------------------------------- guardar o método (Checkout setup)
async def test_setup_session_creates_customer_and_saves_card(make_client, svc):
    u = await create_user("maria", display_name="Maria S.")
    c = make_client()
    await c.login_as(u)
    r = await c.post("/api/billing/payment-methods", json={"provider": "stripe"})
    assert r.status_code == 200, r.text
    out = r.json()
    assert out["redirect_url"].startswith("https://checkout.stripe.com/c/pay/cs_test_")
    co = await get(Checkout, out["checkout_id"])
    assert co.provider == "stripe" and co.purpose == "setup_pm" and co.status == "pending"
    [(_, _, cust_form)] = [x for x in svc.stripe.form_log if x[1] == "/v1/customers"]
    assert cust_form["email"] == "maria@example.com" and cust_form["name"] == "Maria S."
    assert cust_form["metadata[portal_user_id]"] == u.id
    user = await get(User, u.id)
    assert user.stripe_customer_id.startswith("cus_")
    form = session_form(svc, co.provider_ref)
    assert form["mode"] == "setup" and form["customer"] == user.stripe_customer_id
    assert form["success_url"] == f"https://portal.test/app/pagamento/retorno?checkout={co.id}"
    assert form["cancel_url"] == "https://portal.test/app/faturacao?cancelado=1"
    assert form["metadata[checkout_id]"] == co.id and form["setup_intent_data[metadata][portal_user_id]"] == u.id
    [req] = svc.stripe.find("POST", r"^/v1/checkout/sessions$")
    assert req.headers["idempotency-key"] == f"setup-{co.id}"

    # regresso antes de concluir → pendente; depois de concluir → método guardado
    assert (await c.get(f"/api/billing/checkout/{co.id}")).json()["status"] == "pending"
    svc.stripe.complete_setup(co.provider_ref, brand="mastercard", last4="5555", exp_month=12, exp_year=2030)
    r = await c.get(f"/api/billing/checkout/{co.id}")
    assert r.json()["status"] == "completed"
    pm = await fetch_one(PaymentMethod)
    assert pm.provider == "stripe" and pm.kind == "card" and pm.label == "Cartão Mastercard ••••5555"
    assert pm.expires_at == datetime(2031, 1, 1, tzinfo=timezone.utc) and pm.is_default
    assert pm.provider_customer_id == user.stripe_customer_id and pm.provider_account == svc.stripe.account_id

    # segundo método reutiliza o cliente Stripe; checkout de outro utilizador não é visível
    await c.post("/api/billing/payment-methods", json={"provider": "stripe"})
    assert len(svc.stripe.find("POST", r"^/v1/customers$")) == 1
    other = make_client()
    await other.login_as(await create_user("joao"))
    assert (await other.get(f"/api/billing/checkout/{co.id}")).status_code == 404


async def test_checkout_completed_webhook_subscribes(client, svc):
    u = await create_user("maria")
    await client.login_as(u)
    out = await subscribe_api(client, "tkflix-mensal", provider="stripe")
    assert out["status"] == "redirect"
    co = await get(Checkout, out["checkout_id"])
    pm = svc.stripe.complete_setup(co.provider_ref)
    for _ in range(2):  # o Stripe pode reenviar o evento
        r = await post_stripe_webhook(client, "checkout.session.completed",
                                      {"id": co.provider_ref, "object": "checkout.session",
                                       "client_reference_id": co.id}, event_id="evt_cs_1")
        assert r.status_code == 200
    await drain()
    co = await get(Checkout, co.id)
    assert co.status == "completed"
    sub = await get(Subscription, co.intent["subscription_id"])
    assert sub.status == SubStatus.active and sub.provider == "portal"
    inv = await fetch_one(Invoice)
    assert inv.status == "paid" and inv.total_cents == 500
    [pi] = svc.stripe.charges()
    assert pi["payment_method"] == pm["id"] and pi["amount"] == 500 and pi["metadata"]["invoice_id"] == inv.id
    assert svc.stripe.keys_for("/v1/payment_intents") == [f"inv-{inv.id}-1"]
    ev = await fetch_one(WebhookEvent)
    assert ev.status == "processed" and ev.event_type == "checkout.session.completed"
    r = await client.get(f"/api/billing/checkout/{co.id}")
    assert r.json()["subscription_id"] == sub.id and r.json()["return_to"] == "/app/servicos"
    assert (await client.get("/api/auth/me")).json()["has_access"] is True
    assert svc.jf.by_name("maria") is not None
    assert not await emails("subscription_active", to=u.email)  # sem emails de confirmação (o cliente vê no portal)


async def test_checkout_intent_fails_cleanly_when_card_is_declined(client, svc):
    u = await create_user("maria")
    await client.login_as(u)
    out = await subscribe_api(client, "tkflix-mensal", provider="stripe")
    co = await get(Checkout, out["checkout_id"])
    pm = svc.stripe.complete_setup(co.provider_ref)
    svc.stripe.behavior[pm["id"]] = ("card_error", "insufficient_funds")
    r = await client.get(f"/api/billing/checkout/{co.id}")
    body = r.json()
    assert body["status"] == "completed" and body["subscription_id"] is None and "recusado" in body["error"]
    assert (await fetch_one(PaymentMethod)).status == "active"  # o cartão fica guardado
    assert (await fetch_one(Subscription)).status == SubStatus.ended
    assert (await fetch_one(Invoice)).status == "void"


async def test_expired_session_cancels_checkout(client, svc):
    u = await create_user("maria")
    await client.login_as(u)
    out = (await client.post("/api/billing/payment-methods", json={"provider": "stripe"})).json()
    co = await get(Checkout, out["checkout_id"])
    svc.stripe.expire_session(co.provider_ref)
    await post_stripe_webhook(client, "checkout.session.expired",
                              {"id": co.provider_ref, "object": "checkout.session", "client_reference_id": co.id})
    await drain()
    assert (await get(Checkout, co.id)).status == "cancelled"
    assert await fetch(PaymentMethod) == []
    # checkout desconhecido → ignorado
    await post_stripe_webhook(client, "checkout.session.completed", {"id": "cs_x", "client_reference_id": "nope"})
    await drain()
    assert {e.status for e in await fetch(WebhookEvent)} == {"processed", "ignored"}


# --------------------------------------------------------------------------- cobranças fora de sessão
async def test_sepa_via_stripe_processing_then_succeeded_webhook(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, c, pm = await customer(make_client, svc, "maria")
    await subscribe_api(c, "tkflix-mensal")
    svc.stripe.behavior[pm.provider_ref] = "processing"
    clock.set(dt(2026, 11, 5, 6))
    inv = await cycle(u)
    assert inv.status == "processing"
    pi = svc.stripe.charges()[-1]
    pay = await fetch_one(Payment, provider_payment_id=pi["id"])
    assert pay.status == "pending"
    pi["status"] = "succeeded"
    await post_stripe_webhook(c, "payment_intent.succeeded", {"id": pi["id"], "object": "payment_intent"})
    await drain()
    assert (await get(Invoice, inv.id)).status == "paid"
    assert (await get(Payment, pay.id)).status == "paid"
    # webhook de um PaymentIntent que não é nosso
    await post_stripe_webhook(c, "payment_intent.succeeded", {"id": "pi_desconhecido"})
    await drain()
    assert (await get(Invoice, inv.id)).status == "paid"


async def test_async_failure_webhook_sets_past_due(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, c, pm = await customer(make_client, svc, "maria")
    out = await subscribe_api(c, "tkflix-mensal")
    svc.stripe.behavior[pm.provider_ref] = "processing"
    clock.set(dt(2026, 11, 5, 6))
    inv = await cycle(u)
    pi = svc.stripe.charges()[-1]
    pi["status"] = "requires_payment_method"
    pi["last_payment_error"] = {"code": "card_declined", "decline_code": "insufficient_funds",
                                "message": "Saldo insuficiente."}
    await post_stripe_webhook(c, "payment_intent.payment_failed", {"id": pi["id"], "object": "payment_intent"})
    await drain()
    inv = await get(Invoice, inv.id)
    assert inv.status == "failed" and inv.last_error == "Saldo insuficiente." and inv.attempt_count == 1
    sub = await get(Subscription, out["subscription_id"])
    assert sub.status == SubStatus.past_due and sub.grace_until == dt(2026, 11, 15, 6)
    assert (await get(PaymentMethod, pm.id)).status == "active"  # recusa normal: o cartão continua válido
    [mail] = await emails("payment_failed", to=u.email)
    assert mail["ctx"]["reason"] == "Saldo insuficiente."


async def test_authentication_required_asks_customer_to_pay_now(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, c, pm = await customer(make_client, svc, "maria")
    out = await subscribe_api(c, "tkflix-mensal")
    svc.stripe.behavior[pm.provider_ref] = ("requires_action",)
    clock.set(dt(2026, 11, 5, 6))
    inv = await cycle(u)
    assert inv.status == "failed" and "authentication" in inv.last_error
    assert (await get(PaymentMethod, pm.id)).status == "active"

    # "Pagar agora": Checkout em modo payment com o valor da cobrança (guarda o método para as próximas)
    r = await c.post(f"/api/billing/invoices/{inv.id}/pay", json={"provider": "stripe"})
    assert r.status_code == 200, r.text
    co = await get(Checkout, r.json()["checkout_id"])
    assert co.purpose == "pay_invoice" and co.invoice_id == inv.id
    form = session_form(svc, co.provider_ref)
    assert form["mode"] == "payment" and form["line_items[0][price_data][unit_amount]"] == "500"
    assert form["payment_intent_data[setup_future_usage]"] == "off_session"
    assert form["payment_intent_data[metadata][invoice_id]"] == inv.id
    [req] = [q for q in svc.stripe.find("POST", r"^/v1/checkout/sessions$")
             if q.headers["idempotency-key"] == f"pay-{co.id}"]
    assert req

    svc.stripe.complete_payment(co.provider_ref, last4="1111")
    await post_stripe_webhook(c, "checkout.session.completed", {"id": co.provider_ref, "client_reference_id": co.id})
    await drain()
    inv = await get(Invoice, inv.id)
    assert inv.status == "paid" and inv.attempt_count == 2
    assert (await get(Subscription, out["subscription_id"])).status == SubStatus.active
    new_pm = await get(PaymentMethod, (await get(Checkout, co.id)).payment_method_id)
    assert new_pm.label.endswith("••••1111") and new_pm.is_default and new_pm.id != pm.id
    assert (await c.get(f"/api/billing/checkout/{co.id}")).json()["status"] == "completed"
    assert len([p for p in await fetch(Payment) if p.invoice_id == inv.id and p.status == "paid"]) == 1
    assert not await emails("payment_received", to=u.email)  # sem emails de confirmação (o cliente vê no portal)


async def test_expired_card_decline_falls_back_to_other_method(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, c, card = await customer(make_client, svc, "maria")
    await subscribe_api(c, "tkflix-mensal")
    sepa = await add_method(svc, u, "gocardless", default=False)
    svc.stripe.behavior[card.provider_ref] = ("card_error", "expired_card")
    clock.set(dt(2026, 11, 5, 6))
    inv = await cycle(u)
    # o cartão é recusado como inutilizável → tenta o mandato com outra chave de idempotência
    assert inv.status == "processing" and inv.attempt_count == 2 and inv.payment_method_id == sepa.id
    assert svc.stripe.keys_for("/v1/payment_intents")[-1] == f"inv-{inv.id}-1"
    assert svc.gc.charges()[-1]["idempotency_key"] == f"inv-{inv.id}-2"
    card = await get(PaymentMethod, card.id)
    assert card.status == "revoked" and card.is_default is False
    assert (await get(PaymentMethod, sepa.id)).is_default is True
    assert await emails("payment_failed") == [] and await emails("payment_method_needed") == []
    assert sorted(p.status for p in await fetch(Payment, invoice_id=inv.id)) == ["failed", "pending"]


async def test_provider_outage_on_cycle_is_retried_with_same_key(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, c, _ = await customer(make_client, svc, "maria")
    await subscribe_api(c, "tkflix-mensal")
    svc.stripe.fail_paths["/v1/payment_intents"] = 500
    clock.set(dt(2026, 11, 5, 6))
    inv = await cycle(u)
    assert inv.status == "open" and inv.attempt_count == 0
    assert (await get(User, u.id)).next_billing_at == dt(2026, 12, 5, 6)  # o ciclo não corre outra vez
    del svc.stripe.fail_paths["/v1/payment_intents"]
    clock.advance(minutes=6)
    await drain()
    inv = await get(Invoice, inv.id)
    assert inv.status == "paid" and inv.attempt_count == 1
    assert svc.stripe.keys_for("/v1/payment_intents")[-2:] == [f"inv-{inv.id}-1"] * 2
    assert await emails("payment_failed") == []


# --------------------------------------------------------------------------- outros webhooks
async def test_dispute_is_a_chargeback(client, svc):
    u = await create_user("maria")
    sub = await stripe_subscribe(client, svc, u)
    [pi] = svc.stripe.charges()
    await post_stripe_webhook(client, "charge.dispute.created",
                              {"id": "dp_1", "object": "dispute", "payment_intent": pi["id"]})
    await drain()
    pay = await fetch_one(Payment)
    assert pay.status == "charged_back" and "chargeback" in pay.failure_reason
    inv = await fetch_one(Invoice)
    assert inv.status == "failed" and inv.paid_at is None
    assert (await get(Subscription, sub.id)).status == SubStatus.past_due


async def test_refund_marks_payment(client, svc):
    u = await create_user("maria")
    await stripe_subscribe(client, svc, u)
    [pi] = svc.stripe.charges()
    await post_stripe_webhook(client, "charge.refunded", {"id": "ch_1", "object": "charge", "payment_intent": pi["id"]})
    await drain()
    assert (await fetch_one(Payment)).status == "refunded"
    assert (await fetch_one(Invoice)).status == "paid"  # o reembolso é uma decisão do admin, não uma dívida


async def test_payment_method_detached_revokes_method(client, svc):
    u = await create_user("maria")
    await stripe_subscribe(client, svc, u)
    pm = await fetch_one(PaymentMethod)
    await post_stripe_webhook(client, "payment_method.detached", {"id": pm.provider_ref, "object": "payment_method"})
    await drain()
    pm = await get(PaymentMethod, pm.id)
    assert pm.status == "revoked" and pm.status_reason == "Método removido no Stripe"
    assert await emails("payment_method_needed", to=u.email)


async def test_customer_deleted_unlinks_and_revokes(client, svc):
    u = await create_user("maria")
    await stripe_subscribe(client, svc, u)
    cid = (await get(User, u.id)).stripe_customer_id
    await post_stripe_webhook(client, "customer.deleted", {"id": cid, "object": "customer"})
    await drain()
    assert (await get(User, u.id)).stripe_customer_id is None
    assert (await fetch_one(PaymentMethod)).status == "revoked"


def test_helpers_handle_both_shapes():
    assert sc.invoice_subscription_id({"subscription": "sub_a"}) == "sub_a"
    assert sc.invoice_subscription_id({"subscription": {"id": "sub_b"}}) == "sub_b"
    assert sc.invoice_subscription_id({"parent": {"subscription_details": {"subscription": "sub_c"}}}) == "sub_c"
    assert sc.invoice_subscription_id(
        {"lines": {"data": [{"parent": {"subscription_item_details": {"subscription": "sub_d"}}}]}}) == "sub_d"
    assert sc.invoice_subscription_id({}) is None
    assert sc.sub_period_end({"items": {"data": [{"current_period_end": 100}, {"current_period_end": 200}]}}
                             ) == datetime.fromtimestamp(200, tz=timezone.utc)
    assert sc.sub_period_end({"current_period_end": 50}) == datetime.fromtimestamp(50, tz=timezone.utc)
    assert sc.sub_period_end({}) is None


async def test_webhook_signature_and_duplicates(client):
    body = json.dumps({"id": "evt_x", "type": "customer.created", "data": {"object": {}}}).encode()
    r = await client.post("/api/webhooks/stripe", content=body, headers={"Stripe-Signature": "t=1,v1=00"})
    assert r.status_code == 400
    r = await client.post("/api/webhooks/stripe", content=body)
    assert r.status_code == 400
    old = int(time.time()) - 3600
    r = await client.post("/api/webhooks/stripe", content=body,
                          headers={"Stripe-Signature": stripe_signature(body, ts=old)})
    assert r.status_code == 400  # fora da tolerância (replay)
    r = await post_stripe_webhook(client, "customer.created", {"id": "cus_1"}, secret="whsec_outro")
    assert r.status_code == 400
    assert await fetch(WebhookEvent) == []
    for _ in range(2):
        r = await post_stripe_webhook(client, "customer.created", {"id": "cus_1"}, event_id="evt_same")
        assert r.status_code == 200
    assert len(await fetch(WebhookEvent)) == 1
    await drain()
    assert (await fetch_one(WebhookEvent)).status == "ignored"


async def test_concurrent_duplicate_webhooks_stored_once(client):
    import asyncio

    rs = await asyncio.gather(*[post_stripe_webhook(client, "customer.created", {"id": "cus_1"}, event_id="evt_race")
                                for _ in range(4)])
    assert {r.status_code for r in rs} == {200}
    assert len(await fetch(WebhookEvent)) == 1


async def test_old_stripe_billing_endpoints_are_gone(client):
    u = await create_user("maria")
    await client.login_as(u)
    assert (await client.post("/api/billing/portal")).status_code in (404, 405)
    assert (await client.post("/api/billing/checkout", json={"plan_id": 1, "provider": "stripe"})).status_code in (
        404, 405)
    plan = await plan_by_code("tkflix-mensal")
    assert plan.stripe_price_id is None  # já não é preciso configurar preços no Stripe
