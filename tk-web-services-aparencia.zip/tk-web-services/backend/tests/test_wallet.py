"""Carteira de créditos: carregamentos, uso nas cobranças, carregamento mensal, contas só-carteira e estornos."""
from __future__ import annotations

from conftest import (
    create_user,
    customer,
    cycle,
    dbs,
    drain,
    dt,
    fetch,
    fetch_one,
    gc_event,
    get,
    plan_by_code,
    post_gc_webhook,
    subscribe_api,
)
from sqlalchemy import select

from app.models import Invoice, InvoiceLine, Subscription, SubStatus, User, Wallet, WalletTransaction
from app.services import billing
from app.services import wallet as wallet_svc


import pytest


@pytest.fixture
def monthly_on(settings):
    """Carregamento mensal e contas só-carteira (desligados por omissão — faturação por autorização)."""
    settings.set("wallet_monthly_enabled", True)
    settings.set("wallet_only_for_new_users", True)
    settings.set("billing_require_method", False)


async def credit(user: User, cents: int, kind: str = "adjustment") -> None:
    async with dbs() as db:
        await wallet_svc.post(db, user.id, cents, kind, "teste")
        await db.commit()


async def balance(user: User) -> int:
    async with dbs() as db:
        return await wallet_svc.balance(db, user.id)


async def lines_of(inv_id: str) -> list[InvoiceLine]:
    async with dbs() as db:
        return list((await db.scalars(select(InvoiceLine).where(InvoiceLine.invoice_id == inv_id)
                                      .order_by(InvoiceLine.id))).all())


# --------------------------------------------------------------------------- razão
async def test_ledger_is_idempotent_and_never_negative():
    u = await create_user("maria")
    async with dbs() as db:
        await wallet_svc.post(db, u.id, 700, "topup", "a", key="k1")
        assert await wallet_svc.post(db, u.id, 700, "topup", "a", key="k1") is None  # repetido: nada
        try:
            await wallet_svc.post(db, u.id, -800, "game_bet", "b")
            raise AssertionError("devia recusar saldo negativo")
        except wallet_svc.WalletError:
            pass
        await db.commit()
    assert await balance(u) == 700
    txs = await fetch(WalletTransaction, user_id=u.id)
    assert len(txs) == 1 and txs[0].balance_after_cents == 700


# --------------------------------------------------------------------------- carregamento único
async def test_one_off_topup_minimum_and_card_charge(make_client, svc):
    u, c, pm = await customer(make_client, svc, "maria")
    r = await c.post("/api/wallet/topup", json={"amount_cents": 499})
    assert r.status_code == 400 and "5,00" in r.json()["detail"]
    r = await c.post("/api/wallet/topup", json={"amount_cents": 1500})
    assert r.status_code == 200 and r.json()["status"] == "paid", r.text
    assert await balance(u) == 1500
    inv = await fetch_one(Invoice, user_id=u.id)
    assert inv.kind == "topup" and inv.status == "paid" and inv.total_cents == 1500
    [charge] = svc.stripe.charges()
    assert int(charge["amount"]) == 1500
    w = (await c.get("/api/wallet")).json()
    assert w["balance_cents"] == 1500 and w["transactions"][0]["kind"] == "topup"


async def test_declined_topup_is_voided_not_debt(make_client, svc):
    u, c, pm = await customer(make_client, svc, "maria")
    svc.stripe.behavior[pm.provider_ref] = ("card_error", "insufficient_funds")
    r = await c.post("/api/wallet/topup", json={"amount_cents": 1000})
    assert r.status_code == 400 and "recusado" in r.json()["detail"]
    inv = await fetch_one(Invoice, user_id=u.id)
    assert inv.status == "void" and inv.next_attempt_at is None
    async with dbs() as db:
        assert await billing.unpaid_invoices(db, u.id) == []
    assert await balance(u) == 0


async def test_sepa_topup_credits_only_when_confirmed(make_client, svc):
    u, c, pm = await customer(make_client, svc, "maria", provider="gocardless")
    r = await c.post("/api/wallet/topup", json={"amount_cents": 2000})
    assert r.json()["status"] == "processing"
    assert await balance(u) == 0
    assert (await c.get("/api/wallet")).json()["pending_topup_cents"] == 2000
    [p] = svc.gc.charges()
    svc.gc.set_payment(p["id"], "confirmed")
    await post_gc_webhook(c, [gc_event("payments", "confirmed", payment=p["id"])])
    await drain()
    assert await balance(u) == 2000
    # webhook repetido não credita outra vez
    await post_gc_webhook(c, [gc_event("payments", "paid_out", payment=p["id"])])
    await drain()
    assert await balance(u) == 2000


# --------------------------------------------------------------------------- o saldo paga primeiro
async def test_cycle_uses_wallet_first_and_charges_the_rest(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, c, pm = await customer(make_client, svc, "maria")
    await subscribe_api(c, "tkflix-mensal")  # 5,00 € cobrados ao cartão
    await credit(u, 300)
    clock.set(dt(2026, 11, 5, 6))
    inv = await cycle(u)
    kinds = {ln.kind: ln.amount_cents for ln in await lines_of(inv.id)}
    assert kinds["renewal"] == 500 and kinds["wallet"] == -300
    assert inv.total_cents == 200 and inv.status == "paid"
    assert int(svc.stripe.charges()[-1]["amount"]) == 200
    assert await balance(u) == 0


async def test_wallet_covering_everything_means_no_charge(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, c, pm = await customer(make_client, svc, "maria")
    await subscribe_api(c, "tkflix-mensal")
    await credit(u, 2000)
    before = len(svc.stripe.charges())
    clock.set(dt(2026, 11, 5, 6))
    inv = await cycle(u)
    assert inv.total_cents == 0 and inv.status == "paid"
    assert len(svc.stripe.charges()) == before
    assert await balance(u) == 1500
    summary = (await c.get("/api/billing/summary")).json()
    assert summary["upcoming"]["wallet_cents"] == 500 and summary["upcoming"]["total_cents"] == 0


async def test_voided_first_invoice_refunds_wallet(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, c, pm = await customer(make_client, svc, "maria")
    await credit(u, 200)
    svc.stripe.behavior[pm.provider_ref] = ("card_error", "card_declined")
    r = await c.post("/api/billing/subscribe", json={"plan_id": (await plan_by_code("tkflix-mensal")).id})
    assert r.status_code == 400
    inv = await fetch_one(Invoice, user_id=u.id)
    assert inv.status == "void"
    assert await balance(u) == 200  # os 2 € reservados voltaram


# --------------------------------------------------------------------------- carregamento mensal
async def test_monthly_topup_single_charge_funds_services_and_skips_when_covered(monthly_on, make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, c, pm = await customer(make_client, svc, "maria")
    await subscribe_api(c, "tkflix-mensal")
    r = await c.put("/api/wallet/monthly", json={"amount_cents": 800})
    assert r.status_code == 200 and "8,00" in r.json()["message"]
    # dia de faturação: uma só cobrança de 8 € — paga os 5 € do TKFLIX e 3 € ficam na carteira
    clock.set(dt(2026, 11, 5, 6))
    inv = await cycle(u)
    kinds = [(ln.kind, ln.amount_cents) for ln in await lines_of(inv.id)]
    assert ("renewal", 500) in kinds and ("mtopup", 800) in kinds and ("topup_use", -500) in kinds
    assert inv.total_cents == 800 and inv.status == "paid"
    assert int(svc.stripe.charges()[-1]["amount"]) == 800
    assert await balance(u) == 300
    # os ganhos (ou um carregamento) cobrem o mês seguinte → sem carregamento nem cobrança
    await credit(u, 500)
    before = len(svc.stripe.charges())
    clock.set(dt(2026, 12, 5, 6))
    inv = await cycle(u)
    assert inv.total_cents == 0 and not [ln for ln in await lines_of(inv.id) if ln.kind == "mtopup"]
    assert len(svc.stripe.charges()) == before
    assert await balance(u) == 300


async def test_monthly_topup_bonus_percent(monthly_on, make_client, svc, clock, settings):
    settings.set("wallet_monthly_bonus_percent", 5)
    clock.set(dt(2026, 10, 5, 12))
    u, c, pm = await customer(make_client, svc, "maria")
    await subscribe_api(c, "tkflix-mensal")
    await c.put("/api/wallet/monthly", json={"amount_cents": 1000})
    clock.set(dt(2026, 11, 5, 6))
    await cycle(u)
    assert await balance(u) == 1000 - 500 + 50


async def test_monthly_only_without_services_charges_now_then_monthly(monthly_on, make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 3))  # antes da hora de faturação do próprio dia
    u, c, pm = await customer(make_client, svc, "maria")
    await c.put("/api/wallet/monthly", json={"amount_cents": 1000})
    user = await get(User, u.id)
    assert user.billing_anchor_day == 5 and user.next_billing_at == dt(2026, 10, 5, 3)
    await cycle(u)
    assert await balance(u) == 1000
    user = await get(User, u.id)
    assert user.next_billing_at == dt(2026, 11, 5, 6)  # não volta a cobrar no mesmo dia


async def test_new_account_is_wallet_only(monthly_on, make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, c, pm = await customer(make_client, svc, "novo", billing_mode="wallet")
    plan = await plan_by_code("tkflix-mensal")
    r = await c.post("/api/billing/subscribe", json={"plan_id": plan.id})
    assert r.status_code == 400 and "carteira" in r.json()["detail"].lower()
    q = (await c.get("/api/billing/quote", params={"plan_id": plan.id})).json()
    assert q["wallet_only"] is True and q["suggested_monthly_cents"] == 500
    # aderir com o carregamento mensal no mesmo passo: uma cobrança só
    out = await subscribe_api(c, "tkflix-mensal", monthly_topup_cents=1000)
    assert out["status"] == "active"
    [inv] = await fetch(Invoice, user_id=u.id)
    assert inv.total_cents == 1000 and inv.status == "paid"
    assert await balance(u) == 500
    assert (await get(Wallet, u.id)).monthly_topup_cents == 1000


async def test_wallet_only_can_subscribe_with_balance_and_no_method(monthly_on, make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, c, _ = await customer(make_client, svc, "novo", provider=None, billing_mode="wallet")
    await credit(u, 600)
    out = await subscribe_api(c, "tkflix-mensal")
    assert out["status"] == "active"
    sub = await get(Subscription, out["subscription_id"])
    assert sub.status == SubStatus.active
    assert await balance(u) == 100 and svc.stripe.charges() == []


async def test_topup_settles_overdue_invoice(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, c, pm = await customer(make_client, svc, "maria")
    await subscribe_api(c, "tkflix-mensal")
    svc.stripe.behavior[pm.provider_ref] = ("card_error", "insufficient_funds")
    clock.set(dt(2026, 11, 5, 6))
    inv = await cycle(u)
    assert inv.status == "failed"
    sub = await fetch_one(Subscription, user_id=u.id)
    assert sub.status == SubStatus.past_due
    async with dbs() as db:
        await wallet_svc.admin_adjust(db, await db.get(User, u.id), await db.get(User, u.id), 1000, "oferta")
        await db.commit()
    inv = await get(Invoice, inv.id)
    assert inv.status == "paid"
    assert (await get(Subscription, sub.id)).status == SubStatus.active
    assert await balance(u) == 1000 - 500


async def test_chargeback_reverses_topup_and_debt_goes_to_next_invoice(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, c, pm = await customer(make_client, svc, "maria", provider="gocardless")
    await c.post("/api/wallet/topup", json={"amount_cents": 1000})
    [p] = svc.gc.charges()
    svc.gc.set_payment(p["id"], "confirmed")
    await post_gc_webhook(c, [gc_event("payments", "confirmed", payment=p["id"])])
    await drain()
    assert await balance(u) == 1000
    # gastou 800 e depois o banco estornou o carregamento
    async with dbs() as db:
        await wallet_svc.post(db, u.id, -800, "game_bet", "aposta")
        await db.commit()
    svc.gc.set_payment(p["id"], "charged_back")
    await post_gc_webhook(c, [gc_event("payments", "charged_back", payment=p["id"])])
    await drain()
    assert await balance(u) == -800
    # o saldo negativo entra na cobrança seguinte e a carteira volta a zero
    await subscribe_api(c, "tkflix-mensal")
    inv = (await fetch(Invoice, kind="immediate"))[0]
    kinds = {ln.kind: ln.amount_cents for ln in await lines_of(inv.id)}
    assert kinds["adjustment"] == 800 and inv.total_cents == 1300
    assert await balance(u) == 0


async def test_admin_convert_legacy_to_monthly(monthly_on, make_client, svc, clock, admin_client):
    clock.set(dt(2026, 10, 5, 12))
    u, c, pm = await customer(make_client, svc, "maria")
    await subscribe_api(c, "tkflix-tv-mensal")  # 7,50 €
    r = await admin_client.post(f"/api/admin/users/{u.id}/wallet/convert")
    assert r.status_code == 200 and r.json()["result"] == "convertido", r.text
    assert (await get(Wallet, u.id)).monthly_topup_cents == 800  # arredondado ao euro
    r = await admin_client.post(f"/api/admin/users/{u.id}/wallet/adjust", json={"amount_cents": 250, "reason": "x"})
    assert r.status_code == 200
    assert await balance(u) == 250


async def test_wallet_page_requires_full_session(make_client):
    u = await create_user("maria")
    c = make_client()
    await c.login_as(u, scope="streaming")
    assert (await c.get("/api/wallet")).status_code == 403


async def test_stale_hosted_topup_is_voided_never_auto_charged(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, c, pm = await customer(make_client, svc, "maria")
    r = await c.post("/api/wallet/topup", json={"amount_cents": 1000, "provider": "stripe"})
    assert r.json()["status"] == "redirect"
    clock.set(dt(2026, 10, 8, 12))
    async with dbs() as db:
        await billing.schedule_due(db)
    await drain()
    inv = await fetch_one(Invoice, user_id=u.id)
    assert inv.status == "void" and svc.stripe.charges() == []
