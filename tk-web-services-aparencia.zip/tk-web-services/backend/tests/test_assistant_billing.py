"""Agente de Faturação: ferramentas de leitura, ações com confirmação e âmbito "streaming"."""
from __future__ import annotations

import json
from datetime import timedelta

import pytest
from asst import as_json, confirm_action, expire_action, run_tool
from conftest import add_sub, create_user, customer, dbs, fetch, fetch_one, get, make_product, plan_by_code, update_row

from app.assistant.models import PendingAction
from app.assistant.tools import ToolFailure
from app.db import utcnow
from app.models import Invoice, InvoiceLine, PaymentMethod, Subscription, SubStatus


async def propose(user, tool, *, scope=None, channel="web", **args):
    out, result = await run_tool(user, tool, agent="billing", scope=scope, channel=channel, **args)
    events = [m for m in result.messages if (m.ui or {}).get("type") == "confirm"]
    return out, (events[0].ui["action_id"] if events else None), (events[0].content if events else None)


@pytest.fixture
async def paying(make_client, svc):
    """Cliente com cartão guardado e o TKFLIX mensal subscrito (pelo próprio assistente, com confirmação)."""
    u, _, _ = await customer(make_client, svc, "ana")
    plan = await plan_by_code("tkflix-mensal")
    out, action_id, summary = await propose(u, "change_or_subscribe_plan", plan_id=plan.id)
    assert action_id and summary.startswith("Aderir a TKFLIX")
    assert "NÃO está feita" in out
    assert not await fetch(Subscription)  # nada feito antes da confirmação
    content = await confirm_action(u, action_id)
    assert "TKFLIX" in content and ("ativo" in content or "Pedido feito" in content)
    return u


async def test_overview_and_catalog(paying):
    d = as_json((await run_tool(paying, "get_billing_overview", agent="billing"))[0])
    sub = d["subscriptions"][0]
    assert sub["plan"] == "TKFLIX" and sub["status"] == "ativa" and sub["price"] == "5,00 €/mês"
    assert d["payment_methods"][0]["default"] is True and d["unpaid_charges"] == []
    assert d["next_charge"]["date"] and d["invite_bonus"]["needed"]
    anon = as_json((await run_tool(None, "get_catalog", agent="billing"))[0])  # não precisa de conta
    # sem conta (ou sem convite) o TKFLIX é o "TK CDN" em beta fechado, sem planos nem preços
    assert anon["services"][0]["service"] == "TK CDN" and "plans" not in anon["services"][0]
    assert "TKFLIX" not in json.dumps(anon)
    cat = as_json((await run_tool(paying, "get_catalog", agent="billing"))[0])
    assert [p["name"] for p in cat["services"][0]["plans"]] == ["TKFLIX", "TKFLIX Anual", "TKFLIX + TV",
                                                                 "TKFLIX + TV Anual"]
    assert cat["services"][0]["plans"][1]["price"] == "50,00 €/ano"


async def test_quote_change_cancel_resume_flow(paying, svc):
    tv = await plan_by_code("tkflix-tv-mensal")
    mensal = await plan_by_code("tkflix-mensal")
    assert (await run_tool(paying, "quote_plan", agent="billing", plan_id=mensal.id))[0] == \
        "O cliente já está neste plano."
    q = as_json((await run_tool(paying, "quote_plan", agent="billing", plan_id=tv.id))[0])
    assert q["type"] == "mudança de plano" and q["regular_price"] == "7,50 €/mês"
    _, action_id, summary = await propose(paying, "change_or_subscribe_plan", plan_id=tv.id)
    assert summary.startswith("Mudar para TKFLIX + TV")
    content = await confirm_action(paying, action_id)
    assert content.startswith("Plano alterado para TKFLIX + TV")
    sub = await fetch_one(Subscription)
    assert sub.plan_id == tv.id
    # Cancelar → confirmar → reativar → confirmar.
    _, action_id, summary = await propose(paying, "cancel_subscription", subscription_id=sub.id)
    assert summary.startswith("Cancelar TKFLIX + TV")
    assert (await get(Subscription, sub.id)).status == SubStatus.active
    assert (await confirm_action(paying, action_id)).startswith("Cancelado")
    assert (await get(Subscription, sub.id)).status == SubStatus.canceling
    _, action_id, summary = await propose(paying, "resume_subscription", subscription_id=sub.id)
    assert summary.startswith("Reativar")
    assert (await confirm_action(paying, action_id)).startswith("Reativado")
    assert (await get(Subscription, sub.id)).status == SubStatus.active
    assert {a.status for a in await fetch(PendingAction)} == {"done"}


async def test_subscribe_without_payment_method(svc):
    u = await create_user("ana")
    plan = await plan_by_code("tkflix-mensal")
    _, action_id, _ = await propose(u, "change_or_subscribe_plan", plan_id=plan.id)
    content = await confirm_action(u, action_id)
    assert "Falta um método de pagamento" in content and "https://portal.test/app/faturacao" in content
    assert not await fetch(Subscription)
    assert (await get(PendingAction, action_id)).status == "failed"


async def test_billing_error_after_confirmation_marks_action_failed(paying):
    """Entre a proposta e a confirmação o estado mudou: o BillingError faz rollback e a ação fica 'failed'."""
    tv = await plan_by_code("tkflix-tv-mensal")
    sub = await fetch_one(Subscription)
    _, action_id, _ = await propose(paying, "change_or_subscribe_plan", plan_id=tv.id)
    await update_row(Subscription, sub.id, status=SubStatus.past_due)
    content = await confirm_action(paying, action_id)
    assert content.startswith("Não foi possível")
    assert (await get(Subscription, sub.id)).plan_id != tv.id
    action = await get(PendingAction, action_id)
    assert action.status == "failed" and action.result.startswith("Não foi possível")


async def test_resume_without_method_fails_cleanly(paying):
    sub = await fetch_one(Subscription)
    _, action_id, _ = await propose(paying, "cancel_subscription", subscription_id=sub.id)
    await confirm_action(paying, action_id)
    _, action_id, _ = await propose(paying, "resume_subscription", subscription_id=sub.id)
    for pm in await fetch(PaymentMethod):
        await update_row(PaymentMethod, pm.id, status="revoked")
    content = await confirm_action(paying, action_id)
    assert "método de pagamento" in content
    assert (await get(Subscription, sub.id)).status == SubStatus.canceling
    assert (await get(PendingAction, action_id)).status == "failed"


async def test_cancel_summary_errors(paying):
    out, action_id, _ = await propose(paying, "cancel_subscription", subscription_id="nao-existe")
    assert out == "Erro: Subscrição não encontrada nesta conta." and action_id is None
    out, action_id, _ = await propose(paying, "cancel_subscription", subscription_id="")
    assert out.startswith("Erro: ") and "interno" not in out and action_id is None
    sub = await fetch_one(Subscription)
    out, _, _ = await propose(paying, "resume_subscription", subscription_id=sub.id)
    assert out == "Erro: Esta subscrição não está cancelada."
    out, _, _ = await propose(paying, "change_or_subscribe_plan", plan_id="abc")
    assert out.startswith("Erro: plan_id inválido")


async def test_other_users_subscription_is_invisible(paying):
    bia = await create_user("bia")
    sub = await fetch_one(Subscription)
    out, action_id, _ = await propose(bia, "cancel_subscription", subscription_id=sub.id)
    assert out == "Erro: Subscrição não encontrada nesta conta." and action_id is None
    # Uma ação de outro cliente não pode ser decidida por outra pessoa.
    _, action_id, _ = await propose(paying, "cancel_subscription", subscription_id=sub.id)
    with pytest.raises(ToolFailure):
        await confirm_action(bia, action_id)
    assert (await get(Subscription, sub.id)).status == SubStatus.active


async def test_expired_and_double_confirmation(paying):
    sub = await fetch_one(Subscription)
    _, action_id, _ = await propose(paying, "cancel_subscription", subscription_id=sub.id)
    await expire_action(action_id)
    assert "expirou" in await confirm_action(paying, action_id)
    assert (await get(PendingAction, action_id)).status == "expired"
    _, action_id, _ = await propose(paying, "cancel_subscription", subscription_id=sub.id)
    await confirm_action(paying, action_id)
    with pytest.raises(ToolFailure, match="já foi tratada"):
        await confirm_action(paying, action_id)
    _, action_id, _ = await propose(paying, "resume_subscription", subscription_id=sub.id)
    assert (await confirm_action(paying, action_id, confirm=False)).startswith("Ok, não fiz nada")
    assert (await get(Subscription, sub.id)).status == SubStatus.canceling


async def test_new_proposal_cancels_previous_pending(paying):
    sub = await fetch_one(Subscription)
    async with dbs() as db:
        from app.assistant import runtime
        from app.assistant.agents import get_agent
        from app.assistant.models import AssistantConversation
        from asst import tool_ctx

        from app.models import User

        u = await db.get(User, paying.id)
        conv = AssistantConversation(user_id=u.id, channel="web", agent="billing")
        db.add(conv)
        await db.flush()
        ctx = tool_ctx(db, u, conv, agent="billing")
        reg = get_agent("billing").registry
        tv = await plan_by_code("tkflix-tv-mensal")
        await runtime._execute(ctx, reg.get("cancel_subscription"), {"subscription_id": sub.id}, call_id="a",
                               result=runtime.TurnResult())
        await runtime._execute(ctx, reg.get("change_or_subscribe_plan"), {"plan_id": tv.id}, call_id="b",
                               result=runtime.TurnResult())
        await db.commit()
    rows = [a for a in await fetch(PendingAction) if a.status != "done"]  # "done" = a adesão da fixture
    assert sorted(a.status for a in rows) == ["cancelled", "pending"]
    assert next(a for a in rows if a.status == "pending").tool == "change_or_subscribe_plan"


async def test_list_charges(paying):
    async with dbs() as db:
        inv = Invoice(number="TK-0001", user_id=paying.id, status="failed", total_cents=1234,
                      last_error="Cartão recusado")
        void = Invoice(number="TK-0002", user_id=paying.id, status="void", total_cents=99)
        db.add_all([inv, void])
        await db.flush()
        db.add(InvoiceLine(user_id=paying.id, invoice_id=inv.id, kind="renewal", description="TKFLIX set",
                           amount_cents=1234))
        await db.commit()
    rows = as_json((await run_tool(paying, "list_charges", agent="billing", limit=50))[0])
    mine = next(r for r in rows if r["number"] == "TK-0001")
    assert mine["status"] == "falhada (vamos tentar de novo)" and mine["total"] == "12,34 €"
    assert mine["lines"] == ["TKFLIX set: 12,34 €"] and mine["error"] == "Cartão recusado"
    assert "TK-0002" not in json.dumps(rows)  # anuladas não aparecem
    rows = as_json((await run_tool(paying, "list_charges", agent="billing", scope="streaming"))[0])
    assert all("lines" not in r for r in rows)
    bia = await create_user("bia")
    assert (await run_tool(bia, "list_charges", agent="billing"))[0] == "Ainda não há cobranças."


async def test_streaming_scope_restricts_billing_tools(make_client, svc):
    _, plans = await make_product("cloud", plans=[("cloud-m", 300, "month")])
    u, _, _ = await customer(make_client, svc, "ana")
    cloud_plan = await plan_by_code("cloud-m")
    await add_sub(u, "cloud-m", current_period_start=utcnow() - timedelta(days=2),
                  current_period_end=utcnow() + timedelta(days=28))
    await add_sub(u, current_period_start=utcnow() - timedelta(days=2),
                  current_period_end=utcnow() + timedelta(days=28))
    # Sem âmbito vê as duas; a partir do Jellyfin só o streaming.
    d = as_json((await run_tool(u, "get_billing_overview", agent="billing"))[0])
    assert {s["service"] for s in d["subscriptions"]} == {"Cloud", "TKFLIX Streaming"}
    d = as_json((await run_tool(u, "get_billing_overview", agent="billing", scope="streaming"))[0])
    assert [s["service"] for s in d["subscriptions"]] == ["TKFLIX Streaming"]
    cat = (await run_tool(u, "get_catalog", agent="billing", scope="streaming"))[0]
    assert "Cloud" not in cat
    out, action_id, _ = await propose(u, "change_or_subscribe_plan", scope="streaming", plan_id=cloud_plan.id)
    assert out.startswith("Erro: Aqui (a partir do Jellyfin)") and action_id is None
    cloud_sub = next(s for s in await fetch(Subscription) if s.plan_id == cloud_plan.id)
    out, action_id, _ = await propose(u, "cancel_subscription", scope="streaming", subscription_id=cloud_sub.id)
    assert out == "Erro: Subscrição não encontrada nesta conta." and action_id is None


async def test_portal_link_per_channel(svc):
    out, _ = await run_tool(None, "get_portal_link", agent="billing", purpose="payment_method")
    assert as_json(out) == {"link": "/app/faturacao#metodos"}
    out, _ = await run_tool(None, "get_portal_link", agent="billing", channel="whatsapp", purpose="store")
    assert as_json(out)["link"] == "https://portal.test/app/loja" and "sessão" in as_json(out)["note"]


async def test_billing_agent_has_no_streaming_tools():
    from app.assistant.agents import AGENTS

    billing = set(AGENTS["billing"].registry.names())
    support = set(AGENTS["support"].registry.names())
    assert billing & support == {"search_knowledge", "escalate_to_human"}
    assert not {n for n in billing if "subtitle" in n or "title" in n or "issue" in n or "playback" in n}
    assert not {"get_billing_overview", "list_charges", "cancel_subscription", "get_catalog"} & support
    confirm = {t.name for a in AGENTS.values() for t in a.registry._tools.values() if t.confirm}
    assert confirm == {"change_or_subscribe_plan", "cancel_subscription", "resume_subscription",
                       "quick_connect_authorize"}
