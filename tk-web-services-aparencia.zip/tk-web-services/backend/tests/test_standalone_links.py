"""Portal noutra máquina: service token do Cloudflare Access só para os hosts do TKFLIX, por https."""
from __future__ import annotations

import pytest

from app.config import get_settings
from app.integrations.upstream import headers_for


@pytest.fixture
def access(monkeypatch):
    s = get_settings()
    monkeypatch.setattr(s, "tkflix_access_client_id", "cid.access")
    monkeypatch.setattr(s, "tkflix_access_client_secret", "shh")
    monkeypatch.setattr(s, "tkflix_access_hosts", [])
    monkeypatch.setattr(s, "jellyfin_url", "https://tkflix.eu")
    monkeypatch.setattr(s, "bazarr_url", "https://bazarr-api.tkflix.eu")
    monkeypatch.setattr(s, "seerr_url", "http://DUMB:5055")
    monkeypatch.setattr(s, "dispatcharr_url", None)
    return s


def test_sent_to_configured_https_hosts(access):
    h = headers_for("https://bazarr-api.tkflix.eu")
    assert h == {"CF-Access-Client-Id": "cid.access", "CF-Access-Client-Secret": "shh"}
    assert headers_for("https://TKFLIX.eu/") != {}


def test_never_over_plain_http_or_to_other_hosts(access):
    assert headers_for("http://DUMB:5055") == {}
    assert headers_for("https://evil.example.com") == {}
    assert headers_for(None) == {}


def test_explicit_host_list_wins(access, monkeypatch):
    monkeypatch.setattr(access, "tkflix_access_hosts", ["bazarr-api.tkflix.eu"])
    assert headers_for("https://bazarr-api.tkflix.eu") != {}
    assert headers_for("https://tkflix.eu") == {}


def test_off_without_token(access, monkeypatch):
    monkeypatch.setattr(access, "tkflix_access_client_secret", None)
    assert headers_for("https://bazarr-api.tkflix.eu") == {}


async def test_clients_send_the_token(access, monkeypatch):
    import httpx

    from app.integrations.bazarr import BazarrClient
    from app.integrations.jellyfin import JellyfinClient

    seen: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        seen.append(request)
        return httpx.Response(200, json={"data": {"bazarr_version": "1"}, "Version": "12"})

    real = httpx.AsyncClient

    def fake(*a, **kw):
        kw["transport"] = httpx.MockTransport(handler)
        return real(*a, **kw)

    monkeypatch.setattr(httpx, "AsyncClient", fake)
    await BazarrClient(api_key="k").ping()
    await JellyfinClient(api_key="k").ping()
    assert all(r.headers.get("CF-Access-Client-Id") == "cid.access" for r in seen)
    assert seen[0].headers["X-API-KEY"] == "k"
    assert "Token=\"k\"" in seen[1].headers["Authorization"]


async def test_check_links_reports(monkeypatch, capsys):
    from app import cli
    from app.services import health

    async def fake():
        return [{"name": "jellyfin", "configured": True, "ok": True, "info": {"version": "12"}},
                {"name": "bazarr", "configured": True, "ok": False, "error": "timeout"},
                {"name": "stripe", "configured": False}]

    monkeypatch.setattr(health, "integrations", fake)

    class A:
        all = True

    with pytest.raises(SystemExit) as e:
        await cli.check_links(A())
    out = capsys.readouterr().out
    assert "OK  jellyfin (version=12)" in out and "!!  bazarr: timeout" in out and "stripe: não configurado" in out
    assert "1 ligação" in str(e.value)
