from __future__ import annotations

from datetime import timedelta
from urllib.parse import parse_qs, urlparse

import pyotp
import pytest
from conftest import (
    add_method,
    add_sub,
    create_user,
    dbs,
    dt,
    fetch,
    fetch_one,
    get,
    make_product,
    plan_by_code,
    update_row,
)
from test_provisioning import link_jf

from app.db import utcnow
from app.deps import host_allowed, safe_redirect
from app.models import EmailToken, Invoice, ServiceAccount, Subscription, SubStatus, User

EVIL = [
    "https://evil.com", "http://evil.com/app", "//evil.com", "//evil.com/x", "/\\evil.com", "\\\\evil.com",
    "/\t/evil.com", "/\n/evil.com", " //evil.com", "javascript:alert(1)", "JavaScript:alert(1)",
    "data:text/html,<script>alert(1)</script>", "https://portal.test@evil.com/", "https://evil.com#portal.test",
    "https://notportal.test/", "https://portal.test.evil.com/", "ftp://portal.test/", "https:evil.com",
]


@pytest.mark.parametrize("url", EVIL)
def test_safe_redirect_rejects(url):
    assert safe_redirect(url) == "/app"


@pytest.mark.parametrize("url", [
    "/app/conta", "/app?x=1#y", "https://portal.test/oidc/authorize?client_id=a", "https://sonarr.test/calendar",
    "https://radarr.portal.test/", "http://sonarr.test/",  # http só aceite em dev/test
])
def test_safe_redirect_accepts(url):
    assert safe_redirect(url) == url


def test_http_redirect_rejected_in_production(settings):
    settings.set("env", "production")
    assert safe_redirect("http://sonarr.test/") == "/app"
    assert safe_redirect("https://sonarr.test/") == "https://sonarr.test/"


def test_host_allowed_wildcards():
    assert host_allowed("portal.test") and host_allowed("PORTAL.TEST")
    assert host_allowed("a.b.portal.test") and host_allowed("sonarr.test")
    assert not host_allowed("evilportal.test") and not host_allowed("sonarr.test.evil") and not host_allowed(None)


@pytest.mark.parametrize("nxt", ["https://evil.com", "//evil.com", "/\\evil.com", "javascript:alert(1)"])
async def test_login_next_open_redirect(make_client, nxt):
    await create_user("maria")
    r = await make_client().login("maria", next=nxt)
    assert r.status_code == 200 and r.json()["redirect"] == "/app"


async def test_login_next_allowed_host(client):
    await create_user("maria")
    r = await client.login("maria", next="https://sonarr.test/queue")
    assert r.json()["redirect"] == "https://sonarr.test/queue"


# --------------------------------------------------------------------------- ponte Jellyfin → portal
JF_ORIGIN = "https://tv.test"
USER_TOKEN = "jf-user-access-token-0001"


async def exchange(client, token=USER_TOKEN, origin=JF_ORIGIN, **body):
    headers = {"Origin": origin} if origin else {}
    return await client.post("/api/integrations/jellyfin/exchange", json={"token": token, **body}, headers=headers)


async def action(client, act, token=USER_TOKEN, origin=JF_ORIGIN, **body):
    headers = {"Origin": origin} if origin else {}
    return await client.post("/api/integrations/jellyfin/action", json={"token": token, "action": act, **body},
                             headers=headers)


async def linked(svc, name="maria", **kw):
    u = await create_user(name, **kw)
    jf_user = await link_jf(svc, u)
    svc.jf.user_tokens[USER_TOKEN] = jf_user["Id"]
    return u


def magic_token(url: str) -> str:
    assert url.startswith("https://portal.test/entrar-jellyfin?token=")
    return parse_qs(urlparse(url).query)["token"][0]


async def test_exchange_returns_streaming_status_only(make_client, svc):
    u = await linked(svc, display_name="Maria")
    await add_sub(u, "tkflix-tv-mensal", current_period_end=utcnow() + timedelta(days=10))
    _, plans = await make_product("cloud")
    await add_sub(u, "cloud-m")  # outro produto do portal: nunca aparece no Jellyfin
    await add_method(svc, u, "gocardless")
    bridge = make_client(csrf=False)  # a página no Jellyfin não envia o header CSRF
    r = await exchange(bridge)
    assert r.status_code == 200, r.text
    assert r.headers["access-control-allow-origin"] == JF_ORIGIN
    assert r.headers["vary"] == "Origin"
    body = r.json()
    assert body["linked"] is True and body["username"] == "maria" and body["display_name"] == "Maria"
    [sub] = body["subscriptions"]
    assert sub["plan"] == "TKFLIX + TV" and sub["status"] == "active" and sub["status_label"] == "Ativa"
    assert sub["can_change"] and sub["can_cancel"] and not sub["can_resume"] and sub["price"] == "7,50 €"
    assert {p["name"] for p in body["plans"]} == {"TKFLIX", "TKFLIX Anual", "TKFLIX + TV", "TKFLIX + TV Anual"}
    assert body["payment_method"] == "Débito direto · CGD ••••11" and body["has_unpaid"] is False
    assert body["can_add_method"] is True and body["portal_url"] == "https://portal.test"
    assert "cloud" not in str(body).lower()
    # o token usado para validar foi o do utilizador, com o header MediaBrowser
    [req] = svc.jf.find("GET", "/Users/Me")
    assert req.headers["authorization"].endswith(f'Token="{USER_TOKEN}"')


async def test_open_portal_magic_link_gives_streaming_scoped_session(make_client, svc):
    u = await linked(svc)
    await add_sub(u)
    r = await action(make_client(csrf=False), "open_portal")
    assert r.status_code == 200 and r.headers["access-control-allow-origin"] == JF_ORIGIN
    token = magic_token(r.json()["url"])
    browser = make_client()
    r = await browser.post("/api/auth/magic", json={"token": token})
    assert r.status_code == 200 and r.json()["status"] == "ok" and r.json()["redirect"] == "/app/streaming"
    me = (await browser.get("/api/auth/me")).json()
    assert me["username"] == "maria" and me["session_scope"] == "streaming"
    # sessão limitada: o resto do portal pede login com password
    r = await browser.get("/api/billing/invoices")
    assert r.status_code == 403 and r.headers["x-tk-session-scope"] == "streaming"
    r = await make_client().post("/api/auth/magic", json={"token": token})
    assert r.status_code == 400  # uso único


async def test_exchange_preflight_and_cors(make_client, svc):
    c = make_client(csrf=False)
    r = await c.options("/api/integrations/jellyfin/exchange", headers={
        "Origin": JF_ORIGIN, "Access-Control-Request-Method": "POST"})
    assert r.status_code == 204 and r.headers["access-control-allow-origin"] == JF_ORIGIN
    assert "POST" in r.headers["access-control-allow-methods"]
    r = await c.options("/api/integrations/jellyfin/exchange", headers={"Origin": "https://evil.com"})
    assert "access-control-allow-origin" not in r.headers
    # Origem estrangeira → 403 sem CORS (nem sequer chama o Jellyfin)
    r = await exchange(c, origin="https://evil.com")
    assert r.status_code == 403 and "access-control-allow-origin" not in r.headers
    assert svc.jf.find("GET", "/Users/Me") == []
    # sem Origin (chamada servidor-a-servidor) funciona, mas sem headers CORS
    r = await exchange(c, origin=None)
    assert r.status_code == 401 and "access-control-allow-origin" not in r.headers


async def test_exchange_invalid_or_unlinked_token(make_client, svc):
    c = make_client(csrf=False)
    r = await exchange(c, token="token-invalido-0000000")
    assert r.status_code == 401 and r.headers["access-control-allow-origin"] == JF_ORIGIN
    stranger = svc.jf.add_user("estranho")
    svc.jf.user_tokens["token-do-estranho-000"] = stranger["Id"]
    r = await exchange(c, token="token-do-estranho-000")
    assert r.status_code == 200
    assert r.json() == {"linked": False, "username": "estranho", "register_url": "https://portal.test/registar"}


async def test_open_portal_next_is_sanitised(make_client, svc):
    await linked(svc)
    c = make_client(csrf=False)
    for nxt, expected in (("/app/streaming?plano=3", "/app/streaming?plano=3"), ("/app/conta", "/app/streaming"),
                          ("//evil.com", "/app/streaming"), ("https://evil.com", "/app/streaming"),
                          ("/app/streaming//evil.com", "/app/streaming")):
        url = (await action(c, "open_portal", next=nxt)).json()["url"]
        r = await make_client().post("/api/auth/magic", json={"token": magic_token(url)})
        assert r.json()["redirect"] == expected, nxt


async def test_magic_login_refused_for_admin(make_client, svc):
    await linked(svc, "chefe", admin=True)
    r = await action(make_client(csrf=False), "open_portal")
    assert r.json()["url"] == "https://portal.test/login?next=/app/streaming"  # sem link mágico
    from app.services import tokens

    u = await fetch(User)
    async with dbs() as db:
        raw = await tokens.issue(db, u[0].id, "magic_login", {"next": "/app/streaming"})
        await db.commit()
    browser = make_client()
    r = await browser.post("/api/auth/magic", json={"token": raw})
    assert r.status_code == 403
    assert (await browser.get("/api/auth/me")).status_code == 401


async def test_magic_login_with_2fa_requires_code(make_client, svc):
    secret = pyotp.random_base32()
    from app.security import encrypt

    await linked(svc, "segura", totp_enabled=True, totp_secret_enc=encrypt(secret))
    url = (await action(make_client(csrf=False), "open_portal")).json()["url"]
    browser = make_client()
    r = await browser.post("/api/auth/magic", json={"token": magic_token(url)})
    assert r.status_code == 200 and r.json()["status"] == "mfa_required"
    assert (await browser.get("/api/auth/me")).status_code == 401
    r = await browser.post("/api/auth/2fa", json={"code": pyotp.TOTP(secret).now()})
    assert r.status_code == 200 and r.json()["redirect"] == "/app/streaming"
    me = (await browser.get("/api/auth/me")).json()
    assert me["username"] == "segura" and me["session_scope"] == "streaming"


async def test_magic_token_expires(make_client, svc):
    from app.db import utcnow as real_utcnow

    await linked(svc)
    url = (await action(make_client(csrf=False), "open_portal")).json()["url"]
    async with dbs() as db:
        from sqlalchemy import update

        await db.execute(update(EmailToken).values(expires_at=real_utcnow() - timedelta(seconds=1)))
        await db.commit()
    r = await make_client().post("/api/auth/magic", json={"token": magic_token(url)})
    assert r.status_code == 400


# --------------------------------------------------------------------------- ações na página do Jellyfin
async def test_bridge_quote_change_cancel_resume(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u = await linked(svc)
    await add_method(svc, u, "stripe")
    c = make_client(csrf=False)
    mensal, tv = await plan_by_code("tkflix-mensal"), await plan_by_code("tkflix-tv-mensal")
    q = (await action(c, "quote", plan_id=mensal.id)).json()
    assert q["kind"] == "new" and q["due_now_cents"] == 500 and q["needs_payment_method"] is False
    r = await action(c, "subscribe", plan_id=mensal.id)
    assert r.status_code == 200 and r.json()["ok"] is True, r.text
    sub = await fetch_one(Subscription)
    assert sub.status == SubStatus.active and (await fetch_one(Invoice)).status == "paid"
    r = await action(c, "subscribe", plan_id=mensal.id)
    assert r.status_code == 400 and "Mudar de plano" in r.json()["detail"]

    clock.set(dt(2026, 10, 20, 12))
    q = (await action(c, "quote", plan_id=tv.id, subscription_id=sub.id)).json()
    assert q["kind"] == "change" and q["is_upgrade"] is True and q["next_invoice_cents"] > 0
    r = await action(c, "change", plan_id=tv.id, subscription_id=sub.id)
    assert r.status_code == 200 and "entra na próxima cobrança" in r.json()["message"]
    assert (await get(Subscription, sub.id)).plan_id == tv.id

    r = await action(c, "cancel", subscription_id=sub.id)
    assert r.status_code == 200 and "05/11/2026" in r.json()["message"]
    assert (await get(Subscription, sub.id)).status == SubStatus.canceling
    body = (await exchange(c)).json()
    assert body["subscriptions"][0]["can_resume"] is True
    assert body["subscriptions"][0]["access_until"] == "05/11/2026"
    r = await action(c, "resume", subscription_id=sub.id)
    assert r.status_code == 200
    assert (await get(Subscription, sub.id)).status == SubStatus.active
    r = await action(c, "resume", subscription_id=sub.id)
    assert r.status_code == 400


async def test_bridge_subscribe_without_method_returns_magic_link(make_client, svc):
    await linked(svc)
    c = make_client(csrf=False)
    plan = await plan_by_code("tkflix-mensal")
    assert (await action(c, "quote", plan_id=plan.id)).json()["needs_payment_method"] is True
    r = await action(c, "subscribe", plan_id=plan.id)
    body = r.json()
    assert r.status_code == 200 and body["ok"] is False and body["needs_payment_method"] is True
    browser = make_client()
    r = await browser.post("/api/auth/magic", json={"token": magic_token(body["url"])})
    assert r.json()["redirect"] == f"/app/streaming?plano={plan.id}"
    assert await fetch(Subscription) == []


async def test_bridge_cannot_touch_other_products(make_client, svc):
    u = await linked(svc)
    await add_method(svc, u, "stripe")
    _, plans = await make_product("cloud")
    cloud = await add_sub(u, "cloud-m")
    other_user = await create_user("joao")
    foreign = await add_sub(other_user)
    c = make_client(csrf=False)
    r = await action(c, "subscribe", plan_id=plans["cloud-m"].id)
    assert r.status_code == 404
    r = await action(c, "quote", plan_id=plans["cloud-m"].id)
    assert r.status_code == 404
    for act in ("cancel", "resume"):
        assert (await action(c, act, subscription_id=cloud.id)).status_code == 404
        assert (await action(c, act, subscription_id=foreign.id)).status_code == 404
    r = await action(c, "change", plan_id=(await plan_by_code("tkflix-anual")).id, subscription_id=cloud.id)
    assert r.status_code == 404
    assert (await get(Subscription, cloud.id)).status == SubStatus.active
    assert (await get(Subscription, foreign.id)).status == SubStatus.active
    r = await action(c, "hack")
    assert r.status_code == 422


async def test_bridge_action_requires_linked_account_and_valid_token(make_client, svc):
    c = make_client(csrf=False)
    r = await action(c, "open_portal", token="token-invalido-0000000")
    assert r.status_code == 401
    stranger = svc.jf.add_user("estranho")
    svc.jf.user_tokens["token-do-estranho-000"] = stranger["Id"]
    r = await action(c, "open_portal", token="token-do-estranho-000")
    assert r.status_code == 404
    r = await action(c, "open_portal", origin="https://evil.com")
    assert r.status_code == 403
    assert await fetch(EmailToken) == []


async def test_bridge_unexpected_error_returns_502(make_client, svc, clock, monkeypatch):
    clock.set(dt(2026, 10, 5, 12))
    u = await linked(svc)
    await add_method(svc, u, "stripe")
    await add_sub(u, current_period_start=dt(2026, 10, 5, 6), current_period_end=dt(2026, 11, 5, 6),
                  period_amount_cents=500)
    await update_row(User, u.id, billing_anchor_day=5, next_billing_at=dt(2026, 11, 5, 6))
    sub = await fetch_one(Subscription)
    c = make_client(csrf=False)
    from app.services import billing

    async def boom(*a, **kw):
        raise RuntimeError("fornecedor em baixo")

    monkeypatch.setattr(billing, "change_plan", boom)
    r = await action(c, "change", plan_id=(await plan_by_code("tkflix-tv-mensal")).id, subscription_id=sub.id)
    assert r.status_code == 502 and r.headers["access-control-allow-origin"] == JF_ORIGIN
    assert (await get(Subscription, sub.id)).plan_id == (await plan_by_code("tkflix-mensal")).id


async def test_exchange_blocked_user(make_client, svc):
    u = await create_user("maria", is_active=False)
    jf_user = await link_jf(svc, u)
    svc.jf.user_tokens[USER_TOKEN] = jf_user["Id"]
    r = await exchange(make_client(csrf=False))
    assert r.status_code == 403
    assert await fetch(EmailToken) == []


async def test_exchange_matches_dashed_jellyfin_ids(make_client, svc):
    u = await create_user("maria")
    jf_user = await link_jf(svc, u)
    raw = jf_user["Id"]
    dashed = "-".join([raw[:8], raw[8:12], raw[12:16], raw[16:20], raw[20:]])
    svc.jf.users[raw]["Id"] = dashed  # algumas versões devolvem o GUID com hífens
    svc.jf.user_tokens[USER_TOKEN] = raw
    r = await exchange(make_client(csrf=False))
    assert r.json()["linked"] is True
    assert (await fetch(ServiceAccount))[0].external_id == raw
