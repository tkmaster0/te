"""Clientes antigos (modo "manter" + conversão automática), configuração por web, migração pela web, TV e Jellyfin."""
from __future__ import annotations

import sqlite3
import uuid

from conftest import (
    _TMP,
    create_user,
    dbs,
    drain,
    dt,
    fetch,
    fetch_one,
    gc_event,
    get,
    plan_by_code,
    post_gc_webhook,
)

from app.config import get_settings
from app.models import ConfigEntry, Invoice, Plan, Product, ServiceAccount, Subscription, SubStatus, User
from app.security import XC_PASSWORD_RE, decrypt, friendly_password
from app.services import legacy, runtime_config


async def _legacy(svc, name: str, *, amount: int = 500, next_charge: str = "2026-10-20", plan_name: str = "TKFLIX"):
    cust = svc.gc.add_customer(f"{name}@example.com")
    md = svc.gc.add_mandate(cust["id"])
    u = await create_user(name, gocardless_customer_id=cust["id"], gocardless_mandate_id=md["id"])
    gs = svc.gc.add_subscription(md["id"], amount=amount, name=plan_name, next_charge=next_charge)
    svc.gc.add_payment(gs["id"], "paid_out", "2026-09-20")
    async with dbs() as db:
        res = await legacy.migrate_all(db)
    mine = [r["result"] for r in res if r.get("gc_subscription") == gs["id"]]
    assert mine == ["ligada (continua na GoCardless)"]
    return u, gs


async def _other_product() -> Plan:
    async with dbs() as db:
        p = Product(code="cloud", name="TK Cloud", kind="cloud", fulfillment="none", icon="cloud")
        db.add(p)
        await db.flush()
        plan = Plan(product_id=p.id, code="cloud-mensal", name="TK Cloud", price_cents=300, interval_unit="month")
        db.add(plan)
        await db.commit()
        return plan


# --------------------------------------------------------------------------- modo "manter"
async def test_kept_subscription_gives_access_and_is_not_billed_by_portal(svc, clock):
    from app.services import billing
    from app.services.subscriptions import compute_access

    clock.set(dt(2026, 10, 5, 12))
    u, gs = await _legacy(svc, "antigo")
    sub = await fetch_one(Subscription, user_id=u.id)
    assert sub.provider == "gocardless" and sub.status == SubStatus.active and sub.meta["legacy"] is True
    assert sub.current_period_end.date().isoformat() == "2026-10-20"
    async with dbs() as db:
        user = await db.get(User, u.id)
        assert (await compute_access(db, user)).any_active
        clock.set(dt(2026, 10, 20, 7))
        assert await billing.run_cycle(db, user) is None  # quem cobra é a GoCardless
    assert gs["status"] == "active" and svc.gc.charges() == []


async def test_new_service_converts_legacy_without_customer_action(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, gs = await _legacy(svc, "antigo")
    cloud = await _other_product()
    c = make_client()
    await c.login_as(u)
    # pré-visualização: pro-rata até à próxima cobrança da GoCardless (dia 20), sem converter nada ainda
    q = (await c.get("/api/billing/quote", params={"plan_id": cloud.id})).json()
    assert q["period_end"].startswith("2026-10-20") and 0 < q["lines"][0]["amount_cents"] < 300
    assert gs["status"] == "active"

    r = await c.post("/api/billing/subscribe", json={"plan_id": cloud.id})
    assert r.status_code == 200, r.text
    old = await fetch_one(Subscription, provider_subscription_id=gs["id"])
    assert old.provider == "portal" and old.meta["converted_by"] == "adesão a outro serviço"
    assert gs["status"] == "cancelled"  # a GoCardless deixou de cobrar sozinha; o mandato é reaproveitado
    user = await get(User, u.id)
    assert user.billing_anchor_day == 20 and user.next_billing_at == dt(2026, 10, 20, 6)
    new = await fetch_one(Subscription, plan_id=cloud.id)
    assert new.current_period_end == dt(2026, 10, 20, 6) and new.status == SubStatus.active


async def test_plan_change_and_cancel_convert_legacy(make_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, gs = await _legacy(svc, "antigo")
    sub = await fetch_one(Subscription, user_id=u.id)
    c = make_client()
    await c.login_as(u)
    tv = await plan_by_code("tkflix-tv-mensal")
    r = await c.post(f"/api/billing/subscriptions/{sub.id}/change", json={"plan_id": tv.id})
    assert r.status_code == 200, r.text
    sub = await get(Subscription, sub.id)
    assert sub.provider == "portal" and sub.plan_id == tv.id and gs["status"] == "cancelled"

    v, gs2 = await _legacy(svc, "outro")
    sub2 = await fetch_one(Subscription, user_id=v.id)
    c2 = make_client()
    await c2.login_as(v)
    r = await c2.post(f"/api/billing/subscriptions/{sub2.id}/cancel")
    assert r.status_code == 200, r.text
    sub2 = await get(Subscription, sub2.id)
    assert sub2.provider == "portal" and sub2.status == SubStatus.canceling and gs2["status"] == "cancelled"
    assert sub2.access_until == sub2.current_period_end


async def test_legacy_webhooks_payment_failure_success_and_cancel(client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    u, gs = await _legacy(svc, "antigo")
    p = svc.gc.add_payment(gs["id"], "failed", "2026-10-20")
    await post_gc_webhook(client, [gc_event("payments", "failed", payment=p["id"], subscription=gs["id"])])
    await drain()
    sub = await fetch_one(Subscription, user_id=u.id)
    assert sub.status == SubStatus.past_due and sub.grace_until is not None

    p2 = svc.gc.add_payment(gs["id"], "confirmed", "2026-10-23")
    await post_gc_webhook(client, [gc_event("payments", "confirmed", payment=p2["id"], subscription=gs["id"])])
    await drain()
    assert (await get(Subscription, sub.id)).status == SubStatus.active

    gs["status"] = "cancelled"
    await post_gc_webhook(client, [gc_event("subscriptions", "cancelled", subscription=gs["id"])])
    await drain()
    sub = await get(Subscription, sub.id)
    assert sub.status == SubStatus.canceling and sub.access_until is not None


async def test_admin_converts_all_and_status(admin_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    await _legacy(svc, "a1")
    await _legacy(svc, "a2")
    st = (await admin_client.get("/api/admin/migration/status")).json()
    assert len(st["legacy"]) == 2 and st["gocardless_configured"]
    r = await admin_client.post("/api/admin/migration/convert", json={"all": True})
    assert r.json()["converted"] == 2
    assert all(s["status"] == "cancelled" for s in svc.gc.subscriptions.values())
    assert (await admin_client.get("/api/admin/migration/status")).json()["legacy"] == []


async def test_direct_gocardless_import_creates_accounts(admin_client, svc, clock):
    clock.set(dt(2026, 10, 5, 12))
    cust = svc.gc.add_customer("novo.cliente@example.com")
    md = svc.gc.add_mandate(cust["id"])
    gs = svc.gc.add_subscription(md["id"], amount=500, name="TKFLIX")
    r = await admin_client.post("/api/admin/migration/gocardless", json={"dry_run": True})
    assert r.json()["count"] == 1 and await fetch(Subscription) == []
    r = await admin_client.post("/api/admin/migration/gocardless", json={"dry_run": False})
    assert r.json()["count"] == 1
    u = await fetch_one(User, email="novo.cliente@example.com")
    assert u.email_verified_at and u.billing_mode == "legacy" and u.username.startswith("novo.cliente")
    sub = await fetch_one(Subscription, user_id=u.id)
    assert sub.provider == "gocardless" and gs["status"] == "active"


async def test_upload_old_site_database(admin_client, svc):
    path = _TMP / f"old-{uuid.uuid4().hex}.db"
    con = sqlite3.connect(path)
    con.execute("CREATE TABLE user (id INTEGER PRIMARY KEY, email TEXT, username TEXT, password TEXT, "
                "subscription_status TEXT, jellyfin_user_id TEXT, iptvusername TEXT, iptvpwd TEXT, iptvhost TEXT)")
    con.execute("INSERT INTO user VALUES (1, 'ana@example.com', 'Ana', '!', 'Ativa', NULL, 'ana_tv', 'velha123', "
                "'http://tv.antigo')")
    con.commit()
    con.close()
    data = path.read_bytes()
    r = await admin_client.post("/api/admin/migration/legacy-db", files={"file": ("users.db", data)},
                                data={"dry_run": "true"})
    assert r.status_code == 200, r.text
    assert r.json()["new"] == 1 and await fetch(User, email="ana@example.com") == []
    r = await admin_client.post("/api/admin/migration/legacy-db", files={"file": ("users.db", data)},
                                data={"dry_run": "false"})
    assert r.json()["new"] == 1 and r.json()["iptv"] == 1
    u = await fetch_one(User, email="ana@example.com")
    assert u.legacy_id == 1 and u.email_verified_at is not None
    bad = await admin_client.post("/api/admin/migration/legacy-db", files={"file": ("x.db", b"not sqlite")})
    assert bad.status_code == 400


# --------------------------------------------------------------------------- configuração por web
async def test_config_saved_masked_applied_and_reset(admin_client):
    s = get_settings()
    before = s.smtp_host
    r = await admin_client.put("/api/admin/config", json={"values": {
        "smtp_host": "smtp.exemplo.pt", "smtp_port": "587", "smtp_tls_mode": "starttls",
        "smtp_password": "segredo-muito-grande", "public_url": "https://tkws.exemplo.pt/"}})
    assert r.status_code == 200, r.text
    try:
        assert s.smtp_host == "smtp.exemplo.pt" and s.smtp_port == 587 and s.smtp_password == "segredo-muito-grande"
        assert s.public_url == "https://tkws.exemplo.pt"
        row = await fetch_one(ConfigEntry, key="smtp_password")
        assert row.secret and row.value != "segredo-muito-grande"
        assert decrypt(row.value) == "segredo-muito-grande"
        cfg = (await admin_client.get("/api/admin/config")).json()
        email = next(sec for sec in cfg["sections"] if sec["id"] == "email")
        pwd = next(f for f in email["fields"] if f["name"] == "smtp_password")
        assert pwd["value"] is None and pwd["is_set"] and pwd["masked"] == "••••ande"
        # segredo vazio = manter
        await admin_client.put("/api/admin/config", json={"values": {"smtp_password": ""}})
        assert s.smtp_password == "segredo-muito-grande"
        bad = await admin_client.put("/api/admin/config", json={"values": {"public_url": "ftp://x"}})
        assert bad.status_code == 400
        bad = await admin_client.put("/api/admin/config", json={"values": {"secret_key": "x" * 40}})
        assert bad.status_code == 400
    finally:
        r = await admin_client.put("/api/admin/config", json={"values": {
            k: {"reset": True} for k in ("smtp_host", "smtp_port", "smtp_tls_mode", "smtp_password", "public_url")}})
    assert s.smtp_host == before and s.public_url == "https://portal.test"


async def test_config_requires_admin(make_client):
    u = await create_user("maria")
    c = make_client()
    await c.login_as(u)
    assert (await c.get("/api/admin/config")).status_code == 403
    assert (await c.put("/api/admin/config", json={"values": {"app_name": "x"}})).status_code == 403


async def test_setup_wizard_status_and_complete(admin_client):
    st = (await admin_client.get("/api/admin/setup")).json()
    assert st["completed"] is False
    ids = {i["id"] for i in st["checklist"]}
    assert {"conta", "geral", "tunel", "email", "pagamentos", "jellyfin", "servicos", "migracao"} <= ids
    r = await admin_client.post("/api/admin/setup/complete")
    assert r.status_code == 200
    assert (await admin_client.get("/api/admin/setup")).json()["completed"] is True
    tun = (await admin_client.get("/api/admin/tunnel")).json()
    assert tun["configured"] is False and tun["running"] is False


async def test_config_loaded_from_db_on_start():
    s = get_settings()
    async with dbs() as db:
        await runtime_config.save(db, {"app_name": "Portal Novo"})
        await db.commit()
        try:
            await runtime_config.load(db)
            assert s.app_name == "Portal Novo"
        finally:
            await runtime_config.save(db, {"app_name": {"reset": True}})
            await db.commit()
            await runtime_config.load(db)
    assert s.app_name == "TK Web Services"


async def test_cookie_not_secure_over_plain_http():
    """Primeiro acesso por http://IP:8090: o cookie vai sem Secure (senão o browser não o guardava)."""
    await create_user("maria")
    import httpx
    from conftest import CSRF, PASSWORD

    from app.main import app

    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app, client=("192.168.1.20", 5000)),
                                 base_url="http://192.168.1.10:8090", headers=CSRF) as c:
        r = await c.post("/api/auth/login", json={"login": "maria", "password": PASSWORD})
        assert r.status_code == 200
    cookie = r.headers["set-cookie"].lower()
    assert "secure" not in cookie and "domain=" not in cookie


# --------------------------------------------------------------------------- TV (Dispatcharr)
async def test_iptv_friendly_password_visible_and_changeable(make_client, svc):
    from app.services.provisioning import reconcile_user

    assert XC_PASSWORD_RE.match(friendly_password())
    u = await create_user("maria")
    tv = await plan_by_code("tkflix-tv-mensal")
    async with dbs() as db:
        db.add(Subscription(user_id=u.id, plan_id=tv.id, product_id=tv.product_id, status=SubStatus.active,
                            provider="manual"))
        await db.commit()
        await reconcile_user(db, u.id)
        await db.commit()
    c = make_client()
    await c.login_as(u)
    iptv = (await c.get("/api/services")).json()["iptv"]
    assert iptv["source"] == "dispatcharr" and iptv["password"].count("-") == 2
    remote = svc.dc.by_name("maria")
    assert remote["custom_properties"]["xc_password"] == iptv["password"]

    r = await c.post("/api/services/iptv/password", json={"password": "minha.tv-2026"})
    assert r.status_code == 200 and r.json()["password"] == "minha.tv-2026"
    assert svc.dc.by_name("maria")["custom_properties"]["xc_password"] == "minha.tv-2026"
    assert (await c.get("/api/services")).json()["iptv"]["password"] == "minha.tv-2026"
    r = await c.post("/api/services/iptv/password", json={})
    assert r.status_code == 200 and r.json()["password"] != "minha.tv-2026"
    bad = await c.post("/api/services/iptv/password", json={"password": "a b"})
    assert bad.status_code == 400


async def test_iptv_reuses_old_site_credentials_and_is_deleted_after_days(svc, settings):
    from datetime import timedelta

    from app.db import utcnow
    from app.security import encrypt
    from app.services.provisioning import reconcile_user

    u = await create_user("ana")
    tv = await plan_by_code("tkflix-tv-mensal")
    async with dbs() as db:
        db.add(ServiceAccount(user_id=u.id, service="iptv", external_username="ana_tv",
                              secret_enc=encrypt("velha123"), data={"host": "http://tv.antigo"}))
        sub = Subscription(user_id=u.id, plan_id=tv.id, product_id=tv.product_id, status=SubStatus.active,
                           provider="manual")
        db.add(sub)
        await db.commit()
        await reconcile_user(db, u.id)
        await db.commit()
    remote = svc.dc.by_name("ana_tv")
    assert remote and remote["custom_properties"]["xc_password"] == "velha123"  # os aparelhos continuam a entrar

    async with dbs() as db:
        s = await db.get(Subscription, sub.id)
        s.status = SubStatus.ended
        await db.commit()
        await reconcile_user(db, u.id)
        await db.commit()
    sa = await fetch_one(ServiceAccount, user_id=u.id, service="dispatcharr")
    assert sa.data["disabled_at"] and "xc_password" not in svc.dc.by_name("ana_tv")["custom_properties"]
    settings.set("dispatcharr_delete_after_days", 30)
    async with dbs() as db:
        row = await db.get(ServiceAccount, sa.id)
        row.data = {**row.data, "disabled_at": (utcnow() - timedelta(days=31)).isoformat()}
        await db.commit()
        assert (await reconcile_user(db, u.id))["dispatcharr"] == "deleted"
        await db.commit()
    assert svc.dc.by_name("ana_tv") is None
    assert await fetch(ServiceAccount, user_id=u.id, service="dispatcharr") == []


# --------------------------------------------------------------------------- Jellyfin
async def test_jellyfin_files_served_with_portal_url(client, admin_client):
    js = await client.get("/jellyfin/widget.js")
    assert js.status_code == 200 and "javascript" in js.headers["content-type"]
    assert 'var PORTAL_URL = "https://portal.test"' in js.text and "__PORTAL_URL__" not in js.text
    page = await client.get("/jellyfin/conta.html")
    assert 'var PORTAL_URL = "https://portal.test"' in page.text
    sn = (await admin_client.get("/api/admin/jellyfin/snippets")).json()
    assert "https://portal.test/jellyfin/widget.js" in sn["js_loader"]
    assert sn["links"]["plugins"] == "https://tv.test/web/#/dashboard/plugins"
    assert any("JPKribs" in r["url"] for r in sn["repositories"])


async def test_invoice_none_for_kept_legacy_on_cycle(svc, clock):
    """Sem conversão, nenhuma cobrança do portal para a subscrição antiga."""
    clock.set(dt(2026, 10, 5, 12))
    await _legacy(svc, "antigo")
    assert await fetch(Invoice) == []


# --------------------------------------------------------------------------- arranque do zero
async def test_owner_email_registers_as_admin_without_otp(make_client, settings):
    settings.set("registration_mode", "invite")  # nem o convite é preciso para o email do dono
    c = make_client()
    r = await c.post("/api/auth/register", json={"email": "Geral@TKmasterProductions.eu", "username": "geral",
                                                  "password": "Uma-Password-Longa-9"})
    assert r.status_code == 200, r.text
    assert r.json()["redirect"] == "/admin/configurar"
    u = await fetch_one(User, username="geral")
    assert u.is_admin and u.email_verified_at is not None and "tkflix" in (u.unlocked_products or [])
    from app.models import EmailToken

    assert await fetch(EmailToken, user_id=u.id) == []  # nenhum código OTP
    me = (await c.get("/api/auth/me")).json()
    assert me["is_admin"] and me["email_verified"]
    assert (await c.get("/api/admin/setup")).status_code == 200


async def test_other_emails_still_need_invite_and_otp(make_client, settings):
    settings.set("registration_mode", "invite")
    c = make_client()
    r = await c.post("/api/auth/register", json={"email": "x@example.com", "username": "xpto",
                                                  "password": "Uma-Password-Longa-9"})
    assert r.status_code == 400


async def test_admin_email_shortcut_only_while_there_is_no_admin(make_client, admin, settings):
    """Com um admin já criado, outro email da lista não salta o OTP: só fica admin depois de confirmar o email."""
    settings.set("registration_mode", "open")
    settings.set("admin_emails", ["geral@tkmasterproductions.eu", "socio@tkmasterproductions.eu"])
    c = make_client()
    r = await c.post("/api/auth/register", json={"email": "socio@tkmasterproductions.eu", "username": "socio",
                                                  "password": "Uma-Password-Longa-9"})
    assert r.status_code == 200 and r.json()["redirect"] == "/app"
    u = await fetch_one(User, username="socio")
    assert not u.is_admin and u.email_verified_at is None
    from app.services import tokens

    async with dbs() as db:
        code = await tokens.issue_code(db, u.id)
        await db.commit()
    assert (await c.post("/api/auth/verify-code", json={"code": code})).status_code == 200
    assert (await fetch_one(User, username="socio")).is_admin


async def test_more_settings_are_editable_on_the_web(admin_client):
    r = await admin_client.put("/api/admin/config", json={"values": {
        "session_idle_hours": 12, "assistant_temperature": "0,5", "admin_emails": "a@x.pt, b@x.pt",
        "langfuse_public_key": "pk-lf-1", "log_level": "DEBUG"}})
    assert r.status_code == 200, r.text
    s = get_settings()
    assert s.session_idle_hours == 12 and s.assistant_temperature == 0.5 and s.admin_emails == ["a@x.pt", "b@x.pt"]
    import logging
    import os

    assert os.environ["LANGFUSE_PUBLIC_KEY"] == "pk-lf-1" and logging.getLogger().level == logging.DEBUG
    bad = await admin_client.put("/api/admin/config", json={"values": {"assistant_temperature": "5"}})
    assert bad.status_code == 400
    # repor (as definições são globais ao processo de testes)
    await admin_client.put("/api/admin/config", json={"values": {
        k: {"reset": True} for k in ("session_idle_hours", "assistant_temperature", "admin_emails",
                                     "langfuse_public_key", "log_level")}})
    assert "LANGFUSE_PUBLIC_KEY" not in os.environ and s.session_idle_hours == 72
    logging.getLogger().setLevel(logging.WARNING)
