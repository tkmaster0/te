from __future__ import annotations

import argparse
import sqlite3
import uuid
from datetime import datetime, timedelta, timezone

import pytest
from conftest import _TMP, dbs, drain, fetch, fetch_one, get, plan_by_code
from test_auth import werkzeug_pbkdf2

from app import cli
from app.models import Grant, ServiceAccount, Subscription, SubStatus, User
from app.security import decrypt
from fakes import DEFAULT_POLICY

OLD_SCHEMA = """
CREATE TABLE user (
    id INTEGER PRIMARY KEY,
    email VARCHAR(120),
    username VARCHAR(80),
    password VARCHAR(200),
    clear_text_password VARCHAR(200),
    invited_by VARCHAR(80),
    gocardless_customer_id VARCHAR(50),
    gocardless_mandate_id VARCHAR(50),
    subscription_status VARCHAR(20),
    jellyfin_user_id VARCHAR(64),
    subscription_end_date DATETIME,
    reset_code VARCHAR(20),
    iptvpwd VARCHAR(100),
    iptvusername VARCHAR(100),
    iptvhost VARCHAR(200)
)
"""


def jf_guid() -> tuple[str, str]:
    raw = uuid.uuid4().hex
    return raw, str(uuid.UUID(raw))  # sem hífens (Jellyfin) / com hífens (como o site antigo guardava)


@pytest.fixture
def legacy_db(svc):
    path = _TMP / f"legacy-{uuid.uuid4().hex}.db"
    con = sqlite3.connect(path)
    con.execute(OLD_SCHEMA)
    future = (datetime.now(timezone.utc) + timedelta(days=20)).replace(microsecond=0, tzinfo=None)
    past = (datetime.now(timezone.utc) - timedelta(days=3)).replace(microsecond=0, tzinfo=None)
    ids = {}
    for name in ("tkmaster", "maria", "joao", "rita", "pedro"):
        raw, dashed = jf_guid()
        ids[name] = raw
        svc.jf.users[raw] = {"Id": raw, "Name": name, "Policy": {**DEFAULT_POLICY, "IsAdministrator": name == "tkmaster"}}
    rows = [
        (1, "Admin@TKFLIX.eu", "tkmaster", werkzeug_pbkdf2("admin-antiga-1"), "x", None, "CU1", "MD1", "Ativa",
         ids["tkmaster"], None, None, None, None, None),
        (2, "maria@example.com", "Maria", werkzeug_pbkdf2("maria-antiga-1"), "x", "tkmaster", None, None, "Ativa",
         str(uuid.UUID(ids["maria"])), None, None, "iptvpass", "maria_tv", "http://iptv.old:8080"),
        (3, "joao@example.com", "joao", werkzeug_pbkdf2("joao-antiga-1"), "x", "maria", None, None, "A expirar",
         ids["joao"], future.isoformat(sep=" "), None, None, None, None),
        (4, "rita@example.com", "rita", werkzeug_pbkdf2("rita-antiga-1"), "x", "maria", None, None, "A expirar",
         ids["rita"], past.isoformat(sep=" "), None, None, None, None),
        (5, "pedro@example.com", "pedro", werkzeug_pbkdf2("pedro-antiga-1"), "x", "2", None, None, "Em dívida",
         ids["pedro"], None, None, None, None, None),
        (6, "", "semmail", werkzeug_pbkdf2("x"), "x", None, None, None, "Desativa", None, None, None, None, None,
         None),
    ]
    con.executemany(f"INSERT INTO user VALUES ({','.join('?' * 15)})", rows)
    con.commit()
    con.close()
    return path, ids


def args(path, **kw):
    return argparse.Namespace(**{"sqlite": str(path), "admin_username": "tkmaster", "fallback_plan": "tkflix-mensal",
                                 "dry_run": False, "skip_gocardless": True, "dry_run_billing": False, **kw})


async def test_import_legacy(legacy_db, svc, capsys, make_client):
    path, ids = legacy_db
    await cli.import_legacy(args(path))
    out = capsys.readouterr().out
    assert "6 utilizadores no site antigo" in out
    assert "5 novos" in out and "1 ignorados" in out and "ofertas 1" in out and "IPTV 1" in out

    users = {u.username: u for u in await fetch(User)}
    assert set(users) == {"tkmaster", "maria", "joao", "rita", "pedro"}
    assert users["tkmaster"].is_admin and not users["maria"].is_admin
    assert users["tkmaster"].email == "admin@tkflix.eu"
    assert users["tkmaster"].gocardless_mandate_id == "MD1" and users["tkmaster"].gocardless_customer_id == "CU1"
    assert all(u.email_verified_at for u in users.values())
    assert users["maria"].legacy_id == 2
    # referências (por username e por id numérico)
    assert users["maria"].referred_by_id == users["tkmaster"].id
    assert users["joao"].referred_by_id == users["maria"].id
    assert users["pedro"].referred_by_id == users["maria"].id
    assert users["tkmaster"].referred_by_id is None

    # contas Jellyfin ligadas (GUID sem hífens)
    jf = {sa.user_id: sa for sa in await fetch(ServiceAccount, service="jellyfin")}
    assert jf[users["maria"].id].external_id == ids["maria"]
    assert jf[users["joao"].id].external_username == "joao"
    # IPTV manual
    iptv = await fetch_one(ServiceAccount, service="iptv")
    assert iptv.user_id == users["maria"].id and iptv.external_username == "maria_tv"
    assert decrypt(iptv.secret_enc) == "iptvpass" and iptv.data == {"host": "http://iptv.old:8080"}

    # 'A expirar' com data futura → oferta até essa data; com data passada → nada
    [grant] = await fetch(Grant)
    assert grant.user_id == users["joao"].id
    assert grant.plan_id == (await plan_by_code("tkflix-mensal")).id
    assert grant.ends_at > datetime.now(timezone.utc) + timedelta(days=19)
    assert "Em dívida" in out and "pedro" in out  # aviso para verificar à mão

    # login com a password antiga funciona (e é convertida para argon2)
    c = make_client()
    r = await c.login("maria", "maria-antiga-1")
    assert r.status_code == 200
    assert (await get(User, users["maria"].id)).password_hash.startswith("$argon2")

    # reconciliação: quem tem acesso fica ativo, os restantes desativados; o admin do Jellyfin não é tocado
    await drain()
    assert svc.jf.users[ids["joao"]]["Policy"]["IsDisabled"] is False
    assert svc.jf.users[ids["rita"]]["Policy"]["IsDisabled"] is True
    assert svc.jf.users[ids["tkmaster"]]["Policy"]["IsDisabled"] is False
    assert svc.jf.find("POST", rf"/Users/{ids['tkmaster']}/Policy") == []
    assert svc.jf.find("POST", r"^/Users/New$") == []

    # idempotente
    await cli.import_legacy(args(path))
    out = capsys.readouterr().out
    assert "0 novos" in out and "5 já existiam" in out and "ofertas 0" in out
    assert len(await fetch(User)) == 5 and len(await fetch(Grant)) == 1
    assert len(await fetch(ServiceAccount, service="jellyfin")) == 5


async def test_import_legacy_dry_run(legacy_db, capsys):
    path, _ = legacy_db
    await cli.import_legacy(argparse.Namespace(
        sqlite=str(path), admin_username="tkmaster", fallback_plan="tkflix-mensal", dry_run=True,
        skip_gocardless=True))
    assert "Dry-run" in capsys.readouterr().out
    assert await fetch(User) == []


async def test_import_legacy_with_gocardless_migration(legacy_db, svc, capsys):
    """A importação liga as subscrições GoCardless antigas sem as tirar da GoCardless (modo "manter"): o cliente
    continua como estava e o mandato fica guardado para a conversão automática."""
    from app.models import PaymentMethod
    from app.services import legacy

    path, ids = legacy_db
    svc.gc.customers["CU1"] = {"id": "CU1", "email": "admin@tkflix.eu"}
    svc.gc.mandates["MD1"] = {"id": "MD1", "status": "active", "links": {"customer": "CU1"}}
    gs = svc.gc.add_subscription("MD1", amount=750, name="TKFLIX + TV")

    # simulação: nada gravado nem tocado na GoCardless
    await cli.import_legacy(args(path, skip_gocardless=False, dry_run=True))
    out = capsys.readouterr().out
    assert "tkmaster: seria ligada (continua na GoCardless) tkflix-tv-mensal" in out
    assert await fetch(Subscription) == [] and gs["status"] == "active"

    await cli.import_legacy(args(path, skip_gocardless=False))
    out = capsys.readouterr().out
    assert "tkmaster: ligada (continua na GoCardless) tkflix-tv-mensal" in out
    sub = await fetch_one(Subscription)
    admin = await fetch_one(User, username="tkmaster")
    assert sub.user_id == admin.id and sub.provider == "gocardless" and sub.provider_subscription_id == gs["id"]
    assert sub.status == SubStatus.active and sub.price_cents == 750
    assert gs["status"] == "active"  # continua a ser cobrada pela GoCardless
    pm = await fetch_one(PaymentMethod)
    assert pm.user_id == admin.id and pm.provider_ref == "MD1" and pm.is_default

    # `sync-gocardless` depois: nada de novo
    await cli.sync_gocardless(argparse.Namespace(dry_run=False))
    assert "0 subscrições tratadas" in capsys.readouterr().out
    assert len(await fetch(Subscription)) == 1

    # conversão (o que acontece sozinho na 1.ª alteração do cliente)
    async with dbs() as db:
        u = await db.get(User, admin.id)
        assert await legacy.convert_user(db, u, reason="teste") == 1
        await db.commit()
    sub = await fetch_one(Subscription)
    assert sub.provider == "portal" and gs["status"] == "cancelled"
    admin = await fetch_one(User, username="tkmaster")
    assert admin.billing_anchor_day and admin.next_billing_at == sub.current_period_end


async def test_import_legacy_convert_now(legacy_db, svc, capsys):
    path, _ = legacy_db
    svc.gc.customers["CU1"] = {"id": "CU1", "email": "admin@tkflix.eu"}
    svc.gc.mandates["MD1"] = {"id": "MD1", "status": "active", "links": {"customer": "CU1"}}
    gs = svc.gc.add_subscription("MD1", amount=750, name="TKFLIX + TV")
    await cli.import_legacy(args(path, skip_gocardless=False, convert_now=True))
    assert "tkmaster: migrada tkflix-tv-mensal" in capsys.readouterr().out
    sub = await fetch_one(Subscription)
    assert sub.provider == "portal" and gs["status"] == "cancelled"


async def test_import_legacy_existing_username_is_skipped(legacy_db, capsys):
    from conftest import create_user

    path, _ = legacy_db
    await create_user("maria", email="outra-maria@example.com")
    await cli.import_legacy(args(path))
    out = capsys.readouterr().out
    assert "'Maria': username já existe no portal" in out
    assert (await fetch_one(User, username="maria")).legacy_id is None
    joao = await fetch_one(User, username="joao")
    assert joao.referred_by_id is None  # quem convidou não foi importado


async def test_create_admin_and_oidc_client_cli(capsys):
    await cli.create_admin(argparse.Namespace(email="Dono@Example.com", username="Dono", password="Admin-Pass-123"))
    u = await fetch_one(User, username="dono")
    assert u.is_admin and u.email == "dono@example.com"
    await cli.oidc_client(argparse.Namespace(id="jf", name="Jellyfin", redirect=["https://tv.test/cb"],
                                             post_logout=None, require="feature:jellyfin", public=False))
    out = capsys.readouterr().out
    assert "client_secret:" in out
    from app.models import OIDCClient

    c = await fetch_one(OIDCClient)
    assert c.required_access == "feature:jellyfin" and c.secret_hash
