"""Aparência por web: imagens, textos e emails editáveis no admin (dentro e fora do portal)."""
from __future__ import annotations

import pytest
from conftest import dbs, drain

from app.services import mailer, site_content

PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 64
SVG = b'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1 1"><script>alert(1)</script></svg>'


async def test_admin_uploads_logo_and_it_is_public_with_cache(admin_client, client):
    r = await admin_client.put("/api/admin/appearance/images/logo", files={"file": ("logo.png", PNG, "image/png")})
    assert r.status_code == 200, r.text
    url = r.json()["url"]
    assert url.startswith("/media/logo?v=")
    img = await client.get(url)
    assert img.status_code == 200 and img.content == PNG and img.headers["content-type"] == "image/png"
    assert "immutable" in img.headers["cache-control"]
    again = await client.get(url, headers={"If-None-Match": img.headers["etag"]})
    assert again.status_code == 304
    cfg = (await client.get("/api/auth/config")).json()
    assert cfg["site"]["images"] == {"logo": url}
    assert (await admin_client.delete("/api/admin/appearance/images/logo")).status_code == 200
    assert (await client.get(url)).status_code == 404
    assert (await client.get("/api/auth/config")).json()["site"]["images"] == {}


async def test_image_validation_and_svg_is_sandboxed(admin_client, client):
    bad = await admin_client.put("/api/admin/appearance/images/logo", files={"file": ("x.png", b"GIF? nope", "image/png")})
    assert bad.status_code == 400 and "Formato" in bad.json()["detail"]
    big = await admin_client.put("/api/admin/appearance/images/hero",
                                 files={"file": ("x.png", PNG + b"\x00" * site_content.MAX_IMAGE_BYTES, "image/png")})
    assert big.status_code == 413
    assert (await admin_client.put("/api/admin/appearance/images/qualquer",
                                   files={"file": ("x.png", PNG, "image/png")})).status_code == 404
    ok = await admin_client.put("/api/admin/appearance/images/favicon", files={"file": ("f.svg", SVG, "image/svg+xml")})
    r = await client.get(ok.json()["url"])
    assert r.headers["content-type"] == "image/svg+xml" and "sandbox" in r.headers["content-security-policy"]
    assert (await client.put("/api/admin/appearance/images/logo",
                             files={"file": ("logo.png", PNG, "image/png")})).status_code in (401, 403)


async def test_texts_are_saved_cleaned_and_public(admin_client, client):
    r = await admin_client.put("/api/admin/appearance/texts", json={"texts": {
        "landing.hero.title": "  A nuvem da TKmaster  ", "nav.app.services": "", "auth.login.title": "Olá"}})
    assert r.status_code == 200, r.text
    site = (await client.get("/api/auth/config")).json()["site"]
    assert site["texts"] == {"landing.hero.title": "A nuvem da TKmaster", "auth.login.title": "Olá"}
    bad = await admin_client.put("/api/admin/appearance/texts", json={"texts": {"Chave Inválida!": "x"}})
    assert bad.status_code == 400
    assert (await client.put("/api/admin/appearance/texts", json={"texts": {}})).status_code in (401, 403)


async def test_index_html_uses_title_description_favicon_and_share_image(admin_client, client):
    await admin_client.put("/api/admin/appearance/texts", json={"texts": {
        "meta.title": "TKWS <Cloud>", "meta.description": 'Serviços "digitais"'}})
    await admin_client.put("/api/admin/appearance/images/share", files={"file": ("s.png", PNG, "image/png")})
    fav = (await admin_client.put("/api/admin/appearance/images/favicon",
                                  files={"file": ("f.png", PNG, "image/png")})).json()["url"]
    page = await client.get("/")
    if page.status_code == 404:
        pytest.skip("frontend não compilado neste ambiente")
    html = page.text
    assert "<title>TKWS &lt;Cloud&gt;</title>" in html
    assert 'content="Serviços &quot;digitais&quot;"' in html
    assert 'property="og:image" content="https://portal.test/media/share?v=' in html
    assert f'<link rel="icon" href="{fav}" />' in html


async def test_email_overrides_with_preview_logo_and_sandbox(admin_client, settings, monkeypatch):
    data = (await admin_client.get("/api/admin/appearance")).json()
    tpl = next(e for e in data["emails"] if e["id"] == "verify_email")
    assert "code" in tpl["variables"] and tpl["defaults"]["cta"] == "Confirmar email"
    r = await admin_client.put("/api/admin/appearance/emails", json={"emails": {"verify_email": {
        "subject": "Código {{ code }} — {{ app_name }}", "body": "<p>Olá {{ username }}, o código é <b>{{ code }}</b>.</p>",
        "cta": "Ativar conta"}}})
    assert r.status_code == 200, r.text
    # Erros de sintaxe e tentativas de sair da sandbox
    bad = await admin_client.put("/api/admin/appearance/emails", json={"emails": {"verify_email": {"body": "{% if %}"}}})
    assert bad.status_code == 400
    prev = await admin_client.post("/api/admin/appearance/emails/verify_email/preview",
                                   json={"body": "{{ ''.__class__.__mro__ }}"})
    assert prev.status_code == 200 and "object" not in prev.json()["html"].split("<h1")[1]
    await admin_client.put("/api/admin/appearance/images/logo", files={"file": ("logo.png", PNG, "image/png")})

    sent = []

    async def fake_send(msg, **kw):
        sent.append(msg)

    monkeypatch.setattr(mailer.aiosmtplib, "send", fake_send)
    settings.set("smtp_host", "smtp.test")
    async with dbs() as db:
        await mailer.queue_email(db, "maria@example.com", "verify_email", username="maria", code="123456",
                                 cta_url="https://portal.test/verificar-email?token=abc")
        await db.commit()
    await drain()
    [msg] = sent
    assert msg["Subject"] == "Código 123456 — TK Web Services"
    html = msg.get_body(("html",)).get_content()
    assert "Olá maria, o código é <b>123456</b>." in html and "Ativar conta" in html
    assert '<img src="https://portal.test/media/logo?v=' in html
    # Os outros emails ficam como estavam
    subject, _, _ = mailer.render("reset_password", {"username": "maria", "cta_url": "https://x"})
    assert subject == "Redefinir password"


async def test_product_image_and_locked_products_do_not_leak_it(admin_client, client, admin):
    from conftest import plan_by_code

    plan = await plan_by_code("tkflix-mensal")
    r = await admin_client.put(f"/api/admin/appearance/products/{plan.product_id}/image",
                               files={"file": ("p.png", PNG, "image/png")})
    assert r.status_code == 200 and r.json()["image_url"].startswith(f"/media/product-{plan.product_id}?v=")
    products = (await admin_client.get("/api/admin/products")).json()
    assert next(p for p in products if p["id"] == plan.product_id)["image_url"] == r.json()["image_url"]
    # Para quem não tem convite, o produto em beta fechado continua genérico (sem a imagem verdadeira)
    locked = [p for p in (await client.get("/api/catalog")).json() if p["locked"]]
    assert locked and all(p["image_url"] is None for p in locked)
    assert (await admin_client.delete(f"/api/admin/appearance/products/{plan.product_id}/image")).status_code == 200
