"""Endereço da app por serviço e memória dos assistentes por cliente

Revision ID: 0007
Revises: 0006
Create Date: 2026-10-04 10:00:00

"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

import app.db  # noqa: F401 — tipos personalizados (UTCDateTime)

revision: str = '0007'
down_revision: Union[str, Sequence[str], None] = '0006'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    with op.batch_alter_table('products') as batch:
        batch.add_column(sa.Column('app_url', sa.String(length=500), nullable=True))
    op.create_table(
        'assistant_memories',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('user_id', sa.String(length=36), nullable=False),
        sa.Column('agent', sa.String(length=16), nullable=False),
        sa.Column('summary', sa.Text(), nullable=False),
        sa.Column('last_message_id', sa.Integer(), nullable=False),
        sa.Column('updated_at', app.db.UTCDateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], name=op.f('fk_assistant_memories_user_id_users'),
                                ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id', name=op.f('pk_assistant_memories')),
        sa.UniqueConstraint('user_id', 'agent', name='uq_assistant_memories_user_agent'),
    )
    op.create_index(op.f('ix_assistant_memories_user_id'), 'assistant_memories', ['user_id'], unique=False)


def downgrade() -> None:
    op.drop_index(op.f('ix_assistant_memories_user_id'), table_name='assistant_memories')
    op.drop_table('assistant_memories')
    with op.batch_alter_table('products') as batch:
        batch.drop_column('app_url')
