"""Definições editadas por web (assistente de configuração e Admin → Definições)

Revision ID: 0006
Revises: 0005
Create Date: 2026-10-03 10:00:00

"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

import app.db  # noqa: F401 — tipos personalizados (UTCDateTime)
from sqlalchemy.dialects import postgresql

revision: str = '0006'
down_revision: Union[str, Sequence[str], None] = '0005'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        'config_entries',
        sa.Column('key', sa.String(length=64), nullable=False),
        sa.Column('value', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
        sa.Column('secret', sa.Boolean(), nullable=False),
        sa.Column('updated_by', sa.String(length=36), nullable=True),
        sa.Column('updated_at', app.db.UTCDateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint('key', name=op.f('pk_config_entries')),
    )


def downgrade() -> None:
    op.drop_table('config_entries')
