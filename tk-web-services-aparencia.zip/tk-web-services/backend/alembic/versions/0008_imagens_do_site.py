"""Imagens do site editáveis por web (logótipo, favicon, página inicial, partilha, produtos)

Revision ID: 0008
Revises: 0007
Create Date: 2026-10-08 10:00:00

"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

import app.db  # noqa: F401 — tipos personalizados (UTCDateTime)

revision: str = '0008'
down_revision: Union[str, Sequence[str], None] = '0007'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        'site_assets',
        sa.Column('key', sa.String(length=64), nullable=False),
        sa.Column('content_type', sa.String(length=64), nullable=False),
        sa.Column('data', sa.LargeBinary(), nullable=False),
        sa.Column('etag', sa.String(length=32), nullable=False),
        sa.Column('size', sa.Integer(), nullable=False),
        sa.Column('updated_at', app.db.UTCDateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint('key', name=op.f('pk_site_assets')),
    )
    with op.batch_alter_table('products') as batch:
        batch.add_column(sa.Column('image_url', sa.String(length=255), nullable=True))


def downgrade() -> None:
    with op.batch_alter_table('products') as batch:
        batch.drop_column('image_url')
    op.drop_table('site_assets')
