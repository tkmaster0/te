"""Faturação por autorização: sem carregamento mensal da carteira

Os serviços passam a ser cobrados pelo método autorizado (mandato de débito direto GoCardless ou cartão Stripe), com o
valor ajustado pelo portal. Os carregamentos mensais que existiam são desligados e as contas "só carteira" passam ao
modo normal. O saldo da carteira continua a ser usado antes de qualquer cobrança.

Revision ID: 0005
Revises: 0004
Create Date: 2026-09-27 18:00:00

"""
from typing import Sequence, Union

from alembic import op

revision: str = '0005'
down_revision: Union[str, Sequence[str], None] = '0004'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.execute("UPDATE users SET billing_mode = 'legacy' WHERE billing_mode = 'wallet'")
    op.execute("UPDATE wallets SET monthly_topup_cents = NULL, monthly_since = NULL "
               "WHERE monthly_topup_cents IS NOT NULL")


def downgrade() -> None:
    # Não há como saber que contas eram "só carteira" nem os valores antigos — nada a repor.
    pass
