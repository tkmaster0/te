"""Cria uma BD de desenvolvimento com dados de demonstração (SQLite).

    export $(grep -v '^#' scripts/dev.env | xargs) && python scripts/dev_seed.py

Utilizadores:
  admin / Admin-2026!   — administrador (oferta do plano TV anual)
  maria / Filmes-2026!  — streaming TV + produto "Cloud" (manual), SEPA, em dia, 1 convidado
  joao  / Series-2026!  — streaming cancelado (a expirar), cartão
  rita  / Pipocas-2026! — cobrança falhada (pagamento em atraso) e método inutilizável
  nuno  / Novato-2026!  — conta nova, sem serviços nem métodos (onboarding)

Assistente: conversas, conhecimento (incl. sugestões por aprovar) e versões de instruções de demonstração.
Para ver o chat a funcionar sem um modelo real: python scripts/dev_server_fake_llm.py
"""
import asyncio
import sys
from datetime import timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from sqlalchemy import select  # noqa: E402

from app.assistant.models import (  # noqa: E402
    AssistantConversation, AssistantInstruction, AssistantMessage, ChannelIdentity, KnowledgeItem, PendingAction,
)
from app.db import Base, get_engine, sessionmaker, utcnow  # noqa: E402
from app.features import PlanFeatures  # noqa: E402
from app.models import (  # noqa: E402
    AuditLog, Checkout, Grant, InviteCode, Invoice, InvoiceLine, OIDCClient, Payment, PaymentMethod, Plan, PriceChange, Product,
    ServiceAccount, Subscription, SubStatus, User,
)
from app.security import encrypt, hash_password  # noqa: E402
from app.seed import seed_defaults  # noqa: E402
from app.services.billing import anchor_on  # noqa: E402
from app.services.fulfillment import set_access_details  # noqa: E402
from app.services.subscriptions import add_interval  # noqa: E402


async def main():
    engine = get_engine()
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
        await conn.run_sync(Base.metadata.create_all)
    async with sessionmaker()() as db:
        await seed_defaults(db)
        cloud = Product(code="cloud", name="TK Cloud", kind="armazenamento", fulfillment="manual", icon="cloud",
                        description="Armazenamento na nuvem para as tuas fotos e ficheiros, com backup diário.",
                        access_instructions="Entra em https://cloud.tkflix.test com os dados abaixo. "
                                            "Instala a app Nextcloud no telemóvel para sincronizar as fotos.",
                        bonus_eligible=False, sort_order=1)
        vpn = Product(code="vpn", name="TK VPN", kind="rede", fulfillment="webhook", icon="shield",
                      webhook_url="https://vpn.tkflix.test/hooks/portal",
                      description="VPN WireGuard para navegar em segurança fora de casa.", bonus_eligible=False,
                      sort_order=2)
        db.add_all([cloud, vpn])
        await db.flush()
        db.add_all([
            Plan(product_id=cloud.id, code="cloud-100", name="Cloud 100 GB", price_cents=200,
                 highlights=["100 GB", "Backup diário", "Partilha de ficheiros"], features=PlanFeatures().model_dump()),
            Plan(product_id=cloud.id, code="cloud-1tb", name="Cloud 1 TB", price_cents=500, sort_order=1,
                 highlights=["1 TB", "Backup diário", "Partilha de ficheiros", "Versões antigas 30 dias"],
                 features=PlanFeatures().model_dump()),
            Plan(product_id=vpn.id, code="vpn-mensal", name="VPN", price_cents=250,
                 highlights=["5 dispositivos", "Sem registos", "Servidor em Portugal"],
                 features=PlanFeatures().model_dump()),
        ])
        await db.flush()
        plans = {p.code: p for p in (await db.scalars(select(Plan))).all()}
        now = utcnow()
        day = min(now.day, 28)
        anchor_prev = anchor_on(now.year, now.month, day)
        if anchor_prev > now:
            anchor_prev = add_interval(anchor_prev, "month", -1)
        anchor_next = add_interval(anchor_prev, "month", 1)

        def user(u, email, name, pwd, **kw):
            # Clientes "antigos": login antigo no Jellyfin, podem pagar cada serviço e têm o TKFLIX desbloqueado.
            return User(username=u, email=email, display_name=name, password_hash=hash_password(pwd),
                        email_verified_at=now, billing_anchor_day=day, billing_mode="legacy",
                        jellyfin_password_login=True, unlocked_products=["tkflix"], **kw)

        admin = user("admin", "admin@tkflix.test", "TK Master", "Admin-2026!", is_admin=True)
        maria = user("maria", "maria@tkflix.test", "Maria Silva", "Filmes-2026!", next_billing_at=anchor_next)
        joao = user("joao", "joao@tkflix.test", None, "Series-2026!", next_billing_at=anchor_next)
        rita = user("rita", "rita@tkflix.test", "Rita Costa", "Pipocas-2026!", next_billing_at=anchor_next)
        # Conta nova: só carteira, entra por SSO e vê o TKFLIX como "TK CDN" (beta fechado) até meter um código.
        nuno = User(username="nuno", email="nuno@tkflix.test", display_name="Nuno Reis",
                    password_hash=hash_password("Novato-2026!"), email_verified_at=now, billing_mode="wallet",
                    jellyfin_password_login=False, unlocked_products=[])
        db.add_all([admin, maria, joao, rita, nuno])
        await db.flush()
        maria.referred_by_id = admin.id
        joao.referred_by_id = maria.id
        rita.referred_by_id = maria.id
        nuno.referred_by_id = admin.id
        admin.billing_anchor_day = None

        pm_maria = PaymentMethod(user_id=maria.id, provider="gocardless", provider_ref="MD000DEMO1", kind="sepa",
                                 label="Débito direto · CGD ••••4821", is_default=True, provider_account="CR000DEMO")
        pm_joao = PaymentMethod(user_id=joao.id, provider="stripe", provider_ref="pm_demo_joao", kind="card",
                                label="Cartão Visa ••••4242", is_default=True, expires_at=now + timedelta(days=400))
        pm_rita = PaymentMethod(user_id=rita.id, provider="stripe", provider_ref="pm_demo_rita", kind="card",
                                label="Cartão Mastercard ••••5454", status="unusable",
                                status_reason="O cartão expirou.", is_default=True)
        db.add_all([pm_maria, pm_joao, pm_rita])

        def sub(u, code, status=SubStatus.active, **kw):
            p = plans[code]
            return Subscription(user_id=u.id, plan_id=p.id, product_id=p.product_id, provider="portal", status=status,
                                price_cents=p.price_cents, current_period_start=anchor_prev,
                                current_period_end=anchor_next, period_amount_cents=p.price_cents,
                                started_at=now - timedelta(days=200), **kw)

        s_maria = sub(maria, "tkflix-tv-mensal")
        s_cloud = sub(maria, "cloud-100", fulfillment_status="done")
        set_access_details(s_cloud, {"Utilizador": "maria", "Password": "Nuvem-9QX2", "Endereço": "https://cloud.tkflix.test"})
        s_joao = sub(joao, "tkflix-mensal", status=SubStatus.canceling, cancel_at_period_end=True,
                     access_until=anchor_next)
        s_rita = sub(rita, "tkflix-mensal", status=SubStatus.past_due, grace_until=now + timedelta(days=6))
        db.add_all([s_maria, s_cloud, s_joao, s_rita])
        await db.flush()

        # Histórico de cobranças da Maria (uma por mês, com os dois serviços)
        for i in range(5, 0, -1):
            start = add_interval(anchor_prev, "month", -(i - 1))
            inv = Invoice(user_id=maria.id, number=f"C{start.year}-{9000 + i:05d}", kind="cycle", status="paid",
                          total_cents=950, subtotal_cents=950, created_at=start, paid_at=start + timedelta(days=4),
                          payment_method_id=pm_maria.id, period_start=start)
            db.add(inv)
            await db.flush()
            end = add_interval(start, "month", 1)
            db.add(InvoiceLine(user_id=maria.id, invoice_id=inv.id, subscription_id=s_maria.id,
                               product_id=s_maria.product_id, kind="renewal", amount_cents=750,
                               description=f"TKFLIX + TV · {start:%d/%m/%Y}–{end:%d/%m/%Y}"))
            db.add(InvoiceLine(user_id=maria.id, invoice_id=inv.id, subscription_id=s_cloud.id,
                               product_id=cloud.id, kind="renewal", amount_cents=200,
                               description=f"Cloud 100 GB · {start:%d/%m/%Y}–{end:%d/%m/%Y}"))
            db.add(Payment(user_id=maria.id, invoice_id=inv.id, provider="gocardless", provider_payment_id=f"PM0DEMO{i}",
                           amount_cents=950, status="paid", description=f"Cobrança {inv.number}", charge_date=start,
                           payment_method_id=pm_maria.id))
        # João: pagou uma vez
        inv_j = Invoice(user_id=joao.id, number="C2026-09100", kind="cycle", status="paid", total_cents=500,
                        subtotal_cents=500, created_at=anchor_prev, paid_at=anchor_prev, payment_method_id=pm_joao.id)
        db.add(inv_j)
        await db.flush()
        db.add(InvoiceLine(user_id=joao.id, invoice_id=inv_j.id, subscription_id=s_joao.id, product_id=s_joao.product_id,
                           kind="renewal", amount_cents=500, description="TKFLIX · mês atual"))
        # Rita: cobrança falhada
        inv_r = Invoice(user_id=rita.id, number="C2026-09101", kind="cycle", status="failed", total_cents=500,
                        subtotal_cents=500, created_at=anchor_prev, attempt_count=1,
                        next_attempt_at=now + timedelta(days=2), first_failed_at=anchor_prev,
                        last_error="O cartão expirou.", payment_method_id=pm_rita.id)
        db.add(inv_r)
        await db.flush()
        db.add(InvoiceLine(user_id=rita.id, invoice_id=inv_r.id, subscription_id=s_rita.id, product_id=s_rita.product_id,
                           kind="renewal", amount_cents=500, description="TKFLIX · mês atual"))
        # Linha pendente (pro-rata) na próxima cobrança da Maria + mudança de preço agendada
        db.add(InvoiceLine(user_id=maria.id, kind="adjustment", amount_cents=-100,
                           description="Compensação pela manutenção de 12/09"))
        db.add(PriceChange(plan_id=plans["tkflix-mensal"].id, old_price_cents=500, new_price_cents=600,
                           effective_at=now + timedelta(days=35), note="Aumento do custo do servidor e do debrid.",
                           notified_at=now))
        # Regresso do fornecedor (página /app/pagamento/retorno?checkout=…)
        db.add(Checkout(id="demo-checkout-pendente", user_id=nuno.id, plan_id=plans["tkflix-mensal"].id,
                        provider="gocardless", purpose="setup_pm", provider_ref="BRQ000DEMO",
                        intent={"action": "subscribe", "plan_id": plans["tkflix-mensal"].id}))
        db.add(Checkout(id="demo-checkout-concluido", user_id=maria.id, provider="gocardless", purpose="setup_pm",
                        status="completed", completed_at=now, payment_method_id=pm_maria.id))
        db.add(Grant(user_id=admin.id, plan_id=plans["tkflix-tv-anual"].id, reason="Conta do administrador"))
        db.add(ServiceAccount(user_id=maria.id, service="jellyfin", external_id="a1b2c3", external_username="maria"))
        db.add(ServiceAccount(user_id=maria.id, service="dispatcharr", external_id="7", external_username="maria",
                              secret_enc=encrypt("Xy7pQ2mN8vLk3sT1"),
                              applied_state={"enabled": True, "stream_limit": 1, "channel_profiles": []}))
        db.add(InviteCode(code="TK-DEMO-2026", created_by_id=maria.id, max_uses=1))
        db.add(InviteCode(code="TK-ADMN-0001", created_by_id=admin.id, max_uses=10, note="Família"))
        db.add(OIDCClient(client_id="jellyfin", name="Jellyfin (SSO)",
                          redirect_uris=["https://tkflix.test/sso/OID/redirect/tkflix"],
                          secret_hash=hash_password("dev-secret"), required_access="feature:jellyfin"))
        db.add(AuditLog(action="auth.login", actor_id=maria.id, actor_label="maria", target_type="user",
                        target_id=maria.id, ip="127.0.0.1"))
        await seed_assistant(db, now, maria=maria, joao=joao, rita=rita, nuno=nuno, s_maria=s_maria)
        # Carteira: maria com carregamento mensal e saldo; nuno com um carregamento único; código TKFLIX para o nuno.
        from app.models import Wallet, WalletTransaction

        db.add(Wallet(user_id=maria.id, balance_cents=730, monthly_topup_cents=1200, monthly_skip_when_covered=True,
                      monthly_since=now - timedelta(days=40), games_accepted_at=now - timedelta(days=5)))
        db.add(WalletTransaction(user_id=maria.id, kind="monthly_topup", amount_cents=1200, balance_after_cents=1200,
                                 description="Carregamento mensal", created_at=now - timedelta(days=9)))
        db.add(WalletTransaction(user_id=maria.id, kind="invoice", amount_cents=-950, balance_after_cents=250,
                                 description="Pagamento da cobrança do mês", created_at=now - timedelta(days=9)))
        db.add(WalletTransaction(user_id=maria.id, kind="game_bet", amount_cents=-100, balance_after_cents=150,
                                 description="Roleta — aposta", created_at=now - timedelta(days=2)))
        db.add(WalletTransaction(user_id=maria.id, kind="game_win", amount_cents=580, balance_after_cents=730,
                                 description="Roleta — prémio (saiu 17)", created_at=now - timedelta(days=2)))
        db.add(Wallet(user_id=nuno.id, balance_cents=1000))
        db.add(WalletTransaction(user_id=nuno.id, kind="topup", amount_cents=1000, balance_after_cents=1000,
                                 description="Carregamento (demo)", created_at=now - timedelta(hours=3)))
        db.add(InviteCode(code="TKFLIX-NUNO", created_by_id=maria.id, max_uses=1, note="Para o Nuno testar"))
        await db.commit()
    print("BD de desenvolvimento pronta.")


async def seed_assistant(db, now, *, maria, joao, rita, nuno, s_maria):
    """Dados de demonstração dos assistentes (painel admin e histórico do cliente)."""
    from app.assistant.agents import AGENTS

    def ago(**kw):
        return now - timedelta(**kw)

    # Instruções: Suporte com duas versões (a 2.ª ativa), Faturação na predefinição.
    base = AGENTS["support"].default_instructions
    db.add_all([
        AssistantInstruction(agent="support", version=1, content=base, note="Versão inicial", active=False,
                             created_by="admin", created_at=ago(days=12)),
        AssistantInstruction(agent="support", version=2, active=True, created_by="admin", created_at=ago(days=2),
                             note="Quick Connect na TV primeiro",
                             content=base + "- Na TV, sugere sempre entrar com o Quick Connect (código de 6 dígitos) "
                                            "em vez de escrever a password com o comando.\n"),
    ])

    def conv(user, channel, agent, title, *, status="open", created, scope=None, external_ref=None, meta=None,
             note=None):
        c = AssistantConversation(user_id=user.id if user else None, channel=channel, agent=agent, title=title,
                                  status=status, scope=scope, external_ref=external_ref, meta=meta, admin_note=note,
                                  created_at=created, updated_at=created + timedelta(minutes=6),
                                  escalated_at=created + timedelta(minutes=5) if status == "escalated" else None,
                                  resolved_at=created + timedelta(minutes=6) if status == "resolved" else None)
        db.add(c)
        return c

    def msg(c, agent, role, content, at, **kw):
        m = AssistantMessage(conversation_id=c.id, agent=agent, role=role, content=content, created_at=at, **kw)
        db.add(m)
        return m

    # 1) Maria, portal: legendas (Suporte) → cancelar (Faturação) com confirmação cancelada.
    t = ago(hours=3)
    c1 = conv(maria, "web", "billing", "As legendas do The Bear estão dessincronizadas", created=t)
    await db.flush()
    msg(c1, "support", "user", "As legendas do The Bear estão dessincronizadas", t)
    msg(c1, "support", "assistant", None, t + timedelta(seconds=4), model="anthropic/claude-sonnet-4-5",
        tokens_in=3120, tokens_out=48, tool_calls=[{"id": "c1", "name": "find_title", "arguments": {"query": "The Bear"}}])
    msg(c1, "support", "tool", '[{"item_id": "9f1c", "type": "Series", "title": "The Bear (2022)"}]',
        t + timedelta(seconds=5), tool_call_id="c1", tool_name="find_title")
    msg(c1, "support", "assistant", None, t + timedelta(seconds=9), model="anthropic/claude-sonnet-4-5",
        tokens_in=3380, tokens_out=61,
        tool_calls=[{"id": "c2", "name": "sync_subtitles", "arguments": {"item_id": "9f1c", "language": "pt"}}])
    msg(c1, "support", "tool", '{"ok": true, "language": "pt", "shift_ms": -1850}', t + timedelta(seconds=14),
        tool_call_id="c2", tool_name="sync_subtitles")
    a1 = msg(c1, "support", "assistant",
             "Sincronizei as legendas em **português** de *The Bear* (estavam ~1,8 s adiantadas). ✅\n\n"
             "Fecha o episódio e volta a abri-lo, e escolhe a legenda no menu **Legendas**.",
             t + timedelta(seconds=15), model="anthropic/claude-sonnet-4-5", tokens_in=3510, tokens_out=72)
    a1.feedback = 1
    msg(c1, "billing", "event", "A falar com o Agente de Faturação.", t + timedelta(minutes=2),
        ui={"type": "agent_switch", "agent": "billing", "reason": "auto"})
    msg(c1, "billing", "user", "Obrigada! Já agora, quero cancelar a subscrição", t + timedelta(minutes=2))
    msg(c1, "billing", "assistant", None, t + timedelta(minutes=2, seconds=4), model="anthropic/claude-sonnet-4-5",
        tokens_in=4020, tokens_out=40, tool_calls=[{"id": "c3", "name": "get_billing_overview", "arguments": {}}])
    msg(c1, "billing", "tool", '{"subscriptions": [{"subscription_id": "' + s_maria.id + '", "plan": "TKFLIX + TV"}]}',
        t + timedelta(minutes=2, seconds=5), tool_call_id="c3", tool_name="get_billing_overview")
    act = PendingAction(conversation_id=c1.id, user_id=maria.id, agent="billing", tool="cancel_subscription",
                        args={"subscription_id": s_maria.id}, status="cancelled",
                        summary="Cancelar TKFLIX + TV — deixas de ser cobrado e manténs o acesso até ao fim do período.",
                        expires_at=t + timedelta(minutes=32), created_at=t + timedelta(minutes=2, seconds=8),
                        decided_at=t + timedelta(minutes=3))
    db.add(act)
    await db.flush()
    msg(c1, "billing", "event", act.summary, t + timedelta(minutes=2, seconds=8),
        ui={"type": "confirm", "action_id": act.id, "summary": act.summary})
    msg(c1, "billing", "assistant", "Preparei o cancelamento. Para avançar basta carregar em **Confirmar** "
                                    "(válido 30 minutos).", t + timedelta(minutes=2, seconds=9),
        model="anthropic/claude-sonnet-4-5", tokens_in=4210, tokens_out=31)
    msg(c1, "billing", "assistant", "Ok, não fiz nada. 👍", t + timedelta(minutes=3),
        ui={"type": "action_result", "action_id": act.id, "status": "cancelled"})

    # 2) Rita, WhatsApp: pagamento em atraso, escalada, com 👎.
    t = ago(hours=20)
    c2 = conv(rita, "whatsapp", "billing", "Paguei por MB WAY mas continua em atraso", status="escalated", created=t,
              external_ref="351912345789",
              meta={"escalation": "Cliente diz que pagou 5,00 € por MB WAY no dia 26, mas a cobrança C2026-09101 "
                                  "continua falhada. Verificar pagamento manual.", "urgency": "high"})
    await db.flush()
    msg(c2, "billing", "user", "Paguei por MB WAY mas continua em atraso", t)
    msg(c2, "billing", "assistant", None, t + timedelta(seconds=3), model="anthropic/claude-sonnet-4-5",
        tokens_in=2900, tokens_out=35, tool_calls=[{"id": "r1", "name": "get_billing_overview", "arguments": {}}])
    msg(c2, "billing", "tool", '{"unpaid_charges": [{"number": "C2026-09101", "total": "5,00 €", "status": "falhada"}]}',
        t + timedelta(seconds=4), tool_call_id="r1", tool_name="get_billing_overview")
    bad = msg(c2, "billing", "assistant", "Não encontro nenhum pagamento por MB WAY. A cobrança *C2026-09101* "
                                          "(5,00 €) continua por pagar. Podes pagá-la no portal.",
              t + timedelta(seconds=8), model="anthropic/claude-sonnet-4-5", tokens_in=3050, tokens_out=44)
    bad.feedback = -1
    bad.feedback_note = "Eu paguei mesmo, tenho o comprovativo."
    msg(c2, "billing", "user", "Mas eu paguei! Quero falar com uma pessoa", t + timedelta(minutes=2))
    msg(c2, "billing", "assistant", None, t + timedelta(minutes=2, seconds=3), model="anthropic/claude-sonnet-4-5",
        tokens_in=3300, tokens_out=70,
        tool_calls=[{"id": "r2", "name": "escalate_to_human",
                     "arguments": {"summary": "Pagamento MB WAY não reconhecido", "urgency": "high"}}])
    msg(c2, "billing", "tool", "Caso passado a um administrador.", t + timedelta(minutes=2, seconds=4),
        tool_call_id="r2", tool_name="escalate_to_human")
    msg(c2, "billing", "assistant", "Passei o teu caso a um administrador — uma pessoa vai ver o pagamento e "
                                    "responder-te ainda hoje. 🙏", t + timedelta(minutes=2, seconds=6),
        model="anthropic/claude-sonnet-4-5", tokens_in=3420, tokens_out=29)

    # 3) João, Jellyfin: app na TV, resolvida.
    t = ago(days=2)
    c3 = conv(joao, "jellyfin", "support", "Como instalo a app na TV Samsung?", status="resolved", created=t,
              scope="streaming")
    await db.flush()
    msg(c3, "support", "user", "Como instalo a app na TV Samsung?", t)
    a3 = msg(c3, "support", "assistant",
             "Nas Samsung (Tizen) a app oficial não está na loja. O mais simples:\n"
             "1. Usa um Chromecast/Google TV ligado à TV, ou\n2. Abre o browser da TV em https://tkflix.test\n\n"
             "Para entrar sem escrever a password usa o **Quick Connect**.", t + timedelta(seconds=6),
             model="anthropic/claude-sonnet-4-5", tokens_in=2800, tokens_out=90)
    a3.feedback = 1

    # 4) Maria, issue do Seerr (Suporte automático).
    t = ago(days=1, hours=4)
    c4 = conv(maria, "seerr", "support", "Issue #42 — Legendas em falta (Dune: Part Two)", status="resolved",
              created=t, external_ref="42")
    await db.flush()
    msg(c4, "support", "user", "[Issue #42 · Legendas] Dune: Part Two não tem legendas em português", t)
    msg(c4, "support", "assistant", "Descarreguei legendas em português para *Dune: Part Two* (2024). Fecha e "
                                    "reabre o filme para as veres.", t + timedelta(seconds=20),
        model="anthropic/claude-sonnet-4-5", tokens_in=3900, tokens_out=40)

    # 5) Nuno, portal: preços (aberta, recente).
    t = ago(minutes=40)
    c5 = conv(nuno, "web", "billing", "Quanto custa o plano com TV?", created=t)
    await db.flush()
    msg(c5, "billing", "user", "Quanto custa o plano com TV?", t)
    msg(c5, "billing", "assistant", "O **TKFLIX + TV** custa 7,50 €/mês. Se aderires hoje pagas só a parte do mês "
                                    "até ao teu dia de faturação. Vê os planos em /app/planos.",
        t + timedelta(seconds=5), model="anthropic/claude-sonnet-4-5", tokens_in=2600, tokens_out=52)

    # Rita tem o WhatsApp ligado.
    db.add(ChannelIdentity(user_id=rita.id, channel="whatsapp", external_id="351912345789",
                           display="+351 ••• ••789", verified_at=ago(days=5)))

    # Conhecimento: ativos, promovido e sugestões por aprovar.
    db.add_all([
        KnowledgeItem(agent="support", title="Legendas dessincronizadas", tags=["legendas", "sincronizar"],
                      content="1. Identifica o título e o episódio.\n2. Usa **sync_subtitles** no idioma em causa.\n"
                              "3. Diz ao cliente para fechar e reabrir o vídeo e escolher a legenda no menu.",
                      created_by="admin", uses=14, created_at=ago(days=20), updated_at=ago(days=20)),
        KnowledgeItem(agent="support", title="Como entrar na TV com o Quick Connect", tags=["tv", "quick connect"],
                      content="Na app da TV escolhe **Quick Connect**; aparece um código de 6 dígitos. O cliente "
                              "pode dizer-te o código e tu autorizas (pede confirmação) ou ele autoriza em "
                              "Os meus serviços → Streaming.", created_by="admin", uses=9,
                      created_at=ago(days=15), updated_at=ago(days=15)),
        KnowledgeItem(agent="billing", title="Quando é cobrada a primeira mensalidade?", source="promoted",
                      tags=["pro-rata", "dia de faturação"], source_conversation_id=c5.id, created_by="admin",
                      content="Pergunta: Quando pago?\nResposta aprovada: Na adesão pagas só a parte até ao teu dia "
                              "de faturação; a partir daí todos os serviços são cobrados juntos nesse dia.",
                      uses=6, created_at=ago(days=6), updated_at=ago(days=6)),
        KnowledgeItem(agent="billing", title="Pagamento por MB WAY não reconhecido", source="suggested", status="draft",
                      tags=["mbway", "pagamento manual"], source_conversation_id=c2.id,
                      content="Se o cliente diz que pagou por MB WAY fora do portal, não afirmes que não pagou: "
                              "pede a data e o valor, e escala para um administrador verificar o pagamento manual.",
                      created_at=ago(hours=6), updated_at=ago(hours=6)),
        KnowledgeItem(agent="support", title="Apps para TV Samsung (Tizen)", source="suggested", status="draft",
                      tags=["tv", "samsung", "apps"], source_conversation_id=c3.id,
                      content="Nas TV Samsung a app oficial não está na loja. Alternativas: Chromecast/Google TV, "
                              "o browser da TV, ou instalar a app Tizen via modo de programador (avançado).",
                      created_at=ago(hours=5), updated_at=ago(hours=5)),
    ])


asyncio.run(main())
