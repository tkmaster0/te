"""Servidor de desenvolvimento com um modelo de linguagem FALSO (sem custos, sem rede).

Serve para ver o chat dos assistentes a funcionar (encaminhamento, transferências, pedidos de confirmação,
feedback, painel admin) sem configurar um fornecedor real. NUNCA usar em produção.

    cd backend && set -a && . scripts/dev.env && set +a
    python scripts/dev_seed.py
    python scripts/dev_server_fake_llm.py            # http://localhost:8000 (PORT=... para mudar)

Frases que o modelo falso reconhece (o resto recebe uma resposta genérica):
  * "legendas" / "dessincronizadas"         → Suporte, resposta com passos
  * "app" / "TV" / "instalar"               → Suporte, passos + link
  * "próxima cobrança" / "quanto vou pagar" → Faturação, consulta get_billing_overview
  * "mudar de plano" / "planos"             → Faturação, get_catalog (e change_or_subscribe_plan se nomear um plano)
  * "cancelar"                              → Faturação, get_billing_overview → cancel_subscription (cartão Confirmar)
  * falar de pagamentos numa conversa de Suporte (ou vice-versa) → transferência entre agentes
Opcional: FAKE_LLM_DELAY=segundos (predefinição 1.5) para ver o indicador "a escrever".
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
import unicodedata
import uuid
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# Configuração só para desenvolvimento — antes de importar a app (as settings ficam em cache).
os.environ.setdefault("ASSISTANT_ENABLED", "true")
os.environ.setdefault("ASSISTANT_MODEL", "fake/dev-model")
os.environ.setdefault("WHATSAPP_PROVIDER", "evolution")
os.environ.setdefault("EVOLUTION_URL", "http://evolution.invalid")
os.environ.setdefault("EVOLUTION_API_KEY", "dev-only")
os.environ.setdefault("EVOLUTION_INSTANCE", "tkflix-dev")
os.environ.setdefault("WHATSAPP_NUMBER", "351910000000")

from app.assistant import llm  # noqa: E402
from app.assistant.llm import LLMResponse, ToolCall  # noqa: E402

DELAY = float(os.environ.get("FAKE_LLM_DELAY", "1.5"))


def fold(text: str) -> str:
    text = unicodedata.normalize("NFKD", (text or "").lower())
    return "".join(c for c in text if not unicodedata.combining(c))


def has(text: str, *words: str) -> bool:
    return any(w in text for w in words)


BILLING = ("cobranc", "pagar", "pagament", "fatura", "plano", "cancel", "preco", "custa", "subscri", "mensalidade")
SUPPORT = ("legenda", "app", " tv", "televis", "filme", "serie", "episodio", "jellyfin", "instal", "buffering")


class FakeLLM:
    """Implementa a mesma interface que app.assistant.llm.LLM."""

    model = "fake/dev-model"

    async def embed(self, texts):  # noqa: ARG002 — sem embeddings: pesquisa por palavras-chave
        return None

    async def complete(self, messages, tools=None, *, fast=False, metadata=None, json_mode=False):  # noqa: ARG002
        await asyncio.sleep(DELAY if not fast else 0.1)
        if fast and json_mode:
            return self._suggestion(messages)
        if fast:
            text = fold(messages[-1]["content"])
            return LLMResponse(content="BILLING" if has(text, *BILLING) else "SUPPORT", model=self.model)
        names = {t["function"]["name"] for t in (tools or [])}
        agent = "billing" if "get_billing_overview" in names else "support"
        idx = max(i for i, m in enumerate(messages) if m["role"] == "user")
        question = str(messages[idx]["content"]).split("\n\n[Nota interna")[0]
        after = messages[idx + 1:]
        results: dict[str, str] = {}
        id_to_name = {}
        for m in after:
            for c in m.get("tool_calls") or []:
                id_to_name[c["id"]] = c["function"]["name"]
            if m["role"] == "tool":
                results[id_to_name.get(m["tool_call_id"], "?")] = m["content"]
        text = fold(question)
        return (self._billing if agent == "billing" else self._support)(text, results, names)

    # ------------------------------------------------------------------ helpers
    def _say(self, content: str) -> LLMResponse:
        return LLMResponse(content=content, model=self.model, tokens_in=2400 + len(content) * 3, tokens_out=len(content) // 4)

    def _call(self, name: str, args: dict | None = None, content: str | None = None) -> LLMResponse:
        return LLMResponse(content=content, tool_calls=[ToolCall(id=f"call_{uuid.uuid4().hex[:10]}", name=name,
                                                                 arguments=args or {})],
                           model=self.model, tokens_in=2600, tokens_out=40)

    # ------------------------------------------------------------------ Suporte
    def _support(self, text: str, results: dict, names: set) -> LLMResponse:
        if has(text, *BILLING) and not has(text, "legenda", "app") and "transfer_to_billing" in names and not results:
            return self._call("transfer_to_billing", {"summary": "O cliente tem uma questão de faturação."})
        if has(text, "legenda", "dessincron", "subtitle"):
            return self._say(
                "Vamos resolver isso! 🎬\n\n"
                "- Diz-me o **título** (e o episódio, se for uma série) e o idioma da legenda.\n"
                "- Eu sincronizo a legenda automaticamente — demora uns segundos.\n"
                "- Depois fecha o vídeo e volta a abri-lo, e escolhe a legenda no menu **Legendas**.\n\n"
                "Se preferires, também posso procurar outra legenda para essa versão.")
        if has(text, " tv", "televis", "app", "instal", "android", "iphone", "firestick"):
            return self._say(
                "Para ver na TV:\n\n"
                "1. Instala a app **Jellyfin** na loja da TV (Android/Google TV, Fire TV, LG webOS).\n"
                "2. Na app, escolhe **Quick Connect** — aparece um código de 6 dígitos.\n"
                "3. Diz-me o código (ou autoriza-o em [Os meus serviços](/app/servicos)) e entras sem escrever a password.\n\n"
                "Em TV Samsung sem app, usa um Chromecast ou o browser da TV em https://tkflix.test.")
        return self._say("Posso ajudar com apps, legendas, reprodução e pedidos de filmes ou séries. "
                         "Conta-me o que se passa — qual o título e em que dispositivo? 🙂")

    # ------------------------------------------------------------------ Faturação
    def _billing(self, text: str, results: dict, names: set) -> LLMResponse:
        if has(text, "legenda", "filme", "episodio", "buffering") and "transfer_to_support" in names and not results:
            return self._call("transfer_to_support", {"summary": "O cliente tem uma questão técnica do streaming."})

        def overview() -> dict:
            try:
                return json.loads(results.get("get_billing_overview") or "{}")
            except ValueError:
                return {}

        if has(text, "cancel"):
            if "get_billing_overview" not in results:
                return self._call("get_billing_overview")
            if "cancel_subscription" not in results:
                subs = overview().get("subscriptions")
                if isinstance(subs, list) and subs:
                    return self._call("cancel_subscription", {"subscription_id": subs[0]["subscription_id"]})
                return self._say("Não encontrei nenhuma subscrição ativa para cancelar. 🤔")
            out = results["cancel_subscription"]
            if out.startswith("Erro"):
                return self._say(f"Não consegui preparar o cancelamento: {out.removeprefix('Erro: ')}")
            return self._say("Preparei o cancelamento. Manténs o acesso até ao fim do período já pago e podes "
                             "reativar até lá. Para avançar carrega em **Confirmar** (válido 30 minutos).")

        if has(text, "mudar", "plano", "upgrade", "downgrade", "aderir"):
            if "get_catalog" not in results:
                return self._call("get_catalog")
            try:
                catalog = json.loads(results["get_catalog"])
            except ValueError:
                catalog = {}
            plans = [(s["service"], p) for s in catalog.get("services", []) for p in s["plans"]]
            chosen = next((p for _s, p in plans if len(p["name"]) > 4 and fold(p["name"]) in text), None)
            if chosen and "change_or_subscribe_plan" not in results:
                return self._call("change_or_subscribe_plan", {"plan_id": chosen["plan_id"]})
            if "change_or_subscribe_plan" in results:
                return self._say("Está pronto — carrega em **Confirmar** para mudar de plano.")
            lines = "\n".join(f"- **{p['name']}** ({s}) — {p['price']}" for s, p in plans[:8])
            return self._say(f"Estes são os planos disponíveis:\n\n{lines}\n\nDiz-me para qual queres mudar e eu "
                             "mostro-te quanto pagas já. Também podes ver tudo na [Loja](/app/planos).")

        if has(text, "cobranc", "pagar", "pago", "fatura", "quanto", "proxim"):
            if "get_billing_overview" not in results:
                return self._call("get_billing_overview")
            nxt = overview().get("next_charge") or {}
            if not nxt.get("date"):
                return self._say("Ainda não tens nenhuma cobrança agendada. Quando aderires a um serviço, "
                                 "a cobrança passa a ser mensal no teu dia de faturação.")
            lines = "\n".join(f"- {ln}" for ln in nxt.get("lines") or [])
            return self._say(f"A próxima cobrança é a **{nxt['date']}**, no valor de **{nxt.get('total')}**:\n\n"
                             f"{lines}\n\nPodes ver o detalhe em [Faturação](/app/faturacao).")
        return self._say("Posso ajudar com cobranças, planos, métodos de pagamento e faturas. O que precisas? 🙂")

    # ------------------------------------------------------------------ aprendizagem
    def _suggestion(self, messages) -> LLMResponse:
        system = messages[0]["content"]
        agent = "billing" if '"billing"' in system else "support"
        data = ({"useful": True, "title": "Cancelamento: confirmar antes de avançar",
                 "content": "Antes de cancelar, pergunta uma vez se o motivo é um problema técnico que o Suporte "
                            "possa resolver. Depois propõe o cancelamento e lembra que o acesso se mantém até ao fim "
                            "do período pago.", "tags": ["cancelar", "retenção"]}
                if agent == "billing" else
                {"useful": True, "title": "Legendas dessincronizadas numa série",
                 "content": "Confirma o episódio exato com find_episode, sincroniza no idioma pedido e lembra o "
                            "cliente de reabrir o vídeo.", "tags": ["legendas", "séries"]})
        return LLMResponse(content=json.dumps(data, ensure_ascii=False), model=self.model, tokens_in=900, tokens_out=120)


llm.set_llm_factory(FakeLLM)

if __name__ == "__main__":
    import uvicorn

    print("⚠️  Modelo FALSO ativo — só para desenvolvimento.")
    uvicorn.run("app.main:app", host="127.0.0.1", port=int(os.environ.get("PORT", "8000")), log_level="info")
