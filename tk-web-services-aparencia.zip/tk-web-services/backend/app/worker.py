"""Processo worker: executa a fila de jobs e as tarefas periódicas.

    python -m app.worker
"""
from __future__ import annotations

import asyncio
import logging
import signal

from .config import get_settings
from .services import tasks
from .services.jobs import worker_loop


async def main(concurrency: int = 2) -> None:
    logging.basicConfig(level=get_settings().log_level, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGTERM, signal.SIGINT):
        try:
            loop.add_signal_handler(sig, stop.set)
        except NotImplementedError:
            pass
    workers = [asyncio.create_task(worker_loop(stop)) for _ in range(concurrency)]
    sched = asyncio.create_task(tasks.scheduler_loop(stop))
    await stop.wait()
    await asyncio.gather(*workers, sched, return_exceptions=True)


if __name__ == "__main__":
    asyncio.run(main())
