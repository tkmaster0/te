"""Modelos de entrada/saída da API (também geram o OpenAPI usado pelo frontend)."""
from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, EmailStr, Field

from .features import PlanFeatures


class Ok(BaseModel):
    ok: bool = True
    message: str | None = None


# --------------------------------------------------------------------------- auth
class RegisterIn(BaseModel):
    email: EmailStr
    username: str = Field(min_length=3, max_length=32)
    password: str = Field(min_length=8, max_length=256)
    invite_code: str | None = Field(None, max_length=32)
    display_name: str | None = Field(None, max_length=120)
    accept_terms: bool = True


class LoginIn(BaseModel):
    login: str = Field(min_length=1, max_length=254, description="email ou username")
    password: str = Field(min_length=1, max_length=256)
    remember: bool = True
    next: str | None = None


class TwoFactorIn(BaseModel):
    code: str = Field(min_length=6, max_length=16)
    next: str | None = None


class LoginOut(BaseModel):
    status: Literal["ok", "mfa_required"]
    redirect: str | None = None
    user: MeOut | None = None


class TokenIn(BaseModel):
    token: str = Field(min_length=10, max_length=200)


class CodeIn(BaseModel):
    code: str = Field(min_length=4, max_length=12)


class ForgotIn(BaseModel):
    email: EmailStr


class ResetIn(BaseModel):
    token: str = Field(min_length=10, max_length=200)
    password: str = Field(min_length=8, max_length=256)


class AccessSource(BaseModel):
    type: str
    plan: str
    plan_code: str
    status: str | None = None
    until: str | None = None


class MeOut(BaseModel):
    id: str
    username: str
    email: str
    display_name: str | None
    email_verified: bool
    is_admin: bool
    totp_enabled: bool
    created_at: datetime
    has_access: bool
    features: list[str]
    access: list[AccessSource]
    needs_password_sync: bool
    referred_by: str | None = None
    session_scope: str | None = None  # "streaming" = sessão aberta a partir do Jellyfin (limitada)
    billing_anchor_day: int | None = None
    next_billing_at: datetime | None = None
    billing_mode: str = "wallet"
    # False = entra no Jellyfin/Seerr/LibreChat por SSO (contas novas); True = mantém o login antigo no Jellyfin
    jellyfin_password_login: bool = False
    unlocked_products: list[str] = Field(default_factory=list)
    wallet_balance_cents: int = 0
    # Jogos visíveis para este cliente (ligados e com o TKFLIX desbloqueado)
    games_available: bool = False


class PublicConfig(BaseModel):
    app_name: str
    registration_mode: str
    require_email_verification: bool
    providers: dict[str, bool]
    jellyfin_url: str | None
    seerr_url: str | None
    bonus: dict[str, Any]
    site: dict[str, Any]
    billing: dict[str, Any] = Field(default_factory=dict)
    wallet: dict[str, Any] = Field(default_factory=dict)
    games: dict[str, Any] = Field(default_factory=dict)
    sso: dict[str, Any] = Field(default_factory=dict)


# --------------------------------------------------------------------------- conta
class ProfileIn(BaseModel):
    display_name: str | None = Field(None, max_length=120)
    locale: str | None = Field(None, max_length=10)


class PasswordChangeIn(BaseModel):
    current_password: str = Field(min_length=1, max_length=256)
    new_password: str = Field(min_length=8, max_length=256)
    logout_others: bool = True


class EmailChangeIn(BaseModel):
    new_email: EmailStr
    password: str = Field(min_length=1, max_length=256)


class SessionOut(BaseModel):
    id: str
    created_at: datetime
    last_seen_at: datetime
    ip: str | None
    user_agent: str | None
    current: bool


class TotpSetupOut(BaseModel):
    secret: str
    otpauth_uri: str
    qr_svg: str


class TotpEnableIn(BaseModel):
    code: str = Field(min_length=6, max_length=8)


class TotpDisableIn(BaseModel):
    password: str
    code: str = Field(min_length=6, max_length=16)


class PasswordOnlyIn(BaseModel):
    password: str = Field(min_length=1, max_length=256)


class RecoveryCodesOut(BaseModel):
    recovery_codes: list[str]


class ActivityOut(BaseModel):
    created_at: datetime
    action: str
    ip: str | None
    details: dict | None


# --------------------------------------------------------------------------- catálogo / billing
class PlanOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    code: str
    name: str
    description: str | None
    price_cents: int
    currency: str
    interval_unit: str
    interval_count: int
    monthly_equivalent_cents: int
    highlights: list[str]
    features: PlanFeatures
    providers: list[str] = Field(description="Fornecedores disponíveis para novos métodos de pagamento")
    product_id: int


class ProductBrief(BaseModel):
    id: int
    code: str
    name: str
    kind: str
    fulfillment: str
    icon: str | None
    image_url: str | None = None
    jellyfin_managed: bool
    bonus_eligible: bool
    requires_invite: bool = False


class ProductOut(BaseModel):
    id: int
    code: str
    name: str
    description: str | None
    kind: str
    fulfillment: str
    icon: str | None
    image_url: str | None = None
    jellyfin_managed: bool
    bonus_eligible: bool
    requires_invite: bool = False
    # Beta fechado e ainda não desbloqueado: nome/descrição genéricos, sem planos, com opção de meter um código.
    locked: bool = False
    plans: list[PlanOut]


class QuoteLineOut(BaseModel):
    description: str
    amount_cents: int
    kind: str


class QuoteOut(BaseModel):
    kind: str
    lines: list[QuoteLineOut]
    due_now_cents: int
    next_invoice_cents: int
    next_billing_at: datetime | None
    period_end: datetime | None
    recurring_cents: int
    interval_unit: str
    interval_count: int
    bonus_applies: bool
    is_upgrade: bool | None = None
    requires_payment_method: bool = False
    wallet_balance_cents: int = 0
    wallet_cents: int = 0
    charge_now_cents: int = 0
    wallet_only: bool = False
    monthly_enabled: bool = False
    monthly_topup_cents: int | None = None
    suggested_monthly_cents: int | None = None


class SubscribeIn(BaseModel):
    plan_id: int
    payment_method_id: str | None = None
    # Sem método guardado: fornecedor para o criar (redireciona e subscreve no regresso)
    provider: Literal["gocardless", "stripe"] | None = None
    # Ativar (ou alterar) o carregamento mensal da carteira no mesmo passo.
    monthly_topup_cents: int | None = Field(None, ge=0, le=1_000_000)


class SubscribeOut(BaseModel):
    status: Literal["active", "redirect"]
    subscription_id: str | None = None
    checkout_id: str | None = None
    redirect_url: str | None = None
    message: str | None = None


class ChangePlanIn(BaseModel):
    plan_id: int


class ChangePlanOut(BaseModel):
    ok: bool = True
    message: str
    quote: QuoteOut


class CheckoutStatusOut(BaseModel):
    id: str
    status: str
    purpose: str
    provider: str
    subscription_id: str | None
    invoice_id: str | None
    error: str | None
    return_to: str


class UpcomingPriceChange(BaseModel):
    new_price_cents: int
    effective_at: datetime


class SubscriptionOut(BaseModel):
    id: str
    plan: PlanOut
    product: ProductBrief
    product_name: str
    provider: str
    status: str
    price_cents: int
    current_period_start: datetime | None
    current_period_end: datetime | None
    access_until: datetime | None
    grace_until: datetime | None
    cancel_at_period_end: bool
    started_at: datetime
    ended_at: datetime | None
    pending_plan: str | None = None
    upcoming_price_change: UpcomingPriceChange | None = None
    fulfillment_status: str | None = None
    access_details: dict[str, str] = Field(default_factory=dict)
    access_instructions: str | None = None
    app_url: str | None = None
    can_cancel: bool
    can_resume: bool
    can_change: bool


class PaymentMethodOut(BaseModel):
    id: str
    provider: str
    provider_label: str
    kind: str
    label: str
    status: str
    status_reason: str | None
    is_default: bool
    expires_at: datetime | None
    created_at: datetime


class AddPaymentMethodIn(BaseModel):
    provider: Literal["gocardless", "stripe"]


class InvoiceLineOut(BaseModel):
    description: str
    amount_cents: int
    kind: str
    period_start: datetime | None
    period_end: datetime | None


class InvoiceOut(BaseModel):
    id: str
    number: str
    kind: str
    status: str
    currency: str
    subtotal_cents: int
    total_cents: int
    created_at: datetime
    paid_at: datetime | None
    attempt_count: int
    next_attempt_at: datetime | None
    last_error: str | None
    payment_method: str | None
    lines: list[InvoiceLineOut]


class PayInvoiceIn(BaseModel):
    payment_method_id: str | None = None
    provider: Literal["gocardless", "stripe"] | None = None


class PaymentOut(BaseModel):
    id: str
    provider: str
    amount_cents: int
    currency: str
    status: str
    description: str | None
    charge_date: datetime | None
    created_at: datetime
    receipt_url: str | None


# --------------------------------------------------------------------------- serviços
class DeviceOut(BaseModel):
    id: str
    name: str | None
    app: str | None
    last_active: str | None


class QuickConnectIn(BaseModel):
    code: str = Field(min_length=4, max_length=12)


# --------------------------------------------------------------------------- convites
class InviteOut(BaseModel):
    id: int
    code: str
    uses: int
    max_uses: int
    expires_at: datetime | None
    disabled: bool
    note: str | None
    created_at: datetime
    link: str


class InviteCreateIn(BaseModel):
    note: str | None = Field(None, max_length=200)


class InviteEmailIn(BaseModel):
    email: EmailStr


# Resolve referências adiantadas
LoginOut.model_rebuild()


# --------------------------------------------------------------------------- carteira / jogos / catálogo
class UnlockIn(BaseModel):
    code: str = Field(min_length=3, max_length=32)


class TopupIn(BaseModel):
    amount_cents: int = Field(ge=1, le=1_000_000)
    payment_method_id: str | None = None
    provider: Literal["gocardless", "stripe"] | None = None


class MonthlyTopupIn(BaseModel):
    amount_cents: int | None = Field(None, ge=0, le=1_000_000, description="None/0 = desligar")
    skip_when_covered: bool = True
    payment_method_id: str | None = None
    provider: Literal["gocardless", "stripe"] | None = None


class WalletTxOut(BaseModel):
    id: int
    kind: str
    amount_cents: int
    balance_after_cents: int
    description: str
    created_at: datetime


class RouletteBetIn(BaseModel):
    type: Literal["straight", "split", "street", "corner", "line", "column", "dozen", "red", "black", "odd",
                  "even", "low", "high"]
    numbers: list[int] = Field(default_factory=list, max_length=6)
    amount_cents: int = Field(ge=1, le=1_000_000)


class RouletteSpinIn(BaseModel):
    bets: list[RouletteBetIn] = Field(min_length=1, max_length=60)


class BlackjackStartIn(BaseModel):
    bet_cents: int = Field(ge=1, le=1_000_000)


class BlackjackActionIn(BaseModel):
    action: Literal["hit", "stand", "double", "split", "insurance", "no_insurance"]


class GamesSettingsIn(BaseModel):
    accept: bool | None = None
    daily_loss_limit_cents: int | None = Field(None, ge=0, le=1_000_000)
    exclude_days: int | None = Field(None, ge=1, le=3650)


class ClientSeedIn(BaseModel):
    client_seed: str = Field(min_length=1, max_length=64)
