"""Dependências FastAPI: sessão, utilizador atual, IP do cliente, rate limiting, redirects seguros."""
from __future__ import annotations

import ipaddress
import re
import time
from collections import defaultdict, deque
from datetime import timedelta
from urllib.parse import urlparse

from fastapi import Depends, HTTPException, Request, Response
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from .config import get_settings
from .db import get_db, utcnow
from .models import LoginSession, OIDCRefreshToken, User
from .security import new_token, token_hash


# --------------------------------------------------------------------------- IP do cliente
def _trusted(ip: str) -> bool:
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return False
    for net in get_settings().trusted_proxies:
        try:
            if addr in ipaddress.ip_network(net, strict=False):
                return True
        except ValueError:
            continue
    return False


def _valid_ip(value: str | None) -> bool:
    try:
        ipaddress.ip_address(value or "")
    except ValueError:
        return False
    return True


def client_ip(request: Request) -> str:
    peer = request.client.host if request.client else "0.0.0.0"
    if not _trusted(peer):
        return peer
    xff = request.headers.get("x-forwarded-for")
    if xff:
        hops = [h.strip() for h in xff.split(",") if h.strip()]
        for hop in reversed(hops):
            if not _valid_ip(hop):
                # Lixo no header (não é um IP) — não confiar em nada à esquerda; também evita gravar texto
                # arbitrário (e comprido) nas colunas de IP.
                return peer
            if not _trusted(hop):
                return hop
        if hops:
            return hops[0]
    real = request.headers.get("x-real-ip")
    return real if _valid_ip(real) else peer


# --------------------------------------------------------------------------- rate limiting (em memória)
_buckets: dict[str, deque] = defaultdict(deque)


def rate_limit(key: str, limit: int, window_seconds: int) -> None:
    now = time.monotonic()
    q = _buckets[key]
    while q and q[0] <= now - window_seconds:
        q.popleft()
    if len(q) >= limit:
        retry = int(window_seconds - (now - q[0])) + 1
        raise HTTPException(429, detail=f"Demasiados pedidos. Tenta novamente dentro de {retry} s.",
                            headers={"Retry-After": str(retry)})
    q.append(now)


def reset_rate_limits() -> None:
    _buckets.clear()


# --------------------------------------------------------------------------- sessões
def request_is_https(request: Request | None) -> bool:
    """HTTPS direto, ou HTTPS no túnel/proxy à frente (X-Forwarded-Proto vindo de um proxy de confiança)."""
    if request is None:
        return True
    if request.url.scheme == "https":
        return True
    peer = request.client.host if request.client else ""
    return _trusted(peer) and request.headers.get("x-forwarded-proto", "").split(",")[0].strip() == "https"


def _request_host(request: Request | None) -> str:
    if request is None:
        return ""
    host = request.headers.get("x-forwarded-host") if request.client and _trusted(request.client.host) else None
    return (host or request.headers.get("host") or "").split(",")[0].strip().split(":")[0].lower()


def _cookie_args(request: Request | None) -> dict:
    """Cookie "Secure" só por HTTPS e domínio pai só quando o pedido vem de um host desse domínio — assim o primeiro
    acesso por http://IP:8090 (antes do túnel/domínio estarem configurados) também consegue iniciar sessão."""
    s = get_settings()
    domain = (s.cookie_domain or "").strip() or None
    if domain and request is not None:
        bare = domain.lstrip(".").lower()
        host = _request_host(request)
        if not (host == bare or host.endswith("." + bare)):
            domain = None
    return {"secure": bool(s.cookie_secure and request_is_https(request)), "domain": domain}


def set_session_cookie(response: Response, token: str, max_age: int | None, request: Request | None = None) -> None:
    s = get_settings()
    args = _cookie_args(request)
    response.set_cookie(
        s.session_cookie_name, token, max_age=max_age, httponly=True, secure=args["secure"], samesite="lax",
        domain=args["domain"], path="/",
    )


def clear_session_cookie(response: Response, request: Request | None = None) -> None:
    s = get_settings()
    response.delete_cookie(s.session_cookie_name, domain=_cookie_args(request)["domain"], path="/")


async def create_session(db: AsyncSession, request: Request, response: Response, user: User, *,
                         mfa_pending: bool = False, remember: bool = True, scope: str | None = None) -> LoginSession:
    s = get_settings()
    token = new_token(32)
    sess = LoginSession(
        id=token_hash(token),
        user_id=user.id,
        mfa_pending=mfa_pending,
        scope=scope,
        expires_at=utcnow() + (timedelta(hours=12) if scope else
                               timedelta(hours=s.session_ttl_hours) if remember else timedelta(hours=12)),
        ip=client_ip(request),
        user_agent=(request.headers.get("user-agent") or "")[:300],
    )
    db.add(sess)
    set_session_cookie(response, token, int(s.session_ttl_hours * 3600) if remember else None, request)
    return sess


async def load_session(request: Request, db: AsyncSession) -> LoginSession | None:
    s = get_settings()
    token = request.cookies.get(s.session_cookie_name)
    if not token:
        return None
    sess = await db.get(LoginSession, token_hash(token))
    now = utcnow()
    if sess is None or sess.revoked_at or sess.expires_at <= now:
        return None
    if sess.last_seen_at < now - timedelta(hours=s.session_idle_hours):
        return None
    if sess.last_seen_at < now - timedelta(minutes=5):
        sess.last_seen_at = now
        await db.commit()
    return sess


async def optional_session(request: Request, db: AsyncSession = Depends(get_db)) -> LoginSession | None:
    sess = await load_session(request, db)
    request.state.session = sess
    return sess


async def optional_user(sess: LoginSession | None = Depends(optional_session),
                        db: AsyncSession = Depends(get_db)) -> User | None:
    if sess is None or sess.mfa_pending:
        return None
    user = await db.get(User, sess.user_id)
    if user is None or not user.is_active:
        return None
    return user


SCOPED_DETAIL = ("Esta sessão foi aberta a partir do Jellyfin e só permite gerir o streaming. "
                 "Entra com a tua password para aceder ao resto.")


async def require_user_any_scope(user: User | None = Depends(optional_user)) -> User:
    """Qualquer sessão válida, incluindo as limitadas ao streaming (usar só em endpoints do streaming)."""
    if user is None:
        raise HTTPException(401, detail="Sessão inválida ou expirada.")
    return user


async def require_user(request: Request, user: User = Depends(require_user_any_scope)) -> User:
    """Sessão completa. As sessões abertas a partir do Jellyfin (scope="streaming") são recusadas."""
    sess = getattr(request.state, "session", None)
    if sess is not None and sess.scope:
        raise HTTPException(403, detail=SCOPED_DETAIL, headers={"X-TK-Session-Scope": sess.scope})
    return user


def session_scope(request: Request) -> str | None:
    sess = getattr(request.state, "session", None)
    return sess.scope if sess is not None else None


def _check_verified(user: User) -> User:
    if get_settings().require_email_verification and not user.email_verified_at:
        raise HTTPException(403, detail="Confirma o teu email primeiro.")
    return user


async def require_verified(user: User = Depends(require_user)) -> User:
    return _check_verified(user)


async def require_verified_any_scope(user: User = Depends(require_user_any_scope)) -> User:
    return _check_verified(user)


async def require_admin(user: User = Depends(require_user)) -> User:
    if not user.is_admin:
        raise HTTPException(403, detail="Apenas administradores.")
    return user


async def revoke_user_sessions(db: AsyncSession, user_id: str, except_id: str | None = None) -> int:
    rows = (await db.scalars(select(LoginSession).where(LoginSession.user_id == user_id,
                                                        LoginSession.revoked_at.is_(None)))).all()
    n = 0
    for r in rows:
        if r.id != except_id:
            r.revoked_at = utcnow()
            n += 1
    # Os refresh tokens OIDC (apps com SSO) também são "sessões": sem isto um token roubado continuava a
    # funcionar 30 dias depois de um reset de password ou de "terminar as outras sessões".
    await db.execute(update(OIDCRefreshToken).where(OIDCRefreshToken.user_id == user_id,
                                                    OIDCRefreshToken.revoked_at.is_(None))
                     .values(revoked_at=utcnow()))
    return n


# --------------------------------------------------------------------------- redirects seguros
def host_allowed(host: str | None) -> bool:
    if not host:
        return False
    s = get_settings()
    host = host.lower()
    if host == s.public_host:
        return True
    for pattern in s.allowed_redirect_hosts:
        pattern = pattern.lower()
        if pattern.startswith("*."):
            if host.endswith(pattern[1:]) or host == pattern[2:]:
                return True
        elif host == pattern:
            return True
    return False


# Os browsers removem TAB/CR/LF de qualquer ponto do URL e tratam "\\" como "/": "/\t/evil.com" e
# "/\\evil.com" viram "//evil.com". Qualquer carácter de controlo, espaço ou barra invertida → rejeitado.
_UNSAFE_URL_CHARS = re.compile(r"[\x00-\x20\x7f\\]")


def safe_redirect(url: str | None, default: str = "/app") -> str:
    """Aceita caminhos relativos do portal ou URLs absolutos para hosts autorizados."""
    if not url:
        return default
    url = url.strip()
    if _UNSAFE_URL_CHARS.search(url):
        return default
    if url.startswith("/") and not url.startswith("//"):
        return url
    parsed = urlparse(url)
    if parsed.scheme in ("http", "https") and host_allowed(parsed.hostname):
        if parsed.scheme == "http" and not get_settings().is_dev:
            return default
        return url
    return default
