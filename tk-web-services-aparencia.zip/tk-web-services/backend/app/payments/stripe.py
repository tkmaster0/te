"""Stripe: método guardado via Checkout (setup, com SCA) + PaymentIntents fora de sessão.

Não usa Stripe Billing/Subscriptions (sem a comissão extra de Billing): o portal decide quanto e quando
cobrar. Se o banco pedir autenticação numa cobrança automática, o cliente recebe um link "Pagar agora"
(Checkout em modo payment) que também atualiza o método guardado.
"""
from __future__ import annotations

import logging
from datetime import UTC, datetime

import stripe as stripe_sdk
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from ..integrations import stripe_client as sc
from ..models import Checkout, Payment, PaymentMethod, User
from .base import ChargeResult, CheckoutOutcome, NewMethod, PaymentProvider, ProviderError

log = logging.getLogger("tkportal.pay.stripe")

UNUSABLE_DECLINES = {"expired_card", "lost_card", "stolen_card", "card_not_supported", "pickup_card",
                     "restricted_card", "invalid_account", "new_account_information_available"}
BRANDS = {"visa": "Visa", "mastercard": "Mastercard", "amex": "Amex", "maestro": "Maestro"}


def _pi_result(pi: dict) -> ChargeResult:
    st = pi.get("status")
    err = pi.get("_error") or {}
    lpe = pi.get("last_payment_error") or {}
    if st == "succeeded":
        return ChargeResult("succeeded", pi.get("id"))
    if st == "processing":
        return ChargeResult("processing", pi.get("id"))
    code = err.get("decline_code") or lpe.get("decline_code") or err.get("code") or lpe.get("code")
    reason = err.get("message") or lpe.get("message") or {
        "requires_action": "O banco pediu autenticação do pagamento.",
        "requires_payment_method": "Pagamento recusado.",
        "canceled": "Pagamento cancelado.",
    }.get(st, "Pagamento recusado.")
    return ChargeResult("failed", pi.get("id"), str(reason)[:250], method_unusable=code in UNUSABLE_DECLINES)


def describe_pm(pm: dict) -> NewMethod:
    t = pm.get("type")
    exp = None
    if t == "card":
        c = pm.get("card") or {}
        label = f"Cartão {BRANDS.get(c.get('brand'), (c.get('brand') or '').title())} ••••{c.get('last4', '')}"
        if c.get("exp_year") and c.get("exp_month"):
            m, y = int(c["exp_month"]), int(c["exp_year"])
            exp = datetime(y + (m // 12), m % 12 + 1, 1, tzinfo=UTC)  # 1.º dia do mês seguinte
        kind = "card"
    elif t == "sepa_debit":
        d = pm.get("sepa_debit") or {}
        label = f"SEPA (Stripe) ••••{d.get('last4', '')}"
        kind = "sepa"
    else:
        label = f"{(t or 'Método').replace('_', ' ').title()} (Stripe)"
        kind = "other"
    customer = pm.get("customer")
    if isinstance(customer, dict):
        customer = customer.get("id")
    return NewMethod(provider_ref=pm["id"], provider_customer_id=customer, kind=kind, label=label[:120],
                     expires_at=exp)


def _net(exc: Exception) -> bool:
    return isinstance(exc, stripe_sdk.APIConnectionError | stripe_sdk.RateLimitError | stripe_sdk.APIError)


class StripeProvider(PaymentProvider):
    name = "stripe"
    label = "Stripe"
    method_label = "Cartão / Apple Pay / Google Pay"

    def configured(self) -> bool:
        return get_settings().stripe_enabled

    async def account_id(self) -> str | None:
        return await sc.account_id()

    async def _customer(self, db: AsyncSession, user: User) -> str:
        if not user.stripe_customer_id:
            user.stripe_customer_id = await sc.create_customer(email=user.email,
                                                               name=user.display_name or user.username,
                                                               user_id=user.id)
            await db.flush()
        return user.stripe_customer_id

    async def start_setup(self, db, user, checkout, *, return_url, cancel_url) -> str:
        try:
            session = await sc.create_setup_session(customer_id=await self._customer(db, user), checkout_id=checkout.id,
                                                    user_id=user.id, success_url=return_url, cancel_url=cancel_url)
        except stripe_sdk.StripeError as e:
            raise ProviderError(str(e)) from e
        checkout.provider_ref = session["id"]
        return session["url"]

    async def start_payment(self, db, user, checkout, invoice, *, return_url, cancel_url) -> str:
        try:
            session = await sc.create_payment_session(
                customer_id=await self._customer(db, user), checkout_id=checkout.id, invoice_id=invoice.id,
                user_id=user.id, amount_cents=invoice.total_cents, currency=invoice.currency,
                description=f"{get_settings().app_name} {invoice.number}", success_url=return_url, cancel_url=cancel_url)
        except stripe_sdk.StripeError as e:
            raise ProviderError(str(e)) from e
        checkout.provider_ref = session["id"]
        return session["url"]

    async def complete_checkout(self, db, user, checkout) -> CheckoutOutcome:
        try:
            session = await sc.retrieve_checkout_session(checkout.provider_ref)
            if session.get("status") == "expired":
                return CheckoutOutcome("cancelled")
            if session.get("status") != "complete":
                return CheckoutOutcome("pending")
            if session.get("mode") == "setup":
                si = session.get("setup_intent")
                si = si if isinstance(si, dict) else await sc.retrieve_setup_intent(si)
                pm_id = si.get("payment_method")
                pm_id = pm_id.get("id") if isinstance(pm_id, dict) else pm_id
                if not pm_id:
                    return CheckoutOutcome("pending")
                return CheckoutOutcome("completed", method=describe_pm(await sc.retrieve_payment_method(pm_id)))
            pi = session.get("payment_intent")
            pi = pi if isinstance(pi, dict) else await sc.retrieve_payment_intent(pi)
            method = None
            pm_id = pi.get("payment_method")
            pm_id = pm_id.get("id") if isinstance(pm_id, dict) else pm_id
            if pm_id:
                method = describe_pm(await sc.retrieve_payment_method(pm_id))
            return CheckoutOutcome("completed", method=method, charge=_pi_result(pi))
        except stripe_sdk.StripeError as e:
            raise ProviderError(str(e)) from e

    async def charge(self, user, method, invoice, attempt) -> ChargeResult:
        customer = method.provider_customer_id or user.stripe_customer_id
        try:
            pi = await sc.charge_off_session(
                customer_id=customer, payment_method_id=method.provider_ref, amount_cents=invoice.total_cents,
                currency=invoice.currency, description=f"{get_settings().app_name} {invoice.number}",
                metadata={"invoice_id": invoice.id, "portal_user_id": user.id},
                idempotency_key=f"inv-{invoice.id}-{attempt}")
        except stripe_sdk.InvalidRequestError as e:
            # ex.: método removido do cliente, cliente apagado
            return ChargeResult("failed", None, str(getattr(e, "user_message", None) or e)[:250], method_unusable=True)
        except stripe_sdk.StripeError as e:
            if _net(e):
                raise ProviderError(str(e)) from e
            return ChargeResult("failed", None, str(e)[:250])
        return _pi_result(pi)

    async def fetch_payment(self, provider_payment_id: str) -> ChargeResult:
        try:
            return _pi_result(await sc.retrieve_payment_intent(provider_payment_id))
        except stripe_sdk.StripeError as e:
            raise ProviderError(str(e)) from e

    async def release_method(self, method: PaymentMethod) -> None:
        try:
            await sc.detach_payment_method(method.provider_ref)
        except stripe_sdk.StripeError as e:
            log.info("Não foi possível desligar o método %s no Stripe: %s", method.provider_ref, e)

    async def handle_event(self, db: AsyncSession, event: dict) -> str:
        from ..services import billing

        etype = event.get("type", "")
        obj = (event.get("data") or {}).get("object") or {}

        if etype.startswith("checkout.session."):
            ref = obj.get("client_reference_id")
            checkout = await db.get(Checkout, ref) if ref else None
            if checkout is None or checkout.provider != self.name:
                return "ignored: checkout desconhecido"
            await billing.complete_checkout(db, checkout)
            return f"{etype} -> {checkout.status}"

        if etype.startswith("payment_intent."):
            pay = await db.scalar(select(Payment).where(Payment.provider == self.name,
                                                        Payment.provider_payment_id == obj.get("id")))
            if pay is None:
                return "ignored: pagamento desconhecido"
            await billing.apply_payment_result(db, pay, await self.fetch_payment(obj["id"]))
            return f"{etype}"

        if etype == "charge.dispute.created":
            pi_id = obj.get("payment_intent")
            pay = await db.scalar(select(Payment).where(Payment.provider == self.name,
                                                        Payment.provider_payment_id == pi_id)) if pi_id else None
            if pay:
                await billing.apply_payment_result(
                    db, pay, ChargeResult("failed", pi_id, "Pagamento contestado (chargeback)"), chargeback=True)
            return "dispute"

        if etype == "charge.refunded":
            pi_id = obj.get("payment_intent")
            pay = await db.scalar(select(Payment).where(Payment.provider == self.name,
                                                        Payment.provider_payment_id == pi_id)) if pi_id else None
            if pay:
                pay.status = "refunded"
            return "refund"

        if etype == "payment_method.detached":
            pm = await db.scalar(select(PaymentMethod).where(PaymentMethod.provider == self.name,
                                                             PaymentMethod.provider_ref == obj.get("id")))
            if pm:
                await billing.method_revoked(db, pm, "Método removido no Stripe")
            return "pm detached"

        if etype == "customer.deleted":
            for pm in (await db.scalars(select(PaymentMethod).where(
                    PaymentMethod.provider == self.name, PaymentMethod.provider_customer_id == obj.get("id")))).all():
                await billing.method_revoked(db, pm, "Cliente apagado no Stripe")
            u = await db.scalar(select(User).where(User.stripe_customer_id == obj.get("id")))
            if u:
                u.stripe_customer_id = None
            return "customer deleted"

        return f"ignored: {etype}"
