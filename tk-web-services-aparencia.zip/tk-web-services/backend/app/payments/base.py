"""Contrato comum dos fornecedores de pagamento.

O portal é o motor de faturação: um fornecedor só precisa de saber
  1) guardar um método de pagamento do cliente (mandato SEPA, cartão, ...),
  2) cobrar um montante a esse método,
  3) permitir "pagar agora" uma cobrança em atraso (e guardar o método em simultâneo),
  4) traduzir os seus webhooks em alterações de estado de pagamentos/métodos.

Para adicionar um fornecedor novo: implementar esta classe e registá-la em `registry.PROVIDERS`.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from sqlalchemy.ext.asyncio import AsyncSession

    from ..models import Checkout, Invoice, PaymentMethod, User


class ProviderError(Exception):
    """Erro de comunicação com o fornecedor (rede, 5xx, credenciais) — a operação pode ser repetida."""


@dataclass
class ChargeResult:
    # succeeded = pago já | processing = submetido, resultado chega por webhook | failed = recusado
    status: str
    provider_payment_id: str | None = None
    failure_reason: str | None = None
    # True quando o método em si deixou de servir (mandato cancelado, cartão removido) → tentar outro método
    method_unusable: bool = False


@dataclass
class NewMethod:
    provider_ref: str
    provider_customer_id: str | None
    kind: str
    label: str
    status: str = "active"
    expires_at: datetime | None = None


@dataclass
class CheckoutOutcome:
    """Resultado de concluir um fluxo alojado (guardar método e/ou pagar)."""

    state: str  # pending | completed | cancelled
    method: NewMethod | None = None
    charge: ChargeResult | None = None


class PaymentProvider:
    name: str = ""
    label: str = ""          # nome mostrado ao cliente
    method_label: str = ""   # ex.: "Débito direto SEPA"

    def configured(self) -> bool:
        raise NotImplementedError

    async def account_id(self) -> str | None:
        raise NotImplementedError

    async def start_setup(self, db: AsyncSession, user: User, checkout: Checkout, *, return_url: str,
                          cancel_url: str) -> str:
        """Devolve o URL da página alojada onde o cliente autoriza o método."""
        raise NotImplementedError

    async def start_payment(self, db: AsyncSession, user: User, checkout: Checkout, invoice: Invoice, *,
                            return_url: str, cancel_url: str) -> str:
        raise NotImplementedError

    async def complete_checkout(self, db: AsyncSession, user: User, checkout: Checkout) -> CheckoutOutcome:
        raise NotImplementedError

    async def charge(self, user: User, method: PaymentMethod, invoice: Invoice, attempt: int) -> ChargeResult:
        raise NotImplementedError

    async def fetch_payment(self, provider_payment_id: str) -> ChargeResult:
        """Estado atual de um pagamento (reconciliação caso um webhook se perca)."""
        raise NotImplementedError

    async def handle_event(self, db: AsyncSession, event: dict) -> str:
        raise NotImplementedError

    async def release_method(self, method: PaymentMethod) -> None:
        """Opcional: desliga o método no fornecedor quando o cliente o remove."""
        return
