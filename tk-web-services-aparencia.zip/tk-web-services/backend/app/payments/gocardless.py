"""GoCardless: mandato SEPA guardado + pagamentos únicos (um por cobrança consolidada)."""
from __future__ import annotations

import logging

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from ..integrations.gocardless import GoCardlessClient, GoCardlessError
from ..models import Checkout, Payment, PaymentMethod, User
from .base import ChargeResult, CheckoutOutcome, NewMethod, PaymentProvider, ProviderError

log = logging.getLogger("tkportal.pay.gocardless")

PROCESSING = {"pending_customer_approval", "pending_submission", "submitted"}
SUCCEEDED = {"confirmed", "paid_out"}
FAILED = {"failed", "cancelled", "customer_approval_denied", "charged_back"}
MANDATE_USABLE = {"active", "submitted"}
MANDATE_PENDING = {"pending_customer_approval", "pending_submission"}
MANDATE_DEAD = {"cancelled", "failed", "expired", "blocked", "consumed", "suspended_by_payer"}


def map_payment_status(status: str | None) -> str:
    if status in SUCCEEDED:
        return "succeeded"
    if status in FAILED:
        return "failed"
    return "processing"


def _wrap(exc: GoCardlessError) -> Exception:
    if exc.status is None or exc.status >= 500 or exc.status == 429:
        return ProviderError(str(exc))
    return exc


class GoCardlessProvider(PaymentProvider):
    name = "gocardless"
    label = "GoCardless"
    method_label = "Débito direto SEPA"

    def configured(self) -> bool:
        return get_settings().gocardless_enabled

    def _client(self) -> GoCardlessClient:
        return GoCardlessClient()

    async def account_id(self) -> str | None:
        return await self._client().creditor_id()

    async def _customer_id(self, db: AsyncSession, user: User) -> str | None:
        pm = await db.scalar(select(PaymentMethod).where(PaymentMethod.user_id == user.id,
                                                         PaymentMethod.provider == self.name,
                                                         PaymentMethod.provider_customer_id.is_not(None))
                             .order_by(PaymentMethod.created_at.desc()).limit(1))
        return (pm.provider_customer_id if pm else None) or user.gocardless_customer_id

    async def start_setup(self, db, user, checkout, *, return_url, cancel_url) -> str:
        s = get_settings()
        gc = self._client()
        try:
            br = await gc.create_billing_request(
                currency="EUR", scheme=s.gocardless_scheme,
                metadata={"portal_user_id": user.id, "checkout_id": checkout.id},
                customer_id=await self._customer_id(db, user), idempotency_key=f"br-{checkout.id}")
            flow = await gc.create_billing_request_flow(billing_request_id=br["id"], redirect_uri=return_url,
                                                        exit_uri=cancel_url, email=user.email)
        except GoCardlessError as e:
            raise _wrap(e) from e
        checkout.provider_ref = br["id"]
        return flow["authorisation_url"]

    async def start_payment(self, db, user, checkout, invoice, *, return_url, cancel_url) -> str:
        s = get_settings()
        gc = self._client()
        try:
            br = await gc.create_payment_billing_request(
                amount_cents=invoice.total_cents, currency=invoice.currency, description=f"{get_settings().app_name} {invoice.number}",
                metadata={"portal_user_id": user.id, "checkout_id": checkout.id, "invoice_id": invoice.id},
                scheme=s.gocardless_scheme, customer_id=await self._customer_id(db, user),
                idempotency_key=f"brpay-{checkout.id}")
            flow = await gc.create_billing_request_flow(billing_request_id=br["id"], redirect_uri=return_url,
                                                        exit_uri=cancel_url, email=user.email)
        except GoCardlessError as e:
            raise _wrap(e) from e
        checkout.provider_ref = br["id"]
        return flow["authorisation_url"]

    async def describe_mandate(self, mandate: dict) -> NewMethod:
        gc = self._client()
        label = "Débito direto SEPA"
        acct_id = (mandate.get("links") or {}).get("customer_bank_account")
        if acct_id:
            try:
                acct = await gc.get_bank_account(acct_id)
                bank = acct.get("bank_name") or "Conta"
                label = f"Débito direto · {bank} ••••{acct.get('account_number_ending') or ''}".strip()
            except GoCardlessError:
                pass
        st = mandate.get("status")
        return NewMethod(
            provider_ref=mandate["id"], provider_customer_id=(mandate.get("links") or {}).get("customer"),
            kind="sepa", label=label[:120],
            status="active" if st in MANDATE_USABLE else ("pending" if st in MANDATE_PENDING else "revoked"),
        )

    async def complete_checkout(self, db, user, checkout) -> CheckoutOutcome:
        gc = self._client()
        try:
            br = await gc.get_billing_request(checkout.provider_ref)
        except GoCardlessError as e:
            raise _wrap(e) from e
        status = br.get("status")
        if status in ("cancelled", "failed"):
            return CheckoutOutcome("cancelled")
        if status != "fulfilled":
            return CheckoutOutcome("pending")
        links = br.get("links") or {}
        method = None
        if links.get("mandate_request_mandate"):
            try:
                mandate = await gc.get_mandate(links["mandate_request_mandate"])
                method = await self.describe_mandate(mandate)
            except GoCardlessError as e:
                raise _wrap(e) from e
        charge = None
        if links.get("payment_request_payment"):
            try:
                p = await gc.get_payment(links["payment_request_payment"])
            except GoCardlessError as e:
                raise _wrap(e) from e
            charge = ChargeResult(map_payment_status(p.get("status")), p["id"])
        return CheckoutOutcome("completed", method=method, charge=charge)

    async def charge(self, user, method, invoice, attempt) -> ChargeResult:
        gc = self._client()
        try:
            p = await gc.create_payment(
                mandate_id=method.provider_ref, amount_cents=invoice.total_cents, currency=invoice.currency,
                description=f"{get_settings().app_name} {invoice.number}",
                metadata={"invoice_id": invoice.id, "portal_user_id": user.id},
                idempotency_key=f"inv-{invoice.id}-{attempt}",
            )
        except GoCardlessError as e:
            if e.status is not None and 400 <= e.status < 500 and e.status != 429:
                body = e.body.get("error") or {}
                codes = {x.get("reason") for x in body.get("errors") or []}
                unusable = bool(codes & {"mandate_is_inactive", "mandate_not_active", "invalid_state"}) \
                    or "mandate" in str(e).lower()
                return ChargeResult("failed", None, (body.get("message") or str(e))[:250], method_unusable=unusable)
            raise ProviderError(str(e)) from e
        return ChargeResult(map_payment_status(p.get("status")), p["id"])

    async def fetch_payment(self, provider_payment_id: str) -> ChargeResult:
        try:
            p = await self._client().get_payment(provider_payment_id)
        except GoCardlessError as e:
            raise _wrap(e) from e
        return ChargeResult(map_payment_status(p.get("status")), p["id"])

    @staticmethod
    async def _legacy_sub(db: AsyncSession, gc_subscription_id: str | None):
        if not gc_subscription_id:
            return None
        from ..models import Subscription

        return await db.scalar(select(Subscription).where(Subscription.provider == "gocardless",
                                                          Subscription.provider_subscription_id == gc_subscription_id))

    async def handle_event(self, db: AsyncSession, event: dict) -> str:
        from ..services import billing

        rtype = event.get("resource_type")
        action = event.get("action")
        links = event.get("links") or {}
        details = event.get("details") or {}

        if rtype == "payments":
            pay = await db.scalar(select(Payment).where(Payment.provider == self.name,
                                                        Payment.provider_payment_id == links.get("payment")))
            legacy_sub = await self._legacy_sub(db, links.get("subscription"))
            if legacy_sub is not None and (pay is None or pay.invoice_id is None):
                # Pagamento da subscrição antiga, cobrado pela própria GoCardless (cliente ainda no modo "manter").
                from ..services import legacy

                return await legacy.on_payment_event(db, legacy_sub, links["payment"], action or "", details)
            if pay is None:
                return "ignored: pagamento desconhecido"
            # Estado lido da API (não do evento): os eventos podem chegar fora de ordem.
            result = await self.fetch_payment(pay.provider_payment_id)
            reason = details.get("description") if result.status == "failed" else None
            if action in ("charged_back", "late_failure_settled", "chargeback_settled"):
                result = ChargeResult("failed", pay.provider_payment_id, "Pagamento estornado pelo banco")
                await billing.apply_payment_result(db, pay, result, chargeback=True)
            elif action == "failed" and details.get("will_attempt_retry") and result.status != "succeeded":
                # Success+ / nova tentativa automática da GoCardless: ainda não é a falha final — espera-se pela
                # desistência do fornecedor antes de pôr o serviço em risco.
                await billing.provider_retrying(db, pay, details.get("description"))
                return "payment failed -> retry agendado pela GoCardless"
            else:
                await billing.apply_payment_result(db, pay, ChargeResult(result.status, pay.provider_payment_id,
                                                                         reason))
            return f"payment {action} -> {result.status}"

        if rtype == "subscriptions":
            legacy_sub = await self._legacy_sub(db, links.get("subscription"))
            if legacy_sub is None:
                return "ignored: subscrição desconhecida"
            from ..services import legacy

            return await legacy.on_subscription_event(db, legacy_sub, action or "")

        if rtype == "billing_requests":
            checkout = await db.scalar(select(Checkout).where(Checkout.provider == self.name,
                                                              Checkout.provider_ref == links.get("billing_request")))
            if checkout is None:
                return "ignored: checkout desconhecido"
            await billing.complete_checkout(db, checkout)
            return f"billing_request {action} -> {checkout.status}"

        if rtype == "mandates":
            pm = await db.scalar(select(PaymentMethod).where(PaymentMethod.provider == self.name,
                                                             PaymentMethod.provider_ref == links.get("mandate")))
            if pm is None:
                return "ignored: mandato desconhecido"
            if action == "replaced" and links.get("new_mandate"):
                pm.provider_ref = links["new_mandate"]
            elif action in ("active", "submitted", "reinstated"):
                # Um método que o cliente removeu não volta a ficar ativo por um evento do mandato.
                if pm.status == "pending" or (pm.status == "revoked" and pm.status_reason != billing.REMOVED_REASON):
                    pm.status = "active"
                    pm.status_reason = None
            elif action in MANDATE_DEAD:
                await billing.method_revoked(db, pm, details.get("description") or f"Mandato {action}")
            return f"mandate {action}"

        return f"ignored: {rtype}.{action}"
