"""Registo dos fornecedores de pagamento e do seu estado.

Estado efetivo de cada fornecedor:
  * configured  — tem credenciais no .env
  * enabled     — configurado e não desligado no painel (Admin → Fornecedores)
  * accept_new  — aceita novos métodos de pagamento (podes deixar de aceitar novos clientes num fornecedor
                   mas continuar a cobrar quem já lá está, para uma migração suave)

Desligar um fornecedor nunca parte o código: os métodos desse fornecedor ficam "inutilizáveis", os
clientes afetados são avisados e o motor de faturação tenta outros métodos que tenham.
"""
from __future__ import annotations

import time

from sqlalchemy.ext.asyncio import AsyncSession

from ..models import SiteSetting
from .base import PaymentProvider
from .gocardless import GoCardlessProvider
from .stripe import StripeProvider

PROVIDERS: dict[str, PaymentProvider] = {
    "gocardless": GoCardlessProvider(),
    "stripe": StripeProvider(),
}
# Ordem de preferência quando o cliente não escolhe (SEPA primeiro: comissões mais baixas)
PREFERENCE = ["gocardless", "stripe"]

SETTING_KEY = "payment_providers"

_account_cache: dict[str, tuple[float, str | None]] = {}


def get(name: str) -> PaymentProvider | None:
    return PROVIDERS.get(name)


async def overrides(db: AsyncSession) -> dict:
    row = await db.get(SiteSetting, SETTING_KEY)
    return dict(row.value or {}) if row and isinstance(row.value, dict) else {}


async def state(db: AsyncSession) -> dict[str, dict]:
    ov = await overrides(db)
    out = {}
    for name in PREFERENCE:
        p = PROVIDERS[name]
        cfg = p.configured()
        o = ov.get(name) or {}
        enabled = cfg and o.get("enabled", True)
        out[name] = {
            "name": name,
            "label": p.label,
            "method_label": p.method_label,
            "configured": cfg,
            "enabled": bool(enabled),
            "accept_new": bool(enabled and o.get("accept_new", True)),
        }
    return out


async def is_enabled(db: AsyncSession, name: str) -> bool:
    return (await state(db)).get(name, {}).get("enabled", False)


async def available_for_new(db: AsyncSession) -> list[str]:
    st = await state(db)
    return [n for n in PREFERENCE if st[n]["accept_new"]]


async def set_override(db: AsyncSession, name: str, *, enabled: bool | None = None, accept_new: bool | None = None
                       ) -> None:
    row = await db.get(SiteSetting, SETTING_KEY)
    value = dict(row.value or {}) if row and isinstance(row.value, dict) else {}
    cur = dict(value.get(name) or {})
    if enabled is not None:
        cur["enabled"] = enabled
    if accept_new is not None:
        cur["accept_new"] = accept_new
    value[name] = cur
    if row is None:
        db.add(SiteSetting(key=SETTING_KEY, value=value))
    else:
        row.value = value


async def account_id(name: str, *, max_age: float = 600) -> str | None:
    """Identificador da conta atualmente configurada (cache em memória). None se não for possível saber."""
    p = PROVIDERS.get(name)
    if p is None or not p.configured():
        return None
    hit = _account_cache.get(name)
    if hit and time.monotonic() - hit[0] < max_age:
        return hit[1]
    try:
        acct = await p.account_id()
    except Exception:  # noqa: BLE001 — sem rede não sabemos; não marcar nada como inválido por isso
        return hit[1] if hit else None
    _account_cache[name] = (time.monotonic(), acct)
    return acct


def clear_cache() -> None:
    _account_cache.clear()
