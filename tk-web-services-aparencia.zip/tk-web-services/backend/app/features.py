"""Definição dos direitos (features) que um plano concede e como se combinam.

Um utilizador pode ter várias subscrições/ofertas ativas (produtos diferentes). Os direitos
efetivos são a combinação (merge) de todos os planos ativos.
"""
from __future__ import annotations

from pydantic import BaseModel, Field, model_validator


class JellyfinFeature(BaseModel):
    enabled: bool = False
    all_libraries: bool = True
    libraries: list[str] = Field(default_factory=list, description="IDs de bibliotecas (se all_libraries=False)")
    max_streams: int = Field(0, ge=0, description="0 = ilimitado")
    live_tv: bool = False
    downloads: bool = True
    remote_bitrate_mbps: int = Field(0, ge=0, description="0 = sem limite")

    @model_validator(mode="after")
    def _libraries_required(self):
        if self.enabled and not self.all_libraries and not self.libraries:
            raise ValueError("Escolhe pelo menos uma biblioteca ou ativa 'todas as bibliotecas'.")
        return self


class SeerrFeature(BaseModel):
    enabled: bool = False
    movie_quota: int | None = Field(None, description="None = limite global do Seerr")
    movie_quota_days: int | None = None
    tv_quota: int | None = None
    tv_quota_days: int | None = None


class IptvFeature(BaseModel):
    enabled: bool = False
    stream_limit: int = Field(1, ge=0, description="Ligações simultâneas no Dispatcharr (0 = ilimitado)")
    channel_profiles: list[int] = Field(default_factory=list, description="IDs de channel profiles do Dispatcharr")


class PlanFeatures(BaseModel):
    jellyfin: JellyfinFeature = Field(default_factory=JellyfinFeature)
    seerr: SeerrFeature = Field(default_factory=SeerrFeature)
    iptv: IptvFeature = Field(default_factory=IptvFeature)
    groups: list[str] = Field(default_factory=list, description="Grupos extra expostos via OIDC / forward-auth")


def _max_or_unlimited(values: list[int]) -> int:
    """Combina limites onde 0 significa 'ilimitado'."""
    if not values:
        return 0
    if any(v == 0 for v in values):
        return 0
    return max(values)


def _max_quota(values: list[int | None]) -> int | None:
    if not values:
        return None
    if any(v is None for v in values):
        return None
    return max(v for v in values if v is not None)


def merge_features(items: list[PlanFeatures]) -> PlanFeatures:
    out = PlanFeatures()
    jf = [f.jellyfin for f in items if f.jellyfin.enabled]
    if jf:
        out.jellyfin = JellyfinFeature(
            enabled=True,
            all_libraries=any(j.all_libraries for j in jf),
            libraries=sorted({lib for j in jf for lib in j.libraries}),
            max_streams=_max_or_unlimited([j.max_streams for j in jf]),
            live_tv=any(j.live_tv for j in jf),
            downloads=any(j.downloads for j in jf),
            remote_bitrate_mbps=_max_or_unlimited([j.remote_bitrate_mbps for j in jf]),
        )
    se = [f.seerr for f in items if f.seerr.enabled]
    if se:
        out.seerr = SeerrFeature(
            enabled=True,
            movie_quota=_max_quota([s.movie_quota for s in se]),
            movie_quota_days=_max_quota([s.movie_quota_days for s in se]),
            tv_quota=_max_quota([s.tv_quota for s in se]),
            tv_quota_days=_max_quota([s.tv_quota_days for s in se]),
        )
    ip = [f.iptv for f in items if f.iptv.enabled]
    if ip:
        out.iptv = IptvFeature(
            enabled=True,
            stream_limit=_max_or_unlimited([i.stream_limit for i in ip]),
            channel_profiles=sorted({p for i in ip for p in i.channel_profiles}),
        )
    out.groups = sorted({g for f in items for g in f.groups})
    return out


def feature_flags(f: PlanFeatures) -> list[str]:
    flags = []
    if f.jellyfin.enabled:
        flags.append("jellyfin")
        if f.jellyfin.live_tv:
            flags.append("livetv")
    if f.seerr.enabled:
        flags.append("seerr")
    if f.iptv.enabled:
        flags.append("iptv")
    return flags
