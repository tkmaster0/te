"""Primitivas de segurança: hashing de passwords, tokens, cifra em repouso e TOTP."""
from __future__ import annotations

import base64
import hashlib
import hmac
import re
import secrets
import string

import pyotp
from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError, VerifyMismatchError
from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

from .config import get_settings

_ph = PasswordHasher()  # argon2id com parâmetros por omissão (RFC 9106 low-memory)

USERNAME_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{2,31}$")
RESERVED_USERNAMES = {"admin", "administrator", "root", "system", "jellyfin", "support", "suporte", "tkflix"}


# --------------------------------------------------------------------------- passwords
def hash_password(password: str) -> str:
    return _ph.hash(password)


def _verify_werkzeug(stored: str, password: str) -> bool:
    """Compatibilidade com hashes do site antigo (werkzeug `pbkdf2:sha256:N$salt$hash` / `scrypt:...`)."""
    try:
        method, salt, expected = stored.split("$", 2)
    except ValueError:
        return False
    parts = method.split(":")
    if parts[0] == "pbkdf2":
        algo = parts[1] if len(parts) > 1 else "sha256"
        iterations = int(parts[2]) if len(parts) > 2 else 600000
        dk = hashlib.pbkdf2_hmac(algo, password.encode(), salt.encode(), iterations)
        return hmac.compare_digest(dk.hex(), expected)
    if parts[0] == "scrypt":
        n, r, p = (int(x) for x in parts[1:4]) if len(parts) >= 4 else (2**15, 8, 1)
        dk = hashlib.scrypt(password.encode(), salt=salt.encode(), n=n, r=r, p=p, maxmem=132 * 1024 * 1024)
        return hmac.compare_digest(dk.hex(), expected)
    return False


def verify_password(stored: str, password: str) -> tuple[bool, bool]:
    """Devolve (válida, precisa_rehash)."""
    if stored.startswith("$argon2"):
        try:
            _ph.verify(stored, password)
        except (VerifyMismatchError, VerificationError, InvalidHashError):
            return False, False
        return True, _ph.check_needs_rehash(stored)
    if stored.startswith(("pbkdf2:", "scrypt:")):
        ok = _verify_werkzeug(stored, password)
        return ok, ok
    return False, False


def password_problems(password: str, *, username: str | None = None, email: str | None = None) -> list[str]:
    problems: list[str] = []
    if len(password) < 8:
        problems.append("A password tem de ter pelo menos 8 caracteres.")
    if len(password) > 256:
        problems.append("A password é demasiado longa.")
    lowered = password.lower()
    if username and username.lower() in lowered:
        problems.append("A password não pode conter o username.")
    if email and email.split("@")[0].lower() in lowered and len(email.split("@")[0]) >= 4:
        problems.append("A password não pode conter o email.")
    if lowered in {"12345678", "password", "password1", "qwertyui", "tkflix123", "123456789", "1234567890"}:
        problems.append("Essa password é demasiado comum.")
    return problems


# --------------------------------------------------------------------------- tokens
def new_token(nbytes: int = 32) -> str:
    return secrets.token_urlsafe(nbytes)


def token_hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def new_invite_code() -> str:
    alphabet = string.ascii_uppercase.replace("O", "").replace("I", "") + "23456789"
    raw = "".join(secrets.choice(alphabet) for _ in range(8))
    return f"TK-{raw[:4]}-{raw[4:]}"


def new_service_password(length: int = 16) -> str:
    """Password compatível com Dispatcharr/XC (letras, números, . _ -)."""
    alphabet = string.ascii_letters + string.digits
    return "".join(secrets.choice(alphabet) for _ in range(length))


# Palavras curtas e fáceis de escrever num comando de TV (sem acentos nem letras parecidas com números).
_WORDS = (
    "agua", "alma", "amor", "ano", "arco", "asa", "azul", "bala", "barco", "bela", "bico", "boa", "bola", "bom",
    "cabo", "cafe", "cais", "cama", "campo", "canto", "casa", "cedo", "ceu", "chave", "cinco", "cor", "costa",
    "dado", "dia", "doce", "dois", "dona", "duna", "eixo", "fada", "faro", "festa", "figo", "filme", "fino",
    "flor", "fogo", "folha", "forte", "fruta", "gato", "gelo", "grua", "hora", "ilha", "jogo", "lago", "lapa",
    "leao", "leve", "lima", "lobo", "lua", "luz", "mae", "mar", "massa", "mel", "mesa", "mina", "mola", "monte",
    "mundo", "nata", "neve", "ninho", "noite", "nota", "nuvem", "onda", "ouro", "pai", "palco", "pao", "papel",
    "pato", "paz", "pedra", "peixe", "pena", "pera", "pinho", "porto", "praia", "prata", "quinta", "rato", "rede",
    "rei", "rio", "roda", "rosa", "rua", "sal", "salto", "selo", "serra", "sino", "sol", "sopa", "tarde", "teia",
    "terra", "tigre", "torre", "trigo", "uva", "vaca", "vela", "verde", "vila", "vinho", "voo", "zebra",
)


def friendly_password() -> str:
    """Password simples de ler e escrever (ex.: "lua-pato-4821") — para a TV/IPTV, onde se escreve com o comando."""
    a, b = secrets.choice(_WORDS), secrets.choice(_WORDS)
    while b == a:
        b = secrets.choice(_WORDS)
    return f"{a}-{b}-{secrets.randbelow(9000) + 1000}"


XC_PASSWORD_RE = re.compile(r"^[A-Za-z0-9._-]{6,32}$")


def constant_time_eq(a: str, b: str) -> bool:
    return hmac.compare_digest(a.encode(), b.encode())


# --------------------------------------------------------------------------- cifra em repouso
def _derive(info: bytes, length: int = 32) -> bytes:
    return HKDF(algorithm=hashes.SHA256(), length=length, salt=b"tkportal", info=info).derive(
        get_settings().secret_key.encode()
    )


def _fernet() -> Fernet:
    return Fernet(base64.urlsafe_b64encode(_derive(b"fernet-v1")))


def encrypt(value: str) -> str:
    return _fernet().encrypt(value.encode()).decode()


def decrypt(value: str | None) -> str | None:
    if not value:
        return None
    try:
        return _fernet().decrypt(value.encode()).decode()
    except InvalidToken:
        return None


def hmac_sign(value: str, purpose: str) -> str:
    key = _derive(b"hmac-" + purpose.encode())
    return hmac.new(key, value.encode(), hashlib.sha256).hexdigest()


# --------------------------------------------------------------------------- TOTP
def new_totp_secret() -> str:
    return pyotp.random_base32()


def totp_uri(secret: str, account: str) -> str:
    return pyotp.TOTP(secret).provisioning_uri(name=account, issuer_name=get_settings().app_name)


def verify_totp(secret: str, code: str) -> bool:
    code = re.sub(r"\s", "", code or "")
    if not code.isdigit() or len(code) != 6:
        return False
    return pyotp.TOTP(secret).verify(code, valid_window=1)


def new_recovery_codes(n: int = 10) -> list[str]:
    alphabet = string.ascii_lowercase + string.digits
    return ["".join(secrets.choice(alphabet) for _ in range(5)) + "-" + "".join(secrets.choice(alphabet) for _ in range(5)) for _ in range(n)]


def hash_recovery_code(code: str) -> str:
    return hmac_sign(code.strip().lower(), "recovery")
