"""Dados iniciais: o produto TKFLIX com os 4 planos do site antigo."""
from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from .features import IptvFeature, JellyfinFeature, PlanFeatures, SeerrFeature
from .models import Plan, Product

BASE = PlanFeatures(
    jellyfin=JellyfinFeature(enabled=True, all_libraries=True, max_streams=2, live_tv=False),
    seerr=SeerrFeature(enabled=True, movie_quota=10, movie_quota_days=7, tv_quota=5, tv_quota_days=7),
)
TV = PlanFeatures(
    jellyfin=JellyfinFeature(enabled=True, all_libraries=True, max_streams=2, live_tv=True),
    seerr=SeerrFeature(enabled=True, movie_quota=10, movie_quota_days=7, tv_quota=5, tv_quota_days=7),
    iptv=IptvFeature(enabled=True, stream_limit=1),
)

PLANS = [
    ("tkflix-mensal", "TKFLIX", 500, "month", BASE,
     ["Filmes e séries em Full HD / 4K", "2 ecrãs em simultâneo", "Pedidos de conteúdo", "Legendas PT e EN"]),
    ("tkflix-anual", "TKFLIX Anual", 5000, "year", BASE,
     ["Tudo do plano mensal", "2 meses grátis", "Pagamento único anual"]),
    ("tkflix-tv-mensal", "TKFLIX + TV", 750, "month", TV,
     ["Tudo do TKFLIX", "Canais de TV em direto no Jellyfin", "Credenciais IPTV para apps externas"]),
    ("tkflix-tv-anual", "TKFLIX + TV Anual", 7500, "year", TV,
     ["Tudo do TKFLIX + TV", "2 meses grátis", "Pagamento único anual"]),
]


async def seed_defaults(db: AsyncSession) -> bool:
    if await db.scalar(select(Product.id).limit(1)):
        return False
    product = Product(code="tkflix", name="TKFLIX Streaming",
                      description="Filmes, séries e TV — no teu Jellyfin, em qualquer ecrã.", kind="streaming",
                      fulfillment="streaming", jellyfin_managed=True, bonus_eligible=True, icon="tv",
                      sort_order=0, requires_invite=True, locked_name="TK CDN",
                      locked_description="Beta testing fechado")
    db.add(product)
    await db.flush()
    for i, (code, name, price, unit, feats, highlights) in enumerate(PLANS):
        db.add(Plan(product_id=product.id, code=code, name=name, price_cents=price, interval_unit=unit,
                    features=feats.model_dump(), highlights=highlights, sort_order=i))
    await ensure_tkgpt(db)
    await db.commit()
    return True


async def ensure_tkgpt(db: AsyncSession) -> Product:
    """TKGPT (LibreChat): acesso pela conta TKWS (SSO, só com a subscrição ativa) e 2,5 milhões de tokens por mês.
    O plano fica INATIVO até o admin definir o preço em Admin → Produtos & planos."""
    from .config import get_settings

    s = get_settings()
    code = s.librechat_product_code or "tkgpt"
    p = await db.scalar(select(Product).where(Product.code == code))
    if p is not None:
        return p
    p = Product(code=code, name="TKGPT", kind="ia", fulfillment="none", icon="bot", bonus_eligible=False,
                description="Assistente de inteligência artificial com vários modelos, no browser e no telemóvel.",
                access_instructions="Abre o TKGPT e entra com a tua conta TKWS (\"Entrar com TK Web Services\").",
                app_url=s.librechat_url, sort_order=10)
    db.add(p)
    await db.flush()
    db.add(Plan(product_id=p.id, code=f"{code}-mensal", name="TKGPT", price_cents=0, interval_unit="month",
                features={}, is_active=False, sort_order=0,
                highlights=["2,5 milhões de tokens por mês", "Vários modelos de IA", "Entra com a conta TKWS"]))
    return p


async def ensure_test_admin(db: AsyncSession) -> bool:
    """Conta de administrador pré-carregada (TEST_ADMIN_*). Só é criada se ainda não existir nenhum utilizador com
    esse username ou email — nunca repõe a password nem mexe numa conta existente."""
    from sqlalchemy import func

    from .config import get_settings
    from .db import utcnow
    from .models import User
    from .security import hash_password

    s = get_settings()
    if not (s.test_admin_enabled and s.test_admin_username and s.test_admin_password and s.test_admin_email):
        return False
    username, email = s.test_admin_username.strip().lower(), s.test_admin_email.strip().lower()
    if await db.scalar(select(User.id).where((func.lower(User.username) == username) |
                                             (func.lower(User.email) == email)).limit(1)):
        return False
    now = utcnow()
    db.add(User(email=email, username=username, display_name=username, password_hash=hash_password(s.test_admin_password),
                is_admin=True, email_verified_at=now, password_changed_at=now, billing_mode="legacy",
                jellyfin_password_login=True))
    await db.commit()
    return True
