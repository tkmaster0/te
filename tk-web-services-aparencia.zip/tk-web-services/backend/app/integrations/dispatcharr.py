"""Cliente mínimo do Dispatcharr (utilizadores XC para IPTV). Header X-API-Key.

Modelo do Dispatcharr: um utilizador com `user_level=0` (streamer) e `custom_properties.xc_password`
autentica-se na API Xtream Codes (`/player_api.php`, `/get.php`, `/xmltv.php`) com username + xc_password.
Para desativar, removemos `xc_password` (PATCH com valor null → o Dispatcharr apaga a chave).
"""
from __future__ import annotations

from typing import Any

import httpx

from ..config import get_settings
from .upstream import headers_for
from ..security import new_service_password


class DispatcharrError(Exception):
    def __init__(self, message: str, status: int | None = None):
        super().__init__(message)
        self.status = status


class DispatcharrClient:
    def __init__(self, base_url: str | None = None, api_key: str | None = None, timeout: float = 15.0):
        s = get_settings()
        self.base_url = (base_url or s.dispatcharr_url or "").rstrip("/")
        self.api_key = api_key or s.dispatcharr_api_key or ""
        self.timeout = timeout

    async def _req(self, method: str, path: str, **kw) -> httpx.Response:
        if not self.base_url:
            raise DispatcharrError("Dispatcharr não configurado")
        try:
            async with httpx.AsyncClient(base_url=f"{self.base_url}/api/accounts", timeout=self.timeout) as c:
                r = await c.request(method, path, headers={**headers_for(self.base_url), "X-API-Key": self.api_key}, **kw)
        except httpx.HTTPError as exc:
            raise DispatcharrError(f"Dispatcharr inacessível: {exc}") from exc
        if r.status_code >= 400:
            raise DispatcharrError(f"Dispatcharr {method} {path} -> {r.status_code}: {r.text[:300]}", r.status_code)
        return r

    async def list_users(self) -> list[dict[str, Any]]:
        data = (await self._req("GET", "/users/")).json()
        return data.get("results", data) if isinstance(data, dict) else data

    async def find_user(self, username: str) -> dict[str, Any] | None:
        for u in await self.list_users():
            if str(u.get("username", "")).lower() == username.lower():
                return u
        return None

    async def create_user(self, *, username: str, email: str, xc_password: str, stream_limit: int,
                          channel_profiles: list[int]) -> dict[str, Any]:
        body = {
            "username": username,
            "email": email,
            "user_level": 0,
            "password": new_service_password(32),  # password da UI do Dispatcharr (não é usada pelos clientes XC)
            "channel_profiles": channel_profiles,
            "stream_limit": stream_limit,
            "custom_properties": {"xc_password": xc_password},
        }
        return (await self._req("POST", "/users/", json=body)).json()

    async def update_user(self, user_id: int, **fields) -> dict[str, Any]:
        return (await self._req("PATCH", f"/users/{user_id}/", json=fields)).json()

    async def enable(self, user_id: int, *, xc_password: str, stream_limit: int, channel_profiles: list[int]) -> None:
        await self.update_user(
            user_id,
            custom_properties={"xc_password": xc_password},
            stream_limit=stream_limit,
            channel_profiles=channel_profiles,
        )

    async def delete_user(self, user_id: int) -> None:
        await self._req("DELETE", f"/users/{user_id}/")

    async def disable(self, user_id: int) -> None:
        await self.update_user(user_id, custom_properties={"xc_password": None})
