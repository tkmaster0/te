"""Cliente mínimo do Bazarr (API em /api, header X-API-KEY).

O Bazarr identifica filmes pelo `radarrId` e episódios pelo `sonarrEpisodeId`. Para chegar lá a partir de um item
do Jellyfin cruzamos IMDb/TVDB e, em último caso, o nome do ficheiro (os caminhos podem diferir entre
contentores, o nome do ficheiro não).
"""
from __future__ import annotations

import time
from pathlib import PurePosixPath, PureWindowsPath
from typing import Any

import httpx

from ..config import get_settings
from .upstream import headers_for

_cache: dict[str, tuple[float, Any]] = {}
CACHE_SECONDS = 300


class BazarrError(Exception):
    def __init__(self, message: str, status: int | None = None):
        super().__init__(message)
        self.status = status


def filename(path: str | None) -> str:
    if not path:
        return ""
    name = PureWindowsPath(path).name if "\\" in path else PurePosixPath(path).name
    return name.lower()


class BazarrClient:
    def __init__(self, base_url: str | None = None, api_key: str | None = None, timeout: float = 30.0):
        s = get_settings()
        self.base_url = (base_url or s.bazarr_url or "").rstrip("/")
        self.api_key = api_key or s.bazarr_api_key or ""
        self.timeout = timeout

    async def _req(self, method: str, path: str, **kw) -> httpx.Response:
        if not self.base_url:
            raise BazarrError("Bazarr não configurado")
        try:
            async with httpx.AsyncClient(base_url=f"{self.base_url}/api", timeout=kw.pop("timeout", self.timeout)) as c:
                r = await c.request(method, path, headers={**headers_for(self.base_url), "X-API-KEY": self.api_key}, **kw)
        except httpx.HTTPError as exc:
            raise BazarrError(f"Bazarr inacessível: {exc}") from exc
        if r.status_code >= 400:
            raise BazarrError(f"Bazarr {method} {path} -> {r.status_code}: {r.text[:300]}", r.status_code)
        return r

    async def _cached(self, key: str, path: str, params: dict) -> list[dict]:
        hit = _cache.get(key)
        if hit and time.monotonic() - hit[0] < CACHE_SECONDS:
            return hit[1]
        data = (await self._req("GET", path, params=params)).json().get("data", [])
        _cache[key] = (time.monotonic(), data)
        return data

    # ---------------------------------------------------------------- leitura
    async def movies(self) -> list[dict]:
        return await self._cached("movies", "/movies", {"start": 0, "length": -1})

    async def series(self) -> list[dict]:
        return await self._cached("series", "/series", {"start": 0, "length": -1})

    async def movie(self, radarr_id: int) -> dict | None:
        data = (await self._req("GET", "/movies", params={"radarrid[]": radarr_id})).json().get("data", [])
        return data[0] if data else None

    async def episodes(self, series_id: int) -> list[dict]:
        return (await self._req("GET", "/episodes", params={"seriesid[]": series_id})).json().get("data", [])

    async def episode(self, episode_id: int) -> dict | None:
        data = (await self._req("GET", "/episodes", params={"episodeid[]": episode_id})).json().get("data", [])
        return data[0] if data else None

    # ---------------------------------------------------------------- correspondência Jellyfin → Bazarr
    async def find_movie(self, *, imdb: str | None, path: str | None) -> dict | None:
        fname = filename(path)
        for m in await self.movies():
            if imdb and str(m.get("imdbId") or "").lower() == imdb.lower():
                return m
        if fname:
            for m in await self.movies():
                if filename(m.get("path")) == fname:
                    return m
        return None

    async def find_episode(self, *, series_tvdb: str | None, series_imdb: str | None, season: int | None,
                           episode: int | None, path: str | None) -> dict | None:
        fname = filename(path)
        candidates = []
        for s in await self.series():
            if (series_tvdb and str(s.get("tvdbId") or "") == str(series_tvdb)) or \
                    (series_imdb and str(s.get("imdbId") or "").lower() == series_imdb.lower()):
                candidates.append(s)
        for s in candidates:
            for ep in await self.episodes(int(s["sonarrSeriesId"])):
                if fname and filename(ep.get("path")) == fname:
                    return ep
                if season is not None and episode is not None and ep.get("season") == season \
                        and ep.get("episode") == episode:
                    return ep
        return None

    # ---------------------------------------------------------------- ações
    async def search_movie(self, radarr_id: int) -> list[dict]:
        return (await self._req("GET", "/providers/movies", params={"radarrid": radarr_id}, timeout=120)).json() \
            .get("data", [])

    async def search_episode(self, episode_id: int) -> list[dict]:
        return (await self._req("GET", "/providers/episodes", params={"episodeid": episode_id}, timeout=120)).json() \
            .get("data", [])

    async def download_movie(self, radarr_id: int, *, provider: str, subtitle: str, hi: bool, forced: bool,
                             original_format: bool = False) -> None:
        await self._req("POST", "/providers/movies", timeout=120, data={
            "radarrid": radarr_id, "provider": provider, "subtitle": subtitle, "hi": str(hi),
            "forced": str(forced), "original_format": str(original_format)})

    async def download_episode(self, series_id: int, episode_id: int, *, provider: str, subtitle: str, hi: bool,
                               forced: bool, original_format: bool = False) -> None:
        await self._req("POST", "/providers/episodes", timeout=120, data={
            "seriesid": series_id, "episodeid": episode_id, "provider": provider, "subtitle": subtitle,
            "hi": str(hi), "forced": str(forced), "original_format": str(original_format)})

    async def auto_download_movie(self, radarr_id: int, language: str, *, hi: bool = False,
                                  forced: bool = False) -> None:
        """Pesquisa automática do Bazarr (usa as pontuações/fornecedores configurados)."""
        await self._req("PATCH", "/movies/subtitles", timeout=180, params={
            "radarrid": radarr_id, "language": language, "hi": str(hi), "forced": str(forced)})

    async def auto_download_episode(self, series_id: int, episode_id: int, language: str, *, hi: bool = False,
                                    forced: bool = False) -> None:
        await self._req("PATCH", "/episodes/subtitles", timeout=180, params={
            "seriesid": series_id, "episodeid": episode_id, "language": language, "hi": str(hi),
            "forced": str(forced)})

    async def sync_subtitle(self, *, media_type: str, media_id: int, language: str, path: str,
                            forced: bool = False, hi: bool = False) -> None:
        """Sincroniza uma legenda com o áudio do vídeo (ffsubsync, via Bazarr)."""
        await self._req("PATCH", "/subtitles", timeout=300, params={
            "action": "sync", "language": language, "path": path, "type": media_type, "id": media_id,
            "forced": str(forced), "hi": str(hi)})

    async def ping(self) -> dict[str, Any]:
        return (await self._req("GET", "/system/status")).json()
