"""Cliente mínimo da API do Jellyfin 12.

Nota: o Jellyfin 12 deixou de aceitar `X-Emby-Token` / `?api_key=` — usamos sempre o header
`Authorization: MediaBrowser ... Token="..."`.
"""
from __future__ import annotations

from typing import Any

import httpx

from ..config import get_settings
from .upstream import headers_for

CLIENT_HDR = 'MediaBrowser Client="TKPortal", Device="TKPortal", DeviceId="tkportal-backend", Version="2.0"'


class JellyfinError(Exception):
    def __init__(self, message: str, status: int | None = None):
        super().__init__(message)
        self.status = status


def _auth(token: str) -> dict[str, str]:
    return {"Authorization": f'{CLIENT_HDR}, Token="{token}"'}


class JellyfinClient:
    def __init__(self, base_url: str | None = None, api_key: str | None = None, timeout: float = 15.0):
        s = get_settings()
        self.base_url = (base_url or s.jellyfin_url or "").rstrip("/")
        self.api_key = api_key or s.jellyfin_api_key or ""
        self.timeout = timeout

    async def _req(self, method: str, path: str, *, token: str | None = None, **kw) -> httpx.Response:
        if not self.base_url:
            raise JellyfinError("Jellyfin não configurado")
        headers = {**headers_for(self.base_url), **_auth(token or self.api_key), **kw.pop("headers", {})}
        try:
            async with httpx.AsyncClient(base_url=self.base_url, timeout=self.timeout) as c:
                r = await c.request(method, path, headers=headers, **kw)
        except httpx.HTTPError as exc:
            raise JellyfinError(f"Jellyfin inacessível: {exc}") from exc
        if r.status_code >= 400:
            raise JellyfinError(f"Jellyfin {method} {path} -> {r.status_code}: {r.text[:300]}", r.status_code)
        return r

    # ---------------------------------------------------------------- utilizadores
    async def list_users(self) -> list[dict[str, Any]]:
        return (await self._req("GET", "/Users")).json()

    async def get_user(self, user_id: str) -> dict[str, Any] | None:
        try:
            return (await self._req("GET", f"/Users/{user_id}")).json()
        except JellyfinError as e:
            if e.status in (400, 404):
                return None
            raise

    async def find_user_by_name(self, name: str) -> dict[str, Any] | None:
        for u in await self.list_users():
            if u.get("Name", "").lower() == name.lower():
                return u
        return None

    async def create_user(self, name: str, password: str | None) -> dict[str, Any]:
        body: dict[str, Any] = {"Name": name}
        if password:
            body["Password"] = password
        return (await self._req("POST", "/Users/New", json=body)).json()

    async def set_password(self, user_id: str, new_password: str) -> None:
        # Como administrador (API key) não é preciso a password atual.
        await self._req("POST", "/Users/Password", params={"userId": user_id}, json={"NewPw": new_password})

    async def update_policy(self, user_id: str, policy: dict[str, Any]) -> None:
        await self._req("POST", f"/Users/{user_id}/Policy", json=policy)

    async def rename_user(self, user_id: str, new_name: str) -> None:
        user = await self.get_user(user_id)
        if not user:
            raise JellyfinError("Utilizador não existe", 404)
        user["Name"] = new_name
        await self._req("POST", f"/Users/{user_id}", json=user)

    # ---------------------------------------------------------------- bibliotecas / sessões / devices
    async def libraries(self) -> list[dict[str, Any]]:
        data = (await self._req("GET", "/Library/VirtualFolders")).json()
        return [{"id": f.get("ItemId"), "name": f.get("Name"), "type": f.get("CollectionType")} for f in data]

    async def devices(self, user_id: str) -> list[dict[str, Any]]:
        data = (await self._req("GET", "/Devices", params={"userId": user_id})).json()
        return data.get("Items", [])

    async def delete_device(self, device_id: str) -> None:
        await self._req("DELETE", "/Devices", params={"id": device_id})

    async def sessions(self, active_within_seconds: int = 960) -> list[dict[str, Any]]:
        return (await self._req("GET", "/Sessions", params={"activeWithinSeconds": active_within_seconds})).json()

    async def quick_connect_authorize(self, code: str, user_id: str) -> bool:
        r = await self._req("POST", "/QuickConnect/Authorize", params={"code": code, "userId": user_id})
        try:
            return bool(r.json())
        except ValueError:
            return True

    # ---------------------------------------------------------------- conteúdos (assistente de suporte)
    ITEM_FIELDS = "ProviderIds,Path,MediaStreams,MediaSources,Overview,ProductionYear,ParentId,SeriesId,SeasonId"

    async def search_items(self, user_id: str, term: str, *, types: str = "Movie,Series,Episode",
                           limit: int = 8) -> list[dict[str, Any]]:
        """Pesquisa no que ESTE utilizador pode ver (respeita as bibliotecas a que tem acesso)."""
        data = (await self._req("GET", "/Items", params={
            "userId": user_id, "searchTerm": term, "IncludeItemTypes": types, "Recursive": "true",
            "Limit": limit, "Fields": "ProviderIds,ProductionYear,SeriesName,ParentIndexNumber,IndexNumber",
        })).json()
        return data.get("Items", [])

    async def get_item(self, user_id: str, item_id: str) -> dict[str, Any] | None:
        try:
            data = (await self._req("GET", "/Items", params={"userId": user_id, "ids": item_id,
                                                              "Fields": self.ITEM_FIELDS})).json()
        except JellyfinError as e:
            if e.status in (400, 404):
                return None
            raise
        items = data.get("Items", [])
        return items[0] if items else None

    async def episodes(self, user_id: str, series_id: str, season: int | None = None) -> list[dict[str, Any]]:
        params: dict[str, Any] = {"userId": user_id, "Fields": "ProviderIds,MediaStreams"}
        if season is not None:
            params["season"] = season
        return (await self._req("GET", f"/Shows/{series_id}/Episodes", params=params)).json().get("Items", [])

    async def refresh_item(self, item_id: str) -> None:
        await self._req("POST", f"/Items/{item_id}/Refresh", params={
            "metadataRefreshMode": "Default", "imageRefreshMode": "Default", "replaceAllMetadata": "false"})

    async def remote_subtitles(self, item_id: str, language: str) -> list[dict[str, Any]]:
        """Pesquisa de legendas pelos fornecedores configurados no Jellyfin (inclui o plugin Bazarr).

        `language` em ISO 639-2 (por, eng, ...).
        """
        return (await self._req("GET", f"/Items/{item_id}/RemoteSearch/Subtitles/{language}",
                                timeout=60)).json() or []

    async def download_remote_subtitle(self, item_id: str, subtitle_id: str) -> None:
        await self._req("POST", f"/Items/{item_id}/RemoteSearch/Subtitles/{subtitle_id}", timeout=90)

    async def add_to_collection(self, collection_id: str, item_ids: list[str]) -> None:
        await self._req("POST", f"/Collections/{collection_id}/Items", params={"ids": ",".join(item_ids)})

    async def user_sessions(self, user_id: str, active_within_seconds: int = 3600) -> list[dict[str, Any]]:
        target = user_id.replace("-", "").lower()
        return [s for s in await self.sessions(active_within_seconds)
                if str(s.get("UserId", "")).replace("-", "").lower() == target]

    async def playback_history(self, user_id: str, limit: int = 8) -> list[dict[str, Any]]:
        data = (await self._req("GET", "/Items", params={
            "userId": user_id, "Recursive": "true", "IsPlayed": "true", "SortBy": "DatePlayed",
            "SortOrder": "Descending", "Limit": limit, "IncludeItemTypes": "Movie,Episode",
            "Fields": "SeriesName,ParentIndexNumber,IndexNumber"})).json()
        items = data.get("Items", [])
        if items:
            return items
        # Nada terminado: o que está a meio.
        data = (await self._req("GET", "/UserItems/Resume", params={"userId": user_id, "Limit": limit})).json()
        return data.get("Items", [])

    # ---------------------------------------------------------------- tokens de utilizador
    async def whoami(self, user_token: str) -> dict[str, Any]:
        """Valida um access token de utilizador do Jellyfin e devolve o utilizador."""
        return (await self._req("GET", "/Users/Me", token=user_token)).json()

    async def ping(self) -> dict[str, Any]:
        return (await self._req("GET", "/System/Info/Public")).json()


def build_policy(current: dict[str, Any], *, enabled: bool, feature) -> dict[str, Any]:
    """Aplica os direitos do portal a uma UserPolicy existente, preservando o resto."""
    policy = dict(current or {})
    policy.setdefault("AuthenticationProviderId", "Jellyfin.Server.Implementations.Users.DefaultAuthenticationProvider")
    policy.setdefault("PasswordResetProviderId", "Jellyfin.Server.Implementations.Users.DefaultPasswordResetProvider")
    policy["IsDisabled"] = not enabled
    if enabled and feature is not None:
        policy["EnableAllFolders"] = bool(feature.all_libraries)
        policy["EnabledFolders"] = [] if feature.all_libraries else list(feature.libraries)
        policy["EnableLiveTvAccess"] = bool(feature.live_tv)
        policy["MaxActiveSessions"] = int(feature.max_streams or 0)
        policy["EnableContentDownloading"] = bool(feature.downloads)
        policy["RemoteClientBitrateLimit"] = int(feature.remote_bitrate_mbps or 0) * 1_000_000
    return policy
