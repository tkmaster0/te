"""Cabeçalhos extra para chegar aos serviços do TKFLIX (Jellyfin, Seerr, Bazarr, Dispatcharr).

Com o portal na mesma máquina do TKFLIX os pedidos vão pela rede Docker partilhada e não precisam de nada. Com o
portal noutro sítio vão pela internet, para hostnames públicos. Os que não devem ficar abertos a toda a gente (ex.:
a API do Bazarr) podem ficar atrás do Cloudflare Access com uma política "Service Auth"; o portal apresenta-se com
o service token (TKFLIX_ACCESS_CLIENT_ID / TKFLIX_ACCESS_CLIENT_SECRET).

O token só é enviado por HTTPS e só para hosts do TKFLIX configurados — nunca para outros destinos.
"""
from __future__ import annotations

from urllib.parse import urlparse

from ..config import get_settings


def headers_for(base_url: str | None) -> dict[str, str]:
    s = get_settings()
    if not (s.tkflix_access_client_id and s.tkflix_access_client_secret and base_url):
        return {}
    p = urlparse(base_url)
    if p.scheme != "https" or not p.hostname:
        return {}
    allowed = {h.lower() for h in s.tkflix_access_hosts} or {
        (urlparse(u).hostname or "").lower()
        for u in (s.jellyfin_url, s.seerr_url, s.bazarr_url, s.dispatcharr_url) if u}
    if p.hostname.lower() not in allowed:
        return {}
    return {"CF-Access-Client-Id": s.tkflix_access_client_id,
            "CF-Access-Client-Secret": s.tkflix_access_client_secret}
