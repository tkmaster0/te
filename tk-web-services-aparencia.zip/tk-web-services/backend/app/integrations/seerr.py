"""Cliente mínimo do Seerr (sucessor unificado do Jellyseerr/Overseerr). API em /api/v1, header X-Api-Key."""
from __future__ import annotations

from typing import Any

import httpx

from ..config import get_settings
from .upstream import headers_for


class SeerrError(Exception):
    def __init__(self, message: str, status: int | None = None):
        super().__init__(message)
        self.status = status


class SeerrClient:
    def __init__(self, base_url: str | None = None, api_key: str | None = None, timeout: float = 15.0):
        s = get_settings()
        self.base_url = (base_url or s.seerr_url or "").rstrip("/")
        self.api_key = api_key or s.seerr_api_key or ""
        self.timeout = timeout

    async def _req(self, method: str, path: str, **kw) -> httpx.Response:
        if not self.base_url:
            raise SeerrError("Seerr não configurado")
        try:
            async with httpx.AsyncClient(base_url=f"{self.base_url}/api/v1", timeout=self.timeout) as c:
                r = await c.request(method, path, headers={**headers_for(self.base_url), "X-Api-Key": self.api_key}, **kw)
        except httpx.HTTPError as exc:
            raise SeerrError(f"Seerr inacessível: {exc}") from exc
        if r.status_code >= 400:
            raise SeerrError(f"Seerr {method} {path} -> {r.status_code}: {r.text[:300]}", r.status_code)
        return r

    async def find_by_jellyfin_id(self, jellyfin_user_id: str, username: str | None = None) -> dict[str, Any] | None:
        target = jellyfin_user_id.replace("-", "").lower()
        params: dict[str, Any] = {"take": 100, "skip": 0}
        if username:
            params["q"] = username
        for _ in range(50):
            data = (await self._req("GET", "/user", params=params)).json()
            for u in data.get("results", []):
                if str(u.get("jellyfinUserId") or "").replace("-", "").lower() == target:
                    return u
            page = data.get("pageInfo", {})
            if page.get("page", 1) >= page.get("pages", 1):
                break
            params["skip"] += params["take"]
        if username:  # a pesquisa por nome pode não ser suportada — tenta sem filtro
            return await self.find_by_jellyfin_id(jellyfin_user_id, None)
        return None

    async def import_jellyfin_user(self, jellyfin_user_id: str) -> dict[str, Any] | None:
        r = await self._req("POST", "/user/import-from-jellyfin", json={"jellyfinUserIds": [jellyfin_user_id]})
        created = r.json() or []
        return created[0] if created else None

    async def get_main_settings(self, seerr_user_id: int) -> dict[str, Any]:
        return (await self._req("GET", f"/user/{seerr_user_id}/settings/main")).json()

    async def update_main_settings(self, seerr_user_id: int, changes: dict[str, Any]) -> dict[str, Any]:
        current = await self.get_main_settings(seerr_user_id)
        current.update(changes)
        return (await self._req("POST", f"/user/{seerr_user_id}/settings/main", json=current)).json()

    # ---------------------------------------------------------------- issues (assistente de suporte)
    ISSUE_TYPES = {1: "vídeo", 2: "áudio", 3: "legendas", 4: "outro"}

    async def get_permissions(self, seerr_user_id: int) -> int:
        r = await self._req("GET", f"/user/{seerr_user_id}/settings/permissions")
        return int((r.json() or {}).get("permissions") or 0)

    async def set_permissions(self, seerr_user_id: int, permissions: int) -> None:
        await self._req("POST", f"/user/{seerr_user_id}/settings/permissions", json={"permissions": permissions})

    async def issues(self, *, status: str = "open", take: int = 20, requested_by: int | None = None) -> list[dict]:
        params: dict[str, Any] = {"take": take, "skip": 0, "filter": status, "sort": "modified"}
        if requested_by is not None:
            params["requestedBy"] = requested_by
        return (await self._req("GET", "/issue", params=params)).json().get("results", [])

    async def get_issue(self, issue_id: int) -> dict[str, Any]:
        return (await self._req("GET", f"/issue/{int(issue_id)}")).json()

    async def comment_issue(self, issue_id: int, message: str) -> dict[str, Any]:
        return (await self._req("POST", f"/issue/{int(issue_id)}/comment", json={"message": message})).json()

    async def set_issue_status(self, issue_id: int, status: str) -> dict[str, Any]:
        if status not in ("open", "resolved"):
            raise SeerrError("Estado inválido")
        return (await self._req("POST", f"/issue/{int(issue_id)}/{status}")).json()

    async def create_issue(self, *, media_id: int, issue_type: int, message: str, problem_season: int = 0,
                           problem_episode: int = 0) -> dict[str, Any]:
        return (await self._req("POST", "/issue", json={
            "issueType": issue_type, "message": message, "mediaId": media_id,
            "problemSeason": problem_season, "problemEpisode": problem_episode})).json()

    async def media_by_tmdb(self, media_type: str, tmdb_id: int) -> dict[str, Any] | None:
        path = f"/{'movie' if media_type == 'movie' else 'tv'}/{int(tmdb_id)}"
        try:
            return (await self._req("GET", path)).json()
        except SeerrError as e:
            if e.status == 404:
                return None
            raise

    async def user_requests(self, seerr_user_id: int, take: int = 10) -> list[dict[str, Any]]:
        return (await self._req("GET", f"/user/{int(seerr_user_id)}/requests",
                                params={"take": take, "skip": 0})).json().get("results", [])

    async def default_permissions(self) -> int:
        """Permissões por omissão dos utilizadores novos (Definições → Utilizadores no Seerr)."""
        r = await self._req("GET", "/settings/main")
        return int((r.json() or {}).get("defaultPermissions") or 32)

    async def ping(self) -> dict[str, Any]:
        return (await self._req("GET", "/status")).json()
