"""Cliente assíncrono da API GoCardless (Billing Requests + Subscriptions).

Fluxo usado pelo portal:
  1. Billing Request com `mandate_request` (SEPA) + metadata do utilizador.
  2. Billing Request Flow → `authorisation_url` (página alojada pela GoCardless).
  3. Quando o Billing Request fica `fulfilled` (webhook ou regresso do utilizador), o portal cria a
     subscrição sobre o mandato com Idempotency-Key — assim nunca há subscrições duplicadas.
"""
from __future__ import annotations

import hashlib
import hmac
from typing import Any

import httpx

from ..config import get_settings

API_VERSION = "2015-07-06"


class GoCardlessError(Exception):
    def __init__(self, message: str, status: int | None = None, body: dict | None = None):
        super().__init__(message)
        self.status = status
        self.body = body or {}

    @property
    def conflict_id(self) -> str | None:
        """Em conflitos de idempotência a GoCardless devolve o id do recurso já criado."""
        for err in (self.body.get("error", {}) or {}).get("errors", []) or []:
            links = err.get("links") or {}
            if links.get("conflicting_resource_id"):
                return links["conflicting_resource_id"]
        return None


INTERVAL_MAP = {"month": "monthly", "year": "yearly", "week": "weekly"}


def verify_signature(body: bytes, signature: str | None, secret: str) -> bool:
    if not signature:
        return False
    digest = hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(digest, signature)


class GoCardlessClient:
    def __init__(self, token: str | None = None, environment: str | None = None, timeout: float = 20.0):
        s = get_settings()
        self.token = token or s.gocardless_access_token or ""
        env = environment or s.gocardless_environment
        self.base_url = "https://api.gocardless.com" if env == "live" else "https://api-sandbox.gocardless.com"
        self.timeout = timeout

    async def _req(self, method: str, path: str, *, json: dict | None = None, params: dict | None = None,
                   idempotency_key: str | None = None) -> dict[str, Any]:
        headers = {
            "Authorization": f"Bearer {self.token}",
            "GoCardless-Version": API_VERSION,
            "Accept": "application/json",
        }
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key
        try:
            async with httpx.AsyncClient(base_url=self.base_url, timeout=self.timeout) as c:
                r = await c.request(method, path, headers=headers, json=json, params=params)
        except httpx.HTTPError as exc:
            raise GoCardlessError(f"GoCardless inacessível: {exc}") from exc
        try:
            data = r.json() if r.content else {}
        except ValueError:
            data = {}
        if r.status_code >= 400:
            msg = (data.get("error") or {}).get("message") or r.text[:300]
            raise GoCardlessError(f"GoCardless {method} {path} -> {r.status_code}: {msg}", r.status_code, data)
        return data

    # ------------------------------------------------------------- billing requests
    async def create_billing_request(self, *, currency: str, scheme: str, metadata: dict[str, str],
                                     customer_id: str | None = None, idempotency_key: str | None = None) -> dict:
        body: dict[str, Any] = {
            "mandate_request": {"currency": currency, "scheme": scheme, "metadata": metadata},
            "metadata": metadata,
        }
        if customer_id:
            body["links"] = {"customer": customer_id}
        data = await self._req("POST", "/billing_requests", json={"billing_requests": body},
                               idempotency_key=idempotency_key)
        return data["billing_requests"]

    async def create_billing_request_flow(self, *, billing_request_id: str, redirect_uri: str, exit_uri: str,
                                          email: str | None = None, language: str = "pt") -> dict:
        body: dict[str, Any] = {
            "redirect_uri": redirect_uri,
            "exit_uri": exit_uri,
            "language": language,
            "links": {"billing_request": billing_request_id},
        }
        if email:
            body["prefilled_customer"] = {"email": email}
        data = await self._req("POST", "/billing_request_flows", json={"billing_request_flows": body})
        return data["billing_request_flows"]

    async def get_billing_request(self, br_id: str) -> dict:
        return (await self._req("GET", f"/billing_requests/{br_id}"))["billing_requests"]

    # ------------------------------------------------------------- mandates / customers
    async def get_mandate(self, mandate_id: str) -> dict:
        return (await self._req("GET", f"/mandates/{mandate_id}"))["mandates"]

    async def get_customer(self, customer_id: str) -> dict:
        return (await self._req("GET", f"/customers/{customer_id}"))["customers"]

    async def list_mandates(self, customer_id: str) -> list[dict]:
        return (await self._req("GET", "/mandates", params={"customer": customer_id, "limit": 50}))["mandates"]

    # ------------------------------------------------------------- subscriptions
    async def create_subscription(self, *, mandate_id: str, amount_cents: int, currency: str, interval_unit: str,
                                  interval: int, name: str, metadata: dict[str, str], start_date: str | None = None,
                                  idempotency_key: str | None = None) -> dict:
        body: dict[str, Any] = {
            "amount": amount_cents,
            "currency": currency,
            "interval_unit": INTERVAL_MAP.get(interval_unit, interval_unit),
            "interval": interval,
            "name": name[:255],
            "metadata": metadata,
            "retry_if_possible": True,
            "links": {"mandate": mandate_id},
        }
        if start_date:
            body["start_date"] = start_date
        try:
            data = await self._req("POST", "/subscriptions", json={"subscriptions": body},
                                   idempotency_key=idempotency_key)
        except GoCardlessError as e:
            if e.status == 409 and e.conflict_id:
                return await self.get_subscription(e.conflict_id)
            raise
        return data["subscriptions"]

    async def get_subscription(self, sub_id: str) -> dict:
        return (await self._req("GET", f"/subscriptions/{sub_id}"))["subscriptions"]

    async def list_subscriptions(self, *, mandate_id: str | None = None, customer_id: str | None = None) -> list[dict]:
        params: dict[str, Any] = {"limit": 100}
        if mandate_id:
            params["mandate"] = mandate_id
        if customer_id:
            params["customer"] = customer_id
        return (await self._req("GET", "/subscriptions", params=params))["subscriptions"]

    async def list_all_subscriptions(self, *, statuses: tuple[str, ...] = ("active", "paused"),
                                     max_pages: int = 50) -> list[dict]:
        """Todas as subscrições da conta (paginadas), filtradas pelo estado."""
        out: list[dict] = []
        after: str | None = None
        for _ in range(max_pages):
            params: dict[str, Any] = {"limit": 500}
            if after:
                params["after"] = after
            data = await self._req("GET", "/subscriptions", params=params)
            out.extend(x for x in data.get("subscriptions", []) if x.get("status") in statuses)
            after = ((data.get("meta") or {}).get("cursors") or {}).get("after")
            if not after:
                break
        return out

    async def cancel_subscription(self, sub_id: str) -> dict:
        return (await self._req("POST", f"/subscriptions/{sub_id}/actions/cancel", json={"data": {}}))["subscriptions"]

    async def pause_subscription(self, sub_id: str) -> dict:
        return (await self._req("POST", f"/subscriptions/{sub_id}/actions/pause", json={"data": {}}))["subscriptions"]

    async def resume_subscription(self, sub_id: str) -> dict:
        return (await self._req("POST", f"/subscriptions/{sub_id}/actions/resume", json={"data": {}}))["subscriptions"]

    # ------------------------------------------------------------- payments
    async def get_payment(self, payment_id: str) -> dict:
        return (await self._req("GET", f"/payments/{payment_id}"))["payments"]

    async def list_payments(self, *, subscription_id: str | None = None, mandate_id: str | None = None,
                            limit: int = 100) -> list[dict]:
        params: dict[str, Any] = {"limit": limit}
        if subscription_id:
            params["subscription"] = subscription_id
        if mandate_id:
            params["mandate"] = mandate_id
        return (await self._req("GET", "/payments", params=params))["payments"]

    async def create_payment(self, *, mandate_id: str, amount_cents: int, currency: str, description: str,
                             metadata: dict[str, str], idempotency_key: str, charge_date: str | None = None) -> dict:
        body: dict[str, Any] = {
            "amount": amount_cents,
            "currency": currency,
            "description": description[:100],
            "metadata": metadata,
            "retry_if_possible": False,  # as novas tentativas são geridas pelo portal
            "links": {"mandate": mandate_id},
        }
        if charge_date:
            body["charge_date"] = charge_date
        try:
            data = await self._req("POST", "/payments", json={"payments": body}, idempotency_key=idempotency_key)
        except GoCardlessError as e:
            if e.status == 409 and e.conflict_id:
                return await self.get_payment(e.conflict_id)
            raise
        return data["payments"]

    async def create_payment_billing_request(self, *, amount_cents: int, currency: str, description: str,
                                             metadata: dict[str, str], scheme: str, customer_id: str | None,
                                             idempotency_key: str) -> dict:
        """Billing request que paga um valor já e (re)cria o mandato para as próximas cobranças."""
        body: dict[str, Any] = {
            "payment_request": {"amount": amount_cents, "currency": currency, "description": description[:100],
                                "scheme": scheme, "metadata": metadata},
            "mandate_request": {"currency": currency, "scheme": scheme, "metadata": metadata},
            "metadata": metadata,
        }
        if customer_id:
            body["links"] = {"customer": customer_id}
        data = await self._req("POST", "/billing_requests", json={"billing_requests": body},
                               idempotency_key=idempotency_key)
        return data["billing_requests"]

    async def get_bank_account(self, account_id: str) -> dict:
        return (await self._req("GET", f"/customer_bank_accounts/{account_id}"))["customer_bank_accounts"]

    async def creditor_id(self) -> str | None:
        data = await self._req("GET", "/creditors", params={"limit": 1})
        creditors = data.get("creditors") or []
        return creditors[0]["id"] if creditors else None

    async def ping(self) -> dict:
        return (await self._req("GET", "/creditors", params={"limit": 1}))
