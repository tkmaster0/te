"""Wrapper fino sobre o SDK oficial do Stripe (modo assíncrono).

Os objetos Stripe mudaram de forma entre versões da API (ex.: `current_period_end` passou para os
subscription items; `invoice.subscription` passou para `invoice.parent.subscription_details`).
Os helpers `sub_period_end` / `invoice_subscription_id` tratam as duas formas.
"""
from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

import stripe

from ..config import get_settings

_client: stripe.StripeClient | None = None


def client() -> stripe.StripeClient:
    global _client
    if _client is None:
        s = get_settings()
        if not s.stripe_secret_key:
            raise RuntimeError("Stripe não configurado")
        _client = stripe.StripeClient(s.stripe_secret_key, http_client=stripe.HTTPXClient(), max_network_retries=2)
    return _client


def reset_client() -> None:
    global _client
    _client = None


def to_dict(obj: Any) -> dict:
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return obj
    if hasattr(obj, "to_dict"):
        return obj.to_dict()
    return dict(obj)


def ts(value: int | None) -> datetime | None:
    return datetime.fromtimestamp(value, tz=UTC) if value else None


def sub_period_end(sub: dict) -> datetime | None:
    if sub.get("current_period_end"):
        return ts(sub["current_period_end"])
    items = (sub.get("items") or {}).get("data") or []
    ends = [i.get("current_period_end") for i in items if i.get("current_period_end")]
    return ts(max(ends)) if ends else None


def sub_price_id(sub: dict) -> str | None:
    items = (sub.get("items") or {}).get("data") or []
    if not items:
        return None
    price = items[0].get("price") or {}
    return price.get("id") if isinstance(price, dict) else price


def invoice_subscription_id(inv: dict) -> str | None:
    if isinstance(inv.get("subscription"), str):
        return inv["subscription"]
    if isinstance(inv.get("subscription"), dict):
        return inv["subscription"].get("id")
    parent = inv.get("parent") or {}
    details = parent.get("subscription_details") or {}
    sub = details.get("subscription")
    if isinstance(sub, dict):
        return sub.get("id")
    if sub:
        return sub
    for line in (inv.get("lines") or {}).get("data") or []:
        p = line.get("parent") or {}
        d = p.get("subscription_item_details") or {}
        if d.get("subscription"):
            return d["subscription"]
    return None


async def create_customer(*, email: str, name: str, user_id: str) -> str:
    c = await client().v1.customers.create_async(
        params={"email": email, "name": name, "metadata": {"portal_user_id": user_id}}
    )
    return c.id


async def create_checkout_session(*, customer_id: str, price_id: str, checkout_id: str, user_id: str, plan_id: int,
                                  success_url: str, cancel_url: str) -> dict:
    session = await client().v1.checkout.sessions.create_async(
        params={
            "mode": "subscription",
            "customer": customer_id,
            "client_reference_id": checkout_id,
            "line_items": [{"price": price_id, "quantity": 1}],
            "success_url": success_url,
            "cancel_url": cancel_url,
            "allow_promotion_codes": True,
            "locale": "pt",
            "metadata": {"portal_user_id": user_id, "checkout_id": checkout_id, "plan_id": str(plan_id)},
            "subscription_data": {
                "metadata": {"portal_user_id": user_id, "checkout_id": checkout_id, "plan_id": str(plan_id)},
            },
        },
        options={"idempotency_key": f"checkout-{checkout_id}"},
    )
    return to_dict(session)


async def retrieve_checkout_session(session_id: str) -> dict:
    return to_dict(await client().v1.checkout.sessions.retrieve_async(session_id))


async def retrieve_subscription(sub_id: str) -> dict:
    return to_dict(await client().v1.subscriptions.retrieve_async(sub_id))


async def set_cancel_at_period_end(sub_id: str, value: bool) -> dict:
    return to_dict(await client().v1.subscriptions.update_async(sub_id, params={"cancel_at_period_end": value}))


async def change_price(sub_id: str, new_price_id: str) -> dict:
    sub = await retrieve_subscription(sub_id)
    item_id = sub["items"]["data"][0]["id"]
    return to_dict(
        await client().v1.subscriptions.update_async(
            sub_id,
            params={
                "items": [{"id": item_id, "price": new_price_id}],
                "proration_behavior": "create_prorations",
                "cancel_at_period_end": False,
            },
        )
    )


async def pause_collection(sub_id: str, pause: bool) -> dict:
    params: dict[str, Any] = {"pause_collection": {"behavior": "void"} if pause else ""}
    return to_dict(await client().v1.subscriptions.update_async(sub_id, params=params))


async def cancel_now(sub_id: str) -> dict:
    return to_dict(await client().v1.subscriptions.cancel_async(sub_id))


async def billing_portal(customer_id: str, return_url: str) -> str:
    s = await client().v1.billing_portal.sessions.create_async(
        params={"customer": customer_id, "return_url": return_url, "locale": "pt"}
    )
    return s.url


def construct_event(payload: bytes, sig_header: str | None) -> dict:
    s = get_settings()
    event = stripe.Webhook.construct_event(payload, sig_header, s.stripe_webhook_secret or "")
    return to_dict(event)


async def retrieve_invoice(invoice_id: str) -> dict:
    return to_dict(await client().v1.invoices.retrieve_async(invoice_id))


# --------------------------------------------------------------------------- faturação consolidada
async def account_id() -> str:
    acct = await client().v1.accounts.retrieve_current_async()
    return acct.id


async def create_setup_session(*, customer_id: str, checkout_id: str, user_id: str, success_url: str,
                               cancel_url: str) -> dict:
    """Checkout em modo "setup": o cliente guarda um cartão/SEPA para cobranças futuras (com SCA)."""
    session = await client().v1.checkout.sessions.create_async(
        params={
            "mode": "setup",
            "currency": "eur",
            "customer": customer_id,
            "client_reference_id": checkout_id,
            "success_url": success_url,
            "cancel_url": cancel_url,
            "locale": "pt",
            "metadata": {"portal_user_id": user_id, "checkout_id": checkout_id},
            "setup_intent_data": {"metadata": {"portal_user_id": user_id, "checkout_id": checkout_id}},
        },
        options={"idempotency_key": f"setup-{checkout_id}"},
    )
    return to_dict(session)


async def create_payment_session(*, customer_id: str, checkout_id: str, invoice_id: str, user_id: str,
                                 amount_cents: int, currency: str, description: str, success_url: str,
                                 cancel_url: str) -> dict:
    """Checkout em modo "payment" para pagar uma cobrança já (e guardar o método para as próximas)."""
    session = await client().v1.checkout.sessions.create_async(
        params={
            "mode": "payment",
            "customer": customer_id,
            "client_reference_id": checkout_id,
            "success_url": success_url,
            "cancel_url": cancel_url,
            "locale": "pt",
            "line_items": [{"quantity": 1, "price_data": {
                "currency": currency.lower(), "unit_amount": amount_cents, "product_data": {"name": description}}}],
            "metadata": {"portal_user_id": user_id, "checkout_id": checkout_id, "invoice_id": invoice_id},
            "payment_intent_data": {
                "setup_future_usage": "off_session",
                "description": description,
                "metadata": {"portal_user_id": user_id, "checkout_id": checkout_id, "invoice_id": invoice_id},
            },
        },
        options={"idempotency_key": f"pay-{checkout_id}"},
    )
    return to_dict(session)


async def retrieve_setup_intent(setup_intent_id: str) -> dict:
    return to_dict(await client().v1.setup_intents.retrieve_async(setup_intent_id))


async def retrieve_payment_method(pm_id: str) -> dict:
    return to_dict(await client().v1.payment_methods.retrieve_async(pm_id))


async def retrieve_payment_intent(pi_id: str) -> dict:
    return to_dict(await client().v1.payment_intents.retrieve_async(pi_id))


async def charge_off_session(*, customer_id: str, payment_method_id: str, amount_cents: int, currency: str,
                             description: str, metadata: dict, idempotency_key: str) -> dict:
    """PaymentIntent sem o cliente presente (MIT). Devolve o PaymentIntent (mesmo quando é recusado)."""
    try:
        pi = await client().v1.payment_intents.create_async(
            params={
                "amount": amount_cents,
                "currency": currency.lower(),
                "customer": customer_id,
                "payment_method": payment_method_id,
                "off_session": True,
                "confirm": True,
                "description": description,
                "metadata": metadata,
            },
            options={"idempotency_key": idempotency_key},
        )
        return to_dict(pi)
    except stripe.CardError as e:
        err = e.error
        pi = getattr(err, "payment_intent", None) if err else None
        data = to_dict(pi) if pi else {"status": "requires_payment_method"}
        data["_error"] = {"code": getattr(err, "code", None), "decline_code": getattr(err, "decline_code", None),
                          "message": getattr(err, "message", None) or str(e)}
        return data


async def detach_payment_method(pm_id: str) -> None:
    await client().v1.payment_methods.detach_async(pm_id)


# --------------------------------------------------------------------------- migração de subscrições antigas
async def list_subscriptions(*, status: str = "all", starting_after: str | None = None, limit: int = 100) -> dict:
    params: dict[str, Any] = {"status": status, "limit": limit, "expand": ["data.customer",
                                                                          "data.default_payment_method"]}
    if starting_after:
        params["starting_after"] = starting_after
    return to_dict(await client().v1.subscriptions.list_async(params=params))


async def retrieve_price(price_id: str) -> dict:
    return to_dict(await client().v1.prices.retrieve_async(price_id, params={"expand": ["product"]}))


async def retrieve_customer(customer_id: str) -> dict:
    return to_dict(await client().v1.customers.retrieve_async(customer_id))


def sub_period_start(sub: dict) -> datetime | None:
    if sub.get("current_period_start"):
        return ts(sub["current_period_start"])
    items = (sub.get("items") or {}).get("data") or []
    starts = [i.get("current_period_start") for i in items if i.get("current_period_start")]
    return ts(min(starts)) if starts else None
