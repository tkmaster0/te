/*
 * Suporte TKFLIX — chat flutuante em todas as páginas do Jellyfin.
 *
 * Instalação: Admin → Jellyfin no portal mostra o que colar no plugin "JavaScript Injector" (com o endereço do
 * portal já preenchido). Este ficheiro é servido pelo portal em /jellyfin/widget.js.
 *
 * O que faz: um botão "Ajuda" no canto que abre o chat com o assistente. Dentro do Jellyfin o assistente trata do
 * suporte TKFLIX (legendas, reprodução, apps, pedidos) e, na faturação, só da subscrição de streaming — tal como a
 * página "A minha conta" (Custom Pages).
 *
 * Segurança:
 *   • o token da sessão Jellyfin só é enviado para PORTAL_URL, que o valida no próprio Jellyfin (/Users/Me);
 *   • não corre para contas de administrador do Jellyfin (o token de um admin nunca sai do browser);
 *   • tudo o que vem do servidor é inserido como texto (nunca como HTML);
 *   • nada é carregado de fora: este ficheiro é todo o código.
 */
(function () {
  "use strict";
  var PORTAL_URL = "__PORTAL_URL__";   // preenchido pelo portal (Admin → Jellyfin)

  if (window.__tkSupportWidget) return;
  window.__tkSupportWidget = true;

  var AGENT = { billing: "Faturação", support: "Suporte TKFLIX" };
  var CHIPS = ["As legendas estão dessincronizadas", "O vídeo está sempre a parar", "Faltam legendas em português",
               "Como entro na app da TV?"];
  var state = { conv: null, busy: false, loaded: false, open: false, allowed: null };

  // Sessão do Jellyfin: ApiClient (jellyfin-web e apps Android/iOS que o usam por dentro) ou, em versões que já não
  // expõem o ApiClient, as credenciais guardadas pelo próprio jellyfin-web.
  function creds() {
    try {
      var c = JSON.parse(localStorage.getItem("jellyfin_credentials") || "{}");
      var servers = (c.Servers || []).filter(function (s) { return s.AccessToken; });
      servers.sort(function (a, b) { return (b.DateLastAccessed || 0) - (a.DateLastAccessed || 0); });
      return servers[0] || null;
    } catch (e) { return null; }
  }
  function token() {
    try { if (window.ApiClient && window.ApiClient.accessToken()) return window.ApiClient.accessToken(); } catch (e) { /* */ }
    var s = creds();
    return s ? s.AccessToken : null;
  }
  // Apps Android/iOS do Jellyfin (jellyfin-web dentro de uma webview): links externos vão para o browser do sistema.
  function openExternal(url) {
    try { if (window.NativeShell && window.NativeShell.openUrl) return window.NativeShell.openUrl(url, "_blank"); } catch (e) { /* */ }
    window.open(url, "_blank", "noopener");
  }
  function isTv() {
    var h = document.documentElement;
    return h.classList.contains("layout-tv") || /\b(SMART-TV|SmartTV|Tizen|Web0S|webOS|AFT|Android TV|BRAVIA|CrKey)\b/i.test(navigator.userAgent);
  }
  function store(k, v) {
    try { if (v === undefined) return sessionStorage.getItem(k); if (v === null) sessionStorage.removeItem(k); else sessionStorage.setItem(k, v); }
    catch (e) { return null; }
  }
  function el(tag, attrs, text) {
    var n = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) {
      if (k === "class") n.className = attrs[k];
      else if (k.indexOf("on") === 0) n.addEventListener(k.slice(2), attrs[k]);
      else n.setAttribute(k, attrs[k]);
    });
    if (text != null) n.textContent = text;
    return n;
  }

  // ------------------------------------------------------------------ estilos (prefixo tkw- para não colidir)
  var css = "" +
    ".tkw-btn{position:fixed;right:calc(18px + env(safe-area-inset-right,0px));bottom:calc(18px + env(safe-area-inset-bottom,0px) + var(--tkw-lift,0px));" +
    "z-index:9999;display:flex;align-items:center;gap:8px;border:0;-webkit-tap-highlight-color:transparent;" +
    "border-radius:999px;padding:12px 18px;background:#f5c518;color:#0b0b0c;font:600 15px/1 system-ui,sans-serif;" +
    "box-shadow:0 10px 30px rgba(0,0,0,.45);cursor:pointer}" +
    ".tkw-btn:focus-visible,.tkw-panel button:focus-visible,.tkw-panel textarea:focus-visible{outline:2px solid #f5c518;outline-offset:2px}" +
    ".tkw-panel{position:fixed;right:18px;bottom:78px;z-index:9999;width:380px;max-width:calc(100vw - 24px);" +
    "height:min(620px,calc(100vh - 110px));display:flex;flex-direction:column;background:#151517;color:#ededed;" +
    "border:1px solid #2a2a2f;border-radius:16px;box-shadow:0 24px 60px rgba(0,0,0,.6);overflow:hidden;" +
    "font:14px/1.5 system-ui,-apple-system,'Segoe UI',Roboto,sans-serif}" +
    ".tkw-panel[hidden]{display:none}" +
    ".tkw-head{display:flex;align-items:center;gap:10px;padding:12px 14px;border-bottom:1px solid #2a2a2f}" +
    ".tkw-head strong{flex:1;font-size:15px}.tkw-head small{display:block;color:#a1a1aa;font-weight:400;font-size:12px}" +
    ".tkw-icon{background:none;border:0;color:#a1a1aa;cursor:pointer;font-size:18px;padding:4px 6px;border-radius:8px}" +
    ".tkw-icon:hover{color:#fff;background:#26262a}" +
    ".tkw-msgs{flex:1;overflow-y:auto;padding:14px;display:flex;flex-direction:column;gap:9px}" +
    ".tkw-m{max-width:86%;padding:9px 12px;border-radius:14px;white-space:pre-wrap;word-wrap:break-word}" +
    ".tkw-u{align-self:flex-end;background:#f5c518;color:#0b0b0c;border-bottom-right-radius:4px}" +
    ".tkw-a{align-self:flex-start;background:#1f1f23;border:1px solid #2a2a2f;border-bottom-left-radius:4px}" +
    ".tkw-who{display:block;font-size:10.5px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;color:#a1a1aa;margin-bottom:2px}" +
    ".tkw-ev{align-self:center;color:#a1a1aa;font-size:12px}" +
    ".tkw-cf{border:1px solid #5a4418;background:#2a2112;border-radius:12px;padding:11px}" +
    ".tkw-cf p{margin:0 0 9px;color:#fde68a}" +
    ".tkw-row{display:flex;gap:8px;flex-wrap:wrap}" +
    ".tkw-b{border:1px solid #2a2a2f;background:#1f1f23;color:#ededed;border-radius:9px;padding:7px 12px;font:600 13px system-ui,sans-serif;cursor:pointer}" +
    ".tkw-b.tkw-p{background:#f5c518;border-color:#f5c518;color:#0b0b0c}.tkw-b:disabled{opacity:.5;cursor:default}" +
    ".tkw-chip{border:1px solid #2a2a2f;background:#1f1f23;color:#ededed;border-radius:999px;padding:6px 11px;font:13px system-ui,sans-serif;cursor:pointer}" +
    ".tkw-typing{color:#a1a1aa;font-size:12.5px}" +
    ".tkw-form{display:flex;gap:8px;padding:10px;border-top:1px solid #2a2a2f}" +
    ".tkw-form textarea{flex:1;resize:none;min-height:42px;max-height:120px;border-radius:10px;border:1px solid #2a2a2f;" +
    "background:#0b0b0c;color:#ededed;font:inherit;padding:9px 11px}" +
    ".tkw-note{padding:0 12px 10px;color:#71717a;font-size:11.5px}" +
    "@media (max-width:600px){.tkw-panel{right:0;left:0;bottom:0;top:0;width:100%;max-width:none;height:auto;border-radius:0;" +
    "padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}" +
    ".tkw-btn{bottom:calc(84px + env(safe-area-inset-bottom,0px) + var(--tkw-lift,0px));right:14px;padding:12px}.tkw-btn span{display:none}}" +
    // Modo TV do jellyfin-web (comando): alvos maiores e foco bem visível
    ".layout-tv .tkw-btn{padding:16px 24px;font-size:18px}.layout-tv .tkw-panel{width:520px;font-size:17px}" +
    ".layout-tv .tkw-panel button:focus,.layout-tv .tkw-btn:focus{outline:3px solid #fff;outline-offset:3px;transform:scale(1.04)}" +
    ".layout-tv .tkw-chip,.layout-tv .tkw-b{padding:10px 16px;font-size:16px}";

  // ------------------------------------------------------------------ API
  function api(body) {
    var t = token();
    if (!t) return Promise.reject(new Error("Sessão do Jellyfin indisponível."));
    body.token = t;
    return fetch(PORTAL_URL + "/api/integrations/jellyfin/assistant", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body)
    }).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (d) {
        if (!r.ok) { var e = new Error(d.detail || ("Erro " + r.status)); e.status = r.status; throw e; }
        return d;
      });
    });
  }

  // ------------------------------------------------------------------ UI
  var btn, panel, msgs, input, send;

  function build() {
    var style = el("style"); style.textContent = css; document.head.appendChild(style);
    btn = el("button", { class: "tkw-btn", type: "button", "aria-haspopup": "dialog", "aria-expanded": "false",
                         "aria-label": "Abrir o suporte TKFLIX", onclick: toggle });
    btn.appendChild(el("b", { "aria-hidden": "true" }, "💬"));
    btn.appendChild(el("span", {}, "Ajuda"));
    panel = el("div", { class: "tkw-panel", role: "dialog", "aria-label": "Suporte TKFLIX", hidden: "" });
    var head = el("div", { class: "tkw-head" });
    var title = el("strong", {}, "Suporte TKFLIX");
    title.appendChild(el("small", {}, "Legendas, reprodução, apps e a tua subscrição"));
    head.appendChild(title);
    if (!isTv()) {
      head.appendChild(el("button", { class: "tkw-icon", type: "button", title: "Abrir no portal", "aria-label": "Abrir no portal",
                                      onclick: function () { openExternal(PORTAL_URL + "/ajuda"); } }, "↗"));
    }
    head.appendChild(el("button", { class: "tkw-icon", type: "button", title: "Nova conversa", "aria-label": "Nova conversa",
                                    onclick: reset }, "↺"));
    head.appendChild(el("button", { class: "tkw-icon", type: "button", title: "Fechar", "aria-label": "Fechar",
                                    onclick: toggle }, "✕"));
    msgs = el("div", { class: "tkw-msgs", "aria-live": "polite" });
    var form = el("form", { class: "tkw-form", onsubmit: onSend });
    input = el("textarea", { rows: "1", maxlength: "4000", placeholder: "Escreve a tua pergunta…", "aria-label": "Mensagem" });
    input.addEventListener("keydown", function (e) { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); onSend(); } });
    send = el("button", { class: "tkw-b tkw-p", type: "submit" }, "Enviar");
    form.appendChild(input); form.appendChild(send);
    panel.appendChild(head); panel.appendChild(msgs); panel.appendChild(form);
    panel.appendChild(el("div", { class: "tkw-note" }, "Respostas geradas por IA. Mudanças na tua conta pedem sempre confirmação."));
    document.body.appendChild(btn); document.body.appendChild(panel);
    document.addEventListener("keydown", function (e) { if (e.key === "Escape" && state.open) toggle(); });
  }

  function toggle() {
    state.open = !state.open;
    panel.hidden = !state.open;
    btn.setAttribute("aria-expanded", String(state.open));
    if (state.open) {
      if (!state.loaded) loadHistory();
      setTimeout(function () { input.focus(); }, 30);
    } else btn.focus();
  }

  function bubble(m) {
    var ui = m.ui || {};
    if (m.role === "user") return el("div", { class: "tkw-m tkw-u" }, m.content);
    if (m.role === "event" && ui.type === "confirm") {
      var box = el("div", { class: "tkw-cf" });
      var p = el("p"); p.appendChild(el("strong", {}, "Confirmas? ")); p.appendChild(document.createTextNode(ui.summary || m.content || ""));
      box.appendChild(p);
      if (!ui.status || ui.status === "pending") {
        var row = el("div", { class: "tkw-row" });
        row.appendChild(el("button", { class: "tkw-b tkw-p", type: "button", onclick: function (ev) { decide(ui.action_id, true, box); } }, "Confirmar"));
        row.appendChild(el("button", { class: "tkw-b", type: "button", onclick: function () { decide(ui.action_id, false, box); } }, "Cancelar"));
        box.appendChild(row);
      } else {
        box.appendChild(el("span", { class: "tkw-typing" }, { done: "Confirmado", cancelled: "Cancelado", expired: "Expirou", failed: "Falhou" }[ui.status] || ui.status));
      }
      return box;
    }
    if (m.role === "event") return el("div", { class: "tkw-ev" }, "— " + (m.content || "") + " —");
    if (m.role === "assistant" && m.content) {
      var b = el("div", { class: "tkw-m tkw-a" });
      b.appendChild(el("span", { class: "tkw-who" }, AGENT[m.agent] || "Assistente"));
      // **negrito** → <strong>, o resto como texto (sem HTML vindo do servidor).
      String(m.content).split(/(\*\*[^*]+\*\*)/g).forEach(function (part) {
        if (/^\*\*[^*]+\*\*$/.test(part)) b.appendChild(el("strong", {}, part.slice(2, -2)));
        else if (part) b.appendChild(document.createTextNode(part));
      });
      return b;
    }
    return null;
  }

  function append(list) {
    var chips = msgs.querySelector(".tkw-chips");
    if (chips) chips.remove();
    list.forEach(function (m) { var n = bubble(m); if (n) msgs.appendChild(n); });
    msgs.scrollTop = msgs.scrollHeight;
  }

  function typing(on) {
    var t = msgs.querySelector(".tkw-typing-live");
    if (on && !t) { msgs.appendChild(el("div", { class: "tkw-typing tkw-typing-live" }, "A escrever…")); msgs.scrollTop = msgs.scrollHeight; }
    if (!on && t) t.remove();
  }

  function welcome() {
    msgs.textContent = "";
    append([{ role: "assistant", agent: "support", content: "Olá! 👋 Sou o suporte do TKFLIX. Posso ajudar com legendas, " +
      "reprodução, apps e pedidos — ou com a tua subscrição de streaming." }]);
    var chips = el("div", { class: "tkw-row tkw-chips" });
    CHIPS.forEach(function (c) {
      chips.appendChild(el("button", { class: "tkw-chip", type: "button", onclick: function () { input.value = c; onSend(); } }, c));
    });
    msgs.appendChild(chips);
  }

  function loadHistory() {
    state.loaded = true;
    api({ conversation_id: state.conv }).then(function (d) {
      state.conv = d.conversation_id || null;
      if (d.messages && d.messages.length) { msgs.textContent = ""; append(d.messages); } else welcome();
    }).catch(function (e) {
      if (e.status === 503 || e.status === 404) { btn.remove(); panel.remove(); return; }
      msgs.textContent = "";
      append([{ role: "assistant", content: "Não consegui ligar ao suporte: " + e.message }]);
    });
  }

  function reset() { state.conv = null; store("tkw-conv", null); welcome(); input.focus(); }

  function onSend(ev) {
    if (ev) ev.preventDefault();
    var text = input.value.trim();
    if (!text || state.busy) return;
    state.busy = true; send.disabled = true; input.value = "";
    append([{ role: "user", content: text }]);
    typing(true);
    api({ message: text, conversation_id: state.conv }).then(function (d) {
      state.conv = d.conversation_id; store("tkw-conv", state.conv);
      typing(false); append(d.messages || []);
    }).catch(function (e) {
      typing(false);
      append([{ role: "assistant", content: e.status === 429 ? "Estás a enviar muitas mensagens. Espera um pouco. 🙏" : "Não consegui responder agora: " + e.message }]);
    }).then(function () { state.busy = false; send.disabled = false; input.focus(); });
  }

  function decide(actionId, yes, box) {
    box.querySelectorAll("button").forEach(function (b) { b.disabled = true; });
    typing(true);
    api({ action_id: actionId, confirm: yes }).then(function (d) {
      typing(false);
      var row = box.querySelector(".tkw-row"); if (row) row.replaceWith(el("span", { class: "tkw-typing" }, yes ? "Confirmado" : "Cancelado"));
      append(d.messages || []);
    }).catch(function (e) {
      typing(false);
      box.querySelectorAll("button").forEach(function (b) { b.disabled = false; });
      append([{ role: "assistant", content: e.message }]);
    });
  }

  // Esconde o botão durante a reprodução e na página "A minha conta" (que já tem o separador Ajuda).
  function syncVisibility() {
    if (!btn) return;
    var route = (location.hash || "") + " " + (location.pathname || "");
    var playing = /\/?video\b/.test(route) || !!document.querySelector(".videoPlayerContainer:not(.hide)");
    var accountPage = !!document.getElementById("tk-root");
    btn.style.display = playing || accountPage ? "none" : "";
    if ((playing || accountPage) && state.open) toggle();
    // Barra "a reproduzir" (música/mini-player) no fundo: o botão sobe para não a tapar.
    var bar = document.querySelector(".nowPlayingBar:not(.hide)");
    document.documentElement.style.setProperty("--tkw-lift", bar && bar.offsetHeight ? bar.offsetHeight + "px" : "0px");
  }

  // ------------------------------------------------------------------ arranque
  function isAdmin() {
    try {
      if (window.ApiClient && window.ApiClient.getCurrentUser) {
        return window.ApiClient.getCurrentUser().then(function (u) { return !!(u && u.Policy && u.Policy.IsAdministrator); });
      }
      var s = creds();
      if (!s) return Promise.resolve(true);
      // Sem ApiClient: pergunta ao próprio Jellyfin (mesma origem, com o caminho base se houver) quem é o utilizador.
      var base = location.pathname.indexOf("/web/") >= 0 ? location.pathname.split("/web/")[0] : "";
      return fetch(base + "/Users/Me", {
        headers: { "Authorization": 'MediaBrowser Client="TKWS", Device="Browser", DeviceId="tkws", Version="1", Token="' + s.AccessToken + '"' }
      }).then(function (r) { return r.ok ? r.json() : { Policy: { IsAdministrator: true } }; })
        .then(function (u) { return !!(u && u.Policy && u.Policy.IsAdministrator); });
    } catch (e) { return Promise.resolve(true); }  // na dúvida, não expor o token
  }

  var tries = 0;
  (function start() {
    if (!token() || !document.body) { if (tries++ < 60) setTimeout(start, 500); return; }
    isAdmin().then(function (admin) {
      if (admin) return;  // contas de administrador não usam este widget
      state.conv = store("tkw-conv") || null;
      build();
      syncVisibility();
      window.addEventListener("hashchange", syncVisibility);
      setInterval(syncVisibility, 1500);
    }).catch(function () { /* sem utilizador: não mostrar */ });
  })();
})();
