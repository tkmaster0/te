"""Endpoints dos assistentes: chat do portal, chat dentro do Jellyfin, webhooks (WhatsApp, Seerr) e painel admin."""
from __future__ import annotations

import hashlib
import json
import logging
from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException, Query, Request, Response
from fastapi.responses import JSONResponse, PlainTextResponse
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from ..db import get_db, utcnow
from ..deps import rate_limit, require_admin, require_user, require_user_any_scope, session_scope
from ..models import User, WebhookEvent
from ..security import constant_time_eq
from ..services.audit import audit
from ..services.jobs import enqueue
from . import knowledge, learning, runtime
from .agents import AGENTS
from .agents.base import active_instructions
from .channels import whatsapp
from .models import (
    AssistantConversation,
    AssistantInstruction,
    AssistantMessage,
    ChannelIdentity,
    KnowledgeItem,
    PendingAction,
)
from .tools import ToolFailure

log = logging.getLogger("tkportal.assistant.api")

router = APIRouter(prefix="/api/assistant", tags=["assistant"])
admin_router = APIRouter(prefix="/api/admin/assistant", tags=["admin-assistant"], dependencies=[Depends(require_admin)])
bridge_router = APIRouter(prefix="/api/integrations/jellyfin/assistant", tags=["integrations"])
webhook_router = APIRouter(prefix="/api/webhooks", tags=["webhooks"])


def _ready() -> None:
    if not get_settings().assistant_ready:
        raise HTTPException(503, detail="O assistente não está ativo.")


def msg_out(m: AssistantMessage, *, admin: bool = False) -> dict | None:
    ui = m.ui or {}
    if not admin:
        if m.role == "tool" or (m.role == "user" and ui.get("hidden")):
            return None
        if m.role == "assistant" and not m.content:
            return None
    out = {"id": m.id, "role": m.role, "agent": m.agent, "content": m.content, "ui": ui or None,
           "feedback": m.feedback, "created_at": m.created_at.isoformat() if m.created_at else None}
    if admin:
        out.update({"tool_calls": m.tool_calls, "tool_name": m.tool_name, "model": m.model,
                    "tokens_in": m.tokens_in, "tokens_out": m.tokens_out, "feedback_note": m.feedback_note})
    return out


async def _pending_state(db: AsyncSession, msgs: list[dict]) -> list[dict]:
    """Marca os pedidos de confirmação que já não estão pendentes (para a UI esconder os botões)."""
    ids = [m["ui"]["action_id"] for m in msgs if m.get("ui") and m["ui"].get("type") == "confirm"]
    if not ids:
        return msgs
    rows = {a.id: a.status for a in (await db.scalars(select(PendingAction).where(PendingAction.id.in_(ids)))).all()}
    for m in msgs:
        if m.get("ui") and m["ui"].get("type") == "confirm":
            st = rows.get(m["ui"]["action_id"], "expired")
            m["ui"] = {**m["ui"], "status": st}
    return msgs


async def _conv_messages(db: AsyncSession, conv: AssistantConversation, *, admin: bool = False) -> list[dict]:
    rows = (await db.scalars(select(AssistantMessage).where(AssistantMessage.conversation_id == conv.id)
                             .order_by(AssistantMessage.id))).all()
    return await _pending_state(db, [o for m in rows if (o := msg_out(m, admin=admin)) is not None])


def conv_out(c: AssistantConversation) -> dict:
    return {"id": c.id, "channel": c.channel, "agent": c.agent, "title": c.title, "status": c.status,
            "created_at": c.created_at.isoformat(), "updated_at": c.updated_at.isoformat() if c.updated_at else None}


# =========================================================================== cliente (portal)
class ChatIn(BaseModel):
    message: str = Field(min_length=1, max_length=4000)
    conversation_id: str | None = Field(None, max_length=36)


@router.get("/status")
async def status(user: User = Depends(require_user_any_scope), db: AsyncSession = Depends(get_db)):
    s = get_settings()
    ident = await db.scalar(select(ChannelIdentity).where(ChannelIdentity.user_id == user.id,
                                                          ChannelIdentity.channel == "whatsapp"))
    return {"enabled": s.assistant_ready,
            "agents": [{"name": a.name, "label": a.label} for a in AGENTS.values()],
            "whatsapp": {"enabled": s.assistant_ready and s.whatsapp_enabled, "number": s.whatsapp_number,
                         "linked": ident.display if ident else None}}


@router.get("/memory")
async def my_memory(user: User = Depends(require_user), db: AsyncSession = Depends(get_db)):
    """O que cada assistente guarda sobre o cliente (transparência)."""
    from . import memory

    notes = await memory.summary_for(db, user.id)
    return [{"agent": a.name, "label": a.label, "summary": notes.get(a.name, "")} for a in AGENTS.values()]


@router.delete("/memory")
async def forget_memory(user: User = Depends(require_user), db: AsyncSession = Depends(get_db)):
    from . import memory

    await memory.forget(db, user.id)
    await db.commit()
    return {"status": "ok", "message": "Os assistentes esqueceram as conversas anteriores contigo."}


@router.get("/conversations")
async def conversations(request: Request, user: User = Depends(require_user_any_scope),
                        db: AsyncSession = Depends(get_db)):
    q = select(AssistantConversation).where(AssistantConversation.user_id == user.id,
                                            AssistantConversation.channel.in_(["web", "whatsapp", "jellyfin"]))
    if session_scope(request) == "streaming":
        q = q.where(AssistantConversation.scope == "streaming")
    rows = (await db.scalars(q.order_by(AssistantConversation.updated_at.desc()).limit(20))).all()
    return [conv_out(c) for c in rows]


async def _own_conv(db: AsyncSession, conv_id: str, user: User, request: Request) -> AssistantConversation:
    conv = await db.get(AssistantConversation, conv_id)
    if conv is None or conv.user_id != user.id:
        raise HTTPException(404, detail="Conversa não encontrada.")
    if session_scope(request) == "streaming" and conv.scope != "streaming":
        raise HTTPException(404, detail="Conversa não encontrada.")
    return conv


@router.get("/conversations/{conv_id}")
async def conversation(conv_id: str, request: Request, user: User = Depends(require_user_any_scope),
                       db: AsyncSession = Depends(get_db)):
    conv = await _own_conv(db, conv_id, user, request)
    return {**conv_out(conv), "messages": await _conv_messages(db, conv)}


@router.post("/chat")
async def chat(body: ChatIn, request: Request, user: User = Depends(require_user_any_scope),
               db: AsyncSession = Depends(get_db)):
    _ready()
    rate_limit(f"assistant:{user.id}", 20, 60)
    scope = session_scope(request)
    if body.conversation_id:
        await _own_conv(db, body.conversation_id, user, request)
    conv = await runtime.get_or_create_conversation(db, user=user, channel="web", scope=scope,
                                                    conversation_id=body.conversation_id)
    result = await runtime.handle_message(db, conv, user, body.message)
    msgs = [o for m in result.messages if (o := msg_out(m)) is not None]
    return {"conversation_id": conv.id, "agent": result.agent, "messages": await _pending_state(db, msgs)}


class DecideIn(BaseModel):
    confirm: bool


@router.post("/actions/{action_id}")
async def decide(action_id: str, body: DecideIn, request: Request, user: User = Depends(require_user_any_scope),
                 db: AsyncSession = Depends(get_db)):
    action = await db.get(PendingAction, action_id)
    if action is None or action.user_id != user.id:
        raise HTTPException(404, detail="Pedido não encontrado.")
    await _own_conv(db, action.conversation_id, user, request)
    try:
        msg = await runtime.decide_action(db, action, user, confirm=body.confirm)
    except ToolFailure as exc:
        raise HTTPException(400, detail=str(exc)) from exc
    return {"message": msg_out(msg)}


class FeedbackIn(BaseModel):
    value: int = Field(ge=-1, le=1)
    note: str | None = Field(None, max_length=1000)


@router.post("/messages/{message_id}/feedback")
async def feedback(message_id: int, body: FeedbackIn, request: Request, user: User = Depends(require_user_any_scope),
                   db: AsyncSession = Depends(get_db)):
    m = await db.get(AssistantMessage, message_id)
    if m is None or m.role != "assistant":
        raise HTTPException(404, detail="Mensagem não encontrada.")
    await _own_conv(db, m.conversation_id, user, request)
    m.feedback = body.value or None
    m.feedback_note = body.note
    await db.commit()
    return {"ok": True}


# Ligar/desligar o WhatsApp exige sessão completa: o WhatsApp não tem âmbito, por isso ligá-lo a partir de uma
# sessão limitada ao streaming (aberta no Jellyfin) dava acesso à faturação de todos os serviços.
@router.post("/whatsapp/link")
async def whatsapp_link(user: User = Depends(require_user), db: AsyncSession = Depends(get_db)):
    s = get_settings()
    if not (s.assistant_ready and s.whatsapp_enabled):
        raise HTTPException(400, detail="O WhatsApp não está disponível.")
    rate_limit(f"wa-link:{user.id}", 5, 3600)
    code = await whatsapp.issue_link_code(db, user)
    await db.commit()
    link = f"https://wa.me/{s.whatsapp_number}?text={code}" if s.whatsapp_number else None
    return {"code": code, "expires_in": int(whatsapp.LINK_TTL.total_seconds()), "wa_link": link}


@router.delete("/whatsapp")
async def whatsapp_unlink(user: User = Depends(require_user), db: AsyncSession = Depends(get_db)):
    for ident in (await db.scalars(select(ChannelIdentity).where(ChannelIdentity.user_id == user.id,
                                                                 ChannelIdentity.channel == "whatsapp"))).all():
        await db.delete(ident)
    audit(db, "assistant.whatsapp_unlinked", actor=user, target_type="user", target_id=user.id)
    await db.commit()
    return {"ok": True}


# =========================================================================== Jellyfin (Custom Pages)
class BridgeChatIn(BaseModel):
    token: str = Field(min_length=16, max_length=128)
    message: str | None = Field(None, max_length=4000)
    conversation_id: str | None = Field(None, max_length=36)
    action_id: str | None = Field(None, max_length=36)
    confirm: bool | None = None


@bridge_router.options("")
async def bridge_preflight(request: Request):
    from ..routers.bridge import _allowed_origin, _cors

    return _cors(Response(status_code=204), _allowed_origin(request))


@bridge_router.post("")
async def bridge_chat(body: BridgeChatIn, request: Request, db: AsyncSession = Depends(get_db)):
    """Chat dentro do Jellyfin. Sem mensagem devolve o histórico; com action_id confirma/cancela uma ação."""
    from ..routers.bridge import _allowed_origin, _cors, _resolve

    origin = _allowed_origin(request)
    user, me, err = await _resolve(db, request, body.token)
    if err is not None:
        return err
    if ((me or {}).get("Policy") or {}).get("IsAdministrator"):
        # O widget não corre para administradores; se um token de admin chegar cá, não o usamos para nada.
        return _cors(JSONResponse({"detail": "Contas de administrador do Jellyfin não usam o assistente aqui."},
                                  status_code=403), origin)
    if user is None:
        return _cors(JSONResponse({"detail": "Esta conta Jellyfin não está ligada ao portal."}, status_code=404),
                     origin)
    if not get_settings().assistant_ready:
        return _cors(JSONResponse({"detail": "O assistente não está ativo."}, status_code=503), origin)
    conv = None
    if body.conversation_id:
        conv = await db.get(AssistantConversation, body.conversation_id)
        if conv is None or conv.user_id != user.id or conv.channel != "jellyfin":
            conv = None
    if body.action_id:
        action = await db.get(PendingAction, body.action_id)
        action_conv = await db.get(AssistantConversation, action.conversation_id) if action else None
        # Só ações preparadas no próprio Jellyfin (âmbito "streaming"): uma ação do chat do portal podia mexer
        # noutros serviços, que a página do Jellyfin não pode gerir.
        if action is None or action.user_id != user.id or action_conv is None or action_conv.channel != "jellyfin":
            return _cors(JSONResponse({"detail": "Pedido não encontrado."}, status_code=404), origin)
        try:
            msg = await runtime.decide_action(db, action, user, confirm=bool(body.confirm))
        except ToolFailure as exc:
            return _cors(JSONResponse({"detail": str(exc)}, status_code=400), origin)
        return _cors(JSONResponse({"conversation_id": action.conversation_id, "messages": [msg_out(msg)]}), origin)
    if not body.message:
        if conv is None:
            conv = await db.scalar(select(AssistantConversation).where(
                AssistantConversation.user_id == user.id, AssistantConversation.channel == "jellyfin",
                AssistantConversation.status.in_(["open", "escalated"]),
                AssistantConversation.updated_at >= utcnow() - timedelta(hours=12))
                .order_by(AssistantConversation.updated_at.desc()).limit(1))
        data = {"conversation_id": conv.id if conv else None,
                "messages": await _conv_messages(db, conv) if conv else []}
        return _cors(JSONResponse(json.loads(json.dumps(data, default=str))), origin)
    rate_limit(f"assistant:{user.id}", 20, 60)
    if conv is None:
        conv = await runtime.get_or_create_conversation(db, user=user, channel="jellyfin", scope="streaming")
    result = await runtime.handle_message(db, conv, user, body.message)
    msgs = await _pending_state(db, [o for m in result.messages if (o := msg_out(m)) is not None])
    return _cors(JSONResponse({"conversation_id": conv.id, "agent": result.agent, "messages": msgs}), origin)


# =========================================================================== webhooks
async def _store_event(db: AsyncSession, provider: str, event_id: str, event_type: str, payload: dict) -> bool:
    if await db.scalar(select(WebhookEvent.id).where(WebhookEvent.provider == provider,
                                                     WebhookEvent.event_id == event_id)):
        return False
    try:
        # Savepoint: numa corrida (dois webhooks iguais ao mesmo tempo) só este evento é desfeito, não os jobs já
        # enfileirados para as mensagens anteriores do mesmo lote.
        async with db.begin_nested():
            db.add(WebhookEvent(provider=provider, event_id=event_id[:128], event_type=event_type[:96],
                                payload=payload, status="processed", processed_at=utcnow()))
    except IntegrityError:
        return False
    return True


@webhook_router.post("/seerr")
async def seerr_webhook(request: Request, db: AsyncSession = Depends(get_db)):
    s = get_settings()
    auth = request.headers.get("authorization") or ""
    if not s.seerr_webhook_secret or not constant_time_eq(auth.removeprefix("Bearer ").strip(), s.seerr_webhook_secret):
        return Response(status_code=401)
    body = await request.body()
    try:
        data = json.loads(body or b"{}")
    except ValueError:
        return Response(status_code=400)
    ntype = str(data.get("notification_type") or "")
    issue = data.get("issue") or {}
    if ntype == "TEST_NOTIFICATION":
        return {"ok": True}
    if ntype not in ("ISSUE_CREATED", "ISSUE_COMMENT") or not issue.get("issue_id"):
        return {"ignored": ntype}
    digest = hashlib.sha256(body).hexdigest()[:24]
    if await _store_event(db, "seerr", f"{ntype}:{issue['issue_id']}:{digest}", ntype, data):
        # Pequeno atraso: dá tempo ao Seerr de gravar o comentário antes de o lermos pela API.
        await enqueue(db, "assistant_seerr", {"issue_id": int(issue["issue_id"]), "event": ntype}, delay_seconds=5,
                      max_attempts=4)
    await db.commit()
    return {"ok": True}


@webhook_router.get("/whatsapp")
async def whatsapp_verify(mode: str = Query("", alias="hub.mode"), token: str = Query("", alias="hub.verify_token"),
                          challenge: str = Query("", alias="hub.challenge")):
    expected = get_settings().whatsapp_cloud_verify_token
    if mode == "subscribe" and expected and constant_time_eq(token, expected):
        return PlainTextResponse(challenge)
    return Response(status_code=403)


async def _queue_inbound(db: AsyncSession, items: list[dict]) -> int:
    n = 0
    for it in items:
        if not it.get("phone") or not it.get("id"):
            continue
        if await _store_event(db, "whatsapp", str(it["id"]), "message", {"phone": it["phone"][-4:]}):
            await enqueue(db, "assistant_whatsapp", it, max_attempts=3)
            n += 1
    await db.commit()
    return n


@webhook_router.post("/whatsapp")
async def whatsapp_cloud(request: Request, db: AsyncSession = Depends(get_db)):
    s = get_settings()
    body = await request.body()
    if s.whatsapp_provider != "cloud" or not whatsapp.CloudAdapter.verify_signature(
            body, request.headers.get("x-hub-signature-256")):
        return Response(status_code=401)
    try:
        data = json.loads(body)
    except ValueError:
        return Response(status_code=400)
    return {"received": await _queue_inbound(db, whatsapp.CloudAdapter.parse(data))}


@webhook_router.post("/evolution")
async def whatsapp_evolution(request: Request, token: str | None = Query(None), db: AsyncSession = Depends(get_db)):
    s = get_settings()
    auth = (request.headers.get("authorization") or "").removeprefix("Bearer ").strip() or token
    if s.whatsapp_provider != "evolution" or not whatsapp.EvolutionAdapter.verify_token(auth):
        return Response(status_code=401)
    try:
        data = json.loads(await request.body())
    except ValueError:
        return Response(status_code=400)
    return {"received": await _queue_inbound(db, whatsapp.EvolutionAdapter.parse(data))}


# =========================================================================== admin
def _agent_or_404(name: str):
    if name not in AGENTS:
        raise HTTPException(404, detail="Agente desconhecido.")
    return AGENTS[name]


@admin_router.get("/overview")
async def overview(db: AsyncSession = Depends(get_db)):
    s = get_settings()
    since = utcnow() - timedelta(days=7)
    by = (await db.execute(select(AssistantConversation.channel, AssistantConversation.agent, func.count())
                           .where(AssistantConversation.created_at >= since)
                           .group_by(AssistantConversation.channel, AssistantConversation.agent))).all()
    fb = dict((await db.execute(select(AssistantMessage.feedback, func.count())
                                .where(AssistantMessage.feedback.is_not(None), AssistantMessage.created_at >= since)
                                .group_by(AssistantMessage.feedback))).all())
    escalated = await db.scalar(select(func.count()).select_from(AssistantConversation)
                                .where(AssistantConversation.status == "escalated"))
    drafts = await db.scalar(select(func.count()).select_from(KnowledgeItem).where(KnowledgeItem.status == "draft"))
    linked = await db.scalar(select(func.count()).select_from(ChannelIdentity)
                             .where(ChannelIdentity.channel == "whatsapp"))
    tokens = (await db.execute(select(func.coalesce(func.sum(AssistantMessage.tokens_in), 0),
                                      func.coalesce(func.sum(AssistantMessage.tokens_out), 0))
                               .where(AssistantMessage.created_at >= since))).one()
    return {
        "config": {"enabled": s.assistant_ready, "model": s.assistant_model, "fast_model": s.assistant_fast_model,
                   "embedding_model": s.assistant_embedding_model, "langfuse": s.assistant_langfuse,
                   "whatsapp": s.whatsapp_provider if s.whatsapp_enabled else None,
                   "bazarr": s.bazarr_enabled, "seerr_webhook": bool(s.seerr_webhook_secret),
                   "seerr_poll": bool(s.seerr_enabled and s.seerr_poll_enabled),
                   "seerr_auto_triage": s.seerr_auto_triage, "jellyfin": s.jellyfin_enabled},
        "last_7_days": {"conversations": [{"channel": c, "agent": a, "count": n} for c, a, n in by],
                        "thumbs_up": fb.get(1, 0), "thumbs_down": fb.get(-1, 0),
                        "tokens_in": int(tokens[0]), "tokens_out": int(tokens[1])},
        "escalated_open": escalated or 0, "knowledge_drafts": drafts or 0, "whatsapp_linked": linked or 0,
    }


@admin_router.get("/agents")
async def agents(db: AsyncSession = Depends(get_db)):
    out = []
    for a in AGENTS.values():
        versions = (await db.scalars(select(AssistantInstruction).where(AssistantInstruction.agent == a.name)
                                     .order_by(AssistantInstruction.version.desc()).limit(20))).all()
        out.append({
            "name": a.name, "label": a.label, "rules": a.rules, "default_instructions": a.default_instructions,
            "instructions": await active_instructions(db, a),
            "versions": [{"id": v.id, "version": v.version, "note": v.note, "active": v.active,
                          "created_by": v.created_by, "created_at": v.created_at.isoformat(),
                          "content": v.content} for v in versions],
            "tools": [{"name": t.name, "description": t.description, "confirm": t.confirm,
                       "channels": list(t.channels) if t.channels else None} for t in a.registry._tools.values()],
            "knowledge": await db.scalar(select(func.count()).select_from(KnowledgeItem).where(
                KnowledgeItem.agent == a.name, KnowledgeItem.status == "active")) or 0,
        })
    return out


class InstructionIn(BaseModel):
    content: str = Field(min_length=1, max_length=20000)
    note: str | None = Field(None, max_length=200)


@admin_router.post("/agents/{agent}/instructions")
async def save_instructions(agent: str, body: InstructionIn, admin: User = Depends(require_admin),
                            db: AsyncSession = Depends(get_db)):
    _agent_or_404(agent)
    last = await db.scalar(select(func.max(AssistantInstruction.version)).where(AssistantInstruction.agent == agent))
    for v in (await db.scalars(select(AssistantInstruction).where(AssistantInstruction.agent == agent,
                                                                  AssistantInstruction.active.is_(True)))).all():
        v.active = False
    row = AssistantInstruction(agent=agent, version=(last or 0) + 1, content=body.content, note=body.note, active=True,
                               created_by=admin.username)
    db.add(row)
    audit(db, "assistant.instructions", actor=admin, target_type="agent", target_id=agent, version=row.version)
    await db.commit()
    return {"ok": True, "version": row.version}


@admin_router.post("/agents/{agent}/instructions/{version_id}/activate")
async def activate_instructions(agent: str, version_id: int, admin: User = Depends(require_admin),
                                db: AsyncSession = Depends(get_db)):
    _agent_or_404(agent)
    row = await db.get(AssistantInstruction, version_id)
    if row is None or row.agent != agent:
        raise HTTPException(404, detail="Versão não encontrada.")
    for v in (await db.scalars(select(AssistantInstruction).where(AssistantInstruction.agent == agent))).all():
        v.active = v.id == row.id
    audit(db, "assistant.instructions_rollback", actor=admin, target_type="agent", target_id=agent,
          version=row.version)
    await db.commit()
    return {"ok": True}


@admin_router.post("/agents/{agent}/instructions/reset")
async def reset_instructions(agent: str, admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    _agent_or_404(agent)
    for v in (await db.scalars(select(AssistantInstruction).where(AssistantInstruction.agent == agent))).all():
        v.active = False
    audit(db, "assistant.instructions_reset", actor=admin, target_type="agent", target_id=agent)
    await db.commit()
    return {"ok": True}


def kb_out(k: KnowledgeItem) -> dict:
    return {"id": k.id, "agent": k.agent, "title": k.title, "content": k.content, "tags": k.tags or [],
            "source": k.source, "status": k.status, "uses": k.uses, "embedded": bool(k.embedding),
            "source_conversation_id": k.source_conversation_id, "created_by": k.created_by,
            "created_at": k.created_at.isoformat(), "updated_at": k.updated_at.isoformat() if k.updated_at else None}


@admin_router.get("/knowledge")
async def kb_list(agent: str | None = None, status: str | None = None, q: str | None = None,
                  db: AsyncSession = Depends(get_db)):
    query = select(KnowledgeItem)
    if agent:
        query = query.where(KnowledgeItem.agent == agent)
    if status:
        query = query.where(KnowledgeItem.status == status)
    else:
        query = query.where(KnowledgeItem.status != "archived")
    rows = list((await db.scalars(query.order_by(KnowledgeItem.updated_at.desc()).limit(500))).all())
    if q:
        terms = knowledge.terms(q)
        rows = [r for r in rows if all(t in knowledge.fold(f"{r.title} {r.content} {' '.join(r.tags or [])}")
                                       for t in terms)]
    return [kb_out(r) for r in rows]


class KnowledgeIn(BaseModel):
    agent: str = Field(pattern="^(billing|support)$")
    title: str = Field(min_length=3, max_length=200)
    content: str = Field(min_length=3, max_length=8000)
    tags: list[str] = Field(default_factory=list, max_length=12)
    status: str = Field("active", pattern="^(active|draft|archived)$")


@admin_router.post("/knowledge")
async def kb_create(body: KnowledgeIn, admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    item = KnowledgeItem(agent=body.agent, title=body.title, content=body.content, tags=body.tags,
                         status=body.status, source="manual", created_by=admin.username)
    db.add(item)
    await knowledge.embed_item(item)
    audit(db, "assistant.knowledge_create", actor=admin, target_type="knowledge", agent=body.agent, title=body.title)
    await db.commit()
    return kb_out(item)


@admin_router.put("/knowledge/{item_id}")
async def kb_update(item_id: int, body: KnowledgeIn, admin: User = Depends(require_admin),
                    db: AsyncSession = Depends(get_db)):
    item = await db.get(KnowledgeItem, item_id)
    if item is None:
        raise HTTPException(404, detail="Artigo não encontrado.")
    changed = (item.title, item.content) != (body.title, body.content)
    item.agent, item.title, item.content, item.tags, item.status = (body.agent, body.title, body.content, body.tags,
                                                                    body.status)
    if changed or not item.embedding:
        item.embedding = None
        await knowledge.embed_item(item)
    audit(db, "assistant.knowledge_update", actor=admin, target_type="knowledge", target_id=item.id)
    await db.commit()
    return kb_out(item)


@admin_router.delete("/knowledge/{item_id}")
async def kb_delete(item_id: int, admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    item = await db.get(KnowledgeItem, item_id)
    if item is None:
        raise HTTPException(404, detail="Artigo não encontrado.")
    await db.delete(item)
    audit(db, "assistant.knowledge_delete", actor=admin, target_type="knowledge", target_id=item_id)
    await db.commit()
    return {"ok": True}


@admin_router.post("/knowledge/reindex")
async def kb_reindex(db: AsyncSession = Depends(get_db)):
    n = 0
    for item in (await db.scalars(select(KnowledgeItem).where(KnowledgeItem.status == "active"))).all():
        await knowledge.embed_item(item)
        n += bool(item.embedding)
    await db.commit()
    return {"embedded": n}


@admin_router.get("/conversations")
async def admin_conversations(status: str | None = None, agent: str | None = None, channel: str | None = None,
                              negative: bool = False, user_id: str | None = None, page: int = Query(1, ge=1),
                              db: AsyncSession = Depends(get_db)):
    q = select(AssistantConversation, User.username).outerjoin(User, User.id == AssistantConversation.user_id)
    if status:
        q = q.where(AssistantConversation.status == status)
    if agent:
        q = q.where(AssistantConversation.agent == agent)
    if channel:
        q = q.where(AssistantConversation.channel == channel)
    if user_id:
        q = q.where(AssistantConversation.user_id == user_id)
    if negative:
        q = q.where(AssistantConversation.id.in_(select(AssistantMessage.conversation_id)
                                                 .where(AssistantMessage.feedback == -1)))
    rows = (await db.execute(q.order_by(AssistantConversation.updated_at.desc()).offset((page - 1) * 50)
                             .limit(50))).all()
    out = []
    for c, username in rows:
        n = await db.scalar(select(func.count()).select_from(AssistantMessage).where(
            AssistantMessage.conversation_id == c.id, AssistantMessage.role == "user"))
        neg = await db.scalar(select(func.count()).select_from(AssistantMessage).where(
            AssistantMessage.conversation_id == c.id, AssistantMessage.feedback == -1))
        out.append({**conv_out(c), "username": username, "user_messages": n or 0, "negative": neg or 0,
                    "escalation": (c.meta or {}).get("escalation"), "admin_note": c.admin_note})
    return out


@admin_router.get("/conversations/{conv_id}")
async def admin_conversation(conv_id: str, db: AsyncSession = Depends(get_db)):
    conv = await db.get(AssistantConversation, conv_id)
    if conv is None:
        raise HTTPException(404, detail="Conversa não encontrada.")
    user = await db.get(User, conv.user_id) if conv.user_id else None
    actions = (await db.scalars(select(PendingAction).where(PendingAction.conversation_id == conv.id)
                                .order_by(PendingAction.created_at))).all()
    return {**conv_out(conv), "username": user.username if user else None, "user_id": conv.user_id,
            "external_ref": conv.external_ref if conv.channel == "seerr" else (
                whatsapp.mask(conv.external_ref) if conv.external_ref else None),
            "meta": conv.meta, "admin_note": conv.admin_note, "reviewed": conv.reviewed,
            "messages": await _conv_messages(db, conv, admin=True),
            "actions": [{"id": a.id, "tool": a.tool, "summary": a.summary, "status": a.status, "result": a.result,
                         "created_at": a.created_at.isoformat()} for a in actions]}


class ConvPatch(BaseModel):
    status: str | None = Field(None, pattern="^(open|escalated|resolved|closed)$")
    admin_note: str | None = Field(None, max_length=4000)


@admin_router.patch("/conversations/{conv_id}")
async def admin_conv_patch(conv_id: str, body: ConvPatch, admin: User = Depends(require_admin),
                           db: AsyncSession = Depends(get_db)):
    conv = await db.get(AssistantConversation, conv_id)
    if conv is None:
        raise HTTPException(404, detail="Conversa não encontrada.")
    if body.status:
        conv.status = body.status
        if body.status == "resolved":
            conv.resolved_at = utcnow()
    if body.admin_note is not None:
        conv.admin_note = body.admin_note or None
        conv.reviewed = False  # uma nota nova volta a poder gerar conhecimento
    audit(db, "assistant.conversation_update", actor=admin, target_type="conversation", target_id=conv.id,
          status=body.status)
    await db.commit()
    return {"ok": True}


@admin_router.post("/conversations/{conv_id}/suggest")
async def admin_suggest(conv_id: str, db: AsyncSession = Depends(get_db)):
    _ready()
    conv = await db.get(AssistantConversation, conv_id)
    if conv is None:
        raise HTTPException(404, detail="Conversa não encontrada.")
    items = await learning.suggest_from_conversation(db, conv)
    await db.commit()
    return [kb_out(i) for i in items]


class PromoteIn(BaseModel):
    title: str | None = Field(None, max_length=200)
    content: str | None = Field(None, max_length=8000)


@admin_router.post("/messages/{message_id}/promote")
async def admin_promote(message_id: int, body: PromoteIn, admin: User = Depends(require_admin),
                        db: AsyncSession = Depends(get_db)):
    m = await db.get(AssistantMessage, message_id)
    if m is None or m.role != "assistant" or not m.content:
        raise HTTPException(404, detail="Mensagem não encontrada.")
    item = await learning.promote(db, m, title=body.title, content=body.content, admin=admin.username)
    audit(db, "assistant.knowledge_promote", actor=admin, target_type="message", target_id=m.id)
    await db.commit()
    return kb_out(item)
