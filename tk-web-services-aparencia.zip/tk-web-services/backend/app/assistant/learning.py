"""Aprendizagem supervisionada.

Os agentes melhoram de três formas, todas visíveis e reversíveis no painel:
  1. Factos vivos: produtos, planos, preços, regras de cobrança e integrações ativas são lidos a cada conversa —
     um serviço novo fica conhecido sem mexer em nada.
  2. Conhecimento promovido: o admin transforma uma boa resposta (ou a correção de uma má) num artigo.
  3. Sugestões automáticas: conversas escaladas/resolvidas ou com 👎 são resumidas pelo modelo em rascunhos de
     artigo, que só entram em uso depois de o admin aprovar (evita que o agente "aprenda" um erro).
"""
from __future__ import annotations

import json
import logging
from datetime import timedelta

from sqlalchemy import and_, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..db import utcnow
from .knowledge import embed_item
from .llm import LLMError, get_llm
from .models import AssistantConversation, AssistantMessage, KnowledgeItem, PendingAction

log = logging.getLogger("tkportal.assistant.learning")

PROMPT = """Analisa esta conversa de apoio ao cliente do agente "{agent}" de um serviço de streaming.
Se ela contém conhecimento REUTILIZÁVEL (um procedimento, uma resposta correta a uma dúvida frequente, a correção
de um erro do agente, ou uma nota do administrador), escreve um artigo curto para a base de conhecimento DESTE
agente. Não incluas dados pessoais (nomes, emails, valores de uma conta concreta, números de telefone).
{scope_rule}
Responde só com JSON: {{"useful": true|false, "title": "...", "content": "...", "tags": ["..."]}}"""

SCOPE_RULE = {
    "billing": "O artigo só pode falar de faturação/pagamentos/planos — nunca de funcionalidades do streaming.",
    "support": "O artigo só pode falar de suporte técnico/uso do serviço — nunca de preços ou pagamentos.",
}


def _transcript(msgs: list[AssistantMessage], note: str | None) -> str:
    lines = []
    for m in msgs:
        if m.role == "user" and not (m.ui or {}).get("hidden"):
            lines.append(f"Cliente: {m.content}")
        elif m.role == "assistant" and m.content:
            fb = " [👎 cliente]" if m.feedback == -1 else (" [👍 cliente]" if m.feedback == 1 else "")
            lines.append(f"Agente: {m.content}{fb}" + (f" (nota: {m.feedback_note})" if m.feedback_note else ""))
        elif m.role == "tool":
            lines.append(f"(ferramenta {m.tool_name}: {(m.content or '')[:300]})")
    if note:
        lines.append(f"Nota do administrador: {note}")
    return "\n".join(lines)[-12000:]


async def suggest_from_conversation(db: AsyncSession, conv: AssistantConversation) -> list[KnowledgeItem]:
    out = []
    for agent in ("billing", "support"):
        msgs = list((await db.scalars(select(AssistantMessage).where(
            AssistantMessage.conversation_id == conv.id, AssistantMessage.agent == agent)
            .order_by(AssistantMessage.id))).all())
        if not any(m.role == "user" for m in msgs):
            continue
        try:
            resp = await get_llm().complete([
                {"role": "system", "content": PROMPT.format(agent=agent, scope_rule=SCOPE_RULE[agent])},
                {"role": "user", "content": _transcript(msgs, conv.admin_note)},
            ], fast=True, json_mode=True)
            data = json.loads((resp.content or "{}").strip().removeprefix("```json").removesuffix("```"))
        except (LLMError, json.JSONDecodeError, AttributeError) as exc:
            log.info("Sugestão de conhecimento falhou (%s): %s", conv.id, exc)
            continue
        if not data.get("useful") or not data.get("title") or not data.get("content"):
            continue
        item = KnowledgeItem(agent=agent, title=str(data["title"])[:200], content=str(data["content"])[:4000],
                             tags=[str(t)[:40] for t in (data.get("tags") or [])][:8], source="suggested",
                             status="draft", source_conversation_id=conv.id)
        db.add(item)
        out.append(item)
    conv.reviewed = True
    return out


async def run(db: AsyncSession, limit: int = 20) -> int:
    """Conversas paradas há >1h, ainda não revistas, que valem a pena (escaladas, resolvidas, com feedback)."""
    idle = utcnow() - timedelta(hours=1)
    has_feedback = select(AssistantMessage.conversation_id).where(AssistantMessage.feedback.is_not(None))
    convs = (await db.scalars(select(AssistantConversation).where(
        AssistantConversation.reviewed.is_(False), AssistantConversation.updated_at <= idle,
        or_(AssistantConversation.status.in_(["escalated", "resolved"]),
            AssistantConversation.admin_note.is_not(None),
            AssistantConversation.id.in_(has_feedback)))
        .order_by(AssistantConversation.updated_at).limit(limit))).all()
    n = 0
    for conv in convs:
        n += len(await suggest_from_conversation(db, conv))
        await db.commit()
    return n


async def promote(db: AsyncSession, message: AssistantMessage, *, title: str | None, content: str | None,
                  admin: str) -> KnowledgeItem:
    """Transforma uma resposta (possivelmente corrigida pelo admin) num artigo ativo."""
    question = await db.scalar(select(AssistantMessage).where(
        AssistantMessage.conversation_id == message.conversation_id, AssistantMessage.id < message.id,
        AssistantMessage.role == "user").order_by(AssistantMessage.id.desc()).limit(1))
    q = (question.content if question else "") or ""
    q = q.split("\n\n[Nota interna")[0]
    item = KnowledgeItem(agent=message.agent, title=(title or q or "Resposta aprovada")[:200],
                         content=(content or f"Pergunta: {q}\nResposta aprovada: {message.content}")[:4000],
                         source="promoted", status="active", source_conversation_id=message.conversation_id,
                         created_by=admin)
    db.add(item)
    await embed_item(item)
    return item


async def expire_actions(db: AsyncSession) -> int:
    rows = (await db.scalars(select(PendingAction).where(and_(PendingAction.status == "pending",
                                                              PendingAction.expires_at <= utcnow())))).all()
    for a in rows:
        a.status = "expired"
    await db.commit()
    return len(rows)
