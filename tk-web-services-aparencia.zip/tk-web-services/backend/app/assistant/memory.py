"""Memória de longo prazo dos assistentes: cada agente lembra-se das conversas anteriores com cada cliente.

Separação (como no resto do runtime): a memória é por (cliente, agente). O Agente de Faturação só vê o que ele próprio
conversou com o cliente e o de Suporte idem — nunca a memória nem as mensagens do outro.

Como funciona:
  * depois de cada conversa (10 min sem mensagens), um job resume as mensagens novas desse agente com o cliente e
    junta-as à memória (modelo rápido, sem dados sensíveis);
  * no início de cada resposta o agente recebe essa memória e, enquanto o resumo não corre, os últimos excertos das
    conversas anteriores com ele;
  * o cliente pode pedir para esquecer (Ajuda → "Esquecer conversas anteriores").
"""
from __future__ import annotations

import logging

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from ..db import utcnow
from ..services.jobs import enqueue, job_handler
from .models import AssistantConversation, AssistantMemory, AssistantMessage

log = logging.getLogger("tkportal.assistant.memory")

MAX_SUMMARY = 1500
RECENT_EXCERPTS = 8
DELAY_SECONDS = 600


def _hidden(m: AssistantMessage) -> bool:
    return bool((m.ui or {}).get("hidden"))


async def _messages_after(db: AsyncSession, user_id: str, agent: str, after_id: int, *, exclude_conv: str | None,
                          limit: int, newest_first: bool) -> list[AssistantMessage]:
    q = (select(AssistantMessage).join(AssistantConversation,
                                       AssistantConversation.id == AssistantMessage.conversation_id)
         .where(AssistantConversation.user_id == user_id, AssistantMessage.agent == agent,
                AssistantMessage.role.in_(["user", "assistant"]), AssistantMessage.content.is_not(None),
                AssistantMessage.id > after_id))
    if exclude_conv:
        q = q.where(AssistantMessage.conversation_id != exclude_conv)
    q = q.order_by(AssistantMessage.id.desc() if newest_first else AssistantMessage.id).limit(limit)
    return [m for m in (await db.scalars(q)).all() if not _hidden(m)]


def _line(m: AssistantMessage, width: int = 400) -> str:
    who = "Cliente" if m.role == "user" else "Tu"
    text = " ".join((m.content or "").split())
    return f"{who}: {text[:width]}{'…' if len(text) > width else ''}"


async def context_for(db: AsyncSession, conv: AssistantConversation, agent: str) -> str:
    """Texto para o prompt de sistema: memória deste agente sobre o cliente + excertos ainda não resumidos."""
    if not conv.user_id:
        return ""
    mem = await db.scalar(select(AssistantMemory).where(AssistantMemory.user_id == conv.user_id,
                                                        AssistantMemory.agent == agent))
    parts: list[str] = []
    if mem and mem.summary.strip():
        parts.append("O que sabes deste cliente das conversas anteriores contigo:\n" + mem.summary.strip())
    recent = await _messages_after(db, conv.user_id, agent, mem.last_message_id if mem else 0, exclude_conv=conv.id,
                                   limit=RECENT_EXCERPTS, newest_first=True)
    if recent:
        recent.reverse()
        parts.append("Últimas mensagens de conversas anteriores contigo (mais antigas primeiro):\n"
                     + "\n".join(_line(m) for m in recent))
    if not parts:
        return ""
    return ("Memória (só tua — usa-a para dar continuidade, sem a repetir ao cliente; se ele contradisser algo, "
            "vale o que diz agora):\n\n" + "\n\n".join(parts))


async def schedule(db: AsyncSession, user_id: str | None, agents: set[str]) -> None:
    if not user_id:
        return
    for agent in agents:
        await enqueue(db, "assistant_memory", {"user_id": user_id, "agent": agent},
                      dedupe_key=f"memory:{user_id}:{agent}", delay_seconds=DELAY_SECONDS, max_attempts=3)


SUMMARY_PROMPT = """És o módulo de memória do {label} da TK Web Services. Atualiza as notas que este agente guarda sobre
UM cliente, juntando a memória atual com as conversas novas.

Guarda só o que ajuda a continuar a conversa numa próxima vez: preferências, aparelhos e apps que usa, problemas
recorrentes e como se resolveram, pedidos ou promessas por cumprir, decisões tomadas, tom preferido.
Nunca guardes passwords, códigos, IBAN, números de cartão, tokens ou links com segredos.
Escreve em português de Portugal, em tópicos curtos ("- ..."), no máximo {max_chars} caracteres. Remove o que já não
interessa. Responde só com as notas."""


@job_handler("assistant_memory")
async def update_memory(db: AsyncSession, payload: dict) -> None:
    from .agents import get_agent
    from .llm import LLMError, get_llm

    if not get_settings().assistant_ready:
        return
    user_id, agent = payload["user_id"], payload["agent"]
    mem = await db.scalar(select(AssistantMemory).where(AssistantMemory.user_id == user_id,
                                                        AssistantMemory.agent == agent))
    new = await _messages_after(db, user_id, agent, mem.last_message_id if mem else 0, exclude_conv=None,
                                limit=200, newest_first=False)
    if not new:
        return
    transcript, total = [], 0
    for m in new:
        line = _line(m, 600)
        total += len(line)
        if total > 14000:
            break
        transcript.append(line)
    label = get_agent(agent).label
    try:
        resp = await get_llm().complete([
            {"role": "system", "content": SUMMARY_PROMPT.format(label=f"Agente de {label}", max_chars=MAX_SUMMARY)},
            {"role": "user", "content": f"Memória atual:\n{(mem.summary if mem else '') or '(vazia)'}\n\n"
                                        f"Conversas novas:\n" + "\n".join(transcript)},
        ], fast=True, metadata={"trace_name": f"assistant-memory-{agent}", "trace_user_id": user_id})
    except LLMError as exc:
        log.info("Memória do agente %s não atualizada: %s", agent, exc)
        return
    summary = (resp.content or "").strip()[:MAX_SUMMARY]
    if mem is None:
        mem = AssistantMemory(user_id=user_id, agent=agent, summary="", last_message_id=0)
        db.add(mem)
    if summary:
        mem.summary = summary
    mem.last_message_id = new[-1].id
    mem.updated_at = utcnow()


async def forget(db: AsyncSession, user_id: str) -> None:
    """O cliente pede para esquecer: memória apagada e conversas anteriores deixam de ser usadas como contexto."""
    from .agents import AGENTS

    last = int(await db.scalar(select(func.coalesce(func.max(AssistantMessage.id), 0)).join(
        AssistantConversation, AssistantConversation.id == AssistantMessage.conversation_id).where(
        AssistantConversation.user_id == user_id)) or 0)
    for agent in AGENTS:
        mem = await db.scalar(select(AssistantMemory).where(AssistantMemory.user_id == user_id,
                                                            AssistantMemory.agent == agent))
        if mem is None:
            db.add(AssistantMemory(user_id=user_id, agent=agent, summary="", last_message_id=last))
        else:
            mem.summary, mem.last_message_id = "", last


async def summary_for(db: AsyncSession, user_id: str) -> dict[str, str]:
    rows = (await db.scalars(select(AssistantMemory).where(AssistantMemory.user_id == user_id))).all()
    return {m.agent: m.summary for m in rows if m.summary}
