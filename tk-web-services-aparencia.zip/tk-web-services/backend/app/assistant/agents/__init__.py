"""Registo dos agentes. Adicionar um agente novo = um módulo com AGENT e uma entrada aqui."""
from __future__ import annotations

from .base import Agent
from .billing import AGENT as BILLING
from .support import AGENT as SUPPORT

AGENTS: dict[str, Agent] = {"billing": BILLING, "support": SUPPORT}


def get_agent(name: str) -> Agent:
    return AGENTS.get(name) or SUPPORT
