"""Agente de Suporte TKFLIX — Jellyfin, legendas (Bazarr), reprodução, dispositivos, pedidos e issues do Seerr.

Não tem nenhuma ferramenta de faturação: não vê preços, cobranças nem métodos de pagamento. Sobre a conta só
sabe se o streaming está ativo; se não estiver por causa de pagamentos, transfere para a Faturação.
"""
from __future__ import annotations

import base64
import json
import logging
from datetime import timedelta

from sqlalchemy import func, select

from ...config import get_settings
from ...db import utcnow
from ...features import PlanFeatures
from ...integrations.bazarr import BazarrClient, BazarrError
from ...integrations.jellyfin import JellyfinClient, JellyfinError
from ...integrations.seerr import SeerrClient, SeerrError
from ...models import AuditLog, Plan, Product, ServiceAccount, Subscription, SubStatus
from ...services.audit import audit
from ...services.subscriptions import fmt_date
from ..tools import ToolContext, ToolFailure, ToolRegistry, obj
from .base import COMMON_RULES, Agent, add_common_tools

log = logging.getLogger("tkportal.assistant.support")

reg = ToolRegistry("support")
add_common_tools(reg, other="billing", other_label="Agente de Faturação (pagamentos, planos, preços, faturas)")

ISO3 = {"pt": "por", "pb": "por", "en": "eng", "es": "spa", "fr": "fre", "de": "ger", "it": "ita", "nl": "dut",
        "ru": "rus", "ja": "jpn", "ko": "kor", "zh": "chi", "ar": "ara", "pl": "pol", "sv": "swe", "tr": "tur"}
ISO2 = {v: k for k, v in ISO3.items()} | {"por": "pt", "fra": "fr", "deu": "de", "nld": "nl", "zho": "zh"}
LANG_NAMES = {"pt": "português", "pb": "português do Brasil", "en": "inglês", "es": "espanhol", "fr": "francês"}
DAILY_SUBTITLE_ACTIONS = 25

RULES = COMMON_RULES + """
És o **Agente de Suporte da TKFLIX** (streaming em Jellyfin). Ajudas com: encontrar conteúdos, problemas de
reprodução (buffering, qualidade, transcodificação, áudio), legendas (procurar, descarregar, sincronizar, ativar a
descarga automática), apps e dispositivos (instalação, Quick Connect para entrar na TV), pedidos de filmes/séries e
issues no Seerr, e dúvidas gerais sobre como usar o serviço.

É PROIBIDO falares de preços, pagamentos, faturas, planos, subscrições ou métodos de pagamento — nem para dar uma
ideia. Nesses casos (incluindo "a minha conta está suspensa por falta de pagamento") usa transfer_to_billing.

Método de trabalho:
1. Identifica o título exato com find_title antes de mexer em legendas ou diagnosticar (confirma com o cliente se
   houver várias correspondências — ano, temporada, episódio).
2. Legendas dessincronizadas → sync_subtitles no idioma em causa. Legendas em falta → search_subtitles e
   download_subtitle (escolhe a de melhor pontuação que corresponda à versão; se o cliente não disser o idioma,
   usa o primeiro idioma preferido). Depois de descarregar/sincronizar, diz ao cliente para fechar e reabrir o
   vídeo (e escolher a legenda no menu).
3. Reprodução → playback_diagnostics. Transcodificação por "ContainerNotSupported"/"VideoCodecNotSupported" ou
   largura de banda indica limitação do dispositivo/rede: sugere a app recomendada ou uma qualidade mais baixa.
4. Se não conseguires resolver com as ferramentas, usa report_issue (fica registado no Seerr) ou escalate_to_human.
"""

DEFAULT_INSTRUCTIONS = """\
- Apps recomendadas: Android/Google TV/Fire TV → app oficial Jellyfin (ou Findroid); iPhone/iPad/Apple TV →
  Swiftfin ou Infuse; Smart TV Samsung/LG → app Jellyfin da loja da TV; computador → o browser.
- Para entrar numa TV sem escrever a password, usa Quick Connect: na TV escolhe "Quick Connect", aparece um código
  de 6 caracteres, e o cliente dá-te esse código.
- Idiomas de legendas por omissão: português, depois inglês.
"""


# =========================================================================== utilitários
async def _jf_user_id(ctx: ToolContext) -> str:
    user = ctx.require_user()
    sa = await ctx.db.scalar(select(ServiceAccount).where(ServiceAccount.user_id == user.id,
                                                          ServiceAccount.service == "jellyfin"))
    if sa is None or not sa.external_id:
        raise ToolFailure("Esta conta ainda não tem utilizador no Jellyfin (streaming inativo). Se o cliente tem "
                          "subscrição, escala para um humano.")
    return sa.external_id


def _jf() -> JellyfinClient:
    if not get_settings().jellyfin_enabled:
        raise ToolFailure("O Jellyfin não está configurado no portal.")
    return JellyfinClient(timeout=30)


def _label(it: dict) -> str:
    if it.get("Type") == "Episode":
        return (f"{it.get('SeriesName')} T{it.get('ParentIndexNumber', '?')}E{it.get('IndexNumber', '?')} — "
                f"{it.get('Name')}")
    year = f" ({it.get('ProductionYear')})" if it.get("ProductionYear") else ""
    return f"{it.get('Name')}{year}"


async def _item(ctx: ToolContext, item_id: str) -> tuple[str, dict]:
    uid = await _jf_user_id(ctx)
    item_id = str(item_id or "").strip()
    if not item_id:
        raise ToolFailure("Falta o item_id (usa find_title).")
    try:
        it = await _jf().get_item(uid, item_id)
    except JellyfinError as exc:
        raise ToolFailure(f"Jellyfin indisponível: {exc}") from exc
    if it is None:
        raise ToolFailure("Não encontrei esse título na biblioteca deste cliente.")
    return uid, it


def _lang2(language: str | None) -> str:
    lang = (language or "").strip().lower()
    if not lang:
        return get_settings().subtitle_languages[0] if get_settings().subtitle_languages else "pt"
    if lang in ("pt-br", "ptbr", "brasileiro", "br"):
        return "pb"
    if lang in ("portugues", "português", "pt-pt"):
        return "pt"
    if lang in ("ingles", "inglês", "english"):
        return "en"
    if len(lang) == 3:
        return ISO2.get(lang, lang[:2])
    return lang[:2]


async def _quota(ctx: ToolContext) -> None:
    user = ctx.require_user()
    n = await ctx.db.scalar(select(func.count()).select_from(AuditLog).where(
        AuditLog.actor_id == user.id, AuditLog.action.like("assistant.subtitle%"),
        AuditLog.created_at >= utcnow() - timedelta(days=1)))
    if (n or 0) >= DAILY_SUBTITLE_ACTIONS:
        raise ToolFailure("Limite diário de ações de legendas atingido. Sugere tentar amanhã ou escalar.")


async def _bazarr_target(it: dict) -> tuple[str, dict] | None:
    """(tipo, registo do Bazarr) para um item do Jellyfin, ou None se o Bazarr não o conhecer."""
    if not get_settings().bazarr_enabled:
        return None
    bz = BazarrClient()
    prov = {k.lower(): v for k, v in (it.get("ProviderIds") or {}).items()}
    path = it.get("Path") or next((s.get("Path") for s in it.get("MediaSources") or [] if s.get("Path")), None)
    try:
        if it.get("Type") == "Movie":
            m = await bz.find_movie(imdb=prov.get("imdb"), path=path)
            return ("movie", m) if m else None
        if it.get("Type") == "Episode":
            series = None
            if it.get("SeriesId"):
                try:
                    series = await _jf().get_item(str(it.get("_uid")), it["SeriesId"]) if it.get("_uid") else None
                except JellyfinError:
                    series = None
            sprov = {k.lower(): v for k, v in ((series or {}).get("ProviderIds") or {}).items()}
            ep = await bz.find_episode(series_tvdb=sprov.get("tvdb"), series_imdb=sprov.get("imdb"),
                                       season=it.get("ParentIndexNumber"), episode=it.get("IndexNumber"), path=path)
            return ("episode", ep) if ep else None
    except BazarrError as exc:
        log.warning("Bazarr: %s", exc)
        raise ToolFailure(f"O Bazarr não respondeu: {exc}") from exc
    return None


def _encode(data: dict) -> str:
    return base64.urlsafe_b64encode(json.dumps(data, separators=(",", ":")).encode()).decode().rstrip("=")


def _decode(token: str) -> dict:
    try:
        pad = "=" * (-len(token) % 4)
        return json.loads(base64.urlsafe_b64decode(token + pad))
    except (ValueError, json.JSONDecodeError) as exc:
        raise ToolFailure("option_id inválido — usa um id devolvido por search_subtitles.") from exc


# =========================================================================== conteúdos
@reg.tool("find_title", "Procura filmes, séries ou episódios na biblioteca do cliente. Devolve item_id.",
          obj({"query": {"type": "string", "description": "Título (e ano, se souberes)."},
               "kind": {"type": "string", "enum": ["any", "movie", "series", "episode"]}}, ["query"]))
async def find_title(ctx: ToolContext, args: dict):
    uid = await _jf_user_id(ctx)
    types = {"movie": "Movie", "series": "Series", "episode": "Episode"}.get(str(args.get("kind")),
                                                                           "Movie,Series,Episode")
    try:
        items = await _jf().search_items(uid, str(args.get("query") or "")[:100], types=types)
    except JellyfinError as exc:
        raise ToolFailure(f"Jellyfin indisponível: {exc}") from exc
    if not items:
        return ("Não está na biblioteca. Se o cliente quer este título, sugere pedi-lo no Seerr "
                f"({get_settings().seerr_public_url or 'app de pedidos'}).")
    return [{"item_id": it["Id"], "type": it.get("Type"), "title": _label(it)} for it in items]


@reg.tool("find_episode", "Encontra o item_id de um episódio a partir da série, temporada e número.",
          obj({"series_item_id": {"type": "string"}, "season": {"type": "integer"}, "episode": {"type": "integer"}},
              ["series_item_id", "season", "episode"]))
async def find_episode(ctx: ToolContext, args: dict):
    uid = await _jf_user_id(ctx)
    try:
        eps = await _jf().episodes(uid, str(args["series_item_id"]), int(args["season"]))
    except (JellyfinError, KeyError, ValueError) as exc:
        raise ToolFailure(f"Não consegui listar os episódios: {exc}") from exc
    for ep in eps:
        if ep.get("IndexNumber") == int(args["episode"]):
            return {"item_id": ep["Id"], "title": _label(ep)}
    return f"Essa temporada tem {len(eps)} episódios na biblioteca; o episódio pedido não está lá."


@reg.tool("title_details",
          "Detalhes técnicos de um título: faixas de áudio e de legendas (idioma, externa/embutida, forçada), vídeo "
          "(resolução, codec, HDR) e se o Bazarr o conhece.", obj({"item_id": {"type": "string"}}, ["item_id"]))
async def title_details(ctx: ToolContext, args: dict):
    uid, it = await _item(ctx, str(args.get("item_id")))
    it["_uid"] = uid
    streams = it.get("MediaStreams") or []
    video = next((s for s in streams if s.get("Type") == "Video"), {})
    out = {
        "title": _label(it), "type": it.get("Type"),
        "video": {"resolution": f"{video.get('Width')}x{video.get('Height')}" if video.get("Width") else None,
                  "codec": video.get("Codec"), "hdr": video.get("VideoRangeType") or video.get("VideoRange"),
                  "bitrate_mbps": round((video.get("BitRate") or 0) / 1_000_000, 1) or None},
        "audio": [{"language": s.get("Language"), "codec": s.get("Codec"), "channels": s.get("Channels"),
                   "title": s.get("DisplayTitle")} for s in streams if s.get("Type") == "Audio"],
        "subtitles": [{"language": s.get("Language"), "external": bool(s.get("IsExternal")),
                       "forced": bool(s.get("IsForced")), "hearing_impaired": bool(s.get("IsHearingImpaired")),
                       "format": s.get("Codec"), "title": s.get("DisplayTitle")}
                      for s in streams if s.get("Type") == "Subtitle"],
        "container": (it.get("MediaSources") or [{}])[0].get("Container"),
    }
    if get_settings().bazarr_enabled and it.get("Type") in ("Movie", "Episode"):
        try:
            target = await _bazarr_target(it)
        except ToolFailure:
            target = None
        out["bazarr"] = "conhecido" if target else "não encontrado no Bazarr (sincronização indisponível)"
        if target:
            out["bazarr_subtitles"] = [{"language": s.get("code2"), "forced": s.get("forced"), "hi": s.get("hi"),
                                        "has_file": bool(s.get("path"))} for s in target[1].get("subtitles") or []]
            out["bazarr_missing"] = [s.get("code2") for s in target[1].get("missing_subtitles") or []]
    return out


# =========================================================================== legendas
@reg.tool("search_subtitles",
          "Procura legendas para um filme/episódio num idioma (via Bazarr, ou pelos fornecedores do Jellyfin). "
          "Devolve opções com option_id para download_subtitle.",
          obj({"item_id": {"type": "string"},
               "language": {"type": "string", "description": "Código ISO 639-1 (pt, en, pb para pt-BR, ...)."}},
              ["item_id"]))
async def search_subtitles(ctx: ToolContext, args: dict):
    uid, it = await _item(ctx, str(args.get("item_id")))
    it["_uid"] = uid
    lang = _lang2(args.get("language"))
    target = await _bazarr_target(it) if it.get("Type") in ("Movie", "Episode") else None
    options = []
    if target:
        kind, rec = target
        bz = BazarrClient()
        try:
            found = await (bz.search_movie(int(rec["radarrId"])) if kind == "movie"
                           else bz.search_episode(int(rec["sonarrEpisodeId"])))
        except BazarrError as exc:
            raise ToolFailure(f"O Bazarr não respondeu: {exc}") from exc
        for sub in found:
            sl = str(sub.get("language") or "").lower()
            if not sl.startswith(lang):
                continue
            options.append({
                "option_id": _encode({"b": kind, "r": rec.get("radarrId"), "s": rec.get("sonarrSeriesId"),
                                      "e": rec.get("sonarrEpisodeId"), "p": sub.get("provider"),
                                      "i": sub.get("subtitle"), "hi": bool(sub.get("hearing_impaired")),
                                      "f": bool(sub.get("forced")), "o": bool(sub.get("original_format"))}),
                "provider": sub.get("provider"), "score": sub.get("score"),
                "release": (sub.get("release_info") or [None])[0] if isinstance(sub.get("release_info"), list)
                else sub.get("release_info"),
                "hearing_impaired": bool(sub.get("hearing_impaired")), "forced": bool(sub.get("forced"))})
    else:
        try:
            found = await _jf().remote_subtitles(it["Id"], ISO3.get(lang, lang))
        except JellyfinError as exc:
            raise ToolFailure(f"Pesquisa de legendas falhou: {exc}") from exc
        for sub in found:
            options.append({"option_id": _encode({"j": sub.get("Id")}), "provider": sub.get("ProviderName"),
                            "score": sub.get("CommunityRating") or sub.get("DownloadCount"),
                            "release": sub.get("Name"), "hearing_impaired": bool(sub.get("HearingImpaired")),
                            "forced": bool(sub.get("IsForced"))})
    options.sort(key=lambda o: float(o.get("score") or 0), reverse=True)
    if not options:
        return f"Não há legendas em {LANG_NAMES.get(lang, lang)} nos fornecedores. Sugere report_issue ou tentar mais tarde."
    return {"language": lang, "options": options[:6], "title": _label(it)}


@reg.tool("download_subtitle", "Descarrega uma legenda escolhida de search_subtitles para o título.",
          obj({"item_id": {"type": "string"}, "option_id": {"type": "string"}}, ["item_id", "option_id"]))
async def download_subtitle(ctx: ToolContext, args: dict):
    await _quota(ctx)
    uid, it = await _item(ctx, str(args.get("item_id")))
    it["_uid"] = uid
    opt = _decode(str(args.get("option_id") or ""))
    if "j" not in opt:
        # O option_id vem do modelo: os ids do Bazarr têm de ser os DESTE item (que o cliente pode ver), senão
        # um option_id forjado descarregava legendas para outro título.
        target = await _bazarr_target(it) if it.get("Type") in ("Movie", "Episode") else None
        rec = target[1] if target else {}
        same = target is not None and opt.get("b") == target[0] and (
            str(opt.get("r")) == str(rec.get("radarrId")) if target[0] == "movie" else
            (str(opt.get("s")), str(opt.get("e"))) == (str(rec.get("sonarrSeriesId")), str(rec.get("sonarrEpisodeId"))))
        if not same:
            raise ToolFailure("Essa opção não é deste título — usa search_subtitles com este item_id.")
    try:
        if "j" in opt:
            await _jf().download_remote_subtitle(it["Id"], str(opt["j"]))
        else:
            bz = BazarrClient()
            if opt.get("b") == "movie":
                await bz.download_movie(int(opt["r"]), provider=opt["p"], subtitle=opt["i"], hi=opt["hi"],
                                        forced=opt["f"], original_format=opt.get("o", False))
            else:
                await bz.download_episode(int(opt["s"]), int(opt["e"]), provider=opt["p"], subtitle=opt["i"],
                                          hi=opt["hi"], forced=opt["f"], original_format=opt.get("o", False))
            try:
                await _jf().refresh_item(it["Id"])
            except JellyfinError:
                pass
    except (BazarrError, JellyfinError, KeyError, ValueError) as exc:
        raise ToolFailure(f"O download falhou: {exc}") from exc
    audit(ctx.db, "assistant.subtitle_download", actor=ctx.user, target_type="jellyfin_item", target_id=it["Id"])
    return "Legenda descarregada. O cliente deve fechar e voltar a abrir o vídeo e escolher a legenda no menu."


@reg.tool("auto_download_subtitles",
          "Pede ao Bazarr para escolher e descarregar automaticamente a melhor legenda num idioma.",
          obj({"item_id": {"type": "string"}, "language": {"type": "string"}}, ["item_id"]))
async def auto_download(ctx: ToolContext, args: dict):
    await _quota(ctx)
    uid, it = await _item(ctx, str(args.get("item_id")))
    it["_uid"] = uid
    lang = _lang2(args.get("language"))
    target = await _bazarr_target(it)
    if not target:
        raise ToolFailure("O Bazarr não conhece este título — usa search_subtitles (fornecedores do Jellyfin).")
    kind, rec = target
    bz = BazarrClient()
    try:
        if kind == "movie":
            await bz.auto_download_movie(int(rec["radarrId"]), lang)
        else:
            await bz.auto_download_episode(int(rec["sonarrSeriesId"]), int(rec["sonarrEpisodeId"]), lang)
        await _jf().refresh_item(it["Id"])
    except BazarrError as exc:
        raise ToolFailure(f"O Bazarr não encontrou/descarregou: {exc}") from exc
    except JellyfinError:
        pass
    audit(ctx.db, "assistant.subtitle_auto", actor=ctx.user, target_type="jellyfin_item", target_id=it["Id"], lang=lang)
    return f"Pedido ao Bazarr concluído para {LANG_NAMES.get(lang, lang)}. Reabrir o vídeo para ver a legenda."


@reg.tool("sync_subtitles",
          "Sincroniza (acerta o tempo de) a legenda existente num idioma com o áudio do vídeo, via Bazarr. "
          "Pode demorar 1-3 minutos.",
          obj({"item_id": {"type": "string"}, "language": {"type": "string"}}, ["item_id"]))
async def sync_subtitles(ctx: ToolContext, args: dict):
    await _quota(ctx)
    uid, it = await _item(ctx, str(args.get("item_id")))
    it["_uid"] = uid
    lang = _lang2(args.get("language"))
    target = await _bazarr_target(it)
    if not target:
        raise ToolFailure("O Bazarr não conhece este título, por isso não dá para sincronizar automaticamente. "
                          "Alternativa: search_subtitles para outra versão da legenda.")
    kind, rec = target
    subs = [s for s in rec.get("subtitles") or [] if s.get("path") and str(s.get("code2", "")).startswith(lang)]
    if not subs:
        raise ToolFailure(f"Não há legenda externa em {LANG_NAMES.get(lang, lang)} para sincronizar "
                          "(as legendas embutidas no vídeo não se sincronizam). Procura uma com search_subtitles.")
    sub = subs[0]
    media_id = int(rec["radarrId"] if kind == "movie" else rec["sonarrEpisodeId"])
    try:
        await BazarrClient().sync_subtitle(media_type=kind, media_id=media_id, language=str(sub.get("code2")),
                                           path=sub["path"], forced=bool(sub.get("forced")), hi=bool(sub.get("hi")))
    except BazarrError as exc:
        raise ToolFailure(f"A sincronização falhou: {exc}") from exc
    try:
        await _jf().refresh_item(it["Id"])
    except JellyfinError:
        pass
    audit(ctx.db, "assistant.subtitle_sync", actor=ctx.user, target_type="jellyfin_item", target_id=it["Id"], lang=lang)
    return "Legenda sincronizada. O cliente deve fechar e voltar a abrir o vídeo."


@reg.tool("enable_auto_subtitles",
          "Ativa a descarga automática de legendas para um filme ou série inteira (adiciona à coleção que o "
          "plugin Bazarr do Jellyfin vigia).", obj({"item_id": {"type": "string"}}, ["item_id"]))
async def enable_auto(ctx: ToolContext, args: dict):
    coll = get_settings().bazarr_auto_collection_id
    if not coll:
        raise ToolFailure("A descarga automática por coleção não está configurada.")
    uid, it = await _item(ctx, str(args.get("item_id")))
    target_id = it.get("SeriesId") if it.get("Type") == "Episode" else it["Id"]
    try:
        await _jf().add_to_collection(coll, [target_id])
    except JellyfinError as exc:
        raise ToolFailure(f"Não consegui adicionar à coleção: {exc}") from exc
    audit(ctx.db, "assistant.subtitle_auto_collection", actor=ctx.user, target_type="jellyfin_item",
          target_id=target_id)
    return "Ativado: as legendas deste título passam a ser procuradas automaticamente (pode demorar algumas horas)."


# =========================================================================== reprodução / dispositivos / conta
@reg.tool("playback_diagnostics",
          "O que o cliente está a ver ou viu há pouco: dispositivo, app, reprodução direta vs transcodificação e "
          "motivos, bitrate. Usa para buffering/qualidade/erros de reprodução.")
async def playback(ctx: ToolContext, args: dict):
    uid = await _jf_user_id(ctx)
    jf = _jf()
    try:
        sessions = await jf.user_sessions(uid)
        history = await jf.playback_history(uid, limit=5)
    except JellyfinError as exc:
        raise ToolFailure(f"Jellyfin indisponível: {exc}") from exc
    now = []
    for s in sessions:
        np_ = s.get("NowPlayingItem")
        ps = s.get("PlayState") or {}
        ti = s.get("TranscodingInfo") or {}
        now.append({
            "device": s.get("DeviceName"), "app": f"{s.get('Client')} {s.get('ApplicationVersion') or ''}".strip(),
            "last_activity": s.get("LastActivityDate"), "playing": _label(np_) if np_ else None,
            "play_method": ps.get("PlayMethod"), "paused": ps.get("IsPaused"),
            "transcode_reasons": ti.get("TranscodeReasons"), "transcode_video": ti.get("VideoCodec"),
            "transcode_bitrate_mbps": round((ti.get("Bitrate") or 0) / 1_000_000, 1) or None,
            "hardware_accel": ti.get("HardwareAccelerationType"),
        })
    return {"sessions_last_hour": now or "nenhuma sessão ativa na última hora",
            "recently_watched": [_label(i) for i in history]}


@reg.tool("my_devices", "Dispositivos/apps que usaram a conta do cliente (nome, app, última atividade).")
async def devices(ctx: ToolContext, args: dict):
    uid = await _jf_user_id(ctx)
    try:
        items = await _jf().devices(uid)
    except JellyfinError as exc:
        raise ToolFailure(f"Jellyfin indisponível: {exc}") from exc
    return [{"name": d.get("Name"), "app": f"{d.get('AppName')} {d.get('AppVersion') or ''}".strip(),
             "last_activity": d.get("DateLastActivity")} for d in items[:15]] or "Sem dispositivos registados."


@reg.tool("streaming_access_status",
          "Se o acesso ao streaming do cliente está ativo e que funcionalidades tem (sem dados financeiros).")
async def access_status(ctx: ToolContext, args: dict):
    user = ctx.require_user()
    rows = (await ctx.db.execute(select(Subscription, Plan, Product).join(Plan, Plan.id == Subscription.plan_id)
                                 .join(Product, Product.id == Subscription.product_id)
                                 .where(Subscription.user_id == user.id, Product.jellyfin_managed.is_(True),
                                        Subscription.status != SubStatus.ended))).all()
    if not rows:
        return "O cliente não tem streaming ativo. Para aderir → transfer_to_billing."
    sub, plan, _ = rows[0]
    st = SubStatus(sub.status)
    if st in (SubStatus.suspended, SubStatus.pending):
        return {"access": "sem acesso", "reason": "questão de pagamento (tratar com a Faturação: transfer_to_billing)"}
    f = PlanFeatures.model_validate(plan.features or {})
    return {"access": "ativo", "plan_name": plan.name,
            "ends_on": fmt_date(sub.access_until) if st == SubStatus.canceling else None,
            "payment_issue": st == SubStatus.past_due,
            "features": {"simultaneous_streams": f.jellyfin.max_streams or "ilimitado",
                         "live_tv_in_jellyfin": f.jellyfin.live_tv, "downloads": f.jellyfin.downloads,
                         "remote_bitrate_limit_mbps": f.jellyfin.remote_bitrate_mbps or None,
                         "requests_seerr": f.seerr.enabled, "iptv_m3u_xtream": f.iptv.enabled}}


async def _sum_qc(ctx: ToolContext, args: dict) -> str:
    code = str(args.get("code") or "").strip().upper()
    if not code or len(code) > 10:
        raise ToolFailure("Código Quick Connect inválido.")
    return f"Autorizar o dispositivo com o código Quick Connect {code} a entrar na tua conta TKFLIX (Jellyfin)."


@reg.tool("quick_connect_authorize",
          "Autoriza uma TV/dispositivo a entrar na conta com o código Quick Connect mostrado no ecrã. Pede "
          "confirmação ao cliente.", obj({"code": {"type": "string"}}, ["code"]), confirm=True, summary=_sum_qc,
          channels=("web", "jellyfin", "whatsapp"))
async def quick_connect(ctx: ToolContext, args: dict):
    uid = await _jf_user_id(ctx)
    code = str(args.get("code") or "").strip().upper()
    try:
        ok = await _jf().quick_connect_authorize(code, uid)
    except JellyfinError as exc:
        return f"O código não foi aceite ({'expirou ou está errado' if exc.status in (400, 404) else exc})."
    audit(ctx.db, "jellyfin.quick_connect", actor=ctx.user, target_type="user", target_id=ctx.user.id,
          via="assistant")
    await ctx.db.commit()
    return "Dispositivo autorizado — já deve entrar sozinho." if ok else "O código não foi aceite."


# =========================================================================== Seerr (pedidos e issues)
async def _seerr_user(ctx: ToolContext) -> int:
    user = ctx.require_user()
    if not get_settings().seerr_enabled:
        raise ToolFailure("O Seerr não está configurado.")
    sa = await ctx.db.scalar(select(ServiceAccount).where(ServiceAccount.user_id == user.id,
                                                          ServiceAccount.service == "seerr"))
    if sa is None or not sa.external_id:
        raise ToolFailure("O cliente ainda não tem conta no Seerr (é criada com a subscrição).")
    return int(sa.external_id)


@reg.tool("my_requests", "Estado dos últimos pedidos (filmes/séries) que o cliente fez no Seerr.")
async def my_requests(ctx: ToolContext, args: dict):
    sid = await _seerr_user(ctx)
    try:
        reqs = await SeerrClient().user_requests(sid, take=10)
    except SeerrError as exc:
        raise ToolFailure(f"Seerr indisponível: {exc}") from exc
    status = {1: "pendente de aprovação", 2: "aprovado", 3: "recusado", 4: "falhou", 5: "concluído"}
    media_st = {1: "desconhecido", 2: "pendente", 3: "a processar/descarregar", 4: "parcialmente disponível",
                5: "disponível"}
    return [{"type": r.get("type"), "tmdb_id": (r.get("media") or {}).get("tmdbId"),
             "request": status.get(r.get("status"), r.get("status")),
             "availability": media_st.get((r.get("media") or {}).get("status"), None),
             "created": r.get("createdAt")} for r in reqs] or "Sem pedidos."


@reg.tool("my_issues", "Issues (problemas reportados) do cliente no Seerr e o seu estado.")
async def my_issues(ctx: ToolContext, args: dict):
    sid = await _seerr_user(ctx)
    try:
        issues = await SeerrClient().issues(status="all", take=10, requested_by=sid)
    except SeerrError as exc:
        raise ToolFailure(f"Seerr indisponível: {exc}") from exc
    # Defesa em profundidade: a API key é de administrador, por isso uma versão do Seerr que ignore o filtro
    # requestedBy devolvia as issues (e comentários) de todos os clientes.
    issues = [i for i in issues if str((i.get("createdBy") or {}).get("id")) == str(sid)]
    return [{"issue_id": i.get("id"), "type": SeerrClient.ISSUE_TYPES.get(i.get("issueType")),
             "status": "aberta" if i.get("status") == 1 else "resolvida",
             "tmdb_id": (i.get("media") or {}).get("tmdbId"),
             "last_comment": ((i.get("comments") or [{}])[-1] or {}).get("message")} for i in issues] or "Sem issues."


@reg.tool("report_issue",
          "Regista um problema no Seerr para a equipa (quando não conseguiste resolver: ficheiro com defeito, "
          "áudio errado, episódio em falta...).",
          obj({"item_id": {"type": "string"},
               "issue_type": {"type": "string", "enum": ["video", "audio", "subtitles", "other"]},
               "message": {"type": "string"}}, ["item_id", "issue_type", "message"]),
          channels=("web", "jellyfin", "whatsapp"))
async def report_issue(ctx: ToolContext, args: dict):
    await _seerr_user(ctx)
    uid, it = await _item(ctx, str(args.get("item_id")))
    season = episode = 0
    tmdb = None
    mtype = "movie"
    if it.get("Type") == "Episode":
        mtype = "tv"
        season, episode = int(it.get("ParentIndexNumber") or 0), int(it.get("IndexNumber") or 0)
        try:
            series = await _jf().get_item(uid, it["SeriesId"]) if it.get("SeriesId") else None
        except JellyfinError as exc:
            raise ToolFailure(f"Jellyfin indisponível: {exc}") from exc
        tmdb = ((series or {}).get("ProviderIds") or {}).get("Tmdb")
    elif it.get("Type") == "Series":
        mtype = "tv"
        tmdb = (it.get("ProviderIds") or {}).get("Tmdb")
    else:
        tmdb = (it.get("ProviderIds") or {}).get("Tmdb")
    if not tmdb:
        raise ToolFailure("Este título não tem id TMDB — escala para um humano.")
    sc = SeerrClient()
    try:
        media = await sc.media_by_tmdb(mtype, int(tmdb))
        media_id = ((media or {}).get("mediaInfo") or {}).get("id")
        if not media_id:
            raise ToolFailure("O Seerr não conhece este título — escala para um humano.")
        itype = {"video": 1, "audio": 2, "subtitles": 3, "other": 4}[str(args.get("issue_type"))]
        user = ctx.require_user()
        msg = f"{str(args.get('message'))[:900]}\n\n(reportado pelo assistente em nome de {user.username})"
        issue = await sc.create_issue(media_id=int(media_id), issue_type=itype, message=msg,
                                      problem_season=season, problem_episode=episode)
    except SeerrError as exc:
        raise ToolFailure(f"Não consegui criar a issue: {exc}") from exc
    return {"issue_id": issue.get("id"), "message": "Registado. A equipa foi notificada pelo Seerr."}


@reg.tool("resolve_issue", "Marca a issue do Seerr em análise como resolvida (só quando o problema ficou mesmo resolvido).",
          obj({"note": {"type": "string"}}), channels=("seerr",), requires_user=False)
async def resolve_issue(ctx: ToolContext, args: dict):
    issue_id = ctx.extra.get("issue_id")
    if not issue_id:
        raise ToolFailure("Sem issue associada.")
    ctx.extra["resolve"] = True  # o canal Seerr publica o comentário final e só depois resolve
    return "Vai ser marcada como resolvida depois de publicar a resposta."


# =========================================================================== factos vivos
async def live_facts(ctx: ToolContext) -> str:
    s = get_settings()
    langs = ", ".join(LANG_NAMES.get(x, x) for x in s.subtitle_languages)
    lines = ["Factos atuais do sistema:",
             f"- Endereço do Jellyfin para as apps: {s.jellyfin_public_url or '(ver no portal, Os meus serviços)'}",
             f"- Pedidos de filmes/séries: {s.seerr_public_url or 'Seerr (link no portal)'}",
             f"- Idiomas preferidos de legendas: {langs}",
             f"- Bazarr: {'disponível (procurar, descarregar e sincronizar)' if s.bazarr_enabled else 'não configurado (só pesquisa pelos fornecedores do Jellyfin)'}",
             f"- Descarga automática por coleção: {'disponível' if s.bazarr_auto_collection_id else 'não configurada'}"]
    if ctx.channel == "seerr":
        lines.append("- Estás a responder a uma issue do Seerr. A tua resposta final é publicada como comentário na "
                     "issue. Se resolveres o problema (ex.: legenda descarregada/sincronizada), chama resolve_issue.")
    if ctx.user is not None:
        lines.append(f"- Cliente: {ctx.user.display_name or ctx.user.username}")
    return "\n".join(lines)


AGENT = Agent(name="support", label="Suporte", registry=reg, rules=RULES,
              default_instructions=DEFAULT_INSTRUCTIONS, live_facts=live_facts)
