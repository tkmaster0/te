"""Motor de conversa: encaminha, chama o modelo, executa ferramentas e grava tudo.

Garantias de separação (código, não só instruções):
  * o modelo de cada agente só recebe as ferramentas desse agente, e o runtime recusa executar qualquer nome
    que não esteja no registo do agente ativo;
  * cada agente só vê as mensagens da conversa que lhe pertencem (a transferência passa apenas o pedido do
    cliente e um resumo — nunca os resultados das ferramentas do outro agente);
  * base de conhecimento e instruções são por agente;
  * ferramentas sensíveis nunca são executadas pelo modelo: ficam como ação pendente até o cliente confirmar.
"""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from datetime import timedelta

from sqlalchemy import func, select, update
from sqlalchemy import inspect as sa_inspect
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from ..db import utcnow
from ..models import User
from . import knowledge, memory, routing
from .agents import AGENTS, get_agent
from .agents.base import CHANNEL_STYLE, active_instructions
from .llm import LLMError, LLMResponse, get_llm
from .models import AssistantConversation, AssistantMessage, PendingAction
from .tools import ToolContext, ToolFailure, to_text

log = logging.getLogger("tkportal.assistant")

HISTORY_LIMIT = 30
ACTION_TTL = timedelta(minutes=30)
# Confirmação por texto só no WhatsApp e só com uma palavra explícita ("ok"/"s" soltos respondem a qualquer coisa e
# confirmavam por acidente uma ação proposta — p.ex. depois de uma injeção num resultado de ferramenta).
YES = re.compile(r"^\s*(sim|confirmo)\s*[.!]*\s*$", re.IGNORECASE)
NO = re.compile(r"^\s*(n[aã]o|cancela|cancelar)\s*[.!]*\s*$", re.IGNORECASE)

UNAVAILABLE = ("O assistente está indisponível neste momento. 🙏 Tenta de novo daqui a pouco — se for urgente, "
               "um administrador vai ver a tua mensagem.")


@dataclass
class TurnResult:
    messages: list[AssistantMessage] = field(default_factory=list)
    agent: str = "support"


# =========================================================================== conversas
async def get_or_create_conversation(db: AsyncSession, *, user: User | None, channel: str,
                                     conversation_id: str | None = None, external_ref: str | None = None,
                                     scope: str | None = None) -> AssistantConversation:
    conv = None
    if conversation_id:
        conv = await db.get(AssistantConversation, conversation_id)
        if conv is not None and (conv.user_id != (user.id if user else None) or conv.channel != channel):
            conv = None  # nunca continuar a conversa de outra pessoa / canal
    elif external_ref:
        conv = await db.scalar(select(AssistantConversation).where(
            AssistantConversation.channel == channel, AssistantConversation.external_ref == external_ref,
            AssistantConversation.status.in_(["open", "escalated"]),
            AssistantConversation.updated_at >= utcnow() - timedelta(hours=24))
            .order_by(AssistantConversation.updated_at.desc()).limit(1))
        if conv is not None and user is not None and conv.user_id not in (None, user.id):
            conv = None
    if conv is None or conv.status == "closed":
        conv = AssistantConversation(user_id=user.id if user else None, channel=channel, external_ref=external_ref,
                                     scope=scope, agent="support")
        db.add(conv)
        await db.flush()
    return conv


async def rate_limited(db: AsyncSession, user: User | None, conv: AssistantConversation) -> bool:
    limit = get_settings().assistant_rate_limit_per_hour
    since = utcnow() - timedelta(hours=1)
    q = select(func.count()).select_from(AssistantMessage).join(
        AssistantConversation, AssistantConversation.id == AssistantMessage.conversation_id).where(
        AssistantMessage.role == "user", AssistantMessage.created_at >= since)
    q = q.where(AssistantConversation.user_id == user.id) if user else \
        q.where(AssistantMessage.conversation_id == conv.id)
    return (await db.scalar(q) or 0) >= limit


def _add(db: AsyncSession, conv: AssistantConversation, **kw) -> AssistantMessage:
    msg = AssistantMessage(conversation_id=conv.id, **kw)
    db.add(msg)
    conv.updated_at = utcnow()
    return msg


# =========================================================================== contexto para o modelo
async def _history(db: AsyncSession, conv: AssistantConversation, agent: str) -> list[dict]:
    rows = list((await db.scalars(select(AssistantMessage).where(
        AssistantMessage.conversation_id == conv.id, AssistantMessage.agent == agent,
        AssistantMessage.role.in_(["user", "assistant", "tool"]))
        .order_by(AssistantMessage.id.desc()).limit(HISTORY_LIMIT))).all())
    rows.reverse()
    # Não começar a meio de uma sequência de ferramentas (o fornecedor rejeita tool sem o pedido).
    while rows and rows[0].role != "user":
        rows.pop(0)
    out: list[dict] = []
    for m in rows:
        if m.role == "user":
            out.append({"role": "user", "content": m.content or ""})
        elif m.role == "assistant":
            item: dict = {"role": "assistant", "content": m.content or ""}
            if m.tool_calls:
                item["tool_calls"] = [{"id": c["id"], "type": "function",
                                       "function": {"name": c["name"], "arguments": json.dumps(c["arguments"],
                                                                                               ensure_ascii=False)}}
                                      for c in m.tool_calls]
            out.append(item)
        elif m.role == "tool":
            out.append({"role": "tool", "tool_call_id": m.tool_call_id, "content": m.content or ""})
    return out


async def _system_prompt(ctx: ToolContext, query: str) -> str:
    agent = get_agent(ctx.agent)
    parts = [agent.rules, "Instruções do administrador:\n" + await active_instructions(ctx.db, agent),
             CHANNEL_STYLE.get(ctx.channel, ""), await agent.live_facts(ctx)]
    if ctx.conversation is not None:
        parts.append(await memory.context_for(ctx.db, ctx.conversation, agent.name))
    kb = await knowledge.search(ctx.db, agent.name, query, limit=3)
    if kb:
        parts.append("Conhecimento interno relevante (usa se se aplicar):\n" + knowledge.render(kb))
    parts.append(f"Data de hoje: {utcnow().strftime('%d/%m/%Y')}.")
    return "\n\n".join(p for p in parts if p)


# =========================================================================== turno
async def handle_message(db: AsyncSession, conv: AssistantConversation, user: User | None, text: str, *,
                         extra: dict | None = None) -> TurnResult:
    """Processa uma mensagem do cliente e devolve as mensagens novas a mostrar. Faz commit."""
    text = (text or "").strip()[:4000]
    conv_id = conv.id
    result = TurnResult(agent=conv.agent)
    if not text:
        return result
    is_new = not await db.scalar(select(func.count()).select_from(AssistantMessage)
                                 .where(AssistantMessage.conversation_id == conv.id))
    if conv.title is None:
        conv.title = text[:120]

    # Resposta a uma ação pendente ("sim"/"não") — sem passar pelo modelo.
    pending = await latest_pending(db, conv)
    yes = conv.channel == "whatsapp" and bool(YES.match(text))
    if pending is not None and (yes or NO.match(text)):
        _add(db, conv, agent=pending.agent, role="user", content=text)
        try:
            msg = await decide_action(db, pending, user, confirm=yes, commit=False)
        except ToolFailure as exc:
            msg = _add(db, conv, agent=pending.agent, role="assistant", content=str(exc))
        result.messages.append(msg)
        await db.commit()
        return result
    if pending is not None:
        # Outra mensagem qualquer: o pedido pendente deixa de valer (o cliente pede outra vez se quiser).
        await db.execute(update(PendingAction).where(PendingAction.id == pending.id,
                                                     PendingAction.status == "pending")
                         .values(status="cancelled", decided_at=utcnow()))

    if await rate_limited(db, user, conv):
        msg = _add(db, conv, agent=conv.agent, role="assistant",
                   content="Recebemos muitas mensagens tuas na última hora. Tenta de novo um pouco mais tarde. 🙏")
        await db.commit()
        result.messages.append(msg)
        return result

    agent = await routing.pick_agent(text, channel=conv.channel, current=None if is_new else conv.agent,
                                     is_new=is_new)
    if agent != conv.agent and not is_new:
        result.messages.append(_switch_event(db, conv, agent, reason="auto"))
    conv.agent = agent
    used_agents = {agent}
    _add(db, conv, agent=agent, role="user", content=text)
    await db.commit()  # a mensagem do cliente fica gravada aconteça o que acontecer ao modelo
    try:
        await _run_agent(db, conv, user, text, result, extra=extra or {}, transfers_left=1)
    except LLMError:
        await db.rollback()  # objetos expirados: recarregar pelo id guardado
        conv = await db.get(AssistantConversation, conv_id, populate_existing=True)
        assert conv is not None
        msg = _add(db, conv, agent=conv.agent, role="assistant", content=UNAVAILABLE)
        result.messages.append(msg)
    result.agent = conv.agent
    used_agents.add(conv.agent)
    # Memória: cada agente que falou atualiza as suas notas sobre o cliente quando a conversa acalmar.
    await memory.schedule(db, conv.user_id, used_agents)
    await db.commit()
    return result


def _switch_event(db: AsyncSession, conv: AssistantConversation, agent: str, *, reason: str) -> AssistantMessage:
    label = get_agent(agent).label
    return _add(db, conv, agent=agent, role="event", content=f"A falar com o Agente de {label}.",
                ui={"type": "agent_switch", "agent": agent, "reason": reason})


async def _run_agent(db: AsyncSession, conv: AssistantConversation, user: User | None, query: str,
                     result: TurnResult, *, extra: dict, transfers_left: int) -> None:
    s = get_settings()
    llm = get_llm()
    ctx = ToolContext(db=db, user=user, conversation=conv, agent=conv.agent, channel=conv.channel, scope=conv.scope,
                      extra=extra)
    agent = get_agent(ctx.agent)
    tools = agent.registry.available(ctx)
    allowed = {t.name: t for t in tools}
    system = await _system_prompt(ctx, query)
    for _ in range(s.assistant_max_tool_rounds):
        messages = [{"role": "system", "content": system}, *await _history(db, conv, ctx.agent)]
        resp: LLMResponse = await llm.complete(messages, [t.schema() for t in tools] or None,
                                               metadata={"trace_name": f"assistant-{ctx.agent}",
                                                         "session_id": conv.id,
                                                         "trace_user_id": user.id if user else None})
        calls = resp.tool_calls
        amsg = _add(db, conv, agent=ctx.agent, role="assistant", content=resp.content or None, model=resp.model,
                    tokens_in=resp.tokens_in, tokens_out=resp.tokens_out,
                    tool_calls=[{"id": c.id, "name": c.name, "arguments": c.arguments} for c in calls] or None)
        if not calls:
            if not (resp.content or "").strip():
                amsg.content = "Desculpa, não consegui responder a isso. Podes reformular?"
            result.messages.append(amsg)
            return
        if (resp.content or "").strip():
            result.messages.append(amsg)
        transfer_to: tuple[str, str] | None = None
        for call in calls:
            tool = allowed.get(call.name)
            if tool is None:
                # Nome inventado ou ferramenta do outro agente: recusado aqui, independentemente do modelo.
                log.warning("Agente %s tentou usar ferramenta não permitida: %s", ctx.agent, call.name)
                _add(db, conv, agent=ctx.agent, role="tool", tool_call_id=call.id, tool_name=call.name,
                     content="Erro: ferramenta inexistente para este agente.")
                continue
            if call.name.startswith("transfer_to_"):
                target = call.name.removeprefix("transfer_to_")
                _add(db, conv, agent=ctx.agent, role="tool", tool_call_id=call.id, tool_name=call.name,
                     content="Transferido.")
                if target in AGENTS and transfers_left > 0:
                    transfer_to = (target, str(call.arguments.get("summary") or "")[:500])
                continue
            content = await _execute(ctx, tool, call.arguments, call_id=call.id, result=result)
            _add(db, conv, agent=ctx.agent, role="tool", tool_call_id=call.id, tool_name=call.name, content=content)
        await db.flush()
        if transfer_to:
            target, summary = transfer_to
            result.messages.append(_switch_event(db, conv, target, reason="transfer"))
            conv.agent = target
            # O novo agente recebe só o pedido do cliente e o resumo — nada do que o outro agente consultou.
            _add(db, conv, agent=target, role="user", ui={"hidden": True},
                 content=f"{query}\n\n[Nota interna: transferido do Agente de {agent.label}. Resumo: {summary}]")
            await db.flush()
            await _run_agent(db, conv, user, query, result, extra=extra, transfers_left=transfers_left - 1)
            return
    msg = _add(db, conv, agent=ctx.agent, role="assistant",
               content="Isto está a demorar mais do que devia. Vou passar a um administrador para confirmar.")
    result.messages.append(msg)


async def _execute(ctx: ToolContext, tool, args: dict, *, call_id: str, result: TurnResult) -> str:
    if "_invalid_json" in args:
        return "Erro: argumentos inválidos (JSON)."
    try:
        if tool.confirm:
            summary = await tool.summary(ctx, args) if tool.summary else tool.description
            user = ctx.require_user()
            # Uma nova proposta substitui a anterior ainda pendente.
            for old in (await ctx.db.scalars(select(PendingAction).where(
                    PendingAction.conversation_id == ctx.conversation.id, PendingAction.status == "pending"))).all():
                old.status = "cancelled"
                old.decided_at = utcnow()
            action = PendingAction(conversation_id=ctx.conversation.id, user_id=user.id, agent=ctx.agent,
                                   tool=tool.name, args=args, summary=summary, expires_at=utcnow() + ACTION_TTL)
            ctx.db.add(action)
            await ctx.db.flush()
            ui = {"type": "confirm", "action_id": action.id, "summary": summary}
            msg = _add(ctx.db, ctx.conversation, agent=ctx.agent, role="event", content=summary, ui=ui)
            result.messages.append(msg)
            hint = "responder SIM" if ctx.channel == "whatsapp" else "carregar em Confirmar"
            return (f"Ação preparada e à espera de confirmação do cliente: «{summary}». NÃO está feita. Diz ao "
                    f"cliente, numa frase, que para avançar basta {hint} (válido 30 minutos).")
        try:
            async with ctx.db.begin_nested():  # um erro na ferramenta só desfaz o que ela fez
                out = await tool.handler(ctx, args)
        except Exception:
            await _reload_expired(ctx)
            raise
        return to_text(out)
    except ToolFailure as exc:
        return f"Erro: {exc}"
    except LLMError:
        raise
    except Exception as exc:
        log.exception("Ferramenta %s falhou", tool.name)
        return f"Erro interno ao executar {tool.name} ({type(exc).__name__}). Pede desculpa e oferece escalar."


async def _reload_expired(ctx: ToolContext) -> None:
    """Depois do rollback do savepoint, o SQLAlchemy expira o que a ferramenta alterou (ex.: a conversa). Em
    async, tocar num atributo expirado dá MissingGreenlet — recarregar já aqui a conversa e o cliente."""
    for obj in (ctx.conversation, ctx.user):
        if obj is not None and sa_inspect(obj).expired_attributes:
            await ctx.db.refresh(obj)


# =========================================================================== ações pendentes
async def latest_pending(db: AsyncSession, conv: AssistantConversation) -> PendingAction | None:
    act = await db.scalar(select(PendingAction).where(PendingAction.conversation_id == conv.id,
                                                      PendingAction.status == "pending")
                          .order_by(PendingAction.created_at.desc()).limit(1))
    if act is not None and act.expires_at <= utcnow():
        act.status = "expired"
        return None
    return act


async def decide_action(db: AsyncSession, action: PendingAction, user: User | None, *, confirm: bool,
                        commit: bool = True) -> AssistantMessage:
    conv = await db.get(AssistantConversation, action.conversation_id)
    assert conv is not None
    if user is None or action.user_id != user.id:
        raise ToolFailure("Esta ação não é tua.")
    if action.status != "pending":
        raise ToolFailure("Esta ação já foi tratada.")
    expired = action.expires_at <= utcnow()
    new_status = "expired" if expired else ("done" if confirm else "cancelled")
    # Transição atómica: com dois pedidos ao mesmo tempo (duplo clique, botão + texto, portal + Jellyfin) só um
    # encontra a ação ainda "pending" — o outro não executa nada.
    res = await db.execute(update(PendingAction).where(PendingAction.id == action.id,
                                                       PendingAction.status == "pending")
                           .values(status=new_status, decided_at=utcnow()))
    if res.rowcount != 1:
        raise ToolFailure("Esta ação já foi tratada.")
    action = await db.get(PendingAction, action.id, populate_existing=True) or action
    if expired:
        msg = _add(db, conv, agent=action.agent, role="assistant",
                   content="Esse pedido expirou. Se ainda quiseres, pede outra vez. 🙂")
        if commit:
            await db.commit()
        return msg
    if not confirm:
        msg = _add(db, conv, agent=action.agent, role="assistant", content="Ok, não fiz nada. 👍")
        if commit:
            await db.commit()
        return msg
    agent = get_agent(action.agent)
    tool = agent.registry.get(action.tool)
    action_id = action.id
    if tool is None or not tool.confirm:
        action.status = "failed"
        content = "Não foi possível executar esta ação."
    else:
        await db.commit()  # "done" gravado antes de executar: nunca corre duas vezes
        ctx = ToolContext(db=db, user=user, conversation=conv, agent=action.agent, channel=conv.channel,
                          scope=conv.scope, confirmed=True)
        failed = False
        try:
            content = to_text(await tool.handler(ctx, dict(action.args or {})))
        except ToolFailure as exc:
            failed = True
            await db.rollback()  # nada do que a ferramenta fez a meio fica gravado
            content = f"Não foi possível: {exc}"
        except Exception:
            failed = True
            log.exception("Ação confirmada %s falhou", action.tool)
            await db.rollback()
            content = "Ocorreu um erro ao executar o pedido. Um administrador foi avisado."
        # A ferramenta pode ter feito rollback (objetos expirados): recarregar pelo id antes de lhes tocar.
        action = await db.get(PendingAction, action_id, populate_existing=True) or action
        conv = await db.get(AssistantConversation, action.conversation_id, populate_existing=True) or conv
        if failed:
            action.status = "failed"  # o painel mostra que não foi feito (e o duplo clique continua bloqueado)
        action.result = content[:2000]
    msg = _add(db, conv, agent=action.agent, role="assistant", content=content,
               ui={"type": "action_result", "action_id": action.id, "status": action.status})
    # Contexto para o agente nas mensagens seguintes (ele não viu a execução).
    _add(db, conv, agent=action.agent, role="user", ui={"hidden": True},
         content=f"[Nota interna: o cliente {'confirmou' if confirm else 'recusou'} «{action.summary}». "
                 f"Resultado: {content[:500]}]")
    if commit:
        await db.commit()
    return msg
