"""Escolha do agente para cada mensagem.

1. Regras fixas por canal (issues do Seerr → sempre Suporte).
2. Pontuação por palavras-chave (rápida, sem custo).
3. Se for ambíguo numa conversa nova, pergunta ao modelo rápido (uma palavra).
Numa conversa em curso só muda de agente quando a mensagem é claramente do outro; de resto é o próprio agente
que transfere (ferramenta transfer_to_*), com um resumo.
"""
from __future__ import annotations

import logging

from .knowledge import fold
from .llm import LLMError, get_llm

log = logging.getLogger("tkportal.assistant.routing")

BILLING_WORDS = {
    "pagar": 2, "pagamento": 3, "paguei": 3, "pago": 1, "cobranca": 3, "cobrado": 3, "cobraram": 3, "cobrar": 2,
    "fatura": 3, "faturacao": 3, "recibo": 2, "preco": 3, "precos": 3, "custa": 2, "valor": 1, "euros": 2,
    "eur": 1, "mensalidade": 3, "subscricao": 2, "subscrever": 2, "aderir": 2, "plano": 2, "planos": 2,
    "upgrade": 2, "downgrade": 2, "cancelar": 2, "cancela": 2, "cancelo": 2, "cancelamento": 2, "reativar": 2, "cartao": 3, "debito": 3,
    "iban": 3, "mandato": 3, "multibanco": 3, "mbway": 3, "reembolso": 3, "devolver": 1, "dinheiro": 2,
    "stripe": 3, "gocardless": 3, "bonus": 2, "desconto": 2, "credito": 2, "prorata": 3, "anual": 1, "mensal": 1,
    "suspensa": 2, "suspenso": 2, "atraso": 2, "divida": 3,
}
SUPPORT_WORDS = {
    "legenda": 3, "legendas": 3, "subtitle": 3, "sincronizar": 2, "dessincronizada": 3, "atrasada": 1,
    "filme": 2, "filmes": 2, "serie": 2, "series": 2, "episodio": 3, "temporada": 2, "canal": 2, "canais": 2,
    "jellyfin": 3, "app": 2, "aplicacao": 2, "televisao": 2, "tv": 1, "smart": 1, "android": 2, "iphone": 2,
    "firestick": 3, "chromecast": 3, "buffering": 3, "trava": 3, "carregar": 2, "carrega": 2, "lento": 2,
    "qualidade": 2, "4k": 2, "hdr": 2, "audio": 3, "som": 2, "imagem": 2, "erro": 2, "reproduzir": 3,
    "reproducao": 3, "play": 2, "ver": 1, "pedido": 2, "pedir": 2, "seerr": 3, "jellyseerr": 3, "issue": 2,
    "password": 2, "palavra-passe": 2, "login": 1, "entrar": 1, "dispositivo": 2, "quickconnect": 3,
    "idioma": 2, "dobrado": 2, "iptv": 2, "guia": 1, "epg": 3, "biblioteca": 2, "falta": 1, "aparece": 1,
}


def _stems(words: dict[str, int]) -> dict[str, int]:
    out: dict[str, int] = {}
    for w, v in words.items():
        if len(w) >= 6:
            out[w[:6]] = max(out.get(w[:6], 0), v)
    return out


_B_STEMS, _S_STEMS = _stems(BILLING_WORDS), _stems(SUPPORT_WORDS)


def _weight(word: str, exact: dict[str, int], stems: dict[str, int]) -> int:
    if word in exact:
        return exact[word]
    return stems.get(word[:6], 0) if len(word) >= 6 else 0


def score(text: str) -> tuple[int, int]:
    """Pontuação (faturação, suporte). Aceita variações (cancela/cancelo/cancelar, legendas/legendado...)."""
    words = [w.strip(".,!?;:()\"'") for w in fold(text).replace("-", " ").split()]
    b = sum(_weight(w, BILLING_WORDS, _B_STEMS) for w in words)
    s = sum(_weight(w, SUPPORT_WORDS, _S_STEMS) for w in words)
    return b, s


async def pick_agent(text: str, *, channel: str, current: str | None, is_new: bool,
                     billing_allowed: bool = True) -> str:
    if channel == "seerr" or not billing_allowed:
        return "support"
    b, s = score(text)
    if not is_new and current:
        other = "support" if current == "billing" else "billing"
        mine, theirs = (b, s) if current == "billing" else (s, b)
        return other if theirs >= 3 and theirs >= mine + 3 else current
    if b >= s + 2:
        return "billing"
    if s >= b + 2:
        return "support"
    try:
        resp = await get_llm().complete([
            {"role": "system", "content": "Classifica a mensagem de um cliente de um serviço de streaming. Responde "
                                          "apenas com uma palavra: BILLING (pagamentos, preços, planos, subscrições, "
                                          "faturas) ou SUPPORT (tudo o resto: conteúdos, apps, legendas, erros, "
                                          "pedidos, conta de streaming)."},
            {"role": "user", "content": text[:1000]},
        ], fast=True)
        word = (resp.content or "").strip().upper()
        if "BILL" in word:
            return "billing"
        if "SUPP" in word:
            return "support"
    except LLMError as exc:
        log.info("Encaminhamento por modelo falhou: %s", exc)
    return current or ("billing" if b > s else "support")
