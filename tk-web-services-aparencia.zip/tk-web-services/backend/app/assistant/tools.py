"""Ferramentas dos agentes.

Cada agente tem o SEU registo de ferramentas. O runtime só mostra ao modelo as ferramentas do agente ativo e
só executa nomes que existam nesse registo — um agente não consegue chamar uma ferramenta do outro, mesmo
que o modelo invente o nome.

Ferramentas com `confirm=True` (cancelar, mudar de plano, ...) nunca são executadas pelo modelo: o runtime
grava uma ação pendente e o cliente confirma-a explicitamente (botão, ou "SIM" no WhatsApp).
"""
from __future__ import annotations

import json
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from ..models import User
from .models import AssistantConversation


class ToolFailure(Exception):
    """Erro para mostrar ao modelo (ex.: "não encontrei esse filme"). Não é um erro do sistema."""


@dataclass
class ToolContext:
    db: AsyncSession
    user: User | None
    conversation: AssistantConversation
    agent: str
    channel: str
    scope: str | None = None  # "streaming" = só o produto de streaming (conversas vindas do Jellyfin)
    confirmed: bool = False  # True quando o runtime executa uma ação já confirmada pelo cliente
    extra: dict[str, Any] = field(default_factory=dict)

    def require_user(self) -> User:
        if self.user is None:
            raise ToolFailure("Esta conversa não está associada a uma conta TK Web Services.")
        return self.user


Handler = Callable[[ToolContext, dict[str, Any]], Awaitable[Any]]
Summary = Callable[[ToolContext, dict[str, Any]], Awaitable[str]]


@dataclass
class Tool:
    name: str
    description: str
    parameters: dict[str, Any]
    handler: Handler
    confirm: bool = False
    # Texto mostrado ao cliente no pedido de confirmação (ex.: "Cancelar TKFLIX — acesso até 26/10").
    summary: Summary | None = None
    # Canais onde a ferramenta existe (None = todos). Ex.: ações com confirmação não existem no Seerr.
    channels: tuple[str, ...] | None = None
    requires_user: bool = True

    def schema(self) -> dict[str, Any]:
        return {"type": "function",
                "function": {"name": self.name, "description": self.description, "parameters": self.parameters}}


class ToolRegistry:
    def __init__(self, agent: str) -> None:
        self.agent = agent
        self._tools: dict[str, Tool] = {}

    def tool(self, name: str, description: str, parameters: dict[str, Any] | None = None, *, confirm: bool = False,
             summary: Summary | None = None, channels: tuple[str, ...] | None = None, requires_user: bool = True):
        def deco(fn: Handler) -> Handler:
            if name in self._tools:
                raise ValueError(f"Ferramenta duplicada: {name}")
            self._tools[name] = Tool(name=name, description=description,
                                     parameters=parameters or {"type": "object", "properties": {}},
                                     handler=fn, confirm=confirm, summary=summary, channels=channels,
                                     requires_user=requires_user)
            return fn
        return deco

    def get(self, name: str) -> Tool | None:
        return self._tools.get(name)

    def names(self) -> list[str]:
        return list(self._tools)

    def available(self, ctx: ToolContext) -> list[Tool]:
        out = []
        for t in self._tools.values():
            if t.channels is not None and ctx.channel not in t.channels:
                continue
            if t.confirm and ctx.channel == "seerr":  # sem cliente presente para confirmar
                continue
            if t.name.startswith("transfer_to_") and ctx.channel == "seerr":  # issues são só do suporte
                continue
            if t.name == "transfer_to_billing" and ctx.extra.get("billing_disabled"):
                continue
            if t.requires_user and ctx.user is None:
                continue
            out.append(t)
        return out


def obj(properties: dict[str, Any] | None = None, required: list[str] | None = None) -> dict[str, Any]:
    return {"type": "object", "properties": properties or {}, "required": required or []}


def _default(o: Any) -> Any:
    if isinstance(o, datetime | date):
        return o.isoformat()
    return str(o)


def to_text(result: Any, limit: int = 6000) -> str:
    """Resultado de uma ferramenta → texto para o modelo (JSON compacto e truncado)."""
    text = result if isinstance(result, str) else json.dumps(result, ensure_ascii=False, default=_default)
    return text if len(text) <= limit else text[:limit] + "…(truncado)"
