"""Base de conhecimento por agente.

Pesquisa híbrida: com `ASSISTANT_EMBEDDING_MODEL` usa semelhança de cosseno entre embeddings (guardados em JSON,
calculados em Python — com algumas centenas de artigos é instantâneo e não precisa de pgvector); sem
embeddings, ou se o fornecedor falhar, usa pontuação por palavras-chave (sem acentos, sem palavras vazias).
"""
from __future__ import annotations

import math
import re
import unicodedata
from collections import Counter

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from .llm import get_llm
from .models import KnowledgeItem

_STOP = set(["a", "o", "as", "os", "um", "uma", "uns", "umas", "de", "do", "da", "dos", "das", "em", "no", "na", "nos", "nas", "por", "para", "com", "sem", "e", "ou", "que", "se", "me", "te", "lhe", "nao", "sim", "ja", "mais", "muito", "como", "qual", "quais", "quando", "onde", "porque", "porquê", "pq", "é", "e", "foi", "ser", "estar", "esta", "este", "isto", "isso", "eu", "tu", "ele", "ela", "nos", "vos", "eles", "elas", "meu", "minha", "teu", "tua", "seu", "sua", "ao", "aos", "à", "às", "the", "is", "are", "to", "of", "and", "in", "on", "for", "it", "tenho", "tem", "ter", "consigo", "posso", "pode", "fazer", "faz", "está", "estou"])


def fold(text: str) -> str:
    text = unicodedata.normalize("NFKD", text.lower())
    return "".join(c for c in text if not unicodedata.combining(c))


def terms(text: str) -> list[str]:
    return [w for w in re.findall(r"[a-z0-9]{2,}", fold(text)) if w not in _STOP]


def _cos(a: list[float], b: list[float]) -> float:
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b, strict=False))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(y * y for y in b))
    return dot / (na * nb) if na and nb else 0.0


def _keyword_scores(query: str, items: list[KnowledgeItem]) -> list[tuple[float, KnowledgeItem]]:
    q = terms(query)
    if not q:
        return []
    docs = [(it, Counter(terms(f"{it.title} {it.title} {' '.join(it.tags or [])} {it.content}"))) for it in items]
    n = len(docs) or 1
    df = Counter(t for _, c in docs for t in set(c))
    out = []
    for it, c in docs:
        length = sum(c.values()) or 1
        score = 0.0
        for t in set(q):
            tf = c.get(t, 0)
            if not tf:
                # prefixo (legenda ↔ legendas, sincroniza ↔ sincronizar)
                tf = sum(v for k, v in c.items() if len(t) >= 5 and (k.startswith(t[:5])))
                tf *= 0.6
            if tf:
                idf = math.log(1 + (n - df.get(t, 0) + 0.5) / (df.get(t, 0) + 0.5))
                score += idf * (tf * 2.2) / (tf + 1.2 * (0.25 + 0.75 * length / 80))
        if score > 0:
            out.append((score, it))
    return out


async def search(db: AsyncSession, agent: str, query: str, limit: int = 4) -> list[KnowledgeItem]:
    """Artigos ativos DESTE agente mais relevantes para a pergunta."""
    items = list((await db.scalars(select(KnowledgeItem).where(KnowledgeItem.agent == agent,
                                                               KnowledgeItem.status == "active"))).all())
    if not items or not query.strip():
        return []
    llm = get_llm()
    scored: list[tuple[float, KnowledgeItem]] = []
    model = getattr(llm, "embedding_model", None)
    with_vec = [it for it in items if it.embedding and it.embedding_model == model]
    if model and with_vec:
        vecs = await llm.embed([query])
        if vecs:
            scored = [(_cos(vecs[0], it.embedding), it) for it in with_vec]
            scored = [(s, it) for s, it in scored if s >= 0.35]
    if not scored:
        kw = _keyword_scores(query, items)
        top = max((s for s, _ in kw), default=0)
        scored = [(s, it) for s, it in kw if s >= max(0.8, top * 0.35)]
    scored.sort(key=lambda x: x[0], reverse=True)
    result = [it for _, it in scored[:limit]]
    for it in result:
        it.uses = (it.uses or 0) + 1
    return result


async def embed_item(item: KnowledgeItem) -> None:
    llm = get_llm()
    model = getattr(llm, "embedding_model", None)
    if not model:
        return
    vecs = await llm.embed([f"{item.title}\n{item.content}"])
    if vecs:
        item.embedding = vecs[0]
        item.embedding_model = model


def render(items: list[KnowledgeItem]) -> str:
    return "\n\n".join(f"### {it.title}\n{it.content.strip()}" for it in items)
