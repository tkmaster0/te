"""Tabelas dos assistentes de IA.

Separação por agente em todo o lado: cada conversa, mensagem, instrução e item de conhecimento pertence a
um agente ("billing" ou "support"). Um agente nunca lê o conhecimento, as instruções nem os resultados de
ferramentas do outro.
"""
from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import Boolean, ForeignKey, Index, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from ..db import Base, JSONType, UTCDateTime, utcnow

AGENTS = ("billing", "support")
CHANNELS = ("web", "jellyfin", "whatsapp", "seerr")


def _uuid() -> str:
    return str(uuid.uuid4())


class AssistantConversation(Base):
    __tablename__ = "assistant_conversations"
    __table_args__ = (Index("ix_assistant_conv_channel_ref", "channel", "external_ref"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    user_id: Mapped[str | None] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    channel: Mapped[str] = mapped_column(String(16))  # web | jellyfin | whatsapp | seerr
    # Âmbito da sessão: "streaming" nas conversas vindas do Jellyfin (a faturação só vê o streaming).
    scope: Mapped[str | None] = mapped_column(String(16))
    agent: Mapped[str] = mapped_column(String(16), default="support")  # agente atual
    # Referência externa: telefone (WhatsApp) ou id da issue (Seerr).
    external_ref: Mapped[str | None] = mapped_column(String(64))
    title: Mapped[str | None] = mapped_column(String(160))
    status: Mapped[str] = mapped_column(String(16), default="open")  # open | escalated | resolved | closed
    escalated_at: Mapped[datetime | None] = mapped_column(UTCDateTime())
    resolved_at: Mapped[datetime | None] = mapped_column(UTCDateTime())
    admin_note: Mapped[str | None] = mapped_column(Text)
    reviewed: Mapped[bool] = mapped_column(Boolean, default=False)  # já usada para gerar conhecimento
    meta: Mapped[dict | None] = mapped_column(JSONType)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow, index=True)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow, onupdate=utcnow)


class AssistantMessage(Base):
    __tablename__ = "assistant_messages"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    conversation_id: Mapped[str] = mapped_column(ForeignKey("assistant_conversations.id", ondelete="CASCADE"),
                                                 index=True)
    agent: Mapped[str] = mapped_column(String(16))
    # user | assistant | tool | event (mudança de agente, ação confirmada, nota do admin)
    role: Mapped[str] = mapped_column(String(16))
    content: Mapped[str | None] = mapped_column(Text)
    tool_calls: Mapped[list | None] = mapped_column(JSONType)  # pedidos de ferramenta do modelo
    tool_call_id: Mapped[str | None] = mapped_column(String(64))
    tool_name: Mapped[str | None] = mapped_column(String(64))
    # Dados para a interface (ex.: ação pendente com botões Confirmar/Cancelar).
    ui: Mapped[dict | None] = mapped_column(JSONType)
    feedback: Mapped[int | None] = mapped_column(Integer)  # 1 | -1
    feedback_note: Mapped[str | None] = mapped_column(Text)
    model: Mapped[str | None] = mapped_column(String(96))
    tokens_in: Mapped[int | None] = mapped_column(Integer)
    tokens_out: Mapped[int | None] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)


class AssistantInstruction(Base):
    """Instruções editáveis pelo admin, com versões (a ativa é a de `active=True`).

    As regras de segurança/âmbito de cada agente vivem no código e são sempre aplicadas antes destas: o admin
    melhora o tom, o conteúdo e os procedimentos, mas não consegue (nem por engano) retirar a separação.
    """

    __tablename__ = "assistant_instructions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    agent: Mapped[str] = mapped_column(String(16), index=True)
    version: Mapped[int] = mapped_column(Integer)
    content: Mapped[str] = mapped_column(Text)
    note: Mapped[str | None] = mapped_column(String(200))
    active: Mapped[bool] = mapped_column(Boolean, default=False)
    created_by: Mapped[str | None] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)


class KnowledgeItem(Base):
    __tablename__ = "assistant_knowledge"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    agent: Mapped[str] = mapped_column(String(16), index=True)
    title: Mapped[str] = mapped_column(String(200))
    content: Mapped[str] = mapped_column(Text)
    tags: Mapped[list | None] = mapped_column(JSONType)
    # manual | promoted (resposta promovida pelo admin) | suggested (rascunho gerado a partir de conversas)
    source: Mapped[str] = mapped_column(String(16), default="manual")
    # active | draft (sugestão por aprovar) | archived
    status: Mapped[str] = mapped_column(String(16), default="active", index=True)
    source_conversation_id: Mapped[str | None] = mapped_column(String(36))
    embedding: Mapped[list | None] = mapped_column(JSONType)
    embedding_model: Mapped[str | None] = mapped_column(String(96))
    uses: Mapped[int] = mapped_column(Integer, default=0)
    created_by: Mapped[str | None] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow, onupdate=utcnow)


class PendingAction(Base):
    """Ação sensível proposta pelo agente, à espera de confirmação explícita do cliente."""

    __tablename__ = "assistant_pending_actions"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    conversation_id: Mapped[str] = mapped_column(ForeignKey("assistant_conversations.id", ondelete="CASCADE"),
                                                 index=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    agent: Mapped[str] = mapped_column(String(16))
    tool: Mapped[str] = mapped_column(String(64))
    args: Mapped[dict] = mapped_column(JSONType, default=dict)
    summary: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(16), default="pending")  # pending | done | cancelled | expired | failed
    result: Mapped[str | None] = mapped_column(Text)
    expires_at: Mapped[datetime] = mapped_column(UTCDateTime())
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)
    decided_at: Mapped[datetime | None] = mapped_column(UTCDateTime())


class ChannelIdentity(Base):
    """Liga um identificador externo (telefone do WhatsApp) a um cliente, depois de verificado."""

    __tablename__ = "assistant_channel_identities"
    __table_args__ = (UniqueConstraint("channel", "external_id", name="uq_assistant_identity_channel_ext"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    channel: Mapped[str] = mapped_column(String(16))
    external_id: Mapped[str] = mapped_column(String(64))
    display: Mapped[str | None] = mapped_column(String(64))
    verified_at: Mapped[datetime | None] = mapped_column(UTCDateTime())
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)


class AssistantMemory(Base):
    """Memória de longo prazo de UM agente sobre UM cliente (resumo das conversas anteriores).

    Os agentes são separados também aqui: o de Faturação nunca vê a memória do de Suporte e vice-versa.
    """

    __tablename__ = "assistant_memories"
    __table_args__ = (UniqueConstraint("user_id", "agent", name="uq_assistant_memories_user_agent"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    agent: Mapped[str] = mapped_column(String(16))
    summary: Mapped[str] = mapped_column(Text, default="")
    last_message_id: Mapped[int] = mapped_column(Integer, default=0)  # mensagens até aqui já resumidas
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow, onupdate=utcnow)
