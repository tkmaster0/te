"""WhatsApp: WhatsApp Cloud API (Meta) ou Evolution API (Baileys) — escolhe-se com WHATSAPP_PROVIDER.

Fluxo:
  1. O webhook valida a origem, deduplica a mensagem e enfileira o processamento (responde logo 200).
  2. O número tem de estar ligado a uma conta: no portal (Conta → WhatsApp) o cliente gera um código "TK-XXXXXX"
     e envia-o para o número do serviço. Números não ligados só recebem as instruções.
  3. Mensagens de números ligados vão para o runtime (mesmos agentes e regras do chat do portal). Pedidos de
     confirmação chegam com botões (Cloud API) ou "responde SIM" (Evolution).
Comandos: "novo" recomeça a conversa; "desligar" desliga o número da conta.
"""
from __future__ import annotations

import hashlib
import hmac
import logging
import re
import secrets
import time
from datetime import timedelta

import httpx
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from ...config import get_settings
from ...db import utcnow
from ...models import EmailToken, User
from ...security import token_hash
from ...services.audit import audit
from ...services.jobs import RetryLater, enqueue, job_handler
from .. import runtime
from ..models import AssistantConversation, AssistantMessage, ChannelIdentity, PendingAction
from ..tools import ToolFailure

log = logging.getLogger("tkportal.assistant.whatsapp")

LINK_TTL = timedelta(minutes=15)
LINK_RE = re.compile(r"\bTK-?([A-Z0-9]{6})\b", re.IGNORECASE)
_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
_unlinked_notice: dict[str, float] = {}


def normalize_phone(raw: str | None) -> str:
    return re.sub(r"\D", "", (raw or "").split("@")[0])


def mask(phone: str) -> str:
    return f"+{phone[:3]} ••• ••{phone[-3:]}" if len(phone) > 6 else phone


# =========================================================================== ligação número ↔ conta
async def issue_link_code(db: AsyncSession, user: User) -> str:
    await db.execute(update(EmailToken).where(EmailToken.user_id == user.id, EmailToken.purpose == "whatsapp_link",
                                              EmailToken.used_at.is_(None)).values(used_at=utcnow()))
    code = "".join(secrets.choice(_ALPHABET) for _ in range(6))
    db.add(EmailToken(user_id=user.id, purpose="whatsapp_link", token_hash=token_hash(f"wa-link:{code}"),
                      expires_at=utcnow() + LINK_TTL))
    return f"TK-{code}"


async def consume_link_code(db: AsyncSession, code: str) -> User | None:
    tok = await db.scalar(select(EmailToken).where(EmailToken.token_hash == token_hash(f"wa-link:{code.upper()}"),
                                                   EmailToken.purpose == "whatsapp_link"))
    if tok is None or tok.used_at is not None or tok.expires_at <= utcnow():
        return None
    res = await db.execute(update(EmailToken).where(EmailToken.id == tok.id, EmailToken.used_at.is_(None))
                           .values(used_at=utcnow()))
    if not res.rowcount:
        return None
    return await db.get(User, tok.user_id)


async def identity_for(db: AsyncSession, phone: str) -> ChannelIdentity | None:
    return await db.scalar(select(ChannelIdentity).where(ChannelIdentity.channel == "whatsapp",
                                                         ChannelIdentity.external_id == phone,
                                                         ChannelIdentity.verified_at.is_not(None)))


# =========================================================================== formatação
def to_whatsapp(text: str) -> str:
    base = get_settings().public_url
    text = re.sub(r"\[([^\]]+)\]\((/[^)]*)\)", lambda m: f"{m.group(1)}: {base}{m.group(2)}", text)
    text = re.sub(r"\[([^\]]+)\]\((https?://[^)]+)\)", r"\1: \2", text)
    text = re.sub(r"(?<![\w/])(/app/[\w/#?=&-]*)", lambda m: f"{base}{m.group(1)}", text)
    text = re.sub(r"\*\*(.+?)\*\*", r"*\1*", text)
    text = re.sub(r"^#{1,6}\s*", "", text, flags=re.MULTILINE)
    return text.strip()[:4000]


# =========================================================================== adaptadores
class Adapter:
    buttons = False

    async def send_text(self, phone: str, text: str) -> None:
        raise NotImplementedError

    async def send_confirm(self, phone: str, text: str, action_id: str) -> None:
        await self.send_text(phone, f"{text}\n\nResponde *SIM* para confirmar ou *NÃO* para cancelar.")


class CloudAdapter(Adapter):
    buttons = True

    def _url(self) -> str:
        s = get_settings()
        return f"https://graph.facebook.com/{s.whatsapp_cloud_api_version or 'v21.0'}/{s.whatsapp_cloud_phone_number_id}/messages"

    async def _post(self, body: dict) -> None:
        s = get_settings()
        try:
            async with httpx.AsyncClient(timeout=20) as c:
                r = await c.post(self._url(), json={"messaging_product": "whatsapp", **body},
                                 headers={"Authorization": f"Bearer {s.whatsapp_cloud_token}"})
        except httpx.HTTPError as exc:
            raise RetryLater(f"WhatsApp Cloud inacessível: {exc}", 30) from exc
        if r.status_code >= 500 or r.status_code == 429:
            raise RetryLater(f"WhatsApp Cloud {r.status_code}", 60)
        if r.status_code >= 400:
            log.warning("WhatsApp Cloud recusou a mensagem: %s %s", r.status_code, r.text[:300])

    async def send_text(self, phone: str, text: str) -> None:
        await self._post({"to": phone, "type": "text", "text": {"body": text, "preview_url": True}})

    async def send_confirm(self, phone: str, text: str, action_id: str) -> None:
        await self._post({"to": phone, "type": "interactive", "interactive": {
            "type": "button", "body": {"text": text[:1000]},
            "action": {"buttons": [{"type": "reply", "reply": {"id": f"confirm:{action_id}", "title": "Confirmar"}},
                                   {"type": "reply", "reply": {"id": f"cancel:{action_id}", "title": "Cancelar"}}]}}})

    @staticmethod
    def verify_signature(body: bytes, header: str | None) -> bool:
        secret = get_settings().whatsapp_cloud_app_secret
        if not secret or not header or not header.startswith("sha256="):
            return False
        expected = hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
        return hmac.compare_digest(expected, header.removeprefix("sha256="))

    @staticmethod
    def parse(payload: dict) -> list[dict]:
        out = []
        for entry in payload.get("entry") or []:
            for change in entry.get("changes") or []:
                value = change.get("value") or {}
                names = {c.get("wa_id"): (c.get("profile") or {}).get("name") for c in value.get("contacts") or []}
                for m in value.get("messages") or []:
                    text, button = None, None
                    if m.get("type") == "text":
                        text = (m.get("text") or {}).get("body")
                    elif m.get("type") == "interactive":
                        inter = m.get("interactive") or {}
                        reply = inter.get("button_reply") or inter.get("list_reply") or {}
                        button, text = reply.get("id"), reply.get("title")
                    elif m.get("type") == "button":
                        text = (m.get("button") or {}).get("text")
                    else:
                        text = f"[{m.get('type')}]"  # áudio/imagem: ainda não suportado
                    out.append({"id": m.get("id"), "phone": normalize_phone(m.get("from")), "text": text or "",
                                "button": button, "name": names.get(m.get("from"))})
        return out


class EvolutionAdapter(Adapter):
    async def send_text(self, phone: str, text: str) -> None:
        s = get_settings()
        url = f"{s.evolution_url}/message/sendText/{s.evolution_instance}"
        try:
            async with httpx.AsyncClient(timeout=20) as c:
                r = await c.post(url, json={"number": phone, "text": text}, headers={"apikey": s.evolution_api_key or ""})
        except httpx.HTTPError as exc:
            raise RetryLater(f"Evolution API inacessível: {exc}", 30) from exc
        if r.status_code >= 500:
            raise RetryLater(f"Evolution API {r.status_code}", 60)
        if r.status_code >= 400:
            log.warning("Evolution API recusou a mensagem: %s %s", r.status_code, r.text[:300])

    @staticmethod
    def verify_token(request_token: str | None) -> bool:
        expected = get_settings().evolution_webhook_token
        return bool(expected and request_token and hmac.compare_digest(expected, request_token))

    @staticmethod
    def parse(payload: dict) -> list[dict]:
        event = str(payload.get("event") or "").lower().replace("_", ".")
        if event != "messages.upsert":
            return []
        items = payload.get("data")
        items = items if isinstance(items, list) else [items]
        out = []
        for d in items:
            if not isinstance(d, dict):
                continue
            key = d.get("key") or {}
            jid = str(key.get("remoteJid") or "")
            if key.get("fromMe") or not jid.endswith("@s.whatsapp.net"):
                continue  # mensagens nossas, grupos e estados
            msg = d.get("message") or {}
            text = msg.get("conversation") or (msg.get("extendedTextMessage") or {}).get("text") \
                or (msg.get("buttonsResponseMessage") or {}).get("selectedDisplayText")
            out.append({"id": key.get("id"), "phone": normalize_phone(jid), "text": text or "[mensagem não suportada]",
                        "button": None, "name": d.get("pushName")})
        return out


def adapter() -> Adapter:
    return CloudAdapter() if get_settings().whatsapp_provider == "cloud" else EvolutionAdapter()


# =========================================================================== processamento
# O envio é um job à parte: se o WhatsApp falhar, repete-se só o envio (não a conversa com o modelo).
async def queue_send(db: AsyncSession, phone: str, text: str, action_id: str | None = None) -> None:
    await enqueue(db, "assistant_whatsapp_send", {"phone": phone, "text": text, "action_id": action_id},
                  max_attempts=6)


@job_handler("assistant_whatsapp_send")
async def send(db: AsyncSession, payload: dict) -> None:
    ad = adapter()
    if payload.get("action_id"):
        await ad.send_confirm(payload["phone"], payload["text"], payload["action_id"])
    else:
        await ad.send_text(payload["phone"], payload["text"])


async def _send_turn(db: AsyncSession, phone: str, msgs: list[AssistantMessage]) -> None:
    for m in msgs:
        ui = m.ui or {}
        if ui.get("type") == "confirm":
            await queue_send(db, phone, to_whatsapp(f"Confirmas? {m.content}"), ui["action_id"])
        elif m.role == "assistant" and m.content:
            await queue_send(db, phone, to_whatsapp(m.content))
    await db.commit()


@job_handler("assistant_whatsapp")
async def process(db: AsyncSession, payload: dict) -> None:
    s = get_settings()
    if not s.whatsapp_enabled:
        return
    phone, text = str(payload["phone"]), str(payload.get("text") or "").strip()
    button = payload.get("button")
    ident = await identity_for(db, phone)

    # Um código válido liga o número (também se já estava ligado a outra conta: quem o envia controla as duas).
    m = LINK_RE.search(text)
    linked_user = await consume_link_code(db, m.group(1)) if m else None
    if ident is None or linked_user is not None:
        user = linked_user
        if user is not None:
            old = await db.scalar(select(ChannelIdentity).where(ChannelIdentity.channel == "whatsapp",
                                                                ChannelIdentity.external_id == phone))
            if old is not None:
                await db.delete(old)
            for prev in (await db.scalars(select(ChannelIdentity).where(ChannelIdentity.user_id == user.id,
                                                                        ChannelIdentity.channel == "whatsapp"))).all():
                await db.delete(prev)  # um número por conta
            await db.flush()
            db.add(ChannelIdentity(user_id=user.id, channel="whatsapp", external_id=phone, display=mask(phone),
                                   verified_at=utcnow()))
            audit(db, "assistant.whatsapp_linked", actor=user, target_type="user", target_id=user.id)
            await db.commit()
            await queue_send(db, phone, f"Olá {user.display_name or user.username}! 👋 Este número está agora ligado à "
                                      "tua conta TK Web Services. Podes perguntar-me sobre o TKFLIX (legendas, apps, "
                                      "problemas) ou sobre pagamentos. Escreve *novo* para recomeçar a conversa.")
            return
        # Uma resposta por número a cada 10 min (as instruções e o "código inválido" têm janelas separadas, para
        # o aviso de código errado não ser engolido pelas instruções enviadas há pouco).
        now = time.monotonic()
        key = f"{phone}:code" if m else phone
        last = _unlinked_notice.get(key)
        if last is None or now - last > 600:  # (monotonic pode ser < 600 logo após o arranque)
            _unlinked_notice[key] = now
            msg = ("Olá! Para falares com o assistente da TK Web Services por aqui, liga primeiro o teu número: no portal vai a "
                   f"*Conta → WhatsApp*, gera um código e envia-o nesta conversa.\n{s.public_url}/app/conta")
            if m:
                msg = "Esse código não é válido ou já expirou. Gera um novo no portal (Conta → WhatsApp)."
            await queue_send(db, phone, msg)
        return

    user = await db.get(User, ident.user_id)
    if user is None or not user.is_active:
        return
    low = text.lower()
    if low in ("desligar", "stop", "parar"):
        await db.delete(ident)
        audit(db, "assistant.whatsapp_unlinked", actor=user, target_type="user", target_id=user.id)
        await db.commit()
        await queue_send(db, phone, "Número desligado da tua conta. Até breve! 👋")
        return
    if low in ("novo", "reset", "recomeçar", "recomecar"):
        for c in (await db.scalars(select(AssistantConversation).where(
                AssistantConversation.channel == "whatsapp", AssistantConversation.external_ref == phone,
                AssistantConversation.status.in_(["open", "escalated"])))).all():
            c.status = "closed"
        await db.commit()
        await queue_send(db, phone, "Conversa nova. Em que posso ajudar? 🙂")
        return

    if button and ":" in str(button):
        kind, action_id = str(button).split(":", 1)
        action = await db.get(PendingAction, action_id)
        if action is not None:
            try:
                msg = await runtime.decide_action(db, action, user, confirm=kind == "confirm")
                await _send_turn(db, phone, [msg])
            except ToolFailure as exc:
                await queue_send(db, phone, str(exc))
            return

    conv = await runtime.get_or_create_conversation(db, user=user, channel="whatsapp", external_ref=phone)
    result = await runtime.handle_message(db, conv, user, text)
    await _send_turn(db, phone, result.messages)
