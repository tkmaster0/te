"""Issues do Seerr → Agente de Suporte.

Duas formas de o portal saber das issues (podem estar as duas ligadas — cada comentário só é tratado uma vez):
  * **Leitura automática (por omissão):** a cada 2 minutos o portal lê as issues abertas pela API do Seerr. Não
    ocupa o webhook do Seerr (que só tem um — ex.: já usado pelo Moonfin).
  * **Webhook (opcional, mais imediato):** Definições → Notificações → Webhook, URL https://<portal>/api/webhooks/seerr,
    Authorization Header = SEERR_WEBHOOK_SECRET, tipos "Issue Reported" e "Issue Comment".

Uma issue nova é analisada pelo agente de suporte (ex.: legendas em falta → procura e descarrega; legenda
dessincronizada → sincroniza), a resposta é publicada como comentário e, se ficou resolvida, a issue é fechada.
Comentários do cliente continuam a conversa; comentários do próprio assistente e da equipa são ignorados.
"""
from __future__ import annotations

import logging
from datetime import timedelta
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from ...config import get_settings
from ...db import utcnow
from ...integrations.seerr import SeerrClient, SeerrError
from ...models import ConfigEntry, ServiceAccount, User
from ...services.jobs import PermanentError, RetryLater, enqueue, job_handler
from .. import runtime
from ..models import AssistantConversation

log = logging.getLogger("tkportal.assistant.seerr")

EVENTS = {"ISSUE_CREATED", "ISSUE_COMMENT"}


async def _find_user(db: AsyncSession, created_by: dict) -> User | None:
    jf = str(created_by.get("jellyfinUserId") or "").replace("-", "")
    if jf:
        sa = await db.scalar(select(ServiceAccount).where(ServiceAccount.service == "jellyfin",
                                                          ServiceAccount.external_id.in_([jf, created_by.get("jellyfinUserId")])))
        if sa:
            return await db.get(User, sa.user_id)
    sid = created_by.get("id")
    if sid is not None:
        sa = await db.scalar(select(ServiceAccount).where(ServiceAccount.service == "seerr",
                                                          ServiceAccount.external_id == str(sid)))
        if sa:
            return await db.get(User, sa.user_id)
    # Sem correspondência por email: no Seerr o email é editável pelo próprio utilizador, e um email copiado dava
    # ao agente acesso aos dados (dispositivos, pedidos, reprodução) de outro cliente.
    return None


def _describe(issue: dict) -> str:
    media = issue.get("media") or {}
    itype = SeerrClient.ISSUE_TYPES.get(issue.get("issueType"), "outro")
    parts = [f"Issue #{issue.get('id')} reportada no Seerr — tipo: {itype}."]
    if media.get("mediaType") == "tv":
        s, e = issue.get("problemSeason") or 0, issue.get("problemEpisode") or 0
        where = "série" + (f", temporada {s}" if s else " (todas as temporadas)") + (f", episódio {e}" if e else "")
        parts.append(f"Título: {where}.")
    jf_id = media.get("jellyfinMediaId") or media.get("jellyfinMediaId4k")
    if jf_id:
        parts.append(f"item_id no Jellyfin ({'série' if media.get('mediaType') == 'tv' else 'filme'}): {jf_id}")
    parts.append(f"TMDB: {media.get('tmdbId')}")
    comments = issue.get("comments") or []
    if comments:
        parts.append(f"Descrição do cliente: {comments[0].get('message', '')[:1500]}")
    return "\n".join(parts)


async def _existing(db: AsyncSession, issue_id: int) -> AssistantConversation | None:
    return await db.scalar(select(AssistantConversation).where(
        AssistantConversation.channel == "seerr", AssistantConversation.external_ref == str(issue_id))
        .order_by(AssistantConversation.created_at.desc()).limit(1))


def _cid(c: dict) -> int:
    try:
        return int(c.get("id") or 0)
    except (TypeError, ValueError):
        return 0


def _new_customer_comments(conv: AssistantConversation, comments: list[dict], creator_id: Any,
                           prefix: str) -> list[str]:
    """Comentários do cliente ainda não tratados (os do assistente e da equipa são ignorados)."""
    last = (conv.meta or {}).get("last_comment_id")
    if last is None:  # conversa antiga, de antes deste registo: só o último comentário conta
        pending = comments[-1:] if len(comments) >= 2 else []
    else:
        pending = [c for c in comments if _cid(c) > int(last)]
    out = []
    for c in pending:
        text = str(c.get("message") or "").strip()
        if text and not text.startswith(prefix) and (c.get("user") or {}).get("id") == creator_id:
            out.append(text)
    return out


def _mark(conv: AssistantConversation, comments: list[dict]) -> None:
    top = max((_cid(c) for c in comments), default=0)
    meta = dict(conv.meta or {})
    meta["last_comment_id"] = max(top, int(meta.get("last_comment_id") or 0))
    conv.meta = meta  # JSON: reatribuir para o SQLAlchemy gravar


@job_handler("assistant_seerr")
async def process(db: AsyncSession, payload: dict) -> None:
    s = get_settings()
    if not (s.assistant_ready and s.seerr_enabled and s.seerr_auto_triage):
        return
    issue_id = int(payload["issue_id"])
    sc = SeerrClient()
    try:
        issue = await sc.get_issue(issue_id)
    except SeerrError as exc:
        if exc.status == 404:
            raise PermanentError("issue não existe") from exc
        raise RetryLater(str(exc), 120) from exc
    if issue.get("status") != 1:  # já resolvida
        return
    created_by = issue.get("createdBy") or {}
    user = await _find_user(db, created_by)
    if user is None:
        # Sem cliente associado (equipa, conta antiga...) o agente não tem ferramentas úteis e qualquer utilizador do
        # Seerr podia gastar chamadas pagas ao modelo abrindo issues: fica para um humano.
        log.info("Issue %s de um utilizador do Seerr sem conta no portal — sem triagem automática.", issue_id)
        return
    comments = issue.get("comments") or []
    prefix = s.seerr_bot_prefix or "🤖"
    # O que fazer não depende de quem avisou (webhook ou leitura automática): issue sem conversa → triagem;
    # com conversa → só os comentários novos do cliente. Avisos repetidos não geram respostas repetidas.
    conv = await _existing(db, issue_id)
    if conv is None:
        recent = await db.scalar(select(func.count()).select_from(AssistantConversation).where(
            AssistantConversation.channel == "seerr",
            AssistantConversation.created_at >= utcnow() - timedelta(hours=1)))
        if (recent or 0) >= s.assistant_seerr_max_per_hour:
            log.warning("Limite de triagens do Seerr por hora atingido — issue %s fica para um humano.", issue_id)
            return
        conv = AssistantConversation(user_id=user.id, channel="seerr", external_ref=str(issue_id),
                                     agent="support", scope="streaming", meta={"issue_id": issue_id})
        db.add(conv)
        await db.flush()
        message = _describe(issue)
    else:
        if conv.status in ("escalated", "closed"):
            _mark(conv, comments)
            await db.commit()
            return  # uma pessoa está a tratar
        new = _new_customer_comments(conv, comments, created_by.get("id"), prefix)
        _mark(conv, comments)
        if not new:
            await db.commit()
            return  # comentário nosso, da equipa, ou nada de novo
        message = f"Novo comentário do cliente na issue #{issue_id}: " + "\n".join(new)[:1500]
    _mark(conv, comments)
    extra: dict = {"issue_id": issue_id}
    result = await runtime.handle_message(db, conv, user, message, extra=extra)
    reply = next((m.content for m in reversed(result.messages) if m.role == "assistant" and m.content), None)
    try:
        if reply:
            await sc.comment_issue(issue_id, f"{prefix} {reply}"[:2000])
        if extra.get("resolve") and reply != runtime.UNAVAILABLE:  # o modelo falhou a meio: não fechar
            await sc.set_issue_status(issue_id, "resolved")
            conv.status = "resolved"
            await db.commit()
    except SeerrError as exc:
        log.warning("Não consegui responder à issue %s: %s", issue_id, exc)


# ---------------------------------------------------------------------------------------- leitura automática
POLL_KEY = "_seerr_issue_poll"
POLL_TAKE = 50


def _fingerprint(issue: dict) -> str | None:
    if issue.get("updatedAt"):
        return str(issue["updatedAt"])
    comments = issue.get("comments")
    if isinstance(comments, list):
        return f"c{max((_cid(c) for c in comments), default=0)}:{len(comments)}"
    return None


async def poll(db: AsyncSession, sc: SeerrClient | None = None) -> int:
    """Lê as issues abertas do Seerr e põe na fila as novas ou com alterações (substitui o webhook).

    Na primeira leitura só regista o que já existe (não responde a issues antigas). Devolve quantas foram para a fila.
    """
    s = get_settings()
    if not (s.assistant_ready and s.seerr_enabled and s.seerr_auto_triage and s.seerr_poll_enabled):
        return 0
    sc = sc or SeerrClient()
    try:
        issues = await sc.issues(status="open", take=POLL_TAKE)
    except SeerrError as exc:
        log.info("Seerr: não consegui ler as issues (%s)", exc)
        return 0
    state = await db.get(ConfigEntry, POLL_KEY)
    first = state is None
    seen: dict[str, str] = dict((state.value or {}).get("seen") or {}) if state and isinstance(state.value, dict) else {}
    now_seen: dict[str, str] = {}
    queued = 0
    for issue in issues:
        iid = str(issue.get("id") or "")
        if not iid.isdigit():
            continue
        fp = _fingerprint(issue)
        if fp is None:  # versão do Seerr sem updatedAt nem comentários na lista: lê a issue
            try:
                fp = _fingerprint(await sc.get_issue(int(iid))) or ""
            except SeerrError:
                fp = seen.get(iid, "")
        now_seen[iid] = fp
        if first or seen.get(iid) == fp:
            continue
        await enqueue(db, "assistant_seerr", {"issue_id": int(iid), "event": "POLL"},
                      dedupe_key=f"seerr-issue:{iid}", max_attempts=4)
        queued += 1
    value = {"seen": now_seen, "checked_at": utcnow().isoformat()}
    if state is None:
        db.add(ConfigEntry(key=POLL_KEY, value=value, secret=False))
    else:
        state.value = value
    await db.commit()
    if queued:
        log.info("Seerr: %d issue(s) nova(s) ou com comentários para o assistente.", queued)
    return queued
