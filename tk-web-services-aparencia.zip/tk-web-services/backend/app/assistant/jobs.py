"""Handlers de jobs dos assistentes (importado por services.tasks para os registar)."""
from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from ..services.jobs import job_handler
from . import learning, memory  # noqa: F401 — memory regista o seu handler
from .channels import seerr, whatsapp  # noqa: F401 — registam os seus handlers


@job_handler("assistant_learn")
async def _learn(db: AsyncSession, payload: dict) -> None:
    await learning.run(db)
