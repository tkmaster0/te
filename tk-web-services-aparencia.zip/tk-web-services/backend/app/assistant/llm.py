"""Acesso ao modelo de linguagem através do LiteLLM.

Com o LiteLLM qualquer fornecedor serve (Anthropic, OpenAI, Gemini, Mistral, Ollama local, OpenRouter, um proxy
LiteLLM, ...): basta mudar `ASSISTANT_MODEL` / `ASSISTANT_API_BASE` / `ASSISTANT_API_KEY` no `.env`.

O resto do módulo só conhece `LLM.complete()` e `LLM.embed()`; os testes trocam-no por um modelo falso.
"""
from __future__ import annotations

import json
import logging
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from ..config import get_settings

log = logging.getLogger("tkportal.assistant.llm")


class LLMError(Exception):
    pass


@dataclass
class ToolCall:
    id: str
    name: str
    arguments: dict[str, Any]
    raw_arguments: str = ""


@dataclass
class LLMResponse:
    content: str | None
    tool_calls: list[ToolCall] = field(default_factory=list)
    model: str | None = None
    tokens_in: int | None = None
    tokens_out: int | None = None


class LLM:
    """Implementação real (LiteLLM)."""

    def __init__(self) -> None:
        s = get_settings()
        self.model = s.assistant_model
        self.fast_model = s.assistant_fast_model or s.assistant_model
        self.api_base = s.assistant_api_base
        self.api_key = s.assistant_api_key
        self.timeout = s.assistant_timeout_seconds
        self.temperature = s.assistant_temperature
        self.embedding_model = s.assistant_embedding_model

    def _kw(self) -> dict[str, Any]:
        kw: dict[str, Any] = {"timeout": self.timeout}
        if self.api_base:
            kw["api_base"] = self.api_base
        if self.api_key:
            kw["api_key"] = self.api_key
        return kw

    @staticmethod
    def _litellm():
        try:
            import litellm
        except ImportError as exc:  # pragma: no cover — dependência instalada no Docker
            raise LLMError("O pacote litellm não está instalado.") from exc
        litellm.drop_params = True  # parâmetros não suportados por um fornecedor são ignorados, não dão erro
        on = get_settings().assistant_langfuse
        if on and "langfuse" not in (litellm.success_callback or []):
            litellm.success_callback = [*(litellm.success_callback or []), "langfuse"]
            litellm.failure_callback = [*(litellm.failure_callback or []), "langfuse"]
        elif not on and "langfuse" in (litellm.success_callback or []):   # desligado por web
            litellm.success_callback = [c for c in litellm.success_callback if c != "langfuse"]
            litellm.failure_callback = [c for c in (litellm.failure_callback or []) if c != "langfuse"]
        return litellm

    async def complete(self, messages: list[dict], tools: list[dict] | None = None, *, fast: bool = False,
                       metadata: dict | None = None, json_mode: bool = False) -> LLMResponse:
        if not self.model:
            raise LLMError("ASSISTANT_MODEL não configurado.")
        litellm = self._litellm()
        kw = self._kw()
        if tools:
            kw["tools"] = tools
            kw["tool_choice"] = "auto"
        if json_mode:
            kw["response_format"] = {"type": "json_object"}
        if metadata and get_settings().assistant_langfuse:
            kw["metadata"] = metadata
        try:
            resp = await litellm.acompletion(model=self.fast_model if fast else self.model, messages=messages,
                                             temperature=self.temperature, **kw)
        except Exception as exc:
            log.warning("LLM falhou: %s", exc)
            raise LLMError(str(exc)[:300]) from exc
        msg = resp.choices[0].message
        calls = []
        for tc in getattr(msg, "tool_calls", None) or []:
            raw = tc.function.arguments or "{}"
            try:
                args = json.loads(raw) if isinstance(raw, str) else dict(raw)
            except json.JSONDecodeError:
                args = {"_invalid_json": raw[:500]}
            calls.append(ToolCall(id=tc.id or f"call_{len(calls)}", name=tc.function.name, arguments=args,
                                  raw_arguments=raw if isinstance(raw, str) else json.dumps(raw)))
        usage = getattr(resp, "usage", None)
        return LLMResponse(content=msg.content, tool_calls=calls, model=getattr(resp, "model", None),
                           tokens_in=getattr(usage, "prompt_tokens", None),
                           tokens_out=getattr(usage, "completion_tokens", None))

    async def embed(self, texts: list[str]) -> list[list[float]] | None:
        if not self.embedding_model or not texts:
            return None
        litellm = self._litellm()
        try:
            resp = await litellm.aembedding(model=self.embedding_model, input=texts, **self._kw())
        except Exception as exc:  # noqa: BLE001
            log.warning("Embeddings falharam (uso pesquisa por palavras): %s", exc)
            return None
        return [list(d["embedding"]) if isinstance(d, dict) else list(d.embedding) for d in resp.data]


_factory: Callable[[], Any] = LLM


def get_llm():
    return _factory()


def set_llm_factory(factory: Callable[[], Any] | None) -> None:
    """Testes: substitui o modelo por um falso."""
    global _factory
    _factory = factory or LLM
