"""Webhooks dos fornecedores de pagamento.

Validam a assinatura sobre o corpo em bruto, guardam o evento (deduplicado pelo id) e enfileiram o
processamento — respondem em milissegundos, como a GoCardless e o Stripe recomendam.
"""
from __future__ import annotations

import json
import logging

from fastapi import APIRouter, Depends, Request, Response
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from ..db import get_db
from ..integrations import stripe_client as sc
from ..integrations.gocardless import verify_signature
from ..models import WebhookEvent
from ..services.jobs import enqueue

log = logging.getLogger("tkportal.webhooks")
router = APIRouter(prefix="/api/webhooks", tags=["webhooks"])


async def _store(db: AsyncSession, provider: str, event_id: str, event_type: str, payload: dict) -> bool:
    exists = await db.scalar(select(WebhookEvent.id).where(WebhookEvent.provider == provider,
                                                           WebhookEvent.event_id == event_id))
    if exists:
        return False
    ev = WebhookEvent(provider=provider, event_id=event_id, event_type=event_type, payload=payload)
    try:
        # Savepoint: um evento repetido (corrida entre duas entregas) só desfaz esse evento — um rollback total
        # deitava fora os outros eventos do mesmo lote, e o fornecedor recebia 200 e não os reenviava.
        async with db.begin_nested():
            db.add(ev)
    except IntegrityError:
        return False
    await enqueue(db, "process_webhook", {"id": ev.id}, max_attempts=10)
    return True


@router.post("/gocardless")
async def gocardless_webhook(request: Request, db: AsyncSession = Depends(get_db)):
    s = get_settings()
    body = await request.body()
    if not s.gocardless_webhook_secret or not verify_signature(body, request.headers.get("Webhook-Signature"),
                                                              s.gocardless_webhook_secret):
        log.warning("Webhook GoCardless com assinatura inválida")
        return Response(status_code=498)
    try:
        data = json.loads(body)
    except ValueError:
        return Response(status_code=400)
    new = 0
    for ev in data.get("events", []):
        if await _store(db, "gocardless", ev["id"], f"{ev.get('resource_type')}.{ev.get('action')}", ev):
            new += 1
    await db.commit()
    return {"received": new}


@router.post("/stripe")
async def stripe_webhook(request: Request, db: AsyncSession = Depends(get_db)):
    s = get_settings()
    body = await request.body()
    if not s.stripe_webhook_secret:
        return Response(status_code=400)
    try:
        event = sc.construct_event(body, request.headers.get("Stripe-Signature"))
    except (ValueError, sc.stripe.SignatureVerificationError):
        log.warning("Webhook Stripe com assinatura inválida")
        return Response(status_code=400)
    await _store(db, "stripe", event["id"], event.get("type", ""), event)
    await db.commit()
    return {"received": True}
