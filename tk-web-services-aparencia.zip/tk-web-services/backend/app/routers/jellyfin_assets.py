"""Integração com o Jellyfin servida pelo portal: o widget de ajuda (JavaScript Injector), a página "A minha conta"
(Custom Pages) e o botão de SSO — sempre com o endereço do portal já preenchido.

Admin → Jellyfin mostra exatamente o que colar em cada plugin.
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from ..db import get_db
from ..deps import require_admin
from ..integrations.jellyfin import JellyfinError
from ..models import User
from ..services import jellyfin_help
from ..services.audit import audit
from ..services.oidc_presets import JELLYFIN_PROVIDER

FILES = Path(__file__).resolve().parent.parent / "jellyfin_files"
router = APIRouter(tags=["jellyfin"])
admin_router = APIRouter(prefix="/api/admin/jellyfin", tags=["admin"], dependencies=[Depends(require_admin)])


@lru_cache
def _template(name: str) -> str:
    return (FILES / name).read_text(encoding="utf-8")


def render(name: str) -> str:
    # json-safe: o endereço vai dentro de uma string JS entre aspas.
    url = get_settings().public_url.replace("\\", "").replace('"', "")
    return _template(name).replace("__PORTAL_URL__", url)


def loader_js() -> str:
    url = get_settings().public_url
    return ("(function () {\n"
            "  if (window.__tkwsLoader) return; window.__tkwsLoader = true;\n"
            "  var s = document.createElement('script');\n"
            f"  s.src = '{url}/jellyfin/widget.js';\n"
            "  s.async = true;\n"
            "  document.head.appendChild(s);\n"
            "})();\n")


def sso_button_html() -> str:
    return (f'<form action="/sso/OID/start/{JELLYFIN_PROVIDER}">\n'
            '  <button class="raised block emby-button button-submit tk-sso">Entrar com a conta TK Web Services'
            '</button>\n</form>\n'
            '<p class="tk-sso-hint">Na TV ou numa app sem este botão? Usa o <b>Quick Connect</b> na área de '
            'cliente.</p>')


SSO_CSS = (".tk-sso { background:#f5c518 !important; color:#0b0b0c !important; font-weight:700; border-radius:8px;"
           " margin-top:.5em; }\n.tk-sso:hover { filter:brightness(1.08); }\n"
           ".tk-sso-hint { opacity:.7; font-size:.85em; text-align:center; margin-top:.8em; }")


@router.get("/jellyfin/widget.js", include_in_schema=False)
async def widget_js():
    return Response(render("support-widget.js"), media_type="application/javascript; charset=utf-8",
                    headers={"Cache-Control": "public, max-age=300"})


@router.get("/jellyfin/conta.html", include_in_schema=False)
async def conta_html():
    # Servida como texto (para copiar/descarregar) — a página corre dentro do Jellyfin, não no portal.
    return Response(render("conta.html"), media_type="text/plain; charset=utf-8",
                    headers={"Cache-Control": "no-cache", "Content-Disposition": 'inline; filename="conta.html"'})


@admin_router.get("/snippets")
async def snippets():
    s = get_settings()
    jf = s.jellyfin_public_url
    return {
        "portal_url": s.public_url,
        "jellyfin_url": jf,
        "jellyfin_origin_ok": bool(jf),
        "js_loader": loader_js(),
        "js_full": render("support-widget.js"),
        "custom_page": render("conta.html"),
        "sso_button_html": sso_button_html(),
        "sso_css": SSO_CSS,
        "links": {
            "plugins": f"{jf}/web/#/dashboard/plugins" if jf else None,
            "catalog": f"{jf}/web/#/dashboard/plugins/catalog" if jf else None,
            "repositories": f"{jf}/web/#/dashboard/plugins/repositories" if jf else None,
            "branding": f"{jf}/web/#/dashboard/branding" if jf else None,
            "api_keys": f"{jf}/web/#/dashboard/keys" if jf else None,
            "account_page": f"{jf}/web/#/userpluginsettings.html" if jf else None,
        },
        "repositories": [
            {"name": "JavaScript Injector (n00bcodr) — Jellyfin 12",
             "url": "https://raw.githubusercontent.com/n00bcodr/jellyfin-plugins/main/12/manifest.json"},
            {"name": "JavaScript Injector (n00bcodr) — Jellyfin 10.11",
             "url": "https://raw.githubusercontent.com/n00bcodr/jellyfin-plugins/main/10.11/manifest.json"},
            {"name": "Custom Pages (JPKribs)",
             "url": "https://raw.githubusercontent.com/JPKribs/jellyfin-plugin-custompages/master/manifest.json"},
            {"name": "Jellyfin Security (ZL154)",
             "url": "https://raw.githubusercontent.com/ZL154/JellyfinSecurity/main/manifest.json"},
        ],
    }


# ---------------------------------------------------------------- apps nativas (Android TV, Swiftfin, Moonfin, …)
@admin_router.get("/help")
async def help_status(db: AsyncSession = Depends(get_db)):
    return await jellyfin_help.status(db)


@admin_router.post("/help")
async def help_publish(admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    try:
        out = await jellyfin_help.publish(db, actor_id=admin.id)
    except JellyfinError as exc:
        raise HTTPException(502, str(exc)) from exc
    audit(db, "admin.jellyfin_help_published", actor=admin, item_id=out["id"], created=out["created"])
    await db.commit()
    return out


@admin_router.get("/help/{kind}.png", include_in_schema=False)
async def help_image(kind: str):
    if kind not in ("poster", "backdrop"):
        raise HTTPException(404)
    png = jellyfin_help.poster_png() if kind == "poster" else jellyfin_help.backdrop_png()
    return Response(png, media_type="image/png", headers={"Cache-Control": "no-store"})
