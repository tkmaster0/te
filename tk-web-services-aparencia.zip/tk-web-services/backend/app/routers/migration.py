"""Admin → Migração: tudo o que é preciso para trazer os clientes antigos, pela web e com o mínimo de esforço.

1. Carregar o `users.db` do site antigo (simular → importar).
2. Ligar as subscrições GoCardless (ficam na GoCardless e passam sozinhas para o portal na 1.ª alteração do cliente).
3. Stripe (TKGPT), se houver.
4. Painel de estado: quem continua na GoCardless, quem já passou, e botão para converter já.
"""
from __future__ import annotations

import os
import tempfile

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from pydantic import BaseModel
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from ..db import get_db
from ..deps import rate_limit, require_admin
from ..models import Plan, Subscription, SubStatus, User
from ..services import legacy, legacy_import
from ..services.audit import audit
from ..services.billing import BillingError
from ..services.subscriptions import fmt_money

router = APIRouter(prefix="/api/admin/migration", tags=["admin-migration"], dependencies=[Depends(require_admin)])

MAX_DB_BYTES = 50 * 1024 * 1024


@router.get("/status")
async def status(db: AsyncSession = Depends(get_db)):
    s = get_settings()
    live = [st.value for st in (SubStatus.active, SubStatus.bonus, SubStatus.past_due, SubStatus.canceling)]
    rows = (await db.execute(
        select(Subscription, User.username, User.email, Plan.name)
        .join(User, User.id == Subscription.user_id).join(Plan, Plan.id == Subscription.plan_id)
        .where(Subscription.provider == "gocardless", Subscription.status.in_(live))
        .order_by(Subscription.current_period_end))).all()
    converted = await db.scalar(select(func.count()).select_from(Subscription).where(
        Subscription.provider == "portal", Subscription.meta.is_not(None),
        Subscription.provider_subscription_id.is_not(None)))
    imported = await db.scalar(select(func.count()).select_from(User).where(User.legacy_id.is_not(None)))
    with_gc = await db.scalar(select(func.count()).select_from(User).where(
        (User.gocardless_mandate_id.is_not(None)) | (User.gocardless_customer_id.is_not(None))))
    return {
        "gocardless_configured": s.gocardless_enabled,
        "stripe_configured": s.stripe_enabled,
        "imported_users": imported,
        "users_with_gocardless": with_gc,
        "converted": converted,
        "legacy": [{
            "subscription_id": sub.id, "username": uname, "email": email, "plan": pname, "status": sub.status,
            "price": fmt_money(sub.price_cents or 0), "next_charge": sub.current_period_end.isoformat()
            if sub.current_period_end else None, "gc_subscription": sub.provider_subscription_id,
        } for sub, uname, email, pname in rows],
    }


@router.post("/legacy-db")
async def upload_legacy_db(file: UploadFile = File(...), dry_run: bool = Form(True), keep_gocardless: bool = Form(True),
                           link_gocardless: bool = Form(True), admin: User = Depends(require_admin),
                           db: AsyncSession = Depends(get_db)):
    """Carrega o users.db do site antigo. Primeiro com dry_run (nada é gravado), depois a sério."""
    rate_limit(f"legacy-db:{admin.id}", 20, 3600)
    data = await file.read(MAX_DB_BYTES + 1)
    if len(data) > MAX_DB_BYTES:
        raise HTTPException(413, detail="Ficheiro demasiado grande (máx. 50 MB).")
    if not data.startswith(b"SQLite format 3"):
        raise HTTPException(400, detail="Não é uma base de dados SQLite (o users.db do site antigo).")
    fd, path = tempfile.mkstemp(suffix=".db")
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
        report = await legacy_import.import_sqlite(db, path, dry_run=dry_run, link_gocardless=link_gocardless,
                                                   keep_gocardless=keep_gocardless, admin_username=admin.username)
    except legacy_import.ImportError_ as exc:
        raise HTTPException(400, detail=str(exc)) from exc
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass
    if not dry_run:
        audit(db, "admin.legacy_import", actor=admin, new=report["new"], existing=report["existing"])
        await db.commit()
    report["users"] = report["users"][:500]
    return report


class GcLinkIn(BaseModel):
    dry_run: bool = True
    keep: bool = True
    create_users: bool = True


@router.post("/gocardless")
async def link_gocardless(body: GcLinkIn, admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    """Liga todas as subscrições GoCardless ativas: primeiro pelos dados do site antigo (mandato/cliente), depois
    as restantes pelo email (cria a conta se não existir)."""
    if not get_settings().gocardless_enabled:
        raise HTTPException(400, detail="Configura primeiro a GoCardless (Definições → GoCardless).")
    results = await legacy.migrate_all(db, dry_run=body.dry_run, keep=body.keep)
    seen = {r.get("gc_subscription") for r in results}
    for r in await legacy.import_from_gocardless(db, dry_run=body.dry_run, keep=body.keep,
                                                 create_users=body.create_users):
        if r.get("gc_subscription") not in seen:
            results.append(r)
    if body.dry_run:
        await db.rollback()
    else:
        audit(db, "admin.gocardless_linked", actor=admin, count=len(results), keep=body.keep)
        await db.commit()
    ok = sum(1 for r in results if str(r.get("result", "")).startswith(("ligada", "seria", "migrada", "convertida")))
    return {"dry_run": body.dry_run, "count": ok, "results": results}


class ConvertIn(BaseModel):
    subscription_id: str | None = None
    all: bool = False


@router.post("/convert")
async def convert(body: ConvertIn, admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    """Passa já subscrições antigas para a faturação do portal (normalmente acontece sozinho na 1.ª alteração)."""
    if body.subscription_id:
        subs = [await db.get(Subscription, body.subscription_id)]
    elif body.all:
        subs = list((await db.scalars(select(Subscription).where(Subscription.provider == "gocardless"))).all())
    else:
        raise HTTPException(400, detail="Indica a subscrição ou todas.")
    done, errors = 0, []
    for sub in subs:
        if sub is None or sub.provider != "gocardless":
            continue
        sid = sub.id
        try:
            await legacy.convert_subscription(db, sub, reason="admin")
            await db.commit()
            done += 1
        except BillingError as exc:
            await db.rollback()
            errors.append(f"{sid}: {exc}")
    audit(db, "admin.legacy_converted", actor=admin, count=done)
    await db.commit()
    return {"converted": done, "errors": errors,
            "message": f"{done} subscrição(ões) passaram para o portal." + (f" {len(errors)} com erro." if errors else "")}
