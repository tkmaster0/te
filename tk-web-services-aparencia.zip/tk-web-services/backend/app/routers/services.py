from __future__ import annotations

from urllib.parse import quote

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from ..db import get_db
from ..deps import rate_limit, require_user
from ..integrations.jellyfin import JellyfinClient, JellyfinError
from ..models import User
from ..schemas import DeviceOut, Ok, PasswordOnlyIn, QuickConnectIn
from ..security import decrypt, verify_password
from ..serializers import site_settings
from ..services.audit import audit
from ..services.provisioning import get_account, queue_jellyfin_password
from ..services.subscriptions import compute_access, request_reconcile

router = APIRouter(prefix="/api/services", tags=["services"])


@router.get("")
async def my_services(user: User = Depends(require_user), db: AsyncSession = Depends(get_db)):
    s = get_settings()
    access = await compute_access(db, user)
    f = access.features
    jf = await get_account(db, user.id, "jellyfin")
    seerr = await get_account(db, user.id, "seerr")
    dc = await get_account(db, user.id, "dispatcharr")
    manual = await get_account(db, user.id, "iptv")
    site = await site_settings(db)

    iptv: dict = {"enabled": f.iptv.enabled or manual is not None, "source": None}
    if f.iptv.enabled and dc and dc.external_id and (dc.applied_state or {}).get("enabled"):
        server = s.dispatcharr_public_url or s.dispatcharr_url
        pwd = decrypt(dc.secret_enc)
        iptv.update({
            "source": "dispatcharr", "username": dc.external_username, "password": pwd, "server": server,
            "m3u_url": f"{server}/get.php?username={quote(dc.external_username or '')}&password={quote(pwd or '')}"
                       "&type=m3u_plus&output=ts",
            "epg_url": f"{server}/xmltv.php?username={quote(dc.external_username or '')}&password={quote(pwd or '')}",
            "stream_limit": f.iptv.stream_limit,
        })
    elif manual:
        iptv.update({"source": "manual", "username": manual.external_username, "password": decrypt(manual.secret_enc),
                     "server": (manual.data or {}).get("host")})
    elif f.iptv.enabled:
        iptv["pending"] = True

    return {
        "jellyfin": {
            "configured": s.jellyfin_enabled,
            "enabled": f.jellyfin.enabled,
            "url": s.jellyfin_public_url,
            "username": (jf.external_username if jf else None) or user.username,
            "linked": bool(jf and jf.external_id),
            "needs_password_sync": user.needs_password_sync and user.jellyfin_password_login,
            "password_login": bool(user.jellyfin_password_login),
            "max_streams": f.jellyfin.max_streams,
            "live_tv": f.jellyfin.live_tv,
            "downloads": f.jellyfin.downloads,
            "last_error": jf.last_error if jf and user.is_admin else None,
        },
        "seerr": {
            "configured": s.seerr_enabled,
            "enabled": f.seerr.enabled,
            "url": s.seerr_public_url,
            "linked": bool(seerr and seerr.external_id),
            "movie_quota": f.seerr.movie_quota, "movie_quota_days": f.seerr.movie_quota_days,
            "tv_quota": f.seerr.tv_quota, "tv_quota_days": f.seerr.tv_quota_days,
        },
        "iptv": iptv,
        "apps": site.get("apps") or [],
    }


class IptvPasswordIn(BaseModel):
    # Vazio = gerar uma nova password simples
    password: str | None = Field(None, max_length=32)


@router.post("/iptv/password")
async def change_iptv_password(body: IptvPasswordIn, user: User = Depends(require_user),
                               db: AsyncSession = Depends(get_db)):
    """O cliente muda a password da TV quando quiser (ou gera outra). Fica logo ativa no Dispatcharr."""
    from ..integrations.dispatcharr import DispatcharrError
    from ..services.provisioning import set_iptv_password

    rate_limit(f"iptv-pwd:{user.id}", 10, 3600)
    try:
        pwd = await set_iptv_password(db, user, body.password)
    except ValueError as exc:
        raise HTTPException(400, detail=str(exc)) from exc
    except DispatcharrError as exc:
        await db.rollback()
        raise HTTPException(502, detail="O servidor de TV não respondeu — tenta outra vez daqui a pouco.") from exc
    audit(db, "iptv.password_changed", actor=user, target_type="user", target_id=user.id,
          generated=not (body.password or "").strip())
    await db.commit()
    return {"status": "ok", "password": pwd, "message": "Password da TV atualizada. Usa-a nos teus aparelhos."}


async def _jf_id(db: AsyncSession, user: User) -> str:
    sa = await get_account(db, user.id, "jellyfin")
    if not sa or not sa.external_id:
        raise HTTPException(400, detail="A tua conta Jellyfin ainda não está criada.")
    return sa.external_id


@router.get("/jellyfin/devices", response_model=list[DeviceOut])
async def devices(user: User = Depends(require_user), db: AsyncSession = Depends(get_db)):
    jf_id = await _jf_id(db, user)
    try:
        items = await JellyfinClient().devices(jf_id)
    except JellyfinError as exc:
        raise HTTPException(502, detail="O Jellyfin não respondeu.") from exc
    return [DeviceOut(id=d.get("Id"), name=d.get("CustomName") or d.get("Name"), app=
                      f"{d.get('AppName') or ''} {d.get('AppVersion') or ''}".strip() or None,
                      last_active=d.get("DateLastActivity"))
            for d in items]


@router.delete("/jellyfin/devices/{device_id}", response_model=Ok)
async def delete_device(device_id: str, user: User = Depends(require_user), db: AsyncSession = Depends(get_db)):
    jf_id = await _jf_id(db, user)
    jf = JellyfinClient()
    try:
        mine = {d.get("Id") for d in await jf.devices(jf_id)}  # o Jellyfin já filtra por utilizador
        if device_id not in mine:
            raise HTTPException(404, detail="Dispositivo não encontrado.")
        await jf.delete_device(device_id)
    except JellyfinError as exc:
        raise HTTPException(502, detail="O Jellyfin não respondeu.") from exc
    audit(db, "jellyfin.device_removed", actor=user, target_type="user", target_id=user.id, device=device_id)
    await db.commit()
    return Ok(message="Dispositivo removido — terá de voltar a fazer login.")


@router.post("/jellyfin/quick-connect", response_model=Ok)
async def quick_connect(body: QuickConnectIn, user: User = Depends(require_user), db: AsyncSession = Depends(get_db)):
    rate_limit(f"qc:{user.id}", 10, 600)
    access = await compute_access(db, user)
    if not access.features.jellyfin.enabled:
        raise HTTPException(403, detail="Precisas de uma subscrição ativa.")
    jf_id = await _jf_id(db, user)
    code = "".join(ch for ch in body.code if ch.isalnum())
    try:
        ok = await JellyfinClient().quick_connect_authorize(code, jf_id)
    except JellyfinError as exc:
        raise HTTPException(400, detail="Código inválido ou expirado (ou o Quick Connect está desativado).") from exc
    if not ok:
        raise HTTPException(400, detail="Código inválido ou expirado.")
    audit(db, "jellyfin.quick_connect", actor=user, target_type="user", target_id=user.id)
    await db.commit()
    return Ok(message="Dispositivo autorizado! Já deve entrar sozinho.")


@router.post("/jellyfin/sync-password", response_model=Ok)
async def sync_password(body: PasswordOnlyIn, user: User = Depends(require_user), db: AsyncSession = Depends(get_db)):
    rate_limit(f"syncpwd:{user.id}", 5, 900)
    if not user.jellyfin_password_login:
        raise HTTPException(400, detail="A tua conta entra no Jellyfin por SSO — não há password para sincronizar.")
    ok, _ = verify_password(user.password_hash, body.password)
    if not ok:
        raise HTTPException(400, detail="Password incorreta.")
    await queue_jellyfin_password(db, user, body.password)
    await request_reconcile(db, user.id)
    await db.commit()
    return Ok(message="A password do Jellyfin vai ficar igual à do portal dentro de instantes.")


@router.get("/jellyfin/now-playing")
async def now_playing(user: User = Depends(require_user), db: AsyncSession = Depends(get_db)):
    jf_id = await _jf_id(db, user)
    try:
        sessions = await JellyfinClient().sessions(300)
    except JellyfinError as exc:
        raise HTTPException(502, detail="O Jellyfin não respondeu.") from exc
    out = []
    for s in sessions:
        if (s.get("UserId") or "").replace("-", "") != jf_id.replace("-", ""):
            continue
        item = s.get("NowPlayingItem") or {}
        out.append({
            "device": s.get("DeviceName"), "client": s.get("Client"),
            "title": item.get("Name"), "series": item.get("SeriesName"),
            "playing": bool(item), "paused": bool((s.get("PlayState") or {}).get("IsPaused")),
            "method": (s.get("PlayState") or {}).get("PlayMethod"),
        })
    return out
