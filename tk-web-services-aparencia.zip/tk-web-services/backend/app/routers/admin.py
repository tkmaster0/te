from __future__ import annotations

import secrets
from datetime import UTC, datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from ..config import get_settings
from ..db import get_db, utcnow
from ..deps import client_ip, require_admin, revoke_user_sessions
from ..features import PlanFeatures
from ..integrations.jellyfin import JellyfinClient, JellyfinError
from ..models import (
    ENTITLED_STATUSES,
    AuditLog,
    Grant,
    InviteCode,
    Invoice,
    InvoiceLine,
    Job,
    OIDCClient,
    Payment,
    PaymentMethod,
    Plan,
    PriceChange,
    Product,
    ServiceAccount,
    SiteSetting,
    Subscription,
    SubStatus,
    User,
    WebhookEvent,
)
from ..payments import registry
from ..schemas import Ok
from ..security import encrypt, hash_password, new_invite_code
from ..serializers import (
    SITE_DEFAULTS,
    invoice_out,
    me_out,
    payment_method_out,
    payment_out,
    plan_out,
    site_settings,
    sub_out,
)
from ..services import billing, health, legacy, oidc_keys, tokens
from ..services import wallet as wallet_svc
from ..services.audit import audit
from ..services.billing import LIVE_BILLING
from ..services.bonus import bonus_status
from ..services.fulfillment import set_access_details
from ..services.jobs import RetryLater, enqueue, redact_tokens
from ..services.mailer import queue_email
from ..services.provisioning import reconcile_user
from ..services.subscriptions import compute_access, request_reconcile, set_status
from ..services.tasks import job_counts

router = APIRouter(prefix="/api/admin", tags=["admin"], dependencies=[Depends(require_admin)])


def _page(q, page: int, size: int):
    return q.offset(max(page - 1, 0) * size).limit(size)


# --------------------------------------------------------------------------- estatísticas
@router.get("/stats")
async def stats(db: AsyncSession = Depends(get_db)):
    now = utcnow()
    entitled = [s.value for s in ENTITLED_STATUSES]
    total_users = await db.scalar(select(func.count()).select_from(User))
    new_30d = await db.scalar(select(func.count()).select_from(User).where(User.created_at > now - timedelta(days=30)))
    rows = (await db.execute(
        select(Plan.name, Plan.price_cents, Plan.interval_unit, Plan.interval_count, Subscription.provider,
               Subscription.status, func.count())
        .join(Plan, Plan.id == Subscription.plan_id)
        .where(Subscription.status.in_(entitled + [SubStatus.suspended.value]))
        .group_by(Plan.name, Plan.price_cents, Plan.interval_unit, Plan.interval_count, Subscription.provider,
                  Subscription.status)
    )).all()
    by_plan: dict[str, int] = {}
    by_provider: dict[str, int] = {}
    by_status: dict[str, int] = {}
    for name, _price, _unit, _count_i, provider, status, n in rows:
        by_status[status] = by_status.get(status, 0) + n
        if status in entitled:
            by_plan[name] = by_plan.get(name, 0) + n
            by_provider[provider] = by_provider.get(provider, 0) + n
    mrr = await billing.mrr_cents(db)
    methods = (await db.execute(select(PaymentMethod.provider, PaymentMethod.status, func.count())
                                .group_by(PaymentMethod.provider, PaymentMethod.status))).all()
    by_method: dict[str, dict[str, int]] = {}
    for prov, st, n in methods:
        by_method.setdefault(prov, {})[st] = n
    invoices_unpaid = await db.scalar(select(func.count()).select_from(Invoice).where(
        Invoice.status.in_(["open", "failed"])))
    invoices_unpaid_cents = await db.scalar(select(func.coalesce(func.sum(Invoice.total_cents), 0)).where(
        Invoice.status.in_(["open", "failed"])))
    fulfillment_pending = await db.scalar(select(func.count()).select_from(Subscription).where(
        Subscription.fulfillment_status.in_(["pending", "pending_removal", "error"])))
    revenue_30d = await db.scalar(select(func.coalesce(func.sum(Payment.amount_cents), 0)).where(
        Payment.status == "paid", Payment.updated_at > now - timedelta(days=30)))
    failed_payments_30d = await db.scalar(select(func.count()).select_from(Payment).where(
        Payment.status.in_(["failed", "charged_back"]), Payment.updated_at > now - timedelta(days=30)))
    active_grants = await db.scalar(select(func.count()).select_from(Grant).where(
        Grant.revoked_at.is_(None), or_(Grant.ends_at.is_(None), Grant.ends_at > now)))
    webhook_failed = await db.scalar(select(func.count()).select_from(WebhookEvent).where(
        WebhookEvent.status == "failed"))
    # Evolução: novas subscrições por mês (últimos 12 meses)
    since = now - timedelta(days=365)
    subs_recent = (await db.scalars(select(Subscription.started_at).where(Subscription.started_at > since))).all()
    monthly: dict[str, int] = {}
    for d in subs_recent:
        key = d.strftime("%Y-%m")
        monthly[key] = monthly.get(key, 0) + 1
    return {
        "users": total_users, "new_users_30d": new_30d, "mrr_cents": round(mrr),
        "revenue_30d_cents": revenue_30d, "failed_payments_30d": failed_payments_30d,
        "by_plan": by_plan, "by_provider": by_provider, "by_status": by_status, "active_grants": active_grants,
        "jobs": await job_counts(db), "webhooks_failed": webhook_failed,
        "payment_methods": by_method, "invoices_unpaid": invoices_unpaid,
        "invoices_unpaid_cents": invoices_unpaid_cents, "fulfillment_pending": fulfillment_pending,
        "new_subscriptions_by_month": dict(sorted(monthly.items())),
    }


# --------------------------------------------------------------------------- utilizadores
@router.get("/users")
async def list_users(q: str | None = None, status: str | None = None, page: int = 1, size: int = 50,
                     db: AsyncSession = Depends(get_db)):
    size = min(size, 200)
    query = select(User)
    if q:
        like = f"%{q.lower()}%"
        query = query.where(or_(User.username.like(like), User.email.like(like), User.display_name.ilike(like)))
    if status == "admin":
        query = query.where(User.is_admin.is_(True))
    elif status == "blocked":
        query = query.where(User.is_active.is_(False))
    elif status in {s.value for s in SubStatus}:
        query = query.where(User.id.in_(select(Subscription.user_id).where(Subscription.status == status)))
    elif status == "no_subscription":
        query = query.where(~User.id.in_(select(Subscription.user_id).where(
            Subscription.status.in_([s.value for s in ENTITLED_STATUSES]))))
    total = await db.scalar(select(func.count()).select_from(query.subquery()))
    users = (await db.scalars(_page(query.order_by(User.created_at.desc()), page, size))).all()
    out = []
    for u in users:
        sub = await db.scalar(select(Subscription).where(Subscription.user_id == u.id)
                              .order_by(Subscription.created_at.desc()).limit(1))
        plan = await db.get(Plan, sub.plan_id) if sub else None
        out.append({
            "id": u.id, "username": u.username, "email": u.email, "display_name": u.display_name,
            "is_admin": u.is_admin, "is_active": u.is_active, "email_verified": u.email_verified_at is not None,
            "created_at": u.created_at, "last_login_at": u.last_login_at,
            "subscription": {"status": sub.status, "plan": plan.name if plan else None, "provider": sub.provider,
                             "current_period_end": sub.current_period_end} if sub else None,
        })
    return {"total": total, "page": page, "size": size, "items": out}


async def _user(db: AsyncSession, user_id: str) -> User:
    u = await db.get(User, user_id)
    if u is None:
        raise HTTPException(404, detail="Utilizador não encontrado.")
    return u


@router.get("/users/{user_id}")
async def user_detail(user_id: str, db: AsyncSession = Depends(get_db)):
    u = await _user(db, user_id)
    subs = (await db.scalars(select(Subscription).where(Subscription.user_id == u.id)
                             .order_by(Subscription.created_at.desc()))).all()
    sub_rows = []
    for s in subs:
        row = (await sub_out(db, s)).model_dump()
        row["provider_subscription_id"] = s.provider_subscription_id
        row["period_amount_cents"] = s.period_amount_cents
        sub_rows.append(row)
    invs = (await db.scalars(select(Invoice).where(Invoice.user_id == u.id)
                             .order_by(Invoice.created_at.desc()).limit(40))).all()
    pms = (await db.scalars(select(PaymentMethod).where(PaymentMethod.user_id == u.id)
                            .order_by(PaymentMethod.created_at.desc()))).all()
    payments = (await db.scalars(select(Payment).where(Payment.user_id == u.id)
                                 .order_by(Payment.charge_date.desc().nulls_last(), Payment.created_at.desc()).limit(50))).all()
    grants = (await db.scalars(select(Grant).options(selectinload(Grant.plan)).where(Grant.user_id == u.id)
                               .order_by(Grant.created_at.desc()))).all()
    accounts = (await db.scalars(select(ServiceAccount).where(ServiceAccount.user_id == u.id))).all()
    invitees = (await db.scalars(select(User.username).where(User.referred_by_id == u.id))).all()
    audit_rows = (await db.scalars(select(AuditLog).where(or_(AuditLog.target_id == u.id, AuditLog.actor_id == u.id))
                                   .order_by(AuditLog.created_at.desc()).limit(100))).all()
    access = await compute_access(db, u)
    return {
        "user": {**(await me_out(db, u)).model_dump(), "is_active": u.is_active, "admin_notes": u.admin_notes,
                 "last_login_at": u.last_login_at, "stripe_customer_id": u.stripe_customer_id,
                 "gocardless_customer_id": u.gocardless_customer_id, "gocardless_mandate_id": u.gocardless_mandate_id,
                 "legacy_id": u.legacy_id},
        "effective_features": access.features.model_dump(),
        "billing": {"anchor_day": u.billing_anchor_day, "next_billing_at": u.next_billing_at,
                    "upcoming": await billing.preview_next(db, u),
                    "pending_lines": [{"id": ln.id, "description": ln.description, "amount_cents": ln.amount_cents,
                                       "kind": ln.kind} for ln in await billing.pending_lines(db, u.id)]},
        "invoices": [(await invoice_out(db, i)).model_dump() for i in invs],
        "wallet": {**(await wallet_svc.summary(db, u)), "transactions": [
            {"id": t.id, "kind": t.kind, "amount_cents": t.amount_cents, "balance_after_cents": t.balance_after_cents,
             "description": t.description, "created_at": t.created_at}
            for t in await wallet_svc.transactions(db, u.id, limit=40)]},
        "payment_methods": [payment_method_out(m).model_dump() for m in pms],
        "bonus": await bonus_status(db, u),
        "groups": access.groups(u),
        "subscriptions": sub_rows,
        "payments": [payment_out(p).model_dump() for p in payments],
        "grants": [{"id": g.id, "plan": g.plan.name, "plan_id": g.plan_id, "reason": g.reason, "starts_at": g.starts_at,
                    "ends_at": g.ends_at, "revoked_at": g.revoked_at} for g in grants],
        "service_accounts": [{"service": a.service, "external_id": a.external_id, "username": a.external_username,
                              "applied_state": a.applied_state, "last_synced_at": a.last_synced_at,
                              "last_error": a.last_error, "has_secret": bool(a.secret_enc), "data": a.data}
                             for a in accounts],
        "invitees": list(invitees),
        "audit": [{"created_at": a.created_at, "action": a.action, "actor": a.actor_label, "ip": a.ip,
                   "details": a.details} for a in audit_rows],
    }


class UserPatch(BaseModel):
    email: EmailStr | None = None
    display_name: str | None = Field(None, max_length=120)
    is_admin: bool | None = None
    is_active: bool | None = None
    email_verified: bool | None = None
    admin_notes: str | None = Field(None, max_length=5000)
    billing_mode: str | None = Field(None, pattern="^(legacy|wallet)$")
    jellyfin_password_login: bool | None = None
    unlocked_products: list[str] | None = None


@router.patch("/users/{user_id}", response_model=Ok)
async def patch_user(user_id: str, body: UserPatch, request: Request, admin: User = Depends(require_admin),
                     db: AsyncSession = Depends(get_db)):
    u = await _user(db, user_id)
    changes = body.model_dump(exclude_unset=True)
    if changes.get("email"):
        email = str(changes["email"]).lower()
        if await db.scalar(select(User.id).where(User.email == email, User.id != u.id)):
            raise HTTPException(400, detail="Email já em uso.")
        u.email = email
    if "display_name" in changes:
        u.display_name = changes["display_name"]
    if "is_admin" in changes and changes["is_admin"] is not None:
        if u.id == admin.id and not changes["is_admin"]:
            raise HTTPException(400, detail="Não podes remover o teu próprio acesso de administrador.")
        u.is_admin = changes["is_admin"]
    if "is_active" in changes and changes["is_active"] is not None:
        if u.id == admin.id and not changes["is_active"]:
            raise HTTPException(400, detail="Não te podes bloquear a ti próprio.")
        u.is_active = changes["is_active"]
        if not u.is_active:
            await revoke_user_sessions(db, u.id)
    if "email_verified" in changes and changes["email_verified"] is not None:
        u.email_verified_at = utcnow() if changes["email_verified"] else None
    if "admin_notes" in changes:
        u.admin_notes = changes["admin_notes"]
    if changes.get("billing_mode"):
        u.billing_mode = changes["billing_mode"]
    if changes.get("jellyfin_password_login") is not None:
        u.jellyfin_password_login = changes["jellyfin_password_login"]
    if changes.get("unlocked_products") is not None:
        u.unlocked_products = sorted({c for c in changes["unlocked_products"] if c})
    audit(db, "admin.user_updated", actor=admin, target_type="user", target_id=u.id, ip=client_ip(request),
          changes={k: v for k, v in changes.items() if k != "admin_notes"})
    await request_reconcile(db, u.id)
    await db.commit()
    return Ok()


@router.post("/users/{user_id}/reconcile")
async def reconcile_now(user_id: str, db: AsyncSession = Depends(get_db)):
    await _user(db, user_id)
    try:
        result = await reconcile_user(db, user_id)
        await db.commit()
        return {"ok": True, "result": result}
    except Exception as exc:  # noqa: BLE001
        await db.rollback()
        await request_reconcile(db, user_id, delay_seconds=60)
        await db.commit()
        return {"ok": False, "error": str(exc)}


@router.post("/users/{user_id}/password-reset", response_model=Ok)
async def admin_password_reset(user_id: str, admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    u = await _user(db, user_id)
    raw = await tokens.issue(db, u.id, "reset_password")
    await queue_email(db, u.email, "reset_password", username=u.username,
                      cta_url=f"{get_settings().public_url}/redefinir-password?token={raw}")
    audit(db, "admin.password_reset_sent", actor=admin, target_type="user", target_id=u.id)
    await db.commit()
    return Ok(message=f"Email de redefinição enviado para {u.email}.")


@router.post("/users/{user_id}/sessions/revoke", response_model=Ok)
async def admin_revoke_sessions(user_id: str, admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    n = await revoke_user_sessions(db, (await _user(db, user_id)).id)
    audit(db, "admin.sessions_revoked", actor=admin, target_type="user", target_id=user_id, count=n)
    await db.commit()
    return Ok(message=f"{n} sessões terminadas.")


class GrantIn(BaseModel):
    plan_id: int
    ends_at: datetime | None = None
    days: int | None = Field(None, ge=1, le=3650)
    reason: str | None = Field(None, max_length=200)


@router.post("/users/{user_id}/grants", response_model=Ok)
async def add_grant(user_id: str, body: GrantIn, admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    u = await _user(db, user_id)
    plan = await db.get(Plan, body.plan_id)
    if plan is None:
        raise HTTPException(404, detail="Plano não encontrado.")
    ends = body.ends_at or (utcnow() + timedelta(days=body.days) if body.days else None)
    db.add(Grant(user_id=u.id, plan_id=plan.id, ends_at=ends, reason=body.reason, created_by_id=admin.id))
    audit(db, "admin.grant_added", actor=admin, target_type="user", target_id=u.id, plan=plan.code,
          ends_at=ends.isoformat() if ends else None)
    await request_reconcile(db, u.id)
    await db.commit()
    return Ok(message="Acesso oferecido.")


@router.delete("/grants/{grant_id}", response_model=Ok)
async def revoke_grant(grant_id: int, admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    g = await db.get(Grant, grant_id)
    if g is None:
        raise HTTPException(404, detail="Oferta não encontrada.")
    g.revoked_at = utcnow()
    audit(db, "admin.grant_revoked", actor=admin, target_type="user", target_id=g.user_id, grant=grant_id)
    await request_reconcile(db, g.user_id)
    await db.commit()
    return Ok()


class ManualIptvIn(BaseModel):
    username: str | None = Field(None, max_length=128)
    password: str | None = Field(None, max_length=256)
    host: str | None = Field(None, max_length=300)


@router.put("/users/{user_id}/iptv-manual", response_model=Ok)
async def set_manual_iptv(user_id: str, body: ManualIptvIn, admin: User = Depends(require_admin),
                          db: AsyncSession = Depends(get_db)):
    """Credenciais IPTV introduzidas à mão (ex.: contas de fornecedor fora do Dispatcharr)."""
    u = await _user(db, user_id)
    sa = await db.scalar(select(ServiceAccount).where(ServiceAccount.user_id == u.id, ServiceAccount.service == "iptv"))
    if not body.username:
        if sa:
            await db.delete(sa)
    else:
        if sa is None:
            sa = ServiceAccount(user_id=u.id, service="iptv")
            db.add(sa)
        sa.external_username = body.username
        sa.secret_enc = encrypt(body.password or "")
        sa.data = {"host": body.host}
        await queue_email(db, u.email, "iptv_ready", cta_url=f"{get_settings().public_url}/app/servicos")
    audit(db, "admin.iptv_manual", actor=admin, target_type="user", target_id=u.id, cleared=not body.username)
    await db.commit()
    return Ok()


@router.post("/users/{user_id}/unlink/{service}", response_model=Ok)
async def unlink_service(user_id: str, service: str, admin: User = Depends(require_admin),
                         db: AsyncSession = Depends(get_db)):
    sa = await db.scalar(select(ServiceAccount).where(ServiceAccount.user_id == user_id, ServiceAccount.service == service))
    if sa is None:
        raise HTTPException(404, detail="Ligação não encontrada.")
    await db.delete(sa)
    audit(db, "admin.service_unlinked", actor=admin, target_type="user", target_id=user_id, service=service)
    await db.commit()
    return Ok()


# --------------------------------------------------------------------------- subscrições
class AdminCancelIn(BaseModel):
    immediately: bool = False


@router.post("/subscriptions/{sub_id}/cancel", response_model=Ok)
async def admin_cancel(sub_id: str, body: AdminCancelIn, admin: User = Depends(require_admin),
                       db: AsyncSession = Depends(get_db)):
    sub = await db.get(Subscription, sub_id)
    if sub is None:
        raise HTTPException(404, detail="Subscrição não encontrada.")
    if body.immediately or not sub.current_period_end:
        # Sem fim de período (ex.: subscrição manual/oferta) "no fim do período" nunca chegava: ficava
        # "a cancelar" com acesso para sempre.
        await set_status(db, sub, SubStatus.ended, reason=f"terminada pelo admin {admin.username}")
    elif sub.status in (SubStatus.active, SubStatus.bonus, SubStatus.past_due):
        await set_status(db, sub, SubStatus.canceling, reason=f"cancelada pelo admin {admin.username}",
                         access_until=sub.current_period_end, cancel_at_period_end=True)
    audit(db, "admin.subscription_cancel", actor=admin, target_type="subscription", target_id=sub.id,
          immediately=body.immediately)
    await db.commit()
    return Ok()


class AdminSubPatch(BaseModel):
    price_cents: int | None = Field(None, ge=0, description="Preço fixado desta subscrição")
    extend_days: int | None = Field(None, ge=1, le=366, description="Oferece dias (adia a próxima renovação)")
    fulfillment_status: str | None = Field(None, pattern="^(pending|done|error|pending_removal)$")
    access_details: dict[str, str] | None = None


@router.patch("/subscriptions/{sub_id}", response_model=Ok)
async def admin_patch_sub(sub_id: str, body: AdminSubPatch, admin: User = Depends(require_admin),
                          db: AsyncSession = Depends(get_db)):
    sub = await db.get(Subscription, sub_id)
    if sub is None:
        raise HTTPException(404, detail="Subscrição não encontrada.")
    changes = body.model_dump(exclude_unset=True)
    if "price_cents" in changes and body.price_cents is not None:
        sub.price_cents = body.price_cents
    if body.extend_days and sub.current_period_end:
        sub.current_period_end = sub.current_period_end + timedelta(days=body.extend_days)
        if sub.access_until:
            sub.access_until = sub.access_until + timedelta(days=body.extend_days)
    if "access_details" in changes:
        details = {str(k)[:60]: str(v)[:500] for k, v in (body.access_details or {}).items() if str(k).strip()}
        set_access_details(sub, details or None)
        if details and not body.fulfillment_status:
            sub.fulfillment_status = "done"
    if body.fulfillment_status:
        sub.fulfillment_status = body.fulfillment_status
    audit(db, "admin.subscription_updated", actor=admin, target_type="subscription", target_id=sub.id,
          fields=[k for k in changes if k != "access_details"] + (["access_details"] if "access_details" in changes
                                                                  else []))
    await db.commit()
    return Ok(message="Subscrição atualizada.")


@router.get("/fulfillment")
async def fulfillment_queue(db: AsyncSession = Depends(get_db)):
    """Entregas manuais / webhooks por tratar."""
    rows = (await db.scalars(select(Subscription).where(
        Subscription.fulfillment_status.in_(["pending", "pending_removal", "error"]))
        .order_by(Subscription.updated_at))).all()
    out = []
    for sub in rows:
        user = await db.get(User, sub.user_id)
        out.append({**(await sub_out(db, sub)).model_dump(), "username": user.username if user else None,
                    "email": user.email if user else None, "user_id": sub.user_id})
    return out


class AdjustmentIn(BaseModel):
    amount_cents: int = Field(description="Positivo = cobrar, negativo = crédito")
    description: str = Field(min_length=3, max_length=200)


@router.post("/users/{user_id}/adjustments", response_model=Ok)
async def add_adjustment(user_id: str, body: AdjustmentIn, admin: User = Depends(require_admin),
                         db: AsyncSession = Depends(get_db)):
    """Crédito ou acerto manual — entra na próxima cobrança consolidada do cliente."""
    u = await _user(db, user_id)
    if body.amount_cents == 0:
        raise HTTPException(400, detail="O valor não pode ser zero.")
    db.add(InvoiceLine(user_id=u.id, kind="credit" if body.amount_cents < 0 else "adjustment",
                       amount_cents=body.amount_cents, description=body.description))
    if u.next_billing_at is None:
        # Sem dia de faturação o ciclo não avançava next_billing_at e voltava a correr a cada 5 minutos.
        u.billing_anchor_day = u.billing_anchor_day or min(utcnow().day, 28)
        u.next_billing_at = billing.next_anchor(u.billing_anchor_day, utcnow())
    audit(db, "admin.adjustment", actor=admin, target_type="user", target_id=u.id, amount=body.amount_cents,
          description=body.description)
    await db.commit()
    return Ok(message="Registado — entra na próxima cobrança.")


@router.delete("/adjustments/{line_id}", response_model=Ok)
async def remove_adjustment(line_id: int, admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    ln = await db.get(InvoiceLine, line_id)
    if ln is None or ln.invoice_id is not None:
        raise HTTPException(400, detail="Só é possível remover linhas ainda não cobradas.")
    await db.delete(ln)
    audit(db, "admin.adjustment_removed", actor=admin, target_type="user", target_id=ln.user_id, line=line_id)
    await db.commit()
    return Ok()


# --------------------------------------------------------------------------- cobranças (admin)
@router.get("/invoices")
async def admin_invoices(status: str | None = None, page: int = 1, db: AsyncSession = Depends(get_db)):
    q = select(Invoice)
    if status == "unpaid":
        q = q.where(Invoice.status.in_(["open", "failed"]))
    elif status:
        q = q.where(Invoice.status == status)
    rows = (await db.scalars(_page(q.order_by(Invoice.created_at.desc()), page, 100))).all()
    out = []
    for inv in rows:
        user = await db.get(User, inv.user_id)
        out.append({**(await invoice_out(db, inv)).model_dump(), "username": user.username if user else None,
                    "user_id": inv.user_id})
    return out


@router.post("/invoices/{invoice_id}/retry", response_model=Ok)
async def admin_retry_invoice(invoice_id: str, db: AsyncSession = Depends(get_db)):
    inv = await db.get(Invoice, invoice_id)
    if inv is None or inv.status not in ("open", "failed"):
        raise HTTPException(400, detail="Esta cobrança não está por pagar.")
    try:
        status = await billing.charge_invoice(db, inv)
        await db.commit()
    except RetryLater as exc:
        await db.rollback()
        raise HTTPException(502, detail=f"Fornecedor indisponível: {exc}") from exc
    return Ok(message=f"Resultado: {status}.")


class MarkPaidIn(BaseModel):
    note: str = Field(min_length=3, max_length=200, description="ex.: pago por MB Way / transferência")


@router.post("/invoices/{invoice_id}/mark-paid", response_model=Ok)
async def admin_mark_paid(invoice_id: str, body: MarkPaidIn, admin: User = Depends(require_admin),
                          db: AsyncSession = Depends(get_db)):
    inv = await db.get(Invoice, invoice_id)
    if inv is None or inv.status not in ("open", "failed", "processing"):
        raise HTTPException(400, detail="Esta cobrança não está por pagar.")
    inv.note = body.note
    await billing.mark_paid(db, inv)
    audit(db, "admin.invoice_mark_paid", actor=admin, target_type="invoice", target_id=inv.id, note=body.note)
    await db.commit()
    return Ok(message="Marcada como paga.")


@router.post("/invoices/{invoice_id}/void", response_model=Ok)
async def admin_void_invoice(invoice_id: str, admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    inv = await db.get(Invoice, invoice_id)
    if inv is None or inv.status not in ("open", "failed"):
        raise HTTPException(400, detail="Só é possível anular cobranças por pagar.")
    inv.status = "void"
    inv.voided_at = utcnow()
    inv.next_attempt_at = None
    audit(db, "admin.invoice_void", actor=admin, target_type="invoice", target_id=inv.id)
    if not await billing.unpaid_invoices(db, inv.user_id):
        await billing.debt_cleared(db, inv.user_id, reason="cobrança anulada pelo admin", notify=False)
    await db.commit()
    return Ok(message="Cobrança anulada (o cliente não será cobrado).")


@router.post("/users/{user_id}/run-billing", response_model=Ok)
async def admin_run_billing(user_id: str, db: AsyncSession = Depends(get_db)):
    """Força o ciclo de faturação do cliente agora (útil depois de uma migração)."""
    u = await _user(db, user_id)
    if not u.next_billing_at or u.next_billing_at > utcnow():
        raise HTTPException(400, detail="Este cliente ainda não tem nada a vencer.")
    inv = await billing.run_cycle(db, u)
    await db.commit()
    return Ok(message=f"Cobrança {inv.number} emitida ({inv.status})." if inv else "Nada a cobrar.")


# --------------------------------------------------------------------------- produtos e planos
class ProductIn(BaseModel):
    code: str = Field(min_length=2, max_length=48, pattern=r"^[a-z0-9_-]+$")
    name: str = Field(min_length=1, max_length=120)
    description: str | None = None
    kind: str = Field("streaming", max_length=32)
    fulfillment: str = Field("streaming", pattern="^(streaming|manual|webhook|none)$")
    webhook_url: str | None = Field(None, max_length=500, pattern=r"^https?://")
    webhook_secret: str | None = Field(None, max_length=200, description="None = manter; '' = apagar")
    access_instructions: str | None = Field(None, max_length=5000)
    app_url: str | None = Field(None, max_length=500, pattern=r"^https?://")
    icon: str | None = Field(None, max_length=32)
    bonus_eligible: bool = True
    jellyfin_managed: bool = False
    # Beta fechado: só quem tem convite vê o nome verdadeiro e pode aderir
    requires_invite: bool = False
    locked_name: str | None = Field(None, max_length=120)
    locked_description: str | None = Field(None, max_length=255)
    is_active: bool = True
    sort_order: int = 0


class PlanIn(BaseModel):
    product_id: int
    code: str = Field(min_length=2, max_length=48, pattern=r"^[a-z0-9_-]+$")
    name: str = Field(min_length=1, max_length=120)
    description: str | None = None
    price_cents: int = Field(ge=0)
    currency: str = Field("EUR", pattern="^[A-Za-z]{3}$")
    interval_unit: str = Field("month", pattern="^(month|year|week)$")
    interval_count: int = Field(1, ge=1, le=12)
    gocardless_enabled: bool = True  # obsoleto (métodos de pagamento são por cliente); ignorado
    stripe_price_id: str | None = Field(None, max_length=64)  # obsoleto; ignorado
    features: PlanFeatures = Field(default_factory=PlanFeatures)
    highlights: list[str] = Field(default_factory=list)
    is_active: bool = True
    is_public: bool = True
    sort_order: int = 0


@router.get("/products")
async def admin_products(db: AsyncSession = Depends(get_db)):
    products = (await db.scalars(select(Product).options(selectinload(Product.plans))
                                 .order_by(Product.sort_order, Product.id))).all()
    out = []
    for p in products:
        plans = []
        for pl in p.plans:
            active = await db.scalar(select(func.count()).select_from(Subscription).where(
                Subscription.plan_id == pl.id, Subscription.status.in_([s.value for s in ENTITLED_STATUSES])))
            changes = (await db.scalars(select(PriceChange).where(
                PriceChange.plan_id == pl.id, PriceChange.cancelled_at.is_(None),
                PriceChange.effective_at > utcnow() - timedelta(days=400)).order_by(PriceChange.effective_at.desc()))).all()
            grandfathered = await db.scalar(select(func.count()).select_from(Subscription).where(
                Subscription.plan_id == pl.id, Subscription.status.in_([s.value for s in ENTITLED_STATUSES]),
                Subscription.price_cents.is_not(None), Subscription.price_cents != pl.price_cents))
            plans.append({**plan_out(pl).model_dump(), "is_active": pl.is_active, "is_public": pl.is_public,
                          "sort_order": pl.sort_order, "active_subscriptions": active,
                          "subscribers_on_other_price": grandfathered,
                          "price_changes": [{"id": c.id, "old_price_cents": c.old_price_cents,
                                             "new_price_cents": c.new_price_cents, "effective_at": c.effective_at,
                                             "notified_at": c.notified_at, "note": c.note} for c in changes]})
        out.append({"id": p.id, "code": p.code, "name": p.name, "description": p.description, "kind": p.kind,
                    "fulfillment": p.fulfillment, "webhook_url": p.webhook_url,
                    "has_webhook_secret": bool(p.webhook_secret_enc), "access_instructions": p.access_instructions,
                    "app_url": p.app_url, "icon": p.icon, "image_url": p.image_url, "bonus_eligible": p.bonus_eligible, "jellyfin_managed": p.jellyfin_managed,
                    "requires_invite": bool(p.requires_invite), "locked_name": p.locked_name,
                    "locked_description": p.locked_description,
                    "is_active": p.is_active, "sort_order": p.sort_order, "plans": plans})
    return out


@router.post("/products")
async def create_product(body: ProductIn, admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    if await db.scalar(select(Product.id).where(Product.code == body.code)):
        raise HTTPException(400, detail="Já existe um produto com esse código.")
    data = body.model_dump()
    secret = data.pop("webhook_secret", None)
    p = Product(**data)
    if secret:
        p.webhook_secret_enc = encrypt(secret)
    db.add(p)
    await db.flush()
    audit(db, "admin.product_created", actor=admin, target_type="product", target_id=p.id, code=p.code)
    await db.commit()
    return {"id": p.id}


@router.put("/products/{product_id}", response_model=Ok)
async def update_product(product_id: int, body: ProductIn, admin: User = Depends(require_admin),
                         db: AsyncSession = Depends(get_db)):
    p = await db.get(Product, product_id)
    if p is None:
        raise HTTPException(404, detail="Produto não encontrado.")
    data = body.model_dump()
    secret = data.pop("webhook_secret", None)
    for k, v in data.items():
        setattr(p, k, v)
    if secret is not None:
        p.webhook_secret_enc = encrypt(secret) if secret else None
    audit(db, "admin.product_updated", actor=admin, target_type="product", target_id=p.id)
    await db.commit()
    return Ok()


class ProductSsoIn(BaseModel):
    redirect_uris: list[str] = Field(min_length=1, max_length=10)
    rotate: bool = False


@router.post("/products/{product_id}/sso")
async def product_sso(product_id: int, body: ProductSsoIn, admin: User = Depends(require_admin),
                      db: AsyncSession = Depends(get_db)):
    """Liga a app de um serviço ao SSO: cliente OIDC com o código do produto, só para quem o tem ativo.
    O segredo novo só é mostrado aqui, uma vez."""
    p = await db.get(Product, product_id)
    if p is None:
        raise HTTPException(404, detail="Produto não encontrado.")
    uris = [u.strip() for u in body.redirect_uris if u.strip()]
    if not uris or any(not u.startswith(("https://", "http://")) for u in uris):
        raise HTTPException(400, detail="Os redirect URIs têm de começar por https:// (ou http:// em testes).")
    c = await db.get(OIDCClient, p.code)
    secret = None
    if c is None:
        secret = secrets.token_urlsafe(36)
        c = OIDCClient(client_id=p.code, name=p.name, secret_hash=hash_password(secret))
        db.add(c)
    elif body.rotate or not c.secret_hash:
        secret = secrets.token_urlsafe(36)
        c.secret_hash = hash_password(secret)
    c.name = p.name
    c.redirect_uris = uris
    c.required_access = f"product:{p.code}"
    c.allowed_scopes = c.allowed_scopes or ["openid", "profile", "email", "groups", "offline_access"]
    c.is_active = True
    audit(db, "admin.product_sso", actor=admin, target_type="product", target_id=p.id, rotated=bool(secret))
    await db.commit()
    s = get_settings()
    return {"client_id": p.code, "client_secret": secret, "issuer": s.issuer,
            "discovery": f"{s.issuer}/.well-known/openid-configuration", "redirect_uris": uris,
            "required_access": c.required_access}


@router.post("/plans")
async def create_plan(body: PlanIn, admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    if await db.scalar(select(Plan.id).where(Plan.code == body.code)):
        raise HTTPException(400, detail="Já existe um plano com esse código.")
    if not await db.get(Product, body.product_id):
        raise HTTPException(400, detail="Produto inválido.")
    data = body.model_dump()
    data["features"] = body.features.model_dump()
    data["currency"] = body.currency.upper()
    plan = Plan(**data)
    db.add(plan)
    await db.flush()
    audit(db, "admin.plan_created", actor=admin, target_type="plan", target_id=plan.id, code=plan.code)
    await db.commit()
    return {"id": plan.id}


@router.put("/plans/{plan_id}", response_model=Ok)
async def update_plan(plan_id: int, body: PlanIn, admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    plan = await db.get(Plan, plan_id)
    if plan is None:
        raise HTTPException(404, detail="Plano não encontrado.")
    interval_changed = plan.interval_unit != body.interval_unit or plan.interval_count != body.interval_count
    if interval_changed and await db.scalar(select(func.count()).select_from(Subscription).where(
            Subscription.plan_id == plan.id, Subscription.status.in_([s.value for s in LIVE_BILLING]))):
        raise HTTPException(400, detail="Este plano tem subscritores: não é possível mudar a periodicidade. "
                                        "Cria um plano novo e usa 'Migrar subscritores'.")
    if body.product_id != plan.product_id:
        raise HTTPException(400, detail="Não é possível mudar um plano de produto.")
    price_changed = plan.price_cents != body.price_cents
    if price_changed:
        # "Os subscritores atuais mantêm o preço deles": só é verdade se o preço estiver fixado na subscrição.
        for sub in (await db.scalars(select(Subscription).where(
                Subscription.plan_id == plan.id, Subscription.price_cents.is_(None)))).all():
            sub.price_cents = plan.price_cents
    data = body.model_dump()
    data["features"] = body.features.model_dump()
    data["currency"] = body.currency.upper()
    for k, v in data.items():
        setattr(plan, k, v)
    audit(db, "admin.plan_updated", actor=admin, target_type="plan", target_id=plan.id, price_changed=price_changed)
    # Direitos mudaram → reconciliar todos os subscritores deste plano
    user_ids = set((await db.scalars(select(Subscription.user_id).where(
        Subscription.plan_id == plan.id, Subscription.status.in_([s.value for s in ENTITLED_STATUSES])))).all())
    user_ids |= set((await db.scalars(select(Grant.user_id).where(Grant.plan_id == plan.id,
                                                                   Grant.revoked_at.is_(None)))).all())
    for uid in user_ids:
        await request_reconcile(db, uid)
    await db.commit()
    msg = f"Plano guardado. {len(user_ids)} utilizadores a reconciliar."
    if price_changed:
        msg += (" O novo preço aplica-se a novas subscrições; os subscritores atuais mantêm o preço deles. "
                "Para os mudar também, usa 'Alterar preço dos subscritores' (com aviso por email).")
    return Ok(message=msg)


# --------------------------------------------------------------------------- convites (admin)
class AdminInviteIn(BaseModel):
    max_uses: int = Field(1, ge=1, le=1000)
    days: int | None = Field(None, ge=1, le=365)
    note: str | None = Field(None, max_length=200)
    code: str | None = Field(None, min_length=4, max_length=32, pattern=r"^[A-Za-z0-9-]+$")
    # Produtos em beta fechado que o convite desbloqueia. None = todos; [] = nenhum (só registo).
    unlocks: list[str] | None = None


@router.get("/invites")
async def admin_invites(db: AsyncSession = Depends(get_db)):
    rows = (await db.scalars(select(InviteCode).options(selectinload(InviteCode.created_by))
                             .order_by(InviteCode.created_at.desc()).limit(500))).all()
    return [{"id": i.id, "code": i.code, "uses": i.uses, "max_uses": i.max_uses, "expires_at": i.expires_at,
             "note": i.note, "disabled": i.disabled, "created_at": i.created_at, "unlocks": i.unlocks,
             "created_by": i.created_by.username if i.created_by else None} for i in rows]


@router.post("/invites")
async def admin_create_invite(body: AdminInviteIn, admin: User = Depends(require_admin),
                              db: AsyncSession = Depends(get_db)):
    code = (body.code or new_invite_code()).upper()
    if await db.scalar(select(InviteCode.id).where(func.upper(InviteCode.code) == code)):
        raise HTTPException(400, detail="Esse código já existe.")
    inv = InviteCode(code=code, created_by_id=admin.id, max_uses=body.max_uses, note=body.note,
                     expires_at=utcnow() + timedelta(days=body.days) if body.days else None,
                     unlocks=body.unlocks)
    db.add(inv)
    audit(db, "admin.invite_created", actor=admin, target_type="invite", target_id=code, max_uses=body.max_uses)
    await db.commit()
    return {"id": inv.id, "code": inv.code, "link": f"{get_settings().public_url}/registar?convite={inv.code}"}


@router.delete("/invites/{invite_id}", response_model=Ok)
async def admin_disable_invite(invite_id: int, db: AsyncSession = Depends(get_db)):
    inv = await db.get(InviteCode, invite_id)
    if inv is None:
        raise HTTPException(404, detail="Convite não encontrado.")
    inv.disabled = True
    await db.commit()
    return Ok()


# --------------------------------------------------------------------------- jobs / webhooks / auditoria
@router.get("/jobs")
async def list_jobs(status: str | None = None, kind: str | None = None, page: int = 1,
                    db: AsyncSession = Depends(get_db)):
    q = select(Job)
    if status:
        q = q.where(Job.status == status)
    if kind:
        q = q.where(Job.kind == kind)
    rows = (await db.scalars(_page(q.order_by(Job.id.desc()), page, 100))).all()
    return {"counts": await job_counts(db), "items": [
        {"id": j.id, "kind": j.kind, "status": j.status, "attempts": j.attempts, "max_attempts": j.max_attempts,
         "run_after": j.run_after, "last_error": j.last_error, "created_at": j.created_at,
         "finished_at": j.finished_at,
         "payload": redact_tokens({k: v for k, v in (j.payload or {}).items() if not k.endswith("_enc")})}
        for j in rows]}


@router.post("/jobs/{job_id}/retry", response_model=Ok)
async def retry_job(job_id: int, db: AsyncSession = Depends(get_db)):
    j = await db.get(Job, job_id)
    if j is None:
        raise HTTPException(404, detail="Job não encontrado.")
    if j.status == "running":
        raise HTTPException(400, detail="O job está a correr.")
    j.status = "pending"
    j.run_after = utcnow()
    j.attempts = 0
    await db.commit()
    return Ok()


@router.post("/reconcile-all", response_model=Ok)
async def reconcile_all(db: AsyncSession = Depends(get_db)):
    await enqueue(db, "reconcile_all", {}, dedupe_key="reconcile_all", max_attempts=2)
    await db.commit()
    return Ok(message="Reconciliação de todos os utilizadores agendada.")


@router.get("/webhooks")
async def list_webhooks(status: str | None = None, provider: str | None = None, page: int = 1,
                        db: AsyncSession = Depends(get_db)):
    q = select(WebhookEvent)
    if status:
        q = q.where(WebhookEvent.status == status)
    if provider:
        q = q.where(WebhookEvent.provider == provider)
    rows = (await db.scalars(_page(q.order_by(WebhookEvent.id.desc()), page, 100))).all()
    return [{"id": w.id, "provider": w.provider, "event_id": w.event_id, "event_type": w.event_type,
             "status": w.status, "error": w.error, "received_at": w.received_at, "processed_at": w.processed_at}
            for w in rows]


@router.get("/webhooks/{event_id}")
async def webhook_detail(event_id: int, db: AsyncSession = Depends(get_db)):
    w = await db.get(WebhookEvent, event_id)
    if w is None:
        raise HTTPException(404, detail="Evento não encontrado.")
    return {"id": w.id, "provider": w.provider, "event_type": w.event_type, "status": w.status, "error": w.error,
            "payload": w.payload}


@router.post("/webhooks/{event_id}/replay", response_model=Ok)
async def replay_webhook(event_id: int, db: AsyncSession = Depends(get_db)):
    w = await db.get(WebhookEvent, event_id)
    if w is None:
        raise HTTPException(404, detail="Evento não encontrado.")
    w.status = "received"
    await enqueue(db, "process_webhook", {"id": w.id}, max_attempts=5)
    await db.commit()
    return Ok(message="Evento reenfileirado.")


@router.get("/audit")
async def audit_log(q: str | None = None, action: str | None = None, page: int = 1, db: AsyncSession = Depends(get_db)):
    query = select(AuditLog)
    if action:
        query = query.where(AuditLog.action.like(f"{action}%"))
    if q:
        query = query.where(or_(AuditLog.actor_label.ilike(f"%{q}%"), AuditLog.target_id == q))
    rows = (await db.scalars(_page(query.order_by(AuditLog.id.desc()), page, 100))).all()
    return [{"id": a.id, "created_at": a.created_at, "actor": a.actor_label, "action": a.action,
             "target_type": a.target_type, "target_id": a.target_id, "ip": a.ip, "details": a.details} for a in rows]


# --------------------------------------------------------------------------- OIDC clients
class OIDCClientIn(BaseModel):
    client_id: str = Field(min_length=3, max_length=64, pattern=r"^[a-z0-9_.-]+$")
    name: str = Field(min_length=1, max_length=120)
    redirect_uris: list[str] = Field(min_length=1)
    post_logout_redirect_uris: list[str] = Field(default_factory=list)
    allowed_scopes: list[str] = Field(default_factory=lambda: ["openid", "profile", "email", "groups"])
    required_access: str | None = Field(None, max_length=64)
    public: bool = False
    require_pkce: bool = False
    is_active: bool = True


def _client_out(c: OIDCClient) -> dict:
    return {"client_id": c.client_id, "name": c.name, "redirect_uris": c.redirect_uris,
            "post_logout_redirect_uris": c.post_logout_redirect_uris, "allowed_scopes": c.allowed_scopes,
            "required_access": c.required_access, "public": c.secret_hash is None, "require_pkce": c.require_pkce,
            "is_active": c.is_active, "created_at": c.created_at}


@router.get("/oidc-clients")
async def list_clients(db: AsyncSession = Depends(get_db)):
    s = get_settings()
    rows = (await db.scalars(select(OIDCClient).order_by(OIDCClient.created_at))).all()
    return {"issuer": s.issuer, "discovery": f"{s.issuer}/.well-known/openid-configuration",
            "clients": [_client_out(c) for c in rows]}


@router.post("/oidc-clients")
async def create_client(body: OIDCClientIn, admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    if await db.get(OIDCClient, body.client_id):
        raise HTTPException(400, detail="Já existe um cliente com esse ID.")
    secret = None if body.public else secrets.token_urlsafe(36)
    c = OIDCClient(client_id=body.client_id, name=body.name, redirect_uris=body.redirect_uris,
                   post_logout_redirect_uris=body.post_logout_redirect_uris, allowed_scopes=body.allowed_scopes,
                   required_access=body.required_access or None, require_pkce=body.require_pkce or body.public,
                   secret_hash=hash_password(secret) if secret else None, is_active=body.is_active,
                   token_endpoint_auth_method="none" if body.public else "client_secret_basic")
    db.add(c)
    audit(db, "admin.oidc_client_created", actor=admin, target_type="oidc_client", target_id=c.client_id)
    await db.commit()
    return {**_client_out(c), "client_secret": secret}


@router.put("/oidc-clients/{client_id}", response_model=Ok)
async def update_client(client_id: str, body: OIDCClientIn, admin: User = Depends(require_admin),
                        db: AsyncSession = Depends(get_db)):
    c = await db.get(OIDCClient, client_id)
    if c is None:
        raise HTTPException(404, detail="Cliente não encontrado.")
    c.name = body.name
    c.redirect_uris = body.redirect_uris
    c.post_logout_redirect_uris = body.post_logout_redirect_uris
    c.allowed_scopes = body.allowed_scopes
    c.required_access = body.required_access or None
    c.require_pkce = body.require_pkce or c.secret_hash is None
    c.is_active = body.is_active
    audit(db, "admin.oidc_client_updated", actor=admin, target_type="oidc_client", target_id=c.client_id)
    await db.commit()
    return Ok()


@router.post("/oidc-clients/{client_id}/rotate-secret")
async def rotate_client_secret(client_id: str, admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    c = await db.get(OIDCClient, client_id)
    if c is None or c.secret_hash is None:
        raise HTTPException(400, detail="Cliente inexistente ou público.")
    secret = secrets.token_urlsafe(36)
    c.secret_hash = hash_password(secret)
    audit(db, "admin.oidc_client_secret_rotated", actor=admin, target_type="oidc_client", target_id=c.client_id)
    await db.commit()
    return {"client_secret": secret}


@router.delete("/oidc-clients/{client_id}", response_model=Ok)
async def delete_client(client_id: str, admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    c = await db.get(OIDCClient, client_id)
    if c is None:
        raise HTTPException(404, detail="Cliente não encontrado.")
    await db.delete(c)
    audit(db, "admin.oidc_client_deleted", actor=admin, target_type="oidc_client", target_id=client_id)
    await db.commit()
    return Ok()


@router.post("/oidc-clients/presets")
async def oidc_presets(rotate: bool = False, admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    """Cria/atualiza os clientes do Jellyfin, Seerr e LibreChat (a partir dos URLs do .env). Os segredos novos só são
    mostrados aqui, uma vez."""
    from ..services import oidc_presets as presets

    out = await presets.ensure_presets(db, rotate=rotate)
    audit(db, "admin.oidc_presets", actor=admin, clients=[c["client_id"] for c in out], rotate=rotate)
    await db.commit()
    return {"clients": out, "issuer": get_settings().issuer}


@router.post("/oidc/rotate-keys", response_model=Ok)
async def rotate_keys(admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    await oidc_keys.rotate(db)
    audit(db, "admin.oidc_keys_rotated", actor=admin)
    await db.commit()
    return Ok(message="Nova chave de assinatura ativa. A anterior continua publicada durante 2 dias.")


# --------------------------------------------------------------------------- integrações / definições
@router.get("/integrations")
async def integrations_health():
    return await health.integrations()


@router.get("/jellyfin/libraries")
async def jellyfin_libraries():
    try:
        return await JellyfinClient().libraries()
    except JellyfinError as exc:
        raise HTTPException(502, detail=str(exc)) from exc


@router.get("/settings")
async def get_site_settings(db: AsyncSession = Depends(get_db)):
    return await site_settings(db)


@router.put("/settings", response_model=Ok)
async def put_site_settings(body: dict, admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    from ..services import site_content

    for key, value in body.items():
        if key not in SITE_DEFAULTS:
            raise HTTPException(400, detail=f"Definição desconhecida: {key}")
        try:
            if key == "texts":
                value = site_content.clean_texts(value)
            elif key == "emails":
                value = site_content.clean_emails(value)
        except site_content.ContentError as exc:
            raise HTTPException(400, detail=str(exc)) from exc
        row = await db.get(SiteSetting, key)
        if row is None:
            db.add(SiteSetting(key=key, value=value))
        else:
            row.value = value
    audit(db, "admin.settings_updated", actor=admin, keys=list(body.keys()))
    await db.commit()
    return Ok()


@router.post("/test-email", response_model=Ok)
async def test_email(admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    await queue_email(db, admin.email, "admin_notice", subject="Email de teste",
                      message="Se estás a ler isto, o SMTP do portal está a funcionar.")
    await db.commit()
    return Ok(message=f"Email de teste enfileirado para {admin.email}.")


# --------------------------------------------------------------------------- mudanças de preço
class PriceChangeIn(BaseModel):
    new_price_cents: int = Field(ge=0)
    # new_only: só novos clientes (os atuais mantêm o preço) | existing: também os atuais, a partir de effective_at
    apply_to: str = Field("existing", pattern="^(new_only|existing)$")
    effective_at: datetime | None = None
    note: str | None = Field(None, max_length=255, description="Mensagem incluída no email aos clientes")


@router.post("/plans/{plan_id}/price-change", response_model=Ok)
async def schedule_price_change(plan_id: int, body: PriceChangeIn, admin: User = Depends(require_admin),
                                db: AsyncSession = Depends(get_db)):
    s = get_settings()
    plan = await db.get(Plan, plan_id)
    if plan is None:
        raise HTTPException(404, detail="Plano não encontrado.")
    if body.new_price_cents == plan.price_cents and body.apply_to == "new_only":
        raise HTTPException(400, detail="O preço é igual ao atual.")
    if body.effective_at is not None and body.effective_at.tzinfo is None:
        body.effective_at = body.effective_at.replace(tzinfo=UTC)  # datas sem fuso = UTC
    old = plan.price_cents
    # Todas as subscrições ficam com o preço fixado antes da mudança (proteção contra alterações acidentais).
    subs = (await db.scalars(select(Subscription).where(
        Subscription.plan_id == plan.id, Subscription.price_cents.is_(None)))).all()
    for sub in subs:
        sub.price_cents = old
    plan.price_cents = body.new_price_cents
    msg = f"Novos clientes pagam {billing_fmt(body.new_price_cents)}."
    if body.apply_to == "existing":
        min_date = utcnow() + timedelta(days=s.price_change_notice_days)
        effective = body.effective_at or min_date
        if effective < min_date - timedelta(hours=1) and body.new_price_cents > old:
            raise HTTPException(400, detail=f"Aumentos de preço exigem pelo menos {s.price_change_notice_days} "
                                            "dias de aviso aos clientes.")
        db.add(PriceChange(plan_id=plan.id, old_price_cents=old, new_price_cents=body.new_price_cents,
                           effective_at=effective, note=body.note, created_by_id=admin.id))
        n = await db.scalar(select(func.count()).select_from(Subscription).where(
            Subscription.plan_id == plan.id, Subscription.status.in_([st.value for st in LIVE_BILLING]),
            Subscription.price_cents == old))
        msg += (f" {n} subscritores passam a {billing_fmt(body.new_price_cents)} na primeira renovação a partir de "
                f"{effective:%d/%m/%Y} — vão receber um email de aviso.")
    audit(db, "admin.price_change", actor=admin, target_type="plan", target_id=plan.id, old=old,
          new=body.new_price_cents, apply_to=body.apply_to)
    await db.commit()
    return Ok(message=msg)


@router.delete("/price-changes/{change_id}", response_model=Ok)
async def cancel_price_change(change_id: int, admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    pc = await db.get(PriceChange, change_id)
    if pc is None or pc.cancelled_at is not None:
        raise HTTPException(404, detail="Mudança não encontrada.")
    if pc.effective_at <= utcnow():
        raise HTTPException(400, detail="Esta mudança já está em vigor.")
    pc.cancelled_at = utcnow()
    audit(db, "admin.price_change_cancelled", actor=admin, target_type="plan", target_id=pc.plan_id, change=pc.id)
    await db.commit()
    return Ok(message="Mudança de preço cancelada (os clientes que já foram avisados mantêm o preço atual)." )


def billing_fmt(cents: int) -> str:
    from ..services.subscriptions import fmt_money

    return fmt_money(cents)


# --------------------------------------------------------------------------- migração de planos
class PlanMigrationIn(BaseModel):
    from_plan_id: int
    to_plan_id: int
    when: str = Field("renewal", pattern="^(renewal|now)$")
    keep_price: bool = False  # manter o preço que cada cliente paga hoje
    notify: bool = True
    note: str | None = Field(None, max_length=255)
    dry_run: bool = False


@router.post("/migrations/plan")
async def migrate_plan(body: PlanMigrationIn, admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    """Move todos os subscritores de um plano para outro (ex.: retirar um plano antigo)."""
    src = await db.get(Plan, body.from_plan_id)
    dst = await db.get(Plan, body.to_plan_id)
    if src is None or dst is None or src.id == dst.id:
        raise HTTPException(400, detail="Planos inválidos.")
    if src.product_id != dst.product_id:
        raise HTTPException(400, detail="Só é possível migrar entre planos do mesmo produto.")
    if body.keep_price and body.when == "now":
        raise HTTPException(400, detail="Manter o preço atual só é possível com a migração na renovação.")
    subs = (await db.scalars(select(Subscription).where(
        Subscription.plan_id == src.id, Subscription.provider == "portal",
        Subscription.status.in_([SubStatus.active.value, SubStatus.bonus.value, SubStatus.past_due.value])))).all()
    if body.dry_run:
        return {"affected": len(subs), "users": [s.user_id for s in subs][:200]}
    done, errors = 0, []
    for sub in subs:
        user = await db.get(User, sub.user_id)
        if user is None:
            continue
        if body.when == "now":
            try:
                async with db.begin_nested():
                    # Sem cobrança imediata: a diferença entra na próxima cobrança de cada cliente (e um commit
                    # dentro do savepoint partia a transação).
                    await billing.change_plan(db, user, sub, dst, charge_now=False)
                done += 1
            except billing.BillingError as exc:
                errors.append({"user": user.username, "error": str(exc)})
        else:
            sub.pending_plan_id = dst.id
            price = plan_price_for(sub, src) if body.keep_price else dst.price_cents
            sub.meta = {**(sub.meta or {}), "pending_price_cents": price}
            done += 1
            if body.notify:
                await queue_email(db, user.email, "plan_migration", old_plan=src.name, new_plan=dst.name,
                                  new_price=billing_fmt(price),
                                  interval="ano" if dst.interval_unit == "year" else "mês",
                                  when=sub.current_period_end.strftime("%d/%m/%Y") if sub.current_period_end else "—",
                                  note=body.note, cta_url=f"{get_settings().public_url}/app/servicos")
    audit(db, "admin.plan_migration", actor=admin, target_type="plan", target_id=src.id, to=dst.id, when=body.when,
          count=done)
    await db.commit()
    return {"affected": done, "errors": errors}


def plan_price_for(sub: Subscription, plan: Plan) -> int:
    return sub.price_cents if sub.price_cents is not None else plan.price_cents


# --------------------------------------------------------------------------- fornecedores de pagamento
@router.get("/providers")
async def providers(db: AsyncSession = Depends(get_db)):
    st = await registry.state(db)
    out = []
    for name, info in st.items():
        rows = (await db.execute(select(PaymentMethod.status, func.count()).where(PaymentMethod.provider == name)
                                 .group_by(PaymentMethod.status))).all()
        counts = {k: v for k, v in rows}
        # clientes que dependem só deste fornecedor (sem alternativa)
        users = (await db.scalars(select(PaymentMethod.user_id).where(
            PaymentMethod.provider == name, PaymentMethod.status.in_(["active", "pending", "unusable"])).distinct())).all()
        only = 0
        for uid in users:
            others = await db.scalar(select(func.count()).select_from(PaymentMethod).where(
                PaymentMethod.user_id == uid, PaymentMethod.provider != name,
                PaymentMethod.status.in_(["active", "pending"])))
            if not others:
                only += 1
        acct = await registry.account_id(name) if info["enabled"] else None
        out.append({**info, "account_id": acct, "methods": counts, "customers_only_on_this": only})
    return out


class ProviderPatch(BaseModel):
    enabled: bool | None = None
    accept_new: bool | None = None


@router.put("/providers/{name}", response_model=Ok)
async def update_provider(name: str, body: ProviderPatch, admin: User = Depends(require_admin),
                          db: AsyncSession = Depends(get_db)):
    if registry.get(name) is None:
        raise HTTPException(404, detail="Fornecedor desconhecido.")
    await registry.set_override(db, name, enabled=body.enabled, accept_new=body.accept_new)
    audit(db, "admin.provider_updated", actor=admin, target_type="provider", target_id=name,
          **body.model_dump(exclude_none=True))
    await db.commit()
    counts = await billing.check_methods(db)  # marca/recupera métodos e avisa clientes já
    msg = "Guardado."
    if counts["unusable"]:
        msg += f" {counts['unusable']} métodos ficaram inutilizáveis; {counts['notified']} clientes avisados por email."
    if counts["restored"]:
        msg += f" {counts['restored']} métodos voltaram a estar disponíveis."
    return Ok(message=msg)


class ProviderNotifyIn(BaseModel):
    message: str | None = Field(None, max_length=500)


@router.post("/providers/{name}/notify", response_model=Ok)
async def notify_provider_users(name: str, body: ProviderNotifyIn, admin: User = Depends(require_admin),
                                db: AsyncSession = Depends(get_db)):
    """Pede aos clientes que só têm métodos deste fornecedor para adicionarem outro (migração suave)."""
    if registry.get(name) is None:
        raise HTTPException(404, detail="Fornecedor desconhecido.")
    reason = body.message or ("Vamos deixar de aceitar pagamentos por este meio em breve. Adiciona um novo método "
                              "de pagamento para continuares sem interrupções.")
    users = (await db.scalars(select(PaymentMethod.user_id).where(
        PaymentMethod.provider == name, PaymentMethod.status.in_(["active", "pending"])).distinct())).all()
    n = 0
    for uid in users:
        others = await db.scalar(select(func.count()).select_from(PaymentMethod).where(
            PaymentMethod.user_id == uid, PaymentMethod.provider != name, PaymentMethod.status.in_(["active", "pending"])))
        if others or not await billing.live_subs(db, uid):
            continue
        await billing._notify_method_needed(db, uid, reason)
        n += 1
    audit(db, "admin.provider_notify", actor=admin, target_type="provider", target_id=name, count=n)
    await db.commit()
    return Ok(message=f"{n} clientes avisados.")


# --------------------------------------------------------------------------- migração do sistema antigo
class LegacyMigrationIn(BaseModel):
    dry_run: bool = True
    # true = a subscrição fica na GoCardless e passa sozinha para o portal na 1.ª alteração do cliente
    keep: bool = True


@router.post("/gocardless/import")
async def import_gocardless(body: LegacyMigrationIn | None = None, db: AsyncSession = Depends(get_db)):
    """Liga (ou converte já, keep=false) as subscrições GoCardless antigas (usar dry_run primeiro)."""
    dry = body.dry_run if body else True
    results = await legacy.migrate_all(db, dry_run=dry, keep=body.keep if body else True)
    migrated = sum(1 for r in results if str(r.get("result", "")).startswith(("migrada", "seria", "ligada",
                                                                               "convertida")))
    return {"dry_run": dry, "count": migrated, "results": results}


@router.post("/stripe/import")
async def import_stripe(body: LegacyMigrationIn | None = None, db: AsyncSession = Depends(get_db)):
    """Migra as subscrições Stripe Billing antigas (ex.: TKGPT) para a faturação do portal (usar dry_run primeiro)."""
    from ..services import legacy_stripe

    dry = body.dry_run if body else True
    results = await legacy_stripe.migrate_all(db, dry_run=dry)
    migrated = sum(1 for r in results if r.get("result") in ("migrada", "seria migrada"))
    return {"dry_run": dry, "count": migrated, "results": results}


# --------------------------------------------------------------------------- carteira
class WalletAdjustIn(BaseModel):
    amount_cents: int = Field(ge=-1_000_000, le=1_000_000)
    reason: str = Field(min_length=1, max_length=200)


@router.post("/users/{user_id}/wallet/adjust")
async def wallet_adjust(user_id: str, body: WalletAdjustIn, admin: User = Depends(require_admin),
                        db: AsyncSession = Depends(get_db)):
    u = await _user(db, user_id)
    try:
        tx = await wallet_svc.admin_adjust(db, admin, u, body.amount_cents, body.reason)
    except wallet_svc.WalletError as exc:
        raise HTTPException(400, detail=str(exc)) from exc
    await db.commit()
    return {"ok": True, "balance_cents": tx.balance_after_cents}


@router.post("/users/{user_id}/wallet/convert")
async def wallet_convert(user_id: str, dry_run: bool = False, admin: User = Depends(require_admin),
                         db: AsyncSession = Depends(get_db)):
    u = await _user(db, user_id)
    out = await wallet_svc.convert_to_monthly(db, u, dry_run=dry_run, actor=admin)
    if dry_run:
        await db.rollback()
    else:
        await db.commit()
    return out


@router.post("/wallet/convert-all")
async def wallet_convert_all(body: LegacyMigrationIn | None = None, admin: User = Depends(require_admin),
                             db: AsyncSession = Depends(get_db)):
    """Passa todos os clientes antigos para os créditos mensais (mesmo valor e dia; sem ação deles)."""
    dry = body.dry_run if body else True
    results = []
    for u in (await db.scalars(select(User).where(User.billing_mode == "legacy"))).all():
        results.append(await wallet_svc.convert_to_monthly(db, u, dry_run=dry, actor=admin))
    if dry:
        await db.rollback()
    else:
        await db.commit()
    n = sum(1 for r in results if r["result"] in ("convertido", "seria convertido"))
    return {"dry_run": dry, "count": n, "results": results}


@router.get("/wallet/stats")
async def wallet_stats(db: AsyncSession = Depends(get_db)):
    """Saldo total em carteiras, carregamentos mensais e resultado dos jogos (para o painel)."""
    from ..models import GameRound, Wallet, WalletTransaction

    total = int(await db.scalar(select(func.coalesce(func.sum(Wallet.balance_cents), 0))) or 0)
    monthly_n = int(await db.scalar(select(func.count()).select_from(Wallet).where(
        Wallet.monthly_topup_cents.is_not(None))) or 0)
    monthly_sum = int(await db.scalar(select(func.coalesce(func.sum(Wallet.monthly_topup_cents), 0))) or 0)
    since = utcnow() - timedelta(days=30)
    games = {}
    for game in ("roulette", "blackjack"):
        wager, payout, n = (await db.execute(select(
            func.coalesce(func.sum(GameRound.wager_cents), 0), func.coalesce(func.sum(GameRound.payout_cents), 0),
            func.count()).where(GameRound.game == game, GameRound.status == "settled",
                                GameRound.settled_at >= since))).one()
        games[game] = {"rounds": int(n), "wagered_cents": int(wager), "paid_cents": int(payout),
                       "house_cents": int(wager) - int(payout)}
    legacy_n = int(await db.scalar(select(func.count()).select_from(User).where(User.billing_mode == "legacy")) or 0)
    topups = int(await db.scalar(select(func.coalesce(func.sum(WalletTransaction.amount_cents), 0)).where(
        WalletTransaction.kind.in_(["topup", "monthly_topup"]), WalletTransaction.created_at >= since)) or 0)
    return {"total_balance_cents": total, "monthly_count": monthly_n, "monthly_sum_cents": monthly_sum,
            "legacy_users": legacy_n, "topups_30d_cents": topups, "games_30d": games,
            "games_enabled": get_settings().games_enabled}
