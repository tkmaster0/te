"""Configuração por web: assistente do primeiro arranque e Admin → Definições.

Tudo o que antes ia para o `.env` (URLs, chaves, passwords, túnel…) é definido aqui e pode ser mudado depois, sem
reiniciar o contentor.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from ..db import get_db
from ..deps import rate_limit, require_admin
from ..models import OIDCClient, Plan, Product, User
from ..schemas import Ok
from ..security import verify_password
from ..services import health, runtime_config, tunnel
from ..services.audit import audit
from ..services.jobs import RetryLater

router = APIRouter(prefix="/api/admin", tags=["admin-setup"], dependencies=[Depends(require_admin)])

STRIPE_EVENTS = [
    "checkout.session.completed", "checkout.session.async_payment_succeeded",
    "checkout.session.async_payment_failed", "checkout.session.expired",
    "payment_intent.succeeded", "payment_intent.payment_failed", "payment_intent.processing",
    "payment_intent.canceled", "charge.dispute.created", "charge.refunded",
    "payment_method.detached", "customer.deleted",
]
# Secção → nome da verificação em services.health
SECTION_CHECK = {"jellyfin": "jellyfin", "seerr": "seerr", "tv": "dispatcharr", "bazarr": "bazarr",
                 "gocardless": "gocardless", "stripe": "stripe"}


class ConfigIn(BaseModel):
    values: dict


async def _apply(db: AsyncSession) -> None:
    await runtime_config.load(db)
    await tunnel.ensure()


@router.get("/config")
async def get_config(db: AsyncSession = Depends(get_db)):
    return {"sections": await runtime_config.describe(db), "tunnel": await tunnel.status()}


@router.put("/config")
async def put_config(body: ConfigIn, admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    try:
        changed = await runtime_config.save(db, body.values, actor_id=admin.id)
    except runtime_config.ConfigError as exc:
        await db.rollback()
        raise HTTPException(400, detail=str(exc)) from exc
    audit(db, "admin.config_updated", actor=admin, keys=changed)
    await db.commit()
    await _apply(db)
    return {"status": "ok", "changed": changed, "message": "Guardado." if changed else "Nada mudou.",
            "sections": await runtime_config.describe(db), "tunnel": await tunnel.status()}


@router.post("/config/test/{section}")
async def test_section(section: str, admin: User = Depends(require_admin)):
    rate_limit(f"config-test:{admin.id}", 30, 300)
    if section == "email":
        from ..services.mailer import send_now

        if not get_settings().smtp_enabled:
            raise HTTPException(400, detail="Define primeiro o servidor SMTP.")
        try:
            await send_now(admin.email, "admin_notice", {"subject": "Email de teste",
                                                         "message": "O email do portal está a funcionar."})
        except RetryLater as exc:
            return {"ok": False, "error": str(exc)}
        return {"ok": True, "message": f"Email de teste enviado para {admin.email}."}
    name = SECTION_CHECK.get(section)
    if name is None:
        raise HTTPException(404, detail="Esta secção não tem teste.")
    result = next((r for r in await health.integrations() if r["name"] == name), None)
    if result is None or not result.get("configured"):
        return {"ok": False, "error": "Ainda não está configurado — preenche e guarda primeiro."}
    if result.get("ok"):
        info = ", ".join(f"{k}: {v}" for k, v in (result.get("info") or {}).items() if v not in (None, ""))
        return {"ok": True, "message": f"Ligação OK{(' — ' + info) if info else ''}."}
    return {"ok": False, "error": result.get("error")}


@router.post("/config/stripe-webhook")
async def create_stripe_webhook(admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    """Cria o webhook no Stripe (com o URL deste portal) e guarda o segredo — sem sair da página."""
    s = get_settings()
    if not s.stripe_enabled:
        raise HTTPException(400, detail="Guarda primeiro a secret key do Stripe.")
    if not s.public_url.startswith("https://"):
        raise HTTPException(400, detail="O endereço público do portal tem de ser https:// (o Stripe exige).")
    from ..integrations import stripe_client as sc

    url = f"{s.public_url}/api/webhooks/stripe"
    try:
        existing = await sc.client().v1.webhook_endpoints.list_async(params={"limit": 100})
        for ep in sc.to_dict(existing).get("data", []):
            if ep.get("url") == url and ep.get("status") == "enabled":
                # O segredo de um webhook existente não pode ser lido pela API: cria-se um novo e apaga-se o antigo.
                await sc.client().v1.webhook_endpoints.delete_async(ep["id"])
        ep = sc.to_dict(await sc.client().v1.webhook_endpoints.create_async(params={
            "url": url, "enabled_events": STRIPE_EVENTS, "description": f"{s.app_name} (criado pelo portal)"}))
    except Exception as exc:  # noqa: BLE001 — erros do SDK do Stripe
        raise HTTPException(502, detail=f"O Stripe recusou: {str(exc)[:300]}") from exc
    await runtime_config.save(db, {"stripe_webhook_secret": ep.get("secret")}, actor_id=admin.id)
    audit(db, "admin.stripe_webhook_created", actor=admin, url=url)
    await db.commit()
    await _apply(db)
    return {"status": "ok", "message": f"Webhook criado no Stripe ({url}) e segredo guardado."}


@router.get("/tunnel")
async def tunnel_status():
    return await tunnel.status()


@router.post("/tunnel/restart", response_model=Ok)
async def tunnel_restart():
    await tunnel._stop()  # noqa: SLF001
    await tunnel.ensure()
    return Ok(message="Túnel reiniciado.")


# --------------------------------------------------------------------------- assistente de configuração
async def _checklist(db: AsyncSession) -> list[dict]:
    s = get_settings()
    default_admin = await db.scalar(select(User).where(User.username == s.test_admin_username.lower(),
                                                       User.is_admin.is_(True)))
    weak = bool(default_admin and verify_password(default_admin.password_hash, s.test_admin_password)[0])
    tun = await tunnel.status()
    presets = await db.scalar(select(func.count()).select_from(OIDCClient).where(
        OIDCClient.client_id.in_(["jellyfin", "seerr", "librechat"])))
    products = await db.scalar(select(func.count()).select_from(Product).where(Product.is_active.is_(True)))
    plans = await db.scalar(select(func.count()).select_from(Plan).where(Plan.is_active.is_(True)))
    legacy = await db.scalar(select(func.count()).select_from(User).where(User.legacy_id.is_not(None)))
    # Serviços ativos sem nenhum plano à venda (ex.: o TKGPT acabado de instalar, à espera do preço)
    no_price = [p.name for p in (await db.scalars(select(Product).where(Product.is_active.is_(True)))).all()
                if not await db.scalar(select(func.count()).select_from(Plan).where(
                    Plan.product_id == p.id, Plan.is_active.is_(True)))]
    local = s.public_url.startswith(("http://localhost", "http://127.0.0.1"))
    return [
        {"id": "conta", "label": "Password do administrador", "done": not weak, "optional": False,
         "hint": "A conta pré-carregada ainda usa a password conhecida." if weak else "Password própria definida."},
        {"id": "geral", "label": "Endereço público", "done": not local, "optional": False,
         "hint": s.public_url},
        {"id": "tunel", "label": "Túnel Cloudflare", "done": bool(tun["connected"]), "optional": True,
         "hint": "Ligado" if tun["connected"] else ("A ligar…" if tun["running"] else "Sem túnel")},
        {"id": "email", "label": "Email (SMTP)", "done": s.smtp_enabled, "optional": False,
         "hint": s.smtp_host or "Sem SMTP — os códigos de confirmação não são enviados"},
        {"id": "pagamentos", "label": "Pagamentos", "done": s.gocardless_enabled or s.stripe_enabled, "optional": False,
         "hint": ", ".join(n for n, on in (("GoCardless", s.gocardless_enabled), ("Stripe", s.stripe_enabled)) if on)
         or "Nenhum fornecedor"},
        {"id": "jellyfin", "label": "Jellyfin e serviços do TKFLIX", "done": s.jellyfin_enabled, "optional": True,
         "hint": s.jellyfin_url or "Não ligado"},
        {"id": "sso", "label": "SSO (Jellyfin, Seerr, LibreChat)", "done": bool(presets), "optional": True,
         "hint": f"{presets} clientes OIDC" if presets else "Clientes ainda não criados"},
        {"id": "servicos", "label": "Serviços e planos", "done": bool(products and plans) and not no_price,
         "optional": False, "hint": f"{products} serviços, {plans} planos ativos"
         + (f" · sem preço: {', '.join(no_price)} (define o preço e ativa o plano)" if no_price else "")},
        {"id": "migracao", "label": "Clientes do site antigo", "done": bool(legacy), "optional": True,
         "hint": f"{legacy} importados" if legacy else "Ainda não importados"},
    ]


@router.get("/setup")
async def setup_status(db: AsyncSession = Depends(get_db)):
    return {"completed": await runtime_config.setup_completed(db), "checklist": await _checklist(db),
            "public_url": get_settings().public_url}


@router.post("/setup/complete", response_model=Ok)
async def setup_complete(admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    await runtime_config.mark_setup_completed(db, admin.id)
    audit(db, "admin.setup_completed", actor=admin)
    await db.commit()
    return Ok(message="Configuração concluída. Podes mudar tudo mais tarde em Admin → Definições.")


# --------------------------------------------------------------------------- apps (LibreChat / TKGPT)
@router.get("/apps/librechat")
async def librechat_snippets(db: AsyncSession = Depends(get_db)):
    """O que pôr no LibreChat para o TKGPT: login com a conta TKWS (só com a subscrição ativa) e o limite mensal."""
    s = get_settings()
    client = await db.get(OIDCClient, "librechat")
    env = "\n".join([
        f"OPENID_ISSUER={s.issuer}",
        "OPENID_CLIENT_ID=librechat",
        "OPENID_CLIENT_SECRET=<o segredo mostrado ao criar o cliente>",
        "OPENID_SESSION_SECRET=<uma frase aleatória longa>",
        'OPENID_SCOPE="openid profile email offline_access"',
        "OPENID_CALLBACK_URL=/oauth/openid/callback",
        "OPENID_USE_PKCE=true",
        "OPENID_REUSE_TOKENS=true",
        "OPENID_BUTTON_LABEL=Entrar com TK Web Services",
        "ALLOW_SOCIAL_LOGIN=true",
        "ALLOW_SOCIAL_REGISTRATION=true",
        "ALLOW_EMAIL_LOGIN=false",
        "ALLOW_REGISTRATION=false",
    ])
    yaml = "\n".join([
        "balance:",
        "  enabled: true",
        "  startBalance: 2500000",
        "  autoRefillEnabled: true",
        "  refillIntervalValue: 1",
        "  refillIntervalUnit: 'months'",
        "  refillAmount: 2500000",
    ])
    return {"configured": bool(s.librechat_url), "librechat_url": s.librechat_url, "client_exists": client is not None,
            "env": env, "yaml": yaml, "product_code": s.librechat_product_code}
