"""API dos jogos (roleta europeia e blackjack) com os créditos da carteira."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from ..db import get_db
from ..deps import rate_limit, require_verified
from ..games import service as games
from ..models import User
from ..schemas import BlackjackActionIn, BlackjackStartIn, ClientSeedIn, GamesSettingsIn, Ok, RouletteSpinIn
from ..services.wallet import WalletError

router = APIRouter(prefix="/api/games", tags=["games"])


def _err(exc: Exception) -> HTTPException:
    if isinstance(exc, games.GamesHidden):
        return HTTPException(404, detail="Não encontrado.")
    return HTTPException(400, detail=str(exc))


async def require_games(user: User = Depends(require_verified)) -> User:
    """Os jogos não existem para quem não tem o TKFLIX desbloqueado (nem se revela que existem)."""
    if not games.games_available(user):
        raise HTTPException(404, detail="Não encontrado.")
    return user


@router.get("")
async def overview(user: User = Depends(require_games), db: AsyncSession = Depends(get_db)):
    await games.apply_pending_limit(db, user)
    out = await games.settings_view(db, user)
    out["history"] = await games.history(db, user)
    bj = await games.current_blackjack(db, user)
    out["blackjack"] = await games._bj_out(db, user, bj) if bj else None
    await db.commit()
    return out


@router.put("/settings", response_model=Ok)
async def update_settings(body: GamesSettingsIn, user: User = Depends(require_games),
                          db: AsyncSession = Depends(get_db)):
    await games.update_settings(db, user, accept=body.accept, daily_loss_limit_cents=body.daily_loss_limit_cents,
                                exclude_days=body.exclude_days,
                                set_limit="daily_loss_limit_cents" in body.model_fields_set)
    await db.commit()
    if body.exclude_days:
        return Ok(message=f"Pausa de {body.exclude_days} dia(s) ativa. Até já!")
    return Ok(message="Preferências guardadas.")


@router.post("/seed")
async def rotate_seed(body: ClientSeedIn, user: User = Depends(require_games), db: AsyncSession = Depends(get_db)):
    try:
        out = await games.rotate_seed(db, user, body.client_seed)
    except games.GameError as exc:
        raise _err(exc) from exc
    await db.commit()
    return out


@router.post("/roulette/spin")
async def roulette_spin(body: RouletteSpinIn, user: User = Depends(require_games),
                        db: AsyncSession = Depends(get_db)):
    rate_limit(f"roulette:{user.id}", 40, 60)
    try:
        out = await games.spin(db, user, [b.model_dump() for b in body.bets])
    except (games.GameError, WalletError) as exc:
        await db.rollback()
        raise _err(exc) from exc
    await db.commit()
    return out


@router.post("/blackjack/start")
async def blackjack_start(body: BlackjackStartIn, user: User = Depends(require_games),
                          db: AsyncSession = Depends(get_db)):
    rate_limit(f"blackjack:{user.id}", 60, 60)
    try:
        out = await games.blackjack_start(db, user, body.bet_cents)
    except (games.GameError, WalletError) as exc:
        await db.rollback()
        raise _err(exc) from exc
    await db.commit()
    return out


@router.post("/blackjack/action")
async def blackjack_action(body: BlackjackActionIn, user: User = Depends(require_games),
                           db: AsyncSession = Depends(get_db)):
    rate_limit(f"blackjack:{user.id}", 120, 60)
    try:
        out = await games.blackjack_action(db, user, body.action)
    except (games.GameError, WalletError) as exc:
        await db.rollback()
        raise _err(exc) from exc
    await db.commit()
    return out
