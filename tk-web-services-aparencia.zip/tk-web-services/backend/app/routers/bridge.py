"""Ponte Jellyfin → portal (página "A minha subscrição" do plugin Custom Pages).

**Só gere a subscrição de streaming** (produtos com `jellyfin_managed`). Outros produtos do portal nunca
aparecem aqui nem podem ser alterados por este caminho.

A página corre dentro do Jellyfin com "Allow system access" e envia o access token da sessão Jellyfin do
utilizador em cada pedido. O portal valida o token no próprio Jellyfin (`/Users/Me`), identifica o cliente e
permite, dentro da página:
  * ver o estado da subscrição de streaming, o próximo pagamento e o método de pagamento;
  * mudar de plano de streaming (com pré-visualização da pro-rata), cancelar e reativar;
  * subscrever o streaming se já houver um método de pagamento guardado.
Para tudo o resto (adicionar método de pagamento, outros serviços, conta) a página abre o portal: com um link
de uso único que cria uma sessão **limitada ao streaming**, ou pedindo login normal.
"""
from __future__ import annotations

import time
from urllib.parse import urlparse

from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse, Response
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from ..config import get_settings
from ..db import get_db
from ..deps import client_ip, rate_limit
from ..integrations.jellyfin import JellyfinClient, JellyfinError
from ..models import Plan, Product, ServiceAccount, Subscription, SubStatus, User
from ..payments import registry
from ..services import billing, tokens
from ..services.billing import BillingError
from ..services.subscriptions import fmt_date, fmt_money

router = APIRouter(prefix="/api/integrations/jellyfin", tags=["integrations"])

LABELS = {"active": "Ativa", "past_due": "Pagamento em atraso", "canceling": "Cancelada — acesso até ao fim do período",
          "bonus": "Bónus de convites 🎁", "suspended": "Suspensa", "ended": "Terminada", "pending": "A processar"}

_token_cache: dict[str, tuple[float, dict]] = {}


def _allowed_origin(request: Request) -> str | None:
    s = get_settings()
    origin = request.headers.get("origin")
    if not origin:
        return None
    allowed = set()
    for url in (s.jellyfin_public_url, s.jellyfin_url, *s.jellyfin_extra_origins):
        if url:
            p = urlparse(url)
            allowed.add(f"{p.scheme}://{p.netloc}")
    return origin if origin in allowed else None


def _cors(resp: Response, origin: str | None) -> Response:
    if origin:
        resp.headers["Access-Control-Allow-Origin"] = origin
        resp.headers["Access-Control-Allow-Methods"] = "POST, OPTIONS"
        resp.headers["Access-Control-Allow-Headers"] = "Content-Type"
        resp.headers["Access-Control-Max-Age"] = "600"
        resp.headers["Vary"] = "Origin"
    return resp


class BridgeIn(BaseModel):
    token: str = Field(min_length=16, max_length=128)


class ActionIn(BridgeIn):
    action: str = Field(pattern="^(quote|change|cancel|resume|subscribe|open_portal)$")
    plan_id: int | None = None
    subscription_id: str | None = None
    next: str | None = Field(None, max_length=100)


async def _jellyfin_user(token: str) -> dict | None:
    hit = _token_cache.get(token)
    if hit and time.monotonic() - hit[0] < 60:
        return hit[1]
    try:
        me = await JellyfinClient(timeout=8).whoami(token)
    except JellyfinError:
        return None
    if len(_token_cache) > 2000:
        _token_cache.clear()
    _token_cache[token] = (time.monotonic(), me)
    return me


async def _resolve(db: AsyncSession, request: Request, token: str) -> tuple[User | None, dict | None, JSONResponse | None]:
    origin = _allowed_origin(request)
    if request.headers.get("origin") and origin is None:
        return None, None, JSONResponse({"detail": "Origem não autorizada."}, status_code=403)
    rate_limit(f"jf-bridge:{client_ip(request)}", 60, 600)
    me = await _jellyfin_user(token)
    if me is None:
        return None, None, _cors(JSONResponse({"detail": "Sessão Jellyfin inválida."}, status_code=401), origin)
    jf_id = str(me.get("Id", "")).replace("-", "")
    sa = await db.scalar(select(ServiceAccount).where(ServiceAccount.service == "jellyfin",
                                                      ServiceAccount.external_id.in_([jf_id, me.get("Id")])))
    user = await db.get(User, sa.user_id) if sa else None
    if user is not None and not user.is_active:
        return None, me, _cors(JSONResponse({"detail": "Conta indisponível."}, status_code=403), origin)
    return user, me, None


async def _streaming_state(db: AsyncSession, user: User) -> dict:
    providers = await registry.available_for_new(db)
    products = (await db.scalars(select(Product).options(selectinload(Product.plans)).where(
        Product.jellyfin_managed.is_(True), Product.is_active.is_(True)).order_by(Product.sort_order))).all()
    product_ids = [p.id for p in products]
    subs = (await db.scalars(select(Subscription).where(
        Subscription.user_id == user.id, Subscription.product_id.in_(product_ids),
        Subscription.status.in_([s.value for s in billing.LIVE_BILLING]))
        .order_by(Subscription.created_at.desc()))).all()
    sub_rows = []
    for sub in subs:
        plan = await db.get(Plan, sub.plan_id)
        sub_rows.append({
            "id": sub.id, "product_id": sub.product_id, "plan_id": sub.plan_id, "plan": plan.name if plan else "?",
            "status": sub.status, "status_label": LABELS.get(sub.status, sub.status),
            "price": fmt_money(billing.plan_price(sub, plan)) if plan else None,
            "interval": "ano" if plan and plan.interval_unit == "year" else "mês",
            "renews_at": fmt_date(sub.current_period_end) if sub.status != SubStatus.canceling else None,
            "access_until": fmt_date(sub.access_until or sub.current_period_end)
            if sub.status == SubStatus.canceling else None,
            "grace_until": fmt_date(sub.grace_until) if sub.status == SubStatus.past_due else None,
            "can_change": sub.status in (SubStatus.active, SubStatus.bonus) and sub.provider in ("portal", "gocardless"),
            "can_cancel": sub.status in (SubStatus.active, SubStatus.bonus, SubStatus.past_due)
            and sub.provider in ("portal", "gocardless"),
            "can_resume": sub.status == SubStatus.canceling and sub.provider in ("portal", "gocardless"),
        })
    plans = [{"id": pl.id, "product_id": pl.product_id, "name": pl.name, "price": fmt_money(pl.price_cents),
              "interval": "ano" if pl.interval_unit == "year" else "mês", "highlights": pl.highlights or []}
             for p in products for pl in p.plans if pl.is_active and pl.is_public]
    method = await billing.default_method(db, user.id)
    unpaid = await billing.unpaid_invoices(db, user.id)
    return {
        "subscriptions": sub_rows,
        "plans": plans,
        "payment_method": method.label if method else None,
        "next_billing_at": fmt_date(user.next_billing_at) if user.next_billing_at else None,
        "has_unpaid": bool(unpaid),
        "can_add_method": bool(providers),
    }


async def _magic_url(db: AsyncSession, user: User, next_path: str | None) -> str:
    nxt = next_path if next_path and next_path.startswith("/app/streaming") else "/app/streaming"
    raw = await tokens.issue(db, user.id, "magic_login", {"next": nxt})
    return f"{get_settings().public_url}/entrar-jellyfin?token={raw}"


@router.options("/exchange")
@router.options("/action")
async def preflight(request: Request):
    return _cors(Response(status_code=204), _allowed_origin(request))


@router.post("/exchange")
async def exchange(body: BridgeIn, request: Request, db: AsyncSession = Depends(get_db)):
    """Estado da subscrição de streaming do utilizador Jellyfin."""
    s = get_settings()
    origin = _allowed_origin(request)
    user, me, err = await _resolve(db, request, body.token)
    if err:
        return err
    if user is None:
        return _cors(JSONResponse({"linked": False, "username": (me or {}).get("Name"),
                                   "register_url": f"{s.public_url}/registar"}), origin)
    state = await _streaming_state(db, user)
    return _cors(JSONResponse({
        "linked": True,
        "username": user.username,
        "display_name": user.display_name or user.username,
        "is_admin": user.is_admin,
        **state,
        "portal_url": s.public_url,
    }), origin)


async def _how_to_pay(db: AsyncSession, user: User, q) -> str:
    """wallet (o saldo paga) | method (método guardado / carregamento mensal) | needs_method | needs_wallet."""
    from ..models import Wallet
    from ..services import wallet as wallet_svc

    method = await billing.default_method(db, user.id)
    if get_settings().billing_require_method and not wallet_svc.is_wallet_only(user):
        return "method" if method else "needs_method"
    if q.wallet_balance_cents >= q.due_now_cents + q.next_invoice_cents and q.due_now_cents + q.next_invoice_cents > 0:
        return "wallet"
    if wallet_svc.is_wallet_only(user):
        w = await db.get(Wallet, user.id)
        return "method" if (w and w.monthly_topup_cents and method) else "needs_wallet"
    return "method" if method else "needs_method"


@router.post("/action")
async def action(body: ActionIn, request: Request, db: AsyncSession = Depends(get_db)):
    """Ações sobre a subscrição de streaming, feitas dentro da página do Jellyfin."""
    s = get_settings()
    origin = _allowed_origin(request)
    user, _, err = await _resolve(db, request, body.token)
    if err:
        return err
    if user is None:
        return _cors(JSONResponse({"detail": "Conta Jellyfin não ligada ao portal."}, status_code=404), origin)
    rate_limit(f"jf-action:{user.id}", 20, 600)

    def reply(data: dict, status: int = 200) -> Response:
        return _cors(JSONResponse(data, status_code=status), origin)

    async def streaming_sub() -> Subscription | None:
        if not body.subscription_id:
            return None
        sub = await db.get(Subscription, body.subscription_id)
        if sub is None or sub.user_id != user.id:
            return None
        product = await db.get(Product, sub.product_id)
        return sub if product and product.jellyfin_managed else None

    async def streaming_plan() -> Plan | None:
        if not body.plan_id:
            return None
        plan = await db.get(Plan, body.plan_id)
        if plan is None or not plan.is_active or not plan.is_public:
            return None
        product = await db.get(Product, plan.product_id)
        return plan if product and product.jellyfin_managed and product.is_active else None

    try:
        if body.action == "open_portal":
            if user.is_admin:
                return reply({"url": f"{s.public_url}/login?next=/app/streaming"})
            url = await _magic_url(db, user, body.next)
            await db.commit()
            return reply({"url": url})

        if body.action in ("quote", "change", "subscribe"):
            plan = await streaming_plan()
            if plan is None:
                return reply({"detail": "Plano indisponível."}, 404)
            if body.action == "quote":
                sub = await streaming_sub()
                q = await billing.quote_change(db, user, sub, plan) if sub else await billing.quote_new(db, user, plan)
                out = q.as_dict()
                how = await _how_to_pay(db, user, q)
                out["needs_payment_method"] = how in ("needs_method", "needs_wallet") and sub is None
                out["needs_wallet"] = how == "needs_wallet" and sub is None
                out["paid_by_wallet"] = how == "wallet"
                return reply(out)
            if body.action == "change":
                sub = await streaming_sub()
                if sub is None:
                    return reply({"detail": "Subscrição não encontrada."}, 404)
                q = await billing.change_plan(db, user, sub, plan, scope="streaming")
                await db.commit()
                net = q.due_now_cents + q.next_invoice_cents
                msg = (f"Plano alterado para {plan.name}. " + (
                    f"A diferença ({fmt_money(net)}) entra na próxima cobrança." if net > 0 else
                    f"Ficas com {fmt_money(-net)} de crédito." if net < 0 else ""))
                return reply({"ok": True, "message": msg.strip()})
            # subscribe
            q = await billing.quote_new(db, user, plan)
            how = await _how_to_pay(db, user, q)
            if how == "needs_wallet":
                # Conta só-carteira sem saldo: o carregamento mensal liga-se no portal (sessão completa).
                return reply({"ok": False, "needs_payment_method": True,
                              "url": f"{s.public_url}/login?next=/app/planos?plano={plan.id}",
                              "message": "Os serviços TK pagam-se com a carteira — abre a TK Web Services para ativar o "
                                         "carregamento mensal."})
            if how == "needs_method":
                url = await _magic_url(db, user, f"/app/streaming?plano={plan.id}") if not user.is_admin else \
                    f"{s.public_url}/login?next=/app/streaming"
                await db.commit()
                return reply({"ok": False, "needs_payment_method": True, "url": url,
                              "message": "Falta um método de pagamento — abre o portal para o adicionar."})
            method = await billing.default_method(db, user.id)
            sub = await billing.subscribe(db, user, plan, method=method, scope="streaming")
            await db.commit()
            if sub.status == SubStatus.pending:
                return reply({"ok": True, "message": f"Estamos a processar o pagamento de {plan.name} — fica ativo "
                                                     "assim que for confirmado."})
            return reply({"ok": True, "message": f"{plan.name} ativo. Bom filme! 🍿"})

        sub = await streaming_sub()
        if sub is None:
            return reply({"detail": "Subscrição não encontrada."}, 404)
        if body.action == "cancel":
            await billing.cancel(db, user, sub, scope="streaming")
            await db.commit()
            return reply({"ok": True, "message": "Cancelado. Manténs o acesso até "
                                                 f"{fmt_date(sub.access_until or sub.current_period_end)}."})
        if body.action == "resume":
            await billing.resume(db, user, sub, scope="streaming")
            await db.commit()
            return reply({"ok": True, "message": "Reativado — continua tudo como antes."})
    except BillingError as exc:
        await db.rollback()
        return reply({"detail": str(exc)}, 400)
    except Exception:  # noqa: BLE001
        await db.rollback()
        return reply({"detail": "Não foi possível concluir agora. Tenta de novo dentro de instantes."}, 502)
    return reply({"detail": "Ação desconhecida."}, 400)
