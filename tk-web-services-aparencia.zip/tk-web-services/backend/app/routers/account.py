from __future__ import annotations

import io

import qrcode
import qrcode.image.svg
from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from ..db import get_db, utcnow
from ..deps import client_ip, optional_session, rate_limit, require_user, revoke_user_sessions
from ..models import AuditLog, LoginSession, User
from ..schemas import (
    ActivityOut,
    EmailChangeIn,
    MeOut,
    Ok,
    PasswordChangeIn,
    PasswordOnlyIn,
    ProfileIn,
    RecoveryCodesOut,
    SessionOut,
    TokenIn,
    TotpDisableIn,
    TotpEnableIn,
    TotpSetupOut,
)
from ..security import (
    decrypt,
    encrypt,
    hash_password,
    hash_recovery_code,
    new_recovery_codes,
    new_totp_secret,
    password_problems,
    totp_uri,
    verify_password,
    verify_totp,
)
from ..serializers import me_out
from ..services import tokens
from ..services.audit import audit
from ..services.mailer import queue_email
from ..services.provisioning import queue_jellyfin_password
from ..services.subscriptions import request_reconcile

router = APIRouter(prefix="/api/account", tags=["account"])


def _check_password(user: User, password: str) -> None:
    ok, _ = verify_password(user.password_hash, password)
    if not ok:
        raise HTTPException(400, detail="Password atual incorreta.")


@router.patch("/profile", response_model=MeOut)
async def update_profile(body: ProfileIn, user: User = Depends(require_user), db: AsyncSession = Depends(get_db)):
    if body.display_name is not None:
        user.display_name = body.display_name.strip() or None
    if body.locale:
        user.locale = body.locale
    await db.commit()
    return await me_out(db, user)


@router.post("/password", response_model=Ok)
async def change_password(body: PasswordChangeIn, request: Request, user: User = Depends(require_user),
                          sess: LoginSession | None = Depends(optional_session), db: AsyncSession = Depends(get_db)):
    rate_limit(f"pwchange:{user.id}", 5, 900)
    _check_password(user, body.current_password)
    if (problems := password_problems(body.new_password, username=user.username, email=user.email)):
        raise HTTPException(400, detail=" ".join(problems))
    user.password_hash = hash_password(body.new_password)
    user.password_changed_at = utcnow()
    if body.logout_others:
        await revoke_user_sessions(db, user.id, except_id=sess.id if sess else None)
    await queue_jellyfin_password(db, user, body.new_password)
    await queue_email(db, user.email, "password_changed", username=user.username,
                      when=utcnow().strftime("%d/%m/%Y %H:%M UTC"))
    audit(db, "account.password_changed", actor=user, target_type="user", target_id=user.id, ip=client_ip(request))
    await db.commit()
    return Ok(message="Password alterada. O Jellyfin é atualizado dentro de instantes.")


@router.post("/email", response_model=Ok)
async def request_email_change(body: EmailChangeIn, user: User = Depends(require_user),
                               db: AsyncSession = Depends(get_db)):
    rate_limit(f"emailchange:{user.id}", 3, 3600)
    _check_password(user, body.password)
    new_email = body.new_email.strip().lower()
    if new_email == user.email:
        raise HTTPException(400, detail="Esse já é o teu email.")
    if await db.scalar(select(User.id).where(User.email == new_email)):
        raise HTTPException(400, detail="Esse email já está associado a outra conta.")
    raw = await tokens.issue(db, user.id, "change_email", {"email": new_email})
    await queue_email(db, new_email, "change_email", username=user.username,
                      cta_url=f"{get_settings().public_url}/confirmar-email?token={raw}")
    await db.commit()
    return Ok(message=f"Enviámos um link de confirmação para {new_email}.")


@router.post("/email/confirm", response_model=Ok)
async def confirm_email_change(body: TokenIn, db: AsyncSession = Depends(get_db)):
    tok = await tokens.consume(db, body.token, "change_email")
    if tok is None or not tok.data:
        raise HTTPException(400, detail="Link inválido ou expirado.")
    user = await db.get(User, tok.user_id)
    new_email = tok.data["email"]
    if user is None:
        raise HTTPException(400, detail="Conta inexistente.")
    if await db.scalar(select(User.id).where(User.email == new_email, User.id != user.id)):
        raise HTTPException(400, detail="Esse email já está associado a outra conta.")
    old = user.email
    user.email = new_email
    user.email_verified_at = utcnow()
    audit(db, "account.email_changed", actor=user, target_type="user", target_id=user.id, old=old, new=new_email)
    await queue_email(db, old, "admin_notice", subject="Email da conta alterado",
                      message=f"O email da conta {user.username} foi alterado para {new_email}. "
                              "Se não foste tu, contacta o suporte.")
    await request_reconcile(db, user.id)  # propaga o email ao Seerr
    await db.commit()
    return Ok(message="Email alterado.")


# --------------------------------------------------------------------------- sessões
@router.get("/sessions", response_model=list[SessionOut])
async def list_sessions(user: User = Depends(require_user), sess: LoginSession | None = Depends(optional_session),
                        db: AsyncSession = Depends(get_db)):
    rows = (await db.scalars(select(LoginSession).where(
        LoginSession.user_id == user.id, LoginSession.revoked_at.is_(None), LoginSession.expires_at > utcnow(),
        LoginSession.mfa_pending.is_(False)).order_by(LoginSession.last_seen_at.desc()))).all()
    return [SessionOut(id=r.public_id, created_at=r.created_at, last_seen_at=r.last_seen_at, ip=r.ip,
                       user_agent=r.user_agent, current=bool(sess and r.id == sess.id)) for r in rows]


@router.delete("/sessions/{public_id}", response_model=Ok)
async def revoke_session(public_id: str, user: User = Depends(require_user), db: AsyncSession = Depends(get_db)):
    row = await db.scalar(select(LoginSession).where(LoginSession.public_id == public_id,
                                                     LoginSession.user_id == user.id))
    if row is None:
        raise HTTPException(404, detail="Sessão não encontrada.")
    row.revoked_at = utcnow()
    await db.commit()
    return Ok()


@router.post("/sessions/revoke-others", response_model=Ok)
async def revoke_others(user: User = Depends(require_user), sess: LoginSession | None = Depends(optional_session),
                        db: AsyncSession = Depends(get_db)):
    n = await revoke_user_sessions(db, user.id, except_id=sess.id if sess else None)
    await db.commit()
    return Ok(message=f"{n} sessões terminadas.")


# --------------------------------------------------------------------------- 2FA
@router.post("/2fa/setup", response_model=TotpSetupOut)
async def totp_setup(user: User = Depends(require_user), db: AsyncSession = Depends(get_db)):
    if user.totp_enabled:
        raise HTTPException(400, detail="A autenticação de dois fatores já está ativa.")
    secret = new_totp_secret()
    user.totp_secret_enc = encrypt(secret)
    await db.commit()
    uri = totp_uri(secret, user.email)
    img = qrcode.make(uri, image_factory=qrcode.image.svg.SvgPathImage, box_size=8)
    buf = io.BytesIO()
    img.save(buf)
    return TotpSetupOut(secret=secret, otpauth_uri=uri, qr_svg=buf.getvalue().decode())


@router.post("/2fa/enable", response_model=RecoveryCodesOut)
async def totp_enable(body: TotpEnableIn, request: Request, user: User = Depends(require_user),
                      db: AsyncSession = Depends(get_db)):
    rate_limit(f"totp-enable:{user.id}", 10, 600)
    secret = decrypt(user.totp_secret_enc)
    if not secret or not verify_totp(secret, body.code):
        raise HTTPException(400, detail="Código inválido. Confirma a hora do telemóvel e tenta de novo.")
    codes = new_recovery_codes()
    user.totp_enabled = True
    user.recovery_codes = [hash_recovery_code(c) for c in codes]
    audit(db, "account.2fa_enabled", actor=user, target_type="user", target_id=user.id, ip=client_ip(request))
    await db.commit()
    return RecoveryCodesOut(recovery_codes=codes)


@router.post("/2fa/disable", response_model=Ok)
async def totp_disable(body: TotpDisableIn, request: Request, user: User = Depends(require_user),
                       db: AsyncSession = Depends(get_db)):
    rate_limit(f"totp-disable:{user.id}", 5, 900)
    _check_password(user, body.password)
    secret = decrypt(user.totp_secret_enc)
    code = body.code.strip().lower()
    valid = bool(secret and verify_totp(secret, code)) or (hash_recovery_code(code) in (user.recovery_codes or []))
    if not valid:
        raise HTTPException(400, detail="Código inválido.")
    user.totp_enabled = False
    user.totp_secret_enc = None
    user.recovery_codes = None
    audit(db, "account.2fa_disabled", actor=user, target_type="user", target_id=user.id, ip=client_ip(request))
    await db.commit()
    return Ok(message="Autenticação de dois fatores desativada.")


@router.post("/2fa/recovery-codes", response_model=RecoveryCodesOut)
async def regenerate_recovery(body: PasswordOnlyIn, user: User = Depends(require_user),
                              db: AsyncSession = Depends(get_db)):
    rate_limit(f"recovery-regen:{user.id}", 5, 900)
    if not user.totp_enabled:
        raise HTTPException(400, detail="Ativa primeiro a autenticação de dois fatores.")
    _check_password(user, body.password)
    codes = new_recovery_codes()
    user.recovery_codes = [hash_recovery_code(c) for c in codes]
    audit(db, "account.recovery_codes_regenerated", actor=user, target_type="user", target_id=user.id)
    await db.commit()
    return RecoveryCodesOut(recovery_codes=codes)


@router.get("/activity", response_model=list[ActivityOut])
async def activity(user: User = Depends(require_user), db: AsyncSession = Depends(get_db)):
    rows = (await db.scalars(select(AuditLog).where(
        or_(AuditLog.actor_id == user.id, AuditLog.target_id == user.id),
        AuditLog.action.like("auth.%") | AuditLog.action.like("account.%"),
    ).order_by(AuditLog.created_at.desc()).limit(50))).all()
    return [ActivityOut(created_at=r.created_at, action=r.action, ip=r.ip, details=None) for r in rows]
