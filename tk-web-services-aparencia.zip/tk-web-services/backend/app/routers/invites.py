from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from ..db import get_db
from ..deps import rate_limit, require_user, require_verified
from ..models import InviteCode, Subscription, User
from ..schemas import InviteCreateIn, InviteEmailIn, InviteOut, Ok
from ..security import new_invite_code
from ..services.audit import audit
from ..services.bonus import _is_paying, bonus_status
from ..services.mailer import queue_email
from ..services.subscriptions import compute_access

router = APIRouter(prefix="/api/invites", tags=["invites"])

STATUS_LABEL = {
    "active": "Ativa", "past_due": "Em dívida", "canceling": "A expirar", "bonus": "Bónus",
    "suspended": "Suspensa", "ended": "Terminada", "pending": "Pendente",
}


def invite_out(inv: InviteCode) -> InviteOut:
    return InviteOut(id=inv.id, code=inv.code, uses=inv.uses, max_uses=inv.max_uses, expires_at=inv.expires_at,
                     disabled=inv.disabled, note=inv.note, created_at=inv.created_at,
                     link=f"{get_settings().public_url}/registar?convite={inv.code}")


async def _can_create(db: AsyncSession, user: User) -> tuple[bool, str | None, int]:
    s = get_settings()
    open_codes = int(await db.scalar(select(func.count()).select_from(InviteCode).where(
        InviteCode.created_by_id == user.id, InviteCode.disabled.is_(False),
        InviteCode.uses < InviteCode.max_uses)) or 0)
    if user.is_admin:
        return True, None, open_codes
    if s.invites_require_active_subscription and not (await compute_access(db, user)).any_active:
        return False, "Precisas de uma subscrição ativa para convidar amigos.", open_codes
    if open_codes >= s.invites_per_user:
        return False, f"Já tens {open_codes} convites por usar (máximo {s.invites_per_user}).", open_codes
    return True, None, open_codes


@router.get("")
async def my_invites(user: User = Depends(require_user), db: AsyncSession = Depends(get_db)):
    codes = (await db.scalars(select(InviteCode).where(InviteCode.created_by_id == user.id)
                              .order_by(InviteCode.created_at.desc()))).all()
    invitees = (await db.scalars(select(User).where(User.referred_by_id == user.id)
                                 .order_by(User.created_at.desc()))).all()
    rows = []
    for inv in invitees:
        sub = await db.scalar(select(Subscription).where(Subscription.user_id == inv.id)
                              .order_by(Subscription.created_at.desc()).limit(1))
        status = sub.status if sub else None
        rows.append({"username": inv.username, "joined": inv.created_at, "status": status,
                     "status_label": STATUS_LABEL.get(status, "Sem subscrição") if status else "Sem subscrição",
                     "counts_for_bonus": await _is_paying(db, inv)})
    can, reason, _ = await _can_create(db, user)
    return {
        "codes": [invite_out(c) for c in codes],
        "invitees": rows,
        "bonus": await bonus_status(db, user),
        "can_create": can,
        "reason": reason,
        "limit": get_settings().invites_per_user,
    }


@router.post("", response_model=InviteOut)
async def create_invite(body: InviteCreateIn, user: User = Depends(require_verified), db: AsyncSession = Depends(get_db)):
    rate_limit(f"invite-create:{user.id}", 10, 3600)
    can, reason, _ = await _can_create(db, user)
    if not can:
        raise HTTPException(400, detail=reason)
    inv = InviteCode(code=new_invite_code(), created_by_id=user.id, max_uses=1, note=body.note)
    db.add(inv)
    audit(db, "invite.create", actor=user, target_type="invite", target_id=inv.code)
    await db.commit()
    return invite_out(inv)


@router.delete("/{invite_id}", response_model=Ok)
async def disable_invite(invite_id: int, user: User = Depends(require_user), db: AsyncSession = Depends(get_db)):
    inv = await db.scalar(select(InviteCode).where(InviteCode.id == invite_id, InviteCode.created_by_id == user.id))
    if inv is None:
        raise HTTPException(404, detail="Convite não encontrado.")
    inv.disabled = True
    await db.commit()
    return Ok()


@router.post("/{invite_id}/email", response_model=Ok)
async def email_invite(invite_id: int, body: InviteEmailIn, user: User = Depends(require_verified),
                       db: AsyncSession = Depends(get_db)):
    rate_limit(f"invite-email:{user.id}", 5, 3600)
    inv = await db.scalar(select(InviteCode).where(InviteCode.id == invite_id, InviteCode.created_by_id == user.id))
    if inv is None or inv.disabled or inv.uses >= inv.max_uses:
        raise HTTPException(400, detail="Convite indisponível.")
    await queue_email(db, str(body.email).lower(), "invite", inviter=user.display_name or user.username, code=inv.code,
                      cta_url=invite_out(inv).link)
    audit(db, "invite.email", actor=user, target_type="invite", target_id=inv.code)
    await db.commit()
    return Ok(message="Convite enviado.")
