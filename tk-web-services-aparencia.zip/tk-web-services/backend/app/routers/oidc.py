"""Fornecedor OpenID Connect (Authorization Code + PKCE) e forward-auth para o reverse proxy.

Permite "Entrar com TK Web Services" em qualquer app compatível com OIDC (plugin SSO do Jellyfin, Grafana,
Portainer, ...) e proteger os UIs de administração da pilha DUMB (Sonarr, Radarr, Decypharr, ...)
com o mesmo login, via forward-auth no Traefik / Caddy / nginx.
"""
from __future__ import annotations

import base64
import hashlib
import time
from datetime import timedelta
from urllib.parse import urlencode, urlparse

import jwt
from fastapi import APIRouter, Depends, HTTPException, Request, Response
from fastapi.responses import JSONResponse, RedirectResponse
from sqlalchemy import update
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from ..db import get_db, utcnow
from ..deps import clear_session_cookie, host_allowed, load_session
from ..models import LoginSession, OIDCClient, OIDCCode, OIDCRefreshToken, User
from ..security import constant_time_eq, new_token, token_hash, verify_password
from ..services import oidc_keys
from ..services.audit import audit
from ..services.subscriptions import Access, compute_access

router = APIRouter(tags=["oidc"], include_in_schema=False)

SUPPORTED_SCOPES = ["openid", "profile", "email", "groups", "offline_access"]


# --------------------------------------------------------------------------- helpers
def _issuer() -> str:
    return get_settings().issuer


def _oauth_error(error: str, desc: str, status: int = 400, headers: dict | None = None) -> JSONResponse:
    return JSONResponse({"error": error, "error_description": desc}, status_code=status,
                        headers={"Cache-Control": "no-store", **(headers or {})})


def _redirect_with(uri: str, params: dict) -> RedirectResponse:
    sep = "&" if urlparse(uri).query else "?"
    return RedirectResponse(uri + sep + urlencode({k: v for k, v in params.items() if v is not None}), status_code=302)


def access_ok(requirement: str | None, user: User, access: Access) -> bool:
    if not requirement:
        return True
    if user.is_admin:
        return True
    if requirement == "admin":
        return False
    if requirement == "any_active":
        return access.any_active
    if requirement.startswith("feature:"):
        return requirement.split(":", 1)[1] in access.flags
    if requirement.startswith("group:"):
        return requirement.split(":", 1)[1] in access.groups(user)
    if requirement.startswith("plan:"):
        return any(s["plan_code"] == requirement.split(":", 1)[1] for s in access.sources)
    if requirement.startswith("product:"):
        return any(s.get("product_code") == requirement.split(":", 1)[1] for s in access.sources)
    return False


def user_claims(user: User, access: Access, scopes: set[str]) -> dict:
    claims: dict = {}
    if "profile" in scopes:
        claims.update({"preferred_username": user.username, "name": user.display_name or user.username,
                       "nickname": user.username, "locale": user.locale,
                       "updated_at": int(user.updated_at.timestamp()) if user.updated_at else None})
    if "email" in scopes:
        claims.update({"email": user.email, "email_verified": user.email_verified_at is not None})
    if "groups" in scopes:
        claims["groups"] = access.groups(user)
        claims["roles"] = claims["groups"]
    return {k: v for k, v in claims.items() if v is not None}


# --------------------------------------------------------------------------- discovery / jwks
@router.get("/.well-known/openid-configuration")
async def discovery():
    iss = _issuer()
    return {
        "issuer": iss,
        "authorization_endpoint": f"{iss}/oidc/authorize",
        "token_endpoint": f"{iss}/oidc/token",
        "userinfo_endpoint": f"{iss}/oidc/userinfo",
        "jwks_uri": f"{iss}/oidc/jwks.json",
        "end_session_endpoint": f"{iss}/oidc/logout",
        "revocation_endpoint": f"{iss}/oidc/revoke",
        "response_types_supported": ["code"],
        "response_modes_supported": ["query"],
        "grant_types_supported": ["authorization_code", "refresh_token"],
        "subject_types_supported": ["public"],
        "id_token_signing_alg_values_supported": ["RS256"],
        "scopes_supported": SUPPORTED_SCOPES,
        "token_endpoint_auth_methods_supported": ["client_secret_basic", "client_secret_post", "none"],
        "code_challenge_methods_supported": ["S256"],
        "claims_supported": ["sub", "iss", "aud", "exp", "iat", "auth_time", "nonce", "preferred_username", "name",
                             "nickname", "email", "email_verified", "groups", "roles", "locale"],
    }


@router.get("/oidc/jwks.json")
async def jwks(db: AsyncSession = Depends(get_db)):
    return JSONResponse(await oidc_keys.jwks(db), headers={"Cache-Control": "public, max-age=300"})


# --------------------------------------------------------------------------- authorize
@router.api_route("/oidc/authorize", methods=["GET", "POST"])
async def authorize(request: Request, db: AsyncSession = Depends(get_db)):
    s = get_settings()
    params = dict(request.query_params)
    if request.method == "POST":
        params.update({k: str(v) for k, v in (await request.form()).items()})
    client_id = params.get("client_id", "")
    redirect_uri = params.get("redirect_uri", "")
    client = await db.get(OIDCClient, client_id) if client_id else None
    if not s.oidc_enabled or client is None or not client.is_active:
        raise HTTPException(400, detail="Cliente OIDC desconhecido.")
    if redirect_uri not in (client.redirect_uris or []):
        raise HTTPException(400, detail="redirect_uri não registado para este cliente.")
    state = params.get("state")
    err = lambda e, d: _redirect_with(redirect_uri, {"error": e, "error_description": d, "state": state,
                                                     "iss": _issuer()})
    if params.get("response_type") != "code":
        return err("unsupported_response_type", "Apenas response_type=code é suportado.")
    scopes = set((params.get("scope") or "").split())
    if "openid" not in scopes:
        return err("invalid_scope", "O scope 'openid' é obrigatório.")
    scopes &= set(client.allowed_scopes or SUPPORTED_SCOPES) | {"openid"}
    challenge = params.get("code_challenge")
    method = params.get("code_challenge_method") or ("S256" if challenge else None)
    if (client.require_pkce or client.secret_hash is None) and not challenge:
        return err("invalid_request", "PKCE (code_challenge) obrigatório para este cliente.")
    if challenge and method != "S256":
        return err("invalid_request", "Apenas code_challenge_method=S256 é suportado.")
    if challenge and not (43 <= len(challenge) <= 128):
        return err("invalid_request", "code_challenge inválido.")
    if len(params.get("nonce") or "") > 255 or len(state or "") > 1024:
        return err("invalid_request", "nonce/state demasiado longo.")

    sess = await load_session(request, db)
    if sess is None or sess.mfa_pending or sess.scope:  # sessões do Jellyfin não servem para SSO
        if params.get("prompt") == "none":
            return err("login_required", "É necessário iniciar sessão.")
        here = f"{s.public_url}/oidc/authorize?{urlencode(params)}"
        return RedirectResponse(f"{s.public_url}/login?{urlencode({'next': here})}", status_code=302)
    user = await db.get(User, sess.user_id)
    if user is None or not user.is_active:
        return err("access_denied", "Conta indisponível.")
    if user.email_verified_at is None and not user.is_admin:
        # As apps (Seerr, LibreChat) ligam contas pelo email: um email por confirmar nunca sai do portal, senão
        # alguém podia registar-se com o email de outra pessoa e entrar na conta dela nessas apps.
        if params.get("prompt") == "none":
            return err("access_denied", "Email por confirmar.")
        return RedirectResponse(f"{s.public_url}/sem-acesso?{urlencode({'app': client.name, 'motivo': 'email'})}",
                                status_code=302)
    access = await compute_access(db, user)
    if not access_ok(client.required_access, user, access):
        audit(db, "oidc.denied", actor=user, target_type="oidc_client", target_id=client.client_id)
        await db.commit()
        if params.get("prompt") == "none":
            return err("access_denied", "Sem acesso a esta aplicação.")
        return RedirectResponse(f"{s.public_url}/sem-acesso?{urlencode({'app': client.name})}", status_code=302)

    code = new_token(32)
    db.add(OIDCCode(
        code_hash=token_hash(code), client_id=client.client_id, user_id=user.id, redirect_uri=redirect_uri,
        scope=" ".join(sorted(scopes)), nonce=params.get("nonce"), code_challenge=challenge,
        code_challenge_method=method, auth_time=sess.auth_time, session_id=sess.id,
        expires_at=utcnow() + timedelta(seconds=s.oidc_code_ttl),
    ))
    await db.commit()
    return _redirect_with(redirect_uri, {"code": code, "state": state, "iss": _issuer()})


# --------------------------------------------------------------------------- token
async def _authenticate_client(request: Request, db: AsyncSession, form: dict) -> OIDCClient | None:
    client_id = form.get("client_id")
    secret = form.get("client_secret")
    auth = request.headers.get("authorization", "")
    if auth.lower().startswith("basic "):
        try:
            from urllib.parse import unquote

            raw = base64.b64decode(auth[6:]).decode()
            cid, _, csec = raw.partition(":")
            client_id, secret = unquote(cid), unquote(csec)
        except Exception:  # noqa: BLE001
            return None
    if not client_id:
        return None
    client = await db.get(OIDCClient, client_id)
    if client is None or not client.is_active:
        return None
    if client.secret_hash is None:
        return client  # cliente público — PKCE obrigatório
    if not secret:
        return None
    ok, _ = verify_password(client.secret_hash, secret)
    return client if ok else None


async def _issue_tokens(db: AsyncSession, client: OIDCClient, user: User, scope: str, *, nonce: str | None,
                        auth_time, with_refresh: bool) -> dict:
    s = get_settings()
    access = await compute_access(db, user)
    scopes = set(scope.split())
    now = int(time.time())
    at_claims = {"iss": _issuer(), "sub": user.id, "aud": client.client_id, "client_id": client.client_id,
                 "iat": now, "exp": now + s.oidc_access_token_ttl, "scope": scope, "jti": oidc_keys.new_jti(),
                 "token_use": "access"}
    access_token = await oidc_keys.sign(db, at_claims)
    at_hash = base64.urlsafe_b64encode(hashlib.sha256(access_token.encode()).digest()[:16]).rstrip(b"=").decode()
    id_claims = {"iss": _issuer(), "sub": user.id, "aud": client.client_id, "iat": now,
                 "exp": now + s.oidc_id_token_ttl, "auth_time": int(auth_time.timestamp()), "at_hash": at_hash,
                 "azp": client.client_id, **user_claims(user, access, scopes)}
    if nonce:
        id_claims["nonce"] = nonce
    out = {"access_token": access_token, "token_type": "Bearer", "expires_in": s.oidc_access_token_ttl,
           "id_token": await oidc_keys.sign(db, id_claims), "scope": scope}
    if with_refresh:
        rt = new_token(40)
        db.add(OIDCRefreshToken(token_hash=token_hash(rt), client_id=client.client_id, user_id=user.id, scope=scope,
                                expires_at=utcnow() + timedelta(days=s.oidc_refresh_token_ttl_days)))
        out["refresh_token"] = rt
    return out


def _pkce_ok(verifier: str | None, challenge: str | None) -> bool:
    if not challenge:
        return True
    if not verifier or not (43 <= len(verifier) <= 128):
        return False
    digest = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
    return constant_time_eq(digest, challenge)


@router.post("/oidc/token")
async def token(request: Request, db: AsyncSession = Depends(get_db)):
    form = {k: str(v) for k, v in (await request.form()).items()}
    client = await _authenticate_client(request, db, form)
    if client is None:
        return _oauth_error("invalid_client", "Autenticação do cliente falhou.", 401,
                            {"WWW-Authenticate": 'Basic realm="oidc"'})
    grant = form.get("grant_type")

    if grant == "authorization_code":
        code = await db.get(OIDCCode, token_hash(form.get("code", "")))
        if code is None or code.client_id != client.client_id or code.expires_at <= utcnow():
            return _oauth_error("invalid_grant", "Código inválido ou expirado.")
        if code.redirect_uri != form.get("redirect_uri"):
            return _oauth_error("invalid_grant", "redirect_uri não corresponde.")
        if client.secret_hash is None and not code.code_challenge:
            return _oauth_error("invalid_grant", "PKCE obrigatório.")
        if not _pkce_ok(form.get("code_verifier"), code.code_challenge):
            return _oauth_error("invalid_grant", "code_verifier inválido.")
        res = await db.execute(update(OIDCCode).where(OIDCCode.code_hash == code.code_hash, OIDCCode.used_at.is_(None))
                               .values(used_at=utcnow()))
        if not res.rowcount:
            # Reutilização de código: revoga tokens emitidos a partir dele (RFC 6749 §4.1.2)
            await db.execute(update(OIDCRefreshToken).where(OIDCRefreshToken.user_id == code.user_id,
                                                            OIDCRefreshToken.client_id == client.client_id)
                             .values(revoked_at=utcnow()))
            await db.commit()
            return _oauth_error("invalid_grant", "Código já utilizado.")
        user = await db.get(User, code.user_id)
        if user is None or not user.is_active:
            return _oauth_error("invalid_grant", "Conta indisponível.")
        scopes = set(code.scope.split())
        with_refresh = client.secret_hash is not None or "offline_access" in scopes
        out = await _issue_tokens(db, client, user, code.scope, nonce=code.nonce, auth_time=code.auth_time,
                                  with_refresh=with_refresh)
        audit(db, "oidc.token", actor=user, target_type="oidc_client", target_id=client.client_id)
        await db.commit()
        return JSONResponse(out, headers={"Cache-Control": "no-store", "Pragma": "no-cache"})

    if grant == "refresh_token":
        rt = await db.get(OIDCRefreshToken, token_hash(form.get("refresh_token", "")))
        if rt is None or rt.client_id != client.client_id or rt.revoked_at or rt.expires_at <= utcnow():
            return _oauth_error("invalid_grant", "Refresh token inválido.")
        res = await db.execute(update(OIDCRefreshToken).where(OIDCRefreshToken.token_hash == rt.token_hash,
                                                              OIDCRefreshToken.revoked_at.is_(None))
                               .values(revoked_at=utcnow()))
        if not res.rowcount:
            return _oauth_error("invalid_grant", "Refresh token inválido.")
        user = await db.get(User, rt.user_id)
        if user is None or not user.is_active:
            await db.commit()
            return _oauth_error("invalid_grant", "Conta indisponível.")
        access = await compute_access(db, user)
        if not access_ok(client.required_access, user, access):
            await db.commit()
            return _oauth_error("invalid_grant", "Sem acesso a esta aplicação.")
        scope = rt.scope
        if form.get("scope"):
            requested = set(form["scope"].split())
            if not requested <= set(scope.split()):
                return _oauth_error("invalid_scope", "Scope superior ao original.")
            scope = " ".join(sorted(requested))
        out = await _issue_tokens(db, client, user, scope, nonce=None, auth_time=rt.created_at, with_refresh=True)
        await db.commit()
        return JSONResponse(out, headers={"Cache-Control": "no-store", "Pragma": "no-cache"})

    return _oauth_error("unsupported_grant_type", "grant_type não suportado.")


# --------------------------------------------------------------------------- userinfo / revoke / logout
@router.api_route("/oidc/userinfo", methods=["GET", "POST"])
async def userinfo(request: Request, db: AsyncSession = Depends(get_db)):
    auth = request.headers.get("authorization", "")
    if not auth.lower().startswith("bearer "):
        return _oauth_error("invalid_token", "Token em falta.", 401, {"WWW-Authenticate": "Bearer"})
    try:
        claims = await oidc_keys.verify(db, auth[7:].strip())
    except jwt.PyJWTError:
        return _oauth_error("invalid_token", "Token inválido.", 401, {"WWW-Authenticate": 'Bearer error="invalid_token"'})
    if claims.get("token_use") != "access":
        return _oauth_error("invalid_token", "Não é um access token.", 401)
    user = await db.get(User, claims["sub"])
    if user is None or not user.is_active:
        return _oauth_error("invalid_token", "Conta indisponível.", 401)
    access = await compute_access(db, user)
    client = await db.get(OIDCClient, claims.get("client_id") or "")
    if client is None or not client.is_active or not access_ok(client.required_access, user, access):
        # A subscrição acabou depois de o token ser emitido: a app deixa de receber os dados do cliente.
        return _oauth_error("invalid_token", "Sem acesso a esta aplicação.", 401,
                            {"WWW-Authenticate": 'Bearer error="invalid_token"'})
    return {"sub": user.id, **user_claims(user, access, set(claims.get("scope", "").split()))}


@router.post("/oidc/revoke")
async def revoke(request: Request, db: AsyncSession = Depends(get_db)):
    form = {k: str(v) for k, v in (await request.form()).items()}
    client = await _authenticate_client(request, db, form)
    if client is None:
        return _oauth_error("invalid_client", "Autenticação do cliente falhou.", 401)
    rt = await db.get(OIDCRefreshToken, token_hash(form.get("token", "")))
    if rt and rt.client_id == client.client_id:
        rt.revoked_at = utcnow()
        await db.commit()
    return Response(status_code=200)


@router.api_route("/oidc/logout", methods=["GET", "POST"])
async def end_session(request: Request, db: AsyncSession = Depends(get_db)):
    s = get_settings()
    params = dict(request.query_params)
    if request.method == "POST":
        params.update({k: str(v) for k, v in (await request.form()).items()})
    target = f"{s.public_url}/login?saiu=1"
    post_logout = params.get("post_logout_redirect_uri")
    client_id = params.get("client_id")
    if not client_id and params.get("id_token_hint"):
        try:
            # Um id_token expirado continua a ser uma dica válida (a assinatura é que tem de bater certo).
            hint = await oidc_keys.verify(db, params["id_token_hint"], verify_exp=False)
            client_id = hint.get("aud") if isinstance(hint.get("aud"), str) else None
        except Exception:  # noqa: BLE001
            client_id = None
    if post_logout and client_id:
        client = await db.get(OIDCClient, client_id)
        if client and post_logout in (client.post_logout_redirect_uris or []):
            sep = "&" if urlparse(post_logout).query else "?"
            target = post_logout + (sep + urlencode({"state": params["state"]}) if params.get("state") else "")
    sess = await load_session(request, db)
    if sess:
        sess.revoked_at = utcnow()
        await db.commit()
    resp = RedirectResponse(target, status_code=302)
    clear_session_cookie(resp, request)
    return resp


# --------------------------------------------------------------------------- forward-auth
def _original_url(request: Request) -> str | None:
    h = request.headers
    if h.get("x-original-url"):
        return h["x-original-url"]
    host = h.get("x-forwarded-host")
    if not host:
        return None
    proto = h.get("x-forwarded-proto", "https")
    uri = h.get("x-forwarded-uri", "/")
    return f"{proto}://{host}{uri}"


@router.get("/auth/verify")
async def forward_auth(request: Request, require: str = "admin", mode: str = "redirect",
                       db: AsyncSession = Depends(get_db)):
    """Endpoint de forward-auth.

    - Traefik `forwardAuth` / Caddy `forward_auth`: devolve 302 para o login quando não há sessão.
    - nginx `auth_request`: usa `?mode=status` (401/403 simples; o nginx trata do redirect).
    - `?require=admin | any_active | feature:jellyfin | group:<nome> | plan:<código>`
    """
    s = get_settings()
    sess: LoginSession | None = await load_session(request, db)
    user = await db.get(User, sess.user_id) if sess and not sess.mfa_pending and not sess.scope else None
    if user is None or not user.is_active:
        if mode == "status":
            return Response(status_code=401)
        original = _original_url(request)
        nxt = original if original and host_allowed(urlparse(original).hostname) else None
        url = f"{s.public_url}/login" + (f"?{urlencode({'next': nxt})}" if nxt else "")
        return RedirectResponse(url, status_code=302)
    access = await compute_access(db, user)
    if not access_ok(require, user, access):
        return Response("Sem acesso.", status_code=403)
    groups = access.groups(user)
    return Response(status_code=200, headers={
        "Remote-User": user.username,
        "Remote-Name": user.display_name or user.username,
        "Remote-Email": user.email,
        "Remote-Groups": ",".join(groups),
        "X-Auth-Request-User": user.username,
        "X-Auth-Request-Email": user.email,
        "X-Auth-Request-Groups": ",".join(groups),
        "Cache-Control": "no-store",
    })
