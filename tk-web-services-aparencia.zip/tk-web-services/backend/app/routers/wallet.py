"""API da carteira de créditos: saldo, movimentos, carregamento único e carregamento mensal.

Sem emails de confirmação: o cliente vê o resultado logo na página (e no extrato da carteira).
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from ..db import get_db
from ..deps import rate_limit, require_user, require_verified
from ..models import USABLE_PM_STATUSES, PaymentMethod, User
from ..payments.base import ProviderError
from ..schemas import MonthlyTopupIn, Ok, TopupIn, WalletTxOut
from ..services import billing
from ..services import wallet as wallet_svc
from ..services.billing import BillingError
from ..services.jobs import RetryLater
from ..services.subscriptions import fmt_date, fmt_money
from .billing import _err

router = APIRouter(prefix="/api/wallet", tags=["wallet"])

ERRORS = (BillingError, ProviderError, RetryLater, wallet_svc.WalletError)


def tx_out(tx) -> WalletTxOut:
    return WalletTxOut(id=tx.id, kind=tx.kind, amount_cents=tx.amount_cents,
                       balance_after_cents=tx.balance_after_cents, description=tx.description,
                       created_at=tx.created_at)


@router.get("")
async def my_wallet(user: User = Depends(require_user), db: AsyncSession = Depends(get_db)):
    out = await wallet_svc.summary(db, user)
    out["transactions"] = [tx_out(t).model_dump() for t in await wallet_svc.transactions(db, user.id, limit=30)]
    await db.commit()
    return out


@router.get("/transactions", response_model=list[WalletTxOut])
async def my_transactions(before: int | None = None, user: User = Depends(require_user),
                          db: AsyncSession = Depends(get_db)):
    return [tx_out(t) for t in await wallet_svc.transactions(db, user.id, limit=50, before_id=before)]


async def _method(db: AsyncSession, user: User, pm_id: str | None) -> PaymentMethod | None:
    if not pm_id:
        return await billing.default_method(db, user.id)
    pm = await db.get(PaymentMethod, pm_id)
    if pm is None or pm.user_id != user.id or pm.status not in USABLE_PM_STATUSES:
        raise HTTPException(400, detail="Método de pagamento inválido.")
    return pm


@router.post("/topup")
async def topup(body: TopupIn, user: User = Depends(require_verified), db: AsyncSession = Depends(get_db)):
    """Carregamento único (mínimo 5 €). Com um método guardado é cobrado já; senão abre a página do fornecedor."""
    rate_limit(f"topup:{user.id}", 10, 3600)
    try:
        method = None if body.provider else await _method(db, user, body.payment_method_id)
        if method is None and not body.provider:
            raise BillingError("Escolhe como queres pagar o carregamento.")
        inv = await wallet_svc.create_topup_invoice(db, user, body.amount_cents)
        await db.commit()  # a cobrança fica gravada antes de falar com o fornecedor
        if body.provider:
            res = await billing.start_invoice_payment(db, user, inv, body.provider)
            return {"status": "redirect", **res}
        status = await billing.charge_or_defer(db, inv, method=method, notify=False)
        await db.commit()
    except ERRORS as exc:
        await db.rollback()
        raise _err(exc) from exc
    msgs = {
        "paid": f"Carregados {fmt_money(body.amount_cents)} na tua carteira.",
        "processing": f"Carregamento de {fmt_money(body.amount_cents)} submetido — o saldo entra quando o banco "
                      "confirmar (débito direto: alguns dias úteis).",
        "deferred": "Estamos a processar o carregamento — o saldo entra assim que for confirmado.",
        "failed": f"O carregamento foi recusado: {inv.last_error or 'tenta outro método'}",
        "void": f"O carregamento foi recusado: {inv.last_error or 'tenta outro método'}",
    }
    if status in ("failed", "void"):
        raise HTTPException(400, detail=msgs[status])
    return {"status": status, "message": msgs.get(status, status),
            "balance_cents": await wallet_svc.balance(db, user.id)}


@router.put("/monthly")
async def set_monthly(body: MonthlyTopupIn, user: User = Depends(require_verified), db: AsyncSession = Depends(get_db)):
    """Liga, altera ou desliga o carregamento mensal (sem confirmações: aplica-se no próximo dia de faturação)."""
    rate_limit(f"monthly:{user.id}", 20, 3600)
    amount = body.amount_cents or 0
    if amount > 0 and not wallet_svc.monthly_enabled():
        raise HTTPException(400, detail="O carregamento mensal não está disponível — os serviços são cobrados pelo "
                                        "teu método de pagamento autorizado.")
    try:
        if amount > 0 and not await billing.usable_methods(db, user.id):
            if not body.provider:
                raise BillingError("Adiciona um método de pagamento para o carregamento mensal.")
            res = await billing.start_method_setup(db, user, body.provider, intent={
                "action": "monthly_topup", "amount_cents": amount, "skip_when_covered": body.skip_when_covered})
            return {"status": "redirect", **res}
        w = await wallet_svc.set_monthly(db, user, amount or None, skip_when_covered=body.skip_when_covered)
        await db.commit()
    except ERRORS as exc:
        await db.rollback()
        raise _err(exc) from exc
    if not w.monthly_topup_cents:
        return {"status": "ok", "message": "Carregamento mensal desligado."}
    when = fmt_date(user.next_billing_at)
    return {"status": "ok", "message": f"Carregamento mensal de {fmt_money(w.monthly_topup_cents)} ativo — "
                                       f"próximo a {when}. Paga os teus serviços e o resto fica na carteira."}


@router.delete("/monthly", response_model=Ok)
async def disable_monthly(user: User = Depends(require_user), db: AsyncSession = Depends(get_db)):
    await wallet_svc.set_monthly(db, user, None)
    await db.commit()
    return Ok(message="Carregamento mensal desligado.")
