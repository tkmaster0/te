"""Aparência do site por web: imagens (/media/<chave>), textos e emails — Admin → Aparência."""
from __future__ import annotations

import re

from fastapi import APIRouter, Depends, File, HTTPException, Request, UploadFile
from fastapi.responses import Response
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from ..db import get_db
from ..deps import require_admin
from ..models import Product, SiteAsset, SiteSetting, User
from ..schemas import Ok
from ..services import site_content
from ..services.audit import audit
from ..services.mailer import TEMPLATES, render

router = APIRouter(tags=["site"])
admin_router = APIRouter(prefix="/api/admin/appearance", tags=["admin"], dependencies=[Depends(require_admin)])


# ------------------------------------------------------------------------------------------------- público
@router.get("/media/{key}", include_in_schema=False)
async def media(key: str, request: Request, v: str | None = None, db: AsyncSession = Depends(get_db)):
    if not site_content.valid_key(key):
        raise HTTPException(404)
    row = await db.get(SiteAsset, key)
    if row is None:
        raise HTTPException(404)
    etag = f'"{row.etag}"'
    # Com a versão certa no URL (?v=) a imagem pode ficar em cache "para sempre": um ficheiro novo muda o URL.
    cache = "public, max-age=31536000, immutable" if v and row.etag.startswith(v) else "public, max-age=300"
    headers = {"ETag": etag, "Cache-Control": cache, "X-Content-Type-Options": "nosniff"}
    if row.content_type == "image/svg+xml":
        # Um SVG aberto diretamente nunca corre scripts (dentro de <img> já não corria).
        headers["Content-Security-Policy"] = "default-src 'none'; style-src 'unsafe-inline'; img-src data:; sandbox"
    if request.headers.get("if-none-match") == etag:
        return Response(status_code=304, headers=headers)
    return Response(row.data, media_type=row.content_type, headers=headers)


# --------------------------------------------------------------------------------------------------- admin
_VAR_RE = re.compile(r"\{\{\s*([a-z_][a-z0-9_]*)|\{%\s*if\s+([a-z_][a-z0-9_]*)")
SAMPLES = {
    "username": "maria", "code": "482913", "plan": "Plano Base", "product": "Serviço", "amount": "9,99 €",
    "old_price": "7,99 €", "new_price": "9,99 €", "effective": "01/11/2026", "interval": "mês", "date": "05/11/2026",
    "inviter": "joao", "subject": "Assunto de teste", "message": "Mensagem de teste.", "when": "08/10/2026 10:00 UTC",
    "note": "Obrigado por estares connosco.", "reason": "fundos insuficientes",
}


def _variables(template: str) -> list[str]:
    found: list[str] = []
    for part in TEMPLATES[template]:
        for a, b in _VAR_RE.findall(part or ""):
            name = a or b
            if name not in found and name not in ("app_name", "portal_url"):
                found.append(name)
    return found


async def _setting(db: AsyncSession, key: str) -> dict:
    row = await db.get(SiteSetting, key)
    return row.value if row and isinstance(row.value, dict) else {}


async def _save(db: AsyncSession, key: str, value: dict) -> None:
    row = await db.get(SiteSetting, key)
    if row is None:
        db.add(SiteSetting(key=key, value=value))
    else:
        row.value = value


@admin_router.get("")
async def appearance(db: AsyncSession = Depends(get_db)):
    imgs = {r.key: r for r in [await db.get(SiteAsset, k) for k in site_content.IMAGE_SLOTS] if r is not None}
    emails = await _setting(db, "emails")
    return {
        "images": [{"key": k, **meta, "url": site_content.url_for(imgs[k]) if k in imgs else None,
                    "size": imgs[k].size if k in imgs else None,
                    "content_type": imgs[k].content_type if k in imgs else None}
                   for k, meta in site_content.IMAGE_SLOTS.items()],
        "texts": await _setting(db, "texts"),
        "emails": [{"id": tpl, "defaults": dict(zip(site_content.EMAIL_FIELDS, parts, strict=True)),
                    "override": emails.get(tpl) or {}, "variables": _variables(tpl)}
                   for tpl, parts in TEMPLATES.items()],
        "max_image_bytes": site_content.MAX_IMAGE_BYTES,
    }


class TextsIn(BaseModel):
    texts: dict


@admin_router.put("/texts", response_model=Ok)
async def put_texts(body: TextsIn, admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    try:
        texts = site_content.clean_texts(body.texts)
    except site_content.ContentError as exc:
        raise HTTPException(400, detail=str(exc)) from exc
    await _save(db, "texts", texts)
    audit(db, "admin.texts_updated", actor=admin, count=len(texts))
    await db.commit()
    return Ok(message=f"{len(texts)} texto(s) personalizado(s).")


class EmailsIn(BaseModel):
    emails: dict


@admin_router.put("/emails", response_model=Ok)
async def put_emails(body: EmailsIn, admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    try:
        emails = site_content.clean_emails(body.emails)
    except site_content.ContentError as exc:
        raise HTTPException(400, detail=str(exc)) from exc
    await _save(db, "emails", emails)
    audit(db, "admin.emails_updated", actor=admin, templates=sorted(emails))
    await db.commit()
    return Ok(message="Emails guardados.")


class EmailPreviewIn(BaseModel):
    subject: str | None = None
    title: str | None = None
    body: str | None = None
    cta: str | None = None


@admin_router.post("/emails/{template}/preview")
async def preview_email(template: str, body: EmailPreviewIn, db: AsyncSession = Depends(get_db)):
    if template not in TEMPLATES:
        raise HTTPException(404)
    fields = {k: v for k, v in body.model_dump().items() if v}
    try:
        overrides = site_content.clean_emails({template: fields}) if fields else {}
    except site_content.ContentError as exc:
        raise HTTPException(400, detail=str(exc)) from exc
    s = get_settings()
    ctx = {v: SAMPLES.get(v, f"[{v}]") for v in _variables(template)}
    ctx["cta_url"] = f"{s.public_url.rstrip('/')}/app"
    logo = (await site_content.images(db)).get("logo")
    subject, html, text = render(template, ctx, overrides, s.public_url.rstrip("/") + logo if logo else None)
    return {"subject": subject, "html": html, "text": text}


async def _upload(file: UploadFile) -> bytes:
    data = await file.read(site_content.MAX_IMAGE_BYTES + 1)
    if len(data) > site_content.MAX_IMAGE_BYTES:
        raise HTTPException(413, detail="A imagem tem mais de 2 MB.")
    return data


@admin_router.put("/images/{key}")
async def put_image(key: str, file: UploadFile = File(...), admin: User = Depends(require_admin),
                    db: AsyncSession = Depends(get_db)):
    if key not in site_content.IMAGE_SLOTS:
        raise HTTPException(404, detail="Imagem desconhecida.")
    try:
        row = await site_content.put_image(db, key, await _upload(file))
    except site_content.ContentError as exc:
        raise HTTPException(400, detail=str(exc)) from exc
    audit(db, "admin.image_updated", actor=admin, key=key, size=row.size)
    await db.commit()
    return {"key": key, "url": site_content.url_for(row)}


@admin_router.delete("/images/{key}", response_model=Ok)
async def delete_image(key: str, admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    if key not in site_content.IMAGE_SLOTS:
        raise HTTPException(404, detail="Imagem desconhecida.")
    await site_content.delete_image(db, key)
    audit(db, "admin.image_removed", actor=admin, key=key)
    await db.commit()
    return Ok(message="Imagem removida — volta a usar a original.")


@admin_router.put("/products/{product_id}/image")
async def put_product_image(product_id: int, file: UploadFile = File(...), admin: User = Depends(require_admin),
                            db: AsyncSession = Depends(get_db)):
    p = await db.get(Product, product_id)
    if p is None:
        raise HTTPException(404, detail="Produto não encontrado.")
    try:
        row = await site_content.put_image(db, f"product-{p.id}", await _upload(file))
    except site_content.ContentError as exc:
        raise HTTPException(400, detail=str(exc)) from exc
    p.image_url = site_content.url_for(row)
    audit(db, "admin.product_image_updated", actor=admin, target_type="product", target_id=str(p.id))
    await db.commit()
    return {"image_url": p.image_url}


@admin_router.delete("/products/{product_id}/image", response_model=Ok)
async def delete_product_image(product_id: int, admin: User = Depends(require_admin),
                               db: AsyncSession = Depends(get_db)):
    p = await db.get(Product, product_id)
    if p is None:
        raise HTTPException(404, detail="Produto não encontrado.")
    await site_content.delete_image(db, f"product-{p.id}")
    p.image_url = None
    audit(db, "admin.product_image_removed", actor=admin, target_type="product", target_id=str(p.id))
    await db.commit()
    return Ok(message="Imagem removida — o produto volta a usar o ícone.")
