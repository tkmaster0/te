"""Comandos de administração.

    python -m app.cli create-admin --email eu@exemplo.pt --username tkmaster
    python -m app.cli import-legacy --sqlite /caminho/para/instance/users.db [--dry-run]
    python -m app.cli sync-gocardless
    python -m app.cli oidc-client --id jellyfin --name Jellyfin --redirect https://tkflix.eu/sso/OID/redirect/tkflix \
        --require feature:jellyfin
    python -m app.cli forward-auth-hint
    python -m app.cli drain            # executa já todos os jobs pendentes
    python -m app.cli reconcile-all
    python -m app.cli check-links      # testa as ligações ao Jellyfin/Seerr/Bazarr/Dispatcharr/pagamentos
"""
from __future__ import annotations

import argparse
import asyncio
import getpass
import secrets
import sys

from sqlalchemy import select

from .db import sessionmaker, utcnow
from .models import OIDCClient, User
from .security import hash_password, password_problems
from .seed import seed_defaults
from .services import tasks  # noqa: F401
from .services.jobs import drain, enqueue


async def create_admin(args) -> None:
    password = args.password or getpass.getpass("Password: ")
    if (p := password_problems(password, username=args.username)):
        sys.exit(" ".join(p))
    async with sessionmaker()() as db:
        user = await db.scalar(select(User).where((User.email == args.email.lower()) |
                                                  (User.username == args.username.lower())))
        if user:
            user.is_admin = True
            user.password_hash = hash_password(password)
            print(f"Utilizador existente {user.username} promovido a admin (password atualizada).")
        else:
            user = User(email=args.email.lower(), username=args.username.lower(), password_hash=hash_password(password),
                        is_admin=True, email_verified_at=utcnow(), password_changed_at=utcnow(),
                        billing_mode="legacy", jellyfin_password_login=True)
            db.add(user)
            print(f"Admin {args.username} criado.")
        await db.commit()




async def import_legacy(args) -> None:
    """Importa utilizadores do site antigo (Flask/SQLite). Idempotente: pode correr várias vezes.
    O mesmo está em Admin → Migração (upload do users.db), sem linha de comandos."""
    from .services.legacy_import import ImportError_, import_sqlite

    async with sessionmaker()() as db:
        try:
            r = await import_sqlite(db, args.sqlite, dry_run=args.dry_run, admin_username=args.admin_username,
                                    fallback_plan=args.fallback_plan, link_gocardless=not args.skip_gocardless,
                                    keep_gocardless=not getattr(args, "convert_now", False))
        except ImportError_ as exc:
            sys.exit(str(exc))
    print(f"{r['total']} utilizadores no site antigo: {r['new']} novos, {r['existing']} já existiam, "
          f"{r['skipped']} ignorados · Jellyfin {r['jellyfin']} · IPTV {r['iptv']} · convites {r['referrals']} · "
          f"ofertas {r['grants']}")
    if r["dry_run"]:
        print("Dry-run: nada foi gravado.")
    for w in r["warnings"]:
        print(f"  ! {w}")
    for x in r["subscriptions"]:
        print(f"  · {x.get('user', '?')}: {x.get('result')} {x.get('plan', '')} "
              f"{('próxima cobrança ' + x['paid_until'][:10]) if x.get('paid_until') else ''}")


async def sync_gocardless(args) -> None:
    """Migra as subscrições GoCardless antigas para a faturação consolidada (mandatos reaproveitados)."""
    from .services import legacy

    async with sessionmaker()() as db:
        results = await legacy.migrate_all(db, dry_run=args.dry_run, keep=not getattr(args, "convert_now", False))
    for r in results:
        print(f"  · {r.get('user', '?')} [{r.get('gc_subscription', '')}]: {r.get('result')} {r.get('plan', '')} "
              f"{('pago até ' + r['paid_until'][:10]) if r.get('paid_until') else ''}")
    ok = sum(1 for r in results if str(r.get("result", "")).startswith(("migrada", "seria", "ligada", "convertida")))
    print(f"{'(simulação) ' if args.dry_run else ''}{ok} subscrições tratadas.")


async def import_stripe(args) -> None:
    """Passa as subscrições Stripe antigas (ex.: TKGPT) para a faturação do portal, sem ação dos clientes."""
    from .services import legacy_stripe

    async with sessionmaker()() as db:
        results = await legacy_stripe.migrate_all(db, dry_run=args.dry_run, create_users=not args.no_create_users)
    for r in results:
        print(f"  · {r.get('email', '?')} [{r.get('stripe_subscription', '')}]: {r.get('result')} "
              f"{r.get('plan', '')} {('pago até ' + r['paid_until'][:10]) if r.get('paid_until') else ''}")


async def wallet_convert(args) -> None:
    """Passa clientes antigos para os créditos mensais (mesmo valor, mesmo dia, mesmo método — sem ação deles)."""
    from .services import wallet as wallet_svc

    async with sessionmaker()() as db:
        q = select(User).where(User.billing_mode == "legacy")
        if args.user:
            q = select(User).where((User.username == args.user.lower()) | (User.email == args.user.lower()))
        n = 0
        for u in (await db.scalars(q)).all():
            r = await wallet_svc.convert_to_monthly(db, u, dry_run=args.dry_run)
            print(f"  · {u.username}: {r['result']} {('→ ' + str(r['monthly_cents'] / 100) + ' €/mês') if r.get('monthly_cents') else ''}")
            n += r["result"] in ("convertido", "seria convertido")
        if args.dry_run:
            await db.rollback()
        else:
            await db.commit()
    print(f"{'(simulação) ' if args.dry_run else ''}{n} clientes {'seriam convertidos' if args.dry_run else 'convertidos'}.")


async def oidc_presets(args) -> None:
    """Cria (ou atualiza) os clientes OIDC do Jellyfin, Seerr e LibreChat e mostra os segredos novos."""
    from .services import oidc_presets as presets

    async with sessionmaker()() as db:
        out = await presets.ensure_presets(db, rotate=args.rotate)
        await db.commit()
    for c in out:
        print(f"· {c['client_id']}: {c['status']}  redirect={', '.join(c['redirect_uris'])}  acesso={c['required_access']}")
        if c.get("client_secret"):
            print(f"    client_secret: {c['client_secret']}   (guarda já — não volta a ser mostrado)")


async def oidc_client(args) -> None:
    async with sessionmaker()() as db:
        c = await db.get(OIDCClient, args.id)
        secret = None if args.public else secrets.token_urlsafe(36)
        if c is None:
            c = OIDCClient(client_id=args.id, name=args.name or args.id)
            db.add(c)
        c.redirect_uris = args.redirect
        c.post_logout_redirect_uris = args.post_logout or []
        c.required_access = args.require
        c.secret_hash = hash_password(secret) if secret else None
        c.require_pkce = bool(args.public)
        c.token_endpoint_auth_method = "none" if args.public else "client_secret_basic"
        await db.commit()
    print(f"client_id: {args.id}")
    if secret:
        print(f"client_secret: {secret}   (guarda já — não volta a ser mostrado)")


async def run_drain(args) -> None:
    n = await drain()
    print(f"{n} jobs executados.")


async def reconcile_all(args) -> None:
    async with sessionmaker()() as db:
        await enqueue(db, "reconcile_all", {}, dedupe_key="reconcile_all")
        await db.commit()
    print("Agendado. O worker trata do resto (ou corre `python -m app.cli drain`).")


async def check_links(args) -> None:
    """Testa a ligação do portal a cada integração (Jellyfin, Seerr, Bazarr, Dispatcharr, pagamentos…)."""
    from .services import health

    bad = 0
    for r in await health.integrations():
        if not r["configured"]:
            if args.all:
                print(f"  -   {r['name']}: não configurado")
            continue
        if r["ok"]:
            info = ", ".join(f"{k}={v}" for k, v in (r.get("info") or {}).items() if v not in (None, ""))
            print(f"  OK  {r['name']}" + (f" ({info})" if info else ""))
        else:
            bad += 1
            print(f"  !!  {r['name']}: {r['error']}")
    if bad:
        sys.exit(f"{bad} ligação(ões) com problemas.")


async def seed(args) -> None:
    async with sessionmaker()() as db:
        print("Criado." if await seed_defaults(db) else "Já existiam produtos — nada a fazer.")


def main() -> None:
    p = argparse.ArgumentParser(prog="tkportal")
    sub = p.add_subparsers(dest="cmd", required=True)

    a = sub.add_parser("create-admin")
    a.add_argument("--email", required=True)
    a.add_argument("--username", required=True)
    a.add_argument("--password")
    a.set_defaults(fn=create_admin)

    li = sub.add_parser("import-legacy")
    li.add_argument("--sqlite", required=True)
    li.add_argument("--admin-username", default="tkmaster")
    li.add_argument("--fallback-plan", default="tkflix-mensal")
    li.add_argument("--dry-run", action="store_true")
    li.add_argument("--skip-gocardless", action="store_true")
    li.add_argument("--convert-now", action="store_true",
                    help="passa já as subscrições GoCardless para o portal (por omissão ficam na GoCardless e passam "
                         "sozinhas na primeira alteração do cliente)")
    li.set_defaults(fn=import_legacy)

    sg = sub.add_parser("sync-gocardless", help="liga as subscrições GoCardless antigas ao portal")
    sg.add_argument("--dry-run", action="store_true")
    sg.add_argument("--convert-now", action="store_true", help="passa já para a faturação do portal")
    sg.set_defaults(fn=sync_gocardless)

    ist = sub.add_parser("import-stripe", help="migra subscrições Stripe antigas (ex.: TKGPT) para o portal")
    ist.add_argument("--dry-run", action="store_true")
    ist.add_argument("--no-create-users", action="store_true",
                     help="não criar contas no portal para clientes Stripe sem conta (só liga as existentes)")
    ist.set_defaults(fn=import_stripe)

    wc = sub.add_parser("wallet-convert", help="passa clientes antigos para os créditos mensais (sem ação deles)")
    wc.add_argument("--dry-run", action="store_true")
    wc.add_argument("--user", help="só este cliente (username ou email)")
    wc.set_defaults(fn=wallet_convert)

    op_ = sub.add_parser("oidc-presets", help="cria os clientes OIDC do Jellyfin, Seerr e LibreChat")
    op_.add_argument("--rotate", action="store_true", help="gera segredos novos para os clientes que já existem")
    op_.set_defaults(fn=oidc_presets)

    oc = sub.add_parser("oidc-client")
    oc.add_argument("--id", required=True)
    oc.add_argument("--name")
    oc.add_argument("--redirect", action="append", required=True)
    oc.add_argument("--post-logout", action="append")
    oc.add_argument("--require", help="admin | any_active | feature:jellyfin | group:x | plan:código")
    oc.add_argument("--public", action="store_true")
    oc.set_defaults(fn=oidc_client)

    sub.add_parser("drain").set_defaults(fn=run_drain)
    sub.add_parser("reconcile-all").set_defaults(fn=reconcile_all)
    sub.add_parser("seed").set_defaults(fn=seed)
    cl = sub.add_parser("check-links", help="testa as ligações às integrações (TKFLIX, pagamentos, email…)")
    cl.add_argument("--all", action="store_true", help="mostra também as que não estão configuradas")
    cl.set_defaults(fn=check_links)

    args = p.parse_args()
    asyncio.run(args.fn(args))


if __name__ == "__main__":
    main()
