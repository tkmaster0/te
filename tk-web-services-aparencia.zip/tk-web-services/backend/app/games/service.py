"""Jogos com créditos: regras de jogo responsável, sementes verificáveis e movimentos na carteira.

  * Só com os créditos da carteira; os ganhos ficam na carteira (pagam serviços, não se levantam).
  * Aposta mínima de 1 € por jogada (fichas da roleta desde 0,20 €), máximo configurável.
  * Maioridade confirmada, limite diário de perdas (do sistema e, opcionalmente, mais baixo escolhido pelo cliente)
    e autoexclusão temporária.
  * Cada aposta é debitada antes de sortear e cada prémio creditado na mesma transação (bloqueio na carteira).
"""
from __future__ import annotations

from datetime import datetime, timedelta

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from ..db import is_postgres, utcnow
from ..models import GameRound, GameSeed, User, WalletTransaction
from ..security import decrypt, encrypt
from ..services import wallet as wallet_svc
from ..services.audit import audit
from ..services.subscriptions import fmt_money
from . import blackjack as bj
from . import fair, roulette


class GameError(Exception):
    pass


class GamesHidden(GameError):
    """Jogos indisponíveis para este cliente (não tem o produto exigido desbloqueado) — responde-se 404."""


def games_available(user: User | None) -> bool:
    """Os jogos só aparecem a quem tem o TKFLIX desbloqueado (registo com convite TKFLIX ou código na Loja)."""
    s = get_settings()
    if user is None or not (s.games_enabled and s.wallet_enabled):
        return False
    need = (s.games_require_product or "").strip()
    return not need or user.is_admin or need in (user.unlocked_products or [])


# =========================================================================== regras
def _day_start(now: datetime) -> datetime:
    return now.replace(hour=0, minute=0, second=0, microsecond=0)


async def net_today(db: AsyncSession, user_id: str) -> int:
    """Resultado líquido de hoje nos jogos (negativo = perdeu)."""
    now = utcnow()
    return int(await db.scalar(select(func.coalesce(func.sum(WalletTransaction.amount_cents), 0)).where(
        WalletTransaction.user_id == user_id, WalletTransaction.kind.in_(["game_bet", "game_win"]),
        WalletTransaction.created_at >= _day_start(now))) or 0)


async def loss_limit(db: AsyncSession, user_id: str) -> int:
    s = get_settings()
    w = await wallet_svc.get_wallet(db, user_id)
    limits = [x for x in (s.games_daily_loss_limit_cents, w.games_daily_loss_limit_cents) if x]
    return min(limits) if limits else 0


async def check_can_wager(db: AsyncSession, user: User, amount_cents: int) -> None:
    s = get_settings()
    if not s.games_enabled or not s.wallet_enabled:
        raise GameError("Os jogos não estão disponíveis.")
    if not games_available(user):
        raise GamesHidden("Não encontrado.")
    w = await wallet_svc.get_wallet(db, user.id)
    if not w.games_accepted_at:
        raise GameError(f"Confirma primeiro que tens {s.games_min_age} anos ou mais e aceitas as regras dos jogos.")
    if w.games_excluded_until and w.games_excluded_until > utcnow():
        raise GameError(f"Pausa ativa até {w.games_excluded_until:%d/%m/%Y %H:%M}.")
    if w.balance_cents < amount_cents:
        raise GameError("Saldo insuficiente na carteira.")
    limit = await loss_limit(db, user.id)
    if limit:
        lost = -min(await net_today(db, user.id), 0)
        if lost + amount_cents > limit:
            left = max(limit - lost, 0)
            raise GameError(f"Chegaste ao limite diário de perdas ({fmt_money(limit)}). "
                            f"Podes apostar mais {fmt_money(left)} hoje.")


async def settings_view(db: AsyncSession, user: User) -> dict:
    s = get_settings()
    w = await wallet_svc.get_wallet(db, user.id)
    seed = await active_seed(db, user)
    limit = await loss_limit(db, user.id)
    net = await net_today(db, user.id)
    return {
        "enabled": games_available(user),
        "accepted": bool(w.games_accepted_at),
        "min_age": s.games_min_age,
        "excluded_until": w.games_excluded_until.isoformat() if w.games_excluded_until and
        w.games_excluded_until > utcnow() else None,
        "min_bet_cents": s.games_min_bet_cents,
        "max_bet_cents": s.games_max_bet_cents,
        "chips_cents": list(roulette.CHIPS_CENTS),
        "daily_loss_limit_cents": limit or None,
        "system_daily_loss_limit_cents": s.games_daily_loss_limit_cents or None,
        "user_daily_loss_limit_cents": w.games_daily_loss_limit_cents,
        "net_today_cents": net,
        "balance_cents": w.balance_cents,
        "seed": {"server_seed_hash": seed.server_seed_hash, "client_seed": seed.client_seed, "nonce": seed.nonce},
    }


async def update_settings(db: AsyncSession, user: User, *, accept: bool | None, daily_loss_limit_cents: int | None,
                          exclude_days: int | None, set_limit: bool) -> None:
    w = await wallet_svc.get_wallet(db, user.id, lock=True)
    if accept:
        w.games_accepted_at = w.games_accepted_at or utcnow()
    if set_limit:
        new = daily_loss_limit_cents or None
        old = w.games_daily_loss_limit_cents
        # Baixar o limite é imediato; subir (ou tirar) só conta a partir de amanhã, para não ser decidido a quente.
        if new is not None and (old is None or new <= old):
            w.games_daily_loss_limit_cents = new
        elif new != old:
            audit(db, "games.limit_raise_requested", actor=user, target_type="user", target_id=user.id,
                  old=old, new=new)
            meta_key = "games_limit_pending"
            from ..models import SiteSetting

            row = await db.get(SiteSetting, f"{meta_key}:{user.id}")
            value = {"value": new, "from": (_day_start(utcnow()) + timedelta(days=1)).isoformat()}
            if row is None:
                db.add(SiteSetting(key=f"{meta_key}:{user.id}", value=value))
            else:
                row.value = value
    if exclude_days:
        w.games_excluded_until = max(w.games_excluded_until or utcnow(), utcnow() + timedelta(days=exclude_days))
        audit(db, "games.self_exclusion", actor=user, target_type="user", target_id=user.id, days=exclude_days)


async def apply_pending_limit(db: AsyncSession, user: User) -> None:
    """Aplica um aumento de limite pedido ontem (ou antes)."""
    from ..models import SiteSetting

    row = await db.get(SiteSetting, f"games_limit_pending:{user.id}")
    if row is None or not isinstance(row.value, dict):
        return
    if datetime.fromisoformat(row.value["from"]) <= utcnow():
        w = await wallet_svc.get_wallet(db, user.id, lock=True)
        w.games_daily_loss_limit_cents = row.value.get("value")
        await db.delete(row)


# =========================================================================== sementes
async def active_seed(db: AsyncSession, user: User) -> GameSeed:
    seed = await db.scalar(select(GameSeed).where(GameSeed.user_id == user.id, GameSeed.active.is_(True))
                           .order_by(GameSeed.id.desc()).limit(1))
    if seed is None:
        server = fair.new_server_seed()
        seed = GameSeed(user_id=user.id, server_seed_enc=encrypt(server), server_seed_hash=fair.seed_hash(server),
                        client_seed=fair.new_client_seed(), nonce=0, active=True)
        db.add(seed)
        await db.flush()
    return seed


async def _next_nonce(db: AsyncSession, user: User) -> tuple[GameSeed, str, int]:
    seed = await active_seed(db, user)
    if is_postgres():
        seed = await db.scalar(select(GameSeed).where(GameSeed.id == seed.id).with_for_update()
                               .execution_options(populate_existing=True)) or seed
    nonce = seed.nonce
    seed.nonce = nonce + 1
    server = decrypt(seed.server_seed_enc)
    if not server:
        raise GameError("Semente ilegível — troca a semente e tenta de novo.")
    return seed, server, nonce


async def rotate_seed(db: AsyncSession, user: User, client_seed: str | None) -> dict:
    """Revela a semente atual e começa uma nova (com a semente de cliente escolhida)."""
    old = await active_seed(db, user)
    active = await db.scalar(select(GameRound.id).where(GameRound.user_id == user.id, GameRound.status == "active",
                                                        GameRound.seed_id == old.id).limit(1))
    if active:
        raise GameError("Acaba a mão de blackjack em curso antes de trocar de semente.")
    old.active = False
    old.revealed_at = utcnow()
    server = fair.new_server_seed()
    new = GameSeed(user_id=user.id, server_seed_enc=encrypt(server), server_seed_hash=fair.seed_hash(server),
                   client_seed=(client_seed or fair.new_client_seed())[:64], nonce=0, active=True)
    db.add(new)
    await db.flush()
    return {"revealed": {"server_seed": decrypt(old.server_seed_enc), "server_seed_hash": old.server_seed_hash,
                         "client_seed": old.client_seed, "last_nonce": old.nonce - 1},
            "current": {"server_seed_hash": new.server_seed_hash, "client_seed": new.client_seed, "nonce": 0}}


# =========================================================================== movimentos
async def _bet(db: AsyncSession, user: User, rnd: GameRound, amount: int, label: str) -> None:
    await check_can_wager(db, user, amount)
    await wallet_svc.post(db, user.id, -amount, "game_bet", label, game_round_id=rnd.id)
    rnd.wager_cents += amount


async def _pay(db: AsyncSession, user: User, rnd: GameRound, amount: int, label: str) -> None:
    rnd.payout_cents = amount
    rnd.status = "settled"
    rnd.settled_at = utcnow()
    if amount > 0:
        await wallet_svc.post(db, user.id, amount, "game_win", label, game_round_id=rnd.id,
                              key=f"game-{rnd.id}")
        # Ganhos pagam logo cobranças em atraso.
        await wallet_svc.settle_unpaid(db, user.id)


def _fair_info(seed: GameSeed, nonce: int) -> dict:
    return {"server_seed_hash": seed.server_seed_hash, "client_seed": seed.client_seed, "nonce": nonce}


# =========================================================================== roleta
async def spin(db: AsyncSession, user: User, bets: list[dict]) -> dict:
    s = get_settings()
    await apply_pending_limit(db, user)
    try:
        parsed, total = roulette.validate(bets, min_total=s.games_min_bet_cents, max_total=s.games_max_bet_cents)
    except roulette.BetError as exc:
        raise GameError(str(exc)) from exc
    seed, server, nonce = await _next_nonce(db, user)
    rnd = GameRound(user_id=user.id, game="roulette", seed_id=seed.id, nonce=nonce, state={})
    db.add(rnd)
    await db.flush()
    await _bet(db, user, rnd, total, "Roleta — aposta")
    number = fair.randbelow(fair.stream(server, seed.client_seed, nonce, "roulette"), 37)
    win, detail = roulette.settle(parsed, number)
    rnd.state = {"bets": detail, "number": number, "color": roulette.color(number)}
    await _pay(db, user, rnd, win, f"Roleta — prémio (saiu {number})")
    return {"round_id": rnd.id, "number": number, "color": roulette.color(number), "bets": detail,
            "wager_cents": total, "payout_cents": win, "net_cents": win - total,
            "balance_cents": await wallet_svc.balance(db, user.id), "fair": _fair_info(seed, nonce)}


# =========================================================================== blackjack
async def _lock_round(db: AsyncSession, rnd: GameRound) -> GameRound:
    if not is_postgres():
        return rnd
    return await db.scalar(select(GameRound).where(GameRound.id == rnd.id).with_for_update()
                           .execution_options(populate_existing=True)) or rnd


async def current_blackjack(db: AsyncSession, user: User) -> GameRound | None:
    return await db.scalar(select(GameRound).where(GameRound.user_id == user.id, GameRound.game == "blackjack",
                                                   GameRound.status == "active")
                           .order_by(GameRound.created_at.desc()).limit(1))


async def _bj_out(db: AsyncSession, user: User, rnd: GameRound) -> dict:
    seed = await db.get(GameSeed, rnd.seed_id) if rnd.seed_id else None
    view = bj.public_view(rnd.state)
    return {"round_id": rnd.id, "status": rnd.status, **view, "wager_cents": rnd.wager_cents,
            "balance_cents": await wallet_svc.balance(db, user.id),
            "fair": _fair_info(seed, rnd.nonce or 0) if seed else None}


async def _bj_settle_if_done(db: AsyncSession, user: User, rnd: GameRound) -> None:
    if rnd.state["phase"] == "done" and rnd.status == "active":
        await _pay(db, user, rnd, bj.payout(rnd.state), "Blackjack — prémio")


async def blackjack_start(db: AsyncSession, user: User, bet_cents: int) -> dict:
    s = get_settings()
    await apply_pending_limit(db, user)
    if await current_blackjack(db, user):
        raise GameError("Já tens uma mão a decorrer.")
    if bet_cents < s.games_min_bet_cents or bet_cents > s.games_max_bet_cents:
        raise GameError(f"A aposta tem de estar entre {fmt_money(s.games_min_bet_cents)} e "
                        f"{fmt_money(s.games_max_bet_cents)}.")
    if bet_cents % 10:
        raise GameError("A aposta tem de ser em múltiplos de 0,10 €.")
    seed, server, nonce = await _next_nonce(db, user)
    rnd = GameRound(user_id=user.id, game="blackjack", seed_id=seed.id, nonce=nonce)
    db.add(rnd)
    await db.flush()
    await _bet(db, user, rnd, bet_cents, "Blackjack — aposta")
    shoe = bj.new_shoe(fair.stream(server, seed.client_seed, nonce, "blackjack"))
    rnd.state = bj.new_round(shoe, bet_cents)
    await _bj_settle_if_done(db, user, rnd)
    return await _bj_out(db, user, rnd)


async def blackjack_action(db: AsyncSession, user: User, action: str) -> dict:
    rnd = await current_blackjack(db, user)
    if rnd is None:
        raise GameError("Não tens nenhuma mão a decorrer.")
    rnd = await _lock_round(db, rnd)
    if rnd.status != "active":
        raise GameError("Esta mão já terminou.")
    st = dict(rnd.state)
    st["hands"] = [dict(h, cards=list(h["cards"])) for h in st["hands"]]
    st["dealer"] = list(st["dealer"])
    try:
        if action == "hit":
            bj.hit(st)
        elif action == "stand":
            bj.stand(st)
        elif action == "double":
            if not bj.can_double(st):
                raise bj.ActionError("Só podes dobrar com duas cartas.")
            await _bet(db, user, rnd, st["hands"][st["active"]]["bet"], "Blackjack — dobrar")
            bj.double(st)
        elif action == "split":
            if not bj.can_split(st):
                raise bj.ActionError("Só podes dividir um par (até 4 mãos).")
            await _bet(db, user, rnd, st["hands"][st["active"]]["bet"], "Blackjack — dividir")
            bj.split(st)
        elif action in ("insurance", "no_insurance"):
            take = action == "insurance"
            if take:
                cost = bj.insurance_cost(st)
                if cost <= 0:
                    raise bj.ActionError("Aposta demasiado baixa para seguro.")
                # O seguro não conta para a aposta mínima, mas conta para o saldo e o limite diário.
                await _bet(db, user, rnd, cost, "Blackjack — seguro")
            bj.resolve_insurance(st, take)
        else:
            raise bj.ActionError("Ação desconhecida.")
    except bj.ActionError as exc:
        raise GameError(str(exc)) from exc
    rnd.state = st
    await _bj_settle_if_done(db, user, rnd)
    return await _bj_out(db, user, rnd)


async def history(db: AsyncSession, user: User, limit: int = 20) -> list[dict]:
    rows = (await db.scalars(select(GameRound).where(GameRound.user_id == user.id, GameRound.status == "settled")
                             .order_by(GameRound.settled_at.desc()).limit(limit))).all()
    out = []
    for r in rows:
        summary = ""
        if r.game == "roulette":
            summary = f"Saiu {(r.state or {}).get('number')}"
        elif r.game == "blackjack":
            res = [x["result"] for x in ((r.state or {}).get("results") or []) if not x["result"].startswith("ins")]
            summary = ", ".join(res)
        out.append({"id": r.id, "game": r.game, "wager_cents": r.wager_cents, "payout_cents": r.payout_cents,
                    "net_cents": r.payout_cents - r.wager_cents, "summary": summary,
                    "settled_at": r.settled_at.isoformat() if r.settled_at else None, "nonce": r.nonce})
    return out
