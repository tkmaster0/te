"""Aleatoriedade verificável ("provably fair").

Cada resultado vem de HMAC-SHA256(semente_do_servidor, "semente_do_cliente:nonce:jogo:contador"). Antes de jogar o
cliente vê o SHA-256 da semente do servidor; quando a troca, a semente antiga é revelada e qualquer pessoa pode
recalcular todos os resultados dessa semente. O servidor não pode mudar um resultado depois de mostrar o hash, e o
cliente pode mudar a sua semente quando quiser.
"""
from __future__ import annotations

import hashlib
import hmac
import secrets
from collections.abc import Iterator


def new_server_seed() -> str:
    return secrets.token_hex(32)


def new_client_seed() -> str:
    return secrets.token_hex(8)


def seed_hash(server_seed: str) -> str:
    return hashlib.sha256(server_seed.encode()).hexdigest()


def stream(server_seed: str, client_seed: str, nonce: int, game: str) -> Iterator[int]:
    """Sequência infinita de inteiros de 32 bits, determinística para (sementes, nonce, jogo)."""
    counter = 0
    key = server_seed.encode()
    while True:
        digest = hmac.new(key, f"{client_seed}:{nonce}:{game}:{counter}".encode(), hashlib.sha256).digest()
        for i in range(0, 32, 4):
            yield int.from_bytes(digest[i:i + 4], "big")
        counter += 1


def randbelow(it: Iterator[int], n: int) -> int:
    """Inteiro uniforme em [0, n) — amostragem por rejeição, sem enviesamento de módulo."""
    limit = (2 ** 32 // n) * n
    while True:
        x = next(it)
        if x < limit:
            return x % n


def shuffle(items: list, it: Iterator[int]) -> list:
    """Fisher–Yates com a sequência dada."""
    out = list(items)
    for i in range(len(out) - 1, 0, -1):
        j = randbelow(it, i + 1)
        out[i], out[j] = out[j], out[i]
    return out
