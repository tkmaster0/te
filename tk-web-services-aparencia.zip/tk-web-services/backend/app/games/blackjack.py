"""Blackjack (regras clássicas de casino).

  * 6 baralhos, baralhados de novo em cada mão (resultado verificável — ver fair.py).
  * O dealer fica nos 17 suaves (S17) e espreita o blackjack com um Ás ou uma figura/10 à vista.
  * Blackjack paga 3:2; seguro (com Ás à vista) paga 2:1.
  * Dobrar em quaisquer duas cartas (também depois de dividir, exceto Ases divididos).
  * Dividir pares do mesmo valor até 4 mãos; Ases divididos recebem uma só carta cada.

O estado é um dict serializável (guardado em GameRound.state). O baralho e a carta tapada do dealer nunca são
enviados ao cliente enquanto a mão está a decorrer.
"""
from __future__ import annotations

from collections.abc import Iterator

from .fair import shuffle

RANKS = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"]
SUITS = ["S", "H", "D", "C"]
DECKS = 6
MAX_HANDS = 4


class ActionError(ValueError):
    pass


def new_shoe(it: Iterator[int]) -> list[str]:
    cards = [f"{r}{s}" for _ in range(DECKS) for s in SUITS for r in RANKS]
    return shuffle(cards, it)


def rank(card: str) -> str:
    return card[:-1]


def card_value(card: str) -> int:
    r = rank(card)
    if r == "A":
        return 11
    if r in ("J", "Q", "K"):
        return 10
    return int(r)


def hand_value(cards: list[str]) -> tuple[int, bool]:
    """(total, suave) — suave = há um Ás a contar 11."""
    total = sum(card_value(c) for c in cards)
    aces = sum(1 for c in cards if rank(c) == "A")
    while total > 21 and aces:
        total -= 10
        aces -= 1
    return total, aces > 0


def is_blackjack(cards: list[str]) -> bool:
    return len(cards) == 2 and hand_value(cards)[0] == 21


def _draw(st: dict) -> str:
    card = st["shoe"][st["pos"]]
    st["pos"] += 1
    return card


def new_round(shoe: list[str], bet_cents: int) -> dict:
    st = {"shoe": shoe, "pos": 0, "dealer": [], "hands": [], "active": 0, "phase": "player",
          "insurance": None, "base_bet": bet_cents, "dealer_bj": False, "results": None}
    player = [_draw(st)]
    st["dealer"].append(_draw(st))
    player.append(_draw(st))
    st["dealer"].append(_draw(st))
    st["hands"] = [{"cards": player, "bet": bet_cents, "doubled": False, "done": False, "split_aces": False,
                    "from_split": False}]
    up = rank(st["dealer"][0])
    if up == "A":
        st["phase"] = "insurance"
        return st
    _after_peek(st, peek=card_value(st["dealer"][0]) == 10)
    return st


def _after_peek(st: dict, *, peek: bool) -> None:
    """Depois de o dealer espreitar (ou não poder ter blackjack): resolve logo os blackjacks."""
    st["dealer_bj"] = peek and is_blackjack(st["dealer"])
    player_bj = is_blackjack(st["hands"][0]["cards"])
    if st["dealer_bj"] or player_bj:
        st["hands"][0]["done"] = True
        _finish(st, dealer_draws=False)
    else:
        st["phase"] = "player"


def insurance_cost(st: dict) -> int:
    return st["base_bet"] // 2


def resolve_insurance(st: dict, take: bool) -> None:
    if st["phase"] != "insurance":
        raise ActionError("O seguro já não está disponível.")
    st["insurance"] = insurance_cost(st) if take else 0
    _after_peek(st, peek=True)


def _hand(st: dict) -> dict:
    if st["phase"] != "player":
        raise ActionError("Esta mão já terminou." if st["phase"] == "done" else "Decide primeiro sobre o seguro.")
    return st["hands"][st["active"]]


def can_double(st: dict) -> bool:
    if st["phase"] != "player":
        return False
    h = st["hands"][st["active"]]
    return len(h["cards"]) == 2 and not h["split_aces"] and not h["done"]


def can_split(st: dict) -> bool:
    if st["phase"] != "player":
        return False
    h = st["hands"][st["active"]]
    return (len(h["cards"]) == 2 and not h["done"] and len(st["hands"]) < MAX_HANDS and not h["split_aces"]
            and card_value(h["cards"][0]) == card_value(h["cards"][1]))


def _advance(st: dict) -> None:
    """Passa à mão seguinte ainda por jogar; se não houver, joga o dealer e acaba."""
    while st["active"] < len(st["hands"]) and st["hands"][st["active"]]["done"]:
        st["active"] += 1
        if st["active"] < len(st["hands"]):
            h = st["hands"][st["active"]]
            if len(h["cards"]) == 1:  # mão vinda de uma divisão: recebe a segunda carta agora
                h["cards"].append(_draw(st))
                if h["split_aces"] or hand_value(h["cards"])[0] == 21:
                    h["done"] = True
    if st["active"] >= len(st["hands"]):
        st["active"] = len(st["hands"]) - 1
        _finish(st, dealer_draws=True)


def hit(st: dict) -> None:
    h = _hand(st)
    h["cards"].append(_draw(st))
    total, _ = hand_value(h["cards"])
    if total >= 21:
        h["done"] = True
        _advance(st)


def stand(st: dict) -> None:
    h = _hand(st)
    h["done"] = True
    _advance(st)


def double(st: dict) -> int:
    """Dobra a aposta da mão atual (recebe uma só carta). Devolve o valor extra apostado."""
    if not can_double(st):
        raise ActionError("Só podes dobrar com duas cartas.")
    h = st["hands"][st["active"]]
    extra = h["bet"]
    h["bet"] += extra
    h["doubled"] = True
    h["cards"].append(_draw(st))
    h["done"] = True
    _advance(st)
    return extra


def split(st: dict) -> int:
    """Divide o par da mão atual em duas mãos. Devolve o valor extra apostado."""
    if not can_split(st):
        raise ActionError("Só podes dividir um par (até 4 mãos).")
    idx = st["active"]
    h = st["hands"][idx]
    aces = rank(h["cards"][0]) == "A"
    second = {"cards": [h["cards"].pop()], "bet": h["bet"], "doubled": False, "done": False, "split_aces": aces,
              "from_split": True}
    h["from_split"] = True
    h["split_aces"] = aces
    st["hands"].insert(idx + 1, second)
    h["cards"].append(_draw(st))
    if aces or hand_value(h["cards"])[0] == 21:
        h["done"] = True
        _advance(st)
    return second["bet"]


def _finish(st: dict, *, dealer_draws: bool) -> None:
    live = [h for h in st["hands"] if hand_value(h["cards"])[0] <= 21]
    only_naturals = all(is_blackjack(h["cards"]) and not h["from_split"] for h in st["hands"])
    if dealer_draws and live and not only_naturals and not st["dealer_bj"]:
        while True:
            total, _soft = hand_value(st["dealer"])
            if total < 17:
                st["dealer"].append(_draw(st))
                continue
            break  # S17: fica em 17 suave
    st["phase"] = "done"
    st["results"] = _settle(st)


def _settle(st: dict) -> list[dict]:
    dealer_total, _ = hand_value(st["dealer"])
    dealer_bj = is_blackjack(st["dealer"])
    out = []
    for h in st["hands"]:
        total, _ = hand_value(h["cards"])
        natural = is_blackjack(h["cards"]) and not h["from_split"]
        if total > 21:
            res, pay = "bust", 0
        elif natural and not dealer_bj:
            res, pay = "blackjack", h["bet"] + h["bet"] * 3 // 2
        elif dealer_bj and natural:
            res, pay = "push", h["bet"]
        elif dealer_bj:
            res, pay = "lose", 0
        elif dealer_total > 21 or total > dealer_total:
            res, pay = "win", h["bet"] * 2
        elif total == dealer_total:
            res, pay = "push", h["bet"]
        else:
            res, pay = "lose", 0
        out.append({"result": res, "payout_cents": pay, "total": total})
    if st.get("insurance"):
        out.append({"result": "insurance_win" if dealer_bj else "insurance_lose",
                    "payout_cents": st["insurance"] * 3 if dealer_bj else 0, "total": None})
    return out


def payout(st: dict) -> int:
    return sum(r["payout_cents"] for r in (st.get("results") or []))


def public_view(st: dict) -> dict:
    """O que o cliente pode ver (sem o baralho; sem a carta tapada enquanto a mão decorre)."""
    done = st["phase"] == "done"
    dealer = list(st["dealer"]) if done else [st["dealer"][0], "??"]
    dealer_total = hand_value(st["dealer"])[0] if done else hand_value([st["dealer"][0]])[0]
    hands = []
    for i, h in enumerate(st["hands"]):
        total, soft = hand_value(h["cards"])
        hands.append({"cards": h["cards"], "bet_cents": h["bet"], "total": total, "soft": soft and total <= 21,
                      "doubled": h["doubled"], "done": h["done"], "active": not done and i == st["active"]
                      and st["phase"] == "player",
                      "result": (st["results"][i] if done and st.get("results") else None)})
    return {
        "phase": st["phase"],
        "dealer": dealer,
        "dealer_total": dealer_total,
        "hands": hands,
        "insurance_cents": st.get("insurance"),
        "can": {
            "hit": st["phase"] == "player",
            "stand": st["phase"] == "player",
            "double": can_double(st),
            "split": can_split(st),
            "insurance": st["phase"] == "insurance",
        },
        "insurance_cost_cents": insurance_cost(st) if st["phase"] == "insurance" else None,
        "payout_cents": payout(st) if done else None,
    }
