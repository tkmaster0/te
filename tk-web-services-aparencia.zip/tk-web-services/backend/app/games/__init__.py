"""Jogos com os créditos da carteira: roleta europeia e blackjack."""
