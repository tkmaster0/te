"""Roleta europeia (um só zero, 37 casas). Vantagem da casa: 1/37 ≈ 2,7 %.

Pagamentos (sobre a aposta, que também é devolvida):
  pleno 35:1 · cavalo 17:1 · transversal 11:1 · quadrado 8:1 · seisena 5:1 · coluna/dúzia 2:1 ·
  vermelho/preto, par/ímpar, 1–18/19–36 1:1. O zero faz perder as apostas simples.
"""
from __future__ import annotations

from dataclasses import dataclass

RED = frozenset({1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36})
CHIPS_CENTS = (20, 50, 100, 200, 500, 1000)
PAYOUT = {"straight": 35, "split": 17, "street": 11, "corner": 8, "line": 5, "column": 2, "dozen": 2,
          "red": 1, "black": 1, "odd": 1, "even": 1, "low": 1, "high": 1}
# Ordem física da roda europeia (para a animação no cliente).
WHEEL = [0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10, 5, 24, 16, 33, 1, 20, 14, 31, 9, 22,
         18, 29, 7, 28, 12, 35, 3, 26]


class BetError(ValueError):
    pass


def color(n: int) -> str:
    return "green" if n == 0 else ("red" if n in RED else "black")


def chip_amount_ok(cents: int) -> bool:
    """Montante que se consegue fazer com fichas de 0,20 / 0,50 / 1 / 2 / 5 / 10 €."""
    return cents == 20 or (cents >= 40 and cents % 10 == 0)


def _row(n: int) -> int:
    return (n - 1) // 3


def covered(bet_type: str, numbers: list[int]) -> frozenset[int]:
    """Números cobertos por uma aposta (valida a geometria da mesa)."""
    nums = sorted(set(numbers))
    if any(not 0 <= n <= 36 for n in nums):
        raise BetError("Número fora da mesa.")
    if bet_type == "straight":
        if len(nums) != 1:
            raise BetError("Um pleno é num só número.")
        return frozenset(nums)
    if bet_type == "split":
        if len(nums) != 2:
            raise BetError("Um cavalo cobre dois números.")
        a, b = nums
        if a == 0 and b in (1, 2, 3):
            return frozenset(nums)
        if a >= 1 and (b - a == 3 or (b - a == 1 and _row(a) == _row(b))):
            return frozenset(nums)
        raise BetError("Esses dois números não são vizinhos na mesa.")
    if bet_type == "street":
        if nums in ([0, 1, 2], [0, 2, 3]):
            return frozenset(nums)
        if len(nums) == 3 and nums[0] >= 1 and nums[0] % 3 == 1 and nums == [nums[0], nums[0] + 1, nums[0] + 2]:
            return frozenset(nums)
        raise BetError("Uma transversal é uma linha de três números.")
    if bet_type == "corner":
        if nums == [0, 1, 2, 3]:
            return frozenset(nums)
        if len(nums) == 4:
            n = nums[0]
            if n >= 1 and n % 3 != 0 and nums == [n, n + 1, n + 3, n + 4]:
                return frozenset(nums)
        raise BetError("Um quadrado cobre quatro números que se tocam.")
    if bet_type == "line":
        if len(nums) == 6:
            n = nums[0]
            if n >= 1 and n % 3 == 1 and n <= 31 and nums == list(range(n, n + 6)):
                return frozenset(nums)
        raise BetError("Uma seisena são duas linhas seguidas.")
    if bet_type == "column":
        if len(nums) != 1 or nums[0] not in (1, 2, 3):
            raise BetError("Coluna inválida.")
        c = nums[0]
        return frozenset(n for n in range(1, 37) if (n - c) % 3 == 0)
    if bet_type == "dozen":
        if len(nums) != 1 or nums[0] not in (1, 2, 3):
            raise BetError("Dúzia inválida.")
        d = nums[0]
        return frozenset(range(12 * (d - 1) + 1, 12 * d + 1))
    simple = {
        "red": RED, "black": frozenset(range(1, 37)) - RED,
        "odd": frozenset(n for n in range(1, 37) if n % 2), "even": frozenset(n for n in range(1, 37) if not n % 2),
        "low": frozenset(range(1, 19)), "high": frozenset(range(19, 37)),
    }
    if bet_type in simple:
        return frozenset(simple[bet_type])
    raise BetError("Tipo de aposta desconhecido.")


@dataclass
class Bet:
    type: str
    numbers: list[int]
    amount_cents: int
    covers: frozenset[int]


def validate(bets: list[dict], *, min_total: int, max_total: int) -> tuple[list[Bet], int]:
    out = []
    for b in bets:
        amt = int(b["amount_cents"])
        if not chip_amount_ok(amt):
            raise BetError("Cada aposta tem de ser feita com fichas de 0,20 €, 0,50 €, 1 €, 2 €, 5 € ou 10 €.")
        cov = covered(b["type"], list(b.get("numbers") or []))
        out.append(Bet(type=b["type"], numbers=sorted(set(b.get("numbers") or [])), amount_cents=amt, covers=cov))
    total = sum(b.amount_cents for b in out)
    if total < min_total:
        raise BetError(f"A aposta mínima por jogada é de {min_total / 100:.2f} €".replace(".", ","))
    if total > max_total:
        raise BetError(f"A aposta máxima por jogada é de {max_total / 100:.2f} €".replace(".", ","))
    return out, total


def settle(bets: list[Bet], number: int) -> tuple[int, list[dict]]:
    """Devolve (total a pagar, detalhe por aposta)."""
    total = 0
    detail = []
    for b in bets:
        win = number in b.covers
        pay = b.amount_cents * (PAYOUT[b.type] + 1) if win else 0
        total += pay
        detail.append({"type": b.type, "numbers": b.numbers, "amount_cents": b.amount_cents, "won": win,
                       "payout_cents": pay})
    return total, detail
