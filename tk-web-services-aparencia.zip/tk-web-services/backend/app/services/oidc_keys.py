"""Chaves de assinatura RS256 do fornecedor OIDC (geradas no primeiro uso, privadas cifradas em repouso)."""
from __future__ import annotations

import base64
import hashlib
import json
import time
import uuid

import jwt
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from ..db import utcnow
from ..models import SigningKey
from ..security import decrypt, encrypt

_cache: dict[str, tuple[float, object]] = {}


def _b64(n: int) -> str:
    raw = n.to_bytes((n.bit_length() + 7) // 8, "big")
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode()


async def active_key(db: AsyncSession) -> SigningKey:
    key = await db.scalar(select(SigningKey).where(SigningKey.active.is_(True)).order_by(SigningKey.created_at.desc()))
    if key:
        return key
    priv = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    pub = priv.public_key().public_numbers()
    jwk = {"kty": "RSA", "n": _b64(pub.n), "e": _b64(pub.e), "alg": "RS256", "use": "sig"}
    thumb = hashlib.sha256(json.dumps({"e": jwk["e"], "kty": "RSA", "n": jwk["n"]}, separators=(",", ":"),
                                      sort_keys=True).encode()).digest()
    kid = base64.urlsafe_b64encode(thumb).rstrip(b"=").decode()[:32]
    jwk["kid"] = kid
    pem = priv.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                             serialization.NoEncryption()).decode()
    key = SigningKey(kid=kid, private_pem_enc=encrypt(pem), public_jwk=jwk, active=True)
    db.add(key)
    await db.commit()
    return key


async def rotate(db: AsyncSession) -> SigningKey:
    for k in (await db.scalars(select(SigningKey).where(SigningKey.active.is_(True)))).all():
        k.active = False
        k.retired_at = utcnow()
    await db.flush()
    _cache.clear()
    return await active_key(db)


async def jwks(db: AsyncSession) -> dict:
    await active_key(db)
    keys = (await db.scalars(select(SigningKey).where(SigningKey.retired_at.is_(None) | SigningKey.active.is_(True)
                                                      ))).all()
    # Mantém chaves retiradas nos últimos 2 dias para tokens ainda válidos
    from datetime import timedelta

    recent = (await db.scalars(select(SigningKey).where(SigningKey.retired_at > utcnow() - timedelta(days=2)))).all()
    seen, out = set(), []
    for k in list(keys) + list(recent):
        if k.kid not in seen:
            seen.add(k.kid)
            out.append(k.public_jwk)
    return {"keys": out}


async def sign(db: AsyncSession, claims: dict) -> str:
    key = await active_key(db)
    cached = _cache.get(key.kid)
    if cached is None:
        pem = decrypt(key.private_pem_enc)
        if not pem:
            raise RuntimeError("Chave OIDC ilegível — a SECRET_KEY mudou?")
        _cache[key.kid] = (time.time(), serialization.load_pem_private_key(pem.encode(), password=None))
        cached = _cache[key.kid]
    return jwt.encode(claims, cached[1], algorithm="RS256", headers={"kid": key.kid})


async def verify(db: AsyncSession, token: str, *, audience: str | None = None, verify_exp: bool = True) -> dict:
    header = jwt.get_unverified_header(token)
    key = await db.get(SigningKey, header.get("kid", ""))
    if key is None:
        raise jwt.InvalidTokenError("kid desconhecido")
    pub = jwt.algorithms.RSAAlgorithm.from_jwk(json.dumps(key.public_jwk))
    opts = {"verify_aud": audience is not None, "verify_exp": verify_exp}
    return jwt.decode(token, pub, algorithms=["RS256"], issuer=get_settings().issuer, audience=audience,
                      options=opts)


def new_jti() -> str:
    return uuid.uuid4().hex
