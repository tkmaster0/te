"""Verificação das integrações externas (Jellyfin, Seerr, Bazarr, Dispatcharr, pagamentos, email…)."""
from __future__ import annotations

import asyncio

from ..config import get_settings
from ..integrations.dispatcharr import DispatcharrClient
from ..integrations.gocardless import GoCardlessClient
from ..integrations.jellyfin import JellyfinClient
from ..integrations.seerr import SeerrClient


async def integrations() -> list[dict]:
    """Estado de cada integração (usado em Admin → Integrações e em `cli check-links`)."""
    s = get_settings()

    async def check(name, enabled, fn):
        if not enabled:
            return {"name": name, "configured": False}
        try:
            info = await fn()
            return {"name": name, "configured": True, "ok": True, "info": info}
        except Exception as exc:  # noqa: BLE001
            return {"name": name, "configured": True, "ok": False, "error": str(exc)[:300]}

    async def jf():
        i = await JellyfinClient(timeout=6).ping()
        return {"version": i.get("Version"), "server": i.get("ServerName")}

    async def se():
        i = await SeerrClient(timeout=6).ping()
        return {"version": i.get("version")}

    async def dc():
        users = await DispatcharrClient(timeout=6).list_users()
        return {"users": len(users)}

    async def gc():
        await GoCardlessClient(timeout=8).ping()
        return {"environment": s.gocardless_environment, "webhook_secret": bool(s.gocardless_webhook_secret)}

    async def st():
        from ..integrations import stripe_client as sc

        acct = await sc.client().v1.accounts.retrieve_current_async()
        return {"account": acct.id, "webhook_secret": bool(s.stripe_webhook_secret),
                "live": not (s.stripe_secret_key or "").startswith("sk_test")}

    async def smtp():
        return {"host": s.smtp_host, "from": s.mail_from}

    async def bz():
        from ..integrations.bazarr import BazarrClient

        i = await BazarrClient(timeout=6).ping()
        return {"version": (i.get("data") or {}).get("bazarr_version")}

    async def wa():
        return {"provider": s.whatsapp_provider, "number": s.whatsapp_number}

    async def ai():
        return {"model": s.assistant_model, "embeddings": s.assistant_embedding_model or None}

    # Em paralelo: com o TKFLIX em baixo cada verificação espera pelo timeout — em série a página demorava 30 s.
    return list(await asyncio.gather(
        check("jellyfin", s.jellyfin_enabled, jf),
        check("seerr", s.seerr_enabled, se),
        check("dispatcharr", s.dispatcharr_enabled, dc),
        check("bazarr", s.bazarr_enabled, bz),
        check("gocardless", s.gocardless_enabled, gc),
        check("stripe", s.stripe_enabled, st),
        check("smtp", s.smtp_enabled, smtp),
        check("whatsapp", s.whatsapp_enabled, wa),
        check("assistant", s.assistant_ready, ai),
    ))


