"""Ciclo de vida das subscrições e cálculo de direitos (entitlements)."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta

from sqlalchemy import or_, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from ..config import get_settings
from ..db import utcnow
from ..features import PlanFeatures, feature_flags, merge_features
from ..models import ENTITLED_STATUSES, Grant, Plan, Product, Subscription, SubStatus, User
from .audit import audit
from .jobs import enqueue
from .mailer import queue_email

log = logging.getLogger("tkportal.subs")


def fmt_date(d: datetime | None) -> str:
    return d.strftime("%d/%m/%Y") if d else "—"


def fmt_money(cents: int, currency: str = "EUR") -> str:
    value = f"{cents / 100:,.2f}".replace(",", " ").replace(".", ",")
    return f"{value} €" if currency.upper() == "EUR" else f"{value} {currency.upper()}"


def add_interval(d: datetime, unit: str, count: int) -> datetime:
    if unit == "year":
        try:
            return d.replace(year=d.year + count)
        except ValueError:  # 29 fev
            return d.replace(year=d.year + count, day=28)
    if unit == "week":
        return d + timedelta(weeks=count)
    month = d.month - 1 + count
    year = d.year + month // 12
    month = month % 12 + 1
    import calendar

    day = min(d.day, calendar.monthrange(year, month)[1])
    return d.replace(year=year, month=month, day=day)


# --------------------------------------------------------------------------- entitlements
@dataclass
class Access:
    features: PlanFeatures
    flags: list[str]
    sources: list[dict] = field(default_factory=list)

    @property
    def any_active(self) -> bool:
        return bool(self.sources)

    def groups(self, user: User) -> list[str]:
        g = {"tkflix-user"}
        if user.is_admin:
            g.add("admin")
        if self.any_active:
            g.add("active")
        g.update(f"feature:{f}" for f in self.flags)
        g.update(f"plan:{s['plan_code']}" for s in self.sources)
        g.update(f"product:{s['product_code']}" for s in self.sources if s.get("product_code"))
        g.update(self.features.groups)
        return sorted(g)


def sub_is_entitled(sub: Subscription, now: datetime | None = None) -> bool:
    now = now or utcnow()
    if sub.status not in ENTITLED_STATUSES:
        return False
    if sub.status == SubStatus.canceling and sub.access_until and sub.access_until <= now:
        return False
    if sub.status == SubStatus.past_due and sub.grace_until and sub.grace_until <= now:
        return False
    return True


async def compute_access(db: AsyncSession, user: User) -> Access:
    now = utcnow()
    subs = (
        await db.scalars(
            select(Subscription)
            .options(selectinload(Subscription.plan).selectinload(Plan.product))
            .where(Subscription.user_id == user.id, Subscription.status.in_([s.value for s in ENTITLED_STATUSES]))
        )
    ).all()
    grants = (
        await db.scalars(
            select(Grant)
            .options(selectinload(Grant.plan).selectinload(Plan.product))
            .where(
                Grant.user_id == user.id,
                Grant.revoked_at.is_(None),
                Grant.starts_at <= now,
                or_(Grant.ends_at.is_(None), Grant.ends_at > now),
            )
        )
    ).all()
    feats: list[PlanFeatures] = []
    sources: list[dict] = []
    if user.is_active:
        for s in subs:
            if sub_is_entitled(s, now):
                feats.append(PlanFeatures.model_validate(s.plan.features or {}))
                sources.append({"type": "subscription", "id": s.id, "plan_code": s.plan.code, "plan": s.plan.name,
                                "status": s.status, "product_code": s.plan.product.code if s.plan.product else None})
        for g in grants:
            feats.append(PlanFeatures.model_validate(g.plan.features or {}))
            sources.append({"type": "grant", "id": g.id, "plan_code": g.plan.code, "plan": g.plan.name,
                            "until": g.ends_at.isoformat() if g.ends_at else None,
                            "product_code": g.plan.product.code if g.plan.product else None})
    merged = merge_features(feats)
    return Access(features=merged, flags=feature_flags(merged), sources=sources)


async def request_reconcile(db: AsyncSession, user_id: str, delay_seconds: int = 0) -> None:
    await enqueue(db, "reconcile_user", {"user_id": user_id}, dedupe_key=f"reconcile:{user_id}",
                  delay_seconds=delay_seconds, max_attempts=12)


# --------------------------------------------------------------------------- transições
async def set_status(
    db: AsyncSession,
    sub: Subscription,
    status: SubStatus,
    *,
    reason: str,
    notify: bool = True,
    **fields,
) -> bool:
    """Altera o estado de uma subscrição, dispara reconciliação e notificações. Devolve True se mudou."""
    s = get_settings()
    old = SubStatus(sub.status)
    for k, v in fields.items():
        setattr(sub, k, v)
    if old == status:
        await request_reconcile(db, sub.user_id)
        return False
    sub.status = status
    now = utcnow()
    if status == SubStatus.ended:
        sub.ended_at = sub.ended_at or now
    if status == SubStatus.past_due and not sub.grace_until:
        sub.grace_until = now + timedelta(days=s.grace_period_days)
    if status in (SubStatus.active, SubStatus.bonus):
        sub.grace_until = None
    if status != SubStatus.canceling and status != SubStatus.ended:
        sub.cancel_at_period_end = False
    audit(db, "subscription.status", target_type="subscription", target_id=sub.id, old=old.value,
          new=status.value, reason=reason)
    await request_reconcile(db, sub.user_id)
    if (old in ENTITLED_STATUSES) != (status in ENTITLED_STATUSES):
        from .fulfillment import on_subscription_change

        await on_subscription_change(db, sub, "activated" if status in ENTITLED_STATUSES else "deactivated")

    if notify:
        # Sem emails de confirmação: o cliente vê o resultado das suas ações logo no portal. Só se envia o que ele
        # não sabe e precisa de saber — o serviço foi suspenso por falta de pagamento, ou terminou por isso.
        user = await db.get(User, sub.user_id)
        plan = await db.get(Plan, sub.plan_id)
        if user and plan:
            base = s.public_url
            if status == SubStatus.active and old == SubStatus.pending and s.admin_notify_email:
                await queue_email(db, s.admin_notify_email, "admin_notice", subject=f"Nova subscrição: {plan.name}",
                                  message=f"{user.username} ({user.email}) ativou {plan.name} via {sub.provider}.")
            elif status == SubStatus.ended and old == SubStatus.suspended:
                await queue_email(db, user.email, "subscription_ended", plan=plan.name, cta_url=f"{base}/app/planos")
            elif status == SubStatus.suspended:
                await queue_email(db, user.email, "subscription_suspended", plan=plan.name,
                                  cta_url=f"{base}/app/faturacao")
    return True


async def live_sub_for_product(db: AsyncSession, user_id: str, product_id: int, exclude_id: str | None = None
                               ) -> Subscription | None:
    q = select(Subscription).where(
        Subscription.user_id == user_id,
        Subscription.product_id == product_id,
        Subscription.status.in_([s.value for s in ENTITLED_STATUSES | {SubStatus.suspended}]),
    )
    if exclude_id:
        q = q.where(Subscription.id != exclude_id)
    return await db.scalar(q.order_by(Subscription.created_at.desc()).limit(1))


async def sweep(db: AsyncSession) -> dict:
    """Transições por tempo: cancelamentos que chegaram ao fim, tolerâncias expiradas, ofertas terminadas."""
    now = utcnow()
    counts = {"ended": 0, "suspended": 0, "grants": 0}
    for sub in (await db.scalars(select(Subscription).where(
            Subscription.status == SubStatus.canceling.value, Subscription.access_until <= now))).all():
        await set_status(db, sub, SubStatus.ended, reason="access_until reached")
        counts["ended"] += 1
    from .billing import retries_pending

    for sub in (await db.scalars(select(Subscription).where(
            Subscription.status == SubStatus.past_due.value, Subscription.grace_until <= now))).all():
        # Só se corta depois da última tentativa: enquanto o GoCardless/Stripe (ou o portal) ainda vão tentar
        # cobrar, o cliente mantém o acesso.
        if await retries_pending(db, sub.user_id):
            counts.setdefault("waiting_retry", 0)
            counts["waiting_retry"] += 1
            continue
        await set_status(db, sub, SubStatus.suspended, reason="grace period over")
        counts["suspended"] += 1
    # Ofertas que terminaram na última hora → reconciliar
    for g in (await db.scalars(select(Grant).where(
            Grant.ends_at <= now, Grant.ends_at > now - timedelta(hours=2), Grant.revoked_at.is_(None)))).all():
        await request_reconcile(db, g.user_id)
        counts["grants"] += 1
    await db.commit()
    return counts


async def get_plan(db: AsyncSession, plan_id: int) -> Plan | None:
    return await db.scalar(select(Plan).options(selectinload(Plan.product)).where(Plan.id == plan_id))


async def product_of(db: AsyncSession, plan: Plan) -> Product:
    p = await db.get(Product, plan.product_id)
    assert p is not None
    return p
