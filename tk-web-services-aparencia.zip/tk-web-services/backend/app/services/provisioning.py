"""Reconciliação: aplica os direitos calculados no portal aos serviços externos.

É idempotente — pode correr quantas vezes for preciso. Corre:
  * sempre que algo muda (subscrição, oferta, bloqueio, alteração de plano),
  * periodicamente para todos os utilizadores (deteta desvios feitos à mão no Jellyfin, etc.).
"""
from __future__ import annotations

import logging
import re
from datetime import datetime, timedelta

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from ..db import utcnow
from ..integrations.dispatcharr import DispatcharrClient, DispatcharrError
from ..integrations.jellyfin import JellyfinClient, JellyfinError, build_policy
from ..integrations.seerr import SeerrClient, SeerrError
from ..models import ServiceAccount, User
from ..security import XC_PASSWORD_RE, decrypt, encrypt, friendly_password, new_service_password
from .jobs import PermanentError, RetryLater, enqueue, job_handler
from .subscriptions import compute_access

log = logging.getLogger("tkportal.provisioning")

USERNAME_XC_RE = re.compile(r"^[A-Za-z0-9._-]{3,64}$")

MANAGED_POLICY_KEYS = ("IsDisabled", "EnableAllFolders", "EnabledFolders", "EnableLiveTvAccess", "MaxActiveSessions",
                       "EnableContentDownloading", "RemoteClientBitrateLimit")


async def get_account(db: AsyncSession, user_id: str, service: str) -> ServiceAccount | None:
    return await db.scalar(select(ServiceAccount).where(ServiceAccount.user_id == user_id,
                                                        ServiceAccount.service == service))


async def queue_jellyfin_password(db: AsyncSession, user: User, password: str) -> None:
    """Guarda (cifrada, temporariamente) a password para a aplicar no Jellyfin.

    O payload cifrado é apagado da fila quando o job termina.
    """
    if not get_settings().jellyfin_enabled or not get_settings().jellyfin_sync_password:
        return
    if not user.jellyfin_password_login:
        # Conta SSO: a password do portal nunca vai para o Jellyfin (entra com "Entrar com TK Web Services" ou
        # Quick Connect).
        user.needs_password_sync = False
        return
    await enqueue(db, "jellyfin_set_password", {"user_id": user.id, "password_enc": encrypt(password)},
                  max_attempts=10)
    user.needs_password_sync = False


# --------------------------------------------------------------------------- Jellyfin
def _is_jf_admin(jf_user: dict | None) -> bool:
    return bool(((jf_user or {}).get("Policy") or {}).get("IsAdministrator"))


async def _ensure_jellyfin_account(db: AsyncSession, user: User, jf: JellyfinClient, password: str | None
                                   ) -> tuple[ServiceAccount, dict]:
    sa = await get_account(db, user.id, "jellyfin")
    jf_user = None
    if sa and sa.external_id:
        jf_user = await jf.get_user(sa.external_id)
    if jf_user is None:
        existing = await jf.find_user_by_name(user.username)
        if existing:
            # Liga a uma conta existente só se não estiver já ligada a outro utilizador do portal.
            other = await db.scalar(select(ServiceAccount).where(ServiceAccount.service == "jellyfin",
                                                                 ServiceAccount.external_id == existing["Id"]))
            if other and other.user_id != user.id:
                raise PermanentError(f"A conta Jellyfin '{user.username}' pertence a outro utilizador do portal")
            jf_user = existing
            if _is_jf_admin(existing):
                log.warning("Conta Jellyfin '%s' é administradora — ligada sem alterar a password", user.username)
            elif password:
                await jf.set_password(existing["Id"], password)
            elif user.jellyfin_password_login:
                user.needs_password_sync = True  # a password do Jellyfin pode ser diferente
        else:
            pwd = password or new_service_password(24)
            jf_user = await jf.create_user(user.username, pwd)
            if not password and user.jellyfin_password_login:
                user.needs_password_sync = True
            # Contas novas começam desativadas; a reconciliação ativa se houver direitos.
            full = await jf.get_user(jf_user["Id"]) or jf_user
            policy = build_policy(full.get("Policy") or {}, enabled=False, feature=None)
            policy["IsHidden"] = True
            await jf.update_policy(jf_user["Id"], policy)
            jf_user = await jf.get_user(jf_user["Id"]) or jf_user
        if sa is None:
            sa = ServiceAccount(user_id=user.id, service="jellyfin")
            db.add(sa)
        sa.external_id = jf_user["Id"]
        sa.external_username = jf_user.get("Name")
        await db.flush()
    elif password:
        if _is_jf_admin(jf_user):
            # Nunca mexer em administradores do Jellyfin (nem na password): uma conta do portal comprometida
            # não pode dar controlo do servidor.
            log.warning("Conta Jellyfin %s é administradora — password não sincronizada", jf_user["Id"])
        else:
            await jf.set_password(jf_user["Id"], password)
    assert sa is not None
    return sa, jf_user


@job_handler("jellyfin_set_password")
async def _job_jellyfin_password(db: AsyncSession, payload: dict) -> None:
    user = await db.get(User, payload["user_id"])
    if not user:
        return
    password = decrypt(payload.get("password_enc"))
    if not password:
        raise PermanentError("password ilegível (SECRET_KEY mudou?)")
    jf = JellyfinClient()
    try:
        await _ensure_jellyfin_account(db, user, jf, password)
    except JellyfinError as exc:
        raise RetryLater(str(exc), 120) from exc
    user.needs_password_sync = False
    await enqueue(db, "reconcile_user", {"user_id": user.id}, dedupe_key=f"reconcile:{user.id}")


async def _reconcile_jellyfin(db: AsyncSession, user: User, access) -> str | None:
    jf = JellyfinClient()
    sa = await get_account(db, user.id, "jellyfin")
    want = access.features.jellyfin.enabled and user.is_active
    if sa is None and not want:
        return None
    sa, jf_user = await _ensure_jellyfin_account(db, user, jf, None)
    policy = jf_user.get("Policy") or {}
    if policy.get("IsAdministrator"):
        sa.applied_state = {"admin": True}
        sa.last_synced_at = utcnow()
        return None  # nunca mexer em administradores do Jellyfin
    desired = build_policy(policy, enabled=want, feature=access.features.jellyfin if want else None)
    changed = any(policy.get(k) != desired.get(k) for k in MANAGED_POLICY_KEYS)
    if changed:
        await jf.update_policy(sa.external_id, desired)
    sa.applied_state = {k: desired.get(k) for k in MANAGED_POLICY_KEYS}
    sa.last_synced_at = utcnow()
    sa.last_error = None
    return "updated" if changed else "ok"


# --------------------------------------------------------------------------- Seerr
async def _reconcile_seerr(db: AsyncSession, user: User, access) -> str | None:
    jf_sa = await get_account(db, user.id, "jellyfin")
    sa = await get_account(db, user.id, "seerr")
    want = access.features.seerr.enabled and user.is_active
    if not want:
        # Sem subscrição: tira as permissões no Seerr (a sessão que lá tenha deixa de poder pedir nada). Guarda as
        # anteriores para as repor quando voltar.
        if sa and sa.external_id and not (sa.applied_state or {}).get("suspended"):
            seerr = SeerrClient()
            before = await seerr.get_permissions(int(sa.external_id))
            if before != 0:
                await seerr.set_permissions(int(sa.external_id), 0)
            sa.applied_state = {"suspended": True, "permissions_before": before}
            sa.last_synced_at = utcnow()
            return "suspended"
        return None
    if not jf_sa or not jf_sa.external_id:
        return None
    seerr = SeerrClient()
    if sa and sa.external_id and (sa.applied_state or {}).get("suspended"):
        await seerr.set_permissions(int(sa.external_id), int((sa.applied_state or {}).get("permissions_before") or 0)
                                    or await seerr.default_permissions())
        sa.applied_state = {}
    seerr_user = None
    if sa and sa.external_id:
        seerr_user = {"id": int(sa.external_id)}
    else:
        seerr_user = await seerr.find_by_jellyfin_id(jf_sa.external_id, user.username)
        if not seerr_user:
            seerr_user = await seerr.import_jellyfin_user(jf_sa.external_id)
        if not seerr_user:
            raise RetryLater("Seerr não importou o utilizador (Jellyfin ainda desativado?)", 300)
        if sa is None:
            sa = ServiceAccount(user_id=user.id, service="seerr")
            db.add(sa)
        sa.external_id = str(seerr_user["id"])
        sa.external_username = user.username
    f = access.features.seerr
    desired = {
        "email": user.email,
        "movieQuotaLimit": f.movie_quota,
        "movieQuotaDays": f.movie_quota_days,
        "tvQuotaLimit": f.tv_quota,
        "tvQuotaDays": f.tv_quota_days,
    }
    if (sa.applied_state or {}) != desired:
        await seerr.update_main_settings(int(sa.external_id), desired)
        sa.applied_state = desired
    sa.last_synced_at = utcnow()
    sa.last_error = None
    return "ok"


# --------------------------------------------------------------------------- Dispatcharr (IPTV)
async def _legacy_iptv(db: AsyncSession, user: User) -> tuple[str | None, str | None]:
    """Credenciais IPTV do site antigo (se houver): reaproveitadas para os aparelhos dos clientes migrados
    continuarem a entrar sem mudar nada."""
    old = await get_account(db, user.id, "iptv")
    if old is None:
        return None, None
    uname = (old.external_username or "").strip()
    pwd = decrypt(old.secret_enc) or ""
    return (uname if USERNAME_XC_RE.match(uname) else None), (pwd if XC_PASSWORD_RE.match(pwd) else None)


async def _reconcile_dispatcharr(db: AsyncSession, user: User, access) -> str | None:
    """TV: cria o utilizador no Dispatcharr quando o plano tem TV, mantém-no ativo enquanto a subscrição durar,
    desativa-o quando acaba e apaga-o ao fim de DISPATCHARR_DELETE_AFTER_DAYS sem TV. A password XC é gerada
    automaticamente (simples) e o cliente vê-a e muda-a no portal — nunca vai por email nem passa pelo admin."""
    s = get_settings()
    f = access.features.iptv
    want = f.enabled and user.is_active
    sa = await get_account(db, user.id, "dispatcharr")
    if sa is None and not want:
        return None
    dc = DispatcharrClient()
    newly_created = False
    if sa is None or not sa.external_id:
        old_user, old_pwd = await _legacy_iptv(db, user)
        xc_username = user.username
        if old_user and old_user.lower() != user.username.lower() and not await dc.find_user(old_user):
            xc_username = old_user
        existing = await dc.find_user(xc_username)
        xc_password = (decrypt(sa.secret_enc) if sa is not None and sa.secret_enc else None) or old_pwd \
            or friendly_password()
        if existing:
            # Só se liga a um utilizador "streamer" que não pertença já a outra conta do portal. Sem isto, quem se
            # registasse com o username de um admin/utilizador do Dispatcharr ficava com a password XC dele
            # (mudada por nós) e, no fim da subscrição, desativava-lhe o acesso.
            other = await db.scalar(select(ServiceAccount).where(ServiceAccount.service == "dispatcharr",
                                                                 ServiceAccount.external_id == str(existing["id"])))
            if other and other.user_id != user.id:
                raise DispatcharrError(f"O utilizador Dispatcharr '{xc_username}' pertence a outra conta do portal")
            if int(existing.get("user_level") or 0) != 0:
                raise DispatcharrError(f"O utilizador Dispatcharr '{xc_username}' não é um utilizador de streaming "
                                       "(nível de administrador/standard) — não é ligado automaticamente")
            remote_id = existing["id"]
        else:
            created = await dc.create_user(username=xc_username, email=user.email, xc_password=xc_password,
                                           stream_limit=f.stream_limit, channel_profiles=f.channel_profiles)
            remote_id = created["id"]
            newly_created = True
        if sa is None:
            sa = ServiceAccount(user_id=user.id, service="dispatcharr")
            db.add(sa)
        sa.external_id = str(remote_id)
        sa.external_username = xc_username
        sa.secret_enc = encrypt(xc_password)
        sa.applied_state = {"enabled": newly_created, "stream_limit": f.stream_limit,
                            "channel_profiles": f.channel_profiles} if newly_created else {}
    desired = ({"enabled": True, "stream_limit": f.stream_limit, "channel_profiles": f.channel_profiles}
               if want else {"enabled": False})
    data = dict(sa.data or {})
    if (sa.applied_state or {}) != desired:
        if want:
            pwd = decrypt(sa.secret_enc) or friendly_password()
            sa.secret_enc = encrypt(pwd)
            await dc.enable(int(sa.external_id), xc_password=pwd, stream_limit=f.stream_limit,
                            channel_profiles=f.channel_profiles)
            data.pop("disabled_at", None)
        else:
            await dc.disable(int(sa.external_id))
            data["disabled_at"] = utcnow().isoformat()
        sa.applied_state = desired
    elif not want and "disabled_at" not in data:
        data["disabled_at"] = utcnow().isoformat()
    if not want and s.dispatcharr_delete_after_days and data.get("disabled_at"):
        since = datetime.fromisoformat(data["disabled_at"])
        if utcnow() - since >= timedelta(days=s.dispatcharr_delete_after_days):
            try:
                await dc.delete_user(int(sa.external_id))
            except DispatcharrError as e:
                if e.status != 404:
                    raise
            await db.delete(sa)
            return "deleted"
    sa.data = data
    # Sem email "IPTV pronto": as credenciais aparecem logo em "Os meus serviços".
    sa.last_synced_at = utcnow()
    sa.last_error = None
    return "ok"


async def set_iptv_password(db: AsyncSession, user: User, password: str | None) -> str:
    """O cliente muda (ou gera de novo) a password da TV a qualquer momento. Aplica-a já no Dispatcharr."""
    sa = await get_account(db, user.id, "dispatcharr")
    if sa is None or not sa.external_id:
        raise DispatcharrError("A tua TV ainda não está criada.")
    pwd = (password or "").strip() or friendly_password()
    if not XC_PASSWORD_RE.match(pwd):
        raise ValueError("A password tem de ter 6 a 32 caracteres: letras, números, ponto, hífen ou _.")
    if (sa.applied_state or {}).get("enabled"):
        f = (await compute_access(db, user)).features.iptv
        await DispatcharrClient().enable(int(sa.external_id), xc_password=pwd, stream_limit=f.stream_limit,
                                         channel_profiles=f.channel_profiles)
    sa.secret_enc = encrypt(pwd)
    sa.last_synced_at = utcnow()
    return pwd


# --------------------------------------------------------------------------- orquestração
@job_handler("reconcile_user")
async def reconcile_user_job(db: AsyncSession, payload: dict) -> None:
    await reconcile_user(db, payload["user_id"])


async def reconcile_user(db: AsyncSession, user_id: str) -> dict:
    s = get_settings()
    user = await db.get(User, user_id)
    if not user:
        return {}
    access = await compute_access(db, user)
    from .oidc_presets import revoke_lost_access

    await revoke_lost_access(db, user, access)
    results: dict[str, str | None] = {}
    errors: list[str] = []
    steps = []
    if s.jellyfin_enabled:
        steps.append(("jellyfin", _reconcile_jellyfin, JellyfinError))
    if s.seerr_enabled and s.jellyfin_enabled:
        steps.append(("seerr", _reconcile_seerr, SeerrError))
    if s.dispatcharr_enabled:
        steps.append(("dispatcharr", _reconcile_dispatcharr, DispatcharrError))
    for name, fn, err_type in steps:
        try:
            results[name] = await fn(db, user, access)
            await db.flush()
        except (err_type, RetryLater) as exc:
            errors.append(f"{name}: {exc}")
            sa = await get_account(db, user.id, name)
            if sa:
                sa.last_error = str(exc)[:1000]
    if errors:
        await db.commit()  # guarda o progresso parcial e erros por serviço
        raise RetryLater("; ".join(errors), 120)
    return results


@job_handler("reconcile_all")
async def reconcile_all_job(db: AsyncSession, payload: dict) -> None:
    ids = (await db.scalars(select(User.id))).all()
    for i, uid in enumerate(ids):
        await enqueue(db, "reconcile_user", {"user_id": uid}, dedupe_key=f"reconcile:{uid}", delay_seconds=i // 20)
