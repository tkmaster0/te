"""Carteira de créditos.

Regras:
  * 1 crédito = 1 cêntimo de euro. O saldo é usado **primeiro** em todas as cobranças de serviços; o que faltar é
    cobrado ao método de pagamento na mesma cobrança (a "maneira tradicional").
  * Carregamento único: mínimo `WALLET_MIN_TOPUP_CENTS` (5 €). Com um método guardado é cobrado logo; sem método,
    abre a página do fornecedor.
  * Carregamento mensal: somado à cobrança do dia de faturação. Uma só cobrança por mês: o carregamento paga os
    serviços desse mês e o que sobrar fica na carteira. Se o saldo já cobrir os serviços, o carregamento desse mês
    é saltado (`monthly_skip_when_covered`) — mensalidade "gratuita".
  * Contas novas (`billing_mode="wallet"`) só pagam serviços pela carteira; as antigas (`legacy`) podem continuar
    a pagar cada serviço diretamente, mas o portal incentiva a mudança para os créditos mensais.

Garantias:
  * Razão imutável (`wallet_transactions`); o saldo em `wallets.balance_cents` é atualizado na mesma transação.
  * Cada efeito tem uma chave de idempotência: webhooks repetidos, novas tentativas ou dois cliques não creditam
    nem debitam duas vezes.
  * O que é debitado para uma cobrança fica reservado a essa cobrança; se for anulada, volta à carteira.
"""
from __future__ import annotations

import logging
from datetime import datetime

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from ..db import is_postgres, utcnow
from ..models import Invoice, InvoiceLine, Subscription, SubStatus, User, Wallet, WalletTransaction
from .audit import audit
from .subscriptions import fmt_money

log = logging.getLogger("tkportal.wallet")

TOPUP_KINDS = ("topup", "mtopup", "topup_use")
TOPUP_CREDIT_KINDS = ("topup", "mtopup")
UNPAID = ("open", "failed")


class WalletError(Exception):
    """Erro de regra de negócio da carteira (mostrado ao cliente)."""


# =========================================================================== saldo e razão
async def get_wallet(db: AsyncSession, user_id: str, *, lock: bool = False) -> Wallet:
    """Carteira do cliente (criada se não existir). `lock=True` bloqueia a linha até ao fim da transação."""
    w = await db.get(Wallet, user_id)
    if w is None:
        w = Wallet(user_id=user_id, balance_cents=0)
        db.add(w)
        await db.flush()
    if lock and is_postgres():
        locked = await db.scalar(select(Wallet).where(Wallet.user_id == user_id).with_for_update()
                                 .execution_options(populate_existing=True))
        w = locked or w
    return w


async def balance(db: AsyncSession, user_id: str) -> int:
    w = await db.get(Wallet, user_id)
    return w.balance_cents if w else 0


async def post(db: AsyncSession, user_id: str, amount_cents: int, kind: str, description: str, *,
               invoice_id: str | None = None, game_round_id: str | None = None, key: str | None = None,
               actor_id: str | None = None, allow_negative: bool = False, wallet: Wallet | None = None
               ) -> WalletTransaction | None:
    """Regista um movimento e atualiza o saldo. Idempotente por `key` (devolve None se já tinha sido feito)."""
    if amount_cents == 0:
        return None
    if key and await db.scalar(select(WalletTransaction.id).where(WalletTransaction.idempotency_key == key)):
        return None
    w = wallet or await get_wallet(db, user_id, lock=True)
    new_balance = w.balance_cents + amount_cents
    if new_balance < 0 and not allow_negative:
        raise WalletError("Saldo insuficiente na carteira.")
    w.balance_cents = new_balance
    w.updated_at = utcnow()
    tx = WalletTransaction(user_id=user_id, kind=kind, amount_cents=amount_cents, balance_after_cents=new_balance,
                           description=description[:255], invoice_id=invoice_id, game_round_id=game_round_id,
                           idempotency_key=key, actor_id=actor_id)
    db.add(tx)
    await db.flush()
    return tx


async def transactions(db: AsyncSession, user_id: str, *, limit: int = 50, before_id: int | None = None
                       ) -> list[WalletTransaction]:
    q = select(WalletTransaction).where(WalletTransaction.user_id == user_id)
    if before_id:
        q = q.where(WalletTransaction.id < before_id)
    return list((await db.scalars(q.order_by(WalletTransaction.id.desc()).limit(limit))).all())


# =========================================================================== regras de modo
def is_wallet_only(user: User) -> bool:
    s = get_settings()
    return bool(s.wallet_enabled and s.wallet_monthly_enabled and s.wallet_only_for_new_users
                and user.billing_mode == "wallet")


def monthly_enabled() -> bool:
    s = get_settings()
    return bool(s.wallet_enabled and s.wallet_monthly_enabled)


async def monthly_recurring_cents(db: AsyncSession, user_id: str) -> int:
    """Quanto custam por mês os serviços que continuam (base para sugerir o carregamento mensal)."""
    from ..models import Plan
    from .billing import live_subs, monthly_equivalent, plan_price

    total = 0.0
    for sub in await live_subs(db, user_id):
        if sub.status in (SubStatus.canceling, SubStatus.suspended) or sub.cancel_at_period_end:
            continue
        plan = await db.get(Plan, sub.pending_plan_id or sub.plan_id)
        if plan is None:
            continue
        total += monthly_equivalent(plan_price(sub, plan), plan)
    return round(total)


def suggest_monthly(recurring_cents: int) -> int:
    """Carregamento mensal sugerido: o custo mensal arredondado ao euro, nunca abaixo do mínimo."""
    s = get_settings()
    if recurring_cents <= 0:
        return s.wallet_min_monthly_cents
    euros = -(-recurring_cents // 100)
    return max(s.wallet_min_monthly_cents, euros * 100)


# =========================================================================== cobranças
async def settle_debt_into_lines(db: AsyncSession, user_id: str, inv: Invoice) -> InvoiceLine | None:
    """Saldo negativo (ex.: carregamento estornado já gasto) entra nesta cobrança e a carteira volta a 0."""
    w = await get_wallet(db, user_id, lock=True)
    if w.balance_cents >= 0:
        return None
    debt = -w.balance_cents
    await post(db, user_id, debt, "debt", f"Saldo negativo passado para a cobrança {inv.number}",
               invoice_id=inv.id, key=f"debt-{inv.id}", wallet=w)
    line = InvoiceLine(user_id=user_id, invoice_id=inv.id, kind="adjustment", amount_cents=debt,
                       description="Saldo negativo da carteira (carregamento estornado)")
    db.add(line)
    return line


async def use_for_invoice(db: AsyncSession, user_id: str, inv: Invoice, amount_cents: int) -> int:
    """Paga até `amount_cents` desta cobrança com o saldo. Devolve quanto foi usado (e acrescenta a linha)."""
    if amount_cents <= 0 or not get_settings().wallet_enabled:
        return 0
    w = await get_wallet(db, user_id, lock=True)
    use = min(max(w.balance_cents, 0), amount_cents)
    if use <= 0:
        return 0
    n = int(await db.scalar(select(func.count()).select_from(InvoiceLine).where(
        InvoiceLine.invoice_id == inv.id, InvoiceLine.kind == "wallet")) or 0)
    tx = await post(db, user_id, -use, "invoice", f"Pagamento da cobrança {inv.number}", invoice_id=inv.id,
                    key=f"use-{inv.id}-{n}", wallet=w)
    if tx is None:
        return 0
    db.add(InvoiceLine(user_id=user_id, invoice_id=inv.id, kind="wallet", amount_cents=-use,
                       description="Pago com o saldo da carteira"))
    await db.flush()
    return use


def topup_lines(inv: Invoice, topup_cents: int, remaining_cents: int, *, monthly: bool = True) -> list[InvoiceLine]:
    """Linhas do carregamento mensal: +T entra na carteira quando pago; -min(T, resto) paga logo esta cobrança."""
    if topup_cents <= 0:
        return []
    label = "Carregamento mensal da carteira" if monthly else "Carregamento da carteira"
    out = [InvoiceLine(user_id=inv.user_id, invoice_id=inv.id, kind="mtopup" if monthly else "topup",
                       amount_cents=topup_cents,
                       description=f"{label} ({fmt_money(topup_cents)})")]
    use = min(topup_cents, max(remaining_cents, 0))
    if use > 0:
        out.append(InvoiceLine(user_id=inv.user_id, invoice_id=inv.id, kind="topup_use", amount_cents=-use,
                               description="Parte do carregamento usada nesta cobrança"))
    return out


async def _reversal_round(db: AsyncSession, inv: Invoice) -> int:
    return int(await db.scalar(select(func.count()).select_from(WalletTransaction).where(
        WalletTransaction.invoice_id == inv.id, WalletTransaction.kind == "reversal")) or 0)


async def credit_topups(db: AsyncSession, inv: Invoice) -> int:
    """Cobrança paga: credita os carregamentos que tinha (menos a parte já usada nela) + bónus mensal."""
    lines = (await db.scalars(select(InvoiceLine).where(InvoiceLine.invoice_id == inv.id,
                                                        InvoiceLine.kind.in_(TOPUP_KINDS)))).all()
    if not lines:
        return 0
    s = get_settings()
    rnd = await _reversal_round(db, inv)
    credited = 0
    topup = sum(ln.amount_cents for ln in lines if ln.kind in TOPUP_CREDIT_KINDS)
    used = -sum(ln.amount_cents for ln in lines if ln.kind == "topup_use")
    monthly = any(ln.kind == "mtopup" for ln in lines)
    if topup > 0:
        tx = await post(db, inv.user_id, topup, "monthly_topup" if monthly else "topup",
                        f"Carregamento ({inv.number})", invoice_id=inv.id, key=f"topup-{inv.id}-{rnd}")
        if tx is not None:
            credited += topup
            if used > 0:
                await post(db, inv.user_id, -used, "invoice", f"Pagamento da cobrança {inv.number}",
                           invoice_id=inv.id, key=f"topupuse-{inv.id}-{rnd}", allow_negative=True)
                credited -= used
            if monthly and s.wallet_monthly_bonus_percent > 0:
                bonus = topup * s.wallet_monthly_bonus_percent // 100
                if bonus > 0:
                    await post(db, inv.user_id, bonus, "bonus",
                               f"Bónus de {s.wallet_monthly_bonus_percent}% do carregamento mensal",
                               invoice_id=inv.id, key=f"topupbonus-{inv.id}-{rnd}")
                    credited += bonus
    if credited > 0:
        audit(db, "wallet.topup_credited", target_type="user", target_id=inv.user_id, invoice=inv.id,
              amount=credited)
    return credited


async def reverse_topups(db: AsyncSession, inv: Invoice, reason: str) -> int:
    """Pagamento estornado depois de creditado: retira da carteira o que o carregamento tinha posto (pode ficar
    negativo; o saldo negativo entra na próxima cobrança)."""
    rnd = await _reversal_round(db, inv)
    got = await db.scalar(select(func.coalesce(func.sum(WalletTransaction.amount_cents), 0)).where(
        WalletTransaction.invoice_id == inv.id,
        WalletTransaction.idempotency_key.in_([f"topup-{inv.id}-{rnd}", f"topupuse-{inv.id}-{rnd}",
                                               f"topupbonus-{inv.id}-{rnd}"])))
    got = int(got or 0)
    if got <= 0:
        return 0
    await post(db, inv.user_id, -got, "reversal", f"Carregamento estornado ({inv.number}): {reason}"[:255],
               invoice_id=inv.id, key=f"reversal-{inv.id}-{rnd}", allow_negative=True)
    audit(db, "wallet.topup_reversed", target_type="user", target_id=inv.user_id, invoice=inv.id, amount=got)
    return got


async def refund_invoice(db: AsyncSession, inv: Invoice, reason: str) -> int:
    """Cobrança anulada: o saldo que lhe tinha sido reservado volta à carteira."""
    used = -int(await db.scalar(select(func.coalesce(func.sum(InvoiceLine.amount_cents), 0)).where(
        InvoiceLine.invoice_id == inv.id, InvoiceLine.kind == "wallet")) or 0)
    if used <= 0:
        return 0
    tx = await post(db, inv.user_id, used, "refund", f"Devolvido: cobrança {inv.number} anulada ({reason})"[:255],
                    invoice_id=inv.id, key=f"void-{inv.id}")
    return used if tx else 0


async def drop_topups(db: AsyncSession, inv: Invoice) -> int:
    """Tira de uma cobrança por pagar o carregamento que trazia (já não faz sentido cobrá-lo). Devolve a redução."""
    lines = (await db.scalars(select(InvoiceLine).where(InvoiceLine.invoice_id == inv.id,
                                                        InvoiceLine.kind.in_(TOPUP_KINDS)))).all()
    delta = sum(ln.amount_cents for ln in lines)
    for ln in lines:
        await db.delete(ln)
    if delta:
        inv.total_cents = max(0, inv.total_cents - delta)
        inv.subtotal_cents = max(0, inv.subtotal_cents - delta)
    await db.flush()
    return delta


async def settle_unpaid(db: AsyncSession, user_id: str) -> int:
    """Depois de entrar saldo: paga com ele as cobranças em atraso (as que não estão já submetidas ao banco)."""
    from . import billing

    if not get_settings().wallet_enabled:
        return 0
    invs = (await db.scalars(select(Invoice).where(Invoice.user_id == user_id, Invoice.status.in_(UNPAID),
                                                   Invoice.kind != "topup").order_by(Invoice.created_at))).all()
    paid = 0
    for inv in invs:
        if await balance(db, user_id) <= 0:
            break
        inv = await billing.lock_invoice(db, inv)
        if inv.status not in UNPAID:
            continue
        # Um carregamento que falhou não se paga com a própria carteira: sai da cobrança.
        await drop_topups(db, inv)
        used = await use_for_invoice(db, user_id, inv, inv.total_cents)
        if used:
            inv.total_cents -= used
            paid += used
        if inv.total_cents <= 0:
            inv.total_cents = 0
            await billing.mark_paid(db, inv)
    return paid


# =========================================================================== carregamentos
async def create_topup_invoice(db: AsyncSession, user: User, amount_cents: int, *, now: datetime | None = None
                               ) -> Invoice:
    from .billing import next_number

    s = get_settings()
    if not s.wallet_enabled:
        raise WalletError("A carteira não está disponível.")
    if amount_cents < s.wallet_min_topup_cents:
        raise WalletError(f"O carregamento mínimo é de {fmt_money(s.wallet_min_topup_cents)}.")
    if amount_cents > s.wallet_max_topup_cents:
        raise WalletError(f"O carregamento máximo é de {fmt_money(s.wallet_max_topup_cents)}.")
    now = now or utcnow()
    inv = Invoice(user_id=user.id, number=await next_number(db, now.year), kind="topup", status="open",
                  period_start=now, created_at=now, subtotal_cents=amount_cents, total_cents=amount_cents)
    db.add(inv)
    await db.flush()
    db.add(InvoiceLine(user_id=user.id, invoice_id=inv.id, kind="topup", amount_cents=amount_cents,
                       description=f"Carregamento da carteira ({fmt_money(amount_cents)})"))
    await db.flush()
    audit(db, "wallet.topup_started", actor=user, target_type="user", target_id=user.id, amount=amount_cents)
    return inv


async def set_monthly(db: AsyncSession, user: User, amount_cents: int | None, *, skip_when_covered: bool = True
                      ) -> Wallet:
    """Liga/altera/desliga o carregamento mensal. Sem pro-rata: o carregamento é feito no dia de faturação."""
    from .billing import anchor_on, next_anchor

    s = get_settings()
    w = await get_wallet(db, user.id, lock=True)
    if amount_cents is None or amount_cents <= 0:
        if w.monthly_topup_cents:
            audit(db, "wallet.monthly_off", actor=user, target_type="user", target_id=user.id)
        w.monthly_topup_cents = None
        w.monthly_since = None
        return w
    if not monthly_enabled():
        raise WalletError("O carregamento mensal não está disponível — os serviços são cobrados pelo teu método de "
                          "pagamento.")
    if amount_cents < s.wallet_min_monthly_cents:
        raise WalletError(f"O carregamento mensal mínimo é de {fmt_money(s.wallet_min_monthly_cents)}.")
    if amount_cents > s.wallet_max_monthly_cents:
        raise WalletError(f"O carregamento mensal máximo é de {fmt_money(s.wallet_max_monthly_cents)}.")
    was = w.monthly_topup_cents
    w.monthly_topup_cents = amount_cents
    w.monthly_skip_when_covered = skip_when_covered
    w.monthly_since = w.monthly_since or utcnow()
    now = utcnow()
    if not user.billing_anchor_day:
        # Cliente sem dia de faturação: o dia passa a ser hoje e o primeiro carregamento é feito já (o ciclo corre
        # dentro de minutos), para ter logo saldo para aderir aos serviços.
        user.billing_anchor_day = min(now.day, 28)
        user.next_billing_at = now
    elif user.next_billing_at is None:
        # Já tem dia de faturação: o primeiro carregamento é no próximo (o de hoje, se ainda não passou a hora).
        today = anchor_on(now.year, now.month, user.billing_anchor_day)
        user.next_billing_at = today if today > now else next_anchor(user.billing_anchor_day, now)
    audit(db, "wallet.monthly_set", actor=user, target_type="user", target_id=user.id, old=was, new=amount_cents,
          skip_when_covered=skip_when_covered)
    return w


async def convert_to_monthly(db: AsyncSession, user: User, *, dry_run: bool = False, actor: User | None = None
                             ) -> dict:
    """Passa um cliente antigo para os créditos mensais sem ele ter de fazer nada.

    O carregamento mensal fica igual ao que já paga por mês (arredondado ao euro), no mesmo dia e com o mesmo método
    (mandato GoCardless ou cartão Stripe guardados): a cobrança do mês não muda, passa só a entrar pela carteira.
    """
    from .billing import usable_methods

    recurring = await monthly_recurring_cents(db, user.id)
    w = await get_wallet(db, user.id)
    out = {"user": user.username, "recurring_cents": recurring, "current_monthly_cents": w.monthly_topup_cents}
    if not monthly_enabled():
        return {**out, "result": "carregamento mensal desligado"}
    if w.monthly_topup_cents:
        return {**out, "result": "já tem carregamento mensal"}
    if recurring <= 0:
        return {**out, "result": "sem serviços a pagar"}
    if not await usable_methods(db, user.id):
        return {**out, "result": "sem método de pagamento válido"}
    amount = suggest_monthly(recurring)
    out["monthly_cents"] = amount
    if dry_run:
        return {**out, "result": "seria convertido"}
    await set_monthly(db, user, amount, skip_when_covered=True)
    audit(db, "wallet.converted", actor=actor, target_type="user", target_id=user.id, amount=amount)
    return {**out, "result": "convertido"}


async def admin_adjust(db: AsyncSession, admin: User, user: User, amount_cents: int, reason: str) -> WalletTransaction:
    if amount_cents == 0:
        raise WalletError("Indica um valor diferente de zero.")
    tx = await post(db, user.id, amount_cents, "adjustment", reason or "Ajuste do administrador",
                    actor_id=admin.id)
    assert tx is not None
    audit(db, "wallet.adjust", actor=admin, target_type="user", target_id=user.id, amount=amount_cents, reason=reason)
    if amount_cents > 0:
        await settle_unpaid(db, user.id)
    return tx


async def summary(db: AsyncSession, user: User) -> dict:
    from ..games.service import games_available
    from .billing import usable_methods

    s = get_settings()
    w = await get_wallet(db, user.id)
    recurring = await monthly_recurring_cents(db, user.id)
    pending_topups = int(await db.scalar(select(func.coalesce(func.sum(Invoice.total_cents), 0)).where(
        Invoice.user_id == user.id, Invoice.kind == "topup", Invoice.status == "processing")) or 0)
    has_services = bool(await db.scalar(select(Subscription.id).where(
        Subscription.user_id == user.id, Subscription.provider == "portal",
        Subscription.status.in_([st.value for st in (SubStatus.active, SubStatus.past_due, SubStatus.bonus)]))
        .limit(1)))
    covers_months = (w.balance_cents // recurring) if recurring > 0 else None
    return {
        "enabled": s.wallet_enabled,
        "balance_cents": w.balance_cents,
        "pending_topup_cents": pending_topups,
        "monthly_enabled": monthly_enabled(),
        "monthly_topup_cents": w.monthly_topup_cents if monthly_enabled() else None,
        "monthly_skip_when_covered": w.monthly_skip_when_covered,
        "monthly_bonus_percent": s.wallet_monthly_bonus_percent,
        "recurring_cents": recurring,
        "suggested_monthly_cents": suggest_monthly(recurring),
        "covers_months": covers_months,
        "wallet_only": is_wallet_only(user),
        "billing_mode": user.billing_mode,
        "has_services": has_services,
        "has_payment_method": bool(await usable_methods(db, user.id)),
        "min_topup_cents": s.wallet_min_topup_cents,
        "max_topup_cents": s.wallet_max_topup_cents,
        "min_monthly_cents": s.wallet_min_monthly_cents,
        "max_monthly_cents": s.wallet_max_monthly_cents,
        "next_billing_at": user.next_billing_at.isoformat() if user.next_billing_at else None,
        "games_enabled": games_available(user),
    }
