"""Catálogo com produtos em beta fechado.

Um produto com `requires_invite` (ex.: TKFLIX) só aparece com o nome verdadeiro e só pode ser subscrito por quem:
  * se registou com um convite que o desbloqueia (um convite de um cliente TKFLIX desbloqueia o TKFLIX), ou
  * meteu um código de convite depois, na Loja, ou
  * já o tinha antes (clientes migrados / com subscrição ou oferta).

Para os outros aparece com `locked_name` (ex.: "TK CDN"), desativado, com "Beta testing fechado" e um campo para
meter o código.
"""
from __future__ import annotations

from sqlalchemy import func, or_, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from ..db import utcnow
from ..models import Grant, InviteCode, Plan, Product, Subscription, User
from .audit import audit

DEFAULT_LOCKED_NAME = "TK CDN"
DEFAULT_LOCKED_DESCRIPTION = "Beta testing fechado"


class UnlockError(Exception):
    pass


def product_unlocked(user: User | None, product: Product) -> bool:
    if not product.requires_invite:
        return True
    if user is None:
        return False
    if user.is_admin:
        return True
    return product.code in (user.unlocked_products or [])


def unlock(user: User, codes: list[str]) -> list[str]:
    """Junta produtos desbloqueados ao cliente. Devolve os novos."""
    have = list(user.unlocked_products or [])
    new = [c for c in codes if c not in have]
    if new:
        user.unlocked_products = [*have, *new]
    return new


async def gated_codes(db: AsyncSession) -> list[str]:
    return list((await db.scalars(select(Product.code).where(Product.requires_invite.is_(True)))).all())


async def invite_unlocks(db: AsyncSession, invite: InviteCode) -> list[str]:
    """Produtos que um convite desbloqueia (ver InviteCode.unlocks)."""
    gated = await gated_codes(db)
    if invite.unlocks is not None:
        return [c for c in invite.unlocks if c in gated]
    creator = await db.get(User, invite.created_by_id) if invite.created_by_id else None
    if creator is None or creator.is_admin:
        return gated  # convite do sistema/admin sem indicação: desbloqueia todos
    return [c for c in gated if c in (creator.unlocked_products or [])]


async def backfill_owned(db: AsyncSession, user: User) -> list[str]:
    """Quem já tem (ou teve) o produto fica com ele desbloqueado — nunca esconder um serviço que o cliente usa."""
    gated = (await db.scalars(select(Product).where(Product.requires_invite.is_(True)))).all()
    owned = []
    for p in gated:
        if p.code in (user.unlocked_products or []):
            continue
        has_sub = await db.scalar(select(Subscription.id).where(Subscription.user_id == user.id,
                                                                Subscription.product_id == p.id).limit(1))
        has_grant = await db.scalar(select(Grant.id).join(Plan, Plan.id == Grant.plan_id).where(
            Grant.user_id == user.id, Plan.product_id == p.id).limit(1))
        if has_sub or has_grant:
            owned.append(p.code)
    return unlock(user, owned)


async def unlock_with_code(db: AsyncSession, user: User, code: str) -> list[str]:
    """Desbloqueia produtos com um código de convite (gasta um uso do código)."""
    code = (code or "").strip().upper()
    inv = await db.scalar(select(InviteCode).where(func.upper(InviteCode.code) == code))
    if inv is None or inv.disabled or inv.uses >= inv.max_uses or (inv.expires_at and inv.expires_at <= utcnow()):
        raise UnlockError("Código inválido ou já utilizado.")
    if inv.created_by_id == user.id:
        raise UnlockError("Não podes usar um código teu.")
    codes = await invite_unlocks(db, inv)
    new = [c for c in codes if c not in (user.unlocked_products or [])]
    if not new:
        raise UnlockError("Este código não desbloqueia nada de novo para ti.")
    res = await db.execute(update(InviteCode).where(InviteCode.id == inv.id, InviteCode.uses < InviteCode.max_uses)
                           .values(uses=InviteCode.uses + 1).execution_options(synchronize_session=False))
    if not res.rowcount:
        raise UnlockError("Código inválido ou já utilizado.")
    unlock(user, new)
    if user.referred_by_id is None and inv.created_by_id and inv.created_by_id != user.id:
        # Conta para o bónus de quem convidou, como se se tivesse registado com o convite.
        user.referred_by_id = inv.created_by_id
        user.invite_code_id = user.invite_code_id or inv.id
    audit(db, "catalog.unlock", actor=user, target_type="user", target_id=user.id, code=inv.code, products=new)
    return new


def display(product: Product, unlocked: bool) -> dict:
    """Nome e descrição a mostrar (o nome verdadeiro só para quem tem o produto desbloqueado)."""
    if unlocked:
        return {"name": product.name, "description": product.description, "locked": False}
    return {"name": product.locked_name or DEFAULT_LOCKED_NAME,
            "description": product.locked_description or DEFAULT_LOCKED_DESCRIPTION, "locked": True}


async def visible_product_ids(db: AsyncSession, user: User | None) -> set[int]:
    rows = (await db.scalars(select(Product).where(or_(Product.requires_invite.is_(False),
                                                       Product.requires_invite.is_(None))))).all()
    ids = {p.id for p in rows}
    for p in (await db.scalars(select(Product).where(Product.requires_invite.is_(True)))).all():
        if product_unlocked(user, p):
            ids.add(p.id)
    return ids
