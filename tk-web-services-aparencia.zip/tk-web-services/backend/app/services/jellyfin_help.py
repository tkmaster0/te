"""Ajuda dentro das apps nativas do Jellyfin: Android TV, Swiftfin (iOS/tvOS), Moonfin em todas as plataformas, Roku…

Estas apps não correm o jellyfin-web, por isso o JavaScript Injector (botão «Ajuda») não chega lá. O que todas mostram
é o que está na biblioteca. Por isso o portal cria uma coleção «Ajuda» com:
  * um cartaz e uma imagem de fundo com um QR code para {public_url}/ajuda (o chat com o assistente, no telemóvel);
  * uma descrição com o link curto e, se estiver configurado, o WhatsApp do assistente.
O mesmo assistente (e a mesma memória) está no widget do jellyfin-web, no portal e no WhatsApp.

As imagens são PNG gerados aqui, sem bibliotecas de imagem: o QR vem do `qrcode` (só a matriz) e o texto é desenhado
com uma fonte bitmap 5×7.
"""
from __future__ import annotations

import base64
import logging
import struct
import unicodedata
import zlib
from typing import Any
from urllib.parse import urlparse

import qrcode
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from ..db import utcnow
from ..integrations.jellyfin import JellyfinClient, JellyfinError
from ..models import ConfigEntry

log = logging.getLogger("tkportal.jellyfin_help")

STATE_KEY = "_jellyfin_help_collection"
NAME = "Ajuda"
SORT_NAME = "!0 Ajuda"   # aparece primeiro nas coleções
TAG = "tkws-ajuda"

BG = (11, 11, 12)
YELLOW = (245, 197, 24)
WHITE = (255, 255, 255)
TEXT = (237, 237, 237)
MUTED = (161, 161, 170)

# ---------------------------------------------------------------------------------------------- fonte bitmap 5×7
_GLYPHS: dict[str, tuple[str, ...]] = {
    "A": (".###.", "#...#", "#...#", "#####", "#...#", "#...#", "#...#"),
    "B": ("####.", "#...#", "#...#", "####.", "#...#", "#...#", "####."),
    "C": (".###.", "#...#", "#....", "#....", "#....", "#...#", ".###."),
    "D": ("####.", "#...#", "#...#", "#...#", "#...#", "#...#", "####."),
    "E": ("#####", "#....", "#....", "####.", "#....", "#....", "#####"),
    "F": ("#####", "#....", "#....", "####.", "#....", "#....", "#...."),
    "G": (".###.", "#...#", "#....", "#.###", "#...#", "#...#", ".####"),
    "H": ("#...#", "#...#", "#...#", "#####", "#...#", "#...#", "#...#"),
    "I": (".###.", "..#..", "..#..", "..#..", "..#..", "..#..", ".###."),
    "J": ("..###", "...#.", "...#.", "...#.", "...#.", "#..#.", ".##.."),
    "K": ("#...#", "#..#.", "#.#..", "##...", "#.#..", "#..#.", "#...#"),
    "L": ("#....", "#....", "#....", "#....", "#....", "#....", "#####"),
    "M": ("#...#", "##.##", "#.#.#", "#.#.#", "#...#", "#...#", "#...#"),
    "N": ("#...#", "#...#", "##..#", "#.#.#", "#..##", "#...#", "#...#"),
    "O": (".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###."),
    "P": ("####.", "#...#", "#...#", "####.", "#....", "#....", "#...."),
    "Q": (".###.", "#...#", "#...#", "#...#", "#.#.#", "#..#.", ".##.#"),
    "R": ("####.", "#...#", "#...#", "####.", "#.#..", "#..#.", "#...#"),
    "S": (".####", "#....", "#....", ".###.", "....#", "....#", "####."),
    "T": ("#####", "..#..", "..#..", "..#..", "..#..", "..#..", "..#.."),
    "U": ("#...#", "#...#", "#...#", "#...#", "#...#", "#...#", ".###."),
    "V": ("#...#", "#...#", "#...#", "#...#", "#...#", ".#.#.", "..#.."),
    "W": ("#...#", "#...#", "#...#", "#.#.#", "#.#.#", "#.#.#", ".#.#."),
    "X": ("#...#", "#...#", ".#.#.", "..#..", ".#.#.", "#...#", "#...#"),
    "Y": ("#...#", "#...#", ".#.#.", "..#..", "..#..", "..#..", "..#.."),
    "Z": ("#####", "....#", "...#.", "..#..", ".#...", "#....", "#####"),
    "0": (".###.", "#...#", "#..##", "#.#.#", "##..#", "#...#", ".###."),
    "1": ("..#..", ".##..", "..#..", "..#..", "..#..", "..#..", ".###."),
    "2": (".###.", "#...#", "....#", "...#.", "..#..", ".#...", "#####"),
    "3": ("#####", "...#.", "..#..", "...#.", "....#", "#...#", ".###."),
    "4": ("...#.", "..##.", ".#.#.", "#..#.", "#####", "...#.", "...#."),
    "5": ("#####", "#....", "####.", "....#", "....#", "#...#", ".###."),
    "6": ("..##.", ".#...", "#....", "####.", "#...#", "#...#", ".###."),
    "7": ("#####", "....#", "...#.", "..#..", ".#...", ".#...", ".#..."),
    "8": (".###.", "#...#", "#...#", ".###.", "#...#", "#...#", ".###."),
    "9": (".###.", "#...#", "#...#", ".####", "....#", "...#.", ".##.."),
    " ": (".....",) * 7,
    ".": (".....", ".....", ".....", ".....", ".....", ".##..", ".##.."),
    ":": (".....", ".##..", ".##..", ".....", ".##..", ".##..", "....."),
    "/": (".....", "....#", "...#.", "..#..", ".#...", "#....", "....."),
    "-": (".....", ".....", ".....", "#####", ".....", ".....", "....."),
    "+": (".....", "..#..", "..#..", "#####", "..#..", "..#..", "....."),
}
# Acentos do português (desenhados por cima/baixo da letra base).
_MARKS: dict[str, tuple[int, tuple[str, ...]]] = {
    "́": (-3, ("...#.", "..#..")),   # agudo
    "̀": (-3, (".#...", "..#..")),   # grave
    "̂": (-3, ("..#..", ".#.#.")),   # circunflexo
    "̃": (-3, (".##.#", "#.##.")),   # til
    "̧": (7, ("..#..", ".##..")),    # cedilha
}


def _chars(text: str) -> list[tuple[str, list[str]]]:
    out = []
    for ch in text.upper():
        base, *marks = unicodedata.normalize("NFD", ch)
        out.append((base if base in _GLYPHS else " ", [m for m in marks if m in _MARKS]))
    return out


def text_width(text: str, scale: int) -> int:
    n = len(_chars(text))
    return max(0, n * 6 * scale - scale)


class Canvas:
    def __init__(self, width: int, height: int, color: tuple[int, int, int] = BG):
        self.w, self.h = width, height
        self.px = bytearray(bytes(color) * (width * height))

    def rect(self, x: int, y: int, w: int, h: int, color: tuple[int, int, int]) -> None:
        x0, y0, x1, y1 = max(0, x), max(0, y), min(self.w, x + w), min(self.h, y + h)
        if x1 <= x0 or y1 <= y0:
            return
        row = bytes(color) * (x1 - x0)
        for yy in range(y0, y1):
            i = (yy * self.w + x0) * 3
            self.px[i:i + len(row)] = row

    def _pattern(self, x: int, y: int, rows: tuple[str, ...] | list[str], scale: int, color) -> None:
        for r, line in enumerate(rows):
            for c, bit in enumerate(line):
                if bit == "#":
                    self.rect(x + c * scale, y + r * scale, scale, scale, color)

    def text(self, x: int, y: int, text: str, scale: int, color) -> None:
        for i, (base, marks) in enumerate(_chars(text)):
            cx = x + i * 6 * scale
            self._pattern(cx, y, _GLYPHS[base], scale, color)
            for m in marks:
                dy, rows = _MARKS[m]
                self._pattern(cx, y + dy * scale, rows, scale, color)

    def text_center(self, y: int, text: str, scale: int, color, *, x0: int = 0, width: int | None = None) -> None:
        width = self.w - x0 if width is None else width
        self.text(x0 + (width - text_width(text, scale)) // 2, y, text, scale, color)

    def qr(self, x: int, y: int, size: int, data: str) -> None:
        """Quadrado branco size×size com o QR centrado (zona de silêncio de 4 módulos)."""
        q = qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_M, border=0)
        q.add_data(data)
        q.make(fit=True)
        matrix = q.get_matrix()
        n = len(matrix)
        mod = max(1, size // (n + 8))
        off = (size - n * mod) // 2
        self.rect(x, y, size, size, WHITE)
        for r, row in enumerate(matrix):
            for c, dark in enumerate(row):
                if dark:
                    self.rect(x + off + c * mod, y + off + r * mod, mod, mod, (0, 0, 0))

    def png(self) -> bytes:
        stride = self.w * 3
        raw = b"".join(b"\x00" + bytes(self.px[y * stride:(y + 1) * stride]) for y in range(self.h))

        def chunk(kind: bytes, data: bytes) -> bytes:
            return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xFFFFFFFF)

        return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", self.w, self.h, 8, 2, 0, 0, 0))
                + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))


# ---------------------------------------------------------------------------------------------- conteúdo
def help_url() -> str:
    return f"{get_settings().public_url.rstrip('/')}/ajuda"


def short_url() -> str:
    p = urlparse(help_url())
    return f"{p.netloc}{p.path}"


def whatsapp() -> str | None:
    digits = "".join(ch for ch in (get_settings().whatsapp_number or "") if ch.isdigit())
    return digits or None


def _whatsapp_label(digits: str) -> str:
    if digits.startswith("351") and len(digits) == 12:
        return f"+351 {digits[3:6]} {digits[6:9]} {digits[9:]}"
    return f"+{digits}"


def _fit(text: str, max_width: int, max_scale: int) -> int:
    return max(1, min(max_scale, max_width // max(1, len(text) * 6)))


def poster_png() -> bytes:
    """Cartaz 2:3 (600×900) — o que aparece na grelha de todas as apps."""
    c = Canvas(600, 900)
    c.rect(0, 0, 600, 12, YELLOW)
    c.text_center(64, "AJUDA", 16, YELLOW)
    c.text_center(212, "SUPORTE TKFLIX", 5, TEXT)
    c.qr(110, 282, 380, help_url())
    c.text_center(704, "ABRE NO TELEMÓVEL", 4, TEXT)
    url = short_url()
    c.text_center(756, url, _fit(url, 560, 3), YELLOW)
    if wa := whatsapp():
        label = f"WHATSAPP {_whatsapp_label(wa)}"
        c.text_center(806, label, _fit(label, 560, 3), MUTED)
    c.rect(0, 888, 600, 12, YELLOW)
    return c.png()


def backdrop_png() -> bytes:
    """16:9 (1280×720) — fundo da página de detalhes (Android TV, Moonfin) e miniatura nas filas."""
    c = Canvas(1280, 720)
    c.rect(0, 0, 1280, 10, YELLOW)
    left, width = 70, 620
    c.text(left, 150, "AJUDA", 16, YELLOW)
    c.text(left, 300, "SUPORTE TKFLIX", 6, TEXT)
    c.text(left, 380, "ABRE NO TELEMÓVEL", 4, TEXT)
    url = short_url()
    c.text(left, 440, url, _fit(url, width, 4), YELLOW)
    if wa := whatsapp():
        label = f"WHATSAPP {_whatsapp_label(wa)}"
        c.text(left, 500, label, _fit(label, width, 4), MUTED)
    c.qr(760, 140, 440, help_url())
    c.rect(0, 710, 1280, 10, YELLOW)
    return c.png()


def overview() -> str:
    lines = [
        "Precisas de ajuda? Aponta a câmara do telemóvel ao código desta imagem ou abre "
        f"{short_url()} — o assistente trata de legendas, reprodução, apps, pedidos e da tua subscrição, e lembra-se "
        "das conversas anteriores contigo.",
    ]
    if wa := whatsapp():
        lines.append(f"WhatsApp (o mesmo assistente): {_whatsapp_label(wa)} — wa.me/{wa}")
    lines.append("No browser e nas apps Jellyfin para Android e iOS tens também o botão «Ajuda» no canto do ecrã.")
    return "\n\n".join(lines)


# ---------------------------------------------------------------------------------------------- Jellyfin
async def _admin_user_id(jf: JellyfinClient) -> str:
    for u in await jf.list_users():
        if (u.get("Policy") or {}).get("IsAdministrator"):
            return u["Id"]
    raise JellyfinError("Não há nenhum administrador no Jellyfin para editar a coleção.")


async def _find(jf: JellyfinClient, uid: str, known_id: str | None) -> dict[str, Any] | None:
    fields = "Overview,Genres,Tags,ProviderIds,People,Studios,Taglines,LockedFields,SortName,DateCreated"
    if known_id:
        data = (await jf._req("GET", "/Items", params={"userId": uid, "ids": known_id, "Fields": fields})).json()
        if data.get("Items"):
            return data["Items"][0]
    data = (await jf._req("GET", "/Items", params={
        "userId": uid, "IncludeItemTypes": "BoxSet", "Recursive": "true", "Tags": TAG, "Fields": fields})).json()
    items = data.get("Items") or []
    return items[0] if items else None


async def _upload(jf: JellyfinClient, item_id: str, kind: str, png: bytes) -> None:
    await jf._req("POST", f"/Items/{item_id}/Images/{kind}", content=base64.b64encode(png),
                  headers={"Content-Type": "image/png"}, timeout=60)


async def publish(db: AsyncSession, jf: JellyfinClient | None = None, *, actor_id: str | None = None) -> dict:
    """Cria (ou atualiza) a coleção «Ajuda» no Jellyfin com o cartaz e a descrição atuais."""
    s = get_settings()
    if not s.jellyfin_url or not s.jellyfin_api_key:
        raise JellyfinError("Configura primeiro o Jellyfin (endereço e chave de API).")
    jf = jf or JellyfinClient()
    uid = await _admin_user_id(jf)
    state = await db.get(ConfigEntry, STATE_KEY)
    item = await _find(jf, uid, (state.value or {}).get("id") if state and isinstance(state.value, dict) else None)
    created = item is None
    if created:
        r = await jf._req("POST", "/Collections", params={"name": NAME, "isLocked": "true"})
        new_id = (r.json() or {}).get("Id")
        if not new_id:
            raise JellyfinError("O Jellyfin não devolveu o id da coleção criada.")
        item = await _find(jf, uid, new_id) or {"Id": new_id, "Name": NAME}
    item_id = item["Id"]
    item.update({
        "Name": NAME, "ForcedSortName": SORT_NAME, "Overview": overview(), "LockData": True,
        "Tags": sorted({*(item.get("Tags") or []), TAG}),
    })
    for key in ("Genres", "Taglines", "LockedFields", "People", "Studios"):
        item.setdefault(key, [])
    item.setdefault("ProviderIds", {})
    await jf._req("POST", f"/Items/{item_id}", json=item)
    await _upload(jf, item_id, "Primary", poster_png())
    backdrop = backdrop_png()
    try:   # substitui o fundo anterior em vez de acumular
        await jf._req("DELETE", f"/Items/{item_id}/Images/Backdrop/0")
    except JellyfinError:
        pass
    await _upload(jf, item_id, "Backdrop", backdrop)
    await _upload(jf, item_id, "Thumb", backdrop)
    value = {"id": item_id, "updated_at": utcnow().isoformat(), "url": help_url()}
    if state is None:
        db.add(ConfigEntry(key=STATE_KEY, value=value, secret=False, updated_by=actor_id))
    else:
        state.value, state.updated_by = value, actor_id
    jf_url = s.jellyfin_public_url or s.jellyfin_url
    return {"id": item_id, "created": created, "help_url": help_url(),
            "item_url": f"{jf_url.rstrip('/')}/web/#/details?id={item_id}" if jf_url else None}


async def status(db: AsyncSession) -> dict:
    state = await db.get(ConfigEntry, STATE_KEY)
    value = state.value if state and isinstance(state.value, dict) else {}
    s = get_settings()
    jf_url = s.jellyfin_public_url or s.jellyfin_url
    return {"id": value.get("id"), "updated_at": value.get("updated_at"), "help_url": help_url(),
            "stale": bool(value) and value.get("url") != help_url(),
            "jellyfin_ready": bool(s.jellyfin_url and s.jellyfin_api_key), "whatsapp": whatsapp(),
            "item_url": f"{jf_url.rstrip('/')}/web/#/details?id={value['id']}" if jf_url and value.get("id")
            else None}
