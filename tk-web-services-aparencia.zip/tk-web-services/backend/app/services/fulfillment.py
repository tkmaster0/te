"""Entrega de produtos que não são streaming.

Cada produto tem um tipo de entrega (`Product.fulfillment`):
  * streaming — direitos Jellyfin/Seerr/IPTV do plano (ver provisioning.py)
  * manual    — o admin é avisado e preenche os dados de acesso do cliente no painel
  * webhook   — o portal envia um POST assinado (HMAC-SHA256) para o URL do produto; a resposta pode trazer
                {"access_details": {...}} que o cliente vê no dashboard
  * none      — só cobrança (ex.: donativo, suporte técnico, serviço sem acesso a gerir)

Formato do webhook:
    POST <webhook_url>
    X-TK-Event: subscription.activated | subscription.deactivated | subscription.updated
    X-TK-Signature: sha256=<hex hmac do corpo com o segredo do produto>
    {"event": ..., "subscription": {...}, "user": {...}, "product": {...}, "plan": {...}, "sent_at": ...}
"""
from __future__ import annotations

import hashlib
import hmac
import json
import logging

import httpx
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from ..db import utcnow
from ..models import Plan, Product, Subscription, User
from ..security import decrypt, encrypt
from .audit import audit
from .jobs import PermanentError, RetryLater, enqueue, job_handler
from .mailer import queue_email

log = logging.getLogger("tkportal.fulfillment")


def access_details(sub: Subscription) -> dict:
    raw = decrypt(sub.access_details_enc)
    if not raw:
        return {}
    try:
        data = json.loads(raw)
        return data if isinstance(data, dict) else {}
    except ValueError:
        return {}


def set_access_details(sub: Subscription, data: dict | None) -> None:
    sub.access_details_enc = encrypt(json.dumps(data, ensure_ascii=False)) if data else None


async def on_subscription_change(db: AsyncSession, sub: Subscription, event: str) -> None:
    """event: activated | deactivated | updated. Idempotente o suficiente para ser chamado mais de uma vez."""
    product = await db.get(Product, sub.product_id)
    if product is None:
        return
    kind = product.fulfillment or "streaming"
    if kind == "manual":
        s = get_settings()
        user = await db.get(User, sub.user_id)
        plan = await db.get(Plan, sub.plan_id)
        if event == "activated" and not access_details(sub):
            sub.fulfillment_status = "pending"
        elif event == "deactivated":
            sub.fulfillment_status = "pending_removal" if access_details(sub) else None
        if s.admin_notify_email and user and plan and event in ("activated", "deactivated", "updated"):
            verb = {"activated": "Ativar", "deactivated": "Desativar", "updated": "Atualizar"}[event]
            await queue_email(db, s.admin_notify_email, "admin_notice", subject=f"{verb} {product.name} — {user.username}",
                              message=f"{user.username} ({user.email}) · plano {plan.name}. "
                                      f"Abre Admin → Entregas para tratar.")
    elif kind == "webhook" and product.webhook_url:
        sub.fulfillment_status = "pending"
        await enqueue(db, "fulfillment_webhook", {"subscription_id": sub.id, "event": event}, max_attempts=10)


def sign(secret: str, body: bytes) -> str:
    return "sha256=" + hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()


@job_handler("fulfillment_webhook")
async def _deliver(db: AsyncSession, payload: dict) -> None:
    sub = await db.get(Subscription, payload["subscription_id"])
    if sub is None:
        return
    product = await db.get(Product, sub.product_id)
    user = await db.get(User, sub.user_id)
    plan = await db.get(Plan, sub.plan_id)
    if not (product and user and plan and product.webhook_url):
        return
    event = f"subscription.{payload['event']}"
    body = json.dumps({
        "event": event,
        "sent_at": utcnow().isoformat(),
        "subscription": {"id": sub.id, "status": sub.status, "period_end":
                         sub.current_period_end.isoformat() if sub.current_period_end else None},
        "user": {"id": user.id, "username": user.username, "email": user.email, "display_name": user.display_name},
        "product": {"id": product.id, "code": product.code, "name": product.name},
        "plan": {"id": plan.id, "code": plan.code, "name": plan.name, "features": plan.features},
    }, ensure_ascii=False).encode()
    secret = decrypt(product.webhook_secret_enc) or ""
    sub_id = sub.id

    async def failed(exc: Exception) -> Exception:
        # O worker faz rollback quando o handler falha: o estado "error" (que põe a entrega na fila do admin)
        # tem de ser gravado antes, senão ficava "pending" para sempre.
        sub.fulfillment_status = "error"
        await db.commit()
        return exc

    try:
        async with httpx.AsyncClient(timeout=15) as c:
            r = await c.post(product.webhook_url, content=body, headers={
                "Content-Type": "application/json", "X-TK-Event": event, "X-TK-Signature": sign(secret, body),
                "User-Agent": "TKPortal/2"})
    except httpx.HTTPError as exc:
        raise await failed(RetryLater(f"webhook inacessível: {exc}", 120)) from exc
    if r.status_code >= 500 or r.status_code == 429:
        raise await failed(RetryLater(f"webhook respondeu {r.status_code}", 120))
    if r.status_code >= 400:
        audit(db, "fulfillment.webhook_rejected", target_type="subscription", target_id=sub_id, status=r.status_code)
        raise await failed(PermanentError(f"webhook rejeitou ({r.status_code}): {r.text[:200]}"))
    try:
        data = r.json() if r.content else {}
    except ValueError:
        data = {}
    if isinstance(data, dict) and isinstance(data.get("access_details"), dict):
        set_access_details(sub, {str(k)[:60]: str(v)[:500] for k, v in list(data["access_details"].items())[:20]})
    sub.fulfillment_status = "done"
