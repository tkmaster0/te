"""Fila de trabalhos persistente (outbox) em PostgreSQL.

Tudo o que fala com serviços externos (Jellyfin, Seerr, Dispatcharr, email, processamento de webhooks)
passa por aqui: é enfileirado na mesma transação da alteração de estado e executado pelo worker
com retries e backoff exponencial. Se o Jellyfin estiver em baixo, nada se perde.
"""
from __future__ import annotations

import asyncio
import logging
import os
import re
import socket
import traceback
from collections.abc import Awaitable, Callable
from datetime import timedelta

from sqlalchemy import select, text, update
from sqlalchemy.ext.asyncio import AsyncSession

from ..db import is_postgres, sessionmaker, utcnow
from ..models import Job

log = logging.getLogger("tkportal.jobs")

Handler = Callable[[AsyncSession, dict], Awaitable[None]]
HANDLERS: dict[str, Handler] = {}

WORKER_ID = f"{socket.gethostname()}-{os.getpid()}"


class RetryLater(Exception):
    """Levantar dentro de um handler para reagendar sem contar como erro grave."""

    def __init__(self, message: str, delay_seconds: int = 60):
        super().__init__(message)
        self.delay_seconds = delay_seconds


class PermanentError(Exception):
    """Erro que não vale a pena repetir."""


def job_handler(kind: str):
    def deco(fn: Handler) -> Handler:
        HANDLERS[kind] = fn
        return fn

    return deco


async def enqueue(
    db: AsyncSession,
    kind: str,
    payload: dict | None = None,
    *,
    dedupe_key: str | None = None,
    delay_seconds: int = 0,
    max_attempts: int = 8,
) -> Job | None:
    """Adiciona um job à sessão (sem commit). Com dedupe_key, não duplica jobs pendentes iguais."""
    if dedupe_key:
        existing = await db.scalar(
            select(Job).where(Job.dedupe_key == dedupe_key, Job.status == "pending").limit(1)
        )
        if existing:
            # Garante que corre o quanto antes se o novo pedido for mais urgente.
            target = utcnow() + timedelta(seconds=delay_seconds)
            existing.run_after = min(existing.run_after, target)
            return existing
    job = Job(
        kind=kind,
        payload=payload or {},
        dedupe_key=dedupe_key,
        run_after=utcnow() + timedelta(seconds=delay_seconds),
        max_attempts=max_attempts,
    )
    db.add(job)
    return job


_TOKEN_IN_URL = re.compile(r"([?&]token=)[^&#\s]+")


def redact_tokens(value):
    """Esconde tokens de uso único (reset de password, confirmação de email…) em URLs dentro de um payload."""
    if isinstance(value, str):
        return _TOKEN_IN_URL.sub(r"\1<removido>", value)
    if isinstance(value, dict):
        return {k: redact_tokens(v) for k, v in value.items()}
    if isinstance(value, list):
        return [redact_tokens(v) for v in value]
    return value


def _scrub(payload: dict | None) -> dict:
    """Remove segredos do payload quando o job termina: chaves *_enc e tokens em links de emails.

    Os tokens de email só são guardados como hash na BD; o link no payload do job de envio não pode ficar
    como cópia em claro (visível no painel de jobs e em backups) depois de o email seguir.
    """
    return {k: ("<removido>" if k.endswith("_enc") else redact_tokens(v)) for k, v in (payload or {}).items()}


def _backoff(attempt: int) -> int:
    return min(30 * (2 ** (attempt - 1)), 6 * 3600)


async def _claim(db: AsyncSession) -> int | None:
    now = utcnow()
    if is_postgres():
        row = await db.execute(
            text(
                """
                UPDATE jobs SET status='running', locked_at=:now, locked_by=:wid, attempts=attempts+1
                WHERE id = (
                    SELECT id FROM jobs WHERE status='pending' AND run_after <= :now
                    ORDER BY run_after, id FOR UPDATE SKIP LOCKED LIMIT 1
                ) RETURNING id
                """
            ),
            {"now": now, "wid": WORKER_ID},
        )
        job_id = row.scalar()
        await db.commit()
        return job_id
    # SQLite (dev/testes): um só worker
    job_id = await db.scalar(
        select(Job.id).where(Job.status == "pending", Job.run_after <= now).order_by(Job.run_after, Job.id).limit(1)
    )
    if job_id is None:
        return None
    res = await db.execute(
        update(Job)
        .where(Job.id == job_id, Job.status == "pending")
        .values(status="running", locked_at=now, locked_by=WORKER_ID, attempts=Job.attempts + 1)
    )
    await db.commit()
    return job_id if res.rowcount else None


async def run_one() -> bool:
    """Executa um job pendente. Devolve False se não havia nada para fazer."""
    maker = sessionmaker()
    async with maker() as db:
        job_id = await _claim(db)
    if job_id is None:
        return False

    async with maker() as db:
        job = await db.get(Job, job_id)
        assert job is not None
        handler = HANDLERS.get(job.kind)
        try:
            if handler is None:
                raise PermanentError(f"Sem handler para '{job.kind}'")
            await handler(db, dict(job.payload or {}))
            await db.commit()
        except Exception as exc:  # noqa: BLE001
            await db.rollback()
            job = await db.get(Job, job_id)
            assert job is not None
            permanent = isinstance(exc, PermanentError)
            delay = exc.delay_seconds if isinstance(exc, RetryLater) else _backoff(job.attempts)
            job.last_error = f"{type(exc).__name__}: {exc}"[:4000]
            if not isinstance(exc, RetryLater | PermanentError):
                log.warning("Job %s (%s) falhou: %s\n%s", job.id, job.kind, exc, traceback.format_exc(limit=5))
            if permanent or job.attempts >= job.max_attempts:
                job.status = "failed"
                job.finished_at = utcnow()
                job.payload = _scrub(job.payload)
                log.error("Job %s (%s) falhou definitivamente: %s", job.id, job.kind, job.last_error)
            else:
                job.status = "pending"
                job.run_after = utcnow() + timedelta(seconds=delay)
            job.locked_at = None
            await db.commit()
            return True
        job = await db.get(Job, job_id)
        assert job is not None
        job.status = "done"
        job.finished_at = utcnow()
        job.payload = _scrub(job.payload)
        job.last_error = None
        await db.commit()
    return True


async def drain(max_jobs: int = 1000) -> int:
    """Executa jobs até a fila ficar vazia (usado em testes e no CLI)."""
    n = 0
    while n < max_jobs and await run_one():
        n += 1
    return n


async def recover_stale(db: AsyncSession, minutes: int = 15) -> int:
    res = await db.execute(
        update(Job)
        .where(Job.status == "running", Job.locked_at < utcnow() - timedelta(minutes=minutes))
        .values(status="pending", locked_at=None, run_after=utcnow())
    )
    await db.commit()
    return res.rowcount or 0


async def worker_loop(stop: asyncio.Event, idle_sleep: float = 2.0) -> None:
    log.info("Worker %s a arrancar", WORKER_ID)
    while not stop.is_set():
        try:
            did = await run_one()
        except Exception:
            log.exception("Erro no ciclo do worker")
            did = False
        if not did:
            try:
                await asyncio.wait_for(stop.wait(), timeout=idle_sleep)
            except TimeoutError:
                pass
