"""Programa de bónus por convites (regras do site antigo).

* Um convidado conta enquanto estiver **a ser cobrado**: tem uma subscrição ativa (ou cancelada mas ainda
  dentro do período pago) de um produto com bónus, já pagou pelo menos uma vez, e **não está ele próprio em
  bónus** nem com pagamentos em atraso.
* Quem foi convidado por um administrador (ex.: tkmaster) precisa de BONUS_THRESHOLD_ADMIN_REFERRED (2)
  convidados a contar; os restantes precisam de BONUS_THRESHOLD (3).
* Com o bónus ativo, os produtos com `bonus_eligible` (o streaming) não são cobrados na cobrança consolidada.
  Quando o número desce abaixo do limite, a cobrança é retomada na cobrança seguinte.
"""
from __future__ import annotations

import logging

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from ..db import utcnow
from ..models import Product, Subscription, SubStatus, User
from .audit import audit
from .jobs import job_handler
from .mailer import queue_email

log = logging.getLogger("tkportal.bonus")

PAYING = [SubStatus.active.value, SubStatus.canceling.value]


async def _is_paying(db: AsyncSession, invitee: User) -> bool:
    from .billing import has_paid_before

    if not invitee.is_active:
        return False
    rows = (await db.execute(select(Subscription, Product).join(Product, Product.id == Subscription.product_id).where(
        Subscription.user_id == invitee.id, Subscription.status.in_(PAYING),
        Product.bonus_eligible.is_(True)))).all()
    now = utcnow()
    live = [s for s, _ in rows if not (s.status == SubStatus.canceling and s.access_until and s.access_until <= now)]
    if not live:
        return False
    return await has_paid_before(db, invitee.id)


async def active_invitees(db: AsyncSession, user_id: str) -> int:
    invitees = (await db.scalars(select(User).where(User.referred_by_id == user_id))).all()
    n = 0
    for inv in invitees:
        if await _is_paying(db, inv):
            n += 1
    return n


async def threshold_for(db: AsyncSession, user: User) -> int:
    s = get_settings()
    if user.referred_by_id:
        ref = await db.get(User, user.referred_by_id)
        if ref and ref.is_admin:
            return s.bonus_threshold_admin_referred
    return s.bonus_threshold


async def bonus_status(db: AsyncSession, user: User) -> dict:
    count = await active_invitees(db, user.id)
    threshold = await threshold_for(db, user)
    enabled = get_settings().bonus_enabled
    return {"active_invitees": count, "threshold": threshold, "eligible": enabled and count >= threshold,
            "enabled": enabled}


async def evaluate_user(db: AsyncSession, user: User) -> str | None:
    """Atualiza o estado visível (subscrição 'bonus' ↔ 'active') e avisa o cliente das mudanças."""
    from .billing import _sync_bonus_status

    s = get_settings()
    changed = await _sync_bonus_status(db, user)
    if changed:
        info = await bonus_status(db, user)
        # Bónus ligado: sem email (o cliente vê-o no portal). Bónus desligado: avisa, porque a cobrança volta.
        if changed == "off":
            when = user.next_billing_at.strftime("%d/%m/%Y") if user.next_billing_at else None
            await queue_email(db, user.email, "bonus_off", threshold=info["threshold"], when=when,
                              cta_url=f"{s.public_url}/app/convites")
        audit(db, f"bonus.{changed}", target_type="user", target_id=user.id, **info)
    return changed


@job_handler("bonus_evaluate_all")
async def evaluate_all(db: AsyncSession, payload: dict) -> None:
    ids = (await db.scalars(select(Subscription.user_id).where(
        Subscription.status.in_([SubStatus.active.value, SubStatus.bonus.value])).distinct())).all()
    for uid in ids:
        user = await db.get(User, uid)
        if not user:
            continue
        try:
            await evaluate_user(db, user)
            await db.commit()
        except Exception as exc:  # noqa: BLE001
            await db.rollback()
            log.warning("Bónus: falha para %s: %s", uid, exc)
