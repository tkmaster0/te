"""Clientes OIDC predefinidos para as apps da pilha (Jellyfin, Seerr, LibreChat) e revogação de acessos.

  * Jellyfin (plugin 9p4 SSO): exige `feature:jellyfin` — só com o streaming ativo.
  * Seerr (OIDC nativo): exige `feature:seerr`. O Seerr liga a conta pelo email, por isso o portal mantém o email
    do utilizador do Seerr igual ao do portal (reconciliação).
  * LibreChat (OpenID): exige `product:<LIBRECHAT_PRODUCT_CODE>` (TKGPT). O LibreChat também liga pelo email.

Quando um cliente perde o acesso, os refresh tokens dessa app são revogados na reconciliação: as apps que
renovam a sessão pelo portal (LibreChat com OPENID_REUSE_TOKENS) terminam a sessão na próxima renovação.
"""
from __future__ import annotations

import secrets

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from ..db import utcnow
from ..models import OIDCClient, OIDCRefreshToken, User
from ..security import hash_password

JELLYFIN_PROVIDER = "tkflix"  # igual ao deploy/jellyfin/sso-plugin-config.json e ao botão de login
SEERR_PROVIDER = "tkws"


def preset_defs() -> list[dict]:
    s = get_settings()
    out = []
    if s.jellyfin_public_url:
        jf = s.jellyfin_public_url
        out.append({
            "client_id": "jellyfin", "name": "TKFLIX (Jellyfin)", "required_access": "feature:jellyfin",
            # Dois plugins suportados ao mesmo tempo (o mesmo cliente OIDC):
            #  • Jellyfin Security (ZL154/JellyfinSecurity) — /TwoFactorAuth/Oidc/Callback/<slug>; o slug vem do nome do
            #    fornecedor no plugin (chama-lhe "tkws");
            #  • 9p4 SSO — /sso/OID/redirect/<nome> (3.x) e /sso/OID/r/<nome> (4.x).
            "redirect_uris": [f"{jf}/TwoFactorAuth/Oidc/Callback/{s.jellyfin_security_oidc_slug}",
                              f"{jf}/sso/OID/redirect/{JELLYFIN_PROVIDER}", f"{jf}/sso/OID/r/{JELLYFIN_PROVIDER}"],
            "post_logout_redirect_uris": [jf, f"{jf}/web/"],
        })
    if s.seerr_public_url:
        se = s.seerr_public_url
        out.append({
            "client_id": "seerr", "name": "Pedidos (Seerr)", "required_access": "feature:seerr",
            "redirect_uris": [f"{se}/login", f"{se}/login?provider={SEERR_PROVIDER}&callback=true",
                              f"{se}/profile/settings/linked-accounts",
                              f"{se}/profile/settings/linked-accounts?provider={SEERR_PROVIDER}&callback=true"],
            "post_logout_redirect_uris": [se, f"{se}/login"],
        })
    if s.librechat_url:
        lc = s.librechat_url
        out.append({
            "client_id": "librechat", "name": "TKGPT (LibreChat)",
            "required_access": f"product:{s.librechat_product_code}",
            "redirect_uris": [f"{lc}/oauth/openid/callback"],
            "post_logout_redirect_uris": [lc, f"{lc}/login"],
        })
    return out


async def ensure_presets(db: AsyncSession, *, rotate: bool = False) -> list[dict]:
    """Cria os clientes que faltam (com segredo novo) e acerta os URIs dos existentes. Idempotente."""
    out = []
    for d in preset_defs():
        c = await db.get(OIDCClient, d["client_id"])
        secret = None
        if c is None:
            secret = secrets.token_urlsafe(36)
            c = OIDCClient(client_id=d["client_id"], name=d["name"], secret_hash=hash_password(secret),
                           allowed_scopes=["openid", "profile", "email", "groups", "offline_access"],
                           token_endpoint_auth_method="client_secret_basic", require_pkce=False, is_active=True)
            db.add(c)
            status = "criado"
        else:
            status = "atualizado"
            if rotate and c.secret_hash is not None:
                secret = secrets.token_urlsafe(36)
                c.secret_hash = hash_password(secret)
                status = "segredo novo"
        c.redirect_uris = sorted(set(c.redirect_uris or []) | set(d["redirect_uris"]))
        c.post_logout_redirect_uris = sorted(set(c.post_logout_redirect_uris or []) | set(d["post_logout_redirect_uris"]))
        c.required_access = d["required_access"]
        out.append({"client_id": c.client_id, "status": status, "redirect_uris": c.redirect_uris,
                    "required_access": c.required_access, "client_secret": secret})
    s = get_settings()
    if s.librechat_url:
        # O botão "Abrir" do TKGPT em "Os meus serviços" aponta para o LibreChat.
        from ..models import Product

        p = await db.scalar(select(Product).where(Product.code == s.librechat_product_code))
        if p is not None and not p.app_url:
            p.app_url = s.librechat_url
    await db.flush()
    return out


async def revoke_lost_access(db: AsyncSession, user: User, access) -> int:
    """Revoga os refresh tokens das apps a que o cliente deixou de ter acesso."""
    from ..routers.oidc import access_ok

    client_ids = set((await db.scalars(select(OIDCRefreshToken.client_id).where(
        OIDCRefreshToken.user_id == user.id, OIDCRefreshToken.revoked_at.is_(None),
        OIDCRefreshToken.expires_at > utcnow()))).all())
    n = 0
    for cid in client_ids:
        c = await db.get(OIDCClient, cid)
        if c is None or access_ok(c.required_access, user, access) and user.is_active:
            continue
        res = await db.execute(update(OIDCRefreshToken).where(
            OIDCRefreshToken.user_id == user.id, OIDCRefreshToken.client_id == cid,
            OIDCRefreshToken.revoked_at.is_(None)).values(revoked_at=utcnow()))
        n += res.rowcount or 0
    return n
