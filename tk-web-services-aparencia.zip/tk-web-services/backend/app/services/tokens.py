from __future__ import annotations

from datetime import timedelta

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from ..db import utcnow
from ..models import EmailToken
from ..security import new_token, token_hash

TTL = {
    "verify_email": timedelta(hours=48),
    "reset_password": timedelta(hours=1),
    "change_email": timedelta(hours=24),
    "magic_login": timedelta(minutes=2),
    "verify_code": timedelta(minutes=30),
}

CODE_MAX_ATTEMPTS = 5


async def issue(db: AsyncSession, user_id: str, purpose: str, data: dict | None = None) -> str:
    # Invalida tokens anteriores do mesmo tipo
    await db.execute(
        update(EmailToken)
        .where(EmailToken.user_id == user_id, EmailToken.purpose == purpose, EmailToken.used_at.is_(None))
        .values(used_at=utcnow())
    )
    raw = new_token(32)
    db.add(EmailToken(user_id=user_id, purpose=purpose, token_hash=token_hash(raw), data=data,
                      expires_at=utcnow() + TTL[purpose]))
    return raw


async def consume(db: AsyncSession, raw: str, purpose: str) -> EmailToken | None:
    if not raw or len(raw) > 200:
        return None
    tok = await db.scalar(select(EmailToken).where(EmailToken.token_hash == token_hash(raw),
                                                   EmailToken.purpose == purpose))
    if tok is None or tok.used_at is not None or tok.expires_at <= utcnow():
        return None
    # UPDATE condicional: garante uso único mesmo com pedidos concorrentes
    res = await db.execute(
        update(EmailToken).where(EmailToken.id == tok.id, EmailToken.used_at.is_(None)).values(used_at=utcnow())
    )
    if not res.rowcount:
        return None
    await db.refresh(tok)
    return tok


def _code_hash(user_id: str, code: str) -> str:
    # O código é curto: o hash inclui o utilizador para não colidir entre contas (token_hash é único).
    return token_hash(f"otp:{user_id}:{code}")


async def issue_code(db: AsyncSession, user_id: str, purpose: str = "verify_code") -> str:
    """Código numérico de 6 dígitos (OTP) enviado por email. Invalida os anteriores."""
    import secrets

    await db.execute(
        update(EmailToken)
        .where(EmailToken.user_id == user_id, EmailToken.purpose == purpose, EmailToken.used_at.is_(None))
        .values(used_at=utcnow())
    )
    code = f"{secrets.randbelow(1_000_000):06d}"
    db.add(EmailToken(user_id=user_id, purpose=purpose, token_hash=_code_hash(user_id, code),
                      data={"attempts": 0}, expires_at=utcnow() + TTL[purpose]))
    return code


async def consume_code(db: AsyncSession, user_id: str, code: str, purpose: str = "verify_code") -> bool:
    """Valida o código. Ao fim de CODE_MAX_ATTEMPTS tentativas erradas o código deixa de valer."""
    code = "".join(ch for ch in (code or "") if ch.isdigit())
    tok = await db.scalar(select(EmailToken).where(
        EmailToken.user_id == user_id, EmailToken.purpose == purpose, EmailToken.used_at.is_(None),
        EmailToken.expires_at > utcnow()).order_by(EmailToken.id.desc()).limit(1))
    if tok is None:
        return False
    if len(code) != 6 or tok.token_hash != _code_hash(user_id, code):
        attempts = int((tok.data or {}).get("attempts", 0)) + 1
        tok.data = {"attempts": attempts}
        if attempts >= CODE_MAX_ATTEMPTS:
            tok.used_at = utcnow()
        return False
    res = await db.execute(
        update(EmailToken).where(EmailToken.id == tok.id, EmailToken.used_at.is_(None)).values(used_at=utcnow())
    )
    return bool(res.rowcount)
