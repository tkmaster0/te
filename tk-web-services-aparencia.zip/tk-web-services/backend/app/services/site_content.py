"""Conteúdo do site editável no painel admin: textos, imagens e emails.

* **Textos** — cada texto do portal (página inicial, entrar/registo, menus, cabeçalhos da área de cliente, título e
  descrição do separador…) tem uma chave e um texto por omissão no frontend (frontend/src/content/texts.ts). O admin
  guarda só as alterações (site_settings["texts"]); vazio volta ao texto por omissão.
* **Imagens** — logótipo, favicon, imagem da página inicial, fundo das páginas de entrada, imagem de partilha (pré-
  -visualização de links) e uma imagem por produto. Ficam na base de dados (entram nas cópias) e são servidas em
  /media/<chave>?v=<versão> com cache.
* **Emails** — assunto, título, corpo e botão de cada email (site_settings["emails"]), em Jinja num ambiente
  isolado (sandbox): o admin não consegue executar código no servidor através de um template.
"""
from __future__ import annotations

import hashlib
import html
import re
from functools import lru_cache
from pathlib import Path

from jinja2 import TemplateSyntaxError
from jinja2.sandbox import SandboxedEnvironment
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from ..db import utcnow
from ..models import SiteAsset, SiteSetting

MAX_IMAGE_BYTES = 2 * 1024 * 1024

# Imagens do site (as dos produtos usam a chave product-<id>).
IMAGE_SLOTS: dict[str, dict[str, str]] = {
    "logo": {"label": "Logótipo", "help": "Cabeçalho do site e do portal, e emails. Ideal: PNG/SVG horizontal, fundo "
                                          "transparente, ~400×100."},
    "favicon": {"label": "Ícone do separador (favicon)", "help": "Quadrado, 64×64 ou maior (PNG, SVG ou ICO)."},
    "hero": {"label": "Imagem da página inicial", "help": "Substitui a ilustração ao lado do título. ~1200×900."},
    "auth": {"label": "Fundo das páginas de entrada e registo", "help": "Fica por trás do cartão, escurecida. "
                                                                         "~1920×1080."},
    "share": {"label": "Imagem de partilha", "help": "Aparece quando alguém partilha o link (WhatsApp, Facebook, "
                                                     "LinkedIn…). 1200×630."},
}
KEY_RE = re.compile(r"^(?:[a-z]+|product-\d{1,9})$")
TEXT_KEY_RE = re.compile(r"^[a-z0-9][a-z0-9_.-]{0,79}$")


class ContentError(ValueError):
    pass


# ------------------------------------------------------------------------------------------------ imagens
def detect_image(data: bytes) -> str | None:
    head = data[:512]
    if head.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png"
    if head.startswith(b"\xff\xd8\xff"):
        return "image/jpeg"
    if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
        return "image/webp"
    if head[:6] in (b"GIF87a", b"GIF89a"):
        return "image/gif"
    if head[:4] == b"\x00\x00\x01\x00":
        return "image/x-icon"
    text = head.lstrip(b"\xef\xbb\xbf").lstrip().lower()
    if text.startswith(b"<svg") or (text.startswith(b"<?xml") and b"<svg" in data[:2048].lower()):
        return "image/svg+xml"
    return None


def valid_key(key: str) -> bool:
    return bool(KEY_RE.match(key)) and (key in IMAGE_SLOTS or key.startswith("product-"))


def url_for(asset: SiteAsset) -> str:
    return f"/media/{asset.key}?v={asset.etag[:10]}"


async def put_image(db: AsyncSession, key: str, data: bytes) -> SiteAsset:
    if not valid_key(key):
        raise ContentError("Imagem desconhecida.")
    if not data:
        raise ContentError("Ficheiro vazio.")
    if len(data) > MAX_IMAGE_BYTES:
        raise ContentError("A imagem tem mais de 2 MB.")
    ctype = detect_image(data)
    if ctype is None:
        raise ContentError("Formato não suportado — usa PNG, JPG, WebP, GIF, SVG ou ICO.")
    etag = hashlib.sha256(data).hexdigest()[:32]
    row = await db.get(SiteAsset, key)
    if row is None:
        row = SiteAsset(key=key, content_type=ctype, data=data, etag=etag, size=len(data), updated_at=utcnow())
        db.add(row)
    else:
        row.content_type, row.data, row.etag, row.size, row.updated_at = ctype, data, etag, len(data), utcnow()
    return row


async def delete_image(db: AsyncSession, key: str) -> bool:
    row = await db.get(SiteAsset, key)
    if row is None:
        return False
    await db.delete(row)
    return True


async def images(db: AsyncSession) -> dict[str, str]:
    """URL das imagens do site que estão definidas (as dos produtos vão no próprio produto)."""
    rows = (await db.execute(select(SiteAsset.key, SiteAsset.etag).where(
        SiteAsset.key.in_(list(IMAGE_SLOTS))))).all()
    return {k: f"/media/{k}?v={e[:10]}" for k, e in rows}


# ------------------------------------------------------------------------------------------------- textos
def clean_texts(raw: object) -> dict[str, str]:
    if not isinstance(raw, dict):
        raise ContentError("Os textos têm de ser um objeto {chave: texto}.")
    if len(raw) > 800:
        raise ContentError("Demasiados textos.")
    out: dict[str, str] = {}
    for k, v in raw.items():
        if not isinstance(k, str) or not TEXT_KEY_RE.match(k):
            raise ContentError(f"Chave de texto inválida: {k!r}")
        if v is None:
            continue
        if not isinstance(v, str):
            raise ContentError(f"O texto de {k} tem de ser texto.")
        v = v.strip()
        if len(v) > 4000:
            raise ContentError(f"O texto de {k} é demasiado longo.")
        if v:  # vazio = volta ao texto por omissão
            out[k] = v
    return out


# ------------------------------------------------------------------------------------------------- emails
_sandbox = SandboxedEnvironment(autoescape=True)
EMAIL_FIELDS = ("subject", "title", "body", "cta")


def compile_template(source: str):
    return _sandbox.from_string(source)


def clean_emails(raw: object) -> dict[str, dict[str, str]]:
    from .mailer import TEMPLATES

    if not isinstance(raw, dict):
        raise ContentError("Os emails têm de ser um objeto {template: {...}}.")
    out: dict[str, dict[str, str]] = {}
    for tpl, fields in raw.items():
        if tpl not in TEMPLATES:
            raise ContentError(f"Email desconhecido: {tpl}")
        if not isinstance(fields, dict):
            raise ContentError(f"{tpl}: formato inválido.")
        clean: dict[str, str] = {}
        for f, v in fields.items():
            if f not in EMAIL_FIELDS:
                raise ContentError(f"{tpl}: campo desconhecido {f}.")
            if v is None or not str(v).strip():
                continue
            v = str(v)
            if len(v) > 20000:
                raise ContentError(f"{tpl}.{f}: demasiado longo.")
            try:
                compile_template(v)
            except TemplateSyntaxError as exc:
                raise ContentError(f"{tpl}.{f}: erro no template — {exc.message} (linha {exc.lineno}).") from exc
            clean[f] = v
        if clean:
            out[tpl] = clean
    return out


async def email_overrides(db: AsyncSession) -> dict[str, dict[str, str]]:
    row = await db.get(SiteSetting, "emails")
    return row.value if row and isinstance(row.value, dict) else {}


# ------------------------------------------------------------------------------------- página HTML (fora)
@lru_cache
def _index_template(path: str, mtime: float) -> str:
    return Path(path).read_text(encoding="utf-8")


def _meta_tag(attr: str, name: str, content: str) -> str:
    return f'<meta {attr}="{name}" content="{html.escape(content, quote=True)}" />'


async def render_index(db: AsyncSession, index: Path) -> str:
    """index.html com o título, a descrição, o favicon e a imagem de partilha definidos no admin — o que os
    browsers e as pré-visualizações de links (WhatsApp, Facebook…) leem, mesmo sem correr JavaScript."""
    base = _index_template(str(index), index.stat().st_mtime)
    row = await db.get(SiteSetting, "texts")
    texts = row.value if row and isinstance(row.value, dict) else {}
    imgs = await images(db)
    s = get_settings()
    title = texts.get("meta.title") or s.app_name or "TK Web Services"
    desc = texts.get("meta.description")
    out = re.sub(r"<title>.*?</title>", f"<title>{html.escape(title)}</title>", base, count=1, flags=re.S)
    if desc:
        out = re.sub(r'<meta name="description" content="[^"]*"\s*/?>', _meta_tag("name", "description", desc),
                     out, count=1)
    extra = [_meta_tag("property", "og:title", title), _meta_tag("property", "og:type", "website"),
             _meta_tag("property", "og:url", s.public_url)]
    if desc:
        extra.append(_meta_tag("property", "og:description", desc))
    if "share" in imgs:
        img = s.public_url.rstrip("/") + imgs["share"]
        extra += [_meta_tag("property", "og:image", img), _meta_tag("name", "twitter:card", "summary_large_image")]
    if "favicon" in imgs:
        out = re.sub(r'<link rel="icon"[^>]*>', f'<link rel="icon" href="{html.escape(imgs["favicon"])}" />',
                     out, count=1)
    return out.replace("</head>", "    " + "\n    ".join(extra) + "\n  </head>", 1)
