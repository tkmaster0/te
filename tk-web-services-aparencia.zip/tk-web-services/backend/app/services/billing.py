"""Motor de faturação consolidada.

Modelo:
  * Cada cliente tem um **dia de faturação** (1–28). Todas as subscrições renovam nesse dia, por isso há no
    máximo **uma cobrança por mês**, com todos os serviços somados.
  * Subscrições anuais renovam no dia de faturação do mês respetivo (entram na cobrança desse mês).
  * Produtos novos e mudanças de plano a meio do ciclo geram **linhas pro-rata** (crédito do tempo não usado +
    custo do novo plano até ao próximo dia de faturação). Por omissão estas linhas entram na próxima cobrança
    (uma só cobrança, menos taxas); a primeira compra de um cliente novo é cobrada logo.
  * Mudanças de preço: preço fixado por subscrição (`price_cents`), alterações agendadas com aviso.
  * Pagamentos: o fornecedor (GoCardless/Stripe) é só a forma de cobrar. Se um método deixa de servir,
    tenta-se outro método do cliente; se não houver, o cliente é avisado e tem uma tolerância.

Todo o dinheiro está em cêntimos (inteiros). Arredondamento meio-para-cima nas pro-ratas.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from decimal import ROUND_HALF_UP, Decimal

from sqlalchemy import func, or_, select, text, update
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from ..db import is_postgres, utcnow
from ..models import (
    ENTITLED_STATUSES,
    USABLE_PM_STATUSES,
    Checkout,
    Counter,
    Invoice,
    InvoiceLine,
    Payment,
    PaymentMethod,
    Plan,
    PriceChange,
    Product,
    Subscription,
    SubStatus,
    User,
    Wallet,
)
from ..payments import registry
from ..payments.base import ChargeResult, ProviderError
from . import wallet as wallet_svc
from .audit import audit
from .jobs import RetryLater, enqueue, job_handler
from .mailer import queue_email
from .subscriptions import add_interval, fmt_date, fmt_money, request_reconcile, set_status

log = logging.getLogger("tkportal.billing")

BONUS_WAIVABLE = ("renewal", "proration")
LIVE_BILLING = {SubStatus.active, SubStatus.past_due, SubStatus.bonus, SubStatus.canceling, SubStatus.suspended}
UNPAID_INVOICE = ("open", "failed")
REMOVED_REASON = "Removido pelo cliente"


class BillingError(Exception):
    """Erro de regra de negócio (mostrado ao cliente)."""


# =========================================================================== datas e montantes
def _at_billing_hour(d: datetime) -> datetime:
    return d.replace(hour=get_settings().billing_hour_utc, minute=0, second=0, microsecond=0)


def anchor_on(year: int, month: int, day: int) -> datetime:

    return _at_billing_hour(datetime(year, month, day, tzinfo=UTC))


def next_anchor(anchor_day: int, after: datetime) -> datetime:
    """Primeiro dia de faturação estritamente depois de `after`."""
    cand = anchor_on(after.year, after.month, anchor_day)
    if cand <= after:
        cand = add_interval(cand, "month", 1)
    return cand


def plan_price(sub: Subscription | None, plan: Plan) -> int:
    if sub is not None and sub.price_cents is not None:
        return sub.price_cents
    return plan.price_cents


def prorate(amount_cents: int, start: datetime, end: datetime, plan: Plan) -> int:
    """Valor de `amount` (preço de um período completo do plano) para o intervalo [start, end]."""
    if end <= start or amount_cents == 0:
        return 0
    full_start = add_interval(end, plan.interval_unit, -plan.interval_count)
    full = (end - full_start).total_seconds()
    part = min((end - start).total_seconds(), full)
    value = Decimal(amount_cents) * Decimal(part) / Decimal(full)
    return int(value.quantize(Decimal(1), rounding=ROUND_HALF_UP))


def unused_credit(sub: Subscription, now: datetime) -> int:
    """Crédito pelo tempo não usado do período atual (sobre o valor efetivamente faturado)."""
    paid = sub.period_amount_cents or 0
    if paid <= 0 or not sub.current_period_start or not sub.current_period_end or sub.current_period_end <= now:
        return 0
    total = (sub.current_period_end - sub.current_period_start).total_seconds()
    if total <= 0:
        return 0
    left = min((sub.current_period_end - now).total_seconds(), total)
    value = Decimal(paid) * Decimal(left) / Decimal(total)
    return int(value.quantize(Decimal(1), rounding=ROUND_HALF_UP))


def monthly_equivalent(price_cents: int, plan: Plan) -> float:
    months = plan.interval_count * (12 if plan.interval_unit == "year" else 1)
    if plan.interval_unit == "week":
        months = plan.interval_count * 12 / 52
    return price_cents / months if months else float(price_cents)


def _range(a: datetime, b: datetime) -> str:
    return f"{a:%d/%m/%Y}–{b:%d/%m/%Y}"


# =========================================================================== consultas
async def live_subs(db: AsyncSession, user_id: str) -> list[Subscription]:
    return list((await db.scalars(select(Subscription).where(
        Subscription.user_id == user_id, Subscription.provider == "portal",
        Subscription.status.in_([s.value for s in LIVE_BILLING])).order_by(Subscription.created_at))).all())


async def live_sub_for_product(db: AsyncSession, user_id: str, product_id: int) -> Subscription | None:
    return await db.scalar(select(Subscription).where(
        Subscription.user_id == user_id, Subscription.product_id == product_id,
        Subscription.status.in_([s.value for s in LIVE_BILLING])).order_by(Subscription.created_at.desc()).limit(1))


async def unpaid_invoices(db: AsyncSession, user_id: str) -> list[Invoice]:
    """Cobranças de serviços por pagar (os carregamentos da carteira falhados são anulados, não ficam em dívida)."""
    return list((await db.scalars(select(Invoice).where(
        Invoice.user_id == user_id, Invoice.status.in_(UNPAID_INVOICE), Invoice.kind != "topup")
        .order_by(Invoice.created_at))).all())


async def retries_pending(db: AsyncSession, user_id: str) -> bool:
    """Há cobranças ainda em curso (débito submetido / o fornecedor vai tentar de novo) ou com nova tentativa
    agendada? Enquanto houver, o acesso não é suspenso: só se corta depois da última tentativa."""
    return bool(await db.scalar(select(Invoice.id).where(
        Invoice.user_id == user_id, Invoice.kind != "topup",
        or_(Invoice.status == "processing",
            (Invoice.status == "failed") & Invoice.next_attempt_at.is_not(None))).limit(1)))


async def has_paid_before(db: AsyncSession, user_id: str) -> bool:
    inv = await db.scalar(select(Invoice.id).where(Invoice.user_id == user_id, Invoice.status == "paid",
                                                   Invoice.total_cents > 0).limit(1))
    if inv:
        return True
    legacy = await db.scalar(select(Payment.id).where(Payment.user_id == user_id, Payment.status == "paid").limit(1))
    return bool(legacy)


async def usable_methods(db: AsyncSession, user_id: str) -> list[PaymentMethod]:
    """Métodos que podem ser cobrados agora, com o predefinido primeiro."""
    enabled = {n for n, st in (await registry.state(db)).items() if st["enabled"]}
    rows = (await db.scalars(select(PaymentMethod).where(
        PaymentMethod.user_id == user_id, PaymentMethod.status.in_(list(USABLE_PM_STATUSES)))
        .order_by(PaymentMethod.is_default.desc(), PaymentMethod.created_at.desc()))).all()
    now = utcnow()
    return [pm for pm in rows if pm.provider in enabled and not (pm.expires_at and pm.expires_at <= now)]


async def default_method(db: AsyncSession, user_id: str) -> PaymentMethod | None:
    methods = await usable_methods(db, user_id)
    return methods[0] if methods else None


async def lock_user(db: AsyncSession, user: User) -> User:
    """Bloqueia a linha do cliente até ao fim da transação (PostgreSQL).

    Dois workers (ou um duplo clique) a correr o ciclo / a subscrever ao mesmo tempo para o mesmo cliente
    emitiam duas cobranças. Em SQLite há um só escritor, por isso não é preciso.
    """
    if not is_postgres():
        return user
    locked = await db.scalar(select(User).where(User.id == user.id).with_for_update()
                             .execution_options(populate_existing=True))
    return locked or user


async def lock_invoice(db: AsyncSession, inv: Invoice) -> Invoice:
    """Bloqueia a cobrança até ao fim da transação (PostgreSQL) e relê o estado já gravado.

    "Pagar agora" e a nova tentativa automática (ou dois cliques) ao mesmo tempo usavam a mesma chave de
    idempotência — o fornecedor não cobrava duas vezes, mas o segundo pedido rebentava ao gravar o mesmo pagamento
    (IntegrityError → erro 500 ao cliente). Com o bloqueio, o segundo espera e vê a cobrança já paga/submetida.
    """
    if not is_postgres():
        return inv
    locked = await db.scalar(select(Invoice).where(Invoice.id == inv.id).with_for_update()
                             .execution_options(populate_existing=True))
    return locked or inv


async def lock_for_change(db: AsyncSession, user: User, sub: Subscription) -> tuple[User, Subscription]:
    """Bloqueia o cliente e relê a subscrição antes de a alterar (PostgreSQL).

    Sem isto, dois pedidos ao mesmo tempo (duplo clique, portal + Jellyfin, ou uma ação confirmada duas vezes) liam
    a mesma subscrição e cada um acrescentava o seu crédito/pro-rata: um downgrade repetido dava crédito a dobrar.
    """
    if not is_postgres():
        return user, sub
    user = await lock_user(db, user)
    fresh = await db.scalar(select(Subscription).where(Subscription.id == sub.id)
                            .execution_options(populate_existing=True))
    return user, fresh or sub


# =========================================================================== numeração
async def next_number(db: AsyncSession, year: int) -> str:
    name = f"invoice-{year}"
    if is_postgres():
        await db.execute(text("INSERT INTO counters (name, value) VALUES (:n, 0) ON CONFLICT (name) DO NOTHING"),
                         {"n": name})
    elif await db.get(Counter, name) is None:
        db.add(Counter(name=name, value=0))
        await db.flush()
    value = (await db.execute(text("UPDATE counters SET value = value + 1 WHERE name = :n RETURNING value"),
                              {"n": name})).scalar_one()
    return f"C{year}-{value:05d}"


# =========================================================================== bónus
async def bonus_eligible_now(db: AsyncSession, user: User) -> bool:
    from .bonus import bonus_status

    s = get_settings()
    if not s.bonus_enabled:
        return False
    return (await bonus_status(db, user))["eligible"]


async def _product(db: AsyncSession, product_id: int | None) -> Product | None:
    return await db.get(Product, product_id) if product_id else None


async def _bonus_line(db: AsyncSession, user: User, lines: list[InvoiceLine]) -> InvoiceLine | None:
    """Isenta as linhas de produtos com bónus (renovações e pro-ratas) quando o cliente é elegível."""
    if not await bonus_eligible_now(db, user):
        return None
    waive = 0
    for ln in lines:
        prod = await _product(db, ln.product_id)
        # Só se isentam cobranças (renovações e pro-ratas). Créditos de tempo já pago continuam a ser do
        # cliente: somá-los aqui fazia o bónus "comer" o crédito de uma mudança de plano.
        if prod and prod.bonus_eligible and ln.kind in BONUS_WAIVABLE and ln.amount_cents > 0:
            waive += ln.amount_cents
    if waive <= 0:
        return None
    return InvoiceLine(user_id=user.id, kind="bonus", amount_cents=-waive,
                       description="Bónus de convites — serviço sem custo este mês 🎁")


# =========================================================================== criação de cobranças
async def _finalize(db: AsyncSession, user: User, lines: list[InvoiceLine], *, kind: str, now: datetime,
                    period_start: datetime | None = None, allow_carry: bool = True, topup_cents: int = 0,
                    skip_topup_when_covered: bool = True) -> Invoice | None:
    """Cria a cobrança com as linhas dadas, aplica créditos, a carteira, o carregamento mensal e o mínimo, e
    devolve-a (sem cobrar).

    Ordem: créditos → saldo da carteira (sempre primeiro) → carregamento mensal (paga o que faltar e o resto fica
    na carteira) → o que sobrar é cobrado ao método de pagamento.
    """
    s = get_settings()
    if not lines and topup_cents <= 0:
        return None
    inv = Invoice(user_id=user.id, number=await next_number(db, now.year), kind=kind, status="open",
                  period_start=period_start or now, created_at=now)
    db.add(inv)
    await db.flush()
    for ln in lines:
        ln.invoice_id = inv.id
        ln.user_id = user.id
        if ln.id is None:
            db.add(ln)
    total = sum(ln.amount_cents for ln in lines)
    had_charges = any(ln.amount_cents > 0 for ln in lines)
    if total < 0:
        # Crédito maior do que o devido: fica para a próxima cobrança.
        db.add(InvoiceLine(user_id=user.id, invoice_id=inv.id, kind="carry", amount_cents=-total,
                           description="Crédito transitado para a próxima cobrança"))
        db.add(InvoiceLine(user_id=user.id, invoice_id=None, kind="credit", amount_cents=total,
                           description=f"Crédito transitado da cobrança {inv.number}"))
        total = 0
    has_topup = False
    if s.wallet_enabled and kind != "topup":
        debt = await wallet_svc.settle_debt_into_lines(db, user.id, inv)
        if debt is not None:
            lines = [*lines, debt]
            total += debt.amount_cents
            had_charges = True
        total -= await wallet_svc.use_for_invoice(db, user.id, inv, total)
        covered = had_charges and total == 0
        if topup_cents > 0 and not (covered and skip_topup_when_covered):
            extra = wallet_svc.topup_lines(inv, topup_cents, total, monthly=True)
            db.add_all(extra)
            total += sum(ln.amount_cents for ln in extra)
            has_topup = True
    if 0 < total < s.billing_min_charge_cents and kind == "cycle" and allow_carry and not has_topup:
        # Valor tão baixo que a taxa fixa não compensa: soma-se à próxima cobrança.
        db.add(InvoiceLine(user_id=user.id, invoice_id=inv.id, kind="carry", amount_cents=-total,
                           description="Valor baixo — transitado para a próxima cobrança"))
        db.add(InvoiceLine(user_id=user.id, invoice_id=None, kind="adjustment", amount_cents=total,
                           description=f"Valor transitado da cobrança {inv.number}"))
        total = 0
    inv.subtotal_cents = sum(ln.amount_cents for ln in lines if ln.kind != "carry")
    inv.total_cents = total
    if not lines and not has_topup:
        # Só carregamento, e foi saltado (saldo já cobre): não há cobrança.
        await db.delete(inv)
        await db.flush()
        return None
    if total == 0:
        inv.status = "paid"
        inv.paid_at = now
    await db.flush()
    return inv


async def pending_lines(db: AsyncSession, user_id: str) -> list[InvoiceLine]:
    return list((await db.scalars(select(InvoiceLine).where(
        InvoiceLine.user_id == user_id, InvoiceLine.invoice_id.is_(None)).order_by(InvoiceLine.id))).all())


async def _effective_price_for_renewal(db: AsyncSession, sub: Subscription, plan: Plan, starts: datetime) -> int:
    """Aplica mudanças de preço agendadas que já estejam em vigor no início do novo período."""
    change = await db.scalar(select(PriceChange).where(
        PriceChange.plan_id == plan.id, PriceChange.cancelled_at.is_(None), PriceChange.effective_at <= starts)
        .order_by(PriceChange.effective_at.desc()).limit(1))
    if change and (sub.price_cents is None or sub.price_cents == change.old_price_cents):
        if sub.price_cents != change.new_price_cents:
            audit(db, "subscription.price_changed", target_type="subscription", target_id=sub.id,
                  old=sub.price_cents, new=change.new_price_cents, price_change=change.id)
        sub.price_cents = change.new_price_cents
    return plan_price(sub, plan)


async def _renew_due(db: AsyncSession, user: User, now: datetime) -> list[InvoiceLine]:
    s = get_settings()
    lines: list[InvoiceLine] = []
    for sub in await live_subs(db, user.id):
        guard = 0
        while sub.current_period_end and sub.current_period_end <= now and guard < 24:
            guard += 1
            st = SubStatus(sub.status)
            if st == SubStatus.canceling or sub.cancel_at_period_end:
                await set_status(db, sub, SubStatus.ended, reason="fim do período (cancelada)")
                break
            if st == SubStatus.suspended:
                # Não renova enquanto não pagar; ao fim de N dias termina.
                if sub.updated_at and sub.updated_at < now - timedelta(days=s.suspended_end_days):
                    await set_status(db, sub, SubStatus.ended, reason="suspensa há demasiado tempo")
                break
            if sub.pending_plan_id:  # migração de plano agendada para a renovação
                new_plan = await db.get(Plan, sub.pending_plan_id)
                if new_plan:
                    audit(db, "subscription.plan_migrated", target_type="subscription", target_id=sub.id,
                          old=sub.plan_id, new=new_plan.id)
                    sub.plan_id = new_plan.id
                    sub.product_id = new_plan.product_id
                    sub.price_cents = (sub.meta or {}).get("pending_price_cents", new_plan.price_cents)
                    await request_reconcile(db, sub.user_id)
                sub.pending_plan_id = None
                sub.meta = {k: v for k, v in (sub.meta or {}).items() if k != "pending_price_cents"}
            plan = await db.get(Plan, sub.plan_id)
            assert plan is not None
            start = sub.current_period_end
            end = add_interval(start, plan.interval_unit, plan.interval_count)
            price = await _effective_price_for_renewal(db, sub, plan, start)
            lines.append(InvoiceLine(user_id=user.id, subscription_id=sub.id, product_id=sub.product_id,
                                     kind="renewal", amount_cents=price, period_start=start, period_end=end,
                                     description=f"{plan.name} · {_range(start, end)}"))
            sub.current_period_start = start
            sub.current_period_end = end
            sub.period_amount_cents = price
    return lines


async def run_cycle(db: AsyncSession, user: User, now: datetime | None = None) -> Invoice | None:
    """Renova o que vence, junta as linhas pendentes e emite a cobrança do ciclo (uma por cliente)."""
    from .bonus import evaluate_user

    now = now or utcnow()
    user = await lock_user(db, user)
    if user.next_billing_at is None or user.next_billing_at > now:
        return None
    if not user.billing_anchor_day:
        user.billing_anchor_day = min(user.next_billing_at.day, 28)
    lines = await _renew_due(db, user, now)
    lines += await pending_lines(db, user.id)
    await evaluate_user(db, user)  # estado bónus↔ativo (com os emails) antes de calcular a isenção
    inv = None
    w = await db.get(Wallet, user.id) if get_settings().wallet_enabled else None
    topup = (w.monthly_topup_cents or 0) if w and wallet_svc.monthly_enabled() else 0
    # Só há cobrança se houver algo a cobrar: créditos soltos (ou renovações a 0) ficam para a próxima, em vez
    # de gerarem todos os meses uma cobrança vazia com o crédito "transitado".
    if any(ln.amount_cents > 0 for ln in lines) or topup > 0:
        bonus = await _bonus_line(db, user, lines)
        if bonus:
            lines.append(bonus)
            for ln in lines:
                if ln.kind == "renewal" and ln.subscription_id:
                    prod = await _product(db, ln.product_id)
                    sub = await db.get(Subscription, ln.subscription_id)
                    if prod and prod.bonus_eligible and sub:
                        sub.period_amount_cents = 0
        # Sem serviços ativos não há próxima cobrança: um valor abaixo do mínimo cobra-se já (senão ficava a
        # transitar para sempre).
        inv = await _finalize(db, user, lines, kind="cycle", now=now,
                              allow_carry=bool(await live_subs(db, user.id)), topup_cents=topup,
                              skip_topup_when_covered=bool(w.monthly_skip_when_covered) if w else True)
    nxt = next_anchor(user.billing_anchor_day, now)
    if nxt.date() == now.date():
        # Ciclo corrido antes da hora de faturação do próprio dia (ex.: 1.º carregamento mensal logo ao aderir):
        # o próximo é no mês seguinte, senão cobrava-se duas vezes no mesmo dia.
        nxt = add_interval(nxt, "month", 1)
    user.next_billing_at = nxt
    if not await live_subs(db, user.id) and not await pending_lines(db, user.id) and not topup:
        user.next_billing_at = None  # sem nada para cobrar
    await db.commit()  # a cobrança fica gravada antes de falar com o fornecedor
    if inv and inv.status == "open":
        await charge_or_defer(db, inv, now=now)
    return inv


async def charge_or_defer(db: AsyncSession, inv: Invoice, *, now: datetime | None = None,
                          method: PaymentMethod | None = None, notify: bool = True) -> str:
    """Cobra já; se o fornecedor não responder, agenda nova tentativa (mesma fatura → idempotente).

    Sem rollback: o que já aconteceu nesta tentativa (ex.: um método recusado como inutilizável antes de o
    fornecedor do método seguinte falhar) é verdade e fica gravado. Um rollback depois de um flush também
    expirava os objetos da sessão, e o acesso seguinte (aqui ou no router) rebentava com MissingGreenlet.
    """
    inv_id = inv.id
    try:
        return await charge_invoice(db, inv, now=now, method=method, notify=notify)
    except RetryLater:
        await enqueue(db, "billing_charge", {"invoice_id": inv_id}, dedupe_key=f"charge:{inv_id}",
                      delay_seconds=300, max_attempts=10)
        await db.commit()
        return "deferred"


@job_handler("billing_cycle")
async def _job_cycle(db: AsyncSession, payload: dict) -> None:
    user = await db.get(User, payload["user_id"])
    if user:
        await run_cycle(db, user)


@job_handler("billing_charge")
async def _job_charge(db: AsyncSession, payload: dict) -> None:
    inv = await db.get(Invoice, payload["invoice_id"])
    if inv and inv.status in UNPAID_INVOICE:
        await charge_invoice(db, inv)


async def schedule_due(db: AsyncSession) -> int:
    """Chamado periodicamente: agenda ciclos vencidos e novas tentativas de cobrança."""
    now = utcnow()
    n = 0
    for uid in (await db.scalars(select(User.id).where(User.next_billing_at <= now))).all():
        await enqueue(db, "billing_cycle", {"user_id": uid}, dedupe_key=f"cycle:{uid}", max_attempts=10)
        n += 1
    for inv_id in (await db.scalars(select(Invoice.id).where(Invoice.status == "failed",
                                                             Invoice.next_attempt_at <= now))).all():
        await enqueue(db, "billing_charge", {"invoice_id": inv_id}, dedupe_key=f"charge:{inv_id}", max_attempts=10)
        n += 1
    # Cobranças emitidas mas nunca cobradas (o processo caiu entre o commit e a cobrança, ou o job de nova
    # tentativa esgotou-se): sem isto ficavam "open" para sempre e o serviço continuava sem ser pago.
    for inv_id in (await db.scalars(select(Invoice.id).where(
            Invoice.status == "open", Invoice.total_cents > 0, Invoice.kind != "topup",
            Invoice.created_at <= now - timedelta(minutes=15)))).all():
        await enqueue(db, "billing_charge", {"invoice_id": inv_id}, dedupe_key=f"charge:{inv_id}", max_attempts=10)
        n += 1
    # Carregamentos únicos iniciados numa página do fornecedor e abandonados: anulam-se (nunca são cobrados sozinhos).
    for inv in (await db.scalars(select(Invoice).where(
            Invoice.status == "open", Invoice.kind == "topup",
            Invoice.created_at <= now - timedelta(days=2)))).all():
        inv.status = "void"
        inv.voided_at = now
        inv.note = "Carregamento não concluído"
    await db.commit()
    return n


# =========================================================================== cobrar
def _grace_until(first_failed: datetime, *, no_method: bool) -> datetime:
    s = get_settings()
    days = max(s.grace_period_days, s.payment_method_grace_days) if no_method else s.grace_period_days
    return first_failed + timedelta(days=days)


async def _subs_of_invoice(db: AsyncSession, inv: Invoice) -> list[Subscription]:
    ids = (await db.scalars(select(InvoiceLine.subscription_id).where(
        InvoiceLine.invoice_id == inv.id, InvoiceLine.subscription_id.is_not(None)))).all()
    subs = [await db.get(Subscription, i) for i in set(ids)]
    return [s for s in subs if s is not None]


async def _record_payment(db: AsyncSession, inv: Invoice, pm: PaymentMethod, res: ChargeResult,
                          attempt: int | None = None) -> Payment:
    status = {"succeeded": "paid", "processing": "pending", "failed": "failed"}[res.status]
    pay = None
    if res.provider_payment_id:
        pay = await db.scalar(select(Payment).where(Payment.provider == pm.provider,
                                                    Payment.provider_payment_id == res.provider_payment_id))
    if pay is None:
        n = attempt if attempt is not None else inv.attempt_count + 1
        pay = Payment(provider=pm.provider,
                      provider_payment_id=res.provider_payment_id or f"local-{inv.id}-{n}-{pm.id[:8]}",
                      amount_cents=inv.total_cents, status=status)
        db.add(pay)
    pay.user_id = inv.user_id
    pay.invoice_id = inv.id
    pay.payment_method_id = pm.id
    pay.currency = inv.currency
    pay.status = status
    pay.description = f"Cobrança {inv.number}"
    pay.charge_date = utcnow()
    pay.failure_reason = res.failure_reason
    await db.flush()
    return pay


async def charge_invoice(db: AsyncSession, inv: Invoice, *, now: datetime | None = None,
                         method: PaymentMethod | None = None, notify: bool = True) -> str:
    """Tenta cobrar a cobrança com os métodos do cliente (predefinido primeiro, depois alternativas).

    Cada pedido ao fornecedor usa a chave de idempotência `inv-<id>-<tentativa>` e cada tentativa fica
    gravada (`attempt_count`) logo que o fornecedor responde. Assim:
      * uma falha de rede (ProviderError) não conta: a repetição usa a mesma chave → nunca há cobrança dupla;
      * quando um método é inutilizável e se passa ao seguinte, o seguinte usa a tentativa seguinte (chave
        nova). Reutilizar a chave com outro método dava erro de idempotência no Stripe (ou devolvia a recusa
        em cache do primeiro cartão) e o cliente ficava com a cobrança falhada tendo um método válido.
    """
    now = now or utcnow()
    inv = await lock_invoice(db, inv)
    if inv.status not in UNPAID_INVOICE or inv.total_cents <= 0:
        return inv.status
    user = await db.get(User, inv.user_id)
    assert user is not None
    usable = await usable_methods(db, user.id)
    if method is not None:
        # Um método escolhido tem de estar utilizável (fornecedor ligado, não expirado, não revogado).
        if method.id not in {m.id for m in usable}:
            raise BillingError("Esse método de pagamento não pode ser usado.")
        methods = [method]
    else:
        methods = usable
    attempt = inv.attempt_count + 1
    last: ChargeResult | None = None
    for pm in methods:
        provider = registry.get(pm.provider)
        if provider is None:
            continue
        try:
            res = await provider.charge(user, pm, inv, attempt)
        except ProviderError as exc:
            # A cobrança já está gravada (os chamadores fazem commit antes de cobrar): repetir usa a mesma chave
            # de idempotência (fatura + tentativa), por isso nunca há cobrança dupla.
            raise RetryLater(f"{pm.provider}: {exc}", 300) from exc
        await _record_payment(db, inv, pm, res, attempt)
        inv.payment_method_id = pm.id
        inv.attempt_count = attempt
        if res.status == "succeeded":
            await mark_paid(db, inv, now=now)
            return "paid"
        if res.status == "processing":
            inv.status = "processing"
            inv.next_attempt_at = None
            audit(db, "invoice.processing", target_type="invoice", target_id=inv.id, provider=pm.provider)
            # Igual à subscrição com cobrança síncrona: débito submetido → serviço ativo (se falhar, entra na
            # tolerância). Sem isto, uma primeira cobrança adiada (fornecedor em baixo) e depois submetida
            # deixava a subscrição "pendente" durante os dias do débito.
            await _activate_pending(db, inv, now)
            return "processing"
        last = res
        if res.method_unusable:
            await method_revoked(db, pm, res.failure_reason or "Método recusado pelo fornecedor", notify=False)
            attempt += 1  # o próximo método é outra tentativa (outra chave de idempotência)
            continue
        break
    await _mark_failed(db, inv, now=now, reason=(last.failure_reason if last else None),
                       no_method=last is None or last.method_unusable, notify=notify,
                       count_attempt=last is None)
    return "failed"


async def _mark_failed(db: AsyncSession, inv: Invoice, *, now: datetime, reason: str | None, no_method: bool,
                       notify: bool = True, count_attempt: bool = True) -> None:
    """Cobrança falhada: agenda a próxima tentativa (BILLING_RETRY_DAYS) e põe os serviços em tolerância.

    `count_attempt=False` quando a tentativa já foi contada (ex.: débito que estava "processing" e falhou
    depois): contá-la duas vezes saltava um dos dias de nova tentativa do calendário.
    """
    s = get_settings()
    if count_attempt:
        inv.attempt_count += 1
    if inv.kind == "topup":
        # Carregamento único recusado: não fica em dívida nem é repetido — o cliente vê o erro e tenta de novo.
        inv.status = "void"
        inv.voided_at = now
        inv.next_attempt_at = None
        inv.last_error = (reason or "Pagamento recusado")[:255]
        inv.note = "Carregamento recusado"
        audit(db, "wallet.topup_failed", target_type="invoice", target_id=inv.id, reason=inv.last_error)
        return
    inv.status = "failed"
    inv.last_error = (reason or ("Sem método de pagamento válido" if no_method else "Pagamento recusado"))[:255]
    inv.first_failed_at = inv.first_failed_at or now
    delays = s.retry_days
    n = max(inv.attempt_count, 1)
    inv.next_attempt_at = now + timedelta(days=delays[n - 1]) if n <= len(delays) else None
    grace = _grace_until(inv.first_failed_at, no_method=no_method)
    for sub in await _subs_of_invoice(db, inv):
        if sub.status in (SubStatus.active, SubStatus.bonus, SubStatus.past_due):
            await set_status(db, sub, SubStatus.past_due, reason=f"cobrança {inv.number} falhou", notify=False,
                             grace_until=sub.grace_until or grace)
        elif sub.status == SubStatus.canceling:
            # Cancelada com a cobrança por pagar: o acesso não vai até ao fim do período, só até ao fim da
            # tolerância (senão cancelar dava o resto do mês de graça).
            until = min(d for d in (sub.access_until, grace) if d is not None)
            if sub.access_until != until:
                sub.access_until = until
                await request_reconcile(db, sub.user_id)
    user = await db.get(User, inv.user_id)
    audit(db, "invoice.failed", target_type="invoice", target_id=inv.id, reason=inv.last_error,
          attempt=inv.attempt_count)
    if user and notify:
        await queue_email(db, user.email, "payment_method_needed" if no_method else "payment_failed",
                          amount=fmt_money(inv.total_cents, inv.currency), plan=f"cobrança {inv.number}",
                          grace_until=fmt_date(grace), reason=inv.last_error,
                          cta_url=f"{s.public_url}/app/faturacao")


async def debt_cleared(db: AsyncSession, user_id: str, *, reason: str, notify: bool = True) -> None:
    """Sem nada em dívida: o que estava em atraso/suspenso volta a ficar ativo e as cancelamentos recuperam o
    acesso até ao fim do período."""
    for sub in await live_subs(db, user_id):
        if sub.status in (SubStatus.past_due, SubStatus.suspended):
            await set_status(db, sub, SubStatus.active, reason=reason,
                             notify=notify and sub.status == SubStatus.suspended)
        elif sub.status == SubStatus.canceling and sub.current_period_end and (
                sub.access_until is None or sub.access_until < sub.current_period_end):
            sub.access_until = sub.current_period_end
            await request_reconcile(db, user_id)


async def _activate_pending(db: AsyncSession, inv: Invoice, now: datetime) -> None:
    """Ativa as subscrições que aguardavam esta (primeira) cobrança."""
    activated = []
    for sub in await _subs_of_invoice(db, inv):
        if sub.status == SubStatus.pending:
            await set_status(db, sub, SubStatus.active, reason=f"cobrança {inv.number} paga/submetida")
            activated.append(sub)
    user = await db.get(User, inv.user_id)
    if user and activated:
        # A cobrança podia estar pendente há muito (ex.: fornecedor em baixo, recusada e paga mais tarde):
        # entretanto o ciclo pode ter corrido sem esta subscrição e deixado next_billing_at vazio/adiante —
        # ficava ativa sem voltar a ser cobrada.
        ends = [s.current_period_end for s in activated if s.current_period_end]
        target = max(min(ends), now) if ends else next_anchor(user.billing_anchor_day or min(now.day, 28), now)
        if user.next_billing_at is None or user.next_billing_at > target:
            user.next_billing_at = target


async def mark_paid(db: AsyncSession, inv: Invoice, *, now: datetime | None = None) -> None:
    from .bonus import evaluate_user

    now = now or utcnow()
    if inv.status == "paid":
        return
    was_failed = inv.status == "failed" or inv.first_failed_at is not None
    inv.status = "paid"
    inv.paid_at = now
    inv.next_attempt_at = None
    inv.last_error = None
    audit(db, "invoice.paid", target_type="invoice", target_id=inv.id, amount=inv.total_cents)
    user = await db.get(User, inv.user_id)
    await _activate_pending(db, inv, now)
    if await wallet_svc.credit_topups(db, inv) > 0:
        # O saldo novo paga logo cobranças em atraso (ex.: carregamento feito para regularizar).
        await wallet_svc.settle_unpaid(db, inv.user_id)
    if not await unpaid_invoices(db, inv.user_id):
        await debt_cleared(db, inv.user_id, reason=f"cobrança {inv.number} paga")
        if user:
            await evaluate_user(db, user)
    if was_failed:
        audit(db, "invoice.recovered", target_type="invoice", target_id=inv.id)


async def apply_payment_result(db: AsyncSession, pay: Payment, res: ChargeResult, *, chargeback: bool = False
                               ) -> None:
    """Chamado pelos webhooks (e pela reconciliação) quando um pagamento muda de estado. Idempotente."""
    inv = await db.get(Invoice, pay.invoice_id) if pay.invoice_id else None
    prev = pay.status
    if res.status == "succeeded" and not chargeback:
        pay.status = "paid"
        if inv and inv.status not in ("paid", "void"):
            await mark_paid(db, inv)
        elif inv and prev != "paid":
            # Pago duas vezes (ex.: nova tentativa automática e "pagar agora" em simultâneo) ou pago depois de
            # anulada: o dinheiro entrou — o admin tem de devolver ou creditar.
            audit(db, "invoice.overpaid", target_type="invoice", target_id=inv.id, payment=pay.id,
                  amount=pay.amount_cents, invoice_status=inv.status)
            s = get_settings()
            if s.admin_notify_email:
                await queue_email(db, s.admin_notify_email, "admin_notice",
                                  subject=f"Pagamento a mais na cobrança {inv.number}",
                                  message=f"O pagamento {pay.provider_payment_id} ({fmt_money(pay.amount_cents)}) "
                                          f"chegou com a cobrança já {inv.status}. Devolve ou regista um crédito.")
        return
    if res.status == "processing" and not chargeback:
        if prev not in ("paid", "failed", "charged_back"):
            pay.status = "pending"
        return
    new = "charged_back" if chargeback else "failed"
    if prev == new or (prev == "charged_back" and not chargeback):
        return  # evento repetido (ex.: webhook depois da recusa síncrona, ou reenvio): já foi tratado
    pay.status = new
    pay.failure_reason = res.failure_reason
    if inv is None or inv.status == "void":
        return
    if inv.status == "paid":
        if not (chargeback or prev == "paid"):
            return  # outro pagamento já pagou esta cobrança
        # Estorno / falha tardia do pagamento que a pagou: a cobrança volta a estar por pagar.
        await wallet_svc.reverse_topups(db, inv, res.failure_reason or "pagamento estornado")
        inv.status = "failed"
        inv.paid_at = None
        await _mark_failed(db, inv, now=utcnow(), reason=res.failure_reason, no_method=False)
        return
    if inv.status in ("processing", "open", "failed"):
        # Falha assíncrona (ex.: débito devolvido): a tentativa já foi contada quando ficou "processing".
        was_processing = inv.status == "processing"
        await _mark_failed(db, inv, now=utcnow(), reason=res.failure_reason, no_method=False,
                           count_attempt=not was_processing)


async def provider_retrying(db: AsyncSession, pay: Payment, reason: str | None) -> None:
    """O banco recusou, mas o fornecedor vai tentar de novo sozinho (ex.: GoCardless Success+).

    Não é uma falha final: a cobrança continua "em curso", o serviço não entra em tolerância e o portal não
    agenda tentativas próprias. Só a desistência do fornecedor conta como falha.
    """
    inv = await db.get(Invoice, pay.invoice_id) if pay.invoice_id else None
    pay.status = "pending"
    pay.failure_reason = reason
    if inv is None or inv.status in ("paid", "void"):
        return
    inv.status = "processing"
    inv.next_attempt_at = None
    inv.last_error = (f"{reason or 'Recusado pelo banco'} — nova tentativa automática em curso")[:255]
    audit(db, "invoice.provider_retry", target_type="invoice", target_id=inv.id, reason=reason)


# =========================================================================== métodos de pagamento
async def method_revoked(db: AsyncSession, pm: PaymentMethod, reason: str, *, notify: bool = True) -> None:
    if pm.status == "revoked":
        return
    pm.status = "revoked"
    pm.status_reason = reason[:255]
    was_default = pm.is_default
    pm.is_default = False
    audit(db, "payment_method.revoked", target_type="user", target_id=pm.user_id, method=pm.label, reason=reason)
    others = await usable_methods(db, pm.user_id)
    if was_default and others:
        others[0].is_default = True
    if notify and not others and await live_subs(db, pm.user_id):
        await _notify_method_needed(db, pm.user_id, reason)


async def _notify_method_needed(db: AsyncSession, user_id: str, reason: str) -> None:
    s = get_settings()
    user = await db.get(User, user_id)
    if not user:
        return
    deadline = user.next_billing_at or (utcnow() + timedelta(days=s.payment_method_grace_days))
    await queue_email(db, user.email, "payment_method_needed", reason=reason, grace_until=fmt_date(deadline),
                      amount="", plan="", cta_url=f"{s.public_url}/app/faturacao")


async def save_method(db: AsyncSession, user: User, provider: str, nm, *, make_default: bool = True) -> PaymentMethod:
    """Cria/atualiza um método guardado a partir do resultado de um fluxo do fornecedor."""
    acct = await registry.account_id(provider)
    pm = await db.scalar(select(PaymentMethod).where(PaymentMethod.provider == provider,
                                                     PaymentMethod.provider_ref == nm.provider_ref))
    if pm is None:
        pm = PaymentMethod(user_id=user.id, provider=provider, provider_ref=nm.provider_ref)
        db.add(pm)
    elif pm.user_id != user.id:
        raise BillingError("Este método de pagamento pertence a outra conta.")
    pm.provider_customer_id = nm.provider_customer_id
    pm.provider_account = acct or pm.provider_account
    pm.kind = nm.kind
    pm.label = nm.label
    pm.status = nm.status if nm.status in ("active", "pending") else "revoked"
    pm.status_reason = None
    pm.expires_at = nm.expires_at
    if provider == "gocardless":
        user.gocardless_customer_id = nm.provider_customer_id or user.gocardless_customer_id
        user.gocardless_mandate_id = nm.provider_ref
    await db.flush()
    if make_default or not await db.scalar(select(PaymentMethod.id).where(
            PaymentMethod.user_id == user.id, PaymentMethod.is_default.is_(True), PaymentMethod.id != pm.id)):
        await db.execute(update(PaymentMethod).where(PaymentMethod.user_id == user.id, PaymentMethod.id != pm.id)
                         .values(is_default=False))
        pm.is_default = True
    audit(db, "payment_method.added", actor=user, target_type="user", target_id=user.id, method=pm.label)
    return pm


async def set_default(db: AsyncSession, user: User, pm: PaymentMethod) -> None:
    if pm.user_id != user.id or pm.status not in USABLE_PM_STATUSES:
        raise BillingError("Este método não pode ser usado.")
    await db.execute(update(PaymentMethod).where(PaymentMethod.user_id == user.id).values(is_default=False))
    pm.is_default = True


async def remove_method(db: AsyncSession, user: User, pm: PaymentMethod) -> None:
    if pm.user_id != user.id:
        raise BillingError("Método não encontrado.")
    others = [m for m in await usable_methods(db, user.id) if m.id != pm.id]
    needs = any(s.status != SubStatus.canceling for s in await live_subs(db, user.id))
    if needs and not others and pm.status in USABLE_PM_STATUSES:
        raise BillingError("Adiciona outro método antes de remover este — tens serviços ativos.")
    provider = registry.get(pm.provider)
    if provider:
        await provider.release_method(pm)
    pm.status = "revoked"
    pm.status_reason = REMOVED_REASON
    if pm.is_default:
        pm.is_default = False
        if others:
            others[0].is_default = True


async def check_methods(db: AsyncSession) -> dict:
    """Marca métodos de fornecedores desativados / contas trocadas e avisa os clientes afetados.

    Também reativa métodos quando o fornecedor volta a estar ligado com a mesma conta.
    """
    counts = {"unusable": 0, "restored": 0, "notified": 0, "expired": 0}
    states = await registry.state(db)
    now = utcnow()
    affected: set[str] = set()
    for name, st in states.items():
        acct = await registry.account_id(name) if st["enabled"] else None
        rows = (await db.scalars(select(PaymentMethod).where(
            PaymentMethod.provider == name, PaymentMethod.status.in_(["active", "pending", "unusable"])))).all()
        for pm in rows:
            if not st["enabled"]:
                reason = f"O pagamento por {st['method_label']} ({st['label']}) foi descontinuado."
            elif acct and pm.provider_account and pm.provider_account != acct:
                reason = f"Mudámos de conta {st['label']}: é preciso autorizar de novo o método de pagamento."
            else:
                reason = None
                if acct and not pm.provider_account:
                    pm.provider_account = acct
            if reason and pm.status != "unusable":
                pm.status = "unusable"
                pm.status_reason = reason
                counts["unusable"] += 1
                affected.add(pm.user_id)
            elif reason is None and pm.status == "unusable" and (acct is not None or not pm.provider_account):
                # Só se reativa com a conta confirmada: sem rede `account_id` é None e reativava métodos de
                # uma conta antiga (que depois falhavam na cobrança).
                pm.status = "active"
                pm.status_reason = None
                counts["restored"] += 1
        # Cartões que expiram este mês: avisar antes
    for pm in (await db.scalars(select(PaymentMethod).where(
            PaymentMethod.status == "active", PaymentMethod.expires_at.is_not(None),
            PaymentMethod.expires_at <= now + timedelta(days=20), PaymentMethod.notified_at.is_(None)))).all():
        pm.notified_at = now
        affected.add(pm.user_id)
        counts["expired"] += 1
    for uid in affected:
        if await live_subs(db, uid) and not [m for m in await usable_methods(db, uid)
                                            if not (m.expires_at and m.expires_at <= now + timedelta(days=20))]:
            pm_reason = next((m.status_reason for m in (await db.scalars(select(PaymentMethod).where(
                PaymentMethod.user_id == uid, PaymentMethod.status == "unusable"))).all() if m.status_reason),
                "O teu método de pagamento está a expirar.")
            await _notify_method_needed(db, uid, pm_reason)
            counts["notified"] += 1
    await db.commit()
    return counts


# =========================================================================== fluxos alojados (checkout)
async def start_method_setup(db: AsyncSession, user: User, provider_name: str, *, intent: dict | None = None,
                             scope: str | None = None) -> dict:
    s = get_settings()
    if provider_name not in await registry.available_for_new(db):
        raise BillingError("Esse método de pagamento não está disponível.")
    provider = registry.get(provider_name)
    assert provider is not None
    co = Checkout(user_id=user.id, provider=provider_name, purpose="setup_pm", intent=intent,
                  plan_id=(intent or {}).get("plan_id"), session_scope=scope)
    db.add(co)
    await db.flush()
    back = "/app/streaming" if scope == "streaming" else "/app/faturacao"
    url = await provider.start_setup(db, user, co, return_url=f"{s.public_url}/app/pagamento/retorno?checkout={co.id}",
                                     cancel_url=f"{s.public_url}{back}?cancelado=1")
    audit(db, "checkout.start", actor=user, target_type="checkout", target_id=co.id, provider=provider_name,
          purpose="setup_pm")
    await db.commit()
    return {"checkout_id": co.id, "redirect_url": url}


async def start_invoice_payment(db: AsyncSession, user: User, inv: Invoice, provider_name: str) -> dict:
    s = get_settings()
    if inv.user_id != user.id or inv.status not in UNPAID_INVOICE or inv.total_cents <= 0:
        raise BillingError("Esta cobrança não está por pagar.")
    if provider_name not in await registry.available_for_new(db):
        raise BillingError("Esse método de pagamento não está disponível.")
    provider = registry.get(provider_name)
    assert provider is not None
    co = Checkout(user_id=user.id, provider=provider_name, purpose="pay_invoice", invoice_id=inv.id)
    db.add(co)
    await db.flush()
    url = await provider.start_payment(db, user, co, inv,
                                       return_url=f"{s.public_url}/app/pagamento/retorno?checkout={co.id}",
                                       cancel_url=f"{s.public_url}/app/faturacao?cancelado=1")
    await db.commit()
    return {"checkout_id": co.id, "redirect_url": url}


async def complete_checkout(db: AsyncSession, co: Checkout) -> Checkout:
    """Idempotente: chamado no regresso do cliente, pelos webhooks e pela reconciliação."""
    if co.status != "pending" or not co.provider_ref:
        return co
    provider = registry.get(co.provider)
    user = await db.get(User, co.user_id)
    if provider is None or user is None:
        return co
    try:
        out = await provider.complete_checkout(db, user, co)
    except ProviderError as exc:
        raise RetryLater(str(exc), 60) from exc
    if out.state == "cancelled":
        co.status = "cancelled"
        return co
    if out.state != "completed":
        return co
    pm = None
    if out.method is not None:
        pm = await save_method(db, user, co.provider, out.method)
        co.payment_method_id = pm.id
    co.status = "completed"
    co.completed_at = utcnow()
    if co.purpose == "pay_invoice" and co.invoice_id:
        inv = await db.get(Invoice, co.invoice_id)
        if inv and out.charge:
            if pm is None:
                pm = await default_method(db, user.id)
            if pm is not None:
                if out.charge.status != "failed":
                    inv.attempt_count += 1
                pay = await _record_payment(db, inv, pm, out.charge)
                # Registado como pendente e depois aplicado o resultado real: com o estado final já gravado,
                # apply_payment_result via-o como "evento repetido" e uma recusa aqui não contava.
                pay.status = "pending"
                await apply_payment_result(db, pay, out.charge)
                if out.charge.status == "processing" and inv.status in UNPAID_INVOICE:
                    inv.status = "processing"
    elif co.purpose == "setup_pm":
        # Um método novo resolve cobranças em atraso: tenta já.
        for inv in await unpaid_invoices(db, user.id):
            await enqueue(db, "billing_charge", {"invoice_id": inv.id}, dedupe_key=f"charge:{inv.id}")
        intent = co.intent or {}
        if intent.get("action") == "monthly_topup" and pm is not None and intent.get("amount_cents"):
            try:
                await wallet_svc.set_monthly(db, user, int(intent["amount_cents"]),
                                             skip_when_covered=bool(intent.get("skip_when_covered", True)))
            except wallet_svc.WalletError as exc:
                co.error = str(exc)[:500]
        if intent.get("action") == "subscribe" and intent.get("monthly_topup_cents") and pm is not None:
            try:
                await wallet_svc.set_monthly(db, user, int(intent["monthly_topup_cents"]), skip_when_covered=True)
            except wallet_svc.WalletError as exc:
                co.error = str(exc)[:500]
        if intent.get("action") == "subscribe" and intent.get("plan_id") and pm is not None:
            await db.commit()  # método guardado e checkout concluído, aconteça o que acontecer a seguir
            plan = await db.get(Plan, int(intent["plan_id"]))
            if plan is not None:
                co_id = co.id
                try:
                    sub = await subscribe(db, user, plan, method=pm, scope=co.session_scope)
                    co.intent = {**intent, "subscription_id": sub.id}
                except BillingError as exc:
                    await db.rollback()
                    co = await db.get(Checkout, co_id)
                    assert co is not None
                    await db.refresh(co)
                    co.error = str(exc)[:500]
    return co


# =========================================================================== subscrever / mudar / cancelar
@dataclass
class Quote:
    kind: str                      # new | change
    lines: list[dict] = field(default_factory=list)
    due_now_cents: int = 0         # cobrado já
    next_invoice_cents: int = 0    # somado à próxima cobrança
    next_billing_at: datetime | None = None
    period_end: datetime | None = None
    recurring_cents: int = 0       # preço normal por período depois disto
    interval_unit: str = "month"
    interval_count: int = 1
    bonus_applies: bool = False
    is_upgrade: bool | None = None
    wallet_balance_cents: int = 0  # saldo atual da carteira
    wallet_cents: int = 0          # parte do que se paga já que sai da carteira
    charge_now_cents: int = 0      # o que é cobrado já ao método de pagamento (depois da carteira)

    def as_dict(self) -> dict:
        return {k: (v.isoformat() if isinstance(v, datetime) else v) for k, v in self.__dict__.items()}


def _charge_now(first_purchase: bool, fresh_anchor: bool) -> bool:
    s = get_settings()
    if fresh_anchor:
        return True
    if first_purchase and s.charge_first_purchase_immediately:
        return True
    return s.proration_charge == "immediate"


async def quote_new(db: AsyncSession, user: User, plan: Plan, now: datetime | None = None) -> Quote:
    now = now or utcnow()
    live = await live_subs(db, user.id)
    fresh = not live or not user.billing_anchor_day
    legacy_next = None
    if fresh:
        # Cliente antigo com a subscrição ainda na GoCardless: ao aderir, ela passa para o portal e o dia de
        # faturação fica o da próxima cobrança da GoCardless — a pré-visualização já mostra o pro-rata até lá.
        from .legacy import legacy_anchor

        legacy_next = await legacy_anchor(db, user)
        if legacy_next and legacy_next > now:
            fresh = False
    if fresh:
        start_anchor = anchor_on(now.year, now.month, min(now.day, 28))
        end = add_interval(start_anchor, plan.interval_unit, plan.interval_count)
        amount = plan.price_cents
        next_billing = end if plan.interval_unit != "year" else next_anchor(min(now.day, 28), now)
        desc = f"{plan.name} · {_range(now, end)}"
    else:
        if user.billing_anchor_day or legacy_next is None:
            end = next_anchor(user.billing_anchor_day, now)
        else:
            end = anchor_on(legacy_next.year, legacy_next.month, min(legacy_next.day, 28))
        amount = prorate(plan.price_cents, now, end, plan)
        next_billing = user.next_billing_at or end
        desc = f"{plan.name} (pro-rata) · {_range(now, end)}"
    product = await db.get(Product, plan.product_id)
    q = Quote(kind="new", period_end=end, next_billing_at=next_billing, recurring_cents=plan.price_cents,
              interval_unit=plan.interval_unit, interval_count=plan.interval_count)
    q.lines.append({"description": desc, "amount_cents": amount, "kind": "proration" if not fresh else "renewal"})
    q.bonus_applies = bool(product and product.bonus_eligible and await bonus_eligible_now(db, user))
    if q.bonus_applies:
        q.lines.append({"description": "Bónus de convites", "amount_cents": -amount, "kind": "bonus"})
        amount = 0
    if _charge_now(not await has_paid_before(db, user.id), fresh):
        q.due_now_cents = amount
    else:
        q.next_invoice_cents = amount
    await _apply_wallet_to_quote(db, user, q)
    return q


async def _apply_wallet_to_quote(db: AsyncSession, user: User, q: Quote) -> None:
    if not get_settings().wallet_enabled:
        q.charge_now_cents = q.due_now_cents
        return
    q.wallet_balance_cents = await wallet_svc.balance(db, user.id)
    q.wallet_cents = min(max(q.wallet_balance_cents, 0), max(q.due_now_cents, 0))
    q.charge_now_cents = max(q.due_now_cents - q.wallet_cents, 0)


async def subscribe(db: AsyncSession, user: User, plan: Plan, *, method: PaymentMethod | None = None,
                    scope: str | None = None, now: datetime | None = None) -> Subscription:
    from .bonus import evaluate_user
    from .catalog import product_unlocked

    now = now or utcnow()
    user = await lock_user(db, user)
    product = await db.get(Product, plan.product_id)
    if product is None or not product.is_active or not plan.is_active:
        raise BillingError("Este plano não está disponível.")
    from .legacy import convert_user

    # Subscrições antigas ainda na GoCardless passam já para o portal (mesmo mandato, mesmo dia) — sem ação do
    # cliente — e o serviço novo junta-se a elas na mesma cobrança mensal.
    if (await db.scalar(select(Subscription.id).where(Subscription.user_id == user.id,
                                                      Subscription.product_id == plan.product_id,
                                                      Subscription.provider == "gocardless",
                                                      Subscription.status.in_([s.value for s in LIVE_BILLING]))
                        .limit(1))) is None:
        await convert_user(db, user, reason="adesão a outro serviço")
    if not product_unlocked(user, product):
        raise BillingError("Este serviço está em beta fechado — mete um código de convite para o desbloquear.")
    if scope == "streaming" and not product.jellyfin_managed:
        raise BillingError("A partir do Jellyfin só é possível gerir o streaming.")
    current = await live_sub_for_product(db, user.id, plan.product_id)
    if current is not None:
        if current.status == SubStatus.canceling and current.plan_id == plan.id:
            raise BillingError("Esta subscrição está cancelada — reativa-a em vez de subscrever de novo.")
        raise BillingError("Já tens este serviço — usa 'Mudar de plano'.")
    if await unpaid_invoices(db, user.id):
        raise BillingError("Tens uma cobrança por pagar. Regulariza-a primeiro em Faturação.")
    usable = await usable_methods(db, user.id)
    if method is None:
        method = usable[0] if usable else None
    elif method.id not in {m.id for m in usable}:
        # Validar antes de gravar: depois do commit da subscrição pendente já não havia volta atrás.
        raise BillingError("Esse método de pagamento não pode ser usado.")

    q = await quote_new(db, user, plan, now)
    wallet_row = await db.get(Wallet, user.id) if get_settings().wallet_enabled else None
    monthly = (wallet_row.monthly_topup_cents or 0) if wallet_row else 0
    to_pay = q.due_now_cents + q.next_invoice_cents
    covered = q.wallet_balance_cents >= to_pay
    if get_settings().billing_require_method and method is None and not wallet_svc.is_wallet_only(user):
        raise BillingError("Autoriza primeiro o pagamento (débito direto ou cartão) para aderir.")
    if wallet_svc.is_wallet_only(user):
        # Contas novas: os serviços pagam-se sempre pela carteira — com saldo, ou com o carregamento mensal (que
        # cobra o que faltar no mesmo débito).
        if not covered and not (monthly and method is not None):
            raise BillingError("Carrega a carteira ou ativa o carregamento mensal para aderir.")
    elif method is None and not covered:
        raise BillingError("Adiciona um método de pagamento primeiro.")

    fresh = not await live_subs(db, user.id) or not user.billing_anchor_day
    prev_anchor, prev_next = user.billing_anchor_day, user.next_billing_at
    if fresh:
        user.billing_anchor_day = min(now.day, 28)
    start = now
    amount = q.lines[0]["amount_cents"]
    sub = Subscription(user_id=user.id, plan_id=plan.id, product_id=plan.product_id, provider="portal",
                       status=SubStatus.pending, price_cents=plan.price_cents, current_period_start=start,
                       current_period_end=q.period_end, period_amount_cents=0 if q.bonus_applies else amount,
                       started_at=now)
    db.add(sub)
    await db.flush()
    line = InvoiceLine(user_id=user.id, subscription_id=sub.id, product_id=plan.product_id,
                       kind="renewal" if fresh else "proration", amount_cents=amount,
                       period_start=start, period_end=q.period_end, description=q.lines[0]["description"])
    lines = [line]
    if q.bonus_applies:
        lines.append(InvoiceLine(user_id=user.id, kind="bonus", amount_cents=-amount,
                                 description="Bónus de convites — serviço sem custo 🎁"))
    user.next_billing_at = min(filter(None, [user.next_billing_at if not fresh else None, q.next_billing_at]))
    audit(db, "subscription.created", actor=user, target_type="subscription", target_id=sub.id, plan=plan.code,
          amount=amount, charged_now=q.due_now_cents > 0 or (fresh and amount == 0))

    if q.due_now_cents > 0 or (q.due_now_cents == 0 and q.next_invoice_cents == 0):
        # Dia de faturação novo: esta cobrança é a do ciclo, por isso leva também o carregamento mensal.
        inv = await _finalize(db, user, lines, kind="immediate", now=now, topup_cents=monthly if fresh else 0,
                              skip_topup_when_covered=bool(wallet_row.monthly_skip_when_covered)
                              if wallet_row else True)
        if inv and inv.status == "open":
            await db.commit()  # subscrição (pendente) e cobrança gravadas antes de cobrar
            result = await charge_or_defer(db, inv, now=now, method=method, notify=False)
            if result == "failed":
                # Primeira cobrança recusada de imediato (ex.: cartão recusado): anula tudo.
                inv.status = "void"
                inv.voided_at = utcnow()
                inv.note = "Subscrição não criada: pagamento recusado"
                await wallet_svc.refund_invoice(db, inv, "pagamento recusado")
                sub.status = SubStatus.ended
                sub.ended_at = utcnow()
                user.billing_anchor_day, user.next_billing_at = prev_anchor, prev_next
                if not await live_subs(db, user.id) and not await pending_lines(db, user.id):
                    user.next_billing_at = None
                await db.commit()
                raise BillingError(f"O pagamento foi recusado: {inv.last_error or 'tenta outro método'}")
            if result == "deferred":
                # O fornecedor não respondeu: a cobrança fica agendada e a subscrição ativa-se quando for paga.
                return sub
    else:
        db.add(line)  # pendente → entra na próxima cobrança (o bónus é aplicado nessa altura, se couber)
    await set_status(db, sub, SubStatus.active, reason="subscrição criada")
    await evaluate_user(db, user)  # produto com bónus e cliente elegível → fica logo em "bónus"
    return sub


async def quote_change(db: AsyncSession, user: User, sub: Subscription, new_plan: Plan,
                       now: datetime | None = None) -> Quote:
    now = now or utcnow()
    old_plan = await db.get(Plan, sub.plan_id)
    assert old_plan is not None
    credit = unused_credit(sub, now)
    end = next_anchor(user.billing_anchor_day or min(now.day, 28), now)
    new_amount = prorate(new_plan.price_cents, now, end, new_plan)
    q = Quote(kind="change", period_end=end, next_billing_at=user.next_billing_at or end,
              recurring_cents=new_plan.price_cents, interval_unit=new_plan.interval_unit,
              interval_count=new_plan.interval_count)
    old_m = monthly_equivalent(plan_price(sub, old_plan), old_plan)
    q.is_upgrade = monthly_equivalent(new_plan.price_cents, new_plan) > old_m
    if credit:
        q.lines.append({"description": f"Crédito do tempo não usado de {old_plan.name}", "amount_cents": -credit,
                        "kind": "credit"})
    q.lines.append({"description": f"{new_plan.name} (pro-rata) · {_range(now, end)}", "amount_cents": new_amount,
                    "kind": "proration"})
    product = await db.get(Product, new_plan.product_id)
    net = new_amount - credit
    q.bonus_applies = bool(product and product.bonus_eligible and sub.status == SubStatus.bonus)
    if q.bonus_applies and new_amount > 0:
        # O bónus isenta o novo plano; o crédito do tempo já pago continua a ser do cliente (igual ao que a
        # cobrança do ciclo faz em _bonus_line).
        q.lines.append({"description": "Bónus de convites", "amount_cents": -new_amount, "kind": "bonus"})
        net = -credit
    if net > 0 and get_settings().proration_charge == "immediate" and net >= get_settings().billing_min_charge_cents:
        q.due_now_cents = net
    else:
        q.next_invoice_cents = net
    await _apply_wallet_to_quote(db, user, q)
    return q


async def change_plan(db: AsyncSession, user: User, sub: Subscription, new_plan: Plan, *,
                      scope: str | None = None, now: datetime | None = None, charge_now: bool = True) -> Quote:
    """Muda de plano com pro-rata. `charge_now=False` (migrações do admin) põe tudo na próxima cobrança."""
    now = now or utcnow()
    user, sub = await lock_for_change(db, user, sub)
    if sub.user_id != user.id:
        raise BillingError("Subscrição não encontrada.")
    product = await db.get(Product, sub.product_id)
    if scope == "streaming" and not (product and product.jellyfin_managed):
        raise BillingError("A partir do Jellyfin só é possível gerir o streaming.")
    if sub.provider == "gocardless" and sub.user_id == user.id:
        from .legacy import convert_user

        await convert_user(db, user, reason="mudança de plano")
    if sub.provider != "portal":
        raise BillingError("Esta subscrição ainda está no sistema antigo — contacta o suporte.")
    if sub.status not in (SubStatus.active, SubStatus.bonus):
        raise BillingError("Só é possível mudar de plano numa subscrição ativa e em dia.")
    if new_plan.product_id != sub.product_id or not new_plan.is_active:
        raise BillingError("Plano inválido para esta subscrição.")
    if new_plan.id == sub.plan_id:
        raise BillingError("Já estás neste plano.")
    q = await quote_change(db, user, sub, new_plan, now)
    if not charge_now and q.due_now_cents:
        q.next_invoice_cents, q.due_now_cents = q.due_now_cents, 0
    old_plan_id = sub.plan_id
    new_lines = []
    for ln in q.lines:
        if ln["kind"] == "bonus":
            continue  # o bónus é calculado quando a cobrança é emitida
        new_lines.append(InvoiceLine(user_id=user.id, subscription_id=sub.id, product_id=sub.product_id,
                                     kind=ln["kind"], amount_cents=ln["amount_cents"], description=ln["description"],
                                     period_start=now if ln["kind"] == "proration" else None,
                                     period_end=q.period_end if ln["kind"] == "proration" else None))
    db.add_all(new_lines)
    sub.plan_id = new_plan.id
    sub.price_cents = new_plan.price_cents
    sub.current_period_start = now
    sub.current_period_end = q.period_end
    sub.period_amount_cents = sum(ln["amount_cents"] for ln in q.lines if ln["kind"] == "proration") \
        if not q.bonus_applies else 0
    sub.pending_plan_id = None
    sub.cancel_at_period_end = False
    audit(db, "subscription.plan_changed", actor=user, target_type="subscription", target_id=sub.id,
          old=old_plan_id, new=new_plan.id, net=q.due_now_cents + q.next_invoice_cents)
    if q.due_now_cents > 0:
        # Só as linhas desta mudança (o que a pré-visualização mostrou); outras linhas pendentes da mesma
        # subscrição (ex.: pro-rata de quando foi adicionada) continuam para a cobrança do ciclo.
        inv = await _finalize(db, user, new_lines, kind="immediate", now=now)
        if inv and inv.status == "open":
            await db.commit()
            await charge_or_defer(db, inv, now=now)
    await request_reconcile(db, user.id)
    from .fulfillment import on_subscription_change

    await on_subscription_change(db, sub, "updated")
    return q


async def cancel(db: AsyncSession, user: User, sub: Subscription, *, scope: str | None = None) -> None:
    user, sub = await lock_for_change(db, user, sub)
    product = await db.get(Product, sub.product_id)
    if scope == "streaming" and not (product and product.jellyfin_managed):
        raise BillingError("A partir do Jellyfin só é possível gerir o streaming.")
    if sub.user_id != user.id or sub.status not in (SubStatus.active, SubStatus.bonus, SubStatus.past_due):
        raise BillingError("Esta subscrição não pode ser cancelada.")
    if sub.provider == "gocardless":
        from .legacy import convert_user

        await convert_user(db, user, reason="cancelamento")
    if sub.provider != "portal":
        # Oferta do admin ("manual") ou subscrição antiga ainda cobrada pelo fornecedor: cancelar aqui não parava a
        # cobrança no fornecedor (o cliente continuava a pagar) nem faz sentido para uma oferta.
        raise BillingError("Esta subscrição não pode ser cancelada aqui — contacta o suporte.")
    access_until = sub.current_period_end
    if sub.status == SubStatus.past_due:
        # Com a cobrança por pagar, cancelar não pode dar o resto do período: só a tolerância que já tinha.
        access_until = min(d for d in (sub.current_period_end, sub.grace_until or utcnow()) if d is not None)
    await set_status(db, sub, SubStatus.canceling, reason="cancelada pelo cliente", access_until=access_until,
                     cancel_at_period_end=True)
    audit(db, "subscription.cancel", actor=user, target_type="subscription", target_id=sub.id)


async def resume(db: AsyncSession, user: User, sub: Subscription, *, scope: str | None = None) -> None:
    user, sub = await lock_for_change(db, user, sub)
    product = await db.get(Product, sub.product_id)
    if scope == "streaming" and not (product and product.jellyfin_managed):
        raise BillingError("A partir do Jellyfin só é possível gerir o streaming.")
    if sub.provider == "gocardless" and sub.user_id == user.id:
        from .legacy import convert_user

        await convert_user(db, user, reason="reativação")
    if sub.user_id != user.id or sub.status != SubStatus.canceling or sub.provider != "portal":
        raise BillingError("Esta subscrição não está cancelada.")
    if sub.current_period_end and sub.current_period_end <= utcnow():
        raise BillingError("O período já terminou — subscreve de novo.")
    if not await default_method(db, user.id):
        w = await db.get(Wallet, user.id)
        if get_settings().billing_require_method or not (w and (w.balance_cents > 0 or w.monthly_topup_cents)):
            raise BillingError("Autoriza um método de pagamento (débito direto ou cartão) para reativar.")
    await set_status(db, sub, SubStatus.active, reason="reativada pelo cliente", access_until=None,
                     cancel_at_period_end=False)
    from .bonus import evaluate_user

    await evaluate_user(db, user)
    audit(db, "subscription.resume", actor=user, target_type="subscription", target_id=sub.id)


# =========================================================================== bónus (estado visível)
async def _sync_bonus_status(db: AsyncSession, user: User) -> str | None:
    """Mantém o estado 'bonus' das subscrições elegíveis coerente com o número de convidados pagantes."""
    eligible = await bonus_eligible_now(db, user)
    changed = None
    for sub in await live_subs(db, user.id):
        prod = await _product(db, sub.product_id)
        if not prod or not prod.bonus_eligible:
            continue
        if eligible and sub.status == SubStatus.active:
            await set_status(db, sub, SubStatus.bonus, reason="bónus de convites", notify=False)
            changed = "on"
        elif not eligible and sub.status == SubStatus.bonus:
            await set_status(db, sub, SubStatus.active, reason="bónus terminado", notify=False)
            changed = "off"
    return changed


# =========================================================================== resumo / pré-visualização
async def preview_next(db: AsyncSession, user: User) -> dict:
    """Pré-visualização da próxima cobrança (sem gravar nada)."""
    when = user.next_billing_at
    lines: list[dict] = []
    if when is None:
        return {"at": None, "lines": [], "total_cents": 0}
    for sub in await live_subs(db, user.id):
        if SubStatus(sub.status) in (SubStatus.canceling, SubStatus.suspended) or sub.cancel_at_period_end:
            continue
        if not sub.current_period_end or sub.current_period_end > when:
            continue
        plan = await db.get(Plan, sub.pending_plan_id or sub.plan_id)
        assert plan
        if sub.pending_plan_id:
            price = int((sub.meta or {}).get("pending_price_cents", plan.price_cents))
        else:
            price = plan_price(sub, plan)
        change = await db.scalar(select(PriceChange).where(
            PriceChange.plan_id == plan.id, PriceChange.cancelled_at.is_(None),
            PriceChange.effective_at <= sub.current_period_end).order_by(PriceChange.effective_at.desc()).limit(1))
        if change and (price == change.old_price_cents or (sub.price_cents is None and not sub.pending_plan_id)):
            price = change.new_price_cents
        end = add_interval(sub.current_period_end, plan.interval_unit, plan.interval_count)
        lines.append({"description": f"{plan.name} · {_range(sub.current_period_end, end)}", "amount_cents": price,
                      "kind": "renewal", "product_id": sub.product_id, "subscription_id": sub.id})
    for ln in await pending_lines(db, user.id):
        lines.append({"description": ln.description, "amount_cents": ln.amount_cents, "kind": ln.kind,
                      "product_id": ln.product_id, "subscription_id": ln.subscription_id})
    if await bonus_eligible_now(db, user):
        waive = 0
        for ln in lines:
            prod = await _product(db, ln.get("product_id"))
            if prod and prod.bonus_eligible and ln["kind"] in BONUS_WAIVABLE and ln["amount_cents"] > 0:
                waive += ln["amount_cents"]
        if waive > 0:
            lines.append({"description": "Bónus de convites 🎁", "amount_cents": -waive, "kind": "bonus"})
    total = max(0, sum(ln["amount_cents"] for ln in lines))
    services = total
    w = await db.get(Wallet, user.id) if get_settings().wallet_enabled else None
    wallet_use = 0
    if w and total > 0 and w.balance_cents > 0:
        wallet_use = min(w.balance_cents, total)
        lines.append({"description": "Pago com o saldo da carteira", "amount_cents": -wallet_use, "kind": "wallet"})
        total -= wallet_use
    topup = (w.monthly_topup_cents or 0) if w and wallet_svc.monthly_enabled() else 0
    topup_skipped = False
    if topup:
        if services > 0 and total == 0 and w.monthly_skip_when_covered:
            topup_skipped = True
        else:
            lines.append({"description": f"Carregamento mensal da carteira ({fmt_money(topup)})",
                          "amount_cents": topup, "kind": "mtopup"})
            use = min(topup, total)
            if use:
                lines.append({"description": "Parte do carregamento usada nesta cobrança", "amount_cents": -use,
                              "kind": "topup_use"})
            total += topup - use
    return {"at": when.isoformat(), "lines": lines, "total_cents": total, "services_cents": services,
            "wallet_cents": wallet_use, "topup_cents": 0 if topup_skipped else topup, "topup_skipped": topup_skipped}


async def mrr_cents(db: AsyncSession) -> int:
    rows = (await db.execute(select(Subscription, Plan).join(Plan, Plan.id == Subscription.plan_id).where(
        Subscription.provider == "portal",
        Subscription.status.in_([SubStatus.active.value, SubStatus.past_due.value, SubStatus.canceling.value])))).all()
    return round(sum(monthly_equivalent(plan_price(s, p), p) for s, p in rows))


async def open_invoice_count(db: AsyncSession) -> int:
    return int(await db.scalar(select(func.count()).select_from(Invoice).where(
        Invoice.status.in_(["open", "failed"]))) or 0)


# re-export útil para outros módulos
__all__ = [
    "ENTITLED_STATUSES",
    "BillingError",
    "Quote",
    "apply_payment_result",
    "cancel",
    "change_plan",
    "charge_invoice",
    "check_methods",
    "complete_checkout",
    "or_",
    "preview_next",
    "quote_change",
    "quote_new",
    "resume",
    "run_cycle",
    "subscribe",
]
