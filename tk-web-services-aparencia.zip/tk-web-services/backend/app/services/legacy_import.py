"""Importação do site antigo (Flask/SQLite) — pela web (Admin → Migração) ou pela linha de comandos.

Passos (todos idempotentes; pode correr-se várias vezes):
  1. utilizadores: mesmo username, email e password (o hash antigo continua a funcionar e é atualizado no primeiro
     login), email já confirmado, login antigo no Jellyfin mantido, TKFLIX desbloqueado;
  2. contas Jellyfin e credenciais IPTV antigas ligadas;
  3. quem convidou quem;
  4. subscrições GoCardless: **ligadas e mantidas na GoCardless** (modo "manter") — passam sozinhas para o portal na
     primeira alteração do cliente; ou convertidas já, se o admin escolher;
  5. quem estava "a expirar" mantém o acesso até à data (oferta até ao fim do período pago).
"""
from __future__ import annotations

import logging
import sqlite3
from datetime import UTC, datetime

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..db import utcnow
from ..models import Grant, Plan, ServiceAccount, User
from ..security import USERNAME_RE, encrypt
from ..seed import seed_defaults
from .subscriptions import compute_access, request_reconcile

log = logging.getLogger("tkportal.legacy_import")

LEGACY_STATUS = {"Ativa": "active", "A expirar": "canceling", "Em dívida": "past_due", "Desativa": None,
                 "Bonus": "bonus"}


class ImportError_(ValueError):  # noqa: N801 — não confundir com o ImportError do Python
    pass


def read_rows(path: str) -> tuple[list[sqlite3.Row], set[str]]:
    try:
        con = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
        con.row_factory = sqlite3.Row
        tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if "user" not in tables:
            raise ImportError_("Este ficheiro não tem a tabela 'user' do site antigo (users.db).")
        cols = {r[1] for r in con.execute("PRAGMA table_info(user)")}
        rows = con.execute("SELECT * FROM user ORDER BY id").fetchall()
        con.close()
    except sqlite3.DatabaseError as exc:
        raise ImportError_(f"Não é uma base de dados SQLite válida: {exc}") from exc
    missing = {"id", "username", "email"} - cols
    if missing:
        raise ImportError_(f"Faltam colunas na tabela 'user': {', '.join(sorted(missing))}")
    return rows, cols


async def import_sqlite(db: AsyncSession, path: str, *, dry_run: bool = False, admin_username: str = "tkmaster",
                        fallback_plan: str = "tkflix-mensal", link_gocardless: bool = True,
                        keep_gocardless: bool = True) -> dict:
    """Importa o site antigo. Em `dry_run` nada é gravado (nem tocado na GoCardless)."""
    from .catalog import gated_codes, unlock

    rows, cols = read_rows(path)
    report: dict = {"total": len(rows), "new": 0, "existing": 0, "skipped": 0, "grants": 0, "iptv": 0,
                    "jellyfin": 0, "referrals": 0, "users": [], "warnings": [], "subscriptions": [],
                    "dry_run": dry_run}
    await seed_defaults(db)
    gated = await gated_codes(db)
    by_username: dict[str, User] = {}
    by_legacy_id: dict[int, User] = {}

    def col(r, name):
        return r[name] if name in cols else None

    for r in rows:
        email = (col(r, "email") or "").strip().lower()
        uname = (col(r, "username") or "").strip()
        if not email or not uname:
            report["skipped"] += 1
            report["warnings"].append(f"linha {r['id']}: sem email ou username — ignorada")
            continue
        user = await db.scalar(select(User).where((User.legacy_id == r["id"]) | (User.email == email)))
        state = "existente"
        if user is None:
            lower = uname.lower()
            if not USERNAME_RE.match(lower):
                report["warnings"].append(f"'{uname}': username fora das regras novas — importado na mesma "
                                          "(é o nome no Jellyfin)")
            if await db.scalar(select(User.id).where(User.username == lower)):
                report["warnings"].append(f"'{uname}': username já existe no portal com outro email — ignorado")
                report["skipped"] += 1
                continue
            user = User(username=lower, email=email, password_hash=col(r, "password") or "!", legacy_id=r["id"],
                        email_verified_at=utcnow(), is_admin=lower == admin_username.lower(),
                        billing_mode="legacy", jellyfin_password_login=True, unlocked_products=list(gated),
                        gocardless_customer_id=col(r, "gocardless_customer_id"),
                        gocardless_mandate_id=col(r, "gocardless_mandate_id"))
            db.add(user)
            await db.flush()
            report["new"] += 1
            state = "nova"
        else:
            user.legacy_id = user.legacy_id or r["id"]
            # Cliente migrado: mantém o login antigo no Jellyfin, pode pagar como antes e vê o TKFLIX.
            user.billing_mode = "legacy"
            user.jellyfin_password_login = True
            user.gocardless_customer_id = user.gocardless_customer_id or col(r, "gocardless_customer_id")
            user.gocardless_mandate_id = user.gocardless_mandate_id or col(r, "gocardless_mandate_id")
            unlock(user, list(gated))
            report["existing"] += 1
        by_username[uname.lower()] = user
        by_legacy_id[r["id"]] = user
        report["users"].append({"username": user.username, "email": email, "conta": state,
                                "estado_antigo": col(r, "subscription_status")})

        jf_id = col(r, "jellyfin_user_id")
        if jf_id and not await db.scalar(select(ServiceAccount.id).where(ServiceAccount.service == "jellyfin",
                                                                         ServiceAccount.user_id == user.id)):
            db.add(ServiceAccount(user_id=user.id, service="jellyfin", external_id=jf_id.replace("-", ""),
                                  external_username=uname))
            report["jellyfin"] += 1
        if col(r, "iptvusername"):
            if not await db.scalar(select(ServiceAccount.id).where(ServiceAccount.service == "iptv",
                                                                   ServiceAccount.user_id == user.id)):
                db.add(ServiceAccount(user_id=user.id, service="iptv", external_username=r["iptvusername"],
                                      secret_enc=encrypt(col(r, "iptvpwd") or ""), data={"host": col(r, "iptvhost")}))
                report["iptv"] += 1
    await db.flush()
    # Quem convidou quem: `invited_by` guarda o username de quem convidou (ou, em versões antigas, o id numérico).
    for r in rows:
        u = by_username.get((col(r, "username") or "").strip().lower())
        raw_ref = str(col(r, "invited_by") or "").strip()
        ref = by_username.get(raw_ref.lower()) if raw_ref else None
        if ref is None and raw_ref.isdigit():
            ref = by_legacy_id.get(int(raw_ref))
        if u and ref and u.id != ref.id and not u.referred_by_id:
            u.referred_by_id = ref.id
            report["referrals"] += 1
    if dry_run:
        # As subscrições GoCardless são simuladas a seguir com os utilizadores ainda na sessão.
        if link_gocardless:
            report["subscriptions"] = await _gocardless(db, dry_run=True, keep=keep_gocardless)
        await db.rollback()
        return report
    await db.commit()

    if link_gocardless:
        report["subscriptions"] = await _gocardless(db, dry_run=False, keep=keep_gocardless)

    # Quem estava 'A expirar' (subscrição já cancelada na GoCardless) mantém acesso até à data.
    fallback = await db.scalar(select(Plan).where(Plan.code == fallback_plan))
    for r in rows:
        u = by_username.get((col(r, "username") or "").strip().lower())
        if not u:
            continue
        u = await db.get(User, u.id) or u
        legacy_state = LEGACY_STATUS.get(col(r, "subscription_status"))
        access = await compute_access(db, u)
        if access.any_active or legacy_state is None:
            continue
        end_dt = _parse_dt(col(r, "subscription_end_date"))
        if legacy_state == "canceling" and end_dt and end_dt > utcnow() and fallback:
            if not await db.scalar(select(Grant.id).where(Grant.user_id == u.id, Grant.reason.like("Migração:%"))):
                db.add(Grant(user_id=u.id, plan_id=fallback.id, ends_at=end_dt,
                             reason="Migração: subscrição a expirar"))
                report["grants"] += 1
        elif legacy_state in ("active", "bonus", "past_due"):
            report["warnings"].append(f"{u.username}: estava '{col(r, 'subscription_status')}' no site antigo mas não "
                                      "há subscrição ativa na GoCardless — vê no painel (podes dar uma oferta).")
    for u in by_username.values():
        await request_reconcile(db, u.id)
    await db.commit()
    return report


async def _gocardless(db: AsyncSession, *, dry_run: bool, keep: bool) -> list[dict]:
    from ..config import get_settings
    from . import legacy

    if not get_settings().gocardless_enabled:
        return [{"result": "GoCardless não configurada — as subscrições são ligadas quando a configurares "
                           "(Admin → Migração → Ligar subscrições GoCardless)."}]
    try:
        return await legacy.migrate_all(db, dry_run=dry_run, keep=keep)
    except Exception as exc:  # noqa: BLE001
        log.exception("Ligação das subscrições GoCardless falhou")
        return [{"result": f"erro: {exc}"}]


def _parse_dt(value) -> datetime | None:
    if not value:
        return None
    try:
        d = datetime.fromisoformat(str(value))
    except ValueError:
        return None
    return d.replace(tzinfo=UTC) if d.tzinfo is None else d.astimezone(UTC)
