from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from ..models import AuditLog, User


def audit(
    db: AsyncSession,
    action: str,
    *,
    actor: User | None = None,
    actor_label: str | None = None,
    target_type: str | None = None,
    target_id: str | None = None,
    ip: str | None = None,
    **details,
) -> None:
    db.add(
        AuditLog(
            action=action,
            actor_id=actor.id if actor else None,
            actor_label=actor_label or (actor.username if actor else "system"),
            target_type=target_type,
            target_id=str(target_id) if target_id is not None else None,
            ip=ip,
            details=details or None,
        )
    )
