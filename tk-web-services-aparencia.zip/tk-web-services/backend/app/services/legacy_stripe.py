"""Migração das subscrições Stripe antigas (Stripe Billing — ex.: TKGPT) para a faturação do portal.

Para cada subscrição ativa (ou em período experimental) no Stripe:
  1. o cartão/SEPA já guardado no Stripe passa a ser o método de pagamento do cliente no portal — o cliente não
     tem de fazer nada (as cobranças seguintes são "merchant initiated", como as da subscrição);
  2. o cliente é encontrado pelo email (ou criado, com o email do Stripe — entra com "recuperar password" ou
     diretamente no LibreChat por SSO);
  3. o plano é encontrado pelo `stripe_price_id` (ou criado no produto TKGPT com o mesmo preço e periodicidade);
  4. o período já pago termina na data em que o Stripe ia cobrar; a partir daí cobra o portal, no mesmo dia;
  5. a subscrição Stripe é cancelada logo (sem pro-rata nem fatura final), para não haver cobranças duplicadas.

Idempotente: correr de novo não duplica nada (e volta a tentar cancelar no Stripe o que ficou por cancelar).
"""
from __future__ import annotations

import logging
import re
import secrets

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from ..db import utcnow
from ..integrations import stripe_client as sc
from ..models import Payment, Plan, Product, Subscription, SubStatus, User
from ..payments.stripe import describe_pm
from ..security import USERNAME_RE, hash_password
from .audit import audit
from .billing import anchor_on, save_method
from .subscriptions import add_interval, request_reconcile

log = logging.getLogger("tkportal.legacy.stripe")

MIGRATABLE = {"active", "trialing"}
UNITS = {"month": "month", "year": "year", "week": "week"}


def _id(v) -> str | None:
    if isinstance(v, dict):
        return v.get("id")
    return v


async def _product(db: AsyncSession, stripe_product: dict | str | None) -> Product:
    s = get_settings()
    meta = stripe_product.get("metadata") or {} if isinstance(stripe_product, dict) else {}
    code = meta.get("portal_product") or s.librechat_product_code
    p = await db.scalar(select(Product).where(Product.code == code))
    if p is None:
        name = (stripe_product.get("name") if isinstance(stripe_product, dict) else None) or "TKGPT"
        p = Product(code=code, name=name, description="Assistente de IA (LibreChat) — entra com a tua conta TK.",
                    kind="ai", fulfillment="none", icon="bot", bonus_eligible=False, is_active=True, sort_order=10)
        db.add(p)
        await db.flush()
    return p


async def _plan_for_price(db: AsyncSession, price: dict, *, dry_run: bool) -> Plan | None:
    plan = await db.scalar(select(Plan).where(Plan.stripe_price_id == price["id"]))
    if plan or dry_run:
        return plan
    rec = price.get("recurring") or {}
    unit = UNITS.get(rec.get("interval"), "month")
    count = int(rec.get("interval_count") or 1)
    product = await _product(db, price.get("product"))
    amount = int(price.get("unit_amount") or 0)
    code = f"{product.code}-{unit}-{amount}"
    if await db.scalar(select(Plan.id).where(Plan.code == code)):
        code = f"{code}-{price['id'][-6:].lower()}"
    pname = price.get("product").get("name") if isinstance(price.get("product"), dict) else product.name
    plan = Plan(product_id=product.id, code=code, name=price.get("nickname") or pname or product.name,
                price_cents=amount, currency=(price.get("currency") or "eur").upper(), interval_unit=unit,
                interval_count=count, stripe_price_id=price["id"], gocardless_enabled=True, features={},
                highlights=[], is_active=True, is_public=True)
    db.add(plan)
    await db.flush()
    return plan


async def _username_for(db: AsyncSession, email: str) -> str:
    base = re.sub(r"[^a-z0-9._-]", "", email.split("@")[0].lower())[:24] or "cliente"
    if len(base) < 3:
        base = f"{base}tk"
    cand = base
    while not USERNAME_RE.match(cand) or await db.scalar(select(User.id).where(User.username == cand)):
        cand = f"{base}{secrets.randbelow(9000) + 1000}"
    return cand


async def _user_for(db: AsyncSession, customer: dict, *, create: bool, dry_run: bool) -> tuple[User | None, bool]:
    email = (customer.get("email") or "").strip().lower()
    uid = (customer.get("metadata") or {}).get("portal_user_id")
    user = await db.get(User, uid) if uid else None
    if user is None and email:
        user = await db.scalar(select(User).where(User.email == email))
    if user is not None or not create or not email or dry_run:
        return user, False
    user = User(username=await _username_for(db, email), email=email,
                display_name=(customer.get("name") or None),
                # Sem password utilizável: entra com "recuperar password" ou por SSO a partir do LibreChat.
                password_hash=hash_password(secrets.token_urlsafe(32)),
                email_verified_at=utcnow(), billing_mode="legacy", jellyfin_password_login=False,
                unlocked_products=[], stripe_customer_id=customer.get("id"))
    db.add(user)
    await db.flush()
    return user, True


async def migrate_subscription(db: AsyncSession, st: dict, *, dry_run: bool = False, create_users: bool = True
                               ) -> dict:
    out = {"stripe_subscription": st["id"], "status": st.get("status")}
    customer = st.get("customer") if isinstance(st.get("customer"), dict) else await sc.retrieve_customer(
        _id(st.get("customer")))
    out["email"] = customer.get("email")
    existing = await db.scalar(select(Subscription).where(Subscription.provider_subscription_id == st["id"]))
    if existing:
        if not dry_run and st.get("status") in MIGRATABLE:
            await sc.cancel_now(st["id"])
            return {**out, "result": "já migrada (subscrição Stripe cancelada agora)", "subscription_id": existing.id}
        return {**out, "result": "já migrada", "subscription_id": existing.id}
    if st.get("status") not in MIGRATABLE:
        return {**out, "result": "ignorada (não ativa)"}
    if st.get("cancel_at_period_end"):
        return {**out, "result": "ignorada (já cancelada pelo cliente — termina sozinha no Stripe)"}
    items = (st.get("items") or {}).get("data") or []
    if len(items) != 1:
        return {**out, "result": f"ignorada ({len(items)} itens — migra à mão)"}
    price = items[0].get("price") or {}
    if isinstance(price, str) or not isinstance(price.get("product"), dict):
        price = await sc.retrieve_price(_id(price))
    pm_raw = st.get("default_payment_method")
    if not pm_raw:
        pm_id = ((customer.get("invoice_settings") or {}).get("default_payment_method"))
        pm_raw = await sc.retrieve_payment_method(_id(pm_id)) if pm_id else None
    elif isinstance(pm_raw, str):
        pm_raw = await sc.retrieve_payment_method(pm_raw)
    if not pm_raw:
        return {**out, "result": "sem método de pagamento guardado no Stripe — o cliente tem de o adicionar"}

    user, created = await _user_for(db, customer, create=create_users, dry_run=dry_run)
    if user is None and not dry_run:
        return {**out, "result": "sem conta no portal (usa sem --no-create-users para a criar)"}
    plan = await _plan_for_price(db, price, dry_run=dry_run)
    period_end = sc.sub_period_end(st)
    if period_end is None:
        return {**out, "result": "sem data de renovação no Stripe"}
    unit = plan.interval_unit if plan else UNITS.get((price.get("recurring") or {}).get("interval"), "month")
    count = plan.interval_count if plan else int((price.get("recurring") or {}).get("interval_count") or 1)
    day = min(period_end.day, 28)
    if user is not None and user.billing_anchor_day and user.billing_anchor_day != day:
        day = user.billing_anchor_day  # alinha com os outros serviços do cliente (uma só cobrança por mês)
    period_end = anchor_on(period_end.year, period_end.month, day)
    period_start = sc.sub_period_start(st) or add_interval(period_end, unit, -count)
    amount = int(price.get("unit_amount") or (plan.price_cents if plan else 0))
    out.update({"user": user.username if user else "(nova conta)", "plan": plan.code if plan else price.get("id"),
                "price_cents": amount, "paid_until": period_end.isoformat(), "new_user": created})
    if dry_run:
        return {**out, "result": "seria migrada"}
    assert user is not None and plan is not None
    pm = await save_method(db, user, "stripe", describe_pm(pm_raw), make_default=not await db.scalar(
        select(Subscription.id).where(Subscription.user_id == user.id, Subscription.provider == "portal").limit(1)))
    user.stripe_customer_id = user.stripe_customer_id or customer.get("id")
    sub = Subscription(user_id=user.id, plan_id=plan.id, product_id=plan.product_id, provider="portal",
                       provider_subscription_id=st["id"], provider_customer_id=customer.get("id"),
                       status=SubStatus.active, price_cents=amount, current_period_start=period_start,
                       current_period_end=period_end, period_amount_cents=amount,
                       started_at=sc.ts(st.get("start_date")) or utcnow(),
                       meta={"migrated_from": "stripe"})
    db.add(sub)
    user.billing_anchor_day = day
    if not user.next_billing_at or user.next_billing_at > period_end:
        user.next_billing_at = period_end
    await db.flush()
    pay_ref = f"stripe-legacy-{st['id']}"
    if not await db.scalar(select(Payment.id).where(Payment.provider == "stripe",
                                                    Payment.provider_payment_id == pay_ref)):
        db.add(Payment(user_id=user.id, subscription_id=sub.id, provider="stripe", provider_payment_id=pay_ref,
                       payment_method_id=pm.id, amount_cents=amount, status="paid", charge_date=period_start,
                       description="Pagamento Stripe (sistema antigo)"))
    # Cancelar no Stripe só depois de tudo gravado na sessão; se falhar, quem chama faz rollback e o Stripe continua
    # a cobrar como antes (nada se perde — corre de novo).
    await sc.cancel_now(st["id"])
    audit(db, "legacy.stripe_migrated", target_type="subscription", target_id=sub.id, stripe_subscription=st["id"],
          payment_method=pm.label, paid_until=period_end.isoformat(), created_user=created)
    await request_reconcile(db, user.id)
    return {**out, "result": "migrada", "subscription_id": sub.id}


async def migrate_all(db: AsyncSession, *, dry_run: bool = False, create_users: bool = True) -> list[dict]:
    if not get_settings().stripe_enabled:
        return [{"result": "Stripe não configurado"}]
    results: list[dict] = []
    after = None
    while True:
        page = await sc.list_subscriptions(status="all", starting_after=after)
        data = page.get("data") or []
        for st in data:
            if st.get("status") not in MIGRATABLE and not await db.scalar(
                    select(Subscription.id).where(Subscription.provider_subscription_id == st["id"])):
                continue
            try:
                res = await migrate_subscription(db, st, dry_run=dry_run, create_users=create_users)
                if dry_run:
                    await db.rollback()
                else:
                    await db.commit()  # uma a uma: o que já foi cancelado no Stripe fica gravado
                results.append(res)
            except Exception as exc:  # noqa: BLE001 — uma falha não pára as outras
                await db.rollback()
                log.warning("Migração Stripe %s falhou: %s", st.get("id"), exc)
                results.append({"stripe_subscription": st.get("id"), "result": f"erro: {exc}"})
        if not page.get("has_more") or not data:
            break
        after = data[-1]["id"]
    return results
