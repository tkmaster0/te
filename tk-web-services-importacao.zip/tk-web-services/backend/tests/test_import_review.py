"""Importação com revisão (Admin → Migração): GoCardless primeiro, users.db a completar, tudo editável antes de importar.
Também: créditos na carteira dados pelo admin a vários clientes de uma vez."""
from __future__ import annotations

import sqlite3
import uuid

from conftest import _TMP, create_user, drain, fetch, fetch_one, plan_by_code

from app.models import ImportRow, PaymentMethod, ServiceAccount, Subscription, User, WalletTransaction
from app.security import decrypt

R = "/api/admin/migration/review"


def _users_db(rows: list[tuple]) -> bytes:
    path = _TMP / f"old-{uuid.uuid4().hex}.db"
    con = sqlite3.connect(path)
    con.execute("CREATE TABLE user (id INTEGER PRIMARY KEY, email TEXT, username TEXT, password TEXT, "
                "subscription_status TEXT, subscription_end_date TEXT, jellyfin_user_id TEXT, iptvusername TEXT, "
                "iptvpwd TEXT, iptvhost TEXT, gocardless_customer_id TEXT, gocardless_mandate_id TEXT, "
                "invited_by TEXT)")
    con.executemany("INSERT INTO user VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", rows)
    con.commit()
    con.close()
    return path.read_bytes()


def _gc_world(gc):
    """Ana: tudo certo, mas com outro email no site antigo. Bruno: cancelou a subscrição à mão na GoCardless e
    autorizou um mandato novo. Carla: só existe na GoCardless, com um preço que não corresponde a nenhum plano."""
    ana = gc.add_customer("ana@example.com")
    ana_md = gc.add_mandate(ana["id"])
    ana_sub = gc.add_subscription(ana_md["id"], amount=500, name="TKFLIX", next_charge="2030-01-20")
    gc.add_payment(ana_sub["id"], "paid_out", "2029-12-20")

    bruno = gc.add_customer("bruno@example.com")
    old_md = gc.add_mandate(bruno["id"], status="cancelled", bank="BPI", ending="22")
    new_md = gc.add_mandate(bruno["id"], status="active", bank="Millennium", ending="33")
    gc.add_subscription(old_md["id"], amount=500, name="TKFLIX", status="cancelled")

    carla = gc.add_customer("carla@example.com")
    carla_md = gc.add_mandate(carla["id"])
    carla_sub = gc.add_subscription(carla_md["id"], amount=777, name="Plano antigo", next_charge="2030-01-05")
    gc.add_payment(carla_sub["id"], "failed", "2029-12-05")
    return {"ana": (ana, ana_md, ana_sub), "bruno": (bruno, old_md, new_md), "carla": (carla, carla_md, carla_sub)}


LEGACY_ROWS = [
    # id, email, username, password, status, end, jellyfin, iptv user, iptv pwd, iptv host, gc cust, gc mandate, convidado
    (1, "ana.antiga@example.com", "Ana", "$2b$12$hashantigo", "Ativa", None, "abc-123", "ana_tv", "velha123",
     "http://tv.antigo", None, None, None),
    (2, "bruno@example.com", "bruno", "$2b$12$outrohash", "Ativa", None, None, None, None, None, None, None, "Ana"),
    (3, "dani@example.com", "dani", "$2b$12$dani", "Desativa", None, None, None, None, None, None, None, None),
]


async def _scan(admin_client, svc, *, legacy=True) -> dict:
    world = _gc_world(svc.gc)
    if legacy:
        rows = [list(r) for r in LEGACY_ROWS]
        rows[0][10] = world["ana"][0]["id"]  # o site antigo guardava o cliente GoCardless da Ana
        r = await admin_client.post(f"{R}/legacy", files={"file": ("users.db", _users_db([tuple(x) for x in rows]))})
        assert r.status_code == 200, r.text
        assert r.json()["count"] == 3
    r = await admin_client.post(f"{R}/scan")
    assert r.status_code == 200, r.text
    assert r.json()["state"]["status"] == "running"
    await drain()
    data = (await admin_client.get(R)).json()
    assert data["state"]["status"] == "done", data["state"]
    data["world"] = world
    data["by_email"] = {row["email"]: row for row in data["rows"]}
    return data


def _codes(row) -> set[str]:
    return {f["code"] for f in row["flags"]}


async def test_scan_reads_gocardless_first_and_merges_users_db(admin_client, svc):
    data = await _scan(admin_client, svc)
    rows = data["by_email"]
    assert set(rows) == {"ana@example.com", "bruno@example.com", "carla@example.com", "dani@example.com"}

    ana = rows["ana@example.com"]  # o email da GoCardless ganha; o diferente fica como aviso
    assert "email_mismatch" in _codes(ana)
    assert ana["source"]["legacy"]["username"] == "Ana" and ana["source"]["customer"]["email"] == "ana@example.com"
    assert ana["proposal"]["include"] is True and ana["proposal"]["account"]["action"] == "create"
    assert ana["proposal"]["account"]["username"] == "ana"
    sub = ana["proposal"]["subscriptions"][0]
    assert sub["include"] and sub["mode"] == "keep" and sub["price_cents"] == 500
    assert sub["plan_id"] == (await plan_by_code("tkflix-mensal")).id and sub["next_charge"] == "2030-01-20"
    assert ana["source"]["subscriptions"][0]["payments"][0]["status"] == "paid_out"
    assert ana["proposal"]["link_jellyfin"] and ana["proposal"]["link_iptv"]

    bruno = rows["bruno@example.com"]  # cancelado à mão na GoCardless, mas "Ativa" no site antigo
    assert "cancelled_in_gc" in _codes(bruno)
    assert bruno["proposal"]["subscriptions"][0]["include"] is False
    _, old_md, new_md = data["world"]["bruno"]
    assert bruno["proposal"]["mandate_id"] == new_md["id"]  # o mandato novo, não o cancelado
    assert [m["status"] for m in bruno["source"]["mandates"]] == ["active", "cancelled"]
    assert bruno["source"]["mandates"][0]["bank"] == "Millennium"

    carla = rows["carla@example.com"]  # só na GoCardless e sem plano correspondente
    assert {"no_legacy", "no_plan", "last_payment_failed"} <= _codes(carla)
    assert carla["proposal"]["include"] is False

    dani = rows["dani@example.com"]
    assert "no_gocardless" in _codes(dani)
    assert data["state"]["counts"]["customers"] == 3 and data["state"]["legacy"]["count"] == 3


async def test_old_site_secrets_never_leave_the_portal(admin_client, svc):
    data = await _scan(admin_client, svc)
    leg = data["by_email"]["ana@example.com"]["source"]["legacy"]
    assert leg["has_password"] is True and leg["has_iptv_password"] is True
    raw = (await admin_client.get(R)).text
    assert "hashantigo" not in raw and "velha123" not in raw and "password_enc" not in raw
    stored = await fetch(ImportRow)
    assert all("hashantigo" not in str(r.source) and "velha123" not in str(r.source) for r in stored)


async def test_edit_validates_and_dry_run_writes_nothing(admin_client, svc):
    data = await _scan(admin_client, svc)
    carla = data["by_email"]["carla@example.com"]
    _, carla_md, carla_sub = data["world"]["carla"]
    url = f"{R}/rows/{carla['id']}"

    bad = await admin_client.patch(url, json={"account": {"email": "não-é-email"}})
    assert bad.status_code == 400
    bad = await admin_client.patch(url, json={"mandate_id": data["world"]["ana"][1]["id"]})
    assert bad.status_code == 400 and "não é deste cliente" in bad.json()["detail"]
    bad = await admin_client.patch(url, json={"subscriptions": [{"gc_id": carla_sub["id"], "mode": "talvez"}]})
    assert bad.status_code == 400

    plan = await plan_by_code("tkflix-tv-mensal")
    r = await admin_client.patch(url, json={
        "include": True,
        "account": {"username": "carla.tv", "display_name": "Carla"},
        "subscriptions": [{"gc_id": carla_sub["id"], "include": True, "plan_id": plan.id, "price_cents": 700,
                           "next_charge": "2030-02-01"}],
        "note": "preço acordado por telefone",
    })
    assert r.status_code == 200, r.text
    row = r.json()
    assert row["edited"] and row["proposal"]["account"]["username"] == "carla.tv"
    assert row["proposal"]["subscriptions"][0] == {"gc_id": carla_sub["id"], "include": True, "plan_id": plan.id,
                                                   "price_cents": 700, "mode": "keep", "next_charge": "2030-02-01"}

    sim = await admin_client.post(f"{R}/apply", json={"row_ids": [carla["id"]], "dry_run": True})
    assert sim.status_code == 200, sim.text
    res = sim.json()["results"][0]
    assert res["status"] == "simulated" and "criar conta carla.tv" in res["result"] and "7,00 €" in res["result"]
    assert await fetch(User, email="carla@example.com") == [] and await fetch(Subscription) == []
    assert (await fetch_one(ImportRow, id=carla["id"])).status == "pending"

    r = await admin_client.post(f"{url}/reset")
    assert r.json()["edited"] is False and r.json()["proposal"]["include"] is False


async def test_apply_keep_convert_and_chosen_mandate(admin_client, svc):
    data = await _scan(admin_client, svc)
    rows = data["by_email"]
    _, _, ana_sub = data["world"]["ana"]
    _, carla_md, carla_sub = data["world"]["carla"]
    _, _, bruno_new_md = data["world"]["bruno"]
    plan = await plan_by_code("tkflix-mensal")
    r = await admin_client.patch(f"{R}/rows/{rows['carla@example.com']['id']}", json={
        "include": True, "subscriptions": [{"gc_id": carla_sub["id"], "include": True, "plan_id": plan.id,
                                            "price_cents": 450, "mode": "convert", "next_charge": "2030-01-05"}]})
    assert r.status_code == 200, r.text

    ids = [rows[e]["id"] for e in ("ana@example.com", "bruno@example.com", "carla@example.com")]
    r = await admin_client.post(f"{R}/apply", json={"row_ids": ids, "dry_run": False})
    assert r.status_code == 200, r.text
    assert [x["status"] for x in r.json()["results"]] == ["imported"] * 3, r.json()

    # Ana: conta criada com o email da GoCardless, password antiga, Jellyfin/IPTV e subscrição mantida na GoCardless
    ana = await fetch_one(User, email="ana@example.com")
    assert ana.username == "ana" and ana.password_hash == "$2b$12$hashantigo" and ana.legacy_id == 1
    sub = await fetch_one(Subscription, user_id=ana.id)
    assert sub.provider == "gocardless" and sub.provider_subscription_id == ana_sub["id"] and ana_sub["status"] == "active"
    tv = await fetch_one(ServiceAccount, user_id=ana.id, service="iptv")
    assert decrypt(tv.secret_enc) == "velha123"
    assert await fetch(ServiceAccount, user_id=ana.id, service="jellyfin")

    # Bruno: só a conta + o mandato novo como método de pagamento; convidado pela Ana
    bruno = await fetch_one(User, email="bruno@example.com")
    assert await fetch(Subscription, user_id=bruno.id) == []
    assert bruno.gocardless_mandate_id == bruno_new_md["id"] and bruno.referred_by_id == ana.id
    pm = await fetch_one(PaymentMethod, user_id=bruno.id)
    assert pm.provider_ref == bruno_new_md["id"] and pm.is_default

    # Carla: passou já para o portal com o preço editado; a subscrição antiga foi cancelada na GoCardless
    carla = await fetch_one(User, email="carla@example.com")
    csub = await fetch_one(Subscription, user_id=carla.id)
    assert csub.provider == "portal" and csub.price_cents == 450 and csub.plan_id == plan.id
    assert carla_sub["status"] == "cancelled"

    # Importar outra vez não duplica nada
    again = await admin_client.post(f"{R}/apply", json={"row_ids": ids, "dry_run": False})
    assert [x["status"] for x in again.json()["results"]] == ["imported"] * 3
    assert len(await fetch(Subscription)) == 2
    edit = await admin_client.patch(f"{R}/rows/{ids[0]}", json={"include": False})
    assert edit.status_code == 400


async def test_changed_in_gocardless_since_scan_is_not_imported(admin_client, svc):
    data = await _scan(admin_client, svc)
    ana_row = data["by_email"]["ana@example.com"]
    _, _, ana_sub = data["world"]["ana"]
    ana_sub["status"] = "cancelled"  # cancelada à mão depois da leitura
    r = await admin_client.post(f"{R}/apply", json={"row_ids": [ana_row["id"]], "dry_run": False})
    res = r.json()["results"][0]
    assert res["status"] == "error" and "mudou desde a leitura" in res["result"]
    assert await fetch(User, email="ana@example.com") == []  # nada a meio: a conta também não ficou
    row = await fetch_one(ImportRow, id=ana_row["id"])
    assert row.status == "error"


async def test_rescan_keeps_unimported_edits_and_existing_accounts_are_linked(admin_client, svc):
    existing = await create_user("bruno_novo", email="bruno@example.com")
    data = await _scan(admin_client, svc)
    bruno = data["by_email"]["bruno@example.com"]
    assert bruno["proposal"]["account"] == {"action": "link", "user_id": existing.id, "email": "bruno@example.com",
                                            "username": "bruno_novo", "display_name": ""}
    ana = data["by_email"]["ana@example.com"]
    await admin_client.patch(f"{R}/rows/{ana['id']}", json={"note": "confirmado", "link_iptv": False})

    await admin_client.post(f"{R}/scan")
    await drain()
    again = {r["email"]: r for r in (await admin_client.get(R)).json()["rows"]}
    assert again["ana@example.com"]["proposal"]["note"] == "confirmado"
    assert again["ana@example.com"]["proposal"]["link_iptv"] is False and again["ana@example.com"]["edited"]
    assert len(await fetch(ImportRow)) == 4  # o lote antigo foi substituído


async def test_scan_without_users_db_and_selection(admin_client, svc):
    data = await _scan(admin_client, svc, legacy=False)
    assert len(data["rows"]) == 3 and data["state"]["legacy"]["count"] == 0
    assert all("no_legacy" not in _codes(r) for r in data["rows"])  # sem users.db não há o que avisar
    ids = [r["id"] for r in data["rows"]]
    r = await admin_client.post(f"{R}/select", json={"row_ids": ids, "include": False})
    assert r.json()["count"] == 3
    assert all(not r["proposal"]["include"] for r in (await admin_client.get(R)).json()["rows"])
    r = await admin_client.delete(f"{R}/legacy")
    assert r.status_code == 200


async def test_review_needs_admin(client, svc):
    u = await create_user("curioso")
    await client.login_as(u)
    assert (await client.get(R)).status_code == 403
    assert (await client.post(f"{R}/apply", json={"row_ids": [1], "dry_run": False})).status_code == 403


# --------------------------------------------------------------------------- créditos dados pelo admin
async def test_admin_bulk_credit(admin_client, settings, svc):
    a = await create_user("cliente_a")
    b = await create_user("cliente_b")
    settings.set("wallet_enabled", False)
    r = await admin_client.post("/api/admin/wallet/credit", json={"user_ids": [a.id], "amount_cents": 500,
                                                                   "reason": "Compensação"})
    assert r.status_code == 400

    settings.set("wallet_enabled", True)
    r = await admin_client.post("/api/admin/wallet/credit", json={"user_ids": [a.id, b.id, a.id],
                                                                   "amount_cents": 250, "reason": "Falha de sábado"})
    assert r.status_code == 200, r.text
    assert "2 conta(s)" in r.json()["message"]
    txs = await fetch(WalletTransaction, user_id=a.id)
    assert [(t.amount_cents, t.description) for t in txs] == [(250, "Falha de sábado")]

    bad = await admin_client.post("/api/admin/wallet/credit", json={"user_ids": [a.id], "amount_cents": -5,
                                                                     "reason": "x"})
    assert bad.status_code == 422
    none = await admin_client.post("/api/admin/wallet/credit", json={"amount_cents": 100, "reason": "x"})
    assert none.status_code == 400

    r = await admin_client.post("/api/admin/wallet/credit", json={"audience": "all", "amount_cents": 100,
                                                                   "reason": "Natal"})
    assert r.status_code == 200
    assert len(await fetch(WalletTransaction, user_id=b.id)) == 2
