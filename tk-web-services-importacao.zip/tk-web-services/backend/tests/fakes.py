"""Fakes com estado para os serviços externos (Jellyfin, Seerr, Dispatcharr, GoCardless, Stripe).

Cada fake regista rotas `respx` e guarda um registo dos pedidos recebidos, para os testes poderem
verificar tanto o estado final como as chamadas feitas (idempotência, headers, corpos).
"""
from __future__ import annotations

import base64
import itertools
import json
import re
import uuid
from datetime import date, timedelta
from urllib.parse import parse_qsl

import httpx
import respx

JELLYFIN_HOST = "jellyfin.test"
JELLYFIN_API_KEY = "jf-api-key-123"
SEERR_HOST = "seerr.test"
SEERR_API_KEY = "seerr-key-123"
DISPATCHARR_HOST = "dispatcharr.test"
DISPATCHARR_API_KEY = "dc-key-123"
GC_HOST = "api-sandbox.gocardless.com"
STRIPE_HOST = "api.stripe.com"


def _json(request: httpx.Request) -> dict:
    return json.loads(request.content or b"{}")


def _form(request: httpx.Request) -> dict:
    return dict(parse_qsl(request.content.decode(), keep_blank_values=True))


class Recorder:
    def __init__(self):
        self.calls: list[tuple[str, str, httpx.Request]] = []

    def record(self, request: httpx.Request):
        self.calls.append((request.method, request.url.path, request))

    def writes(self) -> list[tuple[str, str]]:
        return [(m, p) for m, p, _ in self.calls if m != "GET"]

    def find(self, method: str, path_re: str) -> list[httpx.Request]:
        return [r for m, p, r in self.calls if m == method and re.search(path_re, p)]

    def reset(self):
        self.calls.clear()


# --------------------------------------------------------------------------- Jellyfin
DEFAULT_POLICY = {
    "IsAdministrator": False, "IsHidden": False, "IsDisabled": False, "EnableAllFolders": True,
    "EnabledFolders": [], "EnableLiveTvAccess": True, "MaxActiveSessions": 0, "EnableContentDownloading": True,
    "RemoteClientBitrateLimit": 0,
    "AuthenticationProviderId": "Jellyfin.Server.Implementations.Users.DefaultAuthenticationProvider",
    "PasswordResetProviderId": "Jellyfin.Server.Implementations.Users.DefaultPasswordResetProvider",
}
TOKEN_RE = re.compile(r'^MediaBrowser .*Token="(?P<t>[^"]*)"')


class FakeJellyfin(Recorder):
    def __init__(self, mock: respx.MockRouter):
        super().__init__()
        self.users: dict[str, dict] = {}
        self.passwords: dict[str, str] = {}
        self.user_tokens: dict[str, str] = {}  # token -> user id
        self.devices: dict[str, list[dict]] = {}
        self.quick_connect_codes: set[str] = set()
        self.quick_connect_authorized: list[tuple[str, str]] = []  # (código, userId)
        self.down = False
        self.bad_auth_headers: list[str] = []
        # Conteúdos (assistente de suporte). Cada item tem "_lib" (biblioteca): a visibilidade por utilizador
        # segue a Policy (EnableAllFolders / EnabledFolders), como no Jellyfin.
        self.items: dict[str, dict] = {}
        self.remote_subs: dict[tuple[str, str], list[dict]] = {}  # (item, idioma iso3) -> resultados
        self.downloaded_subs: list[tuple[str, str]] = []  # (item, id da legenda)
        self.refreshed: list[str] = []
        self.collections: dict[str, list[str]] = {}
        self.images: dict[tuple[str, str], bytes] = {}  # (item, tipo) -> imagem
        self.sessions: list[dict] = []
        self.played: dict[str, list[str]] = {}  # userId -> itens vistos (mais recente primeiro)
        self.resume: dict[str, list[str]] = {}
        h = JELLYFIN_HOST
        mock.route(host=h).side_effect = self._dispatch

    # -- conteúdos
    def add_item(self, name: str, kind: str = "Movie", *, lib: str = "lib1", year: int | None = 2020,
                 provider_ids: dict | None = None, path: str | None = None, streams: list[dict] | None = None,
                 series: dict | None = None, season: int | None = None, episode: int | None = None,
                 container: str = "mkv") -> dict:
        iid = uuid.uuid4().hex
        it = {"Id": iid, "Name": name, "Type": kind, "ProductionYear": year, "ProviderIds": provider_ids or {},
              "Path": path, "MediaStreams": streams or [], "_lib": lib}
        if kind in ("Movie", "Episode"):
            it["MediaSources"] = [{"Id": iid, "Path": path, "Container": container}]
        if series is not None:
            it.update({"SeriesId": series["Id"], "SeriesName": series["Name"], "ParentIndexNumber": season,
                       "IndexNumber": episode, "_lib": series["_lib"]})
        self.items[iid] = it
        return it

    def visible(self, uid: str | None, it: dict) -> bool:
        user = self.users.get(uid or "")
        if user is None:
            return False
        pol = user["Policy"]
        return bool(pol.get("EnableAllFolders")) or it["_lib"] in (pol.get("EnabledFolders") or [])

    @staticmethod
    def _public(it: dict) -> dict:
        return {k: v for k, v in it.items() if not k.startswith("_")}

    def _items_query(self, request: httpx.Request) -> httpx.Response:
        p = request.url.params
        uid = p.get("userId")
        rows = [it for it in self.items.values() if self.visible(uid, it)]
        if p.get("ids"):
            wanted = set(p["ids"].split(","))
            rows = [it for it in rows if it["Id"] in wanted]
        if p.get("IncludeItemTypes"):
            types = set(p["IncludeItemTypes"].split(","))
            rows = [it for it in rows if it["Type"] in types]
        if p.get("Tags"):
            tags = set(p["Tags"].split("|"))
            rows = [it for it in rows if tags & set(it.get("Tags") or [])]
        if p.get("searchTerm"):
            term = p["searchTerm"].lower()
            rows = [it for it in rows if term in it["Name"].lower() or term in str(it.get("SeriesName", "")).lower()]
        if p.get("IsPlayed") == "true":
            order = self.played.get(uid or "", [])
            rows = [self.items[i] for i in order if i in self.items and self.visible(uid, self.items[i])]
        limit = int(p.get("Limit") or 100)
        return httpx.Response(200, json={"Items": [self._public(it) for it in rows[:limit]],
                                         "TotalRecordCount": len(rows)})

    # -- helpers
    def add_user(self, name: str, *, admin: bool = False, password: str = "old-password", **policy) -> dict:
        uid = uuid.uuid4().hex
        pol = {**DEFAULT_POLICY, "IsAdministrator": admin, **policy}
        self.users[uid] = {"Id": uid, "Name": name, "HasPassword": True, "Policy": pol}
        self.passwords[uid] = password
        return self.users[uid]

    def by_name(self, name: str) -> dict | None:
        return next((u for u in self.users.values() if u["Name"].lower() == name.lower()), None)

    def policy_writes(self) -> list[httpx.Request]:
        return self.find("POST", r"^/Users/[^/]+/Policy$")

    def _dispatch(self, request: httpx.Request) -> httpx.Response:
        self.record(request)
        if self.down:
            return httpx.Response(503, text="down")
        if "x-emby-token" in request.headers or "api_key" in request.url.params:
            self.bad_auth_headers.append(str(request.url))
            return httpx.Response(401, text="X-Emby-Token não é suportado")
        m = TOKEN_RE.match(request.headers.get("authorization", ""))
        token = m.group("t") if m else None
        path, method = request.url.path, request.method
        if path == "/Users/Me" and method == "GET":
            uid = self.user_tokens.get(token or "")
            if not uid or uid not in self.users:
                return httpx.Response(401)
            return httpx.Response(200, json=self.users[uid])
        if token != JELLYFIN_API_KEY:
            self.bad_auth_headers.append(str(request.url))
            return httpx.Response(401)
        if path == "/Users" and method == "GET":
            return httpx.Response(200, json=list(self.users.values()))
        if path == "/Users/New" and method == "POST":
            body = _json(request)
            if self.by_name(body["Name"]):
                return httpx.Response(400, text="User exists")
            u = self.add_user(body["Name"], password=body.get("Password") or "")
            return httpx.Response(200, json=u)
        if path == "/Users/Password" and method == "POST":
            uid = request.url.params.get("userId")
            if uid not in self.users:
                return httpx.Response(404)
            self.passwords[uid] = _json(request)["NewPw"]
            return httpx.Response(204)
        if m2 := re.match(r"^/Users/([^/]+)/Policy$", path):
            uid = m2.group(1)
            if uid not in self.users:
                return httpx.Response(404)
            self.users[uid]["Policy"] = _json(request)
            return httpx.Response(204)
        if m2 := re.match(r"^/Users/([^/]+)$", path):
            uid = m2.group(1)
            if uid not in self.users:
                return httpx.Response(404)
            if method == "GET":
                return httpx.Response(200, json=self.users[uid])
            if method == "POST":
                self.users[uid]["Name"] = _json(request)["Name"]
                return httpx.Response(204)
        if path == "/Devices" and method == "GET":
            return httpx.Response(200, json={"Items": self.devices.get(request.url.params.get("userId"), [])})
        if path == "/Devices" and method == "DELETE":
            did = request.url.params.get("id")
            for items in self.devices.values():
                items[:] = [d for d in items if d["Id"] != did]
            return httpx.Response(204)
        if path == "/QuickConnect/Authorize" and method == "POST":
            code = request.url.params.get("code")
            if code not in self.quick_connect_codes:
                return httpx.Response(404, text="Unknown code")
            self.quick_connect_codes.discard(code)
            self.quick_connect_authorized.append((code, request.url.params.get("userId")))
            return httpx.Response(200, json=True)
        if path == "/Sessions":
            return httpx.Response(200, json=self.sessions)
        if path == "/Items" and method == "GET":
            return self._items_query(request)
        if path == "/UserItems/Resume" and method == "GET":
            uid = request.url.params.get("userId") or ""
            rows = [self._public(self.items[i]) for i in self.resume.get(uid, []) if i in self.items]
            return httpx.Response(200, json={"Items": rows})
        if (m2 := re.match(r"^/Shows/([^/]+)/Episodes$", path)) and method == "GET":
            uid = request.url.params.get("userId")
            series = self.items.get(m2.group(1))
            if series is None or not self.visible(uid, series):
                return httpx.Response(404)
            season = request.url.params.get("season")
            eps = [it for it in self.items.values() if it.get("SeriesId") == series["Id"]
                   and (season is None or str(it.get("ParentIndexNumber")) == season)]
            eps.sort(key=lambda e: (e.get("ParentIndexNumber") or 0, e.get("IndexNumber") or 0))
            return httpx.Response(200, json={"Items": [self._public(e) for e in eps]})
        if m2 := re.match(r"^/Items/([^/]+)/RemoteSearch/Subtitles/([^/]+)$", path):
            iid, arg = m2.group(1), m2.group(2)
            if iid not in self.items:
                return httpx.Response(404)
            if method == "GET":
                return httpx.Response(200, json=self.remote_subs.get((iid, arg), []))
            if method == "POST":
                known = {s["Id"] for subs in self.remote_subs.values() for s in subs}
                if arg not in known:
                    return httpx.Response(404, text="unknown subtitle")
                self.downloaded_subs.append((iid, arg))
                return httpx.Response(204)
        if (m2 := re.match(r"^/Items/([^/]+)/Refresh$", path)) and method == "POST":
            if m2.group(1) not in self.items:
                return httpx.Response(404)
            self.refreshed.append(m2.group(1))
            return httpx.Response(204)
        if path == "/Collections" and method == "POST":
            iid = uuid.uuid4().hex
            self.items[iid] = {"Id": iid, "Name": request.url.params.get("name"), "Type": "BoxSet",
                               "Overview": None, "Tags": [], "_lib": "collections"}
            return httpx.Response(200, json={"Id": iid})
        if (m2 := re.match(r"^/Items/([^/]+)$", path)) and method == "POST":
            it = self.items.get(m2.group(1))
            if it is None:
                return httpx.Response(404)
            body = _json(request)
            if body.get("Id") != it["Id"] or body.get("Genres") is None:
                return httpx.Response(400, text="BaseItemDto incompleto")
            it.update({k: body[k] for k in ("Name", "Overview", "ForcedSortName", "Tags", "LockData") if k in body})
            return httpx.Response(204)
        if m2 := re.match(r"^/Items/([^/]+)/Images/([^/]+)(?:/(\d+))?$", path):
            iid, kind = m2.group(1), m2.group(2)
            if iid not in self.items:
                return httpx.Response(404)
            if method == "POST":
                self.images[(iid, kind)] = base64.b64decode(request.content)
                return httpx.Response(204)
            if method == "DELETE":
                return httpx.Response(204) if self.images.pop((iid, kind), None) is not None else httpx.Response(404)
        if (m2 := re.match(r"^/Collections/([^/]+)/Items$", path)) and method == "POST":
            ids = [i for i in (request.url.params.get("ids") or "").split(",") if i]
            if any(i not in self.items for i in ids):
                return httpx.Response(404)
            self.collections.setdefault(m2.group(1), []).extend(ids)
            return httpx.Response(204)
        if path == "/System/Info/Public":
            return httpx.Response(200, json={"Version": "12.0.0", "ServerName": "TK"})
        if path == "/Library/VirtualFolders":
            return httpx.Response(200, json=[{"ItemId": "lib1", "Name": "Filmes", "CollectionType": "movies"}])
        return httpx.Response(404, text=f"fake jellyfin: {method} {path}")


# --------------------------------------------------------------------------- Seerr
class FakeSeerr(Recorder):
    def __init__(self, mock: respx.MockRouter, jellyfin: FakeJellyfin):
        super().__init__()
        self.jellyfin = jellyfin
        self.users: dict[int, dict] = {}
        self.settings: dict[int, dict] = {}
        self.permissions: dict[int, int] = {}
        self.default_permissions = 32
        self._ids = itertools.count(1)
        self.import_returns_empty = False
        # Issues / pedidos / media (assistente de suporte). O dono da API key é o utilizador 1 (admin).
        self.api_user = {"id": 1, "displayName": "admin", "jellyfinUserId": "admin-jf"}
        self.issues: dict[int, dict] = {}
        self.media: dict[tuple[str, int], dict] = {}  # (movie|tv, tmdb) -> {"mediaInfo": {...}}
        self.requests: dict[int, list[dict]] = {}  # seerr user id -> pedidos
        self.ignore_requested_by = False  # simula versões do Seerr que ignoram o filtro
        self._issue_ids = itertools.count(100)
        self._comment_ids = itertools.count(1000)
        self.down = False
        mock.route(host=SEERR_HOST).side_effect = self._dispatch

    # -- helpers
    def add_media(self, media_type: str, tmdb: int, *, jellyfin_id: str | None = None) -> dict:
        media_id = next(self._issue_ids)
        info = {"id": media_id, "tmdbId": tmdb, "mediaType": media_type, "status": 5,
                "jellyfinMediaId": jellyfin_id}
        self.media[(media_type, tmdb)] = {"id": tmdb, "mediaInfo": info}
        return info

    def add_issue(self, created_by: dict, message: str, *, issue_type: int = 3, media: dict | None = None,
                  season: int = 0, episode: int = 0) -> dict:
        iid = next(self._issue_ids)
        self.issues[iid] = {"id": iid, "issueType": issue_type, "status": 1, "problemSeason": season,
                            "problemEpisode": episode, "media": media or {"mediaType": "movie", "tmdbId": 1},
                            "createdBy": created_by, "comments": []}
        self.add_comment(iid, created_by, message)
        return self.issues[iid]

    def add_comment(self, issue_id: int, user: dict, message: str) -> dict:
        c = {"id": next(self._comment_ids), "message": message, "user": {"id": user["id"]}}
        self.issues[issue_id]["comments"].append(c)
        return c

    def _dispatch(self, request: httpx.Request) -> httpx.Response:
        self.record(request)
        if self.down:
            return httpx.Response(503, text="down")
        if request.headers.get("x-api-key") != SEERR_API_KEY:
            return httpx.Response(401)
        path, method = request.url.path, request.method
        if path == "/api/v1/issue" and method == "GET":
            p = request.url.params
            rows = list(self.issues.values())
            if p.get("filter") == "open":
                rows = [i for i in rows if i["status"] == 1]
            elif p.get("filter") == "resolved":
                rows = [i for i in rows if i["status"] == 2]
            if p.get("requestedBy") and not self.ignore_requested_by:
                rows = [i for i in rows if str(i["createdBy"]["id"]) == p["requestedBy"]]
            return httpx.Response(200, json={"pageInfo": {"page": 1, "pages": 1}, "results": rows[:int(p.get("take", 20))]})
        if path == "/api/v1/issue" and method == "POST":
            body = _json(request)
            media = next((m["mediaInfo"] for m in self.media.values() if m["mediaInfo"]["id"] == body["mediaId"]), None)
            if media is None:
                return httpx.Response(404)
            iid = next(self._issue_ids)
            self.issues[iid] = {"id": iid, "issueType": body["issueType"], "status": 1, "media": media,
                                "problemSeason": body.get("problemSeason", 0),
                                "problemEpisode": body.get("problemEpisode", 0), "createdBy": self.api_user,
                                "comments": [{"id": next(self._comment_ids), "message": body["message"],
                                              "user": {"id": self.api_user["id"]}}]}
            return httpx.Response(201, json=self.issues[iid])
        if m := re.match(r"^/api/v1/issue/(\d+)(?:/(comment|resolved|open))?$", path):
            issue = self.issues.get(int(m.group(1)))
            if issue is None:
                return httpx.Response(404)
            action = m.group(2)
            if action is None and method == "GET":
                return httpx.Response(200, json=issue)
            if action == "comment" and method == "POST":
                c = self.add_comment(issue["id"], self.api_user, _json(request)["message"])
                return httpx.Response(200, json=c)
            if action in ("resolved", "open") and method == "POST":
                issue["status"] = 2 if action == "resolved" else 1
                return httpx.Response(200, json=issue)
        if (m := re.match(r"^/api/v1/(movie|tv)/(\d+)$", path)) and method == "GET":
            media = self.media.get((m.group(1), int(m.group(2))))
            return httpx.Response(200, json=media) if media else httpx.Response(404)
        if (m := re.match(r"^/api/v1/user/(\d+)/requests$", path)) and method == "GET":
            return httpx.Response(200, json={"pageInfo": {"page": 1, "pages": 1},
                                             "results": self.requests.get(int(m.group(1)), [])})
        if path == "/api/v1/user" and method == "GET":
            q = request.url.params.get("q")
            rows = [u for u in self.users.values() if not q or q.lower() in u["jellyfinUsername"].lower()]
            return httpx.Response(200, json={"pageInfo": {"page": 1, "pages": 1, "results": len(rows)},
                                             "results": rows})
        if path == "/api/v1/user/import-from-jellyfin" and method == "POST":
            if self.import_returns_empty:
                return httpx.Response(201, json=[])
            out = []
            for jid in _json(request)["jellyfinUserIds"]:
                ju = self.jellyfin.users.get(jid)
                if not ju:
                    continue
                sid = next(self._ids)
                self.users[sid] = {"id": sid, "jellyfinUserId": jid, "jellyfinUsername": ju["Name"], "email": ""}
                self.settings[sid] = {"username": ju["Name"], "email": "", "movieQuotaLimit": None,
                                      "movieQuotaDays": None, "tvQuotaLimit": None, "tvQuotaDays": None,
                                      "locale": "pt"}
                out.append(self.users[sid])
            return httpx.Response(201, json=out)
        if m := re.match(r"^/api/v1/user/(\d+)/settings/main$", path):
            sid = int(m.group(1))
            if sid not in self.settings:
                return httpx.Response(404)
            if method == "GET":
                return httpx.Response(200, json=self.settings[sid])
            self.settings[sid] = _json(request)
            return httpx.Response(200, json=self.settings[sid])
        if m := re.match(r"^/api/v1/user/(\d+)/settings/permissions$", path):
            sid = int(m.group(1))
            if method == "GET":
                return httpx.Response(200, json={"permissions": self.permissions.get(sid, self.default_permissions)})
            self.permissions[sid] = int(_json(request)["permissions"])
            return httpx.Response(200, json={"permissions": self.permissions[sid]})
        if path == "/api/v1/settings/main" and method == "GET":
            return httpx.Response(200, json={"defaultPermissions": self.default_permissions})
        if path == "/api/v1/status":
            return httpx.Response(200, json={"version": "2.0.0"})
        return httpx.Response(404)


# --------------------------------------------------------------------------- Dispatcharr
class FakeDispatcharr(Recorder):
    def __init__(self, mock: respx.MockRouter):
        super().__init__()
        self.users: dict[int, dict] = {}
        self._ids = itertools.count(100)
        mock.route(host=DISPATCHARR_HOST).side_effect = self._dispatch

    def by_name(self, name: str) -> dict | None:
        return next((u for u in self.users.values() if u["username"] == name), None)

    def _dispatch(self, request: httpx.Request) -> httpx.Response:
        self.record(request)
        if request.headers.get("x-api-key") != DISPATCHARR_API_KEY:
            return httpx.Response(401)
        path, method = request.url.path, request.method
        if path == "/api/accounts/users/" and method == "GET":
            return httpx.Response(200, json=list(self.users.values()))
        if path == "/api/accounts/users/" and method == "POST":
            body = _json(request)
            uid = next(self._ids)
            self.users[uid] = {**body, "id": uid}
            return httpx.Response(201, json=self.users[uid])
        if m := re.match(r"^/api/accounts/users/(\d+)/$", path):
            uid = int(m.group(1))
            if uid not in self.users:
                return httpx.Response(404)
            if method == "DELETE":
                del self.users[uid]
                return httpx.Response(204)
            body = _json(request)
            u = self.users[uid]
            if "custom_properties" in body:
                props = dict(u.get("custom_properties") or {})
                for k, v in body.pop("custom_properties").items():
                    if v is None:
                        props.pop(k, None)
                    else:
                        props[k] = v
                u["custom_properties"] = props
            u.update(body)
            return httpx.Response(200, json=u)
        return httpx.Response(404)


# --------------------------------------------------------------------------- GoCardless
def _gc_error(status: int, message: str, reason: str | None = None, **links) -> httpx.Response:
    err = {"message": message, "type": "invalid_state" if status == 422 else "invalid_api_usage",
           "code": status, "errors": [{"reason": reason, "message": message, **({"links": links} if links else {})}]}
    return httpx.Response(status, json={"error": err})


class FakeGoCardless(Recorder):
    """GoCardless com estado: billing requests (mandato e/ou pagamento), pagamentos únicos com Idempotency-Key,
    mandatos, contas bancárias, credores e subscrições antigas (para a migração)."""

    MANDATE_CHARGEABLE = {"active", "submitted", "pending_submission", "pending_customer_approval"}

    def __init__(self, mock: respx.MockRouter):
        super().__init__()
        self.billing_requests: dict[str, dict] = {}
        self.mandates: dict[str, dict] = {}
        self.customers: dict[str, dict] = {}
        self.bank_accounts: dict[str, dict] = {}
        self.subscriptions: dict[str, dict] = {}
        self.payments: dict[str, dict] = {}
        self.idempotency: dict[tuple[str, str], str] = {}
        self.idempotency_keys: list[tuple[str, str]] = []  # (caminho, chave) por ordem
        self.fail_paths: dict[str, int] = {}  # caminho → status HTTP a devolver (simula falhas)
        self.creditor_id = "CR000001"
        self.new_payment_status = "pending_submission"  # estado dos pagamentos criados por POST /payments
        self._n = itertools.count(1)
        mock.route(host=GC_HOST).side_effect = self._dispatch

    def _id(self, prefix: str) -> str:
        return f"{prefix}{next(self._n):06d}"

    # -- helpers para os testes
    def add_customer(self, email: str) -> dict:
        cid = self._id("CU")
        self.customers[cid] = {"id": cid, "email": email}
        return self.customers[cid]

    def add_mandate(self, customer_id: str, status: str = "active", bank: str = "CGD", ending: str = "11") -> dict:
        mid = self._id("MD")
        ba = self._id("BA")
        self.bank_accounts[ba] = {"id": ba, "bank_name": bank, "account_number_ending": ending,
                                  "links": {"customer": customer_id}}
        self.mandates[mid] = {"id": mid, "status": status, "scheme": "sepa_core",
                              "links": {"customer": customer_id, "customer_bank_account": ba}}
        return self.mandates[mid]

    def fulfil(self, br_id: str, email: str = "cliente@example.com", *, payment_status: str = "pending_submission",
               customer_id: str | None = None) -> dict:
        """O cliente conclui a página alojada: cria cliente + mandato (e o pagamento, se o pedido o tiver)."""
        br = self.billing_requests[br_id]
        cust_id = customer_id or (br.get("links") or {}).get("customer") or self.add_customer(email)["id"]
        if cust_id not in self.customers:
            self.customers[cust_id] = {"id": cust_id, "email": email}
        mandate = self.add_mandate(cust_id)
        br["status"] = "fulfilled"
        br["links"] = {**br.get("links", {}), "customer": cust_id, "mandate_request_mandate": mandate["id"]}
        if br.get("payment_request"):
            pr = br["payment_request"]
            pid = self._id("PM")
            self.payments[pid] = {"id": pid, "status": payment_status, "amount": pr["amount"],
                                  "currency": pr["currency"], "charge_date": date.today().isoformat(),
                                  "description": pr.get("description"), "metadata": pr.get("metadata") or {},
                                  "links": {"mandate": mandate["id"]}}
            br["links"]["payment_request_payment"] = pid
        return br

    def cancel_br(self, br_id: str) -> dict:
        self.billing_requests[br_id]["status"] = "cancelled"
        return self.billing_requests[br_id]

    def add_subscription(self, mandate_id: str, *, amount: int, interval_unit: str = "monthly", name: str = "",
                         status: str = "active", metadata: dict | None = None, next_charge: str | None = None,
                         day_of_month: int | None = None, start_date: str | None = None) -> dict:
        sid = self._id("SB")
        upcoming = [] if status == "paused" else [
            {"charge_date": next_charge or (date.today() + timedelta(days=20)).isoformat(), "amount": amount}]
        self.subscriptions[sid] = {
            "id": sid, "status": status, "amount": amount, "currency": "EUR", "interval_unit": interval_unit,
            "interval": 1, "name": name, "metadata": metadata or {}, "links": {"mandate": mandate_id},
            "upcoming_payments": upcoming, "day_of_month": day_of_month,
            "start_date": start_date or (date.today() - timedelta(days=200)).isoformat(),
        }
        return self.subscriptions[sid]

    def add_payment(self, sub_id: str | None, status: str, charge_date: str, amount: int | None = None,
                    mandate_id: str | None = None) -> dict:
        pid = self._id("PM")
        sub = self.subscriptions.get(sub_id or "") or {}
        links = {"mandate": mandate_id or (sub.get("links") or {}).get("mandate")}
        if sub_id:
            links["subscription"] = sub_id
        self.payments[pid] = {"id": pid, "status": status, "amount": amount or sub.get("amount") or 0,
                              "currency": "EUR", "charge_date": charge_date, "description": sub.get("name"),
                              "links": links}
        return self.payments[pid]

    def set_payment(self, pid: str, status: str) -> dict:
        self.payments[pid]["status"] = status
        return self.payments[pid]

    def charges(self) -> list[dict]:
        """Pagamentos únicos criados pelo portal (POST /payments)."""
        return [p for p in self.payments.values() if p.get("created_by_portal")]

    def keys_for(self, path: str) -> list[str]:
        return [k for p, k in self.idempotency_keys if p == path]

    # -- API
    def _dispatch(self, request: httpx.Request) -> httpx.Response:
        self.record(request)
        if request.headers.get("authorization") != "Bearer gc-token" or not request.headers.get("gocardless-version"):
            return httpx.Response(401, json={"error": {"message": "unauthorized"}})
        path, method = request.url.path, request.method
        key = request.headers.get("idempotency-key")
        if key:
            self.idempotency_keys.append((path, key))
        if path in self.fail_paths:
            return httpx.Response(self.fail_paths[path], json={"error": {"message": "falha simulada"}})
        params = request.url.params

        if path == "/billing_requests" and method == "POST":
            if key and ("br", key) in self.idempotency:
                return _gc_error(409, "conflict", "idempotent_creation_conflict",
                                 conflicting_resource_id=self.idempotency[("br", key)])
            body = _json(request)["billing_requests"]
            bid = self._id("BRQ")
            self.billing_requests[bid] = {"id": bid, "status": "pending", "metadata": body.get("metadata"),
                                          "mandate_request": body.get("mandate_request"),
                                          "payment_request": body.get("payment_request"),
                                          "links": dict(body.get("links") or {})}
            if key:
                self.idempotency[("br", key)] = bid
            return httpx.Response(201, json={"billing_requests": self.billing_requests[bid]})
        if path == "/billing_request_flows" and method == "POST":
            body = _json(request)["billing_request_flows"]
            fid = self._id("BRF")
            return httpx.Response(201, json={"billing_request_flows": {
                "id": fid, "authorisation_url": f"https://pay-sandbox.gocardless.com/billing/static/flow?id={fid}",
                "redirect_uri": body["redirect_uri"], "exit_uri": body["exit_uri"], "links": body["links"],
                "prefilled_customer": body.get("prefilled_customer")}})
        if m := re.match(r"^/billing_requests/([^/]+)$", path):
            br = self.billing_requests.get(m.group(1))
            return httpx.Response(200, json={"billing_requests": br}) if br else _gc_error(404, "not found")
        if m := re.match(r"^/mandates/([^/]+)$", path):
            md = self.mandates.get(m.group(1))
            return httpx.Response(200, json={"mandates": md}) if md else _gc_error(404, "not found")
        if path == "/mandates" and method == "GET":
            cust = params.get("customer")
            return httpx.Response(200, json={"mandates": [m for m in self.mandates.values()
                                                          if not cust or m["links"]["customer"] == cust]})
        if path == "/customers" and method == "GET":
            return httpx.Response(200, json={"customers": list(self.customers.values())})
        if m := re.match(r"^/customers/([^/]+)$", path):
            c = self.customers.get(m.group(1))
            return httpx.Response(200, json={"customers": c}) if c else _gc_error(404, "not found")
        if m := re.match(r"^/customer_bank_accounts/([^/]+)$", path):
            ba = self.bank_accounts.get(m.group(1))
            return httpx.Response(200, json={"customer_bank_accounts": ba}) if ba else _gc_error(404, "not found")
        if path == "/creditors" and method == "GET":
            return httpx.Response(200, json={"creditors": [{"id": self.creditor_id}] if self.creditor_id else []})

        if path == "/payments" and method == "POST":
            if key and ("pay", key) in self.idempotency:
                return _gc_error(409, "A resource has already been created with this idempotency key",
                                 "idempotent_creation_conflict",
                                 conflicting_resource_id=self.idempotency[("pay", key)])
            body = _json(request)["payments"]
            md = self.mandates.get(body["links"]["mandate"])
            if md is None:
                return _gc_error(404, "Mandate not found", "resource_not_found")
            if md["status"] not in self.MANDATE_CHARGEABLE:
                return _gc_error(422, "The mandate for this payment is not active", "mandate_is_inactive")
            pid = self._id("PM")
            self.payments[pid] = {"id": pid, "status": self.new_payment_status, "amount": body["amount"],
                                  "currency": body["currency"], "description": body.get("description"),
                                  "metadata": body.get("metadata") or {},
                                  "charge_date": body.get("charge_date") or date.today().isoformat(),
                                  "links": {"mandate": md["id"]}, "created_by_portal": True,
                                  "idempotency_key": key, "retry_if_possible": body.get("retry_if_possible")}
            if key:
                self.idempotency[("pay", key)] = pid
            return httpx.Response(201, json={"payments": self.payments[pid]})
        if path == "/payments" and method == "GET":
            sub, mandate = params.get("subscription"), params.get("mandate")
            rows = [p for p in self.payments.values()
                    if (not sub or p["links"].get("subscription") == sub)
                    and (not mandate or p["links"].get("mandate") == mandate)]
            return httpx.Response(200, json={"payments": rows})
        if m := re.match(r"^/payments/([^/]+)$", path):
            p = self.payments.get(m.group(1))
            return httpx.Response(200, json={"payments": p}) if p else _gc_error(404, "not found")

        if path == "/subscriptions" and method == "GET":
            mandate = params.get("mandate")
            customer = params.get("customer")
            rows = [s for s in self.subscriptions.values()
                    if (not mandate or s["links"]["mandate"] == mandate)
                    and (not customer or self.mandates.get(s["links"]["mandate"], {}).get("links", {})
                         .get("customer") == customer)]
            return httpx.Response(200, json={"subscriptions": rows})
        if m := re.match(r"^/subscriptions/([^/]+)/actions/(cancel|pause|resume)$", path):
            sub = self.subscriptions.get(m.group(1))
            if not sub:
                return _gc_error(404, "not found")
            action = m.group(2)
            if action == "cancel":
                if sub["status"] == "cancelled":
                    return _gc_error(422, "Subscription already cancelled", "cancellation_failed")
                sub["status"] = "cancelled"
                sub["upcoming_payments"] = []
                for p in self.payments.values():
                    if p["links"].get("subscription") == sub["id"] and p["status"] == "pending_submission":
                        p["status"] = "cancelled"
            elif action == "pause":
                sub["status"] = "paused"
            else:
                sub["status"] = "active"
            return httpx.Response(200, json={"subscriptions": sub})
        if m := re.match(r"^/subscriptions/([^/]+)$", path):
            sub = self.subscriptions.get(m.group(1))
            return httpx.Response(200, json={"subscriptions": sub}) if sub else _gc_error(404, "not found")
        return httpx.Response(404, json={"error": {"message": f"fake gc: {method} {path}"}})


# --------------------------------------------------------------------------- Stripe
def _stripe_error(status: int, etype: str, message: str, **extra) -> httpx.Response:
    return httpx.Response(status, json={"error": {"type": etype, "message": message, **extra}},
                          headers={"Stripe-Should-Retry": "false"})


class FakeStripe(Recorder):
    """Stripe com estado: clientes, Checkout (setup/payment), SetupIntents, PaymentMethods e PaymentIntents
    fora de sessão (com a semântica de idempotência do Stripe: mesma chave → mesma resposta; mesma chave com
    parâmetros diferentes → erro de idempotência)."""

    def __init__(self, mock: respx.MockRouter):
        super().__init__()
        self.customers: dict[str, dict] = {}
        self.sessions: dict[str, dict] = {}
        self.setup_intents: dict[str, dict] = {}
        self.payment_methods: dict[str, dict] = {}
        self.payment_intents: dict[str, dict] = {}
        self.form_log: list[tuple[str, str, dict]] = []
        self.idempotency_keys: list[tuple[str, str]] = []  # (caminho, chave)
        self._idem: dict[str, tuple[dict, httpx.Response]] = {}
        # comportamento das cobranças por método: "succeeded" | "processing" | ("card_error", decline_code)
        # | ("requires_action",) | "api_error"
        self.behavior: dict[str, object] = {}
        self.account_id = "acct_1"
        self.fail_paths: dict[str, int] = {}
        # Subscrições do Stripe Billing antigo (migração) e preços
        self.subscriptions: dict[str, dict] = {}
        self.prices: dict[str, dict] = {}
        self.products: dict[str, dict] = {}
        self._n = itertools.count(1)
        mock.route(host=STRIPE_HOST).side_effect = self._dispatch

    def add_legacy_subscription(self, *, email: str, amount: int = 1000, interval: str = "month",
                                period_start: int, period_end: int, status: str = "active",
                                with_pm: bool = True) -> dict:
        cid = self._id("cus")
        self.customers[cid] = {"id": cid, "object": "customer", "email": email, "name": email.split("@")[0],
                               "metadata": {}, "invoice_settings": {"default_payment_method": None}}
        pm = self.add_payment_method(cid) if with_pm else None
        if pm:
            self.customers[cid]["invoice_settings"]["default_payment_method"] = pm["id"]
        prod = self.products.setdefault("prod_gpt", {"id": "prod_gpt", "object": "product", "name": "TKGPT Pro",
                                                     "metadata": {}})
        price_id = f"price_{amount}_{interval}"
        self.prices[price_id] = {"id": price_id, "object": "price", "unit_amount": amount, "currency": "eur",
                                 "nickname": None, "product": prod["id"],
                                 "recurring": {"interval": interval, "interval_count": 1}}
        sid = self._id("sub")
        self.subscriptions[sid] = {
            "id": sid, "object": "subscription", "status": status, "customer": cid, "cancel_at_period_end": False,
            "default_payment_method": None, "start_date": period_start,
            "items": {"object": "list", "data": [{"id": self._id("si"), "price": dict(self.prices[price_id]),
                                                  "current_period_start": period_start,
                                                  "current_period_end": period_end}]},
        }
        return self.subscriptions[sid]

    def _id(self, prefix: str) -> str:
        return f"{prefix}_{next(self._n):05d}"

    # -- helpers
    def add_payment_method(self, customer: str | None, *, brand: str = "visa", last4: str = "4242",
                           exp_month: int = 12, exp_year: int = 2030, kind: str = "card") -> dict:
        pid = self._id("pm")
        pm = {"id": pid, "object": "payment_method", "type": kind, "customer": customer}
        if kind == "card":
            pm["card"] = {"brand": brand, "last4": last4, "exp_month": exp_month, "exp_year": exp_year}
        elif kind == "sepa_debit":
            pm["sepa_debit"] = {"last4": last4}
        self.payment_methods[pid] = pm
        return pm

    def complete_setup(self, session_id: str, **card) -> dict:
        """O cliente conclui o Checkout em modo setup: cria o método e o SetupIntent."""
        sess = self.sessions[session_id]
        pm = self.add_payment_method(sess["customer"], **card)
        si = {"id": self._id("seti"), "object": "setup_intent", "status": "succeeded", "payment_method": pm["id"],
              "customer": sess["customer"]}
        self.setup_intents[si["id"]] = si
        sess["status"] = "complete"
        sess["setup_intent"] = si["id"]
        return pm

    def complete_payment(self, session_id: str, *, status: str = "succeeded", **card) -> dict:
        """O cliente paga no Checkout em modo payment (o método fica guardado para uso futuro)."""
        sess = self.sessions[session_id]
        pm = self.add_payment_method(sess["customer"], **card)
        pi = {"id": self._id("pi"), "object": "payment_intent", "status": status, "amount": sess["amount_total"],
              "currency": sess.get("currency") or "eur", "customer": sess["customer"], "payment_method": pm["id"],
              "metadata": sess.get("payment_intent_metadata") or {}}
        self.payment_intents[pi["id"]] = pi
        sess["status"] = "complete"
        sess["payment_intent"] = pi["id"]
        return pi

    def expire_session(self, session_id: str) -> dict:
        self.sessions[session_id]["status"] = "expired"
        return self.sessions[session_id]

    def charges(self) -> list[dict]:
        return [pi for pi in self.payment_intents.values() if pi.get("off_session")]

    def keys_for(self, path: str) -> list[str]:
        return [k for p, k in self.idempotency_keys if p == path]

    def _create_pi(self, form: dict) -> httpx.Response:
        pm_id = form.get("payment_method")
        pm = self.payment_methods.get(pm_id or "")
        if pm is None:
            return _stripe_error(400, "invalid_request_error", f"No such PaymentMethod: '{pm_id}'",
                                 code="resource_missing", param="payment_method")
        if pm.get("customer") != form.get("customer"):
            return _stripe_error(400, "invalid_request_error",
                                 "The provided PaymentMethod was previously used without being attached to a Customer",
                                 code="payment_method_unexpected_state")
        behavior = self.behavior.get(pm_id, "succeeded")
        if behavior == "api_error":
            return _stripe_error(500, "api_error", "Erro interno simulado")
        pi = {"id": self._id("pi"), "object": "payment_intent", "amount": int(form["amount"]),
              "currency": form["currency"], "customer": form.get("customer"), "payment_method": pm_id,
              "off_session": True, "description": form.get("description"),
              "metadata": {k[9:-1]: v for k, v in form.items() if k.startswith("metadata[")}}
        self.payment_intents[pi["id"]] = pi
        if behavior in ("succeeded", "processing"):
            pi["status"] = behavior
            return httpx.Response(200, json=pi)
        kind, *rest = behavior if isinstance(behavior, tuple) else (behavior,)
        if kind == "requires_action":
            pi["status"] = "requires_action"
            err = {"code": "authentication_required", "decline_code": "authentication_required",
                   "message": "This payment requires authentication."}
        else:
            pi["status"] = "requires_payment_method"
            decline = rest[0] if rest else "generic_decline"
            err = {"code": "expired_card" if decline == "expired_card" else "card_declined",
                   "decline_code": decline, "message": f"Your card was declined ({decline})."}
        pi["last_payment_error"] = err
        return _stripe_error(402, "card_error", err["message"], code=err["code"], decline_code=err["decline_code"],
                             payment_intent=pi)

    def _dispatch(self, request: httpx.Request) -> httpx.Response:
        self.record(request)
        if request.headers.get("authorization") != "Bearer sk_test_x":
            return _stripe_error(401, "invalid_request_error", "bad key")
        path, method = request.url.path, request.method
        form = _form(request) if method == "POST" else {}
        self.form_log.append((method, path, form))
        key = request.headers.get("idempotency-key")
        if key and method == "POST":
            self.idempotency_keys.append((path, key))
        if path in self.fail_paths:
            return _stripe_error(self.fail_paths[path], "api_error", "falha simulada")
        if key and method == "POST":
            if key in self._idem:
                old_form, old_resp = self._idem[key]
                if old_form != form:
                    return _stripe_error(400, "idempotency_error",
                                         "Keys for idempotent requests can only be used with the same parameters "
                                         "they were first used with.")
                return httpx.Response(old_resp.status_code, content=old_resp.content, headers=old_resp.headers)
        resp = self._route(path, method, form)
        if key and method == "POST" and resp.status_code < 500:
            self._idem[key] = (form, resp)
        return resp

    def _route(self, path: str, method: str, form: dict) -> httpx.Response:
        if path == "/v1/customers" and method == "POST":
            cid = self._id("cus")
            self.customers[cid] = {"id": cid, "object": "customer", "email": form.get("email"),
                                   "name": form.get("name"),
                                   "metadata": {k[9:-1]: v for k, v in form.items() if k.startswith("metadata[")}}
            return httpx.Response(200, json=self.customers[cid])
        if path == "/v1/checkout/sessions" and method == "POST":
            sid = self._id("cs_test")
            self.sessions[sid] = {
                "id": sid, "object": "checkout.session", "status": "open", "mode": form.get("mode"),
                "url": f"https://checkout.stripe.com/c/pay/{sid}", "customer": form.get("customer"),
                "client_reference_id": form.get("client_reference_id"), "currency": form.get("currency"),
                "success_url": form.get("success_url"), "cancel_url": form.get("cancel_url"),
                "amount_total": int(form.get("line_items[0][price_data][unit_amount]") or 0) or None,
                "setup_intent": None, "payment_intent": None,
                "metadata": {k[9:-1]: v for k, v in form.items() if k.startswith("metadata[")},
                "payment_intent_metadata": {k[len("payment_intent_data[metadata]["):-1]: v for k, v in form.items()
                                            if k.startswith("payment_intent_data[metadata][")},
                "setup_future_usage": form.get("payment_intent_data[setup_future_usage]"),
            }
            if form.get("line_items[0][price_data][currency]"):
                self.sessions[sid]["currency"] = form["line_items[0][price_data][currency]"]
            return httpx.Response(200, json=self.sessions[sid])
        if m := re.match(r"^/v1/checkout/sessions/([^/]+)$", path):
            s = self.sessions.get(m.group(1))
            return httpx.Response(200, json=s) if s else _stripe_error(404, "invalid_request_error", "no such session")
        if m := re.match(r"^/v1/setup_intents/([^/]+)$", path):
            si = self.setup_intents.get(m.group(1))
            return httpx.Response(200, json=si) if si else _stripe_error(404, "invalid_request_error", "no such si")
        if m := re.match(r"^/v1/payment_methods/([^/]+)/detach$", path):
            pm = self.payment_methods.get(m.group(1))
            if not pm:
                return _stripe_error(404, "invalid_request_error", "no such payment method")
            pm["customer"] = None
            return httpx.Response(200, json=pm)
        if m := re.match(r"^/v1/payment_methods/([^/]+)$", path):
            pm = self.payment_methods.get(m.group(1))
            return httpx.Response(200, json=pm) if pm else _stripe_error(404, "invalid_request_error", "no such pm")
        if path == "/v1/payment_intents" and method == "POST":
            return self._create_pi(form)
        if m := re.match(r"^/v1/payment_intents/([^/]+)$", path):
            pi = self.payment_intents.get(m.group(1))
            return httpx.Response(200, json=pi) if pi else _stripe_error(404, "invalid_request_error", "no such pi")
        if path in ("/v1/account", "/v1/accounts"):
            return httpx.Response(200, json={"id": self.account_id, "object": "account"})
        if path == "/v1/subscriptions" and method == "GET":
            data = []
            for sub in self.subscriptions.values():
                d = dict(sub)
                d["customer"] = self.customers.get(sub["customer"], sub["customer"])
                data.append(d)
            return httpx.Response(200, json={"object": "list", "data": data, "has_more": False,
                                             "url": "/v1/subscriptions"})
        if m := re.match(r"^/v1/subscriptions/([^/]+)$", path):
            sub = self.subscriptions.get(m.group(1))
            if not sub:
                return _stripe_error(404, "invalid_request_error", "no such subscription")
            if method == "DELETE":
                sub["status"] = "canceled"
            return httpx.Response(200, json=sub)
        if m := re.match(r"^/v1/prices/([^/]+)$", path):
            pr = self.prices.get(m.group(1))
            if not pr:
                return _stripe_error(404, "invalid_request_error", "no such price")
            return httpx.Response(200, json={**pr, "product": self.products.get(pr["product"], pr["product"])})
        if m := re.match(r"^/v1/customers/([^/]+)$", path):
            cu = self.customers.get(m.group(1))
            return httpx.Response(200, json=cu) if cu else _stripe_error(404, "invalid_request_error", "no such cus")
        return _stripe_error(404, "invalid_request_error", f"fake stripe: {method} {path}")


# --------------------------------------------------------------------------- Bazarr
BAZARR_HOST = "bazarr.test"
BAZARR_API_KEY = "bazarr-key-123"


class FakeBazarr(Recorder):
    """Bazarr com estado: filmes (radarrId), séries/episódios (sonarrSeriesId/sonarrEpisodeId), resultados de
    pesquisa manual por fornecedor, downloads, pesquisa automática e sincronização."""

    def __init__(self, mock: respx.MockRouter):
        super().__init__()
        self.movies: dict[int, dict] = {}
        self.series: dict[int, dict] = {}
        self.episodes: dict[int, dict] = {}
        self.search_results: dict[tuple[str, int], list[dict]] = {}  # ("movie", radarrId) | ("episode", epId)
        self.downloads: list[dict] = []
        self.auto: list[dict] = []
        self.syncs: list[dict] = []
        self.fail_paths: dict[str, int] = {}
        self._ids = itertools.count(1)
        mock.route(host=BAZARR_HOST).side_effect = self._dispatch

    def add_movie(self, title: str, *, imdb: str | None = None, path: str | None = None,
                  subtitles: list[dict] | None = None, missing: list[str] | None = None) -> dict:
        rid = next(self._ids)
        self.movies[rid] = {"radarrId": rid, "title": title, "imdbId": imdb, "path": path,
                            "subtitles": subtitles or [], "missing_subtitles": [{"code2": c} for c in missing or []]}
        return self.movies[rid]

    def add_series(self, title: str, *, tvdb: int | None = None, imdb: str | None = None) -> dict:
        sid = next(self._ids)
        self.series[sid] = {"sonarrSeriesId": sid, "title": title, "tvdbId": tvdb, "imdbId": imdb}
        return self.series[sid]

    def add_episode(self, series: dict, season: int, episode: int, *, path: str | None = None,
                    subtitles: list[dict] | None = None) -> dict:
        eid = next(self._ids) + 1000
        self.episodes[eid] = {"sonarrSeriesId": series["sonarrSeriesId"], "sonarrEpisodeId": eid, "season": season,
                              "episode": episode, "path": path, "subtitles": subtitles or [], "missing_subtitles": []}
        return self.episodes[eid]

    def _dispatch(self, request: httpx.Request) -> httpx.Response:
        self.record(request)
        if request.headers.get("x-api-key") != BAZARR_API_KEY:
            return httpx.Response(401)
        path, method, p = request.url.path, request.method, request.url.params
        if path in self.fail_paths:
            return httpx.Response(self.fail_paths[path], text="falha simulada")
        if path == "/api/movies" and method == "GET":
            rows = list(self.movies.values())
            if p.get("radarrid[]"):
                rows = [m for m in rows if str(m["radarrId"]) == p["radarrid[]"]]
            return httpx.Response(200, json={"data": rows, "total": len(rows)})
        if path == "/api/series" and method == "GET":
            return httpx.Response(200, json={"data": list(self.series.values())})
        if path == "/api/episodes" and method == "GET":
            rows = list(self.episodes.values())
            if p.get("seriesid[]"):
                rows = [e for e in rows if str(e["sonarrSeriesId"]) == p["seriesid[]"]]
            if p.get("episodeid[]"):
                rows = [e for e in rows if str(e["sonarrEpisodeId"]) == p["episodeid[]"]]
            return httpx.Response(200, json={"data": rows})
        if path == "/api/providers/movies" and method == "GET":
            return httpx.Response(200, json={"data": self.search_results.get(("movie", int(p["radarrid"])), [])})
        if path == "/api/providers/episodes" and method == "GET":
            return httpx.Response(200, json={"data": self.search_results.get(("episode", int(p["episodeid"])), [])})
        if path in ("/api/providers/movies", "/api/providers/episodes") and method == "POST":
            self.downloads.append({"kind": path.rsplit("/", 1)[1], **_form(request)})
            return httpx.Response(204)
        if path in ("/api/movies/subtitles", "/api/episodes/subtitles") and method == "PATCH":
            self.auto.append({"kind": path.split("/")[2], **dict(p)})
            return httpx.Response(204)
        if path == "/api/subtitles" and method == "PATCH":
            if p.get("action") != "sync":
                return httpx.Response(400)
            self.syncs.append(dict(p))
            return httpx.Response(204)
        if path == "/api/system/status":
            return httpx.Response(200, json={"data": {"bazarr_version": "1.5"}})
        return httpx.Response(404, text=f"fake bazarr: {method} {path}")


# --------------------------------------------------------------------------- modelo de linguagem
class FakeLLM:
    """Modelo falso: `script` é uma lista de respostas (LLMResponse, Exception ou função(messages, tools)).

    As chamadas de classificação (encaminhamento) respondem `route`; com `vectors` (função texto → vetor) e
    `embedding_model` definido, também simula embeddings.
    """

    def __init__(self, script=None, *, route: str = "SUPPORT"):
        self.script = list(script or [])
        self.calls: list[dict] = []
        self.route = route
        self.embedding_model = None
        self.vectors = None
        self.embedded: list[str] = []

    def __call__(self):
        return self

    async def complete(self, messages, tools=None, *, fast=False, metadata=None, json_mode=False):
        self.calls.append({"messages": messages, "tools": [t["function"]["name"] for t in tools or []],
                           "fast": fast, "json_mode": json_mode})
        if fast and not tools and "Classifica" in messages[0]["content"]:
            return _llm_response(self.route)
        if not self.script:
            return _llm_response("ok")
        nxt = self.script.pop(0)
        if isinstance(nxt, Exception):
            raise nxt
        return nxt(messages, tools) if callable(nxt) else nxt

    async def embed(self, texts):
        if not self.embedding_model or self.vectors is None:
            return None
        self.embedded.extend(texts)
        return [self.vectors(t) for t in texts]

    def agent_calls(self):
        return [c for c in self.calls if c["tools"]]


def _llm_response(content):
    from app.assistant.llm import LLMResponse

    return LLMResponse(content)


def call(name, **args):
    """Resposta do modelo que pede uma ferramenta."""
    from app.assistant.llm import LLMResponse, ToolCall

    return LLMResponse(None, [ToolCall(id=f"c-{name}", name=name, arguments=args)])


def calls(*pairs):
    """Resposta com várias ferramentas em paralelo: calls(("find_title", {...}), ...)."""
    from app.assistant.llm import LLMResponse, ToolCall

    return LLMResponse(None, [ToolCall(id=f"c{i}-{n}", name=n, arguments=a) for i, (n, a) in enumerate(pairs)])
