"""Importação com revisão: clientes lidos da GoCardless e do users.db, editáveis antes de importar

Revision ID: 0010
Revises: 0009
Create Date: 2026-10-08 15:00:00

"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

import app.db  # noqa: F401 — tipos personalizados (UTCDateTime, JSONType)

revision: str = '0010'
down_revision: Union[str, Sequence[str], None] = '0009'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _json():
    return sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql')


def upgrade() -> None:
    op.create_table(
        'import_rows',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('batch', sa.String(length=36), nullable=False),
        sa.Column('key', sa.String(length=96), nullable=False),
        sa.Column('email', sa.String(length=254), nullable=True),
        sa.Column('source', _json(), nullable=False),
        sa.Column('proposal', _json(), nullable=False),
        sa.Column('flags', _json(), nullable=False),
        sa.Column('status', sa.String(length=16), nullable=False),
        sa.Column('result', sa.Text(), nullable=True),
        sa.Column('edited', sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column('created_at', app.db.UTCDateTime(timezone=True), nullable=False),
        sa.Column('updated_at', app.db.UTCDateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint('id', name=op.f('pk_import_rows')),
    )
    op.create_index(op.f('ix_import_rows_batch'), 'import_rows', ['batch'], unique=False)
    op.create_index(op.f('ix_import_rows_key'), 'import_rows', ['key'], unique=False)


def downgrade() -> None:
    op.drop_index(op.f('ix_import_rows_key'), table_name='import_rows')
    op.drop_index(op.f('ix_import_rows_batch'), table_name='import_rows')
    op.drop_table('import_rows')
