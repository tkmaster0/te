"""Modelo de dados do portal.

Princípios:
- O portal é a fonte de verdade para utilizadores, subscrições e direitos (entitlements).
- Serviços externos (Jellyfin, Seerr, Dispatcharr) são *reconciliados* a partir desse estado.
- Pagamentos (GoCardless / Stripe) chegam por webhooks idempotentes e ficam espelhados localmente.
"""
from __future__ import annotations

import enum
import uuid
from datetime import datetime

from sqlalchemy import (
    Boolean,
    ForeignKey,
    Index,
    Integer,
    LargeBinary,
    String,
    Text,
    UniqueConstraint,
    false,
    true,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .db import Base, JSONType, UTCDateTime, utcnow


def _uuid() -> str:
    return str(uuid.uuid4())


class SubStatus(str, enum.Enum):
    pending = "pending"          # checkout iniciado, ainda sem subscrição no fornecedor
    active = "active"
    past_due = "past_due"        # pagamento falhou; acesso mantém-se até grace_until
    canceling = "canceling"      # cancelada, acesso até access_until
    bonus = "bonus"              # cobrança pausada pelo programa de bónus, acesso mantém-se
    suspended = "suspended"      # sem pagamento após o período de tolerância
    ended = "ended"


ENTITLED_STATUSES = {SubStatus.active, SubStatus.past_due, SubStatus.canceling, SubStatus.bonus}
LIVE_STATUSES = ENTITLED_STATUSES | {SubStatus.suspended, SubStatus.pending}


class User(Base):
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    username: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    email: Mapped[str] = mapped_column(String(254), unique=True, index=True)
    display_name: Mapped[str | None] = mapped_column(String(120))
    password_hash: Mapped[str] = mapped_column(String(255))
    email_verified_at: Mapped[datetime | None] = mapped_column(UTCDateTime())
    is_admin: Mapped[bool] = mapped_column(Boolean, default=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)  # False = bloqueado pelo admin
    locale: Mapped[str] = mapped_column(String(10), default="pt-PT")

    totp_secret_enc: Mapped[str | None] = mapped_column(Text)
    totp_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    recovery_codes: Mapped[list | None] = mapped_column(JSONType)  # lista de hashes

    referred_by_id: Mapped[str | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"))
    invite_code_id: Mapped[int | None] = mapped_column(ForeignKey("invite_codes.id", ondelete="SET NULL", use_alter=True))

    stripe_customer_id: Mapped[str | None] = mapped_column(String(64), unique=True)
    gocardless_customer_id: Mapped[str | None] = mapped_column(String(64), index=True)
    gocardless_mandate_id: Mapped[str | None] = mapped_column(String(64))

    # Faturação consolidada: todos os serviços do cliente são cobrados juntos neste dia do mês (1–28).
    billing_anchor_day: Mapped[int | None] = mapped_column(Integer)
    next_billing_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), index=True)

    # Quando True, na próxima vez que tivermos a password em claro (login), sincroniza com o Jellyfin.
    needs_password_sync: Mapped[bool] = mapped_column(Boolean, default=False)
    # Login "à antiga" no Jellyfin (username + password do portal). Só os clientes migrados/anteriores ao SSO o
    # mantêm; as contas novas entram no Jellyfin, Seerr e LibreChat por SSO (OIDC) e Quick Connect.
    jellyfin_password_login: Mapped[bool] = mapped_column(Boolean, default=False)
    # legacy = pode pagar cada serviço diretamente (clientes anteriores à carteira)
    # wallet = só a carteira de créditos (contas novas): os serviços são pagos com o saldo da carteira
    billing_mode: Mapped[str] = mapped_column(String(16), default="wallet")
    # Produtos em beta fechado (Product.requires_invite) que este cliente desbloqueou com um código de convite.
    unlocked_products: Mapped[list | None] = mapped_column(JSONType)
    legacy_id: Mapped[int | None] = mapped_column(Integer, unique=True)
    admin_notes: Mapped[str | None] = mapped_column(Text)

    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow, onupdate=utcnow)
    last_login_at: Mapped[datetime | None] = mapped_column(UTCDateTime())
    password_changed_at: Mapped[datetime | None] = mapped_column(UTCDateTime())

    referred_by: Mapped[User | None] = relationship(remote_side="User.id", foreign_keys=[referred_by_id])
    subscriptions: Mapped[list[Subscription]] = relationship(back_populates="user", foreign_keys="Subscription.user_id")


class LoginSession(Base):
    __tablename__ = "login_sessions"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)  # sha256 do token do cookie
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    public_id: Mapped[str] = mapped_column(String(36), default=_uuid, unique=True)
    mfa_pending: Mapped[bool] = mapped_column(Boolean, default=False)
    # None = sessão completa; "streaming" = aberta a partir do Jellyfin, só pode gerir o streaming
    scope: Mapped[str | None] = mapped_column(String(16))
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)
    last_seen_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)
    expires_at: Mapped[datetime] = mapped_column(UTCDateTime())
    auth_time: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)
    ip: Mapped[str | None] = mapped_column(String(64))
    user_agent: Mapped[str | None] = mapped_column(String(300))
    revoked_at: Mapped[datetime | None] = mapped_column(UTCDateTime())

    user: Mapped[User] = relationship()


class EmailToken(Base):
    __tablename__ = "email_tokens"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    purpose: Mapped[str] = mapped_column(String(32))  # verify_email | reset_password | change_email | magic_login
    token_hash: Mapped[str] = mapped_column(String(64), unique=True)
    data: Mapped[dict | None] = mapped_column(JSONType)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)
    expires_at: Mapped[datetime] = mapped_column(UTCDateTime())
    used_at: Mapped[datetime | None] = mapped_column(UTCDateTime())


class InviteCode(Base):
    __tablename__ = "invite_codes"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    code: Mapped[str] = mapped_column(String(32), unique=True, index=True)
    created_by_id: Mapped[str | None] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    max_uses: Mapped[int] = mapped_column(Integer, default=1)
    uses: Mapped[int] = mapped_column(Integer, default=0)
    expires_at: Mapped[datetime | None] = mapped_column(UTCDateTime())
    note: Mapped[str | None] = mapped_column(String(200))
    disabled: Mapped[bool] = mapped_column(Boolean, default=False)
    # Produtos em beta fechado que este código desbloqueia (códigos de produto). None = os que o criador tem
    # desbloqueados (um convite de um cliente TKFLIX desbloqueia o TKFLIX); [] = só serve para o registo.
    unlocks: Mapped[list | None] = mapped_column(JSONType)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)

    created_by: Mapped[User | None] = relationship(foreign_keys=[created_by_id])


class Product(Base):
    __tablename__ = "products"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    code: Mapped[str] = mapped_column(String(48), unique=True)
    name: Mapped[str] = mapped_column(String(120))
    description: Mapped[str | None] = mapped_column(Text)
    kind: Mapped[str] = mapped_column(String(32), default="streaming")  # categoria para mostrar (livre)
    # Como o serviço é entregue quando a subscrição fica ativa:
    #   streaming → direitos Jellyfin/Seerr/IPTV do plano | manual → o admin ativa e preenche os dados de acesso
    #   webhook → o portal notifica um URL teu (HMAC) | none → só cobrança (ex.: donativo, suporte)
    fulfillment: Mapped[str] = mapped_column(String(16), default="streaming")
    webhook_url: Mapped[str | None] = mapped_column(String(500))
    webhook_secret_enc: Mapped[str | None] = mapped_column(Text)
    access_instructions: Mapped[str | None] = mapped_column(Text)  # mostrado ao cliente com o serviço ativo
    # Endereço da app do serviço (botão "Abrir" para quem o tem ativo). Com SSO, o login é a conta TKWS.
    app_url: Mapped[str | None] = mapped_column(String(500))
    # Imagem do produto carregada por web (/media/product-<id>?v=…); sem ela usa o ícone.
    image_url: Mapped[str | None] = mapped_column(String(255))
    icon: Mapped[str | None] = mapped_column(String(32))
    bonus_eligible: Mapped[bool] = mapped_column(Boolean, default=True)  # o bónus de convites isenta este produto
    jellyfin_managed: Mapped[bool] = mapped_column(Boolean, default=False)  # gerível pela página do Jellyfin
    # Beta fechado: só quem se registou com um convite deste produto (ou meteu um código depois) o vê com o nome
    # verdadeiro e o pode subscrever. Os outros veem `locked_name` desativado, com a opção de meter um código.
    requires_invite: Mapped[bool] = mapped_column(Boolean, default=False)
    locked_name: Mapped[str | None] = mapped_column(String(120))
    locked_description: Mapped[str | None] = mapped_column(String(255))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)

    plans: Mapped[list[Plan]] = relationship(back_populates="product", order_by="Plan.sort_order")


class Plan(Base):
    __tablename__ = "plans"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id", ondelete="CASCADE"), index=True)
    code: Mapped[str] = mapped_column(String(48), unique=True)
    name: Mapped[str] = mapped_column(String(120))
    description: Mapped[str | None] = mapped_column(Text)
    price_cents: Mapped[int] = mapped_column(Integer)
    currency: Mapped[str] = mapped_column(String(3), default="EUR")
    interval_unit: Mapped[str] = mapped_column(String(10), default="month")  # month | year
    interval_count: Mapped[int] = mapped_column(Integer, default=1)
    gocardless_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    stripe_price_id: Mapped[str | None] = mapped_column(String(64))
    features: Mapped[dict] = mapped_column(JSONType, default=dict)
    highlights: Mapped[list] = mapped_column(JSONType, default=list)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_public: Mapped[bool] = mapped_column(Boolean, default=True)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)

    product: Mapped[Product] = relationship(back_populates="plans")


class Checkout(Base):
    __tablename__ = "checkouts"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    plan_id: Mapped[int | None] = mapped_column(ForeignKey("plans.id"))
    provider: Mapped[str] = mapped_column(String(16))
    # setup_pm (guardar método) | pay_invoice (pagar cobrança em atraso) | legado: new | change
    purpose: Mapped[str] = mapped_column(String(16), default="setup_pm")
    # O que fazer quando o método ficar guardado, ex.: {"action": "subscribe", "plan_id": 3}
    intent: Mapped[dict | None] = mapped_column(JSONType)
    invoice_id: Mapped[str | None] = mapped_column(String(36))
    payment_method_id: Mapped[str | None] = mapped_column(String(36))
    session_scope: Mapped[str | None] = mapped_column(String(16))
    replaces_subscription_id: Mapped[str | None] = mapped_column(String(36))
    status: Mapped[str] = mapped_column(String(16), default="pending")  # pending | completed | cancelled | failed
    provider_ref: Mapped[str | None] = mapped_column(String(128), index=True)
    subscription_id: Mapped[str | None] = mapped_column(String(36))
    error: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)
    completed_at: Mapped[datetime | None] = mapped_column(UTCDateTime())

    plan: Mapped[Plan] = relationship()


class Subscription(Base):
    __tablename__ = "subscriptions"
    __table_args__ = (
        UniqueConstraint("provider", "provider_subscription_id", name="uq_subscriptions_provider_ref"),
        Index("ix_subscriptions_user_status", "user_id", "status"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    plan_id: Mapped[int] = mapped_column(ForeignKey("plans.id"))
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id"))
    # portal = faturação consolidada (normal) | manual = oferta/sem cobrança
    # gocardless | stripe = subscrição antiga gerida pelo fornecedor (só legado, até ser migrada)
    provider: Mapped[str] = mapped_column(String(16), default="portal")
    # Preço fixado para esta subscrição (None = preço atual do plano). Permite manter preços antigos.
    price_cents: Mapped[int | None] = mapped_column(Integer)
    current_period_start: Mapped[datetime | None] = mapped_column(UTCDateTime())
    # Valor efetivamente faturado pelo período atual (0 se isento por bónus) — base do crédito pro-rata
    period_amount_cents: Mapped[int | None] = mapped_column(Integer)
    # Entrega de produtos "manual"/"webhook": pending | done | error
    fulfillment_status: Mapped[str | None] = mapped_column(String(16))
    access_details_enc: Mapped[str | None] = mapped_column(Text)  # JSON cifrado com dados de acesso do cliente
    provider_subscription_id: Mapped[str | None] = mapped_column(String(64))
    provider_customer_id: Mapped[str | None] = mapped_column(String(64))
    provider_mandate_id: Mapped[str | None] = mapped_column(String(64))
    status: Mapped[SubStatus] = mapped_column(String(16), default=SubStatus.pending)
    current_period_end: Mapped[datetime | None] = mapped_column(UTCDateTime())  # próxima cobrança
    access_until: Mapped[datetime | None] = mapped_column(UTCDateTime())  # fim do acesso se cancelada
    grace_until: Mapped[datetime | None] = mapped_column(UTCDateTime())
    cancel_at_period_end: Mapped[bool] = mapped_column(Boolean, default=False)
    pending_plan_id: Mapped[int | None] = mapped_column(ForeignKey("plans.id"))
    started_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)
    ended_at: Mapped[datetime | None] = mapped_column(UTCDateTime())
    meta: Mapped[dict | None] = mapped_column(JSONType)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow, onupdate=utcnow)

    user: Mapped[User] = relationship(back_populates="subscriptions", foreign_keys=[user_id])
    plan: Mapped[Plan] = relationship(foreign_keys=[plan_id])
    pending_plan: Mapped[Plan | None] = relationship(foreign_keys=[pending_plan_id])


class Payment(Base):
    __tablename__ = "payments"
    __table_args__ = (UniqueConstraint("provider", "provider_payment_id", name="uq_payments_provider_ref"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    user_id: Mapped[str | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), index=True)
    subscription_id: Mapped[str | None] = mapped_column(ForeignKey("subscriptions.id", ondelete="SET NULL"))
    invoice_id: Mapped[str | None] = mapped_column(ForeignKey("invoices.id", ondelete="SET NULL"), index=True)
    payment_method_id: Mapped[str | None] = mapped_column(String(36))
    provider: Mapped[str] = mapped_column(String(16))
    provider_payment_id: Mapped[str] = mapped_column(String(64))
    failure_reason: Mapped[str | None] = mapped_column(String(255))
    amount_cents: Mapped[int] = mapped_column(Integer)
    currency: Mapped[str] = mapped_column(String(3), default="EUR")
    status: Mapped[str] = mapped_column(String(32))  # pending | paid | failed | refunded | cancelled | charged_back
    description: Mapped[str | None] = mapped_column(String(255))
    charge_date: Mapped[datetime | None] = mapped_column(UTCDateTime())
    receipt_url: Mapped[str | None] = mapped_column(String(500))
    # Pagamento feito pelo próprio cliente no portal ("Pagar", carregamento da carteira) — só esses levam o email
    # de "pagamento recebido"; as cobranças automáticas ao método autorizado não.
    interactive: Mapped[bool] = mapped_column(Boolean, default=False, server_default=false())
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow, onupdate=utcnow)


class PaymentMethod(Base):
    """Método de pagamento guardado do cliente (mandato SEPA GoCardless ou método Stripe)."""

    __tablename__ = "payment_methods"
    __table_args__ = (UniqueConstraint("provider", "provider_ref", name="uq_payment_methods_provider_ref"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    provider: Mapped[str] = mapped_column(String(16))  # gocardless | stripe
    provider_account: Mapped[str | None] = mapped_column(String(64))  # conta do fornecedor onde foi criado
    provider_customer_id: Mapped[str | None] = mapped_column(String(64))
    provider_ref: Mapped[str] = mapped_column(String(64))  # mandate id / payment_method id
    kind: Mapped[str] = mapped_column(String(16), default="sepa")  # sepa | card | other
    label: Mapped[str] = mapped_column(String(120))  # ex.: "Débito direto · CGD ••••1234"
    # active | pending (mandato a ser submetido) | unusable (fornecedor desativado/conta trocada) | revoked
    status: Mapped[str] = mapped_column(String(16), default="active")
    status_reason: Mapped[str | None] = mapped_column(String(255))
    is_default: Mapped[bool] = mapped_column(Boolean, default=False)
    expires_at: Mapped[datetime | None] = mapped_column(UTCDateTime())  # cartões
    notified_at: Mapped[datetime | None] = mapped_column(UTCDateTime())
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow, onupdate=utcnow)


USABLE_PM_STATUSES = {"active", "pending"}


class Invoice(Base):
    """Uma cobrança consolidada (todos os serviços do cliente num só pagamento).

    Nota: é um documento de cobrança interno, não uma fatura certificada pela AT.
    """

    __tablename__ = "invoices"
    __table_args__ = (Index("ix_invoices_status_next_attempt", "status", "next_attempt_at"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    number: Mapped[str] = mapped_column(String(32), unique=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    kind: Mapped[str] = mapped_column(String(16), default="cycle")  # cycle | immediate | manual
    # open (por cobrar) | processing (pagamento submetido) | paid | failed (a aguardar nova tentativa/ação)
    # | void (anulada)
    status: Mapped[str] = mapped_column(String(16), default="open")
    currency: Mapped[str] = mapped_column(String(3), default="EUR")
    subtotal_cents: Mapped[int] = mapped_column(Integer, default=0)
    total_cents: Mapped[int] = mapped_column(Integer, default=0)
    period_start: Mapped[datetime | None] = mapped_column(UTCDateTime())
    attempt_count: Mapped[int] = mapped_column(Integer, default=0)
    next_attempt_at: Mapped[datetime | None] = mapped_column(UTCDateTime())
    payment_method_id: Mapped[str | None] = mapped_column(String(36))
    last_error: Mapped[str | None] = mapped_column(String(255))
    first_failed_at: Mapped[datetime | None] = mapped_column(UTCDateTime())
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)
    paid_at: Mapped[datetime | None] = mapped_column(UTCDateTime())
    voided_at: Mapped[datetime | None] = mapped_column(UTCDateTime())
    note: Mapped[str | None] = mapped_column(String(255))

    lines: Mapped[list[InvoiceLine]] = relationship(back_populates="invoice", order_by="InvoiceLine.id")


class InvoiceLine(Base):
    """Linha de cobrança. Sem invoice_id = pendente (entra na próxima cobrança do cliente)."""

    __tablename__ = "invoice_lines"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    invoice_id: Mapped[str | None] = mapped_column(ForeignKey("invoices.id", ondelete="CASCADE"), index=True)
    subscription_id: Mapped[str | None] = mapped_column(ForeignKey("subscriptions.id", ondelete="SET NULL"))
    product_id: Mapped[int | None] = mapped_column(Integer)
    # renewal | proration | credit | bonus | adjustment | carry
    kind: Mapped[str] = mapped_column(String(16))
    description: Mapped[str] = mapped_column(String(255))
    amount_cents: Mapped[int] = mapped_column(Integer)
    period_start: Mapped[datetime | None] = mapped_column(UTCDateTime())
    period_end: Mapped[datetime | None] = mapped_column(UTCDateTime())
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)

    invoice: Mapped[Invoice | None] = relationship(back_populates="lines")


class PriceChange(Base):
    """Mudança de preço agendada de um plano para os subscritores existentes (com aviso prévio)."""

    __tablename__ = "price_changes"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    plan_id: Mapped[int] = mapped_column(ForeignKey("plans.id", ondelete="CASCADE"), index=True)
    old_price_cents: Mapped[int] = mapped_column(Integer)
    new_price_cents: Mapped[int] = mapped_column(Integer)
    effective_at: Mapped[datetime] = mapped_column(UTCDateTime())
    note: Mapped[str | None] = mapped_column(String(255))
    # False = o admin avisa os clientes por fora (sem email nem aviso no portal).
    notify: Mapped[bool] = mapped_column(Boolean, default=True, server_default=true())
    notified_at: Mapped[datetime | None] = mapped_column(UTCDateTime())
    cancelled_at: Mapped[datetime | None] = mapped_column(UTCDateTime())
    created_by_id: Mapped[str | None] = mapped_column(String(36))
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)


class Counter(Base):
    """Contadores sequenciais (numeração das cobranças)."""

    __tablename__ = "counters"

    name: Mapped[str] = mapped_column(String(32), primary_key=True)
    value: Mapped[int] = mapped_column(Integer, default=0)


class Grant(Base):
    """Acesso oferecido manualmente pelo admin (ex.: família, testes, compensação)."""

    __tablename__ = "grants"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    plan_id: Mapped[int] = mapped_column(ForeignKey("plans.id"))
    reason: Mapped[str | None] = mapped_column(String(200))
    starts_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)
    ends_at: Mapped[datetime | None] = mapped_column(UTCDateTime())
    created_by_id: Mapped[str | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"))
    revoked_at: Mapped[datetime | None] = mapped_column(UTCDateTime())
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)

    plan: Mapped[Plan] = relationship()


class ServiceAccount(Base):
    """Ligação entre um utilizador do portal e uma conta num serviço externo."""

    __tablename__ = "service_accounts"
    __table_args__ = (
        UniqueConstraint("user_id", "service", name="uq_service_accounts_user_service"),
        UniqueConstraint("service", "external_id", name="uq_service_accounts_service_ext"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    service: Mapped[str] = mapped_column(String(24))  # jellyfin | seerr | dispatcharr | iptv (manual)
    external_id: Mapped[str | None] = mapped_column(String(64))
    external_username: Mapped[str | None] = mapped_column(String(128))
    secret_enc: Mapped[str | None] = mapped_column(Text)
    data: Mapped[dict | None] = mapped_column(JSONType)
    applied_state: Mapped[dict | None] = mapped_column(JSONType)
    last_synced_at: Mapped[datetime | None] = mapped_column(UTCDateTime())
    last_error: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)


class Job(Base):
    __tablename__ = "jobs"
    __table_args__ = (Index("ix_jobs_status_run_after", "status", "run_after"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    kind: Mapped[str] = mapped_column(String(48))
    payload: Mapped[dict] = mapped_column(JSONType, default=dict)
    status: Mapped[str] = mapped_column(String(16), default="pending")  # pending | running | done | failed
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    max_attempts: Mapped[int] = mapped_column(Integer, default=8)
    run_after: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)
    locked_at: Mapped[datetime | None] = mapped_column(UTCDateTime())
    locked_by: Mapped[str | None] = mapped_column(String(64))
    dedupe_key: Mapped[str | None] = mapped_column(String(128), index=True)
    last_error: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)
    finished_at: Mapped[datetime | None] = mapped_column(UTCDateTime())


class WebhookEvent(Base):
    __tablename__ = "webhook_events"
    __table_args__ = (UniqueConstraint("provider", "event_id", name="uq_webhook_events_provider_event"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    provider: Mapped[str] = mapped_column(String(16))
    event_id: Mapped[str] = mapped_column(String(128))
    event_type: Mapped[str] = mapped_column(String(96))
    payload: Mapped[dict] = mapped_column(JSONType)
    status: Mapped[str] = mapped_column(String(16), default="received")  # received | processed | ignored | failed
    error: Mapped[str | None] = mapped_column(Text)
    received_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)
    processed_at: Mapped[datetime | None] = mapped_column(UTCDateTime())


class AuditLog(Base):
    __tablename__ = "audit_log"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow, index=True)
    actor_id: Mapped[str | None] = mapped_column(String(36), index=True)
    actor_label: Mapped[str | None] = mapped_column(String(128))
    action: Mapped[str] = mapped_column(String(64), index=True)
    target_type: Mapped[str | None] = mapped_column(String(32))
    target_id: Mapped[str | None] = mapped_column(String(64), index=True)
    ip: Mapped[str | None] = mapped_column(String(64))
    details: Mapped[dict | None] = mapped_column(JSONType)


class OIDCClient(Base):
    __tablename__ = "oidc_clients"

    client_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    name: Mapped[str] = mapped_column(String(120))
    secret_hash: Mapped[str | None] = mapped_column(String(255))  # None = cliente público (PKCE obrigatório)
    redirect_uris: Mapped[list] = mapped_column(JSONType, default=list)
    post_logout_redirect_uris: Mapped[list] = mapped_column(JSONType, default=list)
    allowed_scopes: Mapped[list] = mapped_column(JSONType, default=lambda: ["openid", "profile", "email", "groups"])
    # Requisito para poder entrar: "admin", "feature:jellyfin", "feature:iptv", "any_active" ou None
    required_access: Mapped[str | None] = mapped_column(String(64))
    require_pkce: Mapped[bool] = mapped_column(Boolean, default=False)
    token_endpoint_auth_method: Mapped[str] = mapped_column(String(32), default="client_secret_basic")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)


class OIDCCode(Base):
    __tablename__ = "oidc_codes"

    code_hash: Mapped[str] = mapped_column(String(64), primary_key=True)
    client_id: Mapped[str] = mapped_column(ForeignKey("oidc_clients.client_id", ondelete="CASCADE"))
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    redirect_uri: Mapped[str] = mapped_column(Text)
    scope: Mapped[str] = mapped_column(String(500))
    nonce: Mapped[str | None] = mapped_column(String(255))
    code_challenge: Mapped[str | None] = mapped_column(String(128))
    code_challenge_method: Mapped[str | None] = mapped_column(String(10))
    auth_time: Mapped[datetime] = mapped_column(UTCDateTime())
    session_id: Mapped[str | None] = mapped_column(String(64))
    expires_at: Mapped[datetime] = mapped_column(UTCDateTime())
    used_at: Mapped[datetime | None] = mapped_column(UTCDateTime())


class OIDCRefreshToken(Base):
    __tablename__ = "oidc_refresh_tokens"

    token_hash: Mapped[str] = mapped_column(String(64), primary_key=True)
    client_id: Mapped[str] = mapped_column(ForeignKey("oidc_clients.client_id", ondelete="CASCADE"))
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    scope: Mapped[str] = mapped_column(String(500))
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)
    expires_at: Mapped[datetime] = mapped_column(UTCDateTime())
    revoked_at: Mapped[datetime | None] = mapped_column(UTCDateTime())


class SigningKey(Base):
    __tablename__ = "signing_keys"

    kid: Mapped[str] = mapped_column(String(64), primary_key=True)
    private_pem_enc: Mapped[str] = mapped_column(Text)
    public_jwk: Mapped[dict] = mapped_column(JSONType)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)
    retired_at: Mapped[datetime | None] = mapped_column(UTCDateTime())


class SiteSetting(Base):
    """Definições editáveis no painel admin (anúncio, links de apps, suporte, ...)."""

    __tablename__ = "site_settings"

    key: Mapped[str] = mapped_column(String(64), primary_key=True)
    value: Mapped[dict | list | str | int | bool | None] = mapped_column(JSONType)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow, onupdate=utcnow)


class ImportRow(Base):
    """Importação com revisão (Admin → Migração): um cliente lido da GoCardless (e/ou do users.db do site antigo).

    `source` é o que foi lido (só para consulta); `proposal` é o que vai ser importado e o admin pode editar antes de
    importar; `flags` são os avisos para verificar.
    """

    __tablename__ = "import_rows"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    batch: Mapped[str] = mapped_column(String(36), index=True)
    key: Mapped[str] = mapped_column(String(96), index=True)  # gc:<cliente> | legacy:<id>
    email: Mapped[str | None] = mapped_column(String(254))
    source: Mapped[dict] = mapped_column(JSONType)
    proposal: Mapped[dict] = mapped_column(JSONType)
    flags: Mapped[list] = mapped_column(JSONType)
    status: Mapped[str] = mapped_column(String(16), default="pending")  # pending | imported | skipped | error
    result: Mapped[str | None] = mapped_column(Text)
    edited: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow, onupdate=utcnow)


class SiteAsset(Base):
    """Imagens do site carregadas por web (logótipo, favicon, página inicial, partilha, produtos).

    Ficam na base de dados (entram nas cópias diárias) e são servidas em /media/<chave>.
    """

    __tablename__ = "site_assets"

    key: Mapped[str] = mapped_column(String(64), primary_key=True)
    content_type: Mapped[str] = mapped_column(String(64))
    data: Mapped[bytes] = mapped_column(LargeBinary)
    etag: Mapped[str] = mapped_column(String(32))
    size: Mapped[int] = mapped_column(Integer)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow, onupdate=utcnow)


class ConfigEntry(Base):
    """Definições da instalação editadas por web (Admin → Definições / assistente de configuração).

    Sobrepõem-se às variáveis de ambiente. Os segredos (tokens, passwords, chaves) ficam cifrados com a SECRET_KEY.
    """

    __tablename__ = "config_entries"

    key: Mapped[str] = mapped_column(String(64), primary_key=True)
    value: Mapped[dict | list | str | int | float | bool | None] = mapped_column(JSONType)
    secret: Mapped[bool] = mapped_column(Boolean, default=False)
    updated_by: Mapped[str | None] = mapped_column(String(36))
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow, onupdate=utcnow)


class Wallet(Base):
    """Carteira de créditos do cliente (1 crédito = 1 cêntimo de euro).

    O saldo é usado primeiro em todas as cobranças; o que faltar é cobrado ao método de pagamento. O saldo em
    `balance_cents` é uma cache do razão (`wallet_transactions`), atualizada na mesma transação.
    """

    __tablename__ = "wallets"

    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    balance_cents: Mapped[int] = mapped_column(Integer, default=0)
    # Carregamento mensal (None = desligado): somado à cobrança do dia de faturação e creditado quando pago.
    monthly_topup_cents: Mapped[int | None] = mapped_column(Integer)
    # Não carregar no mês em que o saldo já cobre os serviços (mensalidade "gratuita").
    monthly_skip_when_covered: Mapped[bool] = mapped_column(Boolean, default=True)
    monthly_since: Mapped[datetime | None] = mapped_column(UTCDateTime())
    # Jogos: maioridade confirmada, autoexclusão e limite diário de perdas escolhido pelo cliente.
    games_accepted_at: Mapped[datetime | None] = mapped_column(UTCDateTime())
    games_excluded_until: Mapped[datetime | None] = mapped_column(UTCDateTime())
    games_daily_loss_limit_cents: Mapped[int | None] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow, onupdate=utcnow)


class WalletTransaction(Base):
    """Movimento da carteira (razão imutável)."""

    __tablename__ = "wallet_transactions"
    __table_args__ = (Index("ix_wallet_tx_user_created", "user_id", "created_at"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    # topup | monthly_topup | invoice | refund | reversal | game_bet | game_win | bonus | adjustment | debt
    kind: Mapped[str] = mapped_column(String(16))
    amount_cents: Mapped[int] = mapped_column(Integer)  # + entra na carteira, - sai
    balance_after_cents: Mapped[int] = mapped_column(Integer)
    description: Mapped[str] = mapped_column(String(255))
    invoice_id: Mapped[str | None] = mapped_column(String(36), index=True)
    game_round_id: Mapped[str | None] = mapped_column(String(36))
    # Chave única por efeito (ex.: "topup-line-42", "void-<fatura>"): repetir a operação não duplica o movimento.
    idempotency_key: Mapped[str | None] = mapped_column(String(96), unique=True)
    actor_id: Mapped[str | None] = mapped_column(String(36))
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)


class GameSeed(Base):
    """Sementes "provably fair": o hash da semente do servidor é mostrado antes de jogar e a semente é revelada
    quando o cliente a troca, para poder verificar todos os resultados anteriores."""

    __tablename__ = "game_seeds"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    server_seed_enc: Mapped[str] = mapped_column(Text)
    server_seed_hash: Mapped[str] = mapped_column(String(64))
    client_seed: Mapped[str] = mapped_column(String(64))
    nonce: Mapped[int] = mapped_column(Integer, default=0)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)
    revealed_at: Mapped[datetime | None] = mapped_column(UTCDateTime())


class GameRound(Base):
    __tablename__ = "game_rounds"
    __table_args__ = (Index("ix_game_rounds_user_created", "user_id", "created_at"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    game: Mapped[str] = mapped_column(String(16))  # roulette | blackjack
    status: Mapped[str] = mapped_column(String(16), default="active")  # active | settled
    wager_cents: Mapped[int] = mapped_column(Integer, default=0)  # total apostado (inclui dobrar/dividir/seguro)
    payout_cents: Mapped[int] = mapped_column(Integer, default=0)  # total devolvido à carteira
    seed_id: Mapped[int | None] = mapped_column(Integer)
    nonce: Mapped[int | None] = mapped_column(Integer)
    state: Mapped[dict | None] = mapped_column(JSONType)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)
    settled_at: Mapped[datetime | None] = mapped_column(UTCDateTime())


# Tabelas dos assistentes de IA (registadas no mesmo metadata para as migrações e os testes).
from .assistant.models import (  # noqa: F401
    AssistantConversation,
    AssistantInstruction,
    AssistantMessage,
    ChannelIdentity,
    KnowledgeItem,
    PendingAction,
)
