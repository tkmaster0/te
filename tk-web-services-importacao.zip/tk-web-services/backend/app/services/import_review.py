"""Importação com revisão (Admin → Migração): a GoCardless manda, o users.db completa, o admin confirma.

1. **Ler** — o portal lê da GoCardless *todos* os clientes, mandatos, subscrições (incluindo as canceladas à mão) e
   os últimos pagamentos, e cruza com o `users.db` do site antigo (se foi carregado) e com o que já existe no portal.
2. **Rever** — fica uma linha por cliente com uma proposta (conta a criar ou a ligar, mandato, plano, preço, próxima
   cobrança, manter na GoCardless ou passar já para o portal) e avisos para verificar (email diferente, mandato
   cancelado, subscrição cancelada na GoCardless mas "Ativa" no site antigo, último pagamento falhado…). Tudo é
   editável, linha a linha.
3. **Importar** — só as linhas escolhidas. Antes de cada uma a GoCardless é lida outra vez: se algo mudou desde a
   leitura (ex.: subscrição cancelada entretanto), a linha fica com erro em vez de importar dados velhos.
   "Simular" mostra o que seria feito sem gravar nada nem tocar na GoCardless.
"""
from __future__ import annotations

import copy
import logging
import re
import secrets
import uuid
from datetime import UTC, date, datetime, timedelta
from typing import Any

from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from ..db import utcnow
from ..integrations.gocardless import GoCardlessClient, GoCardlessError
from ..models import ConfigEntry, Grant, ImportRow, Plan, ServiceAccount, Subscription, User
from ..security import USERNAME_RE, decrypt, encrypt, hash_password
from .audit import audit
from .jobs import enqueue, job_handler
from .legacy import MIGRATABLE, _match_plan, migrate_gocardless_subscription
from .legacy_import import LEGACY_STATUS, read_rows
from .subscriptions import fmt_money

log = logging.getLogger("tkportal.import_review")

STATE_KEY = "_import_review"
LEGACY_KEY = "_import_legacy_rows"
MANDATE_OK = {"active", "pending_submission", "submitted", "pending_customer_approval"}
MANDATE_RANK = {"active": 0, "submitted": 1, "pending_submission": 2, "pending_customer_approval": 3}
LEGACY_FIELDS = ("id", "username", "email", "subscription_status", "subscription_end_date", "plan",
                 "jellyfin_user_id", "iptvusername", "iptvhost", "invited_by", "gocardless_customer_id",
                 "gocardless_mandate_id", "created_at", "phone", "name")
# O hash da password e a password IPTV do site antigo só existem cifrados (nunca saem pela API).
SECRET_FIELDS = {"password": "password_enc", "iptvpwd": "iptvpwd_enc"}


# Estados da GoCardless em português (para os avisos)
GC_PT = {"active": "ativa", "paused": "pausada", "cancelled": "cancelada", "finished": "terminada",
         "pending_customer_approval": "à espera do cliente", "customer_approval_denied": "recusada",
         "customer_approval_granted": "aprovada", "failed": "falhou", "charged_back": "estornado",
         "pending_submission": "a submeter", "submitted": "submetido", "expired": "expirado",
         "consumed": "substituído", "blocked": "bloqueado", "suspended_by_payer": "suspenso pelo cliente",
         "paid_out": "pago", "confirmed": "confirmado"}
UNIT_PT = {"monthly": "/mês", "yearly": "/ano", "weekly": "/semana"}


def _pt(status: str | None) -> str:
    return GC_PT.get(status or "", status or "?")


def _dpt(value: str | None) -> str:
    """2026-12-01 → 01/12/2026"""
    return "/".join(reversed(value[:10].split("-"))) if value else "?"


class ReviewError(ValueError):
    pass


# ------------------------------------------------------------------------------------------------- estado
async def _cfg(db: AsyncSession, key: str):
    row = await db.get(ConfigEntry, key)
    return row.value if row else None


async def _set_cfg(db: AsyncSession, key: str, value) -> None:
    row = await db.get(ConfigEntry, key)
    if row is None:
        db.add(ConfigEntry(key=key, value=value, secret=False))
    else:
        row.value = value


async def state(db: AsyncSession) -> dict:
    st = await _cfg(db, STATE_KEY) or {"status": "idle"}
    legacy = await _cfg(db, LEGACY_KEY) or {}
    return {**st, "legacy": {"count": len(legacy.get("rows") or []), "name": legacy.get("name"),
                             "loaded_at": legacy.get("loaded_at")}}


async def store_legacy(db: AsyncSession, path: str, name: str | None) -> int:
    """Guarda as linhas do users.db para a próxima leitura (substitui um ficheiro anterior)."""
    rows, cols = read_rows(path)
    out = []
    for r in rows:
        item = {k: r[k] for k in LEGACY_FIELDS if k in cols}
        for col, key in SECRET_FIELDS.items():
            if col in cols and r[col]:
                item[key] = encrypt(str(r[col]))
        out.append(item)
    await _set_cfg(db, LEGACY_KEY, {"rows": out, "name": name, "loaded_at": utcnow().isoformat()})
    return len(out)


async def forget_legacy(db: AsyncSession) -> None:
    row = await db.get(ConfigEntry, LEGACY_KEY)
    if row is not None:
        await db.delete(row)


async def start_scan(db: AsyncSession, actor_id: str | None) -> dict:
    s = get_settings()
    legacy = await _cfg(db, LEGACY_KEY) or {}
    if not s.gocardless_enabled and not legacy.get("rows"):
        raise ReviewError("Configura a GoCardless (Definições → GoCardless) ou carrega o users.db do site antigo.")
    st = await _cfg(db, STATE_KEY) or {}
    started = st.get("started_at")
    stuck = bool(started) and datetime.fromisoformat(started) < utcnow() - timedelta(minutes=20)
    if st.get("status") == "running" and not stuck:
        return await state(db)
    batch = uuid.uuid4().hex
    await _set_cfg(db, STATE_KEY, {"status": "running", "batch": st.get("batch"), "next_batch": batch,
                                   "started_at": utcnow().isoformat(), "by": actor_id})
    await enqueue(db, "import_scan", {"batch": batch}, dedupe_key="import_scan", max_attempts=1)
    await db.commit()
    return await state(db)


@job_handler("import_scan")
async def _scan_job(db: AsyncSession, payload: dict) -> None:
    batch = payload["batch"]
    try:
        counts = await scan(db, batch)
        st = await _cfg(db, STATE_KEY) or {}
        await _set_cfg(db, STATE_KEY, {"status": "done", "batch": batch, "started_at": st.get("started_at"),
                                       "finished_at": utcnow().isoformat(), "counts": counts})
        await db.commit()
    except Exception as exc:  # noqa: BLE001 — o erro fica visível no painel
        log.exception("Leitura para a importação falhou")
        await db.rollback()
        st = await _cfg(db, STATE_KEY) or {}
        await _set_cfg(db, STATE_KEY, {**st, "status": "error", "error": str(exc)[:500],
                                       "finished_at": utcnow().isoformat()})
        await db.commit()


# ---------------------------------------------------------------------------------------------- leitura
def _day(value: str | None) -> str | None:
    return value[:10] if value else None


def _mandate_view(m: dict, bank: dict | None = None) -> dict:
    return {"id": m.get("id"), "status": m.get("status"), "scheme": m.get("scheme"),
            "reference": m.get("reference"), "created_at": _day(m.get("created_at")),
            "next_possible_charge_date": m.get("next_possible_charge_date"),
            "bank": (bank or {}).get("bank_name"), "account_ending": (bank or {}).get("account_number_ending")}


def _sub_view(sub: dict, payments: list[dict]) -> dict:
    upcoming = [p.get("charge_date") for p in (sub.get("upcoming_payments") or []) if p.get("charge_date")]
    return {"id": sub.get("id"), "status": sub.get("status"), "name": sub.get("name"),
            "amount": sub.get("amount"), "currency": sub.get("currency") or "EUR",
            "interval_unit": sub.get("interval_unit"), "interval": sub.get("interval") or 1,
            "day_of_month": sub.get("day_of_month"), "start_date": sub.get("start_date"),
            "end_date": sub.get("end_date"), "created_at": _day(sub.get("created_at")),
            "mandate": (sub.get("links") or {}).get("mandate"), "metadata": sub.get("metadata") or {},
            "upcoming": upcoming[:4],
            "payments": [{"id": p.get("id"), "status": p.get("status"), "amount": p.get("amount"),
                          "charge_date": p.get("charge_date"), "description": p.get("description")}
                         for p in sorted(payments, key=lambda p: p.get("charge_date") or "", reverse=True)[:6]]}


def _flag(level: str, code: str, text: str) -> dict:
    return {"level": level, "code": code, "text": text}


async def _username_for(db: AsyncSession, wanted: str | None, email: str, taken: set[str]) -> str:
    base = (wanted or "").strip().lower()
    if not base:
        base = re.sub(r"[^a-z0-9_.-]", "", email.split("@")[0].lower())[:24] or "cliente"
        if len(base) < 3:
            base = f"{base}cli"
    name, n = base, 1
    while name in taken or await db.scalar(select(User.id).where(User.username == name)):
        n += 1
        name = f"{base}{n}"
    taken.add(name)
    return name


async def scan(db: AsyncSession, batch: str) -> dict:
    """Lê a GoCardless + users.db e cria as linhas de revisão do lote `batch` (substitui o lote anterior)."""
    s = get_settings()
    legacy_rows: list[dict] = list((await _cfg(db, LEGACY_KEY) or {}).get("rows") or [])
    customers: list[dict] = []
    mandates: list[dict] = []
    subs: list[dict] = []
    payments_by_sub: dict[str, list[dict]] = {}
    banks: dict[str, dict] = {}
    if s.gocardless_enabled:
        gc = GoCardlessClient()
        customers = await gc.list_all_customers()
        mandates = await gc.list_all_mandates()
        subs = await gc.list_all_subscriptions(statuses=None)
        for sub in subs:
            try:
                payments_by_sub[sub["id"]] = await gc.list_payments(subscription_id=sub["id"], limit=10)
            except GoCardlessError:
                payments_by_sub[sub["id"]] = []
        for m in mandates:
            ba = (m.get("links") or {}).get("customer_bank_account")
            if ba and ba not in banks:
                try:
                    banks[ba] = await gc.get_bank_account(ba)
                except GoCardlessError:
                    banks[ba] = {}
    m_by_cust: dict[str, list[dict]] = {}
    for m in mandates:
        m_by_cust.setdefault((m.get("links") or {}).get("customer") or "", []).append(m)
    cust_of_mandate = {m["id"]: (m.get("links") or {}).get("customer") for m in mandates}
    s_by_cust: dict[str, list[dict]] = {}
    for sub in subs:
        cid = cust_of_mandate.get((sub.get("links") or {}).get("mandate") or "")
        if cid:
            s_by_cust.setdefault(cid, []).append(sub)
    emails_seen: dict[str, int] = {}
    for c in customers:
        e = (c.get("email") or "").strip().lower()
        if e:
            emails_seen[e] = emails_seen.get(e, 0) + 1

    # Índices do users.db
    leg_by_cust = {str(r["gocardless_customer_id"]): r for r in legacy_rows if r.get("gocardless_customer_id")}
    leg_by_mandate = {str(r["gocardless_mandate_id"]): r for r in legacy_rows if r.get("gocardless_mandate_id")}
    leg_by_email = {str(r.get("email") or "").strip().lower(): r for r in legacy_rows if r.get("email")}

    # Edições ainda não importadas do lote anterior continuam válidas
    previous = {r.key: r for r in (await db.scalars(select(ImportRow).where(
        ImportRow.batch != batch, ImportRow.edited.is_(True), ImportRow.status == "pending"))).all()}

    plans = (await db.scalars(select(Plan))).all()
    plans_by_id = {p.id: p for p in plans}
    taken: set[str] = set()
    used_legacy: set[Any] = set()
    out_rows: list[ImportRow] = []

    for c in sorted(customers, key=lambda x: x.get("created_at") or ""):
        cms = m_by_cust.get(c["id"], [])
        css = s_by_cust.get(c["id"], [])
        leg = leg_by_cust.get(c["id"]) or next((leg_by_mandate[m["id"]] for m in cms if m["id"] in leg_by_mandate),
                                                None) or leg_by_email.get((c.get("email") or "").strip().lower())
        if not cms and not css and leg is None:
            continue
        if leg is not None:
            used_legacy.add(leg.get("id"))
        out_rows.append(await _build_row(db, batch, c, cms, css, payments_by_sub, banks, leg, plans_by_id, taken,
                                         emails_seen, legacy_loaded=bool(legacy_rows)))
    for leg in legacy_rows:
        if leg.get("id") in used_legacy:
            continue
        out_rows.append(await _build_row(db, batch, None, [], [], payments_by_sub, banks, leg, plans_by_id, taken,
                                         emails_seen, legacy_loaded=True, gc_loaded=s.gocardless_enabled))

    for r in out_rows:
        old = previous.get(r.key)
        if old is not None:
            r.proposal = _merge_edits(r.proposal, old.proposal)
            r.edited = True
    # O lote novo substitui os anteriores (as importações feitas ficam no próprio portal e na auditoria).
    await db.execute(delete(ImportRow).where(ImportRow.batch != batch))
    db.add_all(out_rows)
    await db.flush()
    counts = {"rows": len(out_rows), "customers": len(customers), "subscriptions": len(subs),
              "legacy": len(legacy_rows),
              "with_flags": sum(1 for r in out_rows if any(f["level"] != "info" for f in r.flags)),
              "ready": sum(1 for r in out_rows if r.proposal.get("include"))}
    return counts


def _merge_edits(fresh: dict, edited: dict) -> dict:
    """Mantém as escolhas do admin, mas com a lista de subscrições lida agora (as que já não existem saem)."""
    out = {**fresh, **{k: v for k, v in edited.items() if k != "subscriptions"}}
    by_id = {s["gc_id"]: s for s in edited.get("subscriptions") or []}
    out["subscriptions"] = [{**s, **by_id.get(s["gc_id"], {})} for s in fresh.get("subscriptions") or []]
    return out


async def _build_row(db: AsyncSession, batch: str, cust: dict | None, cms: list[dict], css: list[dict],
                     payments_by_sub: dict, banks: dict, leg: dict | None, plans_by_id: dict,
                     taken: set[str], emails_seen: dict, *, legacy_loaded: bool, gc_loaded: bool = True) -> ImportRow:
    flags: list[dict] = []
    gc_email = ((cust or {}).get("email") or "").strip().lower()
    leg_email = str((leg or {}).get("email") or "").strip().lower()
    email = gc_email or leg_email
    name = " ".join(x for x in ((cust or {}).get("given_name"), (cust or {}).get("family_name")) if x) or \
        (cust or {}).get("company_name") or (leg or {}).get("name")

    # Conta no portal: pelo cliente GoCardless, pelo id antigo ou pelo email
    user = None
    if cust:
        user = await db.scalar(select(User).where(User.gocardless_customer_id == cust["id"]))
    if user is None and leg and leg.get("id") is not None:
        user = await db.scalar(select(User).where(User.legacy_id == leg["id"]))
    for e in (gc_email, leg_email):
        if user is None and e:
            user = await db.scalar(select(User).where(User.email == e))

    if gc_email and leg_email and gc_email != leg_email:
        flags.append(_flag("warn", "email_mismatch", f"Email diferente: GoCardless {gc_email} · site antigo "
                                                     f"{leg_email}. Por omissão usa o da GoCardless."))
    if gc_email and emails_seen.get(gc_email, 0) > 1:
        flags.append(_flag("warn", "duplicate_email", "Há mais do que um cliente na GoCardless com este email."))
    if cust and legacy_loaded and leg is None:
        flags.append(_flag("info", "no_legacy", "Não está no users.db — é criada uma conta nova (entra com "
                                                "\"recuperar password\")."))
    if leg is not None and not cust and gc_loaded:
        flags.append(_flag("info", "no_gocardless", "Não aparece na GoCardless — só a conta (sem subscrição)."))
    if not email:
        flags.append(_flag("error", "no_email", "Sem email — define um antes de importar."))

    # Mandatos: o melhor ativo primeiro
    mviews = [_mandate_view(m, banks.get((m.get("links") or {}).get("customer_bank_account") or ""))
              for m in sorted(cms, key=lambda m: (MANDATE_RANK.get(m.get("status") or "", 9),
                                                  -(len(m.get("created_at") or "")), m.get("created_at") or ""))]
    usable = [m for m in mviews if m["status"] in MANDATE_OK]
    if cust and not usable:
        st = ", ".join(sorted({_pt(m["status"]) for m in mviews})) or "nenhum"
        flags.append(_flag("warn", "no_mandate", f"Sem mandato ativo na GoCardless ({st}) — não é possível cobrar "
                                                 "pelo débito direto; o cliente terá de autorizar de novo."))

    leg_state = LEGACY_STATUS.get(str((leg or {}).get("subscription_status") or ""), None)
    sub_entries, sviews = [], []
    for sub in sorted(css, key=lambda x: x.get("created_at") or "", reverse=True):
        view = _sub_view(sub, payments_by_sub.get(sub["id"], []))
        sviews.append(view)
        existing = await db.scalar(select(Subscription).where(Subscription.provider_subscription_id == sub["id"]))
        if existing is not None:
            view["portal"] = {"id": existing.id, "provider": existing.provider, "status": existing.status}
        plan = await _match_plan(db, sub)
        live = sub.get("status") in MIGRATABLE
        mandate_ok = any(m["id"] == view["mandate"] and m["status"] in MANDATE_OK for m in mviews)
        last = view["payments"][0] if view["payments"] else None
        label = f"{sub.get('name') or 'Subscrição'} ({sub['id']})"
        if existing is not None:
            flags.append(_flag("info", "already_imported", f"{label}: já está no portal."))
        elif not live and leg_state in ("active", "past_due", "bonus"):
            flags.append(_flag("warn", "cancelled_in_gc", f"{label}: {_pt(sub.get('status'))} na GoCardless, mas "
                                                          f"\"{leg.get('subscription_status')}\" no site antigo."))
        if live and plan is None:
            flags.append(_flag("error", "no_plan", f"{label}: nenhum plano do portal corresponde "
                                                   f"({fmt_money(sub.get('amount') or 0)}"
                                                   f"{UNIT_PT.get(sub.get('interval_unit') or '', '')})"
                                                   " — escolhe um."))
        elif live and plan is not None and sub.get("amount") not in (None, plan.price_cents):
            flags.append(_flag("info", "price_differs", f"{label}: paga {fmt_money(sub.get('amount') or 0)} e o "
                                                        f"plano {plan.name} custa {fmt_money(plan.price_cents)} — "
                                                        "mantém o preço antigo (podes mudar)."))
        if live and not mandate_ok:
            flags.append(_flag("warn", "sub_mandate", f"{label}: o mandato desta subscrição não está ativo."))
        if live and last and last.get("status") in ("failed", "charged_back", "cancelled", "customer_approval_denied"):
            flags.append(_flag("warn", "last_payment_failed", f"{label}: o último pagamento "
                                                              f"({_dpt(last.get('charge_date'))}) {_pt(last.get('status'))}."))
        sub_entries.append({
            "gc_id": sub["id"], "include": bool(live and existing is None and plan is not None and mandate_ok),
            "plan_id": plan.id if plan else None, "price_cents": sub.get("amount"),
            "mode": "keep", "next_charge": view["upcoming"][0] if view["upcoming"] else None,
        })

    # Quem estava "A expirar" no site antigo (sem subscrição ativa na GoCardless): oferta até à data
    grant = None
    end = str((leg or {}).get("subscription_end_date") or "")[:10]
    if leg_state == "canceling" and end and not any(e["include"] for e in sub_entries):
        try:
            if date.fromisoformat(end) > utcnow().date():
                fallback = next((p for p in plans_by_id.values() if p.code == "tkflix-mensal"), None)
                grant = {"plan_id": fallback.id if fallback else None, "until": end}
                flags.append(_flag("info", "grant", f"\"A expirar\" no site antigo: mantém o acesso até {_dpt(end)} "
                                                    "(oferta)."))
        except ValueError:
            pass

    username = (user.username if user else None) or await _username_for(
        db, str((leg or {}).get("username") or "") or None, email or "cliente@x", taken)
    if leg and not user and str(leg.get("username") or "").lower() != username:
        flags.append(_flag("warn", "username_taken", f"O username antigo \"{leg.get('username')}\" já existe no "
                                                     f"portal — proposta: {username}."))
    if user is None and leg and not USERNAME_RE.match(username):
        flags.append(_flag("info", "username_rules", "Username fora das regras novas — importado na mesma (é o nome "
                                                     "no Jellyfin)."))

    proposal = {
        "include": bool(email) and (any(e["include"] for e in sub_entries) or grant is not None
                                    or (leg is not None and user is None)),
        "account": {"action": "link" if user else "create", "user_id": user.id if user else None,
                    "email": email or "", "username": username, "display_name": name or ""},
        "mandate_id": usable[0]["id"] if usable else None,
        "subscriptions": sub_entries,
        "link_jellyfin": bool((leg or {}).get("jellyfin_user_id")),
        "link_iptv": bool((leg or {}).get("iptvusername")),
        "grant": grant,
        "note": "",
    }
    source = {
        "customer": ({"id": cust.get("id"), "email": cust.get("email"), "given_name": cust.get("given_name"),
                      "family_name": cust.get("family_name"), "company_name": cust.get("company_name"),
                      "created_at": _day(cust.get("created_at")), "city": cust.get("city"),
                      "country_code": cust.get("country_code"), "phone_number": cust.get("phone_number"),
                      "metadata": cust.get("metadata") or {}} if cust else None),
        "mandates": mviews, "subscriptions": sviews, "legacy": leg,
        "portal": ({"user_id": user.id, "username": user.username, "email": user.email} if user else None),
        "default_proposal": copy.deepcopy(proposal),
    }
    key = f"gc:{cust['id']}" if cust else f"legacy:{(leg or {}).get('id')}"
    return ImportRow(batch=batch, key=key, email=email or None, source=source, proposal=proposal, flags=flags,
                     status="pending")


# ------------------------------------------------------------------------------------------------ edição
def _clean_date(v: Any) -> str | None:
    if v in (None, ""):
        return None
    try:
        return date.fromisoformat(str(v)[:10]).isoformat()
    except ValueError as exc:
        raise ReviewError(f"Data inválida: {v}") from exc


async def update_proposal(db: AsyncSession, row: ImportRow, changes: dict) -> ImportRow:
    if row.status == "imported":
        raise ReviewError("Esta linha já foi importada.")
    p = copy.deepcopy(row.proposal)  # cópia funda: o SQLAlchemy só grava o JSON se o valor mudar
    if "include" in changes:
        p["include"] = bool(changes["include"])
    if "account" in changes:
        acc = {**p.get("account", {}), **(changes["account"] or {})}
        if acc.get("action") not in ("link", "create"):
            raise ReviewError("Conta: escolhe ligar a uma existente ou criar.")
        acc["email"] = str(acc.get("email") or "").strip().lower()
        if acc["email"] and not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", acc["email"]):
            raise ReviewError("Email inválido.")
        acc["username"] = str(acc.get("username") or "").strip().lower()
        if acc["action"] == "create" and not re.match(r"^[a-z0-9][a-z0-9._@-]{1,63}$", acc["username"]):
            raise ReviewError("Username inválido (letras minúsculas, números, \".\", \"_\" ou \"-\").")
        acc["display_name"] = str(acc.get("display_name") or "")[:120]
        if acc["action"] == "link":
            uid = acc.get("user_id")
            if not uid and acc["email"]:
                found = await db.scalar(select(User).where(User.email == acc["email"]))
                uid = found.id if found else None
            if not uid or await db.get(User, uid) is None:
                raise ReviewError("Não há nenhuma conta no portal com esse email para ligar.")
            acc["user_id"] = uid
        else:
            acc["user_id"] = None
        p["account"] = acc
    if "mandate_id" in changes:
        mid = changes["mandate_id"] or None
        if mid and mid not in {m["id"] for m in row.source.get("mandates") or []}:
            raise ReviewError("Esse mandato não é deste cliente.")
        p["mandate_id"] = mid
    if "subscriptions" in changes:
        by_id = {s["gc_id"]: s for s in p.get("subscriptions") or []}
        for ch in changes["subscriptions"] or []:
            cur = by_id.get(ch.get("gc_id"))
            if cur is None:
                raise ReviewError("Subscrição desconhecida.")
            if "include" in ch:
                cur["include"] = bool(ch["include"])
            if "plan_id" in ch:
                if ch["plan_id"] and await db.get(Plan, int(ch["plan_id"])) is None:
                    raise ReviewError("Plano inexistente.")
                cur["plan_id"] = int(ch["plan_id"]) if ch["plan_id"] else None
            if "price_cents" in ch:
                price = int(ch["price_cents"])
                if not 0 <= price <= 1_000_000:
                    raise ReviewError("Preço inválido.")
                cur["price_cents"] = price
            if "mode" in ch:
                if ch["mode"] not in ("keep", "convert"):
                    raise ReviewError("Modo inválido.")
                cur["mode"] = ch["mode"]
            if "next_charge" in ch:
                cur["next_charge"] = _clean_date(ch["next_charge"])
        p["subscriptions"] = list(by_id.values())
    for k in ("link_jellyfin", "link_iptv"):
        if k in changes:
            p[k] = bool(changes[k])
    if "grant" in changes:
        g = changes["grant"]
        if g:
            if not g.get("plan_id") or await db.get(Plan, int(g["plan_id"])) is None:
                raise ReviewError("Oferta: escolhe o plano.")
            g = {"plan_id": int(g["plan_id"]), "until": _clean_date(g.get("until"))}
            if not g["until"]:
                raise ReviewError("Oferta: indica até quando.")
        p["grant"] = g or None
    if "note" in changes:
        p["note"] = str(changes["note"] or "")[:500]
    row.proposal = p
    row.edited = True
    if row.status in ("skipped", "error"):
        row.status, row.result = "pending", None
    return row


def reset_proposal(row: ImportRow) -> ImportRow:
    row.proposal = copy.deepcopy(row.source.get("default_proposal") or row.proposal)
    row.edited = False
    if row.status in ("skipped", "error"):
        row.status, row.result = "pending", None
    return row


# ---------------------------------------------------------------------------------------------- importar
def _parse_day(v: str | None) -> datetime | None:
    return datetime.combine(date.fromisoformat(v), datetime.min.time(), tzinfo=UTC) if v else None


async def apply_rows(db: AsyncSession, ids: list[int], *, dry_run: bool, actor: User) -> list[dict]:
    actor_id = actor.id  # depois de um rollback os objetos da sessão expiram — volta-se a ler o admin pelo id
    out = []
    for rid in ids:
        row = await db.get(ImportRow, rid)
        if row is None:
            continue
        if row.status == "imported":
            out.append({"id": rid, "status": "imported", "result": row.result or "já importada"})
            continue
        try:
            actor = await db.get(User, actor_id) or actor
            text = await _apply_one(db, row, dry_run=dry_run, actor=actor)
            if dry_run:
                await db.rollback()
                out.append({"id": rid, "status": "simulated", "result": text})
                continue
            row = await db.get(ImportRow, rid)
            assert row is not None
            row.status = "skipped" if text == "ignorada" else "imported"
            row.result = text
            await db.commit()
            out.append({"id": rid, "status": row.status, "result": text})
        except (ReviewError, GoCardlessError) as exc:
            await db.rollback()
            msg = str(exc)
            if not dry_run:
                row = await db.get(ImportRow, rid)
                if row is not None:
                    row.status, row.result = "error", msg[:1000]
                    await db.commit()
            out.append({"id": rid, "status": "error", "result": msg})
    if not dry_run:
        audit(db, "admin.import_review_applied", actor=await db.get(User, actor_id), rows=len(ids),
              imported=sum(1 for r in out if r["status"] == "imported"))
        await db.commit()
    return out


async def _apply_one(db: AsyncSession, row: ImportRow, *, dry_run: bool, actor: User) -> str:
    from ..payments.gocardless import GoCardlessProvider
    from .billing import save_method
    from .catalog import gated_codes, unlock
    from .subscriptions import request_reconcile

    p = row.proposal
    if not p.get("include"):
        return "ignorada"
    acc = p.get("account") or {}
    leg = row.source.get("legacy") or {}
    cust = row.source.get("customer") or {}
    email = (acc.get("email") or "").strip().lower()
    if not email:
        raise ReviewError("Sem email.")
    steps: list[str] = []

    # 1. conta
    if acc.get("action") == "link":
        user = await db.get(User, acc.get("user_id") or "")
        if user is None:
            raise ReviewError("A conta a ligar já não existe.")
        steps.append(f"ligar à conta {user.username}")
    else:
        if await db.scalar(select(User.id).where(User.email == email)):
            raise ReviewError(f"Já existe uma conta com {email} — escolhe \"ligar\".")
        username = acc.get("username") or ""
        if await db.scalar(select(User.id).where(User.username == username)):
            raise ReviewError(f"O username {username} já existe — muda-o.")
        old_hash = decrypt(leg.get("password_enc"))
        user = User(username=username, email=email, display_name=acc.get("display_name") or None,
                    password_hash=old_hash or hash_password(secrets.token_urlsafe(24)),
                    email_verified_at=utcnow(), billing_mode="legacy", jellyfin_password_login=True,
                    unlocked_products=list(await gated_codes(db)), legacy_id=leg.get("id"),
                    gocardless_customer_id=cust.get("id"), gocardless_mandate_id=p.get("mandate_id"))
        db.add(user)
        await db.flush()
        steps.append(f"criar conta {username} ({email})" + ("" if old_hash else
                                                            " — entra com \"recuperar password\""))
    if leg:
        user.legacy_id = user.legacy_id or leg.get("id")
        user.jellyfin_password_login = True
        unlock(user, list(await gated_codes(db)))
    if cust.get("id"):
        user.gocardless_customer_id = user.gocardless_customer_id or cust["id"]

    # 2. Jellyfin / IPTV do site antigo
    if p.get("link_jellyfin") and leg.get("jellyfin_user_id") and not await db.scalar(
            select(ServiceAccount.id).where(ServiceAccount.service == "jellyfin", ServiceAccount.user_id == user.id)):
        db.add(ServiceAccount(user_id=user.id, service="jellyfin",
                              external_id=str(leg["jellyfin_user_id"]).replace("-", ""),
                              external_username=leg.get("username")))
        steps.append("ligar a conta Jellyfin")
    if p.get("link_iptv") and leg.get("iptvusername") and not await db.scalar(
            select(ServiceAccount.id).where(ServiceAccount.service == "iptv", ServiceAccount.user_id == user.id)):
        db.add(ServiceAccount(user_id=user.id, service="iptv", external_username=leg["iptvusername"],
                              secret_enc=leg.get("iptvpwd_enc") or encrypt(""), data={"host": leg.get("iptvhost")}))
        steps.append("ligar a TV (IPTV)")

    # 3. mandato escolhido (confirmado já na GoCardless; fica como método por omissão no fim)
    gc = GoCardlessClient() if get_settings().gocardless_enabled else None
    mandate = None
    if p.get("mandate_id") and gc is not None:
        mandate = await gc.get_mandate(p["mandate_id"])
        if mandate.get("status") not in MANDATE_OK:
            raise ReviewError(f"O mandato {mandate['id']} está {_pt(mandate.get('status'))} na GoCardless (mudou desde a "
                              "leitura?) — escolhe outro ou volta a ler.")

    # 4. subscrições (lidas de novo na GoCardless)
    for e in p.get("subscriptions") or []:
        if not e.get("include"):
            continue
        if gc is None:
            raise ReviewError("A GoCardless não está configurada.")
        gs = await gc.get_subscription(e["gc_id"])
        if gs.get("status") not in MIGRATABLE:
            raise ReviewError(f"A subscrição {e['gc_id']} está agora \"{_pt(gs.get('status'))}\" na GoCardless (mudou "
                              "desde a leitura) — volta a ler.")
        plan = await db.get(Plan, int(e.get("plan_id") or 0))
        if plan is None:
            raise ReviewError(f"{e['gc_id']}: escolhe o plano.")
        keep = e.get("mode") != "convert"
        # Enquanto fica na GoCardless, a data da próxima cobrança é a dela (a escolhida só conta ao passar já).
        res = await migrate_gocardless_subscription(
            db, gs, dry_run=dry_run, user=user, keep=keep, plan=plan, amount_cents=e.get("price_cents"),
            next_charge=None if keep else _parse_day(e.get("next_charge")))
        steps.append(f"{plan.name} {fmt_money(e.get('price_cents') or 0)} — {res.get('result')}")

    if mandate is not None:
        if not dry_run:
            await save_method(db, user, "gocardless", await GoCardlessProvider().describe_mandate(mandate),
                              make_default=True)
            user.gocardless_mandate_id = mandate["id"]
        steps.append(f"mandato {mandate['id']} como método de pagamento")

    # 5. oferta ("A expirar" no site antigo)
    g = p.get("grant")
    if g and g.get("until"):
        until = _parse_day(g["until"])
        if until and until > utcnow() and not await db.scalar(select(Grant.id).where(
                Grant.user_id == user.id, Grant.reason.like("Migração:%"))):
            db.add(Grant(user_id=user.id, plan_id=int(g["plan_id"]), ends_at=until,
                         reason="Migração: subscrição a expirar", created_by_id=actor.id))
            steps.append(f"oferta até {_dpt(g['until'])}")

    # 6. quem convidou
    ref_name = str(leg.get("invited_by") or "").strip().lower()
    if ref_name and not user.referred_by_id:
        ref = await db.scalar(select(User).where(User.username == ref_name))
        if ref is not None and ref.id != user.id:
            user.referred_by_id = ref.id
            steps.append(f"convidado por {ref.username}")

    await db.flush()
    if not dry_run:
        await request_reconcile(db, user.id)
        audit(db, "import.row_applied", actor=actor, target_type="user", target_id=user.id, row=row.key)
    return " · ".join(steps) or "nada a fazer"


def row_out(row: ImportRow) -> dict:
    src = dict(row.source or {})
    leg = dict(src.get("legacy") or {}) if src.get("legacy") else None
    if leg is not None:
        leg["has_password"] = bool(leg.pop("password_enc", None))
        leg["has_iptv_password"] = bool(leg.pop("iptvpwd_enc", None))
    src["legacy"] = leg
    src.pop("default_proposal", None)
    return {"id": row.id, "key": row.key, "email": row.email, "status": row.status, "result": row.result,
            "edited": row.edited, "flags": row.flags, "proposal": row.proposal, "source": src,
            "updated_at": row.updated_at}
