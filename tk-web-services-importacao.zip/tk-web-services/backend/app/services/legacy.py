"""Clientes do site antigo (Flask) com subscrições GoCardless.

Por omissão (**modo "manter"**) a subscrição antiga **continua na GoCardless**, tal como estava: o cliente não nota
nada e o portal só a acompanha (acesso, data da próxima cobrança, pagamentos falhados, cancelamentos — pelos webhooks
da GoCardless e por uma verificação periódica). O mandato fica guardado como método de pagamento do cliente.

Na primeira alteração do cliente — aderir a outro serviço, mudar de plano, cancelar ou reativar — a subscrição é
**convertida sozinha** para a faturação do portal, sem pedir nada ao cliente:
  1. o período já pago termina na próxima data de cobrança da GoCardless (ou um ciclo depois, se esse pagamento já
     foi submetido ao banco e já não pode ser cancelado);
  2. a subscrição GoCardless é cancelada e a mesma subscrição passa a ser cobrada pelo portal, com o mesmo preço,
     no mesmo dia do mês e pelo mesmo mandato;
  3. a alteração pedida é feita a seguir, já com pro-rata no modelo novo.

O admin também pode converter já (um cliente ou todos) em Admin → Migração. Sem cobranças duplicadas nem falhadas;
tudo idempotente.
"""
from __future__ import annotations

import logging
from datetime import UTC, date, datetime, timedelta

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from ..db import utcnow
from ..integrations.gocardless import GoCardlessClient, GoCardlessError
from ..models import Plan, Subscription, SubStatus, User
from ..payments.gocardless import GoCardlessProvider
from .audit import audit
from .billing import BillingError, anchor_on, save_method
from .subscriptions import add_interval, request_reconcile

log = logging.getLogger("tkportal.legacy")

ALREADY_COLLECTING = {"submitted", "confirmed", "paid_out"}
MIGRATABLE = {"active", "paused", "customer_approval_granted", "pending_customer_approval"}


def _d(s: str) -> datetime:
    return datetime.combine(date.fromisoformat(s[:10]), datetime.min.time(), tzinfo=UTC)


async def _match_plan(db: AsyncSession, gc_sub: dict) -> Plan | None:
    code = (gc_sub.get("metadata") or {}).get("plan")
    if code:
        plan = await db.scalar(select(Plan).where(Plan.code == code))
        if plan:
            return plan
    unit = {"monthly": "month", "yearly": "year", "weekly": "week"}.get(gc_sub.get("interval_unit"), "month")
    name = (gc_sub.get("name") or "").strip().lower()
    plans = (await db.scalars(select(Plan).where(Plan.interval_unit == unit))).all()
    by_name = [p for p in plans if p.name.lower() == name]
    by_price = [p for p in plans if p.price_cents == gc_sub.get("amount")]
    return (by_name or by_price or [None])[0]


async def _schedule(gc: GoCardlessClient, gc_sub: dict, plan: Plan, user: User,
                    next_charge_override: datetime | None = None) -> dict:
    """Datas do período já pago a partir do calendário da subscrição GoCardless (ou da data escolhida pelo admin)."""
    upcoming = gc_sub.get("upcoming_payments") or []
    now = utcnow()
    if next_charge_override is not None:
        next_charge = next_charge_override
    elif upcoming:
        next_charge = _d(upcoming[0]["charge_date"])
    else:  # pausada / cancelada: próxima ocorrência do dia do mês da subscrição
        dom = int(gc_sub.get("day_of_month") or 0)
        if dom <= 0:  # -1 = último dia do mês na GoCardless; sem dia → dia de início
            dom = 28 if dom == -1 else int((gc_sub.get("start_date") or now.date().isoformat())[8:10])
        dom = max(1, min(dom, 28))
        next_charge = anchor_on(now.year, now.month, dom)
        if next_charge <= now:
            next_charge = add_interval(next_charge, "month", 1)
    # Pagamento da próxima data já submetido ao banco? Então esse ciclo já está pago.
    try:
        payments = await gc.list_payments(subscription_id=gc_sub["id"], limit=20)
    except GoCardlessError:
        payments = []
    collecting = [p for p in payments if p.get("status") in ALREADY_COLLECTING
                  and p.get("charge_date") and _d(p["charge_date"]) >= next_charge - timedelta(days=1)]
    collecting.sort(key=lambda p: p["charge_date"])
    period_end = next_charge
    if collecting:
        period_end = add_interval(next_charge, plan.interval_unit, plan.interval_count)
    day = min(period_end.day, 28)
    if user.billing_anchor_day and user.billing_anchor_day != day:
        day = user.billing_anchor_day  # alinha com outras subscrições do mesmo cliente
    period_end = anchor_on(period_end.year, period_end.month, day)
    period_start = add_interval(period_end, plan.interval_unit, -plan.interval_count)
    return {"next_charge": next_charge, "period_end": period_end, "period_start": period_start, "day": day,
            "payments": payments, "collecting": collecting[0] if collecting else None}


async def _resolve_user(db: AsyncSession, gc: GoCardlessClient, gc_sub: dict, user: User | None,
                        *, create: bool = False) -> tuple[User | None, dict, dict]:
    mandate = await gc.get_mandate(gc_sub["links"]["mandate"])
    customer = await gc.get_customer(mandate["links"]["customer"])
    if user is None:
        uid = (gc_sub.get("metadata") or {}).get("portal_user_id")
        user = await db.get(User, uid) if uid else None
    email = (customer.get("email") or "").strip().lower()
    if user is None and email:
        existing = await db.scalar(select(User).where(User.email == email))
        if existing is not None:
            # Só com o email confirmado: quem se registasse com o email de um cliente antigo ficava com a
            # subscrição (e o mandato) dele.
            user = existing if existing.email_verified_at else None
        elif create:
            user = await _create_user_from_customer(db, customer, mandate)
    return user, mandate, customer


async def _create_user_from_customer(db: AsyncSession, customer: dict, mandate: dict) -> User:
    """Cliente GoCardless sem conta no portal (ex.: importação direta, sem a BD do site antigo)."""
    import re
    import secrets

    from ..security import hash_password
    from .catalog import gated_codes

    email = customer["email"].strip().lower()
    base = re.sub(r"[^a-z0-9_.-]", "", email.split("@")[0].lower())[:24] or "cliente"
    if len(base) < 3:
        base = f"{base}cli"
    name, n = base, 1
    while await db.scalar(select(User.id).where(User.username == name)):
        n += 1
        name = f"{base}{n}"
    full = " ".join(x for x in (customer.get("given_name"), customer.get("family_name")) if x) or None
    user = User(username=name, email=email, display_name=full, password_hash=hash_password(secrets.token_urlsafe(24)),
                email_verified_at=utcnow(), billing_mode="legacy", jellyfin_password_login=True,
                unlocked_products=list(await gated_codes(db)), gocardless_customer_id=customer.get("id"),
                gocardless_mandate_id=mandate.get("id"))
    db.add(user)
    await db.flush()
    audit(db, "legacy.user_created", target_type="user", target_id=user.id, email=email)
    return user


async def migrate_gocardless_subscription(db: AsyncSession, gc_sub: dict, *, dry_run: bool = False,
                                          user: User | None = None, keep: bool = True,
                                          create_users: bool = False, plan: Plan | None = None,
                                          amount_cents: int | None = None,
                                          next_charge: datetime | None = None) -> dict:
    """Liga (modo "manter", por omissão) ou converte já (keep=False) uma subscrição GoCardless antiga.

    `plan`, `amount_cents` e `next_charge` vêm da importação com revisão (o que o admin confirmou ou editou);
    sem eles, o plano é adivinhado e o preço e as datas vêm da GoCardless."""
    gc = GoCardlessClient()
    out = {"gc_subscription": gc_sub["id"], "status": gc_sub.get("status")}
    if gc_sub.get("status") not in MIGRATABLE:
        return {**out, "result": "ignorada (não ativa)"}
    existing = await db.scalar(select(Subscription).where(Subscription.provider_subscription_id == gc_sub["id"]))
    if existing:
        if existing.provider == "gocardless":
            if not keep and not dry_run:
                await convert_subscription(db, existing, reason="admin")
                return {**out, "result": "convertida", "subscription_id": existing.id}
            return {**out, "result": "já ligada (continua na GoCardless)" if keep else "seria convertida",
                    "subscription_id": existing.id}
        if not dry_run:
            # Já convertida mas a subscrição antiga continua ativa na GoCardless (o cancelamento falhou da outra vez):
            # sem isto o cliente era cobrado pelos dois lados. Correr de novo repara.
            await _cancel_gc(gc, gc_sub["id"])
            return {**out, "result": "já migrada (subscrição antiga cancelada agora)", "subscription_id": existing.id}
        return {**out, "result": "já migrada", "subscription_id": existing.id}
    user, mandate, customer = await _resolve_user(db, gc, gc_sub, user, create=create_users and not dry_run)
    if user is None:
        email = customer.get("email")
        if create_users and dry_run and email:
            return {**out, "user": email, "result": "seria criada conta e ligada"}
        return {**out, "result": f"sem utilizador no portal ({email})"}
    plan = plan or await _match_plan(db, gc_sub)
    if plan is None:
        return {**out, "user": user.username,
                "result": f"sem plano correspondente ({gc_sub.get('name')} {gc_sub.get('amount')})"}

    amount = int(amount_cents) if amount_cents is not None else int(gc_sub.get("amount") or plan.price_cents)
    paused = gc_sub.get("status") == "paused"
    sched = await _schedule(gc, gc_sub, plan, user, next_charge)
    out.update({"user": user.username, "plan": plan.code, "price_cents": amount, "bonus": paused,
                "paid_until": (sched["next_charge"] if keep else sched["period_end"]).isoformat()})
    if dry_run:
        return {**out, "result": "seria ligada (continua na GoCardless)" if keep else "seria migrada"}

    pm = await save_method(db, user, "gocardless", await GoCardlessProvider().describe_mandate(mandate),
                           make_default=True)
    user.gocardless_mandate_id = user.gocardless_mandate_id or mandate["id"]
    user.gocardless_customer_id = user.gocardless_customer_id or customer.get("id")
    now = utcnow()
    if keep:
        nxt = sched["next_charge"]
        sub = Subscription(user_id=user.id, plan_id=plan.id, product_id=plan.product_id, provider="gocardless",
                           provider_subscription_id=gc_sub["id"], provider_mandate_id=mandate["id"],
                           provider_customer_id=customer.get("id"),
                           status=SubStatus.bonus if paused else SubStatus.active, price_cents=amount,
                           current_period_start=add_interval(nxt, plan.interval_unit, -plan.interval_count),
                           current_period_end=nxt, period_amount_cents=0 if paused else amount,
                           started_at=_d(gc_sub.get("start_date") or now.date().isoformat()),
                           meta={"legacy": True, "migrated_from": "gocardless", "bonus": paused})
        db.add(sub)
        await db.flush()
        await _import_payments(db, user, sub, pm, sched["payments"], None, next_charge=nxt, period_end=nxt)
        audit(db, "legacy.linked", target_type="subscription", target_id=sub.id, gc_subscription=gc_sub["id"],
              payment_method=pm.label, next_charge=nxt.isoformat())
        await request_reconcile(db, user.id)
        return {**out, "result": "ligada (continua na GoCardless)", "subscription_id": sub.id}

    period_end = sched["period_end"]
    sub = Subscription(user_id=user.id, plan_id=plan.id, product_id=plan.product_id, provider="portal",
                       provider_subscription_id=gc_sub["id"], provider_mandate_id=mandate["id"],
                       status=SubStatus.bonus if paused else SubStatus.active, price_cents=amount,
                       current_period_start=sched["period_start"], current_period_end=period_end,
                       period_amount_cents=0 if paused else amount, started_at=_d(gc_sub.get("start_date") or
                                                                                  now.date().isoformat()),
                       meta={"migrated_from": "gocardless", "bonus": paused})
    db.add(sub)
    user.billing_anchor_day = sched["day"]
    if not user.next_billing_at or user.next_billing_at > period_end:
        user.next_billing_at = period_end
    await db.flush()
    await _import_payments(db, user, sub, pm, sched["payments"], sched["collecting"],
                           next_charge=sched["next_charge"], period_end=period_end)
    # Cancelar só depois de tudo gravado na sessão; se falhar, quem chama faz rollback e a GoCardless continua a
    # cobrar (nada se perde — corre de novo).
    await _cancel_gc(gc, gc_sub["id"])
    audit(db, "legacy.migrated", target_type="subscription", target_id=sub.id, gc_subscription=gc_sub["id"],
          payment_method=pm.label, paid_until=period_end.isoformat())
    await request_reconcile(db, user.id)
    return {**out, "result": "migrada", "subscription_id": sub.id}


# =========================================================================== conversão automática
async def legacy_subs(db: AsyncSession, user_id: str) -> list[Subscription]:
    from ..models import LIVE_STATUSES

    return list((await db.scalars(select(Subscription).where(
        Subscription.user_id == user_id, Subscription.provider == "gocardless",
        Subscription.status.in_([st.value for st in LIVE_STATUSES | {SubStatus.canceling}])))).all())


async def convert_subscription(db: AsyncSession, sub: Subscription, *, reason: str) -> None:
    """Passa uma subscrição antiga (cobrada pela GoCardless) para a faturação do portal — sem ação do cliente."""
    if sub.provider != "gocardless" or not sub.provider_subscription_id:
        return
    if not get_settings().gocardless_enabled:
        raise BillingError("A GoCardless não está configurada no portal — não é possível ajustar a subscrição antiga.")
    gc = GoCardlessClient()
    user = await db.get(User, sub.user_id)
    plan = await db.get(Plan, sub.plan_id)
    assert user is not None and plan is not None
    try:
        gc_sub = await gc.get_subscription(sub.provider_subscription_id)
    except GoCardlessError as e:
        raise BillingError("A GoCardless não respondeu — tenta outra vez daqui a pouco.") from e
    sched = await _schedule(gc, gc_sub, plan, user)
    period_end = sched["period_end"]
    if gc_sub.get("status") in ("cancelled", "finished"):
        # Já não cobra: o período pago acaba na data guardada.
        period_end = sub.access_until or sub.current_period_end or period_end
    pm = None
    if sub.provider_mandate_id:
        from ..models import PaymentMethod

        pm = await db.scalar(select(PaymentMethod).where(PaymentMethod.provider == "gocardless",
                                                         PaymentMethod.provider_ref == sub.provider_mandate_id))
    try:
        await _cancel_gc(gc, sub.provider_subscription_id)
    except GoCardlessError as e:
        raise BillingError("Não foi possível ajustar a subscrição antiga na GoCardless — tenta outra vez daqui a "
                           "pouco.") from e
    was_past_due = sub.status == SubStatus.past_due
    sub.provider = "portal"
    sub.current_period_end = period_end
    sub.current_period_start = add_interval(period_end, plan.interval_unit, -plan.interval_count)
    sub.meta = {**(sub.meta or {}), "legacy": False, "converted_at": utcnow().isoformat(), "converted_by": reason}
    if sub.status == SubStatus.canceling:
        sub.access_until = sub.access_until or period_end
    user.billing_anchor_day = user.billing_anchor_day or sched["day"]
    if sub.status != SubStatus.canceling and (not user.next_billing_at or user.next_billing_at > period_end):
        user.next_billing_at = period_end
    if pm is not None:
        await _import_payments(db, user, sub, pm, sched["payments"], sched["collecting"],
                               next_charge=sched["next_charge"], period_end=period_end)
    await db.flush()
    if was_past_due:
        await _charge_overdue(db, user, sub, plan)
    audit(db, "legacy.converted", target_type="subscription", target_id=sub.id, reason=reason,
          gc_subscription=sub.provider_subscription_id, paid_until=period_end.isoformat())


async def _charge_overdue(db: AsyncSession, user: User, sub: Subscription, plan: Plan) -> None:
    """Pagamento GoCardless antigo falhado: passa a dívida para o portal, que tenta cobrar já pelo mandato."""
    from ..models import InvoiceLine
    from .billing import _finalize, charge_or_defer

    now = utcnow()
    amount = int(sub.price_cents or plan.price_cents)
    line = InvoiceLine(user_id=user.id, subscription_id=sub.id, product_id=sub.product_id, kind="renewal",
                       amount_cents=amount, period_start=sub.current_period_start, period_end=sub.current_period_end,
                       description=f"{plan.name} · mensalidade em atraso (sistema antigo)")
    inv = await _finalize(db, user, [line], kind="immediate", now=now)
    if inv and inv.status == "open":
        await db.flush()
        await charge_or_defer(db, inv, now=now, notify=False)


async def convert_user(db: AsyncSession, user: User, *, reason: str) -> int:
    """Converte todas as subscrições antigas do cliente. Chamado antes de qualquer alteração (adesão, mudança de
    plano, cancelamento, reativação) — o cliente não tem de fazer nada."""
    n = 0
    for sub in await legacy_subs(db, user.id):
        await convert_subscription(db, sub, reason=reason)
        n += 1
    return n


async def legacy_anchor(db: AsyncSession, user: User) -> datetime | None:
    """Próxima cobrança das subscrições antigas — base do pro-rata nas pré-visualizações antes da conversão."""
    dates = [s.current_period_end for s in await legacy_subs(db, user.id)
             if s.current_period_end and s.status != SubStatus.canceling]
    return min(dates) if dates else None


# =========================================================================== acompanhamento (modo "manter")
async def on_payment_event(db: AsyncSession, sub: Subscription, payment_id: str, action: str, details: dict) -> str:
    """Pagamento criado pela própria subscrição GoCardless antiga (webhook)."""
    from ..models import Payment
    from ..payments.gocardless import map_payment_status
    from .subscriptions import set_status

    gc = GoCardlessClient()
    p = await gc.get_payment(payment_id)
    status = map_payment_status(p.get("status"))
    pay = await db.scalar(select(Payment).where(Payment.provider == "gocardless",
                                                Payment.provider_payment_id == payment_id))
    if pay is None:
        pay = Payment(user_id=sub.user_id, subscription_id=sub.id, provider="gocardless",
                      provider_payment_id=payment_id, amount_cents=int(p.get("amount") or sub.price_cents or 0),
                      currency=p.get("currency") or "EUR", description="Pagamento GoCardless (subscrição antiga)",
                      charge_date=_d(p["charge_date"]) if p.get("charge_date") else None)
        db.add(pay)
    pay.status = {"succeeded": "paid", "failed": "failed"}.get(status, "pending")
    if action in ("charged_back", "late_failure_settled", "chargeback_settled"):
        pay.status = "failed"
        status = "failed"
    if status == "succeeded":
        if sub.status in (SubStatus.past_due, SubStatus.suspended):
            await set_status(db, sub, SubStatus.active, reason="pagamento GoCardless (antigo) recebido")
        await sync_subscription(db, sub)
        return "legacy payment ok"
    if status == "failed":
        if action == "failed" and details.get("will_attempt_retry"):
            return "legacy payment failed -> retry da GoCardless"
        if sub.status in (SubStatus.active, SubStatus.bonus):
            await set_status(db, sub, SubStatus.past_due, reason="pagamento GoCardless (antigo) falhado")
        return "legacy payment failed"
    return "legacy payment pending"


async def on_subscription_event(db: AsyncSession, sub: Subscription, action: str) -> str:
    from .subscriptions import set_status

    if action in ("cancelled", "finished") and sub.status not in (SubStatus.canceling, SubStatus.ended):
        until = sub.current_period_end or utcnow()
        if sub.status == SubStatus.past_due:
            until = min(until, sub.grace_until or utcnow())
        await set_status(db, sub, SubStatus.canceling, reason=f"subscrição GoCardless {action}", access_until=until,
                         cancel_at_period_end=True)
        return f"legacy subscription {action}"
    if action == "paused" and sub.status == SubStatus.active:
        await set_status(db, sub, SubStatus.bonus, reason="subscrição GoCardless pausada")
    elif action == "resumed" and sub.status == SubStatus.bonus:
        await set_status(db, sub, SubStatus.active, reason="subscrição GoCardless retomada")
    await sync_subscription(db, sub)
    return f"legacy subscription {action}"


async def sync_subscription(db: AsyncSession, sub: Subscription) -> None:
    """Atualiza a próxima data de cobrança a partir da GoCardless (para mostrar ao cliente e para a conversão)."""
    if sub.provider != "gocardless" or not sub.provider_subscription_id:
        return
    try:
        gc_sub = await GoCardlessClient(timeout=10).get_subscription(sub.provider_subscription_id)
    except GoCardlessError:
        return
    plan = await db.get(Plan, sub.plan_id)
    upcoming = gc_sub.get("upcoming_payments") or []
    if upcoming and plan:
        nxt = _d(upcoming[0]["charge_date"])
        sub.current_period_end = nxt
        sub.current_period_start = add_interval(nxt, plan.interval_unit, -plan.interval_count)
    if gc_sub.get("status") in ("cancelled", "finished") and sub.status not in (SubStatus.canceling, SubStatus.ended):
        await on_subscription_event(db, sub, gc_sub["status"])


async def sync_all(db: AsyncSession) -> int:
    if not get_settings().gocardless_enabled:
        return 0
    n = 0
    for sub in (await db.scalars(select(Subscription).where(
            Subscription.provider == "gocardless",
            Subscription.status.in_([SubStatus.active.value, SubStatus.bonus.value, SubStatus.past_due.value])))).all():
        await sync_subscription(db, sub)
        n += 1
    await db.commit()
    return n


async def _cancel_gc(gc: GoCardlessClient, sub_id: str) -> None:
    try:
        await gc.cancel_subscription(sub_id)
    except GoCardlessError as e:
        if e.status not in (409, 422):  # já cancelada / terminada
            raise


async def _import_payments(db: AsyncSession, user: User, sub: Subscription, pm, payments: list[dict],
                           collecting: dict | None, *, next_charge: datetime, period_end: datetime) -> None:
    """Histórico: os pagamentos já cobrados pela GoCardless ficam registados no portal.

    Conta para "já pagou pelo menos uma vez" (bónus de quem convidou) e para o histórico do cliente. Um
    pagamento ainda a ser cobrado (submetido) que estendeu o período fica como cobrança "processing": se o banco
    o devolver, segue o fluxo normal de falha (novas tentativas, tolerância) em vez de dar um mês grátis.
    """
    from ..models import Invoice, InvoiceLine, Payment
    from .billing import next_number

    for p in payments:
        if p.get("status") not in ALREADY_COLLECTING or not p.get("id"):
            continue
        amount = int(p.get("amount") or sub.price_cents or 0)
        pay = await db.scalar(select(Payment).where(Payment.provider == "gocardless",
                                                    Payment.provider_payment_id == p["id"]))
        if pay is None:
            pay = Payment(user_id=user.id, subscription_id=sub.id, provider="gocardless", provider_payment_id=p["id"],
                          payment_method_id=pm.id, amount_cents=amount, currency=p.get("currency") or "EUR",
                          status="pending" if p.get("status") == "submitted" else "paid",
                          description="Pagamento GoCardless (sistema antigo)",
                          charge_date=_d(p["charge_date"]) if p.get("charge_date") else None)
            db.add(pay)
        elif pay.invoice_id is not None:
            continue
        if collecting is not None and p["id"] == collecting["id"] and p.get("status") == "submitted":
            now = utcnow()
            inv = Invoice(user_id=user.id, number=await next_number(db, now.year), kind="manual", status="processing",
                          subtotal_cents=amount, total_cents=amount, period_start=next_charge, attempt_count=1,
                          payment_method_id=pm.id, created_at=now,
                          note="Pagamento da GoCardless (sistema antigo) em curso")
            db.add(inv)
            await db.flush()
            db.add(InvoiceLine(user_id=user.id, invoice_id=inv.id, subscription_id=sub.id, product_id=sub.product_id,
                               kind="renewal", amount_cents=amount, period_start=next_charge, period_end=period_end,
                               description=f"Pagamento em curso na GoCardless · {next_charge:%d/%m/%Y}"))
            pay.invoice_id = inv.id
    await db.flush()


async def migrate_all(db: AsyncSession, *, dry_run: bool = False, keep: bool = True) -> list[dict]:
    """Percorre os clientes com dados GoCardless e liga (ou converte, keep=False) as subscrições antigas."""
    if not get_settings().gocardless_enabled:
        return [{"result": "GoCardless não configurada"}]
    gc = GoCardlessClient()
    users = (await db.scalars(select(User).where(
        (User.gocardless_mandate_id.is_not(None)) | (User.gocardless_customer_id.is_not(None))))).all()
    results = []
    seen: set[str] = set()
    for u in users:
        uid, username = u.id, u.username  # um rollback mais abaixo expira o objeto
        try:
            subs = []
            if u.gocardless_mandate_id:
                subs = await gc.list_subscriptions(mandate_id=u.gocardless_mandate_id)
            if not subs and u.gocardless_customer_id:
                subs = await gc.list_subscriptions(customer_id=u.gocardless_customer_id)
        except GoCardlessError as e:
            results.append({"user": username, "result": f"erro GoCardless: {e}"})
            continue
        for gs in subs:
            if gs["id"] in seen:
                continue
            seen.add(gs["id"])
            try:
                res = await migrate_gocardless_subscription(db, gs, dry_run=dry_run, user=u, keep=keep)
                if not dry_run:
                    await db.commit()  # uma a uma: o que já foi cancelado na GoCardless fica gravado
                results.append(res)
            except (GoCardlessError, BillingError) as e:
                if not dry_run:
                    await db.rollback()
                    u = await db.get(User, uid) or u
                results.append({"user": username, "gc_subscription": gs["id"], "result": f"erro: {e}"})
    return results


async def import_from_gocardless(db: AsyncSession, *, dry_run: bool = False, keep: bool = True,
                                 create_users: bool = True) -> list[dict]:
    """Sem a BD do site antigo: lê todas as subscrições ativas da GoCardless e liga cada uma ao cliente com o mesmo
    email (criando a conta se não existir — o cliente entra por "recuperar password")."""
    if not get_settings().gocardless_enabled:
        return [{"result": "GoCardless não configurada"}]
    gc = GoCardlessClient()
    results = []
    try:
        subs = await gc.list_all_subscriptions(statuses=("active", "paused"))
    except GoCardlessError as e:
        return [{"result": f"erro GoCardless: {e}"}]
    for gs in subs:
        try:
            res = await migrate_gocardless_subscription(db, gs, dry_run=dry_run, keep=keep, create_users=create_users)
            if not dry_run:
                await db.commit()
            results.append(res)
        except (GoCardlessError, BillingError) as e:
            if not dry_run:
                await db.rollback()
            results.append({"gc_subscription": gs.get("id"), "result": f"erro: {e}"})
    return results
