"""Admin → Migração: tudo o que é preciso para trazer os clientes antigos, pela web e com o mínimo de esforço.

1. Importação com revisão (`/review…`): lê a GoCardless (a fonte de verdade) e o `users.db`, mostra uma proposta
   editável por cliente com avisos, e importa só as linhas escolhidas (ver services/import_review.py).
2. Atalhos antigos, sem revisão: carregar o `users.db` de uma vez e ligar todas as subscrições GoCardless.
3. Stripe (TKGPT), se houver.
4. Painel de estado: quem continua na GoCardless, quem já passou, e botão para converter já.
"""
from __future__ import annotations

import os
import tempfile

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from pydantic import BaseModel
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from ..config import get_settings
from ..db import get_db
from ..deps import rate_limit, require_admin
from ..models import ImportRow, Plan, Subscription, SubStatus, User
from ..services import import_review, legacy, legacy_import
from ..services.audit import audit
from ..services.billing import BillingError
from ..services.subscriptions import fmt_money

router = APIRouter(prefix="/api/admin/migration", tags=["admin-migration"], dependencies=[Depends(require_admin)])

MAX_DB_BYTES = 50 * 1024 * 1024


@router.get("/status")
async def status(db: AsyncSession = Depends(get_db)):
    s = get_settings()
    live = [st.value for st in (SubStatus.active, SubStatus.bonus, SubStatus.past_due, SubStatus.canceling)]
    rows = (await db.execute(
        select(Subscription, User.username, User.email, Plan.name)
        .join(User, User.id == Subscription.user_id).join(Plan, Plan.id == Subscription.plan_id)
        .where(Subscription.provider == "gocardless", Subscription.status.in_(live))
        .order_by(Subscription.current_period_end))).all()
    converted = await db.scalar(select(func.count()).select_from(Subscription).where(
        Subscription.provider == "portal", Subscription.meta.is_not(None),
        Subscription.provider_subscription_id.is_not(None)))
    imported = await db.scalar(select(func.count()).select_from(User).where(User.legacy_id.is_not(None)))
    with_gc = await db.scalar(select(func.count()).select_from(User).where(
        (User.gocardless_mandate_id.is_not(None)) | (User.gocardless_customer_id.is_not(None))))
    return {
        "gocardless_configured": s.gocardless_enabled,
        "stripe_configured": s.stripe_enabled,
        "imported_users": imported,
        "users_with_gocardless": with_gc,
        "converted": converted,
        "legacy": [{
            "subscription_id": sub.id, "username": uname, "email": email, "plan": pname, "status": sub.status,
            "price": fmt_money(sub.price_cents or 0), "next_charge": sub.current_period_end.isoformat()
            if sub.current_period_end else None, "gc_subscription": sub.provider_subscription_id,
        } for sub, uname, email, pname in rows],
    }


async def _read_sqlite(file: UploadFile) -> str:
    """Guarda o upload num ficheiro temporário (o chamador apaga-o) depois de confirmar que é SQLite."""
    data = await file.read(MAX_DB_BYTES + 1)
    if len(data) > MAX_DB_BYTES:
        raise HTTPException(413, detail="Ficheiro demasiado grande (máx. 50 MB).")
    if not data.startswith(b"SQLite format 3"):
        raise HTTPException(400, detail="Não é uma base de dados SQLite (o users.db do site antigo).")
    fd, path = tempfile.mkstemp(suffix=".db")
    with os.fdopen(fd, "wb") as fh:
        fh.write(data)
    return path


def _unlink(path: str) -> None:
    try:
        os.unlink(path)
    except OSError:
        pass


@router.post("/legacy-db")
async def upload_legacy_db(file: UploadFile = File(...), dry_run: bool = Form(True), keep_gocardless: bool = Form(True),
                           link_gocardless: bool = Form(True), admin: User = Depends(require_admin),
                           db: AsyncSession = Depends(get_db)):
    """Carrega o users.db do site antigo. Primeiro com dry_run (nada é gravado), depois a sério."""
    rate_limit(f"legacy-db:{admin.id}", 20, 3600)
    path = await _read_sqlite(file)
    try:
        report = await legacy_import.import_sqlite(db, path, dry_run=dry_run, link_gocardless=link_gocardless,
                                                   keep_gocardless=keep_gocardless, admin_username=admin.username)
    except legacy_import.ImportError_ as exc:
        raise HTTPException(400, detail=str(exc)) from exc
    finally:
        _unlink(path)
    if not dry_run:
        audit(db, "admin.legacy_import", actor=admin, new=report["new"], existing=report["existing"])
        await db.commit()
    report["users"] = report["users"][:500]
    return report


class GcLinkIn(BaseModel):
    dry_run: bool = True
    keep: bool = True
    create_users: bool = True


@router.post("/gocardless")
async def link_gocardless(body: GcLinkIn, admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    """Liga todas as subscrições GoCardless ativas: primeiro pelos dados do site antigo (mandato/cliente), depois
    as restantes pelo email (cria a conta se não existir)."""
    if not get_settings().gocardless_enabled:
        raise HTTPException(400, detail="Configura primeiro a GoCardless (Definições → GoCardless).")
    results = await legacy.migrate_all(db, dry_run=body.dry_run, keep=body.keep)
    seen = {r.get("gc_subscription") for r in results}
    for r in await legacy.import_from_gocardless(db, dry_run=body.dry_run, keep=body.keep,
                                                 create_users=body.create_users):
        if r.get("gc_subscription") not in seen:
            results.append(r)
    if body.dry_run:
        await db.rollback()
    else:
        audit(db, "admin.gocardless_linked", actor=admin, count=len(results), keep=body.keep)
        await db.commit()
    ok = sum(1 for r in results if str(r.get("result", "")).startswith(("ligada", "seria", "migrada", "convertida")))
    return {"dry_run": body.dry_run, "count": ok, "results": results}


class ConvertIn(BaseModel):
    subscription_id: str | None = None
    all: bool = False


@router.post("/convert")
async def convert(body: ConvertIn, admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    """Passa já subscrições antigas para a faturação do portal (normalmente acontece sozinho na 1.ª alteração)."""
    if body.subscription_id:
        subs = [await db.get(Subscription, body.subscription_id)]
    elif body.all:
        subs = list((await db.scalars(select(Subscription).where(Subscription.provider == "gocardless"))).all())
    else:
        raise HTTPException(400, detail="Indica a subscrição ou todas.")
    done, errors = 0, []
    for sub in subs:
        if sub is None or sub.provider != "gocardless":
            continue
        sid = sub.id
        try:
            await legacy.convert_subscription(db, sub, reason="admin")
            await db.commit()
            done += 1
        except BillingError as exc:
            await db.rollback()
            errors.append(f"{sid}: {exc}")
    audit(db, "admin.legacy_converted", actor=admin, count=done)
    await db.commit()
    return {"converted": done, "errors": errors,
            "message": f"{done} subscrição(ões) passaram para o portal." + (f" {len(errors)} com erro." if errors else "")}


# ------------------------------------------------------------------------------------- importação com revisão
async def _review_payload(db: AsyncSession) -> dict:
    st = await import_review.state(db)
    rows = (await db.scalars(select(ImportRow).order_by(ImportRow.id))).all()
    plans = (await db.scalars(select(Plan).options(selectinload(Plan.product))
                              .order_by(Plan.product_id, Plan.sort_order, Plan.id))).all()
    return {
        "state": st,
        "gocardless_configured": get_settings().gocardless_enabled,
        "rows": [import_review.row_out(r) for r in rows],
        "plans": [{"id": p.id, "code": p.code, "name": p.name, "product": p.product.name if p.product else None,
                   "price_cents": p.price_cents, "interval_unit": p.interval_unit,
                   "interval_count": p.interval_count, "active": p.is_active} for p in plans],
    }


@router.get("/review")
async def review(db: AsyncSession = Depends(get_db)):
    """Estado da leitura, as linhas para rever (com os dados da GoCardless e do users.db) e os planos."""
    return await _review_payload(db)


@router.post("/review/legacy")
async def review_legacy(file: UploadFile = File(...), admin: User = Depends(require_admin),
                        db: AsyncSession = Depends(get_db)):
    """Guarda o users.db para cruzar com a GoCardless na próxima leitura (não importa nada)."""
    rate_limit(f"legacy-db:{admin.id}", 20, 3600)
    path = await _read_sqlite(file)
    try:
        n = await import_review.store_legacy(db, path, file.filename)
    except legacy_import.ImportError_ as exc:
        raise HTTPException(400, detail=str(exc)) from exc
    finally:
        _unlink(path)
    audit(db, "admin.import_legacy_loaded", actor=admin, rows=n)
    await db.commit()
    return {"ok": True, "count": n,
            "message": f"users.db carregado ({n} utilizadores). Clica em \"Ler a GoCardless\" para cruzar."}


@router.delete("/review/legacy")
async def review_legacy_forget(admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    await import_review.forget_legacy(db)
    audit(db, "admin.import_legacy_removed", actor=admin)
    await db.commit()
    return {"ok": True, "message": "users.db removido do portal."}


@router.post("/review/scan")
async def review_scan(admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    """Lê outra vez a GoCardless (e o users.db carregado) em segundo plano. As edições por importar mantêm-se."""
    rate_limit(f"import-scan:{admin.id}", 30, 3600)
    try:
        return {"state": await import_review.start_scan(db, admin.id)}
    except import_review.ReviewError as exc:
        raise HTTPException(400, detail=str(exc)) from exc


async def _row(db: AsyncSession, row_id: int) -> ImportRow:
    row = await db.get(ImportRow, row_id)
    if row is None:
        raise HTTPException(404, detail="Linha não encontrada (a leitura foi refeita?).")
    return row


@router.patch("/review/rows/{row_id}")
async def review_edit(row_id: int, body: dict, db: AsyncSession = Depends(get_db)):
    """Edita a proposta de uma linha: include, account{action,user_id,email,username,display_name}, mandate_id,
    subscriptions[{gc_id,include,plan_id,price_cents,mode,next_charge}], link_jellyfin, link_iptv, grant, note."""
    row = await _row(db, row_id)
    try:
        await import_review.update_proposal(db, row, body)
    except (import_review.ReviewError, TypeError, ValueError) as exc:
        await db.rollback()
        raise HTTPException(400, detail=str(exc) or "Valor inválido.") from exc
    await db.commit()
    await db.refresh(row)
    return import_review.row_out(row)


@router.post("/review/rows/{row_id}/reset")
async def review_reset(row_id: int, db: AsyncSession = Depends(get_db)):
    """Volta à proposta calculada na leitura."""
    row = await _row(db, row_id)
    import_review.reset_proposal(row)
    await db.commit()
    await db.refresh(row)
    return import_review.row_out(row)


class ReviewSelectIn(BaseModel):
    row_ids: list[int]
    include: bool


@router.post("/review/select")
async def review_select(body: ReviewSelectIn, db: AsyncSession = Depends(get_db)):
    """Marca/desmarca várias linhas de uma vez para importar."""
    n = 0
    for rid in body.row_ids[:5000]:
        row = await db.get(ImportRow, rid)
        if row is None or row.status == "imported":
            continue
        try:
            await import_review.update_proposal(db, row, {"include": body.include})
            n += 1
        except import_review.ReviewError:
            continue
    await db.commit()
    return {"ok": True, "count": n}


class ReviewApplyIn(BaseModel):
    row_ids: list[int]
    dry_run: bool = True


@router.post("/review/apply")
async def review_apply(body: ReviewApplyIn, admin: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    """Importa (ou simula) as linhas indicadas. Cada linha relê a GoCardless antes de gravar."""
    if not body.row_ids:
        raise HTTPException(400, detail="Escolhe pelo menos uma linha.")
    rate_limit(f"import-apply:{admin.id}", 120, 3600)
    results = await import_review.apply_rows(db, body.row_ids[:2000], dry_run=body.dry_run, actor=admin)
    ok = sum(1 for r in results if r["status"] in ("imported", "simulated"))
    err = sum(1 for r in results if r["status"] == "error")
    verb = "simulada(s)" if body.dry_run else "importada(s)"
    return {"dry_run": body.dry_run, "results": results,
            "message": f"{ok} linha(s) {verb}." + (f" {err} com erro." if err else "")}
