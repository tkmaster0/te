import { useRef, useState } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { useConfig } from '../../api/queries'
import { ArrowRight, ArrowRightLeft, CheckCircle2, CreditCard, Database, FlaskConical, Import, Landmark, Link2, PiggyBank, Repeat, Upload, Users, Wallet } from 'lucide-react'
import { api, errorMessage } from '../../api/client'
import { useAction } from '../../api/mutation'
import { useAdminProducts } from '../../api/admin'
import { MigrateDialog } from '../../components/admin/MigrateDialog'
import { ImportReview } from '../../components/admin/ImportReview'
import type { AdminPlan, AdminProduct, LegacyImportOut, LegacyImportReport, LegacyImportResult, MigrationStatus } from '../../api/types'
import { Alert, Badge, Button, Card, CardHeader, Checkbox, EmptyState, Field, Modal, PageHeader, Select, SkeletonCard, Table, THead, Th, Tr, Td } from '../../components/ui'
import type { Tone } from '../../i18n/labels'
import { formatDate, formatMoney, perInterval } from '../../lib/format'

function resultTone(r: string | null | undefined): Tone {
  if (!r) return 'neutral'
  if (['migrada', 'seria migrada', 'convertido', 'seria convertido', 'convertida'].includes(r) || r.startsWith('ligada') || r.startsWith('seria ligada') || r.startsWith('seria criada'))
    return 'success'
  if (r.startsWith('já ')) return 'info'
  if (r.startsWith('erro')) return 'danger'
  return 'warning'
}

function Results({ data }: { data: LegacyImportOut }) {
  const rows = data.results
  if (!rows.length) return <EmptyState compact title="Nada encontrado" description="Não há nada para migrar." />
  return (
    <>
      <div className="hidden md:block">
        <Table>
          <THead>
            <Th>Cliente</Th>
            <Th>Plano</Th>
            <Th className="text-right">Preço</Th>
            <Th>Pago até</Th>
            <Th>Resultado</Th>
          </THead>
          <tbody>
            {rows.map((r: LegacyImportResult, i) => (
              <Tr key={i}>
                <Td className="font-medium">
                  {r.user ?? '—'}
                  {r.email && <span className="block text-xs font-normal text-muted">{r.email}</span>}
                </Td>
                <Td className="font-mono text-xs">{r.plan ?? (r.monthly_cents != null ? 'créditos mensais' : '—')}</Td>
                <Td className="text-right tabular-nums">
                  {r.price_cents != null ? formatMoney(r.price_cents) : r.monthly_cents != null ? `${formatMoney(r.monthly_cents)}/mês` : '—'}
                </Td>
                <Td>{formatDate(r.paid_until ?? null)}</Td>
                <Td>
                  <div className="flex flex-wrap items-center gap-1.5">
                    <Badge tone={resultTone(r.result)}>{r.result ?? '—'}</Badge>
                    {r.bonus === true && <Badge tone="brand">bónus</Badge>}
                  </div>
                </Td>
              </Tr>
            ))}
          </tbody>
        </Table>
      </div>
      <ul className="divide-y divide-border md:hidden">
        {rows.map((r, i) => (
          <li key={i} className="px-5 py-3.5 text-sm">
            <div className="flex items-start justify-between gap-3">
              <p className="font-semibold">{r.user ?? '—'}</p>
              <Badge tone={resultTone(r.result)}>{r.result ?? '—'}</Badge>
            </div>
            <p className="mt-0.5 text-xs text-muted">
              {r.plan ?? 'sem plano'} · {r.price_cents != null ? formatMoney(r.price_cents) : '—'} · pago até {formatDate(r.paid_until ?? null)}
            </p>
          </li>
        ))}
      </ul>
    </>
  )
}

/** Migração entre planos do mesmo produto (ex.: retirar um plano antigo). */
function PlanMigrationCard() {
  const products = useAdminProducts()
  const [fromId, setFromId] = useState<number | ''>('')
  const [open, setOpen] = useState<{ plan: AdminPlan; product: AdminProduct } | null>(null)
  if (products.isPending) return <SkeletonCard lines={2} />
  if (products.isError) return <Alert tone="danger">{errorMessage(products.error)}</Alert>
  const candidates = products.data.filter((p) => p.plans.length > 1)
  const find = (id: number) => {
    for (const p of products.data) {
      const plan = p.plans.find((pl) => pl.id === id)
      if (plan) return { plan, product: p }
    }
    return null
  }
  const sel = fromId ? find(fromId) : null
  return (
    <Card>
      <CardHeader
        icon={<ArrowRightLeft className="size-5" />}
        title="Migrar subscritores entre planos"
        description="Move todos os clientes de um plano para outro do mesmo produto — na renovação (sem acertos) ou já (com pro-rata). Simulas sempre antes de aplicar."
      />
      <div className="px-5 pb-5 pt-4 sm:px-6 sm:pb-6">
        {!candidates.length ? (
          <EmptyState compact title="Nada para migrar" description="Nenhum produto tem mais do que um plano. Cria primeiro o plano de destino em Produtos & planos." />
        ) : (
          <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
            <Field label="Plano de origem" className="min-w-0 flex-1">
              <Select value={fromId} onChange={(e) => setFromId(e.target.value ? Number(e.target.value) : '')}>
                <option value="">Escolhe um plano…</option>
                {candidates.map((p) => (
                  <optgroup key={p.id} label={p.name}>
                    {p.plans.map((pl) => (
                      <option key={pl.id} value={pl.id}>
                        {pl.name} — {formatMoney(pl.price_cents, pl.currency)}
                        {perInterval(pl.interval_unit, pl.interval_count)} · {pl.active_subscriptions}{' '}
                        {pl.active_subscriptions === 1 ? 'subscritor' : 'subscritores'}
                        {!pl.is_active ? ' (inativo)' : ''}
                      </option>
                    ))}
                  </optgroup>
                ))}
              </Select>
            </Field>
            <Button disabled={!sel} onClick={() => sel && setOpen(sel)} icon={<ArrowRight className="size-4" />} className="sm:mb-px">
              Escolher destino
            </Button>
          </div>
        )}
      </div>
      {open && <MigrateDialog plan={open.plan} product={open.product} onClose={() => setOpen(null)} />}
    </Card>
  )
}

interface ImportFlowProps {
  title: string
  endpoint: string
  steps: [typeof Import, string, string][]
  confirmTitle: (n: number) => string
  warnings: React.ReactNode[]
  unit: [string, string]
}

/** Simular → rever → executar, com confirmação explícita (GoCardless, Stripe e conversão para créditos). */
function ImportFlow({ title, endpoint, steps, confirmTitle, warnings, unit }: ImportFlowProps) {
  const [dry, setDry] = useState<LegacyImportOut | null>(null)
  const [done, setDone] = useState<LegacyImportOut | null>(null)
  const [confirmOpen, setConfirmOpen] = useState(false)
  const [understood, setUnderstood] = useState(false)
  const simulate = useAction(() => api.post<LegacyImportOut>(endpoint, { dry_run: true }), {
    success: false,
    errorTitle: 'A simulação falhou',
    onSuccess: (res) => {
      setDry(res)
      setDone(null)
    },
  })
  const migrate = useAction(() => api.post<LegacyImportOut>(endpoint, { dry_run: false }), {
    success: false,
    errorTitle: 'Falhou',
    invalidate: [['admin']],
    onSuccess: (res) => {
      setDone(res)
      setConfirmOpen(false)
      setUnderstood(false)
    },
  })
  const shown = done ?? dry
  const [one, many] = unit
  return (
    <section className="space-y-4">
      <h2 className="pt-2 text-xs font-semibold uppercase tracking-wider text-subtle">{title}</h2>
      <Card className="p-5 sm:p-6">
        <ol className="grid gap-5 text-sm md:grid-cols-3">
          {steps.map(([I, t, d], i) => (
            <li key={t} className="flex gap-3">
              <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-brand-soft text-brand-text">
                <I className="size-5" aria-hidden />
              </span>
              <span>
                <span className="block font-semibold">
                  {i + 1}. {t}
                </span>
                <span className="text-muted">{d}</span>
              </span>
            </li>
          ))}
        </ol>
        <div className="mt-6 flex flex-wrap gap-2">
          <Button variant={dry ? 'secondary' : 'primary'} loading={simulate.isPending} onClick={() => simulate.mutate()} icon={<FlaskConical className="size-4" />}>
            {dry ? 'Simular de novo' : 'Simular'}
          </Button>
          <Button disabled={!dry || !dry.count || !!done} onClick={() => setConfirmOpen(true)} icon={<ArrowRight className="size-4" />}>
            Executar agora{dry?.count ? ` (${dry.count})` : ''}
          </Button>
        </div>
        {!dry && <p className="mt-3 text-xs text-muted">Faz sempre uma simulação primeiro — o botão “Executar agora” só fica disponível depois.</p>}
      </Card>
      {simulate.isError && <Alert tone="danger">{errorMessage(simulate.error)}</Alert>}
      {shown && (
        <Card className="overflow-hidden">
          <CardHeader
            title={done ? 'Resultado' : 'Simulação'}
            description={done ? `${done.count} ${done.count === 1 ? one : many}.` : `${shown.count} ${shown.count === 1 ? one : many} (simulação — nada foi alterado).`}
            actions={done ? <Badge tone="success">Concluído</Badge> : <Badge tone="info">Simulação</Badge>}
          />
          <div className="mt-4 border-t border-border">
            <Results data={shown} />
          </div>
        </Card>
      )}
      <Modal
        open={confirmOpen}
        onClose={() => setConfirmOpen(false)}
        title={confirmTitle(dry?.count ?? 0)}
        footer={
          <>
            <Button variant="secondary" onClick={() => setConfirmOpen(false)}>
              Cancelar
            </Button>
            <Button variant="danger" disabled={!understood} loading={migrate.isPending} onClick={() => migrate.mutate()}>
              Executar agora
            </Button>
          </>
        }
      >
        <div className="space-y-4 text-sm">
          <Alert tone="warning" title="Isto não se desfaz">
            <ul className="mt-1 list-disc space-y-1 pl-4">
              {warnings.map((w, i) => (
                <li key={i}>{w}</li>
              ))}
            </ul>
          </Alert>
          <Checkbox checked={understood} onChange={(e) => setUnderstood(e.target.checked)} label="Revi a simulação e quero continuar" />
        </div>
      </Modal>
    </section>
  )
}

function StatTile({ icon: Icon, label, value }: { icon: typeof Users; label: string; value: number | string }) {
  return (
    <div className="flex items-center gap-3 rounded-2xl border border-border bg-elevated/40 p-4">
      <span className="grid size-10 place-items-center rounded-xl bg-brand-soft text-brand-text">
        <Icon className="size-5" aria-hidden />
      </span>
      <span>
        <span className="block text-xl font-extrabold tabular-nums">{value}</span>
        <span className="block text-xs text-muted">{label}</span>
      </span>
    </div>
  )
}

/** Modo rápido (sem revisão): carregar o users.db do site antigo e importar tudo de uma vez. */
function LegacyDbUpload() {
  const qc = useQueryClient()
  const { data: config } = useConfig()
  const fileRef = useRef<HTMLInputElement>(null)
  const [file, setFile] = useState<File | null>(null)
  const [link, setLink] = useState(true)
  const [report, setReport] = useState<LegacyImportReport | null>(null)
  const gcOn = !!config?.providers?.gocardless
  const run = useAction(
    (dry: boolean) => {
      const fd = new FormData()
      fd.append('file', file as File)
      fd.append('dry_run', String(dry))
      fd.append('link_gocardless', String(link && gcOn))
      fd.append('keep_gocardless', 'true')
      return api.upload<LegacyImportReport>('/api/admin/migration/legacy-db', fd)
    },
    {
      success: (r) => (r.dry_run ? undefined : `Importados: ${r.new} novos, ${r.existing} atualizados.`),
      errorTitle: 'A importação falhou',
      onSuccess: (r) => {
        setReport(r)
        if (!r.dry_run) void qc.invalidateQueries({ queryKey: ['admin'] })
      },
    },
  )
  const pick = (f: File | null | undefined) => {
    setFile(f ?? null)
    setReport(null)
  }
  return (
    <section className="space-y-4">
      <h2 className="pt-2 text-xs font-semibold uppercase tracking-wider text-subtle">Clientes do site antigo de uma vez (users.db)</h2>
      <Card className="p-5 sm:p-6">
        <div className="grid gap-5 lg:grid-cols-[1fr_auto] lg:items-end">
          <div className="space-y-3">
            <p className="text-sm text-muted">
              Carrega a base de dados do site antigo (o ficheiro <code>instance/users.db</code>). Os clientes ficam com o mesmo username, email e password, email
              confirmado, a conta Jellyfin ligada, as credenciais de TV e quem os convidou.
            </p>
            <div
              className="flex cursor-pointer flex-wrap items-center gap-3 rounded-2xl border border-dashed border-border-strong bg-bg p-4 hover:border-brand/60"
              onClick={() => fileRef.current?.click()}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault()
                pick(e.dataTransfer.files?.[0])
              }}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => e.key === 'Enter' && fileRef.current?.click()}
            >
              <span className="grid size-10 place-items-center rounded-xl bg-brand-soft text-brand-text">
                {file ? <Database className="size-5" /> : <Upload className="size-5" />}
              </span>
              <span className="min-w-0 flex-1 text-sm">
                {file ? (
                  <>
                    <b>{file.name}</b> <span className="text-muted">· {(file.size / 1024).toFixed(0)} KB</span>
                  </>
                ) : (
                  <span className="text-muted">Arrasta o users.db para aqui, ou clica para escolher</span>
                )}
              </span>
              <input ref={fileRef} type="file" accept=".db,.sqlite,.sqlite3,application/octet-stream" className="hidden" onChange={(e) => pick(e.target.files?.[0])} />
            </div>
            <Checkbox
              checked={link && gcOn}
              disabled={!gcOn}
              onChange={(e) => setLink(e.target.checked)}
              label="Ligar logo as subscrições GoCardless destes clientes"
              description={gcOn ? 'Ficam na GoCardless como estão; passam sozinhas para o portal na primeira alteração.' : 'Configura primeiro a GoCardless (Definições). Podes ligar depois.'}
            />
          </div>
          <div className="flex flex-wrap gap-2">
            <Button variant={report?.dry_run ? 'secondary' : 'primary'} disabled={!file} loading={run.isPending && run.variables === true} onClick={() => run.mutate(true)} icon={<FlaskConical className="size-4" />}>
              Simular
            </Button>
            <Button disabled={!file || !report?.dry_run} loading={run.isPending && run.variables === false} onClick={() => run.mutate(false)} icon={<Import className="size-4" />}>
              Importar agora
            </Button>
          </div>
        </div>
      </Card>
      {report && (
        <Card className="overflow-hidden">
          <CardHeader
            title={report.dry_run ? 'Simulação — nada foi gravado' : 'Importação concluída'}
            actions={report.dry_run ? <Badge tone="info">Simulação</Badge> : <Badge tone="success">Concluído</Badge>}
          />
          <div className="grid gap-3 p-5 sm:grid-cols-2 sm:p-6 lg:grid-cols-4">
            <StatTile icon={Users} label={`novos (de ${report.total})`} value={report.new} />
            <StatTile icon={CheckCircle2} label="já existiam (atualizados)" value={report.existing} />
            <StatTile icon={Link2} label="contas Jellyfin ligadas" value={report.jellyfin} />
            <StatTile icon={Repeat} label="subscrições GoCardless" value={report.subscriptions.filter((x) => x.gc_subscription).length} />
          </div>
          {report.warnings.length > 0 && (
            <div className="px-5 pb-5 sm:px-6">
              <Alert tone="warning" title={`${report.warnings.length} avisos`}>
                <ul className="mt-1 max-h-40 list-disc space-y-0.5 overflow-auto pl-4">
                  {report.warnings.map((w, i) => (
                    <li key={i}>{w}</li>
                  ))}
                </ul>
              </Alert>
            </div>
          )}
          {report.subscriptions.length > 0 && (
            <div className="border-t border-border">
              <Results data={{ dry_run: report.dry_run, count: report.subscriptions.length, results: report.subscriptions as LegacyImportResult[] }} />
            </div>
          )}
        </Card>
      )}
    </section>
  )
}

/** Passo 2: quem continua na GoCardless e quem já passou para o portal. */
function LegacyStatus() {
  const q = useQuery({ queryKey: ['admin', 'migration-status'], queryFn: () => api.get<MigrationStatus>('/api/admin/migration/status') })
  const [confirm, setConfirm] = useState(false)
  const convert = useAction((body: { subscription_id?: string; all?: boolean }) => api.post<{ message: string }>('/api/admin/migration/convert', body), {
    invalidate: [['admin', 'migration-status']],
    onSuccess: () => setConfirm(false),
  })
  const d = q.data
  return (
    <section className="space-y-4">
      <h2 className="pt-2 text-xs font-semibold uppercase tracking-wider text-subtle">2. Estado</h2>
      {q.isError && <Alert tone="danger">{errorMessage(q.error)}</Alert>}
      {!d ? (
        <SkeletonCard lines={4} />
      ) : (
        <Card className="overflow-hidden">
          <div className="grid gap-3 p-5 sm:grid-cols-3 sm:p-6">
            <StatTile icon={Users} label="clientes importados do site antigo" value={d.imported_users} />
            <StatTile icon={Landmark} label="ainda cobrados pela GoCardless" value={d.legacy.length} />
            <StatTile icon={ArrowRightLeft} label="já passaram para o portal" value={d.converted} />
          </div>
          <CardHeader
            className="pt-0 sm:pt-0"
            title="Subscrições na GoCardless"
            description="Passam sozinhas para o portal na primeira alteração do cliente. Se quiseres, podes passar já."
            actions={
              d.legacy.length > 0 && (
                <Button size="sm" variant="secondary" onClick={() => setConfirm(true)} icon={<Repeat className="size-4" />}>
                  Passar todas já
                </Button>
              )
            }
          />
          <div className="mt-4 border-t border-border">
            {d.legacy.length === 0 ? (
              <EmptyState compact title="Nenhuma" description="Não há subscrições a ser cobradas pela GoCardless antiga." />
            ) : (
              <Table>
                <THead>
                  <Th>Cliente</Th>
                  <Th>Plano</Th>
                  <Th className="text-right">Preço</Th>
                  <Th>Próxima cobrança</Th>
                  <Th>Estado</Th>
                  <Th>
                    <span className="sr-only">Ações</span>
                  </Th>
                </THead>
                <tbody>
                  {d.legacy.map((r) => (
                    <Tr key={r.subscription_id}>
                      <Td className="font-medium">
                        {r.username}
                        <span className="block text-xs font-normal text-muted">{r.email}</span>
                      </Td>
                      <Td>{r.plan}</Td>
                      <Td className="text-right tabular-nums">{r.price}</Td>
                      <Td>{formatDate(r.next_charge)}</Td>
                      <Td>
                        <Badge tone={r.status === 'past_due' ? 'warning' : 'success'}>{r.status === 'past_due' ? 'em atraso' : r.status === 'bonus' ? 'pausada' : 'ativa'}</Badge>
                      </Td>
                      <Td className="text-right">
                        <Button
                          size="sm"
                          variant="ghost"
                          loading={convert.isPending && convert.variables?.subscription_id === r.subscription_id}
                          onClick={() => convert.mutate({ subscription_id: r.subscription_id })}
                        >
                          Passar já
                        </Button>
                      </Td>
                    </Tr>
                  ))}
                </tbody>
              </Table>
            )}
          </div>
        </Card>
      )}
      <Modal
        open={confirm}
        onClose={() => setConfirm(false)}
        title={`Passar ${d?.legacy.length ?? 0} subscrições para o portal agora?`}
        footer={
          <>
            <Button variant="secondary" onClick={() => setConfirm(false)}>
              Cancelar
            </Button>
            <Button loading={convert.isPending} onClick={() => convert.mutate({ all: true })}>
              Passar todas
            </Button>
          </>
        }
      >
        <Alert tone="info">
          As subscrições são canceladas na GoCardless e passam a ser cobradas pelo portal com o mesmo mandato, preço e dia. Se o pagamento do próximo ciclo já foi
          submetido ao banco, esse ciclo conta como pago — ninguém é cobrado duas vezes.
        </Alert>
      </Modal>
    </section>
  )
}

export default function AdminMigration() {
  const { data: config } = useConfig()
  const monthly = config?.wallet?.monthly_enabled === true
  return (
    <div>
      <PageHeader
        eyebrow="Administração"
        title="Migração"
        description="Traz os clientes antigos com a GoCardless como fonte de verdade (mandatos novos, cancelamentos feitos à mão…) e o users.db do site antigo a completar. Revês e editas cliente a cliente, simulas, e importas só o que escolheres — sem os clientes fazerem nada."
      />
      <div className="space-y-8">
        <ImportReview />
        <LegacyStatus />
        <details className="group rounded-2xl border border-border p-4 [&_summary::-webkit-details-marker]:hidden">
          <summary className="cursor-pointer select-none text-sm font-semibold">
            Modo rápido, sem revisão <span className="font-normal text-muted">— importa tudo de uma vez (o modo antigo)</span>
          </summary>
          <div className="mt-4 space-y-8">
            <LegacyDbUpload />
            <ImportFlow
              title="Ligar todas as subscrições GoCardless ativas (ficam na GoCardless)"
              endpoint="/api/admin/migration/gocardless"
              unit={['subscrição ligada', 'subscrições ligadas']}
              steps={[
                [FlaskConical, 'Simula', 'Encontra todas as subscrições ativas na GoCardless e o cliente de cada uma (pelos dados do site antigo ou pelo email).'],
                [Link2, 'Liga', 'O mandato fica guardado como método do cliente e a subscrição aparece no portal — com acesso aos serviços. Clientes sem conta ganham uma.'],
                [Repeat, 'Passa sozinha', 'Continua a ser cobrada pela GoCardless até o cliente aderir, mudar ou cancelar: aí passa para o portal sem ele fazer nada.'],
              ]}
              confirmTitle={(n) => `Ligar ${n} subscrições GoCardless?`}
              warnings={[
                'Nada é cancelado na GoCardless agora — os clientes continuam a ser cobrados como até aqui.',
                'Clientes sem conta no portal ganham uma com o email da GoCardless (já confirmado); entram por “recuperar password”.',
                'Correr de novo não duplica nada.',
              ]}
            />
          </div>
        </details>
        <PlanMigrationCard />
        <ImportFlow
          title="Stripe (TKGPT) — se tiveres subscrições antigas lá"
          endpoint="/api/admin/stripe/import"
          unit={['subscrição migrada', 'subscrições migradas']}
          steps={[
            [FlaskConical, 'Simula', 'Lista as subscrições ativas no Stripe, o cliente (ou conta nova) e até quando está pago.'],
            [Import, 'Migra', 'O cartão já guardado no Stripe passa a método do cliente; o plano é criado com o mesmo preço se não existir.'],
            [CreditCard, 'O portal cobra', 'A subscrição Stripe é cancelada sem pro-rata; o portal cobra na data de renovação.'],
          ]}
          confirmTitle={(n) => `Migrar ${n} subscrições Stripe agora?`}
          warnings={[
            <>As subscrições Stripe Billing são <strong>canceladas já</strong>, sem reembolsos nem fatura final.</>,
            'Clientes sem conta no portal ganham uma (com o email do Stripe) — entram por "recuperar password" ou por SSO a partir do LibreChat.',
            'As cobranças seguintes usam o cartão guardado (fora de sessão), no mesmo dia do mês.',
          ]}
        />
        {monthly && (
        <ImportFlow
          title="Passar clientes antigos para os créditos mensais"
          endpoint="/api/admin/wallet/convert-all"
          unit={['cliente convertido', 'clientes convertidos']}
          steps={[
            [FlaskConical, 'Simula', 'Calcula o carregamento mensal de cada cliente: o que já paga por mês, arredondado ao euro.'],
            [PiggyBank, 'Converte', 'Liga o carregamento mensal com o mesmo método e no mesmo dia — sem pedir nada ao cliente.'],
            [Wallet, 'Carteira primeiro', 'Os serviços passam a ser pagos pela carteira; o que sobrar fica para os meses seguintes.'],
          ]}
          confirmTitle={(n) => `Converter ${n} clientes para créditos mensais?`}
          warnings={[
            'A cobrança mensal fica igual (ou poucos cêntimos acima, pelo arredondamento ao euro — o excedente fica na carteira do cliente).',
            'Se o saldo já cobrir um mês, esse mês não é cobrado.',
            'O cliente pode alterar ou desligar o carregamento na página Carteira.',
          ]}
        />
        )}
      </div>
    </div>
  )
}
