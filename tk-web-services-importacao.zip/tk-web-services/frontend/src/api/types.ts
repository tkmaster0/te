/** Tipos das respostas da API (ver backend/app/schemas.py e routers/*.py). */

export interface Ok {
  ok: boolean
  message?: string | null
}

export interface AccessSource {
  type: 'subscription' | 'grant' | string
  plan: string
  plan_code: string
  status?: string | null
  until?: string | null
}

export interface Me {
  id: string
  username: string
  email: string
  display_name: string | null
  email_verified: boolean
  is_admin: boolean
  totp_enabled: boolean
  created_at: string
  has_access: boolean
  features: string[]
  access: AccessSource[]
  needs_password_sync: boolean
  referred_by?: string | null
  /** "streaming" = sessão aberta a partir do Jellyfin (só pode gerir o streaming). */
  session_scope?: string | null
  billing_anchor_day?: number | null
  next_billing_at?: string | null
  /** "wallet" = conta nova (serviços pagos pela carteira); "legacy" = cliente anterior à carteira. */
  billing_mode?: 'wallet' | 'legacy' | string
  /** true = mantém o login antigo no Jellyfin (username + password). false = entra por SSO / Quick Connect. */
  jellyfin_password_login?: boolean
  unlocked_products?: string[]
  wallet_balance_cents?: number
  /** Jogos visíveis (ligados e com o TKFLIX desbloqueado). */
  games_available?: boolean
}

export interface LoginOut {
  status: 'ok' | 'mfa_required'
  redirect?: string | null
  user?: Me | null
}

export interface SiteApp {
  name: string
  platform: string
  url: string
}

export interface FaqItem {
  q: string
  a: string
}

export interface SiteSettings {
  announcement: string | null
  support_url: string | null
  support_email: string | null
  terms_url: string | null
  privacy_url: string | null
  apps: SiteApp[]
  faq: FaqItem[]
  /** Textos editados em Admin → Aparência (chave → texto). */
  texts?: Record<string, string>
  /** Imagens carregadas em Admin → Aparência (logo, favicon, hero, auth, share → URL). */
  images?: Record<string, string>
}

export interface PublicConfig {
  app_name: string
  registration_mode: 'invite' | 'open' | string
  require_email_verification: boolean
  providers: { gocardless?: boolean; stripe?: boolean }
  jellyfin_url: string | null
  seerr_url: string | null
  bonus: { enabled: boolean; threshold: number; threshold_admin_referred: number }
  site: SiteSettings
  billing?: { require_method: boolean }
  wallet?: { enabled: boolean; min_topup_cents: number; min_monthly_cents: number; monthly_bonus_percent: number; monthly_enabled?: boolean }
  games?: { enabled: boolean; min_bet_cents: number }
  sso?: { enabled: boolean; issuer: string; jellyfin_url: string | null; seerr_url: string | null; librechat_url: string | null }
}

export interface JellyfinFeature {
  enabled: boolean
  all_libraries: boolean
  libraries: string[]
  max_streams: number
  live_tv: boolean
  downloads: boolean
  remote_bitrate_mbps: number
}

export interface SeerrFeature {
  enabled: boolean
  movie_quota: number | null
  movie_quota_days: number | null
  tv_quota: number | null
  tv_quota_days: number | null
}

export interface IptvFeature {
  enabled: boolean
  stream_limit: number
  channel_profiles: number[]
}

export interface PlanFeatures {
  jellyfin: JellyfinFeature
  seerr: SeerrFeature
  iptv: IptvFeature
  groups: string[]
}

export type Provider = 'gocardless' | 'stripe'

export interface Plan {
  id: number
  code: string
  name: string
  description: string | null
  price_cents: number
  currency: string
  interval_unit: 'month' | 'year' | 'week' | string
  interval_count: number
  monthly_equivalent_cents: number
  highlights: string[]
  features: PlanFeatures
  providers: Provider[]
  product_id: number
}

export type Fulfillment = 'streaming' | 'manual' | 'webhook' | 'none'

export interface ProductBrief {
  id: number
  code: string
  name: string
  kind: string
  fulfillment: Fulfillment | string
  icon: string | null
  /** Imagem carregada em Admin → Produtos (substitui o ícone). */
  image_url?: string | null
  jellyfin_managed: boolean
  bonus_eligible: boolean
  requires_invite?: boolean
}

export interface Product extends ProductBrief {
  description: string | null
  /** Beta fechado ainda não desbloqueado: nome genérico, sem planos, com campo para o código de convite. */
  locked?: boolean
  plans: Plan[]
}

export type SubStatus = 'pending' | 'active' | 'past_due' | 'canceling' | 'bonus' | 'suspended' | 'ended'

export interface UpcomingPriceChange {
  new_price_cents: number
  effective_at: string
}

export interface Subscription {
  id: string
  plan: Plan
  product: ProductBrief
  product_name: string
  provider: string
  status: SubStatus | string
  /** Preço fixado para este cliente (pode diferir do preço atual do plano). */
  price_cents: number
  current_period_start: string | null
  current_period_end: string | null
  access_until: string | null
  grace_until: string | null
  cancel_at_period_end: boolean
  started_at: string
  ended_at: string | null
  pending_plan: string | null
  upcoming_price_change: UpcomingPriceChange | null
  fulfillment_status: string | null
  access_details: Record<string, string>
  access_instructions: string | null
  app_url?: string | null
  can_cancel: boolean
  can_resume: boolean
  can_change: boolean
  provider_subscription_id?: string | null
  period_amount_cents?: number | null
}

// --------------------------------------------------------------------------- faturação consolidada
export interface QuoteLine {
  description: string
  amount_cents: number
  kind: string
}

export interface Quote {
  kind: 'new' | 'change' | string
  lines: QuoteLine[]
  due_now_cents: number
  next_invoice_cents: number
  next_billing_at: string | null
  period_end: string | null
  recurring_cents: number
  interval_unit: string
  interval_count: number
  bonus_applies: boolean
  is_upgrade: boolean | null
  /** Descida de plano: só acontece nesta data (renovação); até lá fica o plano atual. */
  scheduled_at?: string | null
  requires_payment_method: boolean
  wallet_balance_cents?: number
  wallet_cents?: number
  charge_now_cents?: number
  wallet_only?: boolean
  monthly_enabled?: boolean
  monthly_topup_cents?: number | null
  suggested_monthly_cents?: number | null
}

export interface UpcomingLine extends QuoteLine {
  product_id: number | null
  subscription_id: string | null
}

export interface Upcoming {
  at: string | null
  lines: UpcomingLine[]
  total_cents: number
  services_cents?: number
  wallet_cents?: number
  topup_cents?: number
  topup_skipped?: boolean
}

export interface PaymentMethod {
  id: string
  provider: Provider | string
  provider_label: string
  kind: string
  label: string
  status: 'active' | 'pending' | 'unusable' | 'revoked' | string
  status_reason: string | null
  is_default: boolean
  expires_at: string | null
  created_at: string
}

export interface ProviderOption {
  name: Provider
  label: string
  provider_label: string
  available: boolean
}

export interface BillingAction {
  type: 'payment_method' | 'invoice' | 'grace' | string
  severity: 'high' | 'medium' | 'low' | string
  title: string
  message: string
  deadline: string | null
  invoice_id?: string
  subscription_id?: string
}

export interface InvoiceLine {
  description: string
  amount_cents: number
  kind: string
  period_start: string | null
  period_end: string | null
}

export interface Invoice {
  id: string
  number: string
  kind: string
  status: 'open' | 'processing' | 'paid' | 'failed' | 'void' | string
  currency: string
  subtotal_cents: number
  total_cents: number
  created_at: string
  paid_at: string | null
  attempt_count: number
  next_attempt_at: string | null
  last_error: string | null
  payment_method: string | null
  lines: InvoiceLine[]
}

export interface BillingSummary {
  anchor_day: number | null
  next_billing_at: string | null
  upcoming: Upcoming
  payment_methods: PaymentMethod[]
  default_payment_method_id: string | null
  providers: ProviderOption[]
  actions: BillingAction[]
  unpaid_invoices: Invoice[]
  bonus: BonusStatus
  wallet?: WalletSummary
  session_scope: string | null
}

export interface SubscribeOut {
  status: 'active' | 'redirect'
  subscription_id?: string | null
  checkout_id?: string | null
  redirect_url?: string | null
  message?: string | null
}

export interface ChangePlanOut {
  ok: boolean
  message: string
  quote: Quote
}

export interface RedirectOut {
  checkout_id?: string | null
  redirect_url: string
}

export interface PayInvoiceOut {
  status?: string
  message?: string
  checkout_id?: string | null
  redirect_url?: string | null
}

export interface CheckoutStatus {
  id: string
  status: 'pending' | 'completed' | 'cancelled' | 'failed' | string
  purpose: 'setup_pm' | 'pay_invoice' | string
  provider: string
  subscription_id: string | null
  invoice_id: string | null
  error: string | null
  return_to: string
}

export interface Payment {
  id: string
  provider: string
  amount_cents: number
  currency: string
  status: string
  description: string | null
  charge_date: string | null
  created_at: string
  receipt_url: string | null
}

export interface ServicesOut {
  jellyfin: {
    configured: boolean
    enabled: boolean
    url: string | null
    username: string
    linked: boolean
    needs_password_sync: boolean
    /** false = conta SSO (entra por "Entrar com TK Web Services" / Quick Connect). */
    password_login?: boolean
    max_streams: number
    live_tv: boolean
    downloads: boolean
    last_error: string | null
  }
  seerr: {
    configured: boolean
    enabled: boolean
    url: string | null
    linked: boolean
    movie_quota: number | null
    movie_quota_days: number | null
    tv_quota: number | null
    tv_quota_days: number | null
  }
  iptv: {
    enabled: boolean
    source: 'dispatcharr' | 'manual' | null
    pending?: boolean
    username?: string | null
    password?: string | null
    server?: string | null
    m3u_url?: string
    epg_url?: string
    stream_limit?: number
  }
  apps: SiteApp[]
}

export interface Device {
  id: string
  name: string | null
  app: string | null
  last_active: string | null
}

export interface NowPlaying {
  device: string | null
  client: string | null
  title: string | null
  series: string | null
  playing: boolean
  paused: boolean
  method: string | null
}

export interface Invite {
  id: number
  code: string
  uses: number
  max_uses: number
  expires_at: string | null
  disabled: boolean
  note: string | null
  created_at: string
  link: string
}

export interface Invitee {
  username: string
  joined: string
  status: string | null
  status_label: string
  counts_for_bonus: boolean
}

export interface BonusStatus {
  active_invitees: number
  threshold: number
  eligible: boolean
  enabled: boolean
}

export interface InvitesOut {
  codes: Invite[]
  invitees: Invitee[]
  bonus: BonusStatus
  can_create: boolean
  reason: string | null
  limit: number
}

export interface SessionInfo {
  id: string
  created_at: string
  last_seen_at: string
  ip: string | null
  user_agent: string | null
  current: boolean
}

export interface Activity {
  created_at: string
  action: string
  ip: string | null
  details: Record<string, unknown> | null
}

export interface TotpSetup {
  secret: string
  otpauth_uri: string
  qr_svg: string
}

// --------------------------------------------------------------------------- admin
export interface AdminStats {
  users: number
  new_users_30d: number
  mrr_cents: number
  revenue_30d_cents: number
  failed_payments_30d: number
  by_plan: Record<string, number>
  by_provider: Record<string, number>
  by_status: Record<string, number>
  active_grants: number
  jobs: Record<string, number>
  webhooks_failed: number
  new_subscriptions_by_month: Record<string, number>
  /** fornecedor → estado do método → n.º */
  payment_methods: Record<string, Record<string, number>>
  invoices_unpaid: number
  invoices_unpaid_cents: number
  fulfillment_pending: number
}

export interface AdminUserRow {
  id: string
  username: string
  email: string
  display_name: string | null
  is_admin: boolean
  is_active: boolean
  email_verified: boolean
  created_at: string
  last_login_at: string | null
  subscription: {
    status: string
    plan: string | null
    provider: string
    current_period_end: string | null
  } | null
}

export interface Paged<T> {
  total: number
  page: number
  size: number
  items: T[]
}

export interface AdminGrant {
  id: number
  plan: string
  plan_id: number
  reason: string | null
  starts_at: string
  ends_at: string | null
  revoked_at: string | null
}

export interface AdminServiceAccount {
  service: string
  external_id: string | null
  username: string | null
  applied_state: Record<string, unknown> | null
  last_synced_at: string | null
  last_error: string | null
  has_secret: boolean
  data: Record<string, unknown> | null
}

export interface AuditRow {
  id?: number
  created_at: string
  actor: string | null
  action: string
  target_type?: string | null
  target_id?: string | null
  ip: string | null
  details: Record<string, unknown> | null
}

export interface AdminUserDetail {
  user: Me & {
    is_active: boolean
    admin_notes: string | null
    last_login_at: string | null
    stripe_customer_id: string | null
    gocardless_customer_id: string | null
    gocardless_mandate_id: string | null
    legacy_id: string | null
  }
  effective_features: PlanFeatures
  groups: string[]
  billing: {
    anchor_day: number | null
    next_billing_at: string | null
    upcoming: Upcoming
    pending_lines: { id: number; description: string; amount_cents: number; kind: string }[]
  }
  invoices: Invoice[]
  payment_methods: PaymentMethod[]
  bonus: BonusStatus
  subscriptions: Subscription[]
  payments: Payment[]
  grants: AdminGrant[]
  service_accounts: AdminServiceAccount[]
  invitees: string[]
  audit: AuditRow[]
  wallet?: WalletSummary & { transactions: WalletTx[] }
}

export interface PriceChange {
  id: number
  old_price_cents: number
  new_price_cents: number
  effective_at: string
  notified_at: string | null
  note: string | null
  /** false = sem aviso pelo portal (o admin avisa por fora). */
  notify?: boolean
}

export interface AdminPlan extends Plan {
  is_active: boolean
  is_public: boolean
  sort_order: number
  active_subscriptions: number
  subscribers_on_other_price: number
  price_changes: PriceChange[]
}

export interface AdminProduct {
  id: number
  code: string
  name: string
  description: string | null
  kind: string
  fulfillment: Fulfillment | string
  webhook_url: string | null
  has_webhook_secret: boolean
  access_instructions: string | null
  app_url?: string | null
  icon: string | null
  image_url?: string | null
  bonus_eligible: boolean
  jellyfin_managed: boolean
  requires_invite?: boolean
  locked_name?: string | null
  locked_description?: string | null
  is_active: boolean
  sort_order: number
  plans: AdminPlan[]
}

export interface AdminInvoice extends Invoice {
  username: string | null
  user_id: string
}

export interface FulfillmentRow extends Subscription {
  username: string | null
  email: string | null
  user_id: string
}

export interface AdminProvider {
  name: Provider
  label: string
  method_label: string
  configured: boolean
  enabled: boolean
  accept_new: boolean
  account_id: string | null
  methods: Record<string, number>
  customers_only_on_this: number
}

export interface LegacyImportResult {
  user?: string | null
  plan?: string | null
  price_cents?: number | null
  paid_until?: string | null
  result?: string | null
  [k: string]: unknown
  email?: string | null
  monthly_cents?: number | null
}

export interface LegacyImportOut {
  dry_run: boolean
  count: number
  results: LegacyImportResult[]
}

export interface AdminInvite {
  id: number
  code: string
  uses: number
  max_uses: number
  expires_at: string | null
  note: string | null
  disabled: boolean
  created_at: string
  created_by: string | null
  unlocks?: string[] | null
}

export interface Job {
  id: number
  kind: string
  status: string
  attempts: number
  max_attempts: number
  run_after: string | null
  last_error: string | null
  created_at: string
  finished_at: string | null
  payload: Record<string, unknown>
}

export interface WebhookRow {
  id: number
  provider: string
  event_id: string
  event_type: string | null
  status: string
  error: string | null
  received_at: string
  processed_at: string | null
}

export interface WebhookDetail {
  id: number
  provider: string
  event_type: string | null
  status: string
  error: string | null
  payload: unknown
}

export interface IntegrationHealth {
  name: string
  configured: boolean
  ok?: boolean
  info?: Record<string, unknown>
  error?: string
}

export interface OidcClient {
  client_id: string
  name: string
  redirect_uris: string[]
  post_logout_redirect_uris: string[]
  allowed_scopes: string[]
  required_access: string | null
  public: boolean
  require_pkce: boolean
  is_active: boolean
  created_at: string
}

export interface OidcClientsOut {
  issuer: string
  discovery: string
  clients: OidcClient[]
}

export interface JellyfinLibrary {
  id: string
  name: string
  type: string | null
}


// --------------------------------------------------------------------------- carteira
export interface WalletTx {
  id: number
  kind: string
  amount_cents: number
  balance_after_cents: number
  description: string
  created_at: string
}

export interface WalletSummary {
  enabled: boolean
  balance_cents: number
  pending_topup_cents: number
  monthly_topup_cents: number | null
  monthly_skip_when_covered: boolean
  monthly_bonus_percent: number
  recurring_cents: number
  suggested_monthly_cents: number
  covers_months: number | null
  wallet_only: boolean
  monthly_enabled?: boolean
  billing_mode: string
  has_services: boolean
  has_payment_method: boolean
  min_topup_cents: number
  max_topup_cents: number
  min_monthly_cents: number
  max_monthly_cents: number
  next_billing_at: string | null
  games_enabled: boolean
}

export interface WalletOut extends WalletSummary {
  transactions: WalletTx[]
}

export interface TopupOut {
  status: 'paid' | 'processing' | 'deferred' | 'redirect' | string
  message?: string
  balance_cents?: number
  redirect_url?: string
  checkout_id?: string
}

// --------------------------------------------------------------------------- jogos
export interface FairInfo {
  server_seed_hash: string
  client_seed: string
  nonce: number
}

export interface GameHistoryRow {
  id: string
  game: 'roulette' | 'blackjack' | string
  wager_cents: number
  payout_cents: number
  net_cents: number
  summary: string
  settled_at: string | null
  nonce: number | null
}

export interface BlackjackHand {
  cards: string[]
  bet_cents: number
  total: number
  soft: boolean
  doubled: boolean
  done: boolean
  active: boolean
  result: { result: string; payout_cents: number; total: number | null } | null
}

export interface BlackjackState {
  round_id: string
  status: 'active' | 'settled' | string
  phase: 'insurance' | 'player' | 'done' | string
  dealer: string[]
  dealer_total: number
  hands: BlackjackHand[]
  insurance_cents: number | null
  can: { hit: boolean; stand: boolean; double: boolean; split: boolean; insurance: boolean }
  insurance_cost_cents: number | null
  payout_cents: number | null
  wager_cents: number
  balance_cents: number
  fair: FairInfo | null
}

export interface GamesOverview {
  enabled: boolean
  accepted: boolean
  min_age: number
  excluded_until: string | null
  min_bet_cents: number
  max_bet_cents: number
  chips_cents: number[]
  daily_loss_limit_cents: number | null
  system_daily_loss_limit_cents: number | null
  user_daily_loss_limit_cents: number | null
  net_today_cents: number
  balance_cents: number
  seed: FairInfo
  history: GameHistoryRow[]
  blackjack: BlackjackState | null
}

export type RouletteBetType =
  | 'straight' | 'split' | 'street' | 'corner' | 'line' | 'column' | 'dozen'
  | 'red' | 'black' | 'odd' | 'even' | 'low' | 'high'

export interface RouletteBet {
  type: RouletteBetType
  numbers: number[]
  amount_cents: number
}

export interface RouletteResult {
  round_id: string
  number: number
  color: 'red' | 'black' | 'green'
  bets: (RouletteBet & { won: boolean; payout_cents: number })[]
  wager_cents: number
  payout_cents: number
  net_cents: number
  balance_cents: number
  fair: FairInfo
}

// --------------------------------------------------------------------------- configuração por web
export type ConfigFieldType = 'text' | 'url' | 'secret' | 'bool' | 'int' | 'float' | 'money' | 'list' | 'select' | 'email'

export interface ConfigField {
  name: string
  label: string
  type: ConfigFieldType
  help: string | null
  placeholder: string | null
  advanced: boolean
  min: number | null
  max: number | null
  options: { value: string; label: string }[]
  source: 'web' | 'env' | 'default'
  value: unknown
  is_set?: boolean
  masked?: string | null
}

export interface ConfigSection {
  id: string
  title: string
  description: string
  fields: ConfigField[]
  test: boolean
  links: { label: string; url: string }[]
}

export interface TunnelStatus {
  installed: boolean
  configured: boolean
  running: boolean
  connected: boolean
  connections: number | null
  restarts: number
  exit_code: number | null
  log: string[]
  service_url: string
}

export interface ConfigOut {
  sections: ConfigSection[]
  tunnel: TunnelStatus
}

export interface SetupStatus {
  completed: boolean
  public_url: string
  checklist: { id: string; label: string; done: boolean; optional: boolean; hint: string }[]
}

export interface JellyfinHelpStatus {
  id: string | null
  updated_at: string | null
  help_url: string
  stale: boolean
  jellyfin_ready: boolean
  whatsapp: string | null
  item_url: string | null
}

export interface JellyfinSnippets {
  portal_url: string
  jellyfin_url: string | null
  jellyfin_origin_ok: boolean
  js_loader: string
  js_full: string
  custom_page: string
  sso_button_html: string
  sso_css: string
  links: Record<string, string | null>
  repositories: { name: string; url: string }[]
}

export interface MigrationStatus {
  gocardless_configured: boolean
  stripe_configured: boolean
  imported_users: number
  users_with_gocardless: number
  converted: number
  legacy: {
    subscription_id: string
    username: string
    email: string
    plan: string
    status: string
    price: string
    next_charge: string | null
    gc_subscription: string
  }[]
}

export interface LegacyImportReport {
  total: number
  new: number
  existing: number
  skipped: number
  grants: number
  iptv: number
  jellyfin: number
  referrals: number
  dry_run: boolean
  users: { username: string; email: string; conta: string; estado_antigo: string | null }[]
  warnings: string[]
  subscriptions: { user?: string; result: string; plan?: string; paid_until?: string; gc_subscription?: string }[]
}

// ---------------------------------------------------------------- Importação com revisão (Admin → Migração)
export type ImportFlagLevel = 'info' | 'warn' | 'error'
export interface ImportFlag {
  level: ImportFlagLevel
  code: string
  text: string
}
export interface ImportSubProposal {
  gc_id: string
  include: boolean
  plan_id: number | null
  price_cents: number | null
  mode: 'keep' | 'convert'
  next_charge: string | null
}
export interface ImportProposal {
  include: boolean
  account: { action: 'link' | 'create'; user_id: string | null; email: string; username: string; display_name: string }
  mandate_id: string | null
  subscriptions: ImportSubProposal[]
  link_jellyfin: boolean
  link_iptv: boolean
  grant: { plan_id: number | null; until: string | null } | null
  note: string
}
export interface ImportMandateView {
  id: string
  status: string
  scheme: string | null
  reference: string | null
  created_at: string | null
  next_possible_charge_date: string | null
  bank: string | null
  account_ending: string | null
}
export interface ImportSubView {
  id: string
  status: string
  name: string | null
  amount: number | null
  currency: string
  interval_unit: string | null
  interval: number
  day_of_month: number | null
  start_date: string | null
  end_date: string | null
  created_at: string | null
  mandate: string | null
  metadata: Record<string, string>
  upcoming: string[]
  payments: { id: string; status: string; amount: number | null; charge_date: string | null; description: string | null }[]
  portal?: { id: string; provider: string; status: string }
}
export interface ImportRowOut {
  id: number
  key: string
  email: string | null
  status: 'pending' | 'imported' | 'skipped' | 'error'
  result: string | null
  edited: boolean
  flags: ImportFlag[]
  proposal: ImportProposal
  updated_at: string | null
  source: {
    customer: {
      id: string
      email: string | null
      given_name: string | null
      family_name: string | null
      company_name: string | null
      created_at: string | null
      city: string | null
      country_code: string | null
      phone_number: string | null
      metadata: Record<string, string>
    } | null
    mandates: ImportMandateView[]
    subscriptions: ImportSubView[]
    legacy: (Record<string, string | number | null> & { has_password?: boolean; has_iptv_password?: boolean }) | null
    portal: { user_id: string; username: string; email: string } | null
  }
}
export interface ImportReviewState {
  status: 'idle' | 'running' | 'done' | 'error'
  started_at?: string | null
  finished_at?: string | null
  error?: string | null
  counts?: { rows: number; customers: number; subscriptions: number; legacy: number; with_flags: number; ready: number }
  legacy: { count: number; name: string | null; loaded_at: string | null }
}
export interface ImportReviewPlan {
  id: number
  code: string
  name: string
  product: string | null
  price_cents: number
  interval_unit: string
  interval_count: number
  active: boolean
}
export interface ImportReview {
  state: ImportReviewState
  gocardless_configured: boolean
  rows: ImportRowOut[]
  plans: ImportReviewPlan[]
}
export interface ImportApplyOut {
  dry_run: boolean
  message: string
  results: { id: number; status: 'imported' | 'simulated' | 'error' | 'skipped'; result: string }[]
}
