import { useEffect, useMemo, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import clsx from 'clsx'
import { AlertTriangle, CheckCircle2, Database, Eye, FlaskConical, Import, Landmark, RefreshCw, RotateCcw, Search, Trash2, Upload } from 'lucide-react'
import { api, errorMessage } from '../../api/client'
import { useAction } from '../../api/mutation'
import type { ImportApplyOut, ImportFlag, ImportProposal, ImportReview as ImportReviewData, ImportReviewPlan, ImportRowOut, ImportSubView } from '../../api/types'
import type { Tone } from '../../i18n/labels'
import { formatDate, formatDateTime, formatMoney, perInterval } from '../../lib/format'
import { centsToInput, parseEuros } from '../wallet/AmountPicker'
import { Alert, Badge, Button, Card, CardHeader, Checkbox, EmptyState, Field, Input, Modal, Pills, Select, SkeletonCard, Spinner, Switch, Table, THead, Th, Tr, Td, Textarea } from '../ui'

const KEY = ['admin', 'import-review']
const BASE = '/api/admin/migration/review'
/** Estados GoCardless em que a subscrição ainda pode ser importada (igual ao backend). */
const LIVE = new Set(['active', 'paused', 'customer_approval_granted', 'pending_customer_approval'])

const GC_STATUS: Record<string, [string, Tone]> = {
  active: ['ativo', 'success'],
  pending_submission: ['a submeter', 'info'],
  submitted: ['submetido', 'info'],
  pending_customer_approval: ['à espera do cliente', 'info'],
  customer_approval_granted: ['aprovada', 'info'],
  customer_approval_denied: ['recusado', 'danger'],
  cancelled: ['cancelado', 'neutral'],
  finished: ['terminada', 'neutral'],
  paused: ['pausada', 'warning'],
  failed: ['falhou', 'danger'],
  expired: ['expirado', 'neutral'],
  consumed: ['substituído', 'neutral'],
  blocked: ['bloqueado', 'danger'],
  suspended_by_payer: ['suspenso pelo cliente', 'warning'],
  paid_out: ['pago', 'success'],
  confirmed: ['confirmado', 'success'],
  charged_back: ['estornado', 'danger'],
}

function GcBadge({ status }: { status: string | null | undefined }) {
  const [label, tone] = GC_STATUS[status ?? ''] ?? [status ?? '—', 'neutral' as Tone]
  return <Badge tone={tone}>{label}</Badge>
}

const unitOf = (u: string | null | undefined) => ({ monthly: 'month', yearly: 'year', weekly: 'week' })[u ?? ''] ?? 'month'

function planLabel(p: ImportReviewPlan) {
  return `${p.product ? `${p.product} · ` : ''}${p.name} — ${formatMoney(p.price_cents)}${perInterval(p.interval_unit, p.interval_count)}${p.active ? '' : ' (inativo)'}`
}

function flagTone(level: ImportFlag['level']): Tone {
  return level === 'error' ? 'danger' : level === 'warn' ? 'warning' : 'info'
}

function FlagSummary({ flags }: { flags: ImportFlag[] }) {
  const err = flags.filter((f) => f.level === 'error').length
  const warn = flags.filter((f) => f.level === 'warn').length
  const info = flags.filter((f) => f.level === 'info').length
  if (!flags.length) return <span className="text-xs text-subtle">—</span>
  const first = flags.find((f) => f.level === 'error') ?? flags.find((f) => f.level === 'warn') ?? flags[0]
  return (
    <div className="space-y-1">
      <div className="flex flex-wrap gap-1">
        {err > 0 && <Badge tone="danger">{err} a corrigir</Badge>}
        {warn > 0 && <Badge tone="warning">{warn} a verificar</Badge>}
        {info > 0 && <Badge tone="neutral">{info} info</Badge>}
      </div>
      <p className="line-clamp-2 max-w-[20rem] text-xs text-muted">{first.text}</p>
    </div>
  )
}

function RowStatus({ row }: { row: ImportRowOut }) {
  if (row.status === 'imported')
    return (
      <Badge tone="success" title={row.result ?? undefined}>
        importado
      </Badge>
    )
  if (row.status === 'error')
    return (
      <Badge tone="danger" title={row.result ?? undefined}>
        erro
      </Badge>
    )
  if (row.status === 'skipped') return <Badge tone="neutral">ignorado</Badge>
  return row.proposal.include ? <Badge tone="brand">{row.edited ? 'a importar (editado)' : 'a importar'}</Badge> : <Badge tone="neutral">{row.edited ? 'fora (editado)' : 'fora'}</Badge>
}

function displayName(row: ImportRowOut) {
  const c = row.source.customer
  return (c && ([c.given_name, c.family_name].filter(Boolean).join(' ') || c.company_name)) || row.proposal.account.display_name || row.source.legacy?.username || row.email || row.key
}

// ------------------------------------------------------------------------------------------- fontes
function Sources({ data }: { data: ImportReviewData }) {
  const qc = useQueryClient()
  const fileRef = useRef<HTMLInputElement>(null)
  const st = data.state
  const upload = useAction(
    (file: File) => {
      const fd = new FormData()
      fd.append('file', file)
      return api.upload<{ message: string }>(`${BASE}/legacy`, fd)
    },
    { invalidate: [KEY], errorTitle: 'Não foi possível ler o ficheiro' },
  )
  const forget = useAction(() => api.del(`${BASE}/legacy`), { invalidate: [KEY] })
  const scan = useAction(() => api.post(`${BASE}/scan`), {
    success: 'A ler a GoCardless… isto pode demorar um pouco.',
    errorTitle: 'Não foi possível começar a leitura',
    onSuccess: () => void qc.invalidateQueries({ queryKey: KEY }),
  })
  const running = st.status === 'running'
  return (
    <Card className="p-5 sm:p-6">
      <div className="grid gap-4 lg:grid-cols-3">
        <div className="flex gap-3 rounded-2xl border border-border p-4">
          <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-brand-soft text-brand-text">
            <Landmark className="size-5" aria-hidden />
          </span>
          <div className="min-w-0 text-sm">
            <p className="font-semibold">GoCardless {data.gocardless_configured ? <Badge tone="success">ligada</Badge> : <Badge tone="warning">por configurar</Badge>}</p>
            <p className="mt-1 text-muted">
              {data.gocardless_configured ? (
                'É a fonte principal: clientes, mandatos, subscrições (incluindo as canceladas à mão) e os últimos pagamentos.'
              ) : (
                <>
                  Configura em <Link to="/admin/definicoes?s=gocardless" className="font-semibold underline">Definições → GoCardless</Link>.
                </>
              )}
            </p>
          </div>
        </div>
        <div className="flex gap-3 rounded-2xl border border-border p-4">
          <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-brand-soft text-brand-text">
            <Database className="size-5" aria-hidden />
          </span>
          <div className="min-w-0 flex-1 text-sm">
            <p className="font-semibold">
              users.db do site antigo {st.legacy.count > 0 ? <Badge tone="success">{st.legacy.count} utilizadores</Badge> : <Badge tone="neutral">opcional</Badge>}
            </p>
            <p className="mt-1 text-muted">
              {st.legacy.count > 0
                ? `${st.legacy.name ?? 'users.db'} · carregado ${formatDateTime(st.legacy.loaded_at)}`
                : 'Completa a GoCardless: username, password, Jellyfin, TV e quem convidou.'}
            </p>
            <div className="mt-2 flex flex-wrap gap-2">
              <Button size="sm" variant="secondary" loading={upload.isPending} icon={<Upload className="size-4" />} onClick={() => fileRef.current?.click()}>
                {st.legacy.count ? 'Substituir' : 'Carregar'}
              </Button>
              {st.legacy.count > 0 && (
                <Button size="sm" variant="ghost" loading={forget.isPending} icon={<Trash2 className="size-4" />} onClick={() => forget.mutate()}>
                  Remover
                </Button>
              )}
              <input
                ref={fileRef}
                type="file"
                accept=".db,.sqlite,.sqlite3,application/octet-stream"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0]
                  if (f) upload.mutate(f)
                  e.target.value = ''
                }}
              />
            </div>
          </div>
        </div>
        <div className="flex flex-col justify-between gap-3 rounded-2xl border border-border p-4 text-sm">
          <div>
            <p className="font-semibold">Leitura</p>
            <p className="mt-1 text-muted">
              {running ? (
                <span className="inline-flex items-center gap-2">
                  <Spinner className="size-4" /> A ler…
                </span>
              ) : st.status === 'done' ? (
                <>
                  Última: {formatDateTime(st.finished_at)} · {st.counts?.customers ?? 0} clientes, {st.counts?.subscriptions ?? 0} subscrições
                </>
              ) : st.status === 'error' ? (
                <span className="text-danger">Falhou: {st.error}</span>
              ) : (
                'Ainda não foi feita.'
              )}
            </p>
          </div>
          <Button loading={scan.isPending || running} disabled={running} icon={<RefreshCw className="size-4" />} onClick={() => scan.mutate()}>
            {st.status === 'idle' ? 'Ler a GoCardless' : 'Ler de novo'}
          </Button>
        </div>
      </div>
      <p className="mt-4 text-xs text-muted">
        Ler de novo atualiza tudo com o que está agora na GoCardless (mandatos novos, cancelamentos feitos à mão…). As tuas edições ainda por importar mantêm-se.
      </p>
    </Card>
  )
}

// --------------------------------------------------------------------------------------- detalhe
function KV({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex gap-3 py-1 text-sm">
      <span className="w-32 shrink-0 text-muted">{label}</span>
      <span className="min-w-0 break-words">{children ?? '—'}</span>
    </div>
  )
}

function SubRead({ s }: { s: ImportSubView }) {
  return (
    <div className="rounded-xl border border-border p-3">
      <div className="flex flex-wrap items-center gap-2">
        <p className="font-semibold">{s.name || 'Subscrição'}</p>
        <GcBadge status={s.status} />
        {s.portal && <Badge tone="info">já no portal</Badge>}
      </div>
      <p className="mt-1 text-sm">
        {formatMoney(s.amount ?? 0, s.currency)}
        {perInterval(unitOf(s.interval_unit), s.interval)}
        {s.day_of_month ? ` · dia ${s.day_of_month === -1 ? 'último' : s.day_of_month}` : ''}
      </p>
      <p className="text-xs text-muted">
        {s.id} · mandato {s.mandate} · desde {formatDate(s.start_date)}
        {s.end_date ? ` · termina ${formatDate(s.end_date)}` : ''}
      </p>
      {s.upcoming.length > 0 && <p className="mt-1 text-xs">Próximas cobranças: {s.upcoming.map((d) => formatDate(d)).join(', ')}</p>}
      {s.payments.length > 0 && (
        <ul className="mt-2 space-y-1 border-t border-border pt-2 text-xs">
          {s.payments.map((p) => (
            <li key={p.id} className="flex items-center gap-2">
              <span className="w-20 text-muted">{formatDate(p.charge_date)}</span>
              <span className="w-16 tabular-nums">{formatMoney(p.amount ?? 0)}</span>
              <GcBadge status={p.status} />
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}

function ReadData({ row }: { row: ImportRowOut }) {
  const c = row.source.customer
  const leg = row.source.legacy
  return (
    <div className="space-y-5">
      <section>
        <h3 className="mb-1 text-xs font-semibold uppercase tracking-wider text-subtle">GoCardless</h3>
        {!c ? (
          <p className="text-sm text-muted">Não aparece na GoCardless.</p>
        ) : (
          <>
            <KV label="Cliente">{[c.given_name, c.family_name].filter(Boolean).join(' ') || c.company_name}</KV>
            <KV label="Email">{c.email}</KV>
            <KV label="Desde">{formatDate(c.created_at)}</KV>
            {(c.city || c.country_code) && <KV label="Local">{[c.city, c.country_code].filter(Boolean).join(', ')}</KV>}
            {c.phone_number && <KV label="Telefone">{c.phone_number}</KV>}
            <KV label="ID">
              <code className="text-xs">{c.id}</code>
            </KV>
          </>
        )}
        {row.source.mandates.length > 0 && (
          <div className="mt-3 space-y-2">
            <p className="text-sm font-medium">Mandatos</p>
            {row.source.mandates.map((m) => (
              <div key={m.id} className="flex flex-wrap items-center gap-2 rounded-xl border border-border px-3 py-2 text-sm">
                <GcBadge status={m.status} />
                <span>
                  {m.bank ?? 'Banco'} {m.account_ending ? `••${m.account_ending}` : ''}
                </span>
                <span className="text-xs text-muted">
                  {m.id} · {m.scheme} · {formatDate(m.created_at)}
                </span>
              </div>
            ))}
          </div>
        )}
        {row.source.subscriptions.length > 0 && (
          <div className="mt-3 space-y-2">
            <p className="text-sm font-medium">Subscrições e pagamentos</p>
            {row.source.subscriptions.map((s) => (
              <SubRead key={s.id} s={s} />
            ))}
          </div>
        )}
      </section>
      <section>
        <h3 className="mb-1 text-xs font-semibold uppercase tracking-wider text-subtle">Site antigo (users.db)</h3>
        {!leg ? (
          <p className="text-sm text-muted">Sem dados do site antigo.</p>
        ) : (
          <>
            <KV label="Username">{leg.username}</KV>
            <KV label="Email">{leg.email}</KV>
            <KV label="Estado">
              {leg.subscription_status ?? '—'}
              {leg.subscription_end_date ? ` (até ${formatDate(String(leg.subscription_end_date))})` : ''}
            </KV>
            <KV label="Password">{leg.has_password ? 'mantém a antiga' : 'sem password — "recuperar password"'}</KV>
            {leg.jellyfin_user_id && <KV label="Jellyfin">{String(leg.jellyfin_user_id)}</KV>}
            {leg.iptvusername && (
              <KV label="TV (IPTV)">
                {String(leg.iptvusername)} {leg.iptvhost ? `· ${leg.iptvhost}` : ''}
              </KV>
            )}
            {leg.invited_by && <KV label="Convidado por">{String(leg.invited_by)}</KV>}
            <KV label="ID antigo">{String(leg.id)}</KV>
          </>
        )}
      </section>
      {row.source.portal && (
        <section>
          <h3 className="mb-1 text-xs font-semibold uppercase tracking-wider text-subtle">Já no portal</h3>
          <KV label="Conta">
            <Link to={`/admin/utilizadores/${row.source.portal.user_id}`} className="font-semibold underline">
              @{row.source.portal.username}
            </Link>{' '}
            · {row.source.portal.email}
          </KV>
        </section>
      )}
    </div>
  )
}

type SubForm = { gc_id: string; include: boolean; plan_id: number | null; price: string; mode: 'keep' | 'convert'; next_charge: string }

function toForm(p: ImportProposal) {
  return {
    include: p.include,
    action: p.account.action,
    user_id: p.account.user_id,
    email: p.account.email,
    username: p.account.username,
    display_name: p.account.display_name,
    mandate_id: p.mandate_id ?? '',
    subs: p.subscriptions.map<SubForm>((s) => ({
      gc_id: s.gc_id,
      include: s.include,
      plan_id: s.plan_id,
      price: s.price_cents != null ? centsToInput(s.price_cents) : '',
      mode: s.mode,
      next_charge: s.next_charge ?? '',
    })),
    link_jellyfin: p.link_jellyfin,
    link_iptv: p.link_iptv,
    grant: !!p.grant,
    grant_plan: p.grant?.plan_id ?? null,
    grant_until: p.grant?.until ?? '',
    note: p.note ?? '',
  }
}

function RowDetail({ row, plans, onClose }: { row: ImportRowOut; plans: ImportReviewPlan[]; onClose: () => void }) {
  const [f, setF] = useState(() => toForm(row.proposal))
  const [sim, setSim] = useState<string | null>(null)
  useEffect(() => setF(toForm(row.proposal)), [row.proposal])
  const set = (patch: Partial<typeof f>) => setF((prev) => ({ ...prev, ...patch }))
  const setSub = (gc: string, patch: Partial<SubForm>) => setF((prev) => ({ ...prev, subs: prev.subs.map((s) => (s.gc_id === gc ? { ...s, ...patch } : s)) }))
  const views = new Map(row.source.subscriptions.map((s) => [s.id, s]))
  const locked = row.status === 'imported'
  const body = () => ({
    include: f.include,
    account: {
      action: f.action,
      // Ao mudar o email de uma conta a ligar, o portal procura a conta por esse email.
      user_id: f.action === 'link' && f.email === row.proposal.account.email ? f.user_id : null,
      email: f.email,
      username: f.username,
      display_name: f.display_name,
    },
    mandate_id: f.mandate_id || null,
    subscriptions: f.subs.map((s) => ({
      gc_id: s.gc_id,
      include: s.include,
      plan_id: s.plan_id,
      price_cents: parseEuros(s.price) ?? 0,
      mode: s.mode,
      next_charge: s.next_charge || null,
    })),
    link_jellyfin: f.link_jellyfin,
    link_iptv: f.link_iptv,
    grant: f.grant ? { plan_id: f.grant_plan, until: f.grant_until || null } : null,
    note: f.note,
  })
  const save = useAction(() => api.patch<ImportRowOut>(`${BASE}/rows/${row.id}`, body()), {
    invalidate: [KEY],
    success: 'Proposta guardada.',
    errorTitle: 'Não foi possível guardar',
  })
  const reset = useAction(() => api.post<ImportRowOut>(`${BASE}/rows/${row.id}/reset`), { invalidate: [KEY], success: 'Proposta reposta.' })
  const simulate = useAction(
    async () => {
      await api.patch(`${BASE}/rows/${row.id}`, body())
      return api.post<ImportApplyOut>(`${BASE}/apply`, { row_ids: [row.id], dry_run: true })
    },
    { success: false, invalidate: [KEY], errorTitle: 'A simulação falhou', onSuccess: (r) => setSim(r.results[0]?.result ?? '—') },
  )
  const leg = row.source.legacy
  return (
    <Modal
      open
      onClose={onClose}
      size="xl"
      title={displayName(row)}
      description={
        <span className="flex flex-wrap items-center gap-2">
          {row.email ?? 'sem email'} <RowStatus row={row} />
        </span>
      }
      footer={
        locked ? (
          <Button variant="secondary" onClick={onClose}>
            Fechar
          </Button>
        ) : (
          <>
            <Button variant="ghost" icon={<RotateCcw className="size-4" />} loading={reset.isPending} disabled={!row.edited} onClick={() => reset.mutate()}>
              Repor proposta
            </Button>
            <Button variant="secondary" icon={<FlaskConical className="size-4" />} loading={simulate.isPending} onClick={() => simulate.mutate()}>
              Simular este
            </Button>
            <Button loading={save.isPending} onClick={() => save.mutate()}>
              Guardar
            </Button>
          </>
        )
      }
    >
      <div className="space-y-4">
        {row.result && (
          <Alert tone={row.status === 'error' ? 'danger' : 'success'} title={row.status === 'error' ? 'Erro na importação' : 'Importado'}>
            {row.result}
          </Alert>
        )}
        {sim && (
          <Alert tone="info" title="Simulação (nada foi gravado)">
            {sim}
          </Alert>
        )}
        {row.flags.length > 0 && (
          <ul className="space-y-1.5">
            {row.flags.map((fl, i) => (
              <li key={i} className="flex items-start gap-2 text-sm">
                <Badge tone={flagTone(fl.level)}>{fl.level === 'error' ? 'corrigir' : fl.level === 'warn' ? 'verificar' : 'info'}</Badge>
                <span>{fl.text}</span>
              </li>
            ))}
          </ul>
        )}
        <div className="grid gap-6 lg:grid-cols-2">
          <div className="rounded-2xl border border-border bg-bg/40 p-4">
            <p className="mb-3 font-semibold">O que foi lido</p>
            <ReadData row={row} />
          </div>
          <fieldset disabled={locked} className="space-y-4">
            <p className="font-semibold">O que vai ser importado</p>
            <Switch checked={f.include} onChange={(v) => set({ include: v })} label="Importar este cliente" description="Desligado: fica de fora (podes voltar a ligar depois)." />
            <div className="space-y-3 rounded-2xl border border-border p-4">
              <p className="text-sm font-medium">Conta no portal</p>
              <Select value={f.action} onChange={(e) => set({ action: e.target.value as 'link' | 'create' })}>
                <option value="create">Criar conta nova</option>
                <option value="link">Ligar a uma conta que já existe (pelo email)</option>
              </Select>
              <Field label="Email">
                <Input type="email" value={f.email} onChange={(e) => set({ email: e.target.value })} />
              </Field>
              {f.action === 'create' && (
                <div className="grid gap-3 sm:grid-cols-2">
                  <Field label="Username" hint="É também o nome no Jellyfin.">
                    <Input value={f.username} onChange={(e) => set({ username: e.target.value })} />
                  </Field>
                  <Field label="Nome" optional>
                    <Input value={f.display_name} onChange={(e) => set({ display_name: e.target.value })} />
                  </Field>
                </div>
              )}
            </div>
            {row.source.mandates.length > 0 && (
              <Field label="Mandato a usar" hint="Fica como método de pagamento do cliente.">
                <Select value={f.mandate_id} onChange={(e) => set({ mandate_id: e.target.value })}>
                  <option value="">Nenhum</option>
                  {row.source.mandates.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.bank ?? 'Banco'} {m.account_ending ? `••${m.account_ending}` : ''} — {GC_STATUS[m.status]?.[0] ?? m.status} ({m.id})
                    </option>
                  ))}
                </Select>
              </Field>
            )}
            {f.subs.map((s) => {
              const v = views.get(s.gc_id)
              const live = LIVE.has(v?.status ?? '')
              return (
                <div key={s.gc_id} className={clsx('space-y-3 rounded-2xl border p-4', s.include ? 'border-brand/60' : 'border-border')}>
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <Checkbox
                      checked={s.include}
                      disabled={!live && !s.include}
                      onChange={(e) => setSub(s.gc_id, { include: e.target.checked })}
                      label={`${v?.name || 'Subscrição'} (${s.gc_id})`}
                      description={live ? undefined : 'Não está ativa na GoCardless — não dá para importar.'}
                    />
                    <GcBadge status={v?.status} />
                  </div>
                  {s.include && (
                    <div className="grid gap-3 sm:grid-cols-2">
                      <Field label="Plano" className="sm:col-span-2">
                        <Select value={s.plan_id ?? ''} onChange={(e) => setSub(s.gc_id, { plan_id: e.target.value ? Number(e.target.value) : null })}>
                          <option value="">Escolhe o plano…</option>
                          {plans.map((p) => (
                            <option key={p.id} value={p.id}>
                              {planLabel(p)}
                            </option>
                          ))}
                        </Select>
                      </Field>
                      <Field
                        label="Preço (€)"
                        hint={
                          s.mode === 'keep'
                            ? `A GoCardless continua a cobrar ${v?.amount != null ? formatMoney(v.amount) : 'o valor dela'}; este preço conta quando passar para o portal.`
                            : v?.amount != null
                              ? `Na GoCardless: ${formatMoney(v.amount)}`
                              : undefined
                        }
                      >
                        <Input inputMode="decimal" value={s.price} onChange={(e) => setSub(s.gc_id, { price: e.target.value })} />
                      </Field>
                      <Field
                        label="Próxima cobrança"
                        hint={s.mode === 'keep' ? 'Fica a da GoCardless enquanto a subscrição lá estiver.' : v?.upcoming[0] ? `Na GoCardless: ${formatDate(v.upcoming[0])}` : undefined}
                      >
                        <Input type="date" disabled={s.mode === 'keep'} value={s.mode === 'keep' ? (v?.upcoming[0] ?? '') : s.next_charge} onChange={(e) => setSub(s.gc_id, { next_charge: e.target.value })} />
                      </Field>
                      <Field label="Quem cobra" className="sm:col-span-2">
                        <Select value={s.mode} onChange={(e) => setSub(s.gc_id, { mode: e.target.value as 'keep' | 'convert' })}>
                          <option value="keep">Continua na GoCardless (passa sozinha para o portal na 1.ª alteração)</option>
                          <option value="convert">Passa já para o portal (a subscrição na GoCardless é cancelada)</option>
                        </Select>
                      </Field>
                    </div>
                  )}
                </div>
              )
            })}
            {(leg?.jellyfin_user_id || leg?.iptvusername) && (
              <div className="space-y-2">
                {leg?.jellyfin_user_id && <Checkbox checked={f.link_jellyfin} onChange={(e) => set({ link_jellyfin: e.target.checked })} label="Ligar a conta Jellyfin antiga" />}
                {leg?.iptvusername && <Checkbox checked={f.link_iptv} onChange={(e) => set({ link_iptv: e.target.checked })} label="Ligar as credenciais de TV (IPTV) antigas" />}
              </div>
            )}
            <div className="space-y-3 rounded-2xl border border-border p-4">
              <Checkbox
                checked={f.grant}
                onChange={(e) => set({ grant: e.target.checked })}
                label="Oferecer acesso até uma data"
                description="Ex.: quem estava “A expirar” no site antigo mantém o acesso até ao fim do que pagou."
              />
              {f.grant && (
                <div className="grid gap-3 sm:grid-cols-2">
                  <Field label="Plano">
                    <Select value={f.grant_plan ?? ''} onChange={(e) => set({ grant_plan: e.target.value ? Number(e.target.value) : null })}>
                      <option value="">Escolhe…</option>
                      {plans.map((p) => (
                        <option key={p.id} value={p.id}>
                          {planLabel(p)}
                        </option>
                      ))}
                    </Select>
                  </Field>
                  <Field label="Até">
                    <Input type="date" value={f.grant_until} onChange={(e) => set({ grant_until: e.target.value })} />
                  </Field>
                </div>
              )}
            </div>
            <Field label="Nota interna" optional>
              <Textarea rows={2} value={f.note} onChange={(e) => set({ note: e.target.value })} maxLength={500} />
            </Field>
          </fieldset>
        </div>
      </div>
    </Modal>
  )
}

// ------------------------------------------------------------------------------------------ lista
type Filter = 'all' | 'ready' | 'check' | 'out' | 'imported' | 'error'

export function ImportReview() {
  const q = useQuery({
    queryKey: KEY,
    queryFn: () => api.get<ImportReviewData>(BASE),
    refetchInterval: (query) => (query.state.data?.state.status === 'running' ? 2000 : false),
  })
  const [filter, setFilter] = useState<Filter>('all')
  const [search, setSearch] = useState('')
  const [openId, setOpenId] = useState<number | null>(null)
  const [confirm, setConfirm] = useState(false)
  const [understood, setUnderstood] = useState(false)
  const [results, setResults] = useState<ImportApplyOut | null>(null)

  const rows = useMemo(() => q.data?.rows ?? [], [q.data])
  const pending = (r: ImportRowOut) => r.status !== 'imported'
  const needsCheck = (r: ImportRowOut) => pending(r) && r.flags.some((f) => f.level !== 'info')
  const groups: Record<Filter, (r: ImportRowOut) => boolean> = {
    all: () => true,
    ready: (r) => pending(r) && r.proposal.include,
    check: needsCheck,
    out: (r) => pending(r) && !r.proposal.include,
    imported: (r) => r.status === 'imported',
    error: (r) => r.status === 'error',
  }
  const term = search.trim().toLowerCase()
  const visible = rows.filter(
    (r) => groups[filter](r) && (!term || [r.email, displayName(r), r.proposal.account.username, r.key].some((x) => String(x ?? '').toLowerCase().includes(term))),
  )
  const marked = rows.filter(groups.ready)

  const toggle = useAction((v: { ids: number[]; include: boolean }) => api.post(`${BASE}/select`, { row_ids: v.ids, include: v.include }), {
    success: false,
    invalidate: [KEY],
  })
  const apply = useAction((dry: boolean) => api.post<ImportApplyOut>(`${BASE}/apply`, { row_ids: marked.map((r) => r.id), dry_run: dry }), {
    invalidate: [KEY, ['admin', 'migration-status']],
    errorTitle: 'Falhou',
    onSuccess: (r) => {
      setResults(r)
      setConfirm(false)
      setUnderstood(false)
    },
  })

  if (q.isPending) return <SkeletonCard lines={4} />
  if (q.isError) return <Alert tone="danger">{errorMessage(q.error)}</Alert>
  const data = q.data
  const open = rows.find((r) => r.id === openId) ?? null
  const byId = new Map(rows.map((r) => [r.id, r]))
  const count = (k: Filter) => rows.filter(groups[k]).length

  return (
    <section className="space-y-4">
      <h2 className="pt-2 text-xs font-semibold uppercase tracking-wider text-subtle">1. Importar clientes — lê, revê, edita e importa só o que escolheres</h2>
      <Sources data={data} />
      {!rows.length ? (
        <Card>
          <EmptyState
            compact
            icon={<Search className="size-6" />}
            title={data.state.status === 'running' ? 'A ler…' : 'Nada para rever ainda'}
            description={data.state.status === 'running' ? 'As linhas aparecem aqui quando a leitura terminar.' : 'Carrega o users.db (opcional) e clica em “Ler a GoCardless”.'}
          />
        </Card>
      ) : (
        <Card className="overflow-hidden">
          <CardHeader
            title="Rever"
            description={`${rows.length} clientes · ${marked.length} marcados para importar · ${count('check')} com avisos para verificar`}
            actions={
              <div className="flex flex-wrap gap-2">
                <Button variant="secondary" size="sm" icon={<FlaskConical className="size-4" />} disabled={!marked.length} loading={apply.isPending && apply.variables === true} onClick={() => apply.mutate(true)}>
                  Simular marcados ({marked.length})
                </Button>
                <Button size="sm" icon={<Import className="size-4" />} disabled={!marked.length} onClick={() => setConfirm(true)}>
                  Importar marcados ({marked.length})
                </Button>
              </div>
            }
          />
          <div className="space-y-3 px-5 pt-4 sm:px-6">
            <div className="relative">
              <Search className="pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-subtle" aria-hidden />
              <Input type="search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Procurar por email, nome ou username…" className="pl-10" aria-label="Procurar" />
            </div>
            <div className="flex flex-wrap items-center justify-between gap-2">
              <Pills
                ariaLabel="Filtrar"
                value={filter}
                onChange={(v) => setFilter(v as Filter)}
                items={[
                  { value: 'all', label: 'Todos', count: rows.length },
                  { value: 'ready', label: 'Marcados', count: count('ready') },
                  { value: 'check', label: 'A verificar', count: count('check') },
                  { value: 'out', label: 'De fora', count: count('out') },
                  { value: 'imported', label: 'Importados', count: count('imported') },
                  { value: 'error', label: 'Com erro', count: count('error') },
                ]}
              />
              <div className="flex gap-2">
                <Button size="sm" variant="ghost" loading={toggle.isPending && toggle.variables?.include === true} onClick={() => toggle.mutate({ ids: visible.filter(pending).map((r) => r.id), include: true })}>
                  Marcar visíveis
                </Button>
                <Button size="sm" variant="ghost" loading={toggle.isPending && toggle.variables?.include === false} onClick={() => toggle.mutate({ ids: visible.filter(pending).map((r) => r.id), include: false })}>
                  Desmarcar visíveis
                </Button>
              </div>
            </div>
          </div>
          {results && (
            <div className="px-5 pt-4 sm:px-6">
              <Alert tone={results.results.some((r) => r.status === 'error') ? 'warning' : results.dry_run ? 'info' : 'success'} title={results.dry_run ? 'Simulação — nada foi gravado' : 'Importação concluída'}>
                <p>{results.message}</p>
                <ul className="mt-2 max-h-56 space-y-1 overflow-auto text-xs">
                  {results.results.map((r) => (
                    <li key={r.id} className="flex gap-2">
                      <Badge tone={r.status === 'error' ? 'danger' : r.status === 'simulated' ? 'info' : 'success'}>{r.status === 'simulated' ? 'ok' : r.status === 'error' ? 'erro' : 'feito'}</Badge>
                      <span>
                        <b>{byId.get(r.id)?.email ?? r.id}</b> — {r.result}
                      </span>
                    </li>
                  ))}
                </ul>
                <Button size="sm" variant="ghost" className="mt-2" onClick={() => setResults(null)}>
                  Fechar
                </Button>
              </Alert>
            </div>
          )}
          <div className="mt-4 border-t border-border">
            {!visible.length ? (
              <EmptyState compact title="Nada neste filtro" />
            ) : (
              <Table minWidth={900}>
                <THead>
                  <Th className="w-10">
                    <span className="sr-only">Importar</span>
                  </Th>
                  <Th>Cliente</Th>
                  <Th>GoCardless</Th>
                  <Th>Site antigo</Th>
                  <Th>Avisos / resultado</Th>
                  <Th>Estado</Th>
                  <Th>
                    <span className="sr-only">Ações</span>
                  </Th>
                </THead>
                <tbody>
                  {visible.map((r) => {
                    const subs = r.source.subscriptions
                    const mandate = r.source.mandates.find((m) => m.id === r.proposal.mandate_id) ?? r.source.mandates[0]
                    return (
                      <Tr key={r.id} onClick={() => setOpenId(r.id)}>
                        <Td onClick={(e) => e.stopPropagation()}>
                          <input
                            type="checkbox"
                            aria-label={`Importar ${r.email ?? r.key}`}
                            checked={r.proposal.include}
                            disabled={!pending(r)}
                            onChange={(e) => toggle.mutate({ ids: [r.id], include: e.target.checked })}
                          />
                        </Td>
                        <Td>
                          <p className="font-semibold">{displayName(r)}</p>
                          <p className="text-xs text-muted">{r.email ?? 'sem email'}</p>
                          <p className="text-xs text-subtle">
                            {r.proposal.account.action === 'link' ? `ligar a @${r.source.portal?.username ?? r.proposal.account.username}` : `conta nova @${r.proposal.account.username}`}
                          </p>
                        </Td>
                        <Td>
                          {mandate ? (
                            <div className="flex flex-wrap items-center gap-1 text-xs">
                              <GcBadge status={mandate.status} /> {mandate.bank ?? ''} {mandate.account_ending ? `••${mandate.account_ending}` : ''}
                            </div>
                          ) : (
                            <span className="text-xs text-subtle">sem mandato</span>
                          )}
                          {subs.map((s) => {
                            const prop = r.proposal.subscriptions.find((x) => x.gc_id === s.id)
                            return (
                              <p key={s.id} className={clsx('mt-1 text-xs', prop?.include ? 'font-medium' : 'text-muted')}>
                                {prop?.include ? '✓ ' : ''}
                                {s.name || 'Subscrição'} {formatMoney(s.amount ?? 0)} · {GC_STATUS[s.status]?.[0] ?? s.status}
                              </p>
                            )
                          })}
                        </Td>
                        <Td className="text-xs">
                          {r.source.legacy ? (
                            <>
                              <p>@{String(r.source.legacy.username ?? '')}</p>
                              <p className="text-muted">{String(r.source.legacy.subscription_status ?? '—')}</p>
                            </>
                          ) : (
                            <span className="text-subtle">—</span>
                          )}
                        </Td>
                        <Td>
                          {r.status === 'imported' ? <p className="line-clamp-3 max-w-[20rem] text-xs text-muted">{r.result}</p> : <FlagSummary flags={r.flags} />}
                        </Td>
                        <Td>
                          <RowStatus row={r} />
                          {r.status === 'error' && <p className="mt-1 line-clamp-2 max-w-[14rem] text-xs text-danger">{r.result}</p>}
                        </Td>
                        <Td className="text-right">
                          <Button size="sm" variant="ghost" icon={<Eye className="size-4" />} onClick={() => setOpenId(r.id)}>
                            Rever
                          </Button>
                        </Td>
                      </Tr>
                    )
                  })}
                </tbody>
              </Table>
            )}
          </div>
        </Card>
      )}
      {open && <RowDetail key={open.id} row={open} plans={data.plans} onClose={() => setOpenId(null)} />}
      <Modal
        open={confirm}
        onClose={() => setConfirm(false)}
        title={`Importar ${marked.length} clientes?`}
        footer={
          <>
            <Button variant="secondary" onClick={() => setConfirm(false)}>
              Cancelar
            </Button>
            <Button disabled={!understood} loading={apply.isPending && apply.variables === false} onClick={() => apply.mutate(false)}>
              Importar agora
            </Button>
          </>
        }
      >
        <div className="space-y-4 text-sm">
          <Alert tone="info" title="Antes de cada cliente, a GoCardless é lida outra vez">
            <ul className="mt-1 list-disc space-y-1 pl-4">
              <li>Se alguma coisa mudou desde a leitura (ex.: subscrição cancelada entretanto), esse cliente fica com erro e não é importado a meio.</li>
              <li>“Continua na GoCardless”: nada é cancelado — o cliente continua a ser cobrado como até aqui.</li>
              <li>“Passa já para o portal”: a subscrição na GoCardless é cancelada e o portal cobra na data indicada.</li>
              <li>Importar outra vez não duplica nada.</li>
            </ul>
          </Alert>
          {marked.some(needsCheck) && (
            <Alert tone="warning" title={`${marked.filter(needsCheck).length} dos marcados têm avisos`}>
              <span className="inline-flex items-center gap-1">
                <AlertTriangle className="size-4" /> Revê-os (filtro “A verificar”) antes de continuar.
              </span>
            </Alert>
          )}
          <Checkbox checked={understood} onChange={(e) => setUnderstood(e.target.checked)} label="Revi os marcados e quero importar" />
        </div>
      </Modal>
      {data.state.status === 'done' && !rows.some(pending) && rows.length > 0 && (
        <Alert tone="success" title="Tudo importado">
          <span className="inline-flex items-center gap-1">
            <CheckCircle2 className="size-4" /> Todos os clientes lidos já estão no portal.
          </span>
        </Alert>
      )}
    </section>
  )
}
