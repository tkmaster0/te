import { useState } from 'react'
import { Link } from 'react-router-dom'
import { api } from '../../api/client'
import { useAction } from '../../api/mutation'
import { useConfig } from '../../api/queries'
import { formatMoney } from '../../lib/format'
import { parseEuros } from '../wallet/AmountPicker'
import { Alert, Button, Field, Input, Modal } from '../ui'

type Audience = 'selected' | 'active' | 'all'

/** Dar créditos (carteira) a vários clientes de uma vez — os escolhidos na lista, quem tem serviços ativos, ou todos. */
export function BulkCreditModal({ open, onClose, selected, onDone }: { open: boolean; onClose: () => void; selected: string[]; onDone?: () => void }) {
  const walletOn = useConfig().data?.wallet?.enabled === true
  const [audience, setAudience] = useState<Audience>(selected.length ? 'selected' : 'active')
  const [amount, setAmount] = useState('')
  const [reason, setReason] = useState('')
  const cents = parseEuros(amount)
  const who = audience === 'selected' ? selected.length : null
  const give = useAction(
    () =>
      api.post('/api/admin/wallet/credit', {
        ...(audience === 'selected' ? { user_ids: selected } : { audience }),
        amount_cents: cents,
        reason: reason.trim(),
      }),
    {
      invalidate: [['admin']],
      errorTitle: 'Não foi possível dar os créditos',
      onSuccess: () => {
        setAmount('')
        setReason('')
        onDone?.()
        onClose()
      },
    },
  )
  const options: [Audience, string, string][] = [
    ['selected', `Os escolhidos na lista (${selected.length})`, 'Marca as caixas na lista de utilizadores.'],
    ['active', 'Todos os clientes com serviços ativos', 'Inclui subscrições em período de oferta ou em atraso.'],
    ['all', 'Todas as contas ativas', 'Toda a gente que não está bloqueada.'],
  ]
  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Dar créditos"
      description="Os créditos entram na carteira e são usados sozinhos nas próximas cobranças (ou nos jogos)."
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancelar
          </Button>
          <Button
            loading={give.isPending}
            disabled={!walletOn || !cents || !reason.trim() || (audience === 'selected' && !selected.length)}
            onClick={() => give.mutate()}
          >
            {cents ? `Dar ${formatMoney(cents)}${who ? ` a ${who}` : ''}` : 'Dar créditos'}
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        {!walletOn && (
          <Alert tone="warning" title="A carteira está desligada">
            Liga-a em <Link to="/admin/definicoes?s=carteira" className="font-semibold underline">Definições → Carteira e jogos</Link>. Sem carteira, dá um crédito na
            próxima cobrança na página de cada cliente.
          </Alert>
        )}
        <fieldset className="space-y-2">
          <legend className="mb-1 text-sm font-medium">A quem</legend>
          {options.map(([id, label, hint]) => (
            <label
              key={id}
              className={`flex cursor-pointer gap-3 rounded-xl border p-3 text-sm ${audience === id ? 'border-brand bg-brand-soft/40' : 'border-border'} ${id === 'selected' && !selected.length ? 'opacity-50' : ''}`}
            >
              <input type="radio" name="audience" className="mt-1" checked={audience === id} disabled={id === 'selected' && !selected.length} onChange={() => setAudience(id)} />
              <span>
                <span className="block font-medium">{label}</span>
                <span className="text-xs text-muted">{hint}</span>
              </span>
            </label>
          ))}
        </fieldset>
        <div className="grid gap-3 sm:grid-cols-[140px_1fr]">
          <Field label="Valor por conta (€)">
            <Input inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="5,00" />
          </Field>
          <Field label="Motivo" hint="Aparece no histórico da carteira do cliente.">
            <Input value={reason} onChange={(e) => setReason(e.target.value)} maxLength={200} placeholder="Compensação pela falha de sábado" />
          </Field>
        </div>
      </div>
    </Modal>
  )
}
