# TK Web Services

Portal de adesão e gestão dos serviços da **TKmaster Productions** — a **TK Web Services (TKWS)**, ao estilo de uma consola cloud. Hoje tem o **TKFLIX** (streaming em Jellyfin, camuflado como "TK CDN" para quem não tem convite) e o **TKGPT** (LibreChat, com 2,5 milhões de tokens por mês); serviços novos acrescentam-se **por web**, sem mexer no código:
- registo aberto (ou por convite), login com 2FA;
- **instalação plug-and-play**: `docker compose up -d` e o resto (endereços, chaves, túnel, pagamentos, integrações) é configurado **por web**, num assistente — e pode ser mudado depois em Admin → Configuração;
- **arranque do zero**: a primeira conta registada com `geral@tkmasterproductions.eu` fica logo administradora, sem código OTP;
- **página inicial corporativa**: só a marca, um catálogo curto gerado a partir dos produtos e a entrada na consola;
- **aparência por web** (Admin → Aparência): textos do site e do portal, imagens (logótipo, favicon, imagem da página inicial, fundo das páginas de entrada, imagem de partilha de links, imagem de cada serviço) e os emails enviados aos clientes;
- **faturação por autorização**: o cliente autoriza uma vez (débito direto SEPA pela GoCardless ou cartão pela Stripe) e o portal cobra o valor certo em cada mês, numa só cobrança, ajustado em adesões, mudanças e cancelamentos;
- **clientes antigos sem atrito**: a subscrição GoCardless antiga continua como está e passa sozinha para o portal na primeira alteração do cliente;
- **carteira de créditos**: o saldo (carregamentos únicos) é usado antes de cada cobrança;
- **TKFLIX em beta fechado**: sem convite aparece como "TK CDN — beta testing fechado", com campo para o código;
- **jogos com créditos**: roleta europeia e blackjack (desligados por omissão — ver a nota legal);
- catálogo multi-produto: o TKFLIX e outros serviços teus (manuais, por webhook ou só cobrança);
- provisionamento automático no TKFLIX (Jellyfin, Seerr) e na TV (Dispatcharr: cria, renova, desativa e apaga; password simples gerada sozinha, que o cliente vê e muda no portal);
- programa de bónus por convites;
- **SSO** (fornecedor OIDC + forward-auth): Jellyfin, Seerr, LibreChat e a pilha DUMB — só com subscrição ativa;
- **dois assistentes de IA separados**, um de Faturação e um de Suporte TKFLIX, **cada um com memória própria** das conversas anteriores com cada cliente:
  - no portal;
  - **dentro do Jellyfin** (botão "Ajuda" no jellyfin-web e nas apps Android/iOS/Tizen/webOS; coleção "Ajuda" com QR code nas apps nativas — Android TV, Swiftfin, Moonfin, Roku…);
  - por WhatsApp;
  - nas issues do Seerr.

**Tudo num contentor (AIO, como o DUMB), independente do TKFLIX:**
- O contentor `tk-web-services` tem o portal (API, fila de jobs e tarefas), a **sua própria base de dados** (PostgreSQL, só acessível dentro do contentor), as cópias diárias e o **túnel Cloudflare**. Sistema de ficheiros só de leitura, sem privilégios.
- Um só volume (`tkws_data` → `/data`) guarda a base de dados, os segredos gerados e as cópias.
- Liga-se ao TKFLIX só pelas APIs de que precisa: Jellyfin, Seerr, Bazarr e Dispatcharr.
- Se o TKFLIX estiver em baixo, os clientes continuam a entrar, pagar e gerir os outros serviços. As ações no TKFLIX ficam em fila e são repetidas quando ele voltar.

Stack: **FastAPI + PostgreSQL** e **React + TypeScript + Tailwind**.

---

## 1. Como funciona a faturação

| Tema | Como o portal trata |
|---|---|
| **Autorização única** | Para aderir, o cliente autoriza o pagamento **uma vez**: mandato de débito direto SEPA (GoCardless) ou cartão (Stripe). A partir daí é o portal que decide quanto cobrar: o valor de cada mês é calculado a partir do que o cliente tem ativo e ajustado sozinho quando adere, muda de plano ou cancela (com pro-rata). Não há carregamentos mensais nem nova autorização (`BILLING_REQUIRE_METHOD=true`). |
| **Uma cobrança por mês** | Cada cliente tem um *dia de faturação* (1–28), fixado na primeira subscrição. Todos os serviços renovam nesse dia e são cobrados juntos: uma taxa de transação e uma linha no extrato. Os planos anuais renovam no dia de faturação do mês respetivo. |
| **Aderir a meio do mês** | Paga-se a pro-rata até ao dia de faturação. A primeira compra é cobrada logo (`CHARGE_FIRST_PURCHASE_IMMEDIATELY`). |
| **Upgrade** | Imediato: o cliente passa logo a ter o plano novo. O tempo não usado do plano antigo vira crédito e o novo é cobrado em pro-rata; a diferença entra na próxima cobrança (`PRORATION_CHARGE=next_invoice`) ou é cobrada logo (`immediate`). |
| **Downgrade** | Na renovação: até ao fim do período já pago o cliente mantém o plano atual (e o acesso); na renovação o valor passa a ser o do plano novo e o acesso ao que já não se aplica (ex.: TV) é retirado. Sem crédito nem cobrança no momento. O cliente pode desfazer a descida agendada escolhendo de novo o plano atual. As migrações do admin "já" continuam imediatas. |
| **Valores pequenos** | Abaixo de `BILLING_MIN_CHARGE_CENTS` o valor passa para a cobrança seguinte, para não pagar uma taxa fixa por 0,40 €. |
| **Falhas** | Novas tentativas em `BILLING_RETRY_DAYS` (3 e 4 dias). O acesso mantém-se durante `GRACE_PERIOD_DAYS`; depois o serviço é suspenso e volta assim que a cobrança é paga. Cada tentativa tem uma chave de idempotência (`inv-<cobrança>-<tentativa>`), e a cobrança é gravada antes de se falar com o fornecedor, por isso nunca há cobranças duplicadas. |
| **Fornecedores plugáveis** | Admin → Fornecedores: desligar um fornecedor, deixar de aceitar métodos novos, ou trocar de conta (nova conta GoCardless/Stripe). Os métodos afetados ficam "inutilizáveis" e os clientes recebem email para escolher outro, com `PAYMENT_METHOD_GRACE_DAYS` de prazo. As cobranças passam automaticamente para outro método válido do cliente. Não é preciso mexer em código. |
| **Mudanças de preço** | Admin → Planos → "Mudar preço": só para clientes novos, ou também para os atuais a partir de uma data. Para os atuais escolhes se o portal avisa: **com aviso**, email automático e aviso na área de cliente, e aumentos com pelo menos `PRICE_CHANGE_NOTICE_DAYS` dias; **sem aviso**, nada é enviado nem mostrado — avisas tu, por fora (e o prazo é contigo). O preço fica fixado em cada subscrição, por isso editar um plano nunca mexe em quem já paga. |
| **Migrações** | Admin → Migração: move todos os clientes de um plano para outro, na renovação ou já (com pro-rata), mantendo ou não o preço, com pré-visualização (dry run). Inclui a importação das subscrições GoCardless do site antigo, que reaproveita os mandatos e não obriga os clientes a fazer nada. |
| **Outros produtos** | Cada produto tem um tipo de entrega:<br>• `streaming`: Jellyfin, Seerr e IPTV do plano;<br>• `manual`: o admin recebe um email, ativa o serviço e preenche os dados de acesso;<br>• `webhook`: o portal chama um URL teu com assinatura HMAC `X-TK-Signature`;<br>• `none`: só cobrança. |
| **Bónus de convites** | Enquanto tiveres 3 convidados a pagar (2 se foste convidado pelo admin), os serviços com bónus deixam de ser cobrados. Quando deixam de pagar, a cobrança é retomada. O bónus aparece como linha negativa na cobrança. |
| **Carteira primeiro** | Em cada cobrança o saldo da carteira paga primeiro; só o que faltar é cobrado ao método de pagamento, na mesma cobrança. Ver secção 1.1. |
| **Retries do fornecedor** | Uma recusa com nova tentativa automática da GoCardless (`will_attempt_retry`, ex.: Success+) **não** é uma falha: a cobrança fica "em curso" e o serviço mantém-se. Só a desistência final do fornecedor conta. Depois disso correm as tentativas do portal e a tolerância; **o serviço só é suspenso quando já não há nenhuma tentativa por fazer**. |
| **Emails** | Sem emails de confirmação: subscrever, mudar, cancelar e reativar não geram email (o cliente vê tudo no portal). **Pagamento recebido** só quando foi o cliente a pagar no portal ("Pagar" uma cobrança ou carregar a carteira); as cobranças automáticas ao método autorizado (mensalidade, novas tentativas, adesões e upgrades) não enviam email. Só se envia o necessário: pagamento falhado, método de pagamento a trocar, serviço suspenso/terminado por falta de pagamento, fim do bónus (a cobrança volta), mudança de preço/migração de plano e os de segurança (confirmar email, recuperar password). **Ao criar conta** é enviado um **código de 6 dígitos (OTP)**, que o cliente escreve no aviso do portal (válido 30 min, 5 tentativas; o mesmo email traz também um link válido 48 h). A GoCardless envia os avisos prévios de débito que a lei SEPA exige; o Stripe não envia recibos (o portal não os pede). |

### 1.1 Carteira de créditos

- **1 crédito = 1 €.** O saldo é usado **primeiro** em todas as cobranças (renovações, pro-ratas, adesões). O que faltar é cobrado ao método de pagamento na mesma cobrança — nunca há duas cobranças.
- **Carregamento único:** a partir de 5 € (`WALLET_MIN_TOPUP_CENTS`). Com um método guardado é cobrado logo; sem método, abre a página do fornecedor. Um carregamento recusado é anulado (não fica em dívida). Com débito direto, o saldo entra quando o banco confirma.
- **Carregamento mensal: desligado por omissão** (`WALLET_MONTHLY_ENABLED=false`). Os serviços são cobrados pelo método autorizado; a carteira serve para carregamentos únicos (ex.: jogos) e créditos dados pelo admin. Com `WALLET_MONTHLY_ENABLED=true` volta a existir o carregamento mensal (somado à cobrança do dia de faturação, com a opção de saltar o mês em que o saldo já chega), as contas só-carteira (`WALLET_ONLY_FOR_NEW_USERS=true`) e a passagem em bloco em Admin → Migração (`cli wallet-convert`). A migração 0005 desliga os carregamentos mensais que existissem.
- **Pro-ratas:** adesões e mudanças de plano a meio do mês continuam a gerar as linhas pro-rata; são pagas pela carteira na cobrança seguinte (ou logo, se houver saldo).
- **Garantias:** razão imutável (`wallet_transactions`) com chaves de idempotência, bloqueio da carteira em cada movimento, saldo reservado a uma cobrança devolvido se ela for anulada, estornos retirados da carteira (um saldo negativo entra na cobrança seguinte), e o saldo novo paga logo cobranças em atraso.
- Admin → Utilizador → Carteira: saldo, movimentos e ajustes manuais (positivos ou negativos, com motivo).
- **Dar créditos a vários de uma vez:** Admin → Utilizadores → **Dar créditos** — aos escolhidos na lista (caixas), a todos os clientes com serviços ativos ou a todas as contas ativas, com um valor por conta e um motivo que aparece no histórico do cliente (ex.: compensação por uma falha). Os créditos pagam logo cobranças em atraso. Sem a carteira ligada, usa "crédito na próxima cobrança" na página do cliente.

### 1.2 Jogos (roleta europeia e blackjack)

> ⚠️ **Nota legal:** em Portugal, jogos de fortuna ou azar online com prémios com valor económico precisam de licença do SRIJ (Decreto-Lei 66/2015). Os créditos pagam serviços, por isso têm valor económico. Os jogos estão **desligados por omissão** (`GAMES_ENABLED=false`) — confirma a situação legal antes de os ligar.

- **Roleta europeia** (um zero): fichas de 0,20 € a 10 €, aposta mínima de 1 € por jogada. Plenos, cavalos, transversais, quadrados, seisenas, colunas, dúzias e apostas simples, com os pagamentos clássicos.
- **Blackjack:** 6 baralhos, dealer fica nos 17 suaves, blackjack paga 3:2, seguro 2:1, dobrar e dividir (até 4 mãos). Aposta mínima 1 €.
- **Provably fair:** o hash da semente do servidor é mostrado antes de jogar; ao trocar de semente, a antiga é revelada e todos os resultados podem ser recalculados (HMAC-SHA256).
- **Jogo responsável:** confirmação de maioridade, limite diário de perdas (do sistema e um mais baixo escolhido pelo cliente; subir só conta no dia seguinte), pausas de 24 h a 6 meses. Os prémios ficam na carteira e pagam serviços (e cobranças em atraso) — não são levantados.

### 1.3 Serviços em beta fechado (TKFLIX → "TK CDN")

- Um produto com **"Beta fechado"** (Admin → Produtos) só aparece com o nome verdadeiro e só pode ser subscrito por quem o tem desbloqueado. Os outros veem o nome genérico (`TK CDN`, "Beta testing fechado") desativado, com um campo para meter um código de convite.
- **Desbloqueia-se** ao criar conta com um convite de um cliente do TKFLIX (ou de admin), ou mais tarde, na Loja, com um código. A página inicial com `?convite=CÓDIGO` também mostra o TKFLIX.
- Nos convites do admin escolhes o que desbloqueiam (todos os produtos em beta, um produto, ou só a conta).
- Os clientes existentes e migrados ficam com o TKFLIX desbloqueado (migração 0004 / `import-legacy`). O assistente de faturação também não revela o TKFLIX a quem não o tem.

A página do Jellyfin (Custom Pages) só gere a **subscrição de streaming (TKFLIX)**. Os links que abre criam uma sessão limitada ao streaming. Tudo o resto (outros serviços, métodos de pagamento, conta) exige login normal no portal.

---

### Aparência (textos, imagens e emails)
**Admin → Aparência**, sem mexer no código:
- **Textos:** página inicial, entrar/registo/password, menu e cabeçalhos da área de cliente, marca e o título/descrição do separador. Cada texto mostra o original; escreve por cima e guarda (vazio volta ao original). `{app}` e `{empresa}` são trocados pelos nomes.
- **Imagens:** logótipo (site, portal e emails), favicon, imagem da página inicial, fundo das páginas de entrada e imagem de partilha (o que aparece ao partilhar o link no WhatsApp/Facebook — o título, a descrição e esta imagem vão no próprio HTML, por isso funcionam mesmo sem JavaScript). A imagem de cada serviço carrega-se no produto (Produtos & planos). Ficam na base de dados — entram nas cópias diárias.
- **Emails:** assunto, título, texto e botão de cada email, com pré-visualização. Usam Jinja (`{{ username }}`, `{% if code %}`…) num ambiente isolado; um texto com erro nunca impede o envio (usa o original).
- Anúncio, FAQ e links (termos, privacidade, suporte) continuam em Admin → Definições → Conteúdo do site.

Para tornar mais um texto editável: acrescenta-o a `frontend/src/content/texts.ts` e usa `t('chave')` no componente.

## 2. Assistentes de IA

Há dois agentes, com a separação garantida no código e não só nas instruções.

| | **Agente de Faturação** | **Agente de Suporte** |
|---|---|---|
| Trata de | subscrições, planos, preços, cobranças, métodos de pagamento, pro-ratas, bónus | Jellyfin, legendas (Bazarr), reprodução/transcodificação, apps e dispositivos, Quick Connect, pedidos e issues do Seerr |
| Nunca | fala de funcionalidades ou conteúdos do streaming | fala de preços, pagamentos ou planos |
| Ferramentas | resumo de faturação, histórico, catálogo, orçamento, mudar/aderir, cancelar, reativar, links do portal | procurar título, detalhes técnicos, procurar/descarregar/sincronizar legendas, descarga automática (coleção Bazarr), diagnóstico de reprodução, dispositivos, Quick Connect, pedidos, issues |

**Garantias de separação:**
- Cada agente só recebe as suas ferramentas, e o runtime recusa executar qualquer outra.
- Cada agente só vê as suas mensagens. Numa transferência, o outro agente recebe só o pedido do cliente e um resumo, nunca os dados que o primeiro consultou.
- A base de conhecimento e as instruções são separadas por agente.
- As regras fixas de cada agente estão no código. O admin edita as instruções (tom, procedimentos), mas não consegue retirar a separação.

**Ações sensíveis** (cancelar, mudar de plano, aderir, reativar, autorizar Quick Connect) nunca são executadas pelo modelo. Ficam pendentes 30 minutos até o cliente confirmar: botão no portal ou no Jellyfin, botão ou "SIM" no WhatsApp. No Jellyfin, a faturação só vê e gere o streaming.

**Aprendizagem** — tudo supervisionado:
1. **Factos vivos:** os produtos, planos, preços, regras de cobrança e integrações são lidos em cada conversa. Um serviço novo criado no painel fica logo conhecido.
2. **Conhecimento promovido:** no painel, promoves uma boa resposta (ou a correção de uma má) a artigo.
3. **Sugestões automáticas:** conversas escaladas, resolvidas ou com 👎 geram rascunhos de artigo, que só entram em uso depois de os aprovares.

**Memória (por cliente e por agente):**
- Cada agente lembra-se das conversas anteriores **que ele próprio** teve com o cliente — o de Faturação nunca vê a memória nem as mensagens do de Suporte, e vice-versa.
- 10 minutos depois de uma conversa, um job resume-a (modelo rápido) e junta-a às notas desse agente sobre o cliente (preferências, aparelhos, problemas recorrentes, pendentes). Nunca guarda passwords, códigos, IBAN, cartões ou tokens.
- Enquanto o resumo não corre, o agente recebe os últimos excertos das conversas anteriores com ele.
- Vale em todos os canais (portal, Jellyfin, WhatsApp, Seerr). O cliente vê as notas e pode pedir para esquecer em Ajuda → "Esquecer conversas anteriores".

**Canais:**
- **Chat no portal:** botão "Ajuda" e página `/app/ajuda` (link curto: `/ajuda`).
- **Chat dentro do Jellyfin:** botão "Ajuda" (JavaScript Injector), separador "Ajuda" da Custom Page e, nas apps nativas, a coleção "Ajuda" com QR code para o chat no telemóvel (ver 4 → TKFLIX dentro do Jellyfin).
- **WhatsApp:** o cliente liga o número em Conta → WhatsApp, com um código `TK-XXXXXX`.
- **Issues do Seerr:** o agente de suporte analisa cada issue nova. Por exemplo, se faltam legendas procura-as e descarrega-as; se estão dessincronizadas sincroniza-as. Responde num comentário e fecha a issue se ficou resolvida.

**Modelo:** qualquer modelo com *tool calling*, através do LiteLLM: Claude, OpenAI, Gemini, Ollama local, um proxy LiteLLM, etc. Configura-o em **Admin → Configuração → Assistente de IA** (ou `ASSISTANT_*` num `.env`). Com o Langfuse ligado (mesma página, opções avançadas: endereço e chaves), cada conversa e chamada de ferramenta fica visível no Langfuse.

**Configuração** (tudo também em Admin → Configuração; os nomes abaixo são as variáveis equivalentes):
1. **Modelo:** `ASSISTANT_ENABLED=true`, `ASSISTANT_MODEL=…` e `ASSISTANT_API_KEY` ou `ASSISTANT_API_BASE`. Opcionalmente, `ASSISTANT_FAST_MODEL` (mais barato, para encaminhar mensagens, gerar rascunhos e resumir a memória) e `ASSISTANT_EMBEDDING_MODEL`.
2. **Bazarr:** `BAZARR_URL` e `BAZARR_API_KEY`. Para a descarga automática por coleção, põe em `BAZARR_AUTO_COLLECTION_ID` o id da coleção que o teu plugin Bazarr vigia (está no URL da coleção no Jellyfin). Sem Bazarr, a pesquisa de legendas usa os fornecedores do próprio Jellyfin; a sincronização precisa do Bazarr.
3. **Seerr:** nada a configurar no Seerr — o portal lê as issues pela API a cada 2 minutos (`SEERR_POLL_ENABLED=true`, por omissão), por isso o único webhook do Seerr fica livre (ex.: para o Moonfin). Opcional, para resposta imediata se o webhook estiver livre: Notificações → Webhook, URL `https://tkws.exemplo.pt/api/webhooks/seerr`, *Authorization Header* = `SEERR_WEBHOOK_SECRET`, tipos "Issue Reported" e "Issue Comment". As duas formas podem estar ligadas ao mesmo tempo: cada comentário só é respondido uma vez.
4. **WhatsApp**, uma de duas opções:
   - **Cloud API (Meta):**
     1. Cria uma app WhatsApp Business.
     2. Webhook `https://tkws.exemplo.pt/api/webhooks/whatsapp`, campo `messages`, verify token = `WHATSAPP_CLOUD_VERIFY_TOKEN`.
     3. Define `WHATSAPP_PROVIDER=cloud`, `WHATSAPP_CLOUD_TOKEN`, `WHATSAPP_CLOUD_PHONE_NUMBER_ID` e `WHATSAPP_CLOUD_APP_SECRET` (valida a assinatura).
   - **Evolution API (Baileys):**
     1. Cria a instância.
     2. Webhook `https://tkws.exemplo.pt/api/webhooks/evolution?token=<EVOLUTION_WEBHOOK_TOKEN>`, evento `MESSAGES_UPSERT`.
     3. Define `WHATSAPP_PROVIDER=evolution`, `EVOLUTION_URL`, `EVOLUTION_API_KEY` e `EVOLUTION_INSTANCE`.

   Em ambos os casos, define `WHATSAPP_NUMBER` para o portal mostrar o link wa.me.
5. **Painel Admin → Assistente:** estado da configuração, instruções com versões e rollback, base de conhecimento (com rascunhos por aprovar), e conversas com cada chamada de ferramenta, notas e "promover a conhecimento".

---

## 3. Instalação (contentor isolado)

### 3.1 Onde corre: mesma máquina do TKFLIX ou outra
A pasta do projeto tem tudo o que o portal precisa para correr sozinho: a base de dados própria, as cópias diárias e o **túnel Cloudflare** (o `cloudflared` corre dentro do contentor do portal e é configurado por web). Não depende do cloudflared nem do Traefik do DUMB para estar online.

| | **A — mesma máquina (agora)** | **B — outra máquina** |
|---|---|---|
| Arranque | `docker compose up -d` (opcional: `COMPOSE_FILE=docker-compose.yml:docker-compose.tkflix-link.yml` num `.env`, para a rede com o DUMB) | `docker compose up -d` |
| Público → portal | túnel embutido: hostname → `http://localhost:8000` | igual |
| Portal → Jellyfin/Seerr/Bazarr/Dispatcharr (Definições) | `http://host.docker.internal:<porta>` (portas publicadas no anfitrião) ou `http://DUMB:<porta>` (rede `tkflix-link`) | URLs `https://` públicas (+ Cloudflare Access para as APIs fechadas) |
| Forward-auth do DUMB → portal | `https://tkws.tkflix.eu/auth/verify` (ou `http://tk-web-services:8000/…`) | `https://tkws.tkflix.eu/auth/verify` |
| Jellyfin/Seerr/LibreChat → portal (OIDC) | `https://tkws.tkflix.eu` | igual |

**Rede partilhada (só no modo A).** O contentor da TK Web Services **não entra na rede do DUMB**. `docker-compose.tkflix-link.yml` junta-o a uma rede pequena, a `tkflix-link`, onde está também o DUMB com o alias `DUMB`. O `deploy/primeiro-arranque.sh` cria a rede e liga o DUMB; para a ligação sobreviver a recriações do DUMB, acrescenta `deploy/dumb/docker-compose.dumb-network.yml` ao compose dele. O portal não vê mais nenhum contentor do stack, e o TKFLIX não vê a base de dados do portal.

**APIs do TKFLIX pela internet (modo B).**
- **Jellyfin e Seerr:** já são públicos (`https://tkflix.eu`, `https://pedidos.tkflix.eu`); a API key vai no cabeçalho, por HTTPS.
- **Bazarr e APIs que não devem ficar abertas:**
  1. Cria um hostname só para a API no túnel do DUMB (ex.: `bazarr-api.tkflix.eu`; ver `deploy/dumb/cloudflared-ingress.yml`).
  2. Protege-o com o **Cloudflare Access**: Application → política **Service Auth** com um *service token*.
  3. Põe o token em Definições → Acesso remoto ao TKFLIX. O portal só o envia por `https` e só para os hosts do TKFLIX configurados.
- **Rede privada (alternativa):** com Tailscale/WireGuard entre as duas máquinas, instalado no anfitrião, basta pôr os IPs privados nas URLs (`http://100.x.y.z:6767`). Os contentores saem pela rede do anfitrião.
- **Com o TKFLIX em baixo ou inacessível:** o portal continua a funcionar; as ações no Jellyfin/Seerr ficam na fila e são repetidas.

**Cloudflare (os dois modos).** O Jellyfin, o Seerr, o LibreChat e o Traefik do DUMB falam com o portal pela URL pública, de servidor para servidor. Se tiveres *Bot Fight Mode* ou regras WAF, cria uma regra **Skip** no hostname do portal para `/.well-known/*`, `/oidc/*`, `/auth/verify` e `/api/webhooks/*`.

`cli check-links` testa todas as ligações a partir do portal (o script de arranque corre-o):

```bash
docker compose exec tkws /entrypoint.sh cli check-links
```

### 3.1.1 Tráfego de fora para o portal
```
Internet → Cloudflare → cloudflared (dentro do contentor do portal) → http://localhost:8000
```
1. Zero Trust → Networks → Tunnels → **Create a tunnel** (Cloudflared) → copia o token.
2. No túnel: Public Hostname → `tkws.tkflix.eu` → Service **HTTP** → **`localhost:8000`**.
3. Põe o token num `.env` (`CLOUDFLARE_TUNNEL_TOKEN=…`) antes do `docker compose up -d` — o túnel arranca com o contentor — ou cola-o mais tarde em Admin → Configuração → Túnel. O portal vigia o `cloudflared`, mostra o estado e o registo, e volta a ligá-lo se cair. As mensagens do túnel aparecem em `docker logs tk-web-services`. Rede que bloqueia UDP 7844? `CLOUDFLARE_TUNNEL_PROTOCOL=http2`.

O portal também publica a porta `8090` no anfitrião (`TKWS_BIND`/`TKWS_PORT`), para o primeiro acesso, administração local ou um reverse proxy teu (`deploy/reverse-proxy/`). Com o túnel a funcionar podes limitá-la ao anfitrião com `TKWS_BIND=127.0.0.1`.

**Forward-auth nas UIs do DUMB:**
1. Copia `deploy/dumb/traefik-tkws-auth.yml` para `…/traefik/dynamic/` na configuração do DUMB (dentro do contentor: `/config/traefik/dynamic/`) e troca o domínio. O Traefik carrega-o sozinho.
2. Nos routers a proteger, acrescenta `middlewares: [tkws-admin@file]`, ou escolhe-o no Traefik Proxy Admin.
3. As moradas usam a URL pública, por isso continuam a funcionar quando o portal mudar de máquina.

**Alternativa só para o modo A:** publicar o portal pelo túnel e pelo Traefik do DUMB, com `deploy/dumb/traefik-tkws-rota.yml` e o hostname → `HTTP localhost:18080` no túnel do DUMB. Funciona, mas o portal fica dependente do DUMB para estar online.

### 3.1.2 Mudar o portal para outra máquina (A → B)
1. Na máquina antiga, guarda a `SECRET_KEY` (cifra os segredos guardados por web) e faz uma cópia final:
   ```bash
   docker exec tk-web-services cat /data/secrets/secret_key; echo
   docker exec tk-web-services pg_dump -h /tmp -U tkws -Fc -f /data/backups/final.dump tkws
   docker cp tk-web-services:/data/backups/final.dump .
   ```
2. Na máquina nova: a pasta do projeto, `final.dump` e um `.env` com `SECRET_KEY=<a de cima>` (e o token do túnel).
3. `docker compose up -d`, repõe a cópia (secção 3.2).
4. Em Admin → Definições, troca os endereços do Jellyfin/Seerr/TV/Bazarr pelos públicos (e o Cloudflare Access, se usares). O túnel continua o mesmo — o hostname não muda.
5. No DUMB: se usavas a morada interna no forward-auth, troca-a pela pública e tira o DUMB da rede (`docker network disconnect tkflix-link DUMB`).

### 3.2 Base de dados (própria)
- **Onde está:** dentro do próprio contentor (PostgreSQL da imagem), com os dados em `/data/postgres` no volume `tkws_data`. Só escuta em `127.0.0.1` dentro do contentor — nada exposto.
- **Password e `SECRET_KEY`:** geradas no primeiro arranque e guardadas em `/data/secrets`. Um `TKWS_DB_PASSWORD`/`SECRET_KEY` num `.env` passa a ser o valor guardado. Um `DATABASE_URL` no `.env` usa uma base de dados externa em vez da interna.
- **Cópias:** uma por dia em `/data/backups` (a primeira 10 minutos depois de arrancar), guardadas `TKWS_BACKUP_KEEP_DAYS` dias (14 por omissão). Para as trazer para fora: `docker cp tk-web-services:/data/backups ./backups`.
- **Repor uma cópia:**
  ```bash
  docker cp tkws-AAAAMMDD-HHMM.dump tk-web-services:/tmp/r.dump
  docker exec tk-web-services pg_restore -h /tmp -U tkws -d tkws --clean --if-exists /tmp/r.dump
  docker restart tk-web-services
  ```
- **Faz também cópia da `SECRET_KEY`** (`docker exec tk-web-services cat /data/secrets/secret_key`): sem ela, os segredos guardados por web ficam ilegíveis.

### 3.3 Arrancar (um só comando)
```bash
docker compose up -d
```
É tudo. Na primeira vez:
1. a imagem é construída a partir desta pasta (alguns minutos; `pull_policy: build`, nunca é descarregada);
2. o contentor cria a base de dados, gera a password e a `SECRET_KEY` (volume `tkws_data` — não é preciso `.env`) e, com `CLOUDFLARE_TUNNEL_TOKEN` no `.env`, liga o túnel;
3. as migrações correm e ficam criados o TKFLIX (em beta fechado) e o TKGPT (sem preço — defines o plano por web).

Abre **`http://<IP do servidor>:8090/registar`** e cria a conta com o email **`geral@tkmasterproductions.eu`**: fica logo administradora, **sem código OTP** (nem convite), e o **assistente de configuração** abre sozinho. Este atalho só existe enquanto não houver nenhum administrador — faz este registo logo a seguir ao primeiro arranque. Para mais emails de administrador: Admin → Configuração → Geral → "Emails de administrador" (esses passam a admin depois de confirmarem o email).

A conta de testes `testews` já não é criada por omissão (`TEST_ADMIN_ENABLED=true` num `.env` volta a criá-la).

| Passo | O que defines |
|---|---|
| A tua conta | Confirmação da conta de administrador |
| Endereço público | `PUBLIC_URL`, registo aberto/convite, domínio da sessão |
| Túnel Cloudflare | Só o token — o `cloudflared` corre dentro do portal. No painel do túnel: Public Hostname → **`http://localhost:8000`** |
| Email | SMTP, com botão de email de teste |
| Pagamentos | GoCardless (token, webhook) e Stripe (chaves; **o webhook é criado automaticamente**) — links diretos para cada página |
| Jellyfin, Seerr, TV | Endereços e API keys, com botão "Testar ligação" e atalhos "mesma máquina" |
| SSO | Cria os clientes OIDC; página Jellyfin com o que colar nos plugins |
| Serviços e planos | Produtos, preços e automações (webhooks) — nada a criar na GoCardless/Stripe |
| Clientes antigos | Importação com revisão: GoCardless + `users.db`, editável cliente a cliente |

Tudo fica guardado na base de dados (segredos cifrados com a `SECRET_KEY`), é aplicado na hora e pode ser mudado em **Admin → Configuração** — incluindo sessões e cookies, validade dos tokens SSO, faturação, carteira, jogos, assistente (temperatura, limites, Langfuse), Seerr, Bazarr, WhatsApp e nível de logs. Só ficam fora a `SECRET_KEY` e a ligação à base de dados (gerados no primeiro arranque). Um `.env` continua a funcionar (tem prioridade sobre os valores por omissão; o que for definido por web tem prioridade sobre o `.env`). Instalações antigas com `.env` não precisam de mudar nada — e o `CLOUDFLARED_TOKEN` antigo passa a ser usado pelo túnel embutido.

Sem acesso pela rede local? Põe `CLOUDFLARE_TUNNEL_TOKEN=…` num `.env` antes do `up` e o túnel arranca logo (o portal atende no túnel em `localhost:8000` e também em `8090`, `8080` e `80`, para túneis antigos). Depois do túnel ligado podes fechar a porta 8090 ao exterior: `TKWS_BIND=127.0.0.1` num `.env`. Imagem já feita em vez de construir: `TKWS_IMAGE`/`TKWS_PULL_POLICY` e `.github/workflows/imagem.yml`. Problemas com a imagem ou o túnel: `deploy/PRIMEIRO-ARRANQUE.md`.

### Pagamentos
Configurados em Admin → Definições (ou no assistente):
- **GoCardless:** access token (Developers → Access tokens) e webhook `https://<portal>/api/webhooks/gocardless` (o URL aparece pronto a copiar, com o link para a página de criação). O portal usa mandatos (Billing Requests) e pagamentos únicos — não cria subscrições na GoCardless.
- **Stripe:** secret key e publishable key; o botão **"Criar webhook automaticamente"** cria o webhook com os eventos certos e guarda o segredo. O portal guarda o cartão (SetupIntent) e cobra *off-session* — não usa o Stripe Billing, por isso não há produtos nem preços a criar no Stripe.
- **Preços:** só no portal (Admin → Produtos & planos). Mudar um preço avisa os clientes atuais com a antecedência definida.
- **Um só fornecedor:** basta deixar o outro sem credenciais.

### Migrar as subscrições Stripe (TKGPT)
```bash
docker compose exec tkws /entrypoint.sh cli import-stripe --dry-run
docker compose exec tkws /entrypoint.sh cli import-stripe
```
Também em Admin → Migração → "Importar do Stripe". Para cada subscrição ativa: o cartão já guardado no Stripe passa a método do cliente (cobranças seguintes fora de sessão, sem pedir nada ao cliente), o cliente é encontrado pelo email (ou é criada uma conta), o plano é encontrado pelo `stripe_price_id` (ou criado no produto `tkgpt` com o mesmo preço), o portal cobra na data em que o Stripe ia renovar e a subscrição Stripe é cancelada sem pro-rata. Idempotente.

### Migrar do site antigo (Admin → Migração)
A **GoCardless é a fonte de verdade** (pode ter havido mandatos novos, cancelamentos feitos à mão, mudanças de valor…); o `users.db` do site antigo **completa** (username, password, Jellyfin, TV, quem convidou).

1. **Ler.** Carrega o `users.db` (opcional) e clica em **Ler a GoCardless**. O portal lê *todos* os clientes, mandatos (com banco e últimos dígitos), subscrições — **incluindo as canceladas** — e os últimos pagamentos de cada uma, e cruza com o `users.db` (pelo cliente GoCardless, pelo mandato ou pelo email) e com as contas que já existem no portal. Fica uma linha por cliente.
2. **Rever.** Cada linha traz uma proposta e avisos para verificar: email diferente entre a GoCardless e o site antigo, cliente sem mandato ativo, subscrição cancelada na GoCardless mas "Ativa" no site antigo, último pagamento falhado, preço diferente do plano, plano sem correspondência, username já ocupado, email repetido… Filtros (marcados, a verificar, de fora, importados, com erro) e pesquisa. **Rever** abre o detalhe lado a lado — *o que foi lido* (GoCardless + `users.db`) e *o que vai ser importado* — e tudo é editável: criar conta ou ligar a uma existente, email, username, nome, mandato a usar, e por subscrição: importar ou não, plano, preço, próxima cobrança e **quem cobra** (continua na GoCardless, ou passa já para o portal e é cancelada na GoCardless); ligar Jellyfin/TV, oferta até uma data e uma nota. "Repor proposta" volta ao calculado.
3. **Importar.** Marca as linhas (uma a uma ou "marcar visíveis"), **Simular** (nada é gravado nem tocado na GoCardless) e **Importar**. Antes de cada cliente a GoCardless é **lida outra vez**: se algo mudou desde a leitura (ex.: subscrição cancelada entretanto, mandato cancelado), esse cliente fica com erro e nada dele é gravado. Importar de novo não duplica nada.

Ler de novo atualiza tudo com o estado atual da GoCardless e **mantém as edições** ainda por importar. A password antiga e a password de TV do `users.db` ficam cifradas no portal e nunca são mostradas. O antigo "modo rápido" (importar o `users.db` e ligar todas as subscrições de uma vez, sem revisão) continua disponível em baixo, na mesma página. **Estado** mostra quem continua na GoCardless e quem já passou para o portal.

**Passagem automática para o modelo novo.** Na primeira alteração do cliente — aderir a outro serviço, mudar de plano, cancelar ou reativar — a subscrição antiga passa sozinha para o portal, sem confirmação nem ação do cliente:
- o período já pago termina na próxima data de cobrança da GoCardless (ou um ciclo depois, se esse débito já foi submetido ao banco);
- a subscrição é cancelada na GoCardless e passa a ser cobrada pelo portal com o mesmo mandato, preço e dia do mês;
- a alteração é feita a seguir, já com pro-rata (a pré-visualização mostra o valor certo antes de confirmar).

Enquanto ficam na GoCardless, os webhooks e uma verificação a cada 6 h mantêm o portal a par: data da próxima cobrança, débitos falhados (tolerância e suspensão como no portal; as novas tentativas da GoCardless são respeitadas) e cancelamentos feitos no banco. O admin pode passar uma subscrição (ou todas) já, no mesmo ecrã.

Pela linha de comandos (opcional): `docker compose exec tkws /entrypoint.sh cli import-legacy --sqlite /caminho/users.db [--dry-run] [--convert-now]`.

---

## 4. SSO (Jellyfin, Seerr, LibreChat e a pilha DUMB)

A TK Web Services é o fornecedor de identidade (OIDC interno, sem Google e afins). Descoberta: `https://tkws.exemplo.pt/.well-known/openid-configuration`.

**Regras comuns:**
- **Só com subscrição ativa:** cada app exige um acesso (`feature:jellyfin`, `feature:seerr`, `product:tkgpt`). Sem ele o login é recusado; o `userinfo` e a renovação de tokens também deixam de funcionar quando a subscrição acaba, e os refresh tokens dessa app são revogados na reconciliação.
- **Email:** vai no `id_token`/`userinfo` (`email`, `email_verified`). O Seerr e o LibreChat ligam as contas pelo email, por isso o portal **só deixa entrar com o email confirmado** e mantém o email do Seerr igual ao da conta.
- **Clientes predefinidos:** Admin → SSO → "Clientes predefinidos" (ou `cli oidc-presets`) cria/atualiza `jellyfin`, `seerr` e `librechat` a partir de `JELLYFIN_PUBLIC_URL`, `SEERR_PUBLIC_URL` e `LIBRECHAT_URL`, e mostra os segredos uma vez.

**Transição sem ninguém ficar sem acesso:**
- **Clientes migrados/atuais** (`jellyfin_password_login=true`): continuam a entrar no Jellyfin com o username e a password de sempre (a password do portal continua a ser sincronizada). Podem usar também o botão SSO.
- **Contas novas** (`SSO_ONLY_FOR_NEW_USERS=true`): a conta Jellyfin é criada com uma password aleatória que ninguém usa — entram com "Entrar com TK Web Services" (web) e **Quick Connect** nas TVs/apps (autorizado no portal, em Os meus serviços). No Seerr e no LibreChat entram por SSO.
- O modo pode ser mudado por cliente em Admin → Utilizador → Acesso e faturação.

### Seerr (OIDC nativo)
1. `SEERR_PUBLIC_URL` no `.env` → Admin → SSO → Clientes predefinidos (cliente `seerr`, acesso `feature:seerr`).
2. No `settings.json` do Seerr, em `oidc.providers`: `{"slug":"tkws","name":"TK Web Services","issuerUrl":"https://tkws.exemplo.pt","clientId":"seerr","clientSecret":"…","newUserLogin":true,"requiredClaims":["email_verified"]}`. Redirects registados: `/login` e `/profile/settings/linked-accounts`.
3. Sem subscrição, o portal também retira as permissões do utilizador no Seerr (e repõe-nas quando volta).

### LibreChat (TKGPT)
O TKGPT já vem criado (Admin → Planos): define lá o preço do plano e ativa-o. O botão "Abrir TKGPT" aparece nos serviços do cliente com o endereço do LibreChat.

**Admin → SSO → TKGPT (LibreChat)** mostra, prontos a copiar, o bloco do `.env` do LibreChat e o bloco do `librechat.yaml` com o limite mensal:
```yaml
balance:
  enabled: true
  startBalance: 2500000
  autoRefillEnabled: true
  refillIntervalValue: 1
  refillIntervalUnit: 'months'
  refillAmount: 2500000
```
Nota: o saldo do LibreChat é em **créditos** (1 000 créditos = 0,001 $) e cada mensagem gasta tokens × taxa do modelo — 2 500 000 créditos são 2,5 milhões de tokens só em modelos com taxa 1; para os outros, ajusta o `refillAmount`.

Passo a passo:
1. Definições → SSO e apps → endereço do LibreChat → Admin → SSO → Clientes predefinidos (cliente `librechat`, acesso `product:tkgpt`). Serviços novos também podem ter o seu cliente SSO: Admin → Planos → produto → "Cliente SSO".
2. `.env` do LibreChat: `OPENID_ISSUER=https://tkws.exemplo.pt`, `OPENID_CLIENT_ID=librechat`, `OPENID_CLIENT_SECRET=…`, `OPENID_SCOPE="openid profile email offline_access"`, `OPENID_CALLBACK_URL=/oauth/openid/callback`, `OPENID_USE_PKCE=true`, `OPENID_REUSE_TOKENS=true` (a sessão termina quando a subscrição acaba), `ALLOW_SOCIAL_LOGIN=true`, `ALLOW_SOCIAL_REGISTRATION=true`. Mantém `ALLOW_EMAIL_LOGIN=true` durante a transição para quem já tinha conta local.

### Jellyfin — plugin Jellyfin Security (recomendado) e/ou 9p4 SSO
O cliente OIDC `jellyfin` (criado em "Clientes predefinidos") já tem os redirects dos **dois** plugins, por isso podes usar um, o outro ou os dois ao mesmo tempo. Em ambos só entra quem tem o streaming ativo e o email confirmado.

**Jellyfin Security** ([ZL154/JellyfinSecurity](https://github.com/ZL154/JellyfinSecurity) — Jellyfin 10.11 e 12; também traz 2FA, passkeys e emparelhamento de TVs):
1. Painel → Plugins → Repositórios → `https://raw.githubusercontent.com/ZL154/JellyfinSecurity/main/manifest.json` → instalar "Jellyfin Security" → reiniciar.
2. Plugin → OIDC → novo fornecedor com o nome **`tkws`** (o slug do redirect vem do nome; tem de dar `/TwoFactorAuth/Oidc/Callback/tkws` — confirma o redirect que o plugin mostra depois de guardar e, se for outro, põe o slug em `JELLYFIN_SECURITY_OIDC_SLUG` e volta a carregar em "Clientes predefinidos"):
   - Discovery / Issuer: `https://tkws.tkflix.eu` (o `PUBLIC_URL`);
   - Client ID `jellyfin`, Client Secret (o mostrado pelo portal);
   - Scopes `openid profile email groups`;
   - **Username claim `preferred_username`** e ligação a contas existentes **por username** ligada — a conta Jellyfin é criada pelo portal com o mesmo username;
   - **Auto-create users desligado** (as contas só existem para quem subscreve) e **admin elevation desligado**.
3. Não obrigues os clientes a 2FA no Jellyfin: quem entra com username + password (clientes antigos, Seerr por login Jellyfin, apps de TV) deixava de conseguir. Se o ligares para alguns, eles usam as "app passwords" do plugin.

**9p4 SSO** (opcional, em paralelo): configura o fornecedor **`tkflix`** com `deploy/jellyfin/sso-plugin-config.json` e cola o botão de `deploy/jellyfin/sso-login-button.html` em Branding → Login disclaimer. Os dois plugins usam o mesmo cliente e o mesmo segredo.

⚠️ No Jellyfin 12 os plugins da 10.11 deixaram de funcionar. Confirma que tens uma versão do plugin SSO compatível com a 12.0.

### UIs de administração (Sonarr, Radarr, Decypharr, DUMB…) com forward-auth
- **Endpoint:** `https://tkws.exemplo.pt/auth/verify?require=admin`.
  - Outros valores de `require`: `any_active`, `feature:jellyfin`, `group:<nome>`, `plan:<código>`.
- **Reverse proxy:** há exemplos em `deploy/reverse-proxy/` (Caddy, Traefik, nginx).
- **Cookie:** `COOKIE_DOMAIN=.tkflix.eu`, para a sessão valer nos subdomínios.
- **Cabeçalhos devolvidos:** `Remote-User`, `Remote-Email` e `Remote-Groups`.
- As sessões limitadas ao streaming (abertas a partir do Jellyfin) nunca servem para SSO nem forward-auth.

### TKFLIX dentro do Jellyfin (ícone de ajuda e "A minha conta")
**Admin → Jellyfin** mostra tudo pronto a copiar, com o endereço do portal já preenchido:
1. **Repositórios de plugins** (Painel → Plugins → Repositórios): JavaScript Injector (n00bcodr), Custom Pages (JPKribs) e, se quiseres, Jellyfin Security.
2. **JavaScript Injector** → Add Script "TK — Ajuda", *Requires authentication* ligado, e colar o carregador (3 linhas que vão buscar `https://<portal>/jellyfin/widget.js`, sempre atualizado). É o que mostra o **ícone "Ajuda"** do assistente em todas as páginas do Jellyfin. Há também a versão completa, para quem não quer carregar nada do portal.
3. **Custom Pages** → página `conta` (Visibility User, Single file, *Allow system access* ligado) com o HTML mostrado (ou descarregado de `/jellyfin/conta.html`): estado da subscrição, mudar de plano, cancelar e ajuda.
4. Opcional: botão "Entrar com a conta TK" para o plugin 9p4 (Branding → Login disclaimer + Custom CSS).

5. **Apps nativas** → botão "Criar a coleção «Ajuda» no Jellyfin": o portal cria (ou atualiza) uma coleção com um cartaz e um fundo com QR code para `https://<portal>/ajuda` e, se configurado, o número de WhatsApp do assistente.

O endereço público do Jellyfin (Definições → Jellyfin) tem de estar definido: é a origem autorizada para o widget e a página falarem com o portal. O ícone só aparece com o assistente ligado e nunca para administradores do Jellyfin.

**Compatibilidade por app:**

| App | Como chega ao assistente |
|---|---|
| Jellyfin no browser | Botão "Ajuda" + página "A minha conta" |
| Jellyfin Android e iOS (apps móveis) | O mesmo botão (usam o jellyfin-web por dentro); os links abrem no browser do telemóvel |
| Jellyfin Desktop / Media Player | O mesmo botão |
| Jellyfin Samsung (Tizen) e LG (webOS) | Botão em modo TV (maior e navegável com o comando) + coleção "Ajuda" |
| Jellyfin Android TV / Fire TV, Swiftfin (iOS/tvOS), Roku, Kodi, Findroid, Streamyfin | Coleção "Ajuda" com QR code e WhatsApp |
| Moonfin (Android, Android TV, iOS, tvOS, web, desktop, Tizen/webOS, Roku) | Coleção "Ajuda" com QR code e WhatsApp — o Moonfin é um cliente próprio (Flutter) e não corre JavaScript do servidor |

As apps nativas não executam plugins de JavaScript, por isso a coleção (visível em todas) é o ponto comum: o cliente aponta o telemóvel ao QR e continua a conversa no portal, com o mesmo assistente e a mesma memória. Se a coleção não aparecer a alguém, confirma que a conta tem acesso às Coleções no Jellyfin.

---

## 5. Desenvolvimento

```bash
# backend
cd backend && pip install -r requirements-dev.txt
set -a && . ./dev.env && set +a && python scripts/dev_seed.py
uvicorn app.main:app --port 8000          # docs: http://localhost:8000/api/docs
python -m pytest -q                       # SQLite; TEST_DATABASE_URL=postgresql+asyncpg://… para Postgres
python scripts/dev_server_fake_llm.py     # API com um modelo falso (para ver o chat sem chave de IA)
# frontend
cd frontend && npm install && npm run dev # http://localhost:5173
```
Contas de demonstração: `admin` / `Admin-2026!`, `maria` / `Filmes-2026!` (carteira com carregamento mensal), `joao` / `Series-2026!`, `rita` / `Pipocas-2026!`, `nuno` / `Novato-2026!` (conta nova só-carteira, vê o TKFLIX como "TK CDN"; desbloqueia com o código `TKFLIX-NUNO`).

## 6. Notas de operação
- **Fila e tarefas:** correm no mesmo processo da API (modo `all` do contentor). Executam a fila de jobs (emails, provisionamento, webhooks, cobranças, WhatsApp, Seerr) e as tarefas periódicas:
  - ciclo de faturação a cada 5 min;
  - verificação de métodos de pagamento;
  - avisos de preço;
  - bónus;
  - reconciliação total a cada 6 h;
  - rascunhos de conhecimento a cada 6 h.
- **Administradores do Jellyfin:** o portal nunca os altera.
- **Rate limiting:** é em memória, e o contentor corre um só processo, por isso é consistente.
- **Backups:** automáticos em `./backups` (secção 3.2); guarda também a `SECRET_KEY` fora do servidor.

## 7. Segurança — notas
- **Revisão:** os problemas encontrados foram corrigidos e têm testes de regressão (`backend/tests/test_security_review.py` e os testes `test_assistant_*`).
- **Assistentes:** tudo o que chega de ferramentas, issues ou do cliente é tratado como dados e nunca como instruções. As ferramentas só atuam sobre a conta do cliente da conversa. As ações que mudam alguma coisa exigem confirmação explícita. Um número de WhatsApp só fala com uma conta depois de verificado com um código gerado no portal.
- **Segredos antigos:** revoga o token GoCardless live, a API key do Jellyfin, a password SMTP da OVH e a chave do Ombi que estavam no código do site antigo.
- **Primeira conta de administrador:** numa instalação sem nenhum admin, quem se registar primeiro com um email de `ADMIN_EMAILS` (por omissão `geral@tkmasterproductions.eu`) fica admin sem OTP. Faz esse registo logo depois do primeiro arranque (ou mantém a porta 8090 só na rede local até lá). A partir daí os outros emails da lista só passam a admin depois de confirmados.
- **Memória dos assistentes:** guardada por cliente e por agente, sem dados sensíveis; o cliente pode apagá-la a qualquer momento.
