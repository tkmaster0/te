import {
  BarChart3,
  Dices,
  Wallet,
  Gift,
  Home,
  Import,
  MessageCircleQuestion,
  Bot,
  KeyRound,
  Package,
  PlaySquare,
  Rocket,
  Tv,
  PlugZap,
  Receipt,
  ReceiptText,
  ScrollText,
  Settings,
  Store,
  Ticket,
  Truck,
  UserCog,
  Users,
  Wrench,
} from 'lucide-react'

export interface NavItem {
  to: string
  label: string
  icon: typeof Home
  end?: boolean
}

export const USER_NAV: NavItem[] = [
  { to: '/app', label: 'Início', icon: Home, end: true },
  { to: '/app/servicos', label: 'Os meus serviços', icon: PlaySquare },
  { to: '/app/planos', label: 'Loja', icon: Store },
  { to: '/app/carteira', label: 'Carteira', icon: Wallet },
  { to: '/app/faturacao', label: 'Faturação', icon: Receipt },
  { to: '/app/jogos', label: 'Jogos', icon: Dices },
  { to: '/app/convites', label: 'Convites', icon: Gift },
  { to: '/app/conta', label: 'Conta', icon: UserCog },
  { to: '/app/ajuda', label: 'Ajuda', icon: MessageCircleQuestion },
]

export const MOBILE_TABS: NavItem[] = [
  { to: '/app', label: 'Início', icon: Home, end: true },
  { to: '/app/servicos', label: 'Serviços', icon: PlaySquare },
  { to: '/app/planos', label: 'Loja', icon: Store },
  { to: '/app/carteira', label: 'Carteira', icon: Wallet },
  { to: '/app/conta', label: 'Conta', icon: UserCog },
]

export const ADMIN_NAV: NavItem[] = [
  { to: '/admin', label: 'Painel', icon: BarChart3, end: true },
  { to: '/admin/utilizadores', label: 'Utilizadores', icon: Users },
  { to: '/admin/cobrancas', label: 'Cobranças', icon: ReceiptText },
  { to: '/admin/entregas', label: 'Entregas', icon: Truck },
  { to: '/admin/planos', label: 'Produtos & planos', icon: Package },
  { to: '/admin/fornecedores', label: 'Fornecedores', icon: PlugZap },
  { to: '/admin/migracao', label: 'Migração', icon: Import },
  { to: '/admin/convites', label: 'Convites', icon: Ticket },
  { to: '/admin/assistente', label: 'Assistente', icon: Bot },
  { to: '/admin/operacoes', label: 'Operações', icon: Wrench },
  { to: '/admin/sso', label: 'SSO / OIDC', icon: KeyRound },
  { to: '/admin/jellyfin', label: 'Jellyfin', icon: Tv },
  { to: '/admin/auditoria', label: 'Auditoria', icon: ScrollText },
  { to: '/admin/definicoes', label: 'Definições', icon: Settings },
  { to: '/admin/configurar', label: 'Configuração inicial', icon: Rocket },
]
