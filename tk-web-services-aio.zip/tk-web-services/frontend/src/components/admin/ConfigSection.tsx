import { useEffect, useMemo, useState } from 'react'
import { useQueryClient } from '@tanstack/react-query'
import clsx from 'clsx'
import { CheckCircle2, ExternalLink, FlaskConical, Globe, RefreshCw, Save, Server, Sparkles, Webhook, XCircle } from 'lucide-react'
import { api, errorMessage } from '../../api/client'
import { keys } from '../../api/keys'
import { useAction } from '../../api/mutation'
import type { ConfigField, ConfigOut, ConfigSection as Section, TunnelStatus } from '../../api/types'
import { Alert, Badge, Button, CopyField, Field, Input, PasswordInput, Select, Switch } from '../ui'

export const CONFIG_KEY = ['admin', 'config'] as const

type FormValue = string | boolean
type Result = { ok: boolean; message?: string; error?: string } | null

// Portas por omissão do DUMB/TKFLIX para os atalhos "mesma máquina".
const PORTS: Record<string, number> = { jellyfin_url: 8096, seerr_url: 5055, dispatcharr_url: 9191, bazarr_url: 6767 }

function initial(f: ConfigField): FormValue {
  if (f.type === 'secret') return ''
  if (f.type === 'bool') return Boolean(f.value)
  if (f.type === 'list') return Array.isArray(f.value) ? (f.value as string[]).join(', ') : ''
  if (f.type === 'money') return f.value == null ? '' : (Number(f.value) / 100).toFixed(2).replace('.', ',')
  return f.value == null ? '' : String(f.value)
}

function toPayload(f: ConfigField, v: FormValue): unknown {
  if (f.type === 'bool') return Boolean(v)
  if (f.type === 'money') {
    const n = Number(String(v).replace(/\s|€/g, '').replace(',', '.'))
    return Number.isFinite(n) ? Math.round(n * 100) : v
  }
  return v
}

function SourceBadge({ f }: { f: ConfigField }) {
  if (f.source === 'web') return <Badge tone="brand">definido aqui</Badge>
  if (f.source === 'env') return <Badge title="Vem do .env / variáveis de ambiente. Se o mudares aqui, passa a valer o valor daqui.">do .env</Badge>
  return null
}

export function TunnelPanel({ t, onRestart, restarting }: { t: TunnelStatus; onRestart?: () => void; restarting?: boolean }) {
  const tone = t.connected ? 'success' : t.running ? 'warning' : t.configured ? 'danger' : 'neutral'
  const label = t.connected ? `Ligado (${t.connections} ligações)` : t.running ? 'A ligar…' : t.configured ? 'Parado' : 'Sem token'
  return (
    <div className="space-y-3 rounded-2xl border border-border bg-elevated/50 p-4">
      <div className="flex flex-wrap items-center gap-2">
        <span className={clsx('size-2.5 rounded-full', t.connected ? 'bg-success' : t.running ? 'animate-pulse bg-warning' : 'bg-border-strong')} />
        <span className="text-sm font-semibold">Túnel</span>
        <Badge tone={tone}>{label}</Badge>
        {!t.installed && <Badge tone="danger">cloudflared não instalado na imagem</Badge>}
        {onRestart && t.configured && (
          <Button size="sm" variant="ghost" className="ml-auto" onClick={onRestart} loading={restarting} icon={<RefreshCw className="size-4" />}>
            Reiniciar
          </Button>
        )}
      </div>
      <ol className="list-decimal space-y-1 pl-5 text-sm text-muted">
        <li>Na Cloudflare: Zero Trust → Networks → Tunnels → <b className="text-fg">Create a tunnel</b> (Cloudflared) → copia o token.</li>
        <li>
          No túnel: <b className="text-fg">Public Hostname</b> → o teu domínio do portal → Service <b className="text-fg">HTTP</b> →{' '}
          <code className="rounded bg-bg px-1.5 py-0.5 text-fg">localhost:8000</code>
        </li>
        <li>Cola o token aqui e guarda — o portal liga-se sozinho (sem reiniciar nada).</li>
      </ol>
      {t.log.length > 0 && (
        <details className="text-xs">
          <summary className="cursor-pointer text-muted">Registo do túnel</summary>
          <pre className="mt-2 max-h-48 overflow-auto rounded-xl bg-bg p-3 font-mono text-[11px] leading-relaxed text-muted">{t.log.join('\n')}</pre>
        </details>
      )}
    </div>
  )
}

function FieldInput({ f, value, onChange, clear, setClear }: {
  f: ConfigField
  value: FormValue
  onChange: (v: FormValue) => void
  clear: boolean
  setClear: (v: boolean) => void
}) {
  if (f.type === 'bool')
    return (
      <div className="flex items-start justify-between gap-3 rounded-xl border border-border px-4 py-3 sm:col-span-2">
        <Switch checked={Boolean(value)} onChange={onChange} label={f.label} description={f.help ?? undefined} />
        <SourceBadge f={f} />
      </div>
    )
  const label = (
    <span className="inline-flex flex-wrap items-center gap-2">
      {f.label} <SourceBadge f={f} />
    </span>
  )
  const quick =
    PORTS[f.name] != null ? (
      <span className="flex gap-1">
        <button type="button" className="text-xs text-brand-text hover:underline" onClick={() => onChange(`http://host.docker.internal:${PORTS[f.name]}`)} title="Serviço publicado no anfitrião (mesma máquina)">
          anfitrião
        </button>
        <span className="text-xs text-subtle">·</span>
        <button type="button" className="text-xs text-brand-text hover:underline" onClick={() => onChange(`http://DUMB:${PORTS[f.name]}`)} title="Rede tkflix-link com o contentor do DUMB">
          DUMB
        </button>
      </span>
    ) : f.name === 'public_url' ? (
      <button type="button" className="text-xs text-brand-text hover:underline" onClick={() => onChange(window.location.origin)}>
        usar este endereço
      </button>
    ) : undefined
  const wide = f.type === 'secret' || f.type === 'url' || f.type === 'list' || (f.help?.length ?? 0) > 90
  if (f.type === 'select')
    return (
      <Field label={label} hint={f.help ?? undefined} className={clsx(wide && 'sm:col-span-2')}>
        <Select value={String(value)} onChange={(e) => onChange(e.target.value)}>
          {f.options.map((o) => (
            <option key={o.value} value={o.value}>
              {o.label}
            </option>
          ))}
        </Select>
      </Field>
    )
  if (f.type === 'secret')
    return (
      <Field
        label={label}
        className="sm:col-span-2"
        hint={
          <>
            {f.is_set ? (
              <span className="inline-flex flex-wrap items-center gap-2">
                <CheckCircle2 className="size-3.5 text-success" aria-hidden /> Definido ({f.masked}). Deixa vazio para manter.
                <button type="button" className="text-danger hover:underline" onClick={() => setClear(!clear)}>
                  {clear ? 'não apagar' : 'apagar'}
                </button>
              </span>
            ) : (
              'Ainda não definido.'
            )}
            {f.help && <span className="mt-1 block">{f.help}</span>}
          </>
        }
      >
        <PasswordInput value={String(value)} onChange={(e) => onChange(e.target.value)} placeholder={clear ? 'vai ser apagado ao guardar' : f.is_set ? '••••••••' : f.placeholder ?? ''} autoComplete="off" disabled={clear} />
      </Field>
    )
  return (
    <Field label={label} hint={f.help ?? undefined} labelAction={quick} className={clsx(wide && 'sm:col-span-2')}>
      <Input
        value={String(value)}
        onChange={(e) => onChange(e.target.value)}
        placeholder={f.placeholder ?? (f.type === 'money' ? '0,00' : '')}
        inputMode={f.type === 'int' ? 'numeric' : f.type === 'money' || f.type === 'float' ? 'decimal' : undefined}
        type={f.type === 'email' ? 'email' : 'text'}
        autoComplete="off"
      />
    </Field>
  )
}

/** Uma secção das definições (formulário + testar ligação + extras da secção). */
export function ConfigSectionForm({ section, tunnel, publicUrl, onSaved, saveLabel = 'Guardar' }: {
  section: Section
  tunnel?: TunnelStatus
  publicUrl?: string
  onSaved?: () => void
  saveLabel?: string
}) {
  const qc = useQueryClient()
  const [values, setValues] = useState<Record<string, FormValue>>({})
  const [clear, setClear] = useState<Record<string, boolean>>({})
  const [advanced, setAdvanced] = useState(false)
  const [result, setResult] = useState<Result>(null)
  const base = useMemo(() => Object.fromEntries(section.fields.map((f) => [f.name, initial(f)])), [section])
  useEffect(() => {
    setValues(base)
    setClear({})
  }, [base])

  const changes = () => {
    const out: Record<string, unknown> = {}
    for (const f of section.fields) {
      const v = values[f.name]
      if (f.type === 'secret') {
        if (clear[f.name]) out[f.name] = { clear: true }
        else if (v) out[f.name] = v
      } else if (v !== base[f.name]) out[f.name] = toPayload(f, v)
    }
    return out
  }
  const dirty = Object.keys(changes()).length > 0

  const save = useAction((vals: Record<string, unknown>) => api.put<ConfigOut & { message: string }>('/api/admin/config', { values: vals }), {
    errorTitle: 'Não foi possível guardar',
    onSuccess: (res) => {
      qc.setQueryData(CONFIG_KEY, { sections: res.sections, tunnel: res.tunnel })
      void qc.invalidateQueries({ queryKey: keys.config })
      void qc.invalidateQueries({ queryKey: ['admin', 'setup'] })
      setResult(null)
      onSaved?.()
    },
  })
  const test = useAction(() => api.post<{ ok: boolean; message?: string; error?: string }>(`/api/admin/config/test/${section.id}`), {
    success: false,
    errorTitle: false,
    onSuccess: (r) => setResult(r),
    onError: (e) => setResult({ ok: false, error: errorMessage(e) }),
  })
  const stripeHook = useAction(() => api.post<{ message: string }>('/api/admin/config/stripe-webhook'), {
    errorTitle: 'Não foi possível criar o webhook',
    onSuccess: () => void qc.invalidateQueries({ queryKey: CONFIG_KEY }),
  })
  const restart = useAction(() => api.post('/api/admin/tunnel/restart'), { onSuccess: () => void qc.invalidateQueries({ queryKey: CONFIG_KEY }) })

  const saveAndTest = async () => {
    const c = changes()
    if (Object.keys(c).length) await save.mutateAsync(c)
    if (section.test) test.mutate()
  }

  const visible = section.fields.filter((f) => advanced || !f.advanced)
  const hasAdvanced = section.fields.some((f) => f.advanced)
  const pub = publicUrl ?? ''
  const hook = (path: string) => (pub ? `${pub}${path}` : path)

  return (
    <div className="space-y-5">
      {section.id === 'tunel' && tunnel && <TunnelPanel t={tunnel} onRestart={() => restart.mutate()} restarting={restart.isPending} />}
      {section.id === 'gocardless' && (
        <CopyField label="URL do webhook (cola na GoCardless → Developers → Webhook endpoints)" value={hook('/api/webhooks/gocardless')} />
      )}
      {section.id === 'stripe' && (
        <div className="space-y-3">
          <CopyField label="URL do webhook" value={hook('/api/webhooks/stripe')} />
          <Alert
            tone="info"
            icon={<Webhook className="size-5" />}
            title="Webhook automático"
            action={
              <Button size="sm" onClick={() => stripeHook.mutate()} loading={stripeHook.isPending} icon={<Sparkles className="size-4" />}>
                Criar webhook automaticamente
              </Button>
            }
          >
            Guarda primeiro a secret key: o portal cria o webhook no Stripe com o URL certo e os eventos necessários e guarda o segredo — não precisas de abrir o Stripe.
          </Alert>
        </div>
      )}
      {section.id === 'seerr' && <CopyField label="URL do webhook de issues (Seerr → Notificações → Webhook)" value={hook('/api/webhooks/seerr')} />}

      <div className="grid gap-4 sm:grid-cols-2">
        {visible.map((f) => (
          <FieldInput
            key={f.name}
            f={f}
            value={values[f.name] ?? initial(f)}
            onChange={(v) => setValues((s) => ({ ...s, [f.name]: v }))}
            clear={Boolean(clear[f.name])}
            setClear={(v) => setClear((s) => ({ ...s, [f.name]: v }))}
          />
        ))}
      </div>

      {result && (
        <Alert tone={result.ok ? 'success' : 'danger'} icon={result.ok ? <CheckCircle2 className="size-5" /> : <XCircle className="size-5" />}>
          {result.ok ? result.message : result.error}
        </Alert>
      )}

      <div className="flex flex-wrap items-center gap-2">
        <Button onClick={() => save.mutate(changes())} loading={save.isPending} disabled={!dirty} icon={<Save className="size-4" />}>
          {saveLabel}
        </Button>
        {section.test && (
          <Button variant="secondary" onClick={() => void saveAndTest()} loading={test.isPending} icon={<FlaskConical className="size-4" />}>
            {dirty ? 'Guardar e testar' : 'Testar ligação'}
          </Button>
        )}
        {hasAdvanced && (
          <Button variant="ghost" size="sm" onClick={() => setAdvanced((a) => !a)} icon={<Server className="size-4" />}>
            {advanced ? 'Esconder opções avançadas' : 'Opções avançadas'}
          </Button>
        )}
        {section.links.map((l) => (
          <a key={l.url} href={l.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-sm text-brand-text hover:underline">
            <Globe className="size-3.5" aria-hidden /> {l.label} <ExternalLink className="size-3" aria-hidden />
          </a>
        ))}
      </div>
    </div>
  )
}
