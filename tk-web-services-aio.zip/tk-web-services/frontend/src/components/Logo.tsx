import clsx from 'clsx'

/**
 * Marca do portal TK Web Services (o TKFLIX é apenas um dos produtos vendidos aqui).
 * Monograma "TK" desenhado em traço (sem depender de fontes), num quadrado arredondado amarelo.
 * Para usar um logótipo oficial, substitui o conteúdo deste componente por
 * <img src="/logo.svg" alt="TK Web Services" className="h-7" /> (coloca o ficheiro em frontend/public/).
 */
export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={clsx('shrink-0', className ?? 'size-8')} aria-hidden>
      <rect width="64" height="64" rx="15" fill="#f5c518" />
      <g fill="none" stroke="#0b0b0c" strokeWidth="7" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12.5 21H30.5M21.5 21V43" />
        <path d="M37.5 21V43M51 21 39.5 32 51 43" />
      </g>
    </svg>
  )
}

export function Logo({ className, size = 'md', wordmarkOnly }: { className?: string; size?: 'sm' | 'md' | 'lg'; wordmarkOnly?: boolean }) {
  const mark = { sm: 'size-7', md: 'size-8', lg: 'size-11' }[size]
  const text = { sm: 'text-base', md: 'text-lg', lg: 'text-3xl' }[size]
  return (
    <span className={clsx('inline-flex shrink-0 items-center gap-2.5', className)} role="img" aria-label="TK Web Services">
      {!wordmarkOnly && <LogoMark className={mark} />}
      <span className={clsx('whitespace-nowrap leading-none tracking-[-0.02em]', text)} aria-hidden>
        <span className="font-black tracking-[-0.04em] text-fg">TK</span> <span className="font-medium text-brand-text">Web Services</span>
      </span>
    </span>
  )
}
