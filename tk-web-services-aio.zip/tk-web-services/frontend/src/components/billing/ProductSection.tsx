import { useMemo, useState } from 'react'
import { KeyRound, Lock, Plus } from 'lucide-react'
import { api, errorMessage } from '../../api/client'
import { BILLING_INVALIDATE } from '../../api/keys'
import { useAction } from '../../api/mutation'
import type { Ok, Plan, Product, Subscription } from '../../api/types'
import { PlanCard } from '../PlanCard'
import { Badge, Button, Pills } from '../ui'
import { ProductIcon } from './ProductIcon'

/** Produto em beta fechado (ex.: aparece como "TK CDN"): desativado, com campo para o código de convite. */
export function LockedProduct({ product }: { product: Product }) {
  const [code, setCode] = useState('')
  const unlock = useAction((c: string) => api.post<Ok>('/api/billing/unlock', { code: c }), {
    invalidate: [...BILLING_INVALIDATE, ['catalog']],
    errorTitle: false,
  })
  return (
    <section aria-labelledby={`prod-${product.id}`} className="relative overflow-hidden rounded-3xl border border-dashed border-border-strong bg-surface/60 p-6 sm:p-8">
      <div className="pointer-events-none absolute inset-0 bg-[repeating-linear-gradient(135deg,transparent,transparent_14px,var(--c-neutral-soft)_14px,var(--c-neutral-soft)_15px)]" aria-hidden />
      <div className="relative flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
        <div className="flex min-w-0 items-start gap-4 opacity-70 grayscale">
          <span className="grid size-14 shrink-0 place-items-center rounded-2xl bg-elevated text-muted">
            <Lock className="size-6" aria-hidden />
          </span>
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <h2 id={`prod-${product.id}`} className="text-xl font-bold">
                {product.name}
              </h2>
              <Badge tone="neutral">Beta fechado</Badge>
            </div>
            <p className="mt-1 text-sm text-muted">{product.description || 'Beta testing fechado'}</p>
          </div>
        </div>
        <form
          className="flex w-full flex-col gap-2 md:w-auto md:min-w-80"
          onSubmit={(e) => {
            e.preventDefault()
            if (code.trim()) unlock.mutate(code.trim())
          }}
        >
          <label htmlFor={`unlock-${product.id}`} className="text-sm font-medium">
            Tens um código de convite?
          </label>
          <div className="flex gap-2">
            <input
              id={`unlock-${product.id}`}
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              placeholder="TK-XXXX-XXXX"
              autoComplete="off"
              className="h-11 min-w-0 flex-1 rounded-xl border border-border bg-bg px-3.5 font-mono text-sm uppercase tracking-wider outline-none focus:border-brand"
            />
            <Button type="submit" loading={unlock.isPending} disabled={!code.trim()} icon={<KeyRound className="size-4" />}>
              Desbloquear
            </Button>
          </div>
          {unlock.isError && <p className="text-xs font-medium text-danger">{errorMessage(unlock.error)}</p>}
        </form>
      </div>
    </section>
  )
}

/** Estados em que o cliente "tem" o produto (não pode subscrever outra vez). */
export const OWNED = new Set(['active', 'past_due', 'canceling', 'bonus'])

function PlanAction({ plan, owned, onAdd, onChange }: { plan: Plan; owned: Subscription | undefined; onAdd: () => void; onChange: () => void }) {
  if (owned) {
    if (owned.plan.id === plan.id)
      return (
        <Button variant="outline" className="w-full" disabled>
          O teu plano atual
        </Button>
      )
    if (owned.can_change)
      return (
        <Button variant="secondary" className="w-full" onClick={onChange}>
          Mudar para este
        </Button>
      )
    const why =
      owned.status === 'canceling'
        ? 'Reativa primeiro'
        : owned.status === 'past_due'
          ? 'Regulariza o pagamento primeiro'
          : 'Indisponível de momento'
    return (
      <Button variant="secondary" className="w-full" disabled title="Para mudar de plano, o serviço tem de estar ativo e em dia.">
        {why}
      </Button>
    )
  }
  return (
    <Button className="w-full" onClick={onAdd} icon={<Plus className="size-4" />}>
      Adicionar
    </Button>
  )
}

export function ProductSection({
  product,
  owned,
  onAdd,
  onChange,
}: {
  product: Product
  owned: Subscription | undefined
  onAdd: (plan: Plan, product: Product) => void
  onChange: (plan: Plan, sub: Subscription) => void
}) {
  if (product.locked) return <LockedProduct product={product} />
  return <UnlockedProductSection product={product} owned={owned} onAdd={onAdd} onChange={onChange} />
}

function UnlockedProductSection({
  product,
  owned,
  onAdd,
  onChange,
}: {
  product: Product
  owned: Subscription | undefined
  onAdd: (plan: Plan, product: Product) => void
  onChange: (plan: Plan, sub: Subscription) => void
}) {
  const units = useMemo(() => Array.from(new Set(product.plans.map((p) => p.interval_unit))), [product])
  const [unit, setUnit] = useState<string>(owned?.plan.interval_unit ?? (units.includes('month') ? 'month' : units[0]))
  const active = units.includes(unit) ? unit : units[0]
  const plans = units.length > 1 ? product.plans.filter((p) => p.interval_unit === active) : product.plans
  const maxPrice = Math.max(...plans.map((p) => p.monthly_equivalent_cents))
  const bestYearSaving = useMemo(() => {
    const m = product.plans.filter((p) => p.interval_unit === 'month')
    const y = product.plans.filter((p) => p.interval_unit === 'year')
    if (!m.length || !y.length) return 0
    const minM = Math.min(...m.map((p) => p.price_cents))
    const minY = Math.min(...y.map((p) => p.monthly_equivalent_cents))
    return minM > 0 ? Math.round((1 - minY / minM) * 100) : 0
  }, [product])

  return (
    <section aria-labelledby={`prod-${product.id}`} className="space-y-5">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex min-w-0 items-start gap-3.5">
          <ProductIcon icon={product.icon} fulfillment={product.fulfillment} size="lg" />
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <h2 id={`prod-${product.id}`} className="text-xl font-bold">
                {product.name}
              </h2>
              {owned && <Badge tone="success">Já tens · {owned.plan.name}</Badge>}
            </div>
            {product.description && <p className="mt-1 text-sm text-muted">{product.description}</p>}
          </div>
        </div>
        {units.length > 1 && (
          <Pills
            ariaLabel={`Periodicidade de ${product.name}`}
            value={active}
            onChange={setUnit}
            items={units.map((u) => ({
              value: u,
              label: u === 'year' ? (bestYearSaving > 0 ? `Anual · −${bestYearSaving}%` : 'Anual') : u === 'month' ? 'Mensal' : 'Semanal',
            }))}
          />
        )}
      </div>
      <div className={`grid gap-4 ${plans.length >= 3 ? 'md:grid-cols-2 xl:grid-cols-3' : 'md:grid-cols-2'}`}>
        {plans.map((plan) => {
          const highlight = plans.length > 1 && plan.monthly_equivalent_cents === maxPrice && !owned
          return (
            <PlanCard
              key={plan.id}
              plan={plan}
              highlight={highlight}
              current={owned?.plan.id === plan.id}
              action={<PlanAction plan={plan} owned={owned} onAdd={() => onAdd(plan, product)} onChange={() => owned && onChange(plan, owned)} />}
            />
          )
        })}
      </div>
    </section>
  )
}

