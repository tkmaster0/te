import { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useQueryClient } from '@tanstack/react-query'
import { ArrowLeft, ArrowRight, Check, CreditCard, Landmark, MailWarning, PiggyBank, Wallet } from 'lucide-react'
import { api, errorMessage } from '../../api/client'
import { BILLING_INVALIDATE } from '../../api/keys'
import { useAction } from '../../api/mutation'
import { useBillingSummary, useConfig, useQuote } from '../../api/queries'
import type { Plan, Product, Provider, SubscribeOut } from '../../api/types'
import { useAuth } from '../../auth/AuthProvider'
import { formatMoney, perInterval } from '../../lib/format'
import { Alert, Button, Modal, Switch, useToast } from '../ui'
import { AmountPicker } from '../wallet/AmountPicker'
import { ProductIcon } from './ProductIcon'
import { firstAvailable, ProviderChoice, SecureRedirectNote } from './ProviderChoice'
import { QuoteSummary } from './QuoteSummary'
import { goToProvider, useIsScoped } from './hooks'

function Steps({ step }: { step: 1 | 2 }) {
  const items = ['Resumo', 'Pagamento']
  return (
    <ol className="mb-5 flex items-center gap-2 text-xs font-medium" aria-label={`Passo ${step} de 2`}>
      {items.map((label, i) => {
        const n = (i + 1) as 1 | 2
        const done = n < step
        const current = n === step
        return (
          <li key={label} className="flex items-center gap-2" aria-current={current ? 'step' : undefined}>
            {i > 0 && <span className="h-px w-6 bg-border-strong" aria-hidden />}
            <span
              className={`grid size-5 place-items-center rounded-full text-[11px] font-bold ${
                current ? 'bg-brand text-brand-fg' : done ? 'bg-success-soft text-success' : 'bg-elevated text-subtle'
              }`}
              aria-hidden
            >
              {done ? <Check className="size-3" /> : n}
            </span>
            <span className={current ? 'text-fg' : 'text-muted'}>{label}</span>
          </li>
        )
      })}
    </ol>
  )
}

function WalletBox(p: {
  covered: boolean
  walletOnly: boolean
  hasMonthly: boolean
  monthlyTopup: number | null
  balance: number
  sendMonthly: boolean
  monthlyOn: boolean
  setMonthlyOn: (v: boolean) => void
  monthly: number
  setMonthly: (v: number) => void
  minMonthly: number
  suggested: number | null
  bonusPercent: number
}) {
  if (p.covered && !p.sendMonthly)
    return (
      <div className="flex items-center gap-3 rounded-xl border border-success/40 bg-success-soft p-4">
        <Wallet className="size-5 shrink-0 text-success" aria-hidden />
        <p className="text-sm">
          O saldo da tua carteira (<strong>{formatMoney(p.balance)}</strong>) paga isto. <strong>Não é cobrado nada.</strong>
        </p>
      </div>
    )
  if (p.hasMonthly)
    return (
      <div className="flex items-center gap-3 rounded-xl border border-border bg-elevated/60 p-4">
        <PiggyBank className="size-5 shrink-0 text-brand-text" aria-hidden />
        <p className="text-sm">
          Entra no teu carregamento mensal de <strong>{formatMoney(p.monthlyTopup)}</strong>
          {p.balance > 0 && <> — e o saldo atual ({formatMoney(p.balance)}) é usado primeiro</>}.
        </p>
      </div>
    )
  const picker = (
    <div className="space-y-3">
      <AmountPicker
        value={p.monthly}
        onChange={p.setMonthly}
        presets={[500, 1000, 1500, 2000]}
        min={p.minMonthly}
        max={50000}
        suggested={p.suggested}
        label="Carregamento mensal"
      />
      <p className="text-xs text-muted">
        Hoje e depois todos os meses no teu dia de faturação: paga os serviços e o que sobrar fica na carteira. Se o saldo já chegar num mês, não há cobrança.
        {p.bonusPercent > 0 && <> Ganhas {p.bonusPercent}% extra em créditos.</>}
      </p>
    </div>
  )
  if (p.walletOnly)
    return (
      <div className="space-y-3 rounded-xl border border-brand/40 bg-brand-soft/50 p-4">
        <p className="flex items-center gap-2 text-sm font-semibold">
          <PiggyBank className="size-4 text-brand-text" aria-hidden /> Os serviços são pagos pela tua carteira — escolhe o carregamento mensal
        </p>
        {picker}
      </div>
    )
  return (
    <div className="space-y-3 rounded-xl border border-border p-4">
      <Switch
        checked={p.monthlyOn}
        onChange={p.setMonthlyOn}
        label={
          <span className="flex items-center gap-2">
            <PiggyBank className="size-4 text-brand-text" aria-hidden /> Pagar com créditos mensais (recomendado)
          </span>
        }
        description="Uma cobrança por mês pela carteira; saldo que sobre ou ganhes paga meses inteiros."
      />
      {p.monthlyOn && picker}
    </div>
  )
}

/**
 * Subscrever um plano novo em 2 passos:
 *  1. pré-visualização (quanto hoje, quanto na próxima cobrança, quanto depois);
 *  2. pagamento — com o método predefinido, ou escolher um fornecedor (redireciona).
 */
export function SubscribeModal({
  plan,
  product,
  open,
  onClose,
}: {
  plan: Plan | null
  product: Pick<Product, 'name' | 'icon' | 'fulfillment'> | null
  open: boolean
  onClose: () => void
}) {
  const { me } = useAuth()
  const scoped = useIsScoped()
  const navigate = useNavigate()
  const qc = useQueryClient()
  const toast = useToast()
  const [step, setStep] = useState<1 | 2>(1)
  const [provider, setProvider] = useState<Provider | null>(null)
  const [methodId, setMethodId] = useState<string | null>(null)
  const [monthlyOn, setMonthlyOn] = useState(true)
  const [monthly, setMonthly] = useState(0)
  const quote = useQuote(open && plan ? plan.id : null)
  const summary = useBillingSummary()
  const { data: config } = useConfig()

  useEffect(() => {
    if (open) {
      setStep(1)
      setMethodId(null)
      setMonthlyOn(true)
    }
  }, [open, plan?.id])
  useEffect(() => {
    if (quote.data?.suggested_monthly_cents) setMonthly(quote.data.suggested_monthly_cents)
  }, [quote.data?.suggested_monthly_cents])

  const resend = useAction(() => api.post('/api/auth/resend-verification'), { success: 'Email enviado.' })
  const subscribe = useAction(
    (body: { plan_id: number; provider?: Provider; payment_method_id?: string; monthly_topup_cents?: number }) =>
      api.post<SubscribeOut>('/api/billing/subscribe', body),
    {
    success: false,
    errorTitle: false,
    onSuccess: async (res) => {
      if (res.status === 'redirect' && res.redirect_url) {
        goToProvider(res.redirect_url)
        return
      }
      await Promise.all(BILLING_INVALIDATE.map((k) => qc.invalidateQueries({ queryKey: k })))
      toast.success(res.message || 'Serviço ativo!')
      onClose()
      navigate(scoped ? '/app/streaming' : '/app/servicos')
    },
    },
  )

  if (!plan) return null
  const methods = summary.data?.payment_methods ?? []
  const usable = methods.filter((m) => m.status === 'active' || m.status === 'pending')
  const defaultMethod = methods.find((m) => m.id === summary.data?.default_payment_method_id) ?? null
  // Método escolhido (por omissão, o predefinido)
  const def = usable.find((m) => m.id === methodId) ?? defaultMethod
  const unusable = methods.find((m) => m.status === 'unusable')
  const providers = summary.data?.providers ?? []
  const chosen = provider && providers.some((p) => p.name === provider && p.available) ? provider : firstAvailable(providers)
  const unverified = me && !me.email_verified
  const redirecting = subscribe.isSuccess && subscribe.data?.status === 'redirect'
  const busy = subscribe.isPending || redirecting
  const q = quote.data
  const walletEnabled = config?.wallet?.enabled !== false && !scoped
  // Por omissão não há carregamento mensal: aderir pede uma autorização de pagamento (débito direto ou cartão) e o
  // portal cobra depois o valor certo. O saldo da carteira, se houver, é usado primeiro.
  const monthlyEnabled = walletEnabled && config?.wallet?.monthly_enabled === true && q?.monthly_enabled !== false
  const requireMethod = config?.billing?.require_method !== false
  const walletOnly = !!q?.wallet_only && monthlyEnabled
  const hasMonthly = monthlyEnabled && !!q?.monthly_topup_cents
  const toPay = (q?.due_now_cents ?? 0) + (q?.next_invoice_cents ?? 0)
  const covered = walletEnabled && !!q && (q.wallet_balance_cents ?? 0) >= toPay && toPay > 0
  // Com o carregamento mensal ligado: obrigatório para contas só-carteira sem saldo; opcional para as outras.
  const sendMonthly = monthlyEnabled && !hasMonthly && ((walletOnly && !covered) || (!walletOnly && monthlyOn))
  const minMonthly = Math.max(config?.wallet?.min_monthly_cents ?? 500, 100)
  const monthlyValid = !sendMonthly || (monthly >= minMonthly && monthly <= 50000)
  const payByWalletOnly = covered && !sendMonthly && (!requireMethod || walletOnly)

  const confirm = () => {
    const base = { plan_id: plan.id, ...(sendMonthly ? { monthly_topup_cents: monthly } : {}) }
    if (payByWalletOnly) subscribe.mutate(base)
    else if (def) subscribe.mutate(def.id === defaultMethod?.id ? base : { ...base, payment_method_id: def.id })
    else if (chosen) subscribe.mutate({ ...base, provider: chosen })
  }

  const footer =
    step === 1 ? (
      <>
        <Button variant="secondary" onClick={onClose}>
          Cancelar
        </Button>
        <Button onClick={() => setStep(2)} disabled={!q || quote.isError} icon={<ArrowRight className="size-4" />} className="flex-row-reverse">
          Continuar
        </Button>
      </>
    ) : (
      <>
        <Button variant="secondary" onClick={() => setStep(1)} icon={<ArrowLeft className="size-4" />} disabled={busy}>
          Voltar
        </Button>
        <Button
          onClick={confirm}
          loading={busy}
          disabled={!!unverified || (!payByWalletOnly && !def && !chosen) || summary.isPending || !monthlyValid}
          title={def ? `Confirmar com ${def.label}` : undefined}
        >
          {redirecting
            ? 'A redirecionar…'
            : payByWalletOnly
              ? 'Confirmar com a carteira'
              : def
                ? `Confirmar com ${def.kind === 'card' ? 'o cartão' : 'débito direto'}`
                : 'Continuar para o pagamento'}
        </Button>
      </>
    )

  return (
    <Modal
      open={open}
      onClose={busy ? () => undefined : onClose}
      title={`Adicionar ${product?.name ?? plan.name}`}
      description={`${plan.name} · ${formatMoney(plan.price_cents, plan.currency)}${perInterval(plan.interval_unit, plan.interval_count)}`}
      footer={footer}
    >
      <Steps step={step} />
      {step === 1 ? (
        <div className="space-y-4">
          <div className="flex items-center gap-3 rounded-xl border border-border bg-elevated/60 p-3">
            <ProductIcon icon={product?.icon} fulfillment={product?.fulfillment} size="sm" />
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-semibold">{plan.name}</p>
              {plan.highlights.length > 0 && <p className="truncate text-xs text-muted">{plan.highlights.slice(0, 3).join(' · ')}</p>}
            </div>
          </div>
          {quote.isError ? <Alert tone="danger">{errorMessage(quote.error)}</Alert> : <QuoteSummary quote={q} loading={quote.isPending} methodLabel={def?.label} />}
        </div>
      ) : (
        <div className="space-y-4">
          {unverified && (
            <Alert
              tone="warning"
              title="Confirma o teu email primeiro"
              action={
                !scoped && (
                  <Button size="sm" variant="secondary" loading={resend.isPending} onClick={() => resend.mutate()} icon={<MailWarning className="size-4" />}>
                    Reenviar
                  </Button>
                )
              }
            >
              Por segurança, só podes subscrever depois de confirmares o email ({me?.email}).
            </Alert>
          )}
          {walletEnabled && q && !monthlyEnabled && (q.wallet_balance_cents ?? 0) > 0 && (
            <div className="flex items-center gap-3 rounded-xl border border-success/40 bg-success-soft p-4">
              <Wallet className="size-5 shrink-0 text-success" aria-hidden />
              <p className="text-sm">
                O saldo da tua carteira (<strong>{formatMoney(q.wallet_balance_cents)}</strong>) é usado primeiro
                {covered ? <> — <strong>não é cobrado nada</strong> ao teu método de pagamento por agora.</> : <>; o resto é cobrado ao método autorizado.</>}
              </p>
            </div>
          )}
          {monthlyEnabled && q && (
            <WalletBox
              covered={covered}
              walletOnly={walletOnly}
              hasMonthly={hasMonthly}
              monthlyTopup={q.monthly_topup_cents ?? null}
              balance={q.wallet_balance_cents ?? 0}
              sendMonthly={sendMonthly}
              monthlyOn={monthlyOn}
              setMonthlyOn={setMonthlyOn}
              monthly={monthly}
              setMonthly={setMonthly}
              minMonthly={minMonthly}
              suggested={q.suggested_monthly_cents ?? null}
              bonusPercent={config?.wallet?.monthly_bonus_percent ?? 0}
            />
          )}
          {payByWalletOnly ? null : def ? (
            <>
              {usable.length > 1 && !scoped ? (
                <fieldset className="space-y-2.5">
                  <legend className="mb-2 text-sm text-muted">Escolhe com que método pagas. O serviço entra na mesma cobrança mensal.</legend>
                  {usable.map((m) => {
                    const active = m.id === def.id
                    return (
                      <label
                        key={m.id}
                        className={`flex cursor-pointer items-center gap-3 rounded-xl border p-4 transition-colors ${
                          active ? 'border-brand/60 bg-brand-soft' : 'border-border hover:border-border-strong'
                        }`}
                      >
                        <input
                          type="radio"
                          name="subscribe-method"
                          checked={active}
                          onChange={() => setMethodId(m.id)}
                          className="size-4 shrink-0 accent-[var(--c-brand)]"
                        />
                        <span className="grid size-10 shrink-0 place-items-center rounded-lg bg-elevated">
                          {m.kind === 'card' ? <CreditCard className="size-5" aria-hidden /> : <Landmark className="size-5" aria-hidden />}
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className="block break-words font-semibold">{m.label}</span>
                          <span className="block text-xs text-muted">
                            {m.provider_label}
                            {m.id === defaultMethod?.id && ' · predefinido'}
                            {m.status === 'pending' && ' · a confirmar'}
                          </span>
                        </span>
                      </label>
                    )
                  })}
                </fieldset>
              ) : (
                <>
                  <p className="text-sm text-muted">Vamos usar o teu método de pagamento predefinido. Não precisas de fazer mais nada.</p>
                  <div className="flex items-center gap-3 rounded-xl border border-brand/50 bg-brand-soft p-4">
                    <span className="grid size-10 shrink-0 place-items-center rounded-lg bg-elevated">
                      {def.kind === 'card' ? <CreditCard className="size-5" aria-hidden /> : <Landmark className="size-5" aria-hidden />}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="break-words font-semibold">{def.label}</p>
                      <p className="text-xs text-muted">{def.provider_label} · predefinido</p>
                    </div>
                    <Check className="size-5 shrink-0 text-brand-text" aria-hidden />
                  </div>
                </>
              )}
              {q && (
                <p className="text-sm">
                  {q.due_now_cents > 0 ? (
                    <>
                      Ao confirmar, cobramos{' '}
                      <strong>
                        {formatMoney(sendMonthly ? Math.max(monthly, q.charge_now_cents ?? q.due_now_cents) : (q.charge_now_cents ?? q.due_now_cents))}
                      </strong>{' '}
                      agora{sendMonthly && monthly > (q.charge_now_cents ?? 0) ? ` — ${formatMoney(monthly - (q.charge_now_cents ?? 0))} ficam na carteira` : ''}.
                    </>
                  ) : q.next_invoice_cents > 0 ? (
                    <>
                      Ao confirmar, o serviço fica ativo já e <strong>{formatMoney(q.next_invoice_cents)}</strong> entram na próxima cobrança.
                    </>
                  ) : (
                    <>Ao confirmar, o serviço fica ativo já.</>
                  )}
                </p>
              )}
              {!scoped && (
                <p className="text-xs text-muted">
                  Queres pagar com um método novo?{' '}
                  <Link to="/app/faturacao?metodo=novo" className="link" onClick={onClose}>
                    Adiciona-o em Faturação
                  </Link>{' '}
                  e volta aqui.
                </p>
              )}
            </>
          ) : (
            <>
              {unusable ? (
                <Alert tone="warning" title={`${unusable.label} já não pode ser usado`}>
                  {unusable.status_reason ?? 'Escolhe um novo método de pagamento.'}
                </Alert>
              ) : (
                <p className="text-sm text-muted">
                  Escolhe como queres pagar: débito direto ou cartão. Autorizas <strong className="text-fg">uma única vez</strong> e, a partir daí,
                  cobramos juntos todos os teus serviços, uma vez por mês — o valor ajusta-se sozinho quando aderes, mudas de plano ou cancelas.
                </p>
              )}
              <ProviderChoice providers={providers} value={chosen} onChange={setProvider} />
              <SecureRedirectNote />
            </>
          )}
          {subscribe.isError && <Alert tone="danger">{errorMessage(subscribe.error)}</Alert>}
        </div>
      )}
    </Modal>
  )
}
