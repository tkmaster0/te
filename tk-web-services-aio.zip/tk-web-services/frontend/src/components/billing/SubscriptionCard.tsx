import type { ReactNode } from 'react'
import { Link } from 'react-router-dom'
import clsx from 'clsx'
import { ArrowLeftRight, ArrowRight, CalendarClock, Gift, RotateCcw, TrendingUp, Wallet, XCircle } from 'lucide-react'
import { api } from '../../api/client'
import { BILLING_INVALIDATE } from '../../api/keys'
import { useAction } from '../../api/mutation'
import type { Subscription } from '../../api/types'
import { formatDate, formatDayMonth, formatMoney, perInterval } from '../../lib/format'
import { Alert, Button, ButtonLink, Card, Menu, StatusBadge, useConfirm } from '../ui'
import { ProductIcon } from './ProductIcon'

export function useSubscriptionActions(sub: Subscription) {
  const confirm = useConfirm()
  const cancel = useAction(() => api.post(`/api/billing/subscriptions/${sub.id}/cancel`), {
    invalidate: BILLING_INVALIDATE,
    success: 'Cancelado.',
    errorTitle: 'Não foi possível cancelar',
  })
  const resume = useAction(() => api.post(`/api/billing/subscriptions/${sub.id}/resume`), {
    invalidate: BILLING_INVALIDATE,
    success: 'Reativado.',
    errorTitle: 'Não foi possível reativar',
  })
  const askCancel = async () => {
    const ok = await confirm({
      title: `Cancelar ${sub.product_name}?`,
      danger: true,
      confirmLabel: 'Sim, cancelar',
      cancelLabel: 'Manter',
      message: (
        <>
          <p>
            Manténs o acesso a <strong className="text-fg">{sub.plan.name}</strong> até{' '}
            <strong className="text-fg">{formatDate(sub.current_period_end, 'ao fim do período pago')}</strong>. Depois disso termina e{' '}
            <strong className="text-fg">não há mais cobranças</strong> por este serviço.
          </p>
          <p>Mudaste de ideias? Podes reativar a qualquer momento até essa data.</p>
        </>
      ),
    })
    if (ok) cancel.mutate()
  }
  return { cancel, resume, askCancel }
}

function Fact({ label, children, tone }: { label: string; children: ReactNode; tone?: 'brand' | 'warning' | 'danger' }) {
  return (
    <div className="min-w-0">
      <dt className="text-xs text-muted">{label}</dt>
      <dd
        className={clsx(
          'mt-0.5 truncate font-semibold',
          tone === 'brand' && 'text-brand-text',
          tone === 'warning' && 'text-warning',
          tone === 'danger' && 'text-danger',
        )}
      >
        {children}
      </dd>
    </div>
  )
}

/** Avisos da subscrição (mudança de preço, migração agendada, atraso, cancelamento…). */
export function SubscriptionNotices({ sub, scoped }: { sub: Subscription; scoped?: boolean }) {
  // Um serviço cancelado que termina antes da mudança de preço nunca chega a pagar o preço novo.
  const endsAt = sub.status === 'canceling' ? (sub.access_until ?? sub.current_period_end) : null
  const pc =
    sub.upcoming_price_change && !(endsAt && new Date(endsAt).getTime() <= new Date(sub.upcoming_price_change.effective_at).getTime())
      ? sub.upcoming_price_change
      : null
  return (
    <>
      {sub.status === 'past_due' && (
        <Alert tone="warning" title="Pagamento em atraso">
          A última cobrança não foi paga. Manténs o acesso até <strong>{formatDate(sub.grace_until, 'breve')}</strong> — regulariza até lá para não perderes o
          serviço.
        </Alert>
      )}
      {sub.status === 'suspended' && (
        <Alert tone="danger" title="Serviço suspenso">
          O acesso foi suspenso por falta de pagamento. Paga a cobrança em atraso e o acesso volta de imediato.
        </Alert>
      )}
      {sub.status === 'canceling' && (
        <Alert tone="info" title="Cancelado">
          Tens acesso até <strong>{formatDate(sub.access_until ?? sub.current_period_end)}</strong> e não voltas a ser cobrado.{' '}
          {sub.can_resume && 'Podes reativar até lá.'}
        </Alert>
      )}
      {sub.status === 'bonus' && (
        <Alert tone="success" title="Grátis graças ao bónus de convites">
          Enquanto tiveres convidados suficientes a pagar, este serviço não é cobrado.
        </Alert>
      )}
      {pc && (
        <Alert tone="info" title={`O preço passa a ${formatMoney(pc.new_price_cents)}${perInterval(sub.plan.interval_unit, sub.plan.interval_count)} a partir de ${formatDayMonth(pc.effective_at)}`}>
          Aplica-se a partir da primeira renovação depois dessa data. {sub.can_cancel && !scoped && 'Se preferires, podes mudar de plano ou cancelar antes.'}
        </Alert>
      )}
      {sub.pending_plan && (
        <Alert tone="info" title={`Na próxima renovação passas para ${sub.pending_plan}`}>
          A mudança acontece a {formatDate(sub.current_period_end)}, sem nada a fazeres.
        </Alert>
      )}
    </>
  )
}

export function periodFact(sub: Subscription): { label: string; value: string; tone?: 'brand' | 'warning' | 'danger' } {
  if (sub.status === 'canceling') return { label: 'Acesso até', value: formatDate(sub.access_until ?? sub.current_period_end) }
  if (sub.status === 'past_due') return { label: 'Regulariza até', value: formatDate(sub.grace_until), tone: 'warning' }
  if (sub.status === 'suspended') return { label: 'Acesso', value: 'Suspenso', tone: 'danger' }
  if (sub.status === 'ended') return { label: 'Terminou a', value: formatDate(sub.ended_at) }
  return { label: 'Próxima renovação', value: formatDate(sub.current_period_end) }
}

/** Cartão completo de um serviço (página "Os meus serviços" e streaming). */
export function SubscriptionCard({
  sub,
  primary,
  onChangePlan,
  children,
  scoped,
  id,
}: {
  sub: Subscription
  primary?: ReactNode
  onChangePlan?: (s: Subscription) => void
  children?: ReactNode
  scoped?: boolean
  id?: string
}) {
  const { resume, askCancel } = useSubscriptionActions(sub)
  const period = periodFact(sub)
  const per = perInterval(sub.plan.interval_unit, sub.plan.interval_count)
  const debt = sub.status === 'past_due' || sub.status === 'suspended'

  let mainAction: ReactNode = primary
  if (sub.can_resume)
    mainAction = (
      <Button onClick={() => resume.mutate()} loading={resume.isPending} icon={<RotateCcw className="size-4" />}>
        Reativar
      </Button>
    )
  else if (debt && !scoped)
    mainAction = (
      <ButtonLink to="/app/faturacao" icon={<Wallet className="size-4" />}>
        Regularizar pagamento
      </ButtonLink>
    )

  return (
    <Card id={id} className="scroll-mt-24">
      <div className="flex items-start gap-3.5 p-5 sm:p-6">
        <ProductIcon icon={sub.product.icon} fulfillment={sub.product.fulfillment} />
        <div className="min-w-0 flex-1">
          <p className="truncate text-xs font-semibold uppercase tracking-wide text-subtle">{sub.product_name}</p>
          <h2 className="mt-0.5 text-lg font-bold leading-snug">{sub.plan.name}</h2>
          <div className="mt-2">
            <StatusBadge status={sub.status} until={sub.access_until ?? sub.current_period_end} />
          </div>
        </div>
        {sub.can_cancel && (
          <Menu
            label={`Mais ações para ${sub.product_name}`}
            items={[
              { label: 'Cancelar serviço', icon: <XCircle />, danger: true, onSelect: askCancel, hint: 'Manténs o acesso até ao fim do período pago.' },
            ]}
          />
        )}
      </div>

      <dl className="mx-5 grid grid-cols-2 gap-4 rounded-xl bg-elevated/60 p-4 text-sm sm:mx-6 sm:grid-cols-3">
        <Fact label={period.label} tone={period.tone}>
          {period.value}
        </Fact>
        <Fact label="Preço" tone={sub.status === 'bonus' ? 'brand' : undefined}>
          {sub.status === 'bonus' ? (
            <span className="inline-flex items-center gap-1">
              <Gift className="size-4" aria-hidden /> Grátis
            </span>
          ) : (
            <>
              {formatMoney(sub.price_cents, sub.plan.currency)}
              <span className="font-normal text-muted">{per}</span>
            </>
          )}
        </Fact>
        <Fact label="Cliente desde">
          <span className="font-medium">{formatDate(sub.started_at)}</span>
        </Fact>
      </dl>

      <div className="space-y-3 px-5 pt-4 empty:hidden sm:px-6">
        <SubscriptionNotices sub={sub} scoped={scoped} />
      </div>

      {children && <div className="px-5 pt-5 sm:px-6">{children}</div>}

      {(mainAction || (sub.can_change && onChangePlan)) && (
        <div className="mt-5 flex flex-wrap items-center gap-2 border-t border-border px-5 py-4 sm:px-6">
          {mainAction}
          {sub.can_change && onChangePlan && (
            <Button variant={mainAction ? 'secondary' : 'primary'} onClick={() => onChangePlan(sub)} icon={<ArrowLeftRight className="size-4" />}>
              Mudar de plano
            </Button>
          )}
        </div>
      )}
      {!mainAction && !(sub.can_change && onChangePlan) && <div className="h-5" />}
    </Card>
  )
}

/** Mosaico compacto para o Início: ícone, plano, estado e a ação principal. */
export function ServiceTile({ sub, jellyfinUrl }: { sub: Subscription; jellyfinUrl?: string | null }) {
  const period = periodFact(sub)
  const streaming = sub.product.jellyfin_managed
  const pendingAccess = sub.fulfillment_status === 'pending'
  const debt = sub.status === 'past_due' || sub.status === 'suspended'
  let action: ReactNode
  if (debt)
    action = (
      <ButtonLink to="/app/faturacao" size="sm" variant="primary" icon={<Wallet className="size-4" />}>
        Regularizar
      </ButtonLink>
    )
  else if (streaming && jellyfinUrl && sub.status !== 'ended')
    action = (
      <a href={jellyfinUrl} target="_blank" rel="noopener noreferrer" className="inline-flex h-8 items-center gap-1.5 rounded-xl bg-brand px-3 text-[13px] font-semibold text-brand-fg hover:bg-brand-hover">
        Abrir TKFLIX <ArrowRight className="size-4" aria-hidden />
      </a>
    )
  else
    action = (
      <Link to={`/app/servicos#sub-${sub.id}`} className="link inline-flex items-center gap-1 text-sm">
        {pendingAccess ? 'Ver estado' : Object.keys(sub.access_details).length ? 'Ver acesso' : 'Gerir'} <ArrowRight className="size-4" aria-hidden />
      </Link>
    )
  return (
    <Card className="flex flex-col p-5">
      <div className="flex items-start gap-3">
        <ProductIcon icon={sub.product.icon} fulfillment={sub.product.fulfillment} />
        <div className="min-w-0 flex-1">
          <p className="truncate text-xs font-medium text-subtle">{sub.product_name}</p>
          <p className="truncate font-bold">{sub.plan.name}</p>
        </div>
      </div>
      <div className="mt-3 flex flex-wrap items-center gap-2">
        <StatusBadge status={sub.status} until={sub.access_until ?? sub.current_period_end} />
        {pendingAccess && <span className="text-xs text-info">A preparar o acesso</span>}
        {sub.upcoming_price_change && sub.status !== 'canceling' && (
          <span className="inline-flex items-center gap-1 text-xs text-muted">
            <TrendingUp className="size-3.5" aria-hidden /> Novo preço a {formatDayMonth(sub.upcoming_price_change.effective_at)}
          </span>
        )}
      </div>
      <p className="mt-3 flex items-center gap-1.5 text-xs text-muted">
        <CalendarClock className="size-3.5" aria-hidden />
        {period.label}: <span className="font-medium text-fg">{period.value}</span>
      </p>
      <div className="mt-4 flex flex-1 items-end">{action}</div>
    </Card>
  )
}
