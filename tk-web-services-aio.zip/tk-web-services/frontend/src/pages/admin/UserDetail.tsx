import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { useQuery, type QueryKey } from '@tanstack/react-query'
import {
  ArrowLeft,
  Ban,
  CheckCircle2,
  ChevronDown,
  CreditCard,
  Gift,
  KeyRound,
  LogOut,
  MailCheck,
  MessagesSquare,
  Pencil,
  Plus,
  Radio,
  ReceiptText,
  RefreshCw,
  Server,
  ShieldCheck,
  ShieldOff,
  Trash2,
  Unlock,
  Wallet,
  XCircle,
  Zap,
} from 'lucide-react'
import { api, errorMessage } from '../../api/client'
import { useAction } from '../../api/mutation'
import { useAdminProducts } from '../../api/admin'
import type { AdminServiceAccount, AdminUserDetail, Subscription } from '../../api/types'
import { useMe } from '../../auth/AuthProvider'
import {
  Alert,
  Badge,
  Button,
  ButtonLink,
  Card,
  CardHeader,
  Checkbox,
  DateText,
  EmptyState,
  Field,
  Input,
  Modal,
  Money,
  PasswordInput,
  Select,
  SkeletonCard,
  StatusBadge,
  Table,
  THead,
  Th,
  Tr,
  Td,
  Textarea,
  useConfirm,
} from '../../components/ui'
import { FULFILLMENT_STATUS, LINE_KIND, PROVIDER_LABEL, SERVICE_LABEL, actionLabel } from '../../i18n/labels'
import { formatDate, formatMoney, formatSignedMoney, initials, perInterval } from '../../lib/format'
import { AccessDetailsEditor, fromRows, toRows, type KV } from '../../components/admin/AccessDetailsEditor'
import { InvoiceAdminActions } from '../../components/admin/InvoiceAdminActions'
import { ChargeLines } from '../../components/billing/ChargeLines'
import { InvoiceList } from '../../components/billing/InvoiceList'
import { ProductIcon } from '../../components/billing/ProductIcon'
import { UserAccessMode, UserWalletAdmin, type AdminWallet } from '../../components/admin/UserWalletAdmin'

function JsonBlock({ value }: { value: unknown }) {
  return (
    <pre className="scrollbar-thin max-h-72 overflow-auto rounded-xl border border-border bg-bg p-3 font-mono text-xs leading-relaxed text-muted">
      {JSON.stringify(value, null, 2)}
    </pre>
  )
}

function Section({ title, icon, actions, children, count }: { title: string; icon?: React.ReactNode; actions?: React.ReactNode; children: React.ReactNode; count?: number }) {
  return (
    <Card className="overflow-hidden">
      <CardHeader
        icon={icon}
        title={
          <span className="flex items-center gap-2">
            {title}
            {count !== undefined && <Badge tone="neutral">{count}</Badge>}
          </span>
        }
        actions={actions}
      />
      <div className="pt-4">{children}</div>
    </Card>
  )
}

// ------------------------------------------------------------------ Subscrições
function AdminSubEditModal({ sub, open, onClose, invalidate }: { sub: Subscription; open: boolean; onClose: () => void; invalidate: unknown[][] }) {
  const deliverable = sub.product.fulfillment === 'manual' || sub.product.fulfillment === 'webhook'
  const [extend, setExtend] = useState('')
  const [price, setPrice] = useState((sub.price_cents / 100).toFixed(2).replace('.', ','))
  const [fstatus, setFstatus] = useState(sub.fulfillment_status ?? '')
  const [rows, setRows] = useState<KV[]>(() => toRows(sub.access_details))
  const cents = (() => {
    const v = price.replace(/\s|€/g, '').replace(',', '.')
    const n = Number(v)
    return v && Number.isFinite(n) && n >= 0 ? Math.round(n * 100) : null
  })()
  const save = useAction(
    () => {
      const body: Record<string, unknown> = {}
      if (Number(extend) > 0) body.extend_days = Number(extend)
      if (cents !== null && cents !== sub.price_cents) body.price_cents = cents
      if (deliverable) {
        const d = fromRows(rows)
        if (JSON.stringify(d) !== JSON.stringify(sub.access_details ?? {})) body.access_details = d
        if (fstatus && fstatus !== sub.fulfillment_status) body.fulfillment_status = fstatus
      }
      return api.patch(`/api/admin/subscriptions/${sub.id}`, body)
    },
    { invalidate, errorTitle: 'Não foi possível guardar', onSuccess: onClose },
  )
  return (
    <Modal
      open={open}
      onClose={onClose}
      title={`Editar ${sub.plan.name}`}
      description={`${sub.product_name} · renova a ${formatDate(sub.current_period_end)}`}
      size="lg"
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancelar
          </Button>
          <Button loading={save.isPending} disabled={cents === null} onClick={() => save.mutate()}>
            Guardar
          </Button>
        </>
      }
    >
      <div className="space-y-5">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Oferecer dias" optional hint="Adia a próxima renovação (e o acesso) este número de dias.">
            <Input type="number" min={1} max={366} value={extend} onChange={(e) => setExtend(e.target.value)} placeholder="ex.: 7" inputMode="numeric" />
          </Field>
          <Field label="Preço fixado (€)" hint={`Preço deste cliente em cada renovação. Plano: ${formatMoney(sub.plan.price_cents, sub.plan.currency)}.`} error={price && cents === null ? 'Valor inválido' : undefined}>
            <Input value={price} onChange={(e) => setPrice(e.target.value)} inputMode="decimal" />
          </Field>
        </div>
        {deliverable && (
          <>
            <Field label="Estado da entrega">
              <Select value={fstatus} onChange={(e) => setFstatus(e.target.value)}>
                <option value="">—</option>
                {Object.entries(FULFILLMENT_STATUS).map(([k, v]) => (
                  <option key={k} value={k}>
                    {v.label}
                  </option>
                ))}
              </Select>
            </Field>
            <div>
              <p className="mb-2 text-sm font-medium">Dados de acesso</p>
              <AccessDetailsEditor rows={rows} onChange={setRows} />
            </div>
          </>
        )}
      </div>
    </Modal>
  )
}

function AdminSubRow({ sub, invalidate }: { sub: Subscription; invalidate: unknown[][] }) {
  const [open, setOpen] = useState(false)
  const [edit, setEdit] = useState(false)
  const [now, setNow] = useState(false)
  const cancel = useAction(() => api.post(`/api/admin/subscriptions/${sub.id}/cancel`, { immediately: now }), {
    invalidate,
    success: 'Subscrição cancelada.',
    errorTitle: 'Falha ao cancelar',
    onSuccess: () => setOpen(false),
  })
  const live = !['ended'].includes(sub.status)
  return (
    <li className="px-5 py-4 sm:px-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="flex min-w-0 items-start gap-3">
          <ProductIcon icon={sub.product.icon} fulfillment={sub.product.fulfillment} size="sm" />
          <div className="min-w-0">
            <p className="font-semibold">
              {sub.plan.name} <span className="font-normal text-muted">· {sub.product_name}</span>
            </p>
            <p className="mt-0.5 text-xs text-muted">
              {formatMoney(sub.price_cents, sub.plan.currency)}
              {perInterval(sub.plan.interval_unit, sub.plan.interval_count)}
              {sub.price_cents !== sub.plan.price_cents && <span className="text-warning"> (plano: {formatMoney(sub.plan.price_cents, sub.plan.currency)})</span>}
              {' · '}
              {PROVIDER_LABEL[sub.provider] ?? sub.provider}
              {sub.provider_subscription_id && <span className="font-mono"> · {sub.provider_subscription_id}</span>}
            </p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-1.5">
          {sub.fulfillment_status && sub.product.fulfillment !== 'streaming' && <StatusBadge kind="fulfillment" status={sub.fulfillment_status} />}
          <StatusBadge status={sub.status} until={sub.access_until ?? sub.current_period_end} />
        </div>
      </div>
      <dl className="mt-3 grid grid-cols-2 gap-x-4 gap-y-1 text-xs sm:grid-cols-4">
        <div>
          <dt className="text-subtle">Início</dt>
          <dd>
            <DateText value={sub.started_at} />
          </dd>
        </div>
        <div>
          <dt className="text-subtle">Renova a</dt>
          <dd>
            <DateText value={sub.current_period_end} />
          </dd>
        </div>
        <div>
          <dt className="text-subtle">Acesso até</dt>
          <dd>
            <DateText value={sub.access_until ?? sub.grace_until} />
          </dd>
        </div>
        <div>
          <dt className="text-subtle">Terminou</dt>
          <dd>
            <DateText value={sub.ended_at} />
          </dd>
        </div>
      </dl>
      {(sub.pending_plan || sub.upcoming_price_change) && (
        <p className="mt-2 text-xs text-info">
          {sub.pending_plan && `Passa a ${sub.pending_plan} na renovação. `}
          {sub.upcoming_price_change &&
            `Novo preço ${formatMoney(sub.upcoming_price_change.new_price_cents)} a partir de ${formatDate(sub.upcoming_price_change.effective_at)}.`}
        </p>
      )}
      {live && (
        <div className="mt-3 flex flex-wrap gap-2">
          <Button size="sm" variant="secondary" onClick={() => setEdit(true)} icon={<Pencil className="size-3.5" />}>
            Editar
          </Button>
          <Button size="sm" variant="ghost" onClick={() => setOpen(true)} icon={<XCircle className="size-3.5" />}>
            Cancelar
          </Button>
        </div>
      )}
      {edit && <AdminSubEditModal sub={sub} open onClose={() => setEdit(false)} invalidate={invalidate} />}
      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title="Cancelar subscrição"
        description={`${sub.plan.name} · ${sub.product_name}`}
        size="sm"
        footer={
          <>
            <Button variant="secondary" onClick={() => setOpen(false)}>
              Voltar
            </Button>
            <Button variant="danger" loading={cancel.isPending} onClick={() => cancel.mutate()}>
              Cancelar subscrição
            </Button>
          </>
        }
      >
        <div className="space-y-3 text-sm">
          <p className="text-muted">Por defeito o cliente mantém o acesso até {formatDate(sub.current_period_end, 'ao fim do período pago')} e não volta a ser cobrado.</p>
          <Checkbox
            checked={now}
            onChange={(e) => setNow(e.target.checked)}
            label="Terminar imediatamente"
            description="O acesso é removido já. Não há reembolso automático — se for caso disso, adiciona um crédito."
          />
        </div>
      </Modal>
    </li>
  )
}

// ------------------------------------------------------------------ Faturação
function BillingSection({ data, invalidate }: { data: AdminUserDetail; invalidate: unknown[][] }) {
  const confirm = useConfirm()
  const b = data.billing
  const u = data.user
  const [type, setType] = useState<'credit' | 'charge'>('credit')
  const [amount, setAmount] = useState('')
  const [desc, setDesc] = useState('')
  const cents = (() => {
    const v = amount.replace(/\s|€/g, '').replace(',', '.')
    const n = Number(v)
    return v && Number.isFinite(n) && n > 0 ? Math.round(n * 100) : null
  })()
  const add = useAction(
    () => api.post(`/api/admin/users/${u.id}/adjustments`, { amount_cents: type === 'credit' ? -(cents ?? 0) : cents, description: desc.trim() }),
    {
      invalidate,
      errorTitle: 'Não foi possível registar',
      onSuccess: () => {
        setAmount('')
        setDesc('')
      },
    },
  )
  const removeLine = useAction((id: number) => api.del(`/api/admin/adjustments/${id}`), { invalidate, success: 'Linha removida.', errorTitle: 'Não foi possível remover' })
  const runBilling = useAction(() => api.post(`/api/admin/users/${u.id}/run-billing`), { invalidate, errorTitle: 'Não foi possível faturar' })
  const due = b.next_billing_at ? new Date(b.next_billing_at).getTime() <= Date.now() : false

  return (
    <Section
      title="Faturação"
      icon={<Wallet className="size-5" />}
      actions={
        <Button
          size="sm"
          variant="secondary"
          disabled={!due}
          title={due ? undefined : 'Só quando a data de faturação já passou'}
          loading={runBilling.isPending}
          icon={<Zap className="size-4" />}
          onClick={async () => {
            if (
              await confirm({
                title: 'Faturar agora?',
                message: 'Emite já a cobrança consolidada deste cliente (renovações e acertos pendentes) e tenta cobrá-la.',
                confirmLabel: 'Faturar agora',
              })
            )
              runBilling.mutate()
          }}
        >
          Faturar agora
        </Button>
      }
    >
      <div className="space-y-5 px-5 pb-5 sm:px-6">
        <dl className="grid grid-cols-2 gap-3 rounded-xl bg-elevated/60 p-4 text-sm sm:grid-cols-4">
          <div>
            <dt className="text-xs text-muted">Dia de faturação</dt>
            <dd className="mt-0.5 font-semibold">{b.anchor_day ? `Dia ${b.anchor_day}` : '—'}</dd>
          </div>
          <div>
            <dt className="text-xs text-muted">Próxima cobrança</dt>
            <dd className={`mt-0.5 font-semibold ${due ? 'text-warning' : ''}`}>{formatDate(b.next_billing_at)}</dd>
          </div>
          <div>
            <dt className="text-xs text-muted">Valor previsto</dt>
            <dd className="mt-0.5 font-semibold tabular-nums">{formatMoney(b.upcoming.total_cents)}</dd>
          </div>
          <div>
            <dt className="text-xs text-muted">Bónus</dt>
            <dd className={`mt-0.5 font-semibold ${data.bonus.eligible ? 'text-brand-text' : ''}`}>
              {data.bonus.enabled ? `${data.bonus.active_invitees} de ${data.bonus.threshold}${data.bonus.eligible ? ' · ativo' : ''}` : 'desligado'}
            </dd>
          </div>
        </dl>

        <div>
          <p className="mb-1 text-xs font-semibold uppercase tracking-wider text-subtle">Pré-visualização da próxima cobrança</p>
          {b.upcoming.lines.length ? (
            <ChargeLines lines={b.upcoming.lines} total={b.upcoming.total_cents} />
          ) : (
            <p className="text-sm text-muted">Nada a cobrar na próxima data.</p>
          )}
        </div>

        {b.pending_lines.length > 0 && (
          <div>
            <p className="mb-1 text-xs font-semibold uppercase tracking-wider text-subtle">Linhas pendentes (ainda não cobradas)</p>
            <ul className="divide-y divide-border rounded-xl border border-border">
              {b.pending_lines.map((ln) => (
                <li key={ln.id} className="flex items-center gap-3 px-3 py-2 text-sm">
                  <span className="min-w-0 flex-1">
                    <span className="block truncate">{ln.description}</span>
                    <span className="text-xs text-subtle">{LINE_KIND[ln.kind] ?? ln.kind}</span>
                  </span>
                  <span className={`shrink-0 font-medium tabular-nums ${ln.amount_cents < 0 ? 'text-success' : ''}`}>{formatSignedMoney(ln.amount_cents)}</span>
                  {(ln.kind === 'adjustment' || ln.kind === 'credit') && (
                    <Button
                      size="icon-sm"
                      variant="ghost"
                      aria-label={`Remover ${ln.description}`}
                      disabled={removeLine.isPending}
                      onClick={async () => {
                        if (await confirm({ title: 'Remover esta linha?', message: `“${ln.description}” (${formatSignedMoney(ln.amount_cents)}) deixa de entrar na próxima cobrança.`, confirmLabel: 'Remover', danger: true }))
                          removeLine.mutate(ln.id)
                      }}
                    >
                      <Trash2 className="size-4" />
                    </Button>
                  )}
                </li>
              ))}
            </ul>
          </div>
        )}

        <form
          className="space-y-3 rounded-xl border border-border p-4"
          onSubmit={(e) => {
            e.preventDefault()
            if (cents && desc.trim().length >= 3) add.mutate()
          }}
        >
          <p className="text-sm font-semibold">Adicionar crédito / acerto</p>
          <div className="flex flex-wrap gap-2" role="radiogroup" aria-label="Tipo">
            {(
              [
                ['credit', 'Crédito (desconto)'],
                ['charge', 'Acerto (cobrar mais)'],
              ] as const
            ).map(([v, l]) => (
              <label key={v} className={`flex cursor-pointer items-center gap-2 rounded-full border px-3 py-1.5 text-sm ${type === v ? 'border-brand bg-brand-soft' : 'border-border'}`}>
                <input type="radio" name="adj-type" checked={type === v} onChange={() => setType(v)} className="size-3.5 accent-[var(--c-brand)]" />
                {l}
              </label>
            ))}
          </div>
          <div className="grid gap-3 sm:grid-cols-[8rem_minmax(0,1fr)]">
            <Field label="Valor (€)">
              <Input value={amount} onChange={(e) => setAmount(e.target.value)} inputMode="decimal" placeholder="1,00" />
            </Field>
            <Field label="Descrição" hint="O cliente vê este texto na cobrança.">
              <Input value={desc} onChange={(e) => setDesc(e.target.value)} maxLength={200} placeholder="ex.: Compensação pela falha de 12/09" />
            </Field>
          </div>
          <div className="flex flex-wrap items-center justify-between gap-2">
            <p className="text-xs text-muted">
              {cents ? `${type === 'credit' ? 'Desconta' : 'Soma'} ${formatMoney(cents)} na próxima cobrança${b.next_billing_at ? ` (${formatDate(b.next_billing_at)})` : ''}.` : 'Entra na próxima cobrança consolidada.'}
            </p>
            <Button type="submit" size="sm" loading={add.isPending} disabled={!cents || desc.trim().length < 3} icon={<Plus className="size-4" />}>
              Adicionar
            </Button>
          </div>
        </form>
      </div>
    </Section>
  )
}

// ------------------------------------------------------------------ Ofertas
function GrantModal({ userId, open, onClose, invalidate }: { userId: string; open: boolean; onClose: () => void; invalidate: unknown[][] }) {
  const products = useAdminProducts()
  const plans = (products.data ?? []).flatMap((p) => p.plans.map((pl) => ({ ...pl, productName: p.name })))
  const [planId, setPlanId] = useState<number | ''>('')
  const [mode, setMode] = useState<'days' | 'date' | 'forever'>('days')
  const [days, setDays] = useState('30')
  const [date, setDate] = useState('')
  const [reason, setReason] = useState('')
  const add = useAction(
    () =>
      api.post(`/api/admin/users/${userId}/grants`, {
        plan_id: planId,
        days: mode === 'days' ? Number(days) : null,
        ends_at: mode === 'date' && date ? new Date(`${date}T23:59:59`).toISOString() : null,
        reason: reason.trim() || null,
      }),
    {
      invalidate,
      errorTitle: 'Não foi possível adicionar',
      onSuccess: () => {
        onClose()
        setReason('')
      },
    },
  )
  const valid = planId !== '' && (mode === 'forever' || (mode === 'days' && Number(days) >= 1) || (mode === 'date' && !!date))
  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Oferecer acesso"
      description="Dá acesso a um plano sem cobrança (ex.: família, testes, compensação)."
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancelar
          </Button>
          <Button loading={add.isPending} disabled={!valid} onClick={() => add.mutate()} icon={<Gift className="size-4" />}>
            Oferecer
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        <Field label="Plano">
          <Select value={planId} onChange={(e) => setPlanId(e.target.value ? Number(e.target.value) : '')}>
            <option value="">Escolhe um plano…</option>
            {plans.map((p) => (
              <option key={p.id} value={p.id}>
                {p.productName} — {p.name}
                {!p.is_active ? ' (inativo)' : ''}
              </option>
            ))}
          </Select>
        </Field>
        <fieldset className="space-y-2">
          <legend className="mb-1 text-sm font-medium">Duração</legend>
          {(
            [
              ['days', 'Número de dias'],
              ['date', 'Até uma data'],
              ['forever', 'Sem data de fim'],
            ] as const
          ).map(([v, l]) => (
            <label key={v} className="flex items-center gap-2 text-sm">
              <input type="radio" name="grant-mode" checked={mode === v} onChange={() => setMode(v)} className="size-4 accent-[var(--c-brand)]" />
              {l}
            </label>
          ))}
        </fieldset>
        {mode === 'days' && (
          <Field label="Dias">
            <Input type="number" min={1} max={3650} value={days} onChange={(e) => setDays(e.target.value)} />
          </Field>
        )}
        {mode === 'date' && (
          <Field label="Data de fim">
            <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          </Field>
        )}
        <Field label="Motivo" optional>
          <Input value={reason} onChange={(e) => setReason(e.target.value)} maxLength={200} placeholder="ex.: Oferta de aniversário" />
        </Field>
      </div>
    </Modal>
  )
}

// ------------------------------------------------------------------ Contas de serviço
function ServiceAccountRow({ sa, userId, invalidate }: { sa: AdminServiceAccount; userId: string; invalidate: unknown[][] }) {
  const confirm = useConfirm()
  const unlink = useAction(() => api.post(`/api/admin/users/${userId}/unlink/${sa.service}`), { invalidate, success: 'Ligação removida.' })
  return (
    <li className="px-5 py-4 sm:px-6">
      <div className="flex flex-wrap items-center gap-2">
        <span className="font-semibold">{SERVICE_LABEL[sa.service] ?? sa.service}</span>
        {sa.last_error ? <Badge tone="danger">Erro</Badge> : sa.external_id ? <Badge tone="success">Ligada</Badge> : <Badge tone="neutral">Sem ID</Badge>}
        {sa.has_secret && <Badge tone="neutral">Com segredo</Badge>}
        <Button
          size="icon-sm"
          variant="ghost"
          className="ml-auto"
          aria-label={`Desassociar ${sa.service}`}
          title="Desassociar (não apaga a conta no serviço)"
          onClick={async () => {
            if (
              await confirm({
                title: `Desassociar ${SERVICE_LABEL[sa.service] ?? sa.service}?`,
                message: 'Remove a ligação no portal (a conta no serviço externo não é apagada). A próxima reconciliação pode voltar a criá-la.',
                confirmLabel: 'Desassociar',
                danger: true,
              })
            )
              unlink.mutate()
          }}
        >
          <Trash2 className="size-4" />
        </Button>
      </div>
      <dl className="mt-2 grid grid-cols-2 gap-x-4 gap-y-2 text-xs">
        <div className="min-w-0">
          <dt className="text-subtle">ID externo</dt>
          <dd className="truncate font-mono">{sa.external_id ?? '—'}</dd>
        </div>
        <div className="min-w-0">
          <dt className="text-subtle">Username</dt>
          <dd className="truncate">{sa.username ?? '—'}</dd>
        </div>
        <div>
          <dt className="text-subtle">Última sincronização</dt>
          <dd>
            <DateText value={sa.last_synced_at} withTime fallback="Nunca" />
          </dd>
        </div>
      </dl>
      {sa.last_error && <p className="mt-2 break-words rounded-lg bg-danger-soft px-3 py-2 font-mono text-xs text-danger">{sa.last_error}</p>}
      {(sa.applied_state || sa.data) && (
        <details className="group mt-2">
          <summary className="flex cursor-pointer items-center gap-1 text-xs text-muted hover:text-fg">
            <ChevronDown className="size-3.5 transition-transform group-open:rotate-180" /> Estado aplicado
          </summary>
          <div className="mt-2">
            <JsonBlock value={{ applied_state: sa.applied_state, data: sa.data }} />
          </div>
        </details>
      )}
    </li>
  )
}

function IptvManualForm({ userId, current, invalidate }: { userId: string; current?: AdminServiceAccount; invalidate: unknown[][] }) {
  const [username, setUsername] = useState(current?.username ?? '')
  const [password, setPassword] = useState('')
  const [host, setHost] = useState(((current?.data as { host?: string } | null)?.host as string) ?? '')
  const save = useAction(
    (v: { username: string | null; password: string | null; host: string | null }) => api.put(`/api/admin/users/${userId}/iptv-manual`, v),
    { invalidate, success: (_r, v) => (v.username ? 'Credenciais IPTV guardadas. O utilizador foi notificado.' : 'Credenciais IPTV removidas.') },
  )
  return (
    <form
      className="space-y-3 px-5 pb-5 sm:px-6"
      onSubmit={(e) => {
        e.preventDefault()
        save.mutate({ username: username.trim() || null, password: password || null, host: host.trim() || null })
      }}
    >
      <p className="text-xs text-muted">Para contas IPTV de fornecedores externos (fora do Dispatcharr). Ao guardar, o utilizador recebe um email.</p>
      <div className="grid grid-cols-1 gap-3">
        <Field label="Username">
          <Input value={username} onChange={(e) => setUsername(e.target.value)} autoComplete="off" />
        </Field>
        <Field label="Password" hint={current?.has_secret ? 'Deixa vazio para limpar.' : undefined}>
          <PasswordInput value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="new-password" />
        </Field>
        <Field label="Servidor">
          <Input value={host} onChange={(e) => setHost(e.target.value)} placeholder="http://servidor:8080" autoComplete="off" />
        </Field>
      </div>
      <div className="flex flex-wrap justify-end gap-2">
        {current && (
          <Button variant="ghost" onClick={() => save.mutate({ username: null, password: null, host: null })} disabled={save.isPending}>
            Remover
          </Button>
        )}
        <Button type="submit" loading={save.isPending} disabled={!username.trim()}>
          Guardar credenciais
        </Button>
      </div>
    </form>
  )
}

// ------------------------------------------------------------------ Perfil
function ProfileForm({ data, invalidate }: { data: AdminUserDetail; invalidate: unknown[][] }) {
  const u = data.user
  const [email, setEmail] = useState(u.email)
  const [name, setName] = useState(u.display_name ?? '')
  const [notes, setNotes] = useState(u.admin_notes ?? '')
  useEffect(() => {
    setEmail(u.email)
    setName(u.display_name ?? '')
    setNotes(u.admin_notes ?? '')
  }, [u.email, u.display_name, u.admin_notes])
  const save = useAction((body: Record<string, unknown>) => api.patch(`/api/admin/users/${u.id}`, body), { invalidate, success: 'Utilizador atualizado.' })
  const dirty = email !== u.email || name !== (u.display_name ?? '') || notes !== (u.admin_notes ?? '')
  return (
    <form
      className="space-y-4 px-5 pb-5 sm:px-6"
      onSubmit={(e) => {
        e.preventDefault()
        const body: Record<string, unknown> = {}
        if (email !== u.email) body.email = email.trim()
        if (name !== (u.display_name ?? '')) body.display_name = name.trim() || null
        if (notes !== (u.admin_notes ?? '')) body.admin_notes = notes
        save.mutate(body)
      }}
    >
      <Field label="Nome">
        <Input value={name} onChange={(e) => setName(e.target.value)} maxLength={120} />
      </Field>
      <Field label="Email">
        <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
      </Field>
      <Field label="Notas internas" hint="Só visíveis para administradores.">
        <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={4} maxLength={5000} />
      </Field>
      <div className="flex justify-end">
        <Button type="submit" loading={save.isPending} disabled={!dirty}>
          Guardar
        </Button>
      </div>
    </form>
  )
}

function FeatureSummary({ data }: { data: AdminUserDetail }) {
  const f = data.effective_features
  const items: [string, string][] = []
  if (f.jellyfin.enabled) {
    items.push(['Jellyfin', f.jellyfin.all_libraries ? 'Todas as bibliotecas' : `${f.jellyfin.libraries.length} bibliotecas`])
    items.push(['Ecrãs', f.jellyfin.max_streams === 0 ? 'Ilimitado' : String(f.jellyfin.max_streams)])
    items.push(['TV em direto', f.jellyfin.live_tv ? 'Sim' : 'Não'])
    items.push(['Downloads', f.jellyfin.downloads ? 'Sim' : 'Não'])
    if (f.jellyfin.remote_bitrate_mbps) items.push(['Bitrate remoto', `${f.jellyfin.remote_bitrate_mbps} Mbps`])
  }
  if (f.seerr.enabled) items.push(['Seerr', `${f.seerr.movie_quota ?? '∞'} filmes / ${f.seerr.tv_quota ?? '∞'} temporadas`])
  if (f.iptv.enabled) items.push(['IPTV', f.iptv.stream_limit === 0 ? 'Ligações ilimitadas' : `${f.iptv.stream_limit} ${f.iptv.stream_limit === 1 ? 'ligação' : 'ligações'}`])
  return (
    <div className="px-5 pb-5 sm:px-6">
      {!items.length ? (
        <p className="text-sm text-muted">Sem acesso a serviços.</p>
      ) : (
        <dl className="grid grid-cols-2 gap-2 text-sm">
          {items.map(([k, v]) => (
            <div key={k} className="rounded-lg bg-elevated px-3 py-2">
              <dt className="text-xs text-muted">{k}</dt>
              <dd className="font-medium">{v}</dd>
            </div>
          ))}
        </dl>
      )}
      {data.groups.length > 0 && (
        <div className="mt-3">
          <p className="mb-1.5 text-xs text-muted">Grupos (OIDC)</p>
          <div className="flex flex-wrap gap-1.5">
            {data.groups.map((g) => (
              <Badge key={g} tone="neutral">
                {g}
              </Badge>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

// ------------------------------------------------------------------ Página
export default function AdminUserDetail() {
  const { id = '' } = useParams()
  const me = useMe()
  const confirm = useConfirm()
  const key = ['admin', 'user', id]
  const invalidate = [key, ['admin', 'users']]
  const q = useQuery({ queryKey: key, queryFn: () => api.get<AdminUserDetail>(`/api/admin/users/${encodeURIComponent(id)}`) })
  const [grantOpen, setGrantOpen] = useState(false)
  const [reconcileResult, setReconcileResult] = useState<{ ok: boolean; result?: unknown; error?: string } | null>(null)

  const patch = useAction((body: Record<string, unknown>) => api.patch(`/api/admin/users/${id}`, body), { invalidate, success: 'Utilizador atualizado.' })
  const reconcile = useAction(() => api.post<{ ok: boolean; result?: unknown; error?: string }>(`/api/admin/users/${id}/reconcile`), {
    invalidate,
    success: false,
    onSuccess: (res) => setReconcileResult(res),
  })
  const reset = useAction(() => api.post(`/api/admin/users/${id}/password-reset`), {})
  const revokeSessions = useAction(() => api.post(`/api/admin/users/${id}/sessions/revoke`), {})
  const revokeGrant = useAction((gid: number) => api.del(`/api/admin/grants/${gid}`), { invalidate, success: 'Oferta revogada.' })
  const products = useAdminProducts()

  if (q.isPending)
    return (
      <div className="space-y-4">
        <SkeletonCard lines={2} />
        <SkeletonCard lines={5} />
      </div>
    )
  if (q.isError)
    return (
      <div className="space-y-4">
        <Link to="/admin/utilizadores" className="link inline-flex items-center gap-1 text-sm">
          <ArrowLeft className="size-4" /> Utilizadores
        </Link>
        <Alert tone="danger">{errorMessage(q.error)}</Alert>
      </div>
    )

  const d = q.data
  const u = d.user
  const self = u.id === me.id
  const iptvManual = d.service_accounts.find((s) => s.service === 'iptv')

  const toggle = async (field: 'is_active' | 'is_admin', value: boolean, title: string, message: string, danger = true) => {
    if (await confirm({ title, message, confirmLabel: 'Confirmar', danger })) patch.mutate({ [field]: value })
  }

  return (
    <div className="space-y-6">
      <Link to="/admin/utilizadores" className="inline-flex items-center gap-1 text-sm text-muted hover:text-fg">
        <ArrowLeft className="size-4" /> Utilizadores
      </Link>

      <header className="flex flex-col gap-4">
        <div className="flex min-w-0 items-center gap-4">
          <span className="grid size-14 shrink-0 place-items-center rounded-2xl bg-brand text-lg font-black text-brand-fg">{initials(u.display_name || u.username)}</span>
          <div className="min-w-0">
            <h1 className="truncate text-2xl font-bold tracking-tight">{u.display_name || u.username}</h1>
            <p className="truncate text-sm text-muted">
              @{u.username} · {u.email}
            </p>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {u.has_access ? <Badge tone="success">Com acesso</Badge> : <Badge tone="neutral">Sem acesso</Badge>}
              {u.is_admin && <Badge tone="brand">Administrador</Badge>}
              {!u.is_active && <Badge tone="danger">Bloqueado</Badge>}
              {u.email_verified ? <Badge tone="success">Email confirmado</Badge> : <Badge tone="warning">Email por confirmar</Badge>}
              {u.totp_enabled && <Badge tone="info">2FA</Badge>}
              {u.needs_password_sync && <Badge tone="warning">Password Jellyfin por sincronizar</Badge>}
            </div>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button size="sm" loading={reconcile.isPending} onClick={() => reconcile.mutate()} icon={<RefreshCw className="size-4" />}>
            Reconciliar agora
          </Button>
          <Button
            size="sm"
            variant="secondary"
            loading={reset.isPending}
            icon={<KeyRound className="size-4" />}
            onClick={async () => {
              if (await confirm({ title: 'Enviar email de redefinição de password?', message: `Para ${u.email}.`, confirmLabel: 'Enviar' })) reset.mutate()
            }}
          >
            Reset de password
          </Button>
          <Button
            size="sm"
            variant="secondary"
            loading={revokeSessions.isPending}
            icon={<LogOut className="size-4" />}
            onClick={async () => {
              if (await confirm({ title: 'Terminar todas as sessões?', message: 'O utilizador terá de voltar a entrar em todos os dispositivos.', confirmLabel: 'Terminar', danger: true }))
                revokeSessions.mutate()
            }}
          >
            Terminar sessões
          </Button>
          <ButtonLink size="sm" variant="secondary" to={`/admin/assistente/conversas?user_id=${encodeURIComponent(u.id)}`} icon={<MessagesSquare className="size-4" />}>
            Conversas com o assistente
          </ButtonLink>
          {!u.email_verified && (
            <Button size="sm" variant="secondary" icon={<MailCheck className="size-4" />} onClick={() => patch.mutate({ email_verified: true })}>
              Marcar email como confirmado
            </Button>
          )}
          {!self &&
            (u.is_admin ? (
              <Button
                size="sm"
                variant="secondary"
                icon={<ShieldOff className="size-4" />}
                onClick={() => toggle('is_admin', false, 'Remover administrador?', `${u.username} deixa de ter acesso à administração.`)}
              >
                Remover admin
              </Button>
            ) : (
              <Button
                size="sm"
                variant="secondary"
                icon={<ShieldCheck className="size-4" />}
                onClick={() => toggle('is_admin', true, 'Tornar administrador?', `${u.username} passa a ter acesso total à administração.`)}
              >
                Tornar admin
              </Button>
            ))}
          {!self &&
            (u.is_active ? (
              <Button
                size="sm"
                variant="danger"
                icon={<Ban className="size-4" />}
                onClick={() => toggle('is_active', false, 'Bloquear utilizador?', 'Todas as sessões são terminadas e o acesso aos serviços é removido na próxima reconciliação.')}
              >
                Bloquear
              </Button>
            ) : (
              <Button size="sm" variant="secondary" icon={<Unlock className="size-4" />} onClick={() => toggle('is_active', true, 'Desbloquear utilizador?', 'O utilizador volta a poder entrar.', false)}>
                Desbloquear
              </Button>
            ))}
        </div>
      </header>

      <div className="grid grid-cols-1 items-start gap-4 xl:grid-cols-[1fr_380px]">
        <div className="min-w-0 space-y-4">
          <BillingSection data={d} invalidate={invalidate} />
          {d.wallet && <UserWalletAdmin userId={u.id} wallet={d.wallet as AdminWallet} invalidate={invalidate} />}

          <Section title="Subscrições" count={d.subscriptions.length}>
            {!d.subscriptions.length ? (
              <EmptyState compact title="Sem subscrições" />
            ) : (
              <ul className="divide-y divide-border border-t border-border">
                {d.subscriptions.map((s) => (
                  <AdminSubRow key={s.id} sub={s} invalidate={invalidate} />
                ))}
              </ul>
            )}
          </Section>

          <Section
            title="Ofertas"
            icon={<Gift className="size-5" />}
            count={d.grants.length}
            actions={
              <Button size="sm" onClick={() => setGrantOpen(true)} icon={<Plus className="size-4" />}>
                Oferecer acesso
              </Button>
            }
          >
            {!d.grants.length ? (
              <EmptyState compact title="Sem ofertas" description="Usa ofertas para dar acesso gratuito a um plano." />
            ) : (
              <ul className="divide-y divide-border border-t border-border">
                {d.grants.map((g) => {
                  const active = !g.revoked_at && (!g.ends_at || new Date(g.ends_at) > new Date())
                  return (
                    <li key={g.id} className="flex flex-wrap items-center gap-3 px-5 py-3 text-sm sm:px-6">
                      <div className="min-w-0 flex-1">
                        <p className="font-medium">
                          {g.plan} {g.reason && <span className="font-normal text-muted">· {g.reason}</span>}
                        </p>
                        <p className="text-xs text-muted">
                          <DateText value={g.starts_at} /> → {g.ends_at ? <DateText value={g.ends_at} /> : 'sem fim'}
                          {g.revoked_at && (
                            <>
                              {' · revogada a '}
                              <DateText value={g.revoked_at} />
                            </>
                          )}
                        </p>
                      </div>
                      {active ? <Badge tone="success">Ativa</Badge> : <Badge tone="neutral">{g.revoked_at ? 'Revogada' : 'Expirada'}</Badge>}
                      {active && (
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={async () => {
                            if (await confirm({ title: 'Revogar oferta?', message: `O acesso a ${g.plan} por esta oferta termina já.`, confirmLabel: 'Revogar', danger: true }))
                              revokeGrant.mutate(g.id)
                          }}
                        >
                          Revogar
                        </Button>
                      )}
                    </li>
                  )
                })}
              </ul>
            )}
          </Section>

          <Section title="Cobranças" icon={<ReceiptText className="size-5" />} count={d.invoices.length}>
            {!d.invoices.length ? (
              <EmptyState compact title="Sem cobranças" />
            ) : (
              <div className="border-t border-border">
                <InvoiceList invoices={d.invoices} renderActions={(inv) => <InvoiceAdminActions inv={inv} invalidate={invalidate as QueryKey[]} />} />
              </div>
            )}
          </Section>

          <Section title="Pagamentos no fornecedor" count={d.payments.length}>
            {!d.payments.length ? (
              <EmptyState compact title="Sem pagamentos" />
            ) : (
              <Table minWidth={520}>
                <THead>
                  <Th>Data</Th>
                  <Th>Descrição</Th>
                  <Th>Estado</Th>
                  <Th className="text-right">Valor</Th>
                </THead>
                <tbody>
                  {d.payments.map((p) => (
                    <Tr key={p.id}>
                      <Td className="whitespace-nowrap text-muted">
                        <DateText value={p.charge_date ?? p.created_at} />
                      </Td>
                      <Td>
                        {p.description ?? '—'}
                        <span className="block text-xs text-subtle">{PROVIDER_LABEL[p.provider] ?? p.provider}</span>
                      </Td>
                      <Td>
                        <StatusBadge kind="payment" status={p.status} />
                      </Td>
                      <Td className="text-right font-semibold">
                        <Money cents={p.amount_cents} currency={p.currency} />
                      </Td>
                    </Tr>
                  ))}
                </tbody>
              </Table>
            )}
          </Section>

          <Section title="Auditoria" count={d.audit.length}>
            {!d.audit.length ? (
              <EmptyState compact title="Sem registos" />
            ) : (
              <ul className="scrollbar-thin max-h-[28rem] divide-y divide-border overflow-y-auto border-t border-border">
                {d.audit.map((a, i) => (
                  <li key={i} className="px-5 py-2.5 text-sm sm:px-6">
                    <div className="flex flex-wrap items-baseline justify-between gap-x-3">
                      <span className="font-medium">{actionLabel(a.action)}</span>
                      <span className="text-xs text-muted">
                        <DateText value={a.created_at} withTime />
                      </span>
                    </div>
                    <p className="text-xs text-muted">
                      {a.actor ?? 'sistema'}
                      {a.ip && ` · ${a.ip}`}
                      {a.details && Object.keys(a.details).length > 0 && <span className="font-mono"> · {JSON.stringify(a.details)}</span>}
                    </p>
                  </li>
                ))}
              </ul>
            )}
          </Section>
        </div>

        <div className="min-w-0 space-y-4">
          <Section title="Acesso e faturação" icon={<KeyRound className="size-5" />}>
            <UserAccessMode
              userId={u.id}
              jellyfinPasswordLogin={!!u.jellyfin_password_login}
              billingMode={u.billing_mode ?? 'wallet'}
              unlocked={u.unlocked_products ?? []}
              gated={(products.data ?? []).filter((p) => p.requires_invite).map((p) => ({ code: p.code, name: p.name }))}
              invalidate={invalidate}
            />
          </Section>
          <Section title="Perfil">
            <ProfileForm data={d} invalidate={invalidate} />
          </Section>

          <Section title="Métodos de pagamento" icon={<CreditCard className="size-5" />} count={d.payment_methods.length}>
            {!d.payment_methods.length ? (
              <EmptyState compact title="Sem métodos" description="O cliente ainda não autorizou nenhum pagamento." />
            ) : (
              <ul className="divide-y divide-border border-t border-border">
                {d.payment_methods.map((m) => (
                  <li key={m.id} className="px-5 py-3 text-sm sm:px-6">
                    <p className="break-words font-medium">{m.label}</p>
                    <div className="mt-1 flex flex-wrap items-center gap-1.5">
                      {m.is_default && m.status !== 'unusable' && <Badge tone="brand">Predefinido</Badge>}
                      <StatusBadge kind="method" status={m.status} />
                    </div>
                    <p className="mt-0.5 text-xs text-muted">
                      {m.provider_label} · desde {formatDate(m.created_at)}
                      {m.expires_at && ` · expira ${formatDate(m.expires_at)}`}
                    </p>
                    {m.status_reason && <p className="mt-1 text-xs text-danger">{m.status_reason}</p>}
                  </li>
                ))}
              </ul>
            )}
          </Section>

          <Section title="Acesso efetivo" icon={<CheckCircle2 className="size-5" />}>
            <FeatureSummary data={d} />
          </Section>

          <Section title="Contas de serviço" icon={<Server className="size-5" />} count={d.service_accounts.length}>
            {!d.service_accounts.length ? (
              <EmptyState compact title="Sem contas associadas" description="São criadas na reconciliação quando o utilizador tem acesso." />
            ) : (
              <ul className="divide-y divide-border border-t border-border">
                {d.service_accounts.map((sa) => (
                  <ServiceAccountRow key={sa.service} sa={sa} userId={u.id} invalidate={invalidate} />
                ))}
              </ul>
            )}
          </Section>

          <Section title="IPTV manual" icon={<Radio className="size-5" />}>
            <IptvManualForm key={iptvManual?.username ?? 'none'} userId={u.id} current={iptvManual} invalidate={invalidate} />
          </Section>

          <Section title="Detalhes">
            <dl className="space-y-2 px-5 pb-5 text-sm sm:px-6">
              {(
                [
                  ['Registo', <DateText key="c" value={u.created_at} withTime />],
                  ['Último login', <DateText key="l" value={u.last_login_at} withTime fallback="Nunca" />],
                  ['Convidado por', u.referred_by ?? '—'],
                  ['Convidou', d.invitees.length ? d.invitees.join(', ') : '—'],
                  ['Cliente Stripe', u.stripe_customer_id ?? '—'],
                  ['Cliente GoCardless', u.gocardless_customer_id ?? '—'],
                  ['Mandato GoCardless', u.gocardless_mandate_id ?? '—'],
                  ['ID no site antigo', u.legacy_id ?? '—'],
                  ['ID', u.id],
                ] as [string, React.ReactNode][]
              ).map(([k, v]) => (
                <div key={k} className="flex justify-between gap-4">
                  <dt className="shrink-0 text-muted">{k}</dt>
                  <dd className="min-w-0 break-all text-right font-mono text-xs leading-5">{v}</dd>
                </div>
              ))}
            </dl>
          </Section>
        </div>
      </div>

      <GrantModal userId={u.id} open={grantOpen} onClose={() => setGrantOpen(false)} invalidate={invalidate} />
      <Modal
        open={!!reconcileResult}
        onClose={() => setReconcileResult(null)}
        title={reconcileResult?.ok ? 'Reconciliação concluída' : 'A reconciliação falhou'}
        description={reconcileResult?.ok ? 'Estado aplicado nos serviços:' : 'Foi agendada uma nova tentativa dentro de 1 minuto.'}
        size="lg"
        footer={<Button onClick={() => setReconcileResult(null)}>Fechar</Button>}
      >
        {reconcileResult?.ok ? <JsonBlock value={reconcileResult.result} /> : <Alert tone="danger">{reconcileResult?.error}</Alert>}
      </Modal>
    </div>
  )
}
