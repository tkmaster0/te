import type { ReactNode } from 'react'
import { Link } from 'react-router-dom'
import clsx from 'clsx'
import {
  AlertTriangle,
  ArrowRight,
  BookOpen,
  Bot,
  Coins,
  Cpu,
  Database,
  Film,
  Gauge,
  MessageCircle,
  MessagesSquare,
  Subtitles,
  ThumbsDown,
  ThumbsUp,
  Webhook,
} from 'lucide-react'
import { errorMessage } from '../../../api/client'
import { useAssistantOverview, type AssistantOverview } from '../../../api/assistant'
import { Alert, Badge, Card, CardHeader, Skeleton } from '../../../components/ui'
import { AGENT_LABEL, CHANNEL_LABEL } from '../../../components/assistant/labels'
import { AssistantHeader, Code, formatTokens } from './shared'

function Kpi({ icon, label, value, hint, tone, to }: { icon: ReactNode; label: string; value: ReactNode; hint?: ReactNode; tone?: 'warning' | 'danger'; to?: string }) {
  const body = (
    <>
      <div className="flex items-center gap-2 text-xs font-medium text-muted">
        <span className={tone === 'warning' ? 'text-warning' : tone === 'danger' ? 'text-danger' : 'text-brand-text'}>{icon}</span>
        {label}
      </div>
      <p className={clsx('mt-2 text-2xl font-bold tracking-tight tabular-nums sm:text-3xl', tone === 'warning' && 'text-warning', tone === 'danger' && 'text-danger')}>{value}</p>
      {hint && <p className="mt-0.5 text-xs text-subtle">{hint}</p>}
    </>
  )
  if (to)
    return (
      <Link to={to} className="card block p-4 transition-colors hover:border-border-strong hover:bg-elevated/40 sm:p-5">
        {body}
      </Link>
    )
  return <Card className="p-4 sm:p-5">{body}</Card>
}

type State = 'ok' | 'off' | 'optional'

function ConfigRow({ icon, name, state, value, hint }: { icon: ReactNode; name: string; state: State; value: ReactNode; hint?: ReactNode }) {
  const badge =
    state === 'ok' ? (
      <Badge tone="success" dot>
        Configurado
      </Badge>
    ) : state === 'off' ? (
      <Badge tone="warning" dot>
        Não configurado
      </Badge>
    ) : (
      <Badge dot>Opcional · desligado</Badge>
    )
  return (
    <li className="flex gap-3 px-5 py-3.5 sm:px-6">
      <span className="mt-0.5 grid size-8 shrink-0 place-items-center rounded-lg bg-elevated text-muted">{icon}</span>
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
          <p className="text-sm font-semibold">{name}</p>
          {badge}
        </div>
        <p className="mt-0.5 break-words text-sm text-muted">{value}</p>
        {hint && state !== 'ok' && <p className="mt-1.5 text-xs leading-relaxed text-subtle">{hint}</p>}
      </div>
    </li>
  )
}

function ConfigCard({ c }: { c: AssistantOverview['config'] }) {
  return (
    <Card className="overflow-hidden">
      <CardHeader icon={<Gauge className="size-5" />} title="Configuração" description="Lida do .env do portal — muda lá e reinicia o contentor." />
      <ul className="mt-4 divide-y divide-border border-t border-border">
        <ConfigRow
          icon={<Cpu className="size-4" />}
          name="Modelo de linguagem"
          state={c.enabled ? 'ok' : 'off'}
          value={
            c.model ? (
              <>
                <Code>{c.model}</Code>
                {c.fast_model && c.fast_model !== c.model && (
                  <>
                    {' '}
                    · rápido: <Code>{c.fast_model}</Code>
                  </>
                )}
                {!c.enabled && ' (assistente desligado)'}
              </>
            ) : (
              'Nenhum modelo definido.'
            )
          }
          hint={
            <>
              Define <Code>ASSISTANT_ENABLED=true</Code> e <Code>ASSISTANT_MODEL</Code> (ex.: <Code>anthropic/claude-sonnet-4-5</Code>, <Code>openai/gpt-4.1-mini</Code>,{' '}
              <Code>ollama/qwen2.5:14b</Code>). Com um proxy LiteLLM ou Ollama usa <Code>ASSISTANT_API_BASE</Code>; a chave vai em <Code>ASSISTANT_API_KEY</Code>.
              Opcional: <Code>ASSISTANT_FAST_MODEL</Code> para o encaminhamento.
            </>
          }
        />
        <ConfigRow
          icon={<Database className="size-4" />}
          name="Embeddings (base de conhecimento)"
          state={c.embedding_model ? 'ok' : 'optional'}
          value={c.embedding_model ? <Code>{c.embedding_model}</Code> : 'Pesquisa por palavras-chave (funciona bem com bases pequenas).'}
          hint={
            <>
              Para pesquisa semântica define <Code>ASSISTANT_EMBEDDING_MODEL</Code> (ex.: <Code>openai/text-embedding-3-small</Code>, <Code>ollama/nomic-embed-text</Code>) e
              carrega em «Reindexar» no Conhecimento.
            </>
          }
        />
        <ConfigRow
          icon={<MessageCircle className="size-4" />}
          name="WhatsApp"
          state={c.whatsapp ? 'ok' : 'optional'}
          value={c.whatsapp ? `Fornecedor: ${c.whatsapp === 'cloud' ? 'WhatsApp Cloud API (Meta)' : 'Evolution API'}` : 'Desligado.'}
          hint={
            <>
              <Code>WHATSAPP_PROVIDER=cloud</Code> com <Code>WHATSAPP_CLOUD_TOKEN</Code>, <Code>WHATSAPP_CLOUD_PHONE_NUMBER_ID</Code>, <Code>WHATSAPP_CLOUD_APP_SECRET</Code> e{' '}
              <Code>WHATSAPP_CLOUD_VERIFY_TOKEN</Code> (webhook <Code>/api/webhooks/whatsapp</Code>), ou <Code>WHATSAPP_PROVIDER=evolution</Code> com <Code>EVOLUTION_URL</Code>,{' '}
              <Code>EVOLUTION_API_KEY</Code>, <Code>EVOLUTION_INSTANCE</Code> (webhook <Code>/api/webhooks/evolution</Code>). Define também <Code>WHATSAPP_NUMBER</Code> para o link
              wa.me.
            </>
          }
        />
        <ConfigRow
          icon={<Subtitles className="size-4" />}
          name="Bazarr (legendas)"
          state={c.bazarr ? 'ok' : 'optional'}
          value={c.bazarr ? 'O Suporte pode procurar, descarregar e sincronizar legendas.' : 'Sem Bazarr o Suporte só pesquisa pelos fornecedores do Jellyfin.'}
          hint={
            <>
              Define <Code>BAZARR_URL</Code> e <Code>BAZARR_API_KEY</Code>. Opcional: <Code>BAZARR_AUTO_COLLECTION_ID</Code> e <Code>SUBTITLE_LANGUAGES</Code>.
            </>
          }
        />
        <ConfigRow
          icon={<Webhook className="size-4" />}
          name="Seerr → Suporte (issues)"
          state={c.seerr_webhook ? 'ok' : 'optional'}
          value={
            c.seerr_webhook
              ? `Webhook ativo${c.seerr_auto_triage ? ' · o Suporte responde automaticamente às issues' : ' · só regista (triagem automática desligada)'}.`
              : 'As issues do Seerr não chegam ao assistente.'
          }
          hint={
            <>
              Define <Code>SEERR_WEBHOOK_SECRET</Code> e, no Seerr, um webhook para <Code>/api/webhooks/seerr</Code> com o header <Code>Authorization: Bearer &lt;segredo&gt;</Code>{' '}
              (eventos «Issue criada» e «Comentário»).
            </>
          }
        />
        <ConfigRow
          icon={<Film className="size-4" />}
          name="Jellyfin"
          state={c.jellyfin ? 'ok' : 'off'}
          value={c.jellyfin ? 'O Suporte consulta títulos, dispositivos e reprodução.' : 'Sem ligação ao Jellyfin as ferramentas de suporte ficam limitadas.'}
          hint={
            <>
              Define <Code>JELLYFIN_URL</Code> e <Code>JELLYFIN_API_KEY</Code>.
            </>
          }
        />
        <ConfigRow
          icon={<Gauge className="size-4" />}
          name="Langfuse (observabilidade)"
          state={c.langfuse ? 'ok' : 'optional'}
          value={c.langfuse ? 'Cada conversa é registada no Langfuse.' : 'Desligado.'}
          hint={
            <>
              <Code>ASSISTANT_LANGFUSE=true</Code> com <Code>LANGFUSE_PUBLIC_KEY</Code>, <Code>LANGFUSE_SECRET_KEY</Code> e <Code>LANGFUSE_HOST</Code>.
            </>
          }
        />
      </ul>
    </Card>
  )
}

function Bars({ title, data, labels }: { title: string; data: Record<string, number>; labels: Record<string, string> }) {
  const entries = Object.entries(data).sort((a, b) => b[1] - a[1])
  const total = entries.reduce((s, [, n]) => s + n, 0)
  return (
    <Card>
      <CardHeader title={title} description="Últimos 7 dias" />
      <div className="px-5 pb-5 pt-4 sm:px-6">
        {!entries.length ? (
          <p className="text-sm text-muted">Sem conversas nos últimos 7 dias.</p>
        ) : (
          <ul className="space-y-3">
            {entries.map(([k, n]) => (
              <li key={k}>
                <div className="mb-1 flex justify-between gap-3 text-sm">
                  <span className="truncate">{labels[k] ?? k}</span>
                  <span className="font-semibold tabular-nums">{n}</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-elevated">
                  <div className="h-full rounded-full bg-brand" style={{ width: `${total ? (n / total) * 100 : 0}%` }} />
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </Card>
  )
}

export default function AssistantOverviewPage() {
  const q = useAssistantOverview()
  const d = q.data
  const byChannel: Record<string, number> = {}
  const byAgent: Record<string, number> = {}
  for (const r of d?.last_7_days.conversations ?? []) {
    byChannel[r.channel] = (byChannel[r.channel] ?? 0) + r.count
    byAgent[r.agent] = (byAgent[r.agent] ?? 0) + r.count
  }
  const total = Object.values(byChannel).reduce((a, b) => a + b, 0)
  const fb = d ? d.last_7_days.thumbs_up + d.last_7_days.thumbs_down : 0

  return (
    <div>
      <AssistantHeader
        title="Assistente"
        description="Dois agentes separados — Faturação e Suporte — no portal, no Jellyfin, no WhatsApp e nas issues do Seerr."
      />
      {q.isError && <Alert tone="danger" title="Não foi possível carregar">{errorMessage(q.error)}</Alert>}
      {q.isLoading || !d ? (
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          {[0, 1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-28 rounded-2xl" />
          ))}
        </div>
      ) : (
        <div className="space-y-4">
          {!d.config.enabled && (
            <Alert tone="warning" title="O assistente está desligado" icon={<Bot />}>
              Os clientes não veem o botão «Ajuda». Para ativar, define no <Code>.env</Code>: <Code>ASSISTANT_ENABLED=true</Code> e <Code>ASSISTANT_MODEL=…</Code> (mais{' '}
              <Code>ASSISTANT_API_BASE</Code> / <Code>ASSISTANT_API_KEY</Code> conforme o fornecedor) e reinicia. Podes preparar as instruções e o conhecimento antes.
            </Alert>
          )}
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            <Kpi icon={<MessagesSquare className="size-4" />} label="Conversas (7 dias)" value={total} hint={`${d.whatsapp_linked} ${d.whatsapp_linked === 1 ? 'cliente' : 'clientes'} com WhatsApp ligado`} to="/admin/assistente/conversas" />
            <Kpi
              icon={<AlertTriangle className="size-4" />}
              label="Escaladas por tratar"
              value={d.escalated_open}
              tone={d.escalated_open ? 'warning' : undefined}
              hint={d.escalated_open ? 'Precisam de um humano' : 'Nada pendente'}
              to="/admin/assistente/conversas?status=escalated"
            />
            <Kpi
              icon={<BookOpen className="size-4" />}
              label="Sugestões por aprovar"
              value={d.knowledge_drafts}
              tone={d.knowledge_drafts ? 'warning' : undefined}
              hint="Rascunhos gerados a partir de conversas"
              to="/admin/assistente/conhecimento?status=draft"
            />
            <Kpi
              icon={<Coins className="size-4" />}
              label="Tokens (7 dias)"
              value={formatTokens(d.last_7_days.tokens_in + d.last_7_days.tokens_out)}
              hint={`${formatTokens(d.last_7_days.tokens_in)} entrada · ${formatTokens(d.last_7_days.tokens_out)} saída`}
            />
          </div>
          <div className="grid grid-cols-1 items-start gap-4 xl:grid-cols-[1fr_360px]">
            <ConfigCard c={d.config} />
            <div className="space-y-4">
              <Card className="p-5 sm:p-6">
                <p className="text-sm font-semibold">Avaliação das respostas</p>
                <p className="text-xs text-muted">Últimos 7 dias</p>
                <div className="mt-4 flex items-center gap-6">
                  <span className="flex items-center gap-2 text-2xl font-bold tabular-nums">
                    <ThumbsUp className="size-5 text-success" aria-label="Positivas" /> {d.last_7_days.thumbs_up}
                  </span>
                  <Link to="/admin/assistente/conversas?negative=1" className="flex items-center gap-2 text-2xl font-bold tabular-nums hover:underline">
                    <ThumbsDown className="size-5 text-danger" aria-label="Negativas" /> {d.last_7_days.thumbs_down}
                  </Link>
                </div>
                {fb > 0 && (
                  <div className="mt-3 flex h-2 overflow-hidden rounded-full bg-elevated">
                    <div className="h-full bg-success" style={{ width: `${(d.last_7_days.thumbs_up / fb) * 100}%` }} />
                    <div className="h-full bg-danger" style={{ width: `${(d.last_7_days.thumbs_down / fb) * 100}%` }} />
                  </div>
                )}
                <Link to="/admin/assistente/conversas?negative=1" className="link mt-3 inline-flex items-center gap-1 text-sm">
                  Rever respostas com 👎 <ArrowRight className="size-4" />
                </Link>
              </Card>
              <Bars title="Por canal" data={byChannel} labels={CHANNEL_LABEL} />
              <Bars title="Por agente" data={byAgent} labels={AGENT_LABEL} />
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
