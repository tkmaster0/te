import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { AlertTriangle, CheckCircle2, PackageCheck, Save, Truck, UserRound } from 'lucide-react'
import { api, errorMessage } from '../../api/client'
import { useAction } from '../../api/mutation'
import type { FulfillmentRow } from '../../api/types'
import { AccessDetailsEditor, fromRows, toRows, type KV } from '../../components/admin/AccessDetailsEditor'
import { ProductIcon } from '../../components/billing/ProductIcon'
import { Alert, Badge, Button, Card, EmptyState, PageHeader, SkeletonCard, StatusBadge } from '../../components/ui'
import { FULFILLMENT_TYPE } from '../../i18n/labels'
import { formatDate } from '../../lib/format'

const INVALIDATE = [['admin', 'fulfillment'], ['admin', 'stats'], ['admin', 'user']]

function FulfillmentCard({ row }: { row: FulfillmentRow }) {
  const [rows, setRows] = useState<KV[]>(() => toRows(row.access_details))
  const removal = row.fulfillment_status === 'pending_removal'
  const patch = useAction((body: Record<string, unknown>) => api.patch(`/api/admin/subscriptions/${row.id}`, body), {
    invalidate: INVALIDATE,
    errorTitle: 'Não foi possível guardar',
  })
  const details = fromRows(rows)
  const hasDetails = Object.keys(details).length > 0

  return (
    <Card className="overflow-hidden">
      <div className="flex flex-wrap items-start gap-3 border-b border-border p-5 sm:px-6">
        <ProductIcon icon={row.product.icon} fulfillment={row.product.fulfillment} size="sm" />
        <div className="min-w-0 flex-1">
          <p className="font-semibold">
            {row.product_name} · <span className="font-normal">{row.plan.name}</span>
          </p>
          <p className="mt-0.5 flex flex-wrap items-center gap-x-2 text-sm text-muted">
            <Link to={`/admin/utilizadores/${row.user_id}`} className="link inline-flex items-center gap-1">
              <UserRound className="size-3.5" aria-hidden /> {row.username ?? 'cliente'}
            </Link>
            {row.email && <span className="truncate">{row.email}</span>}
            <span>· desde {formatDate(row.started_at)}</span>
          </p>
        </div>
        <div className="flex flex-wrap gap-1.5">
          <StatusBadge kind="fulfillment" status={row.fulfillment_status} />
          <StatusBadge status={row.status} />
          <Badge tone="neutral">{FULFILLMENT_TYPE[row.product.fulfillment]?.label ?? row.product.fulfillment}</Badge>
        </div>
      </div>
      <div className="space-y-4 p-5 sm:px-6">
        {removal ? (
          <Alert tone="warning" title="Remover o acesso">
            Esta subscrição terminou. Desativa o acesso no serviço e marca como feito — os dados de acesso deixam de aparecer ao cliente.
          </Alert>
        ) : row.fulfillment_status === 'error' ? (
          <Alert tone="danger" title="O webhook falhou">
            O serviço externo não confirmou. Verifica-o, ou preenche os dados à mão e marca como entregue.
          </Alert>
        ) : (
          <p className="text-sm text-muted">Preenche os dados que o cliente precisa para usar o serviço. Ao guardar, ele passa a vê-los em “Os meus serviços”.</p>
        )}
        {row.access_instructions && (
          <p className="rounded-xl bg-elevated p-3 text-xs text-muted">
            <span className="font-semibold text-fg">Instruções mostradas ao cliente:</span> {row.access_instructions}
          </p>
        )}
        {!removal && <AccessDetailsEditor rows={rows} onChange={setRows} />}
      </div>
      <div className="flex flex-wrap justify-end gap-2 border-t border-border bg-bg/40 px-5 py-3.5 sm:px-6">
        {removal ? (
          <Button
            loading={patch.isPending}
            onClick={() => patch.mutate({ access_details: {}, fulfillment_status: 'done' })}
            icon={<CheckCircle2 className="size-4" />}
          >
            Acesso removido — marcar como feito
          </Button>
        ) : (
          <>
            <Button variant="ghost" disabled={patch.isPending} onClick={() => patch.mutate({ fulfillment_status: 'error' })} icon={<AlertTriangle className="size-4" />}>
              Marcar com erro
            </Button>
            <Button variant="secondary" disabled={patch.isPending} onClick={() => patch.mutate({ fulfillment_status: 'done' })}>
              Marcar como entregue
            </Button>
            <Button
              loading={patch.isPending}
              disabled={!hasDetails}
              onClick={() => patch.mutate({ access_details: details, fulfillment_status: 'done' })}
              icon={<Save className="size-4" />}
            >
              Guardar e entregar
            </Button>
          </>
        )}
      </div>
    </Card>
  )
}

export default function AdminFulfillment() {
  const q = useQuery({ queryKey: ['admin', 'fulfillment'], queryFn: () => api.get<FulfillmentRow[]>('/api/admin/fulfillment') })
  return (
    <div>
      <PageHeader
        eyebrow="Administração"
        title="Entregas"
        description="Serviços manuais ou por webhook à espera de ação: dados de acesso por preencher, acessos a remover e webhooks que falharam."
      />
      {q.isPending ? (
        <div className="space-y-4">
          <SkeletonCard lines={4} />
          <SkeletonCard lines={4} />
        </div>
      ) : q.isError ? (
        <Alert tone="danger">{errorMessage(q.error)}</Alert>
      ) : !q.data.length ? (
        <Card>
          <EmptyState
            icon={<PackageCheck className="size-6" />}
            title="Nada por entregar"
            description="Quando alguém subscrever um produto manual (ou um webhook falhar), aparece aqui."
          />
        </Card>
      ) : (
        <div className="space-y-4">
          <p className="flex items-center gap-2 text-sm text-muted">
            <Truck className="size-4" aria-hidden /> {q.data.length} {q.data.length === 1 ? 'entrega pendente' : 'entregas pendentes'}
          </p>
          {q.data.map((row) => (
            <FulfillmentCard key={row.id + (row.fulfillment_status ?? '')} row={row} />
          ))}
        </div>
      )}
    </div>
  )
}
