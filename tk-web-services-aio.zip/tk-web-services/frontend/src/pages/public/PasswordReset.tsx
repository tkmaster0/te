import { useState, type FormEvent } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { KeyRound, MailCheck } from 'lucide-react'
import { api, errorMessage } from '../../api/client'
import type { Ok } from '../../api/types'
import { AuthCard } from '../../layouts/PublicLayout'
import { Alert, Button, ButtonLink, Field, Input, PasswordInput } from '../../components/ui'
import { PasswordMeter } from '../../components/PasswordMeter'

export function ForgotPasswordPage() {
  const [email, setEmail] = useState('')
  const [sent, setSent] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  const submit = async (e: FormEvent) => {
    e.preventDefault()
    setBusy(true)
    setError(null)
    try {
      const res = await api.post<Ok>('/api/auth/forgot', { email: email.trim() })
      setSent(res.message ?? 'Se o email existir, vais receber um link para redefinir a password.')
    } catch (err) {
      setError(errorMessage(err))
    } finally {
      setBusy(false)
    }
  }

  if (sent)
    return (
      <AuthCard title="Verifica o teu email" icon={<MailCheck className="size-6" />}>
        <p className="text-sm text-muted">{sent}</p>
        <p className="mt-3 text-sm text-muted">O link é válido durante pouco tempo. Não te esqueças de ver a pasta de spam.</p>
        <ButtonLink to="/login" variant="secondary" className="mt-6 w-full">
          Voltar ao login
        </ButtonLink>
      </AuthCard>
    )

  return (
    <AuthCard title="Recuperar password" description="Indica o email da tua conta e enviamos-te um link para definires uma nova password.">
      <form onSubmit={submit} className="space-y-4">
        {error && <Alert tone="danger">{error}</Alert>}
        <Field label="Email">
          <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" inputMode="email" autoFocus required />
        </Field>
        <Button type="submit" size="lg" className="w-full" loading={busy} disabled={!email.includes('@')}>
          Enviar link
        </Button>
      </form>
      <p className="mt-6 text-center text-sm text-muted">
        Lembraste-te?{' '}
        <Link to="/login" className="link">
          Entrar
        </Link>
      </p>
    </AuthCard>
  )
}

export function ResetPasswordPage() {
  const [params] = useSearchParams()
  const token = params.get('token') ?? ''
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [done, setDone] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const mismatch = confirm.length > 0 && confirm !== password

  const submit = async (e: FormEvent) => {
    e.preventDefault()
    if (mismatch) return
    setBusy(true)
    setError(null)
    try {
      const res = await api.post<Ok>('/api/auth/reset', { token, password })
      setDone(res.message ?? 'Password redefinida.')
    } catch (err) {
      setError(errorMessage(err))
    } finally {
      setBusy(false)
    }
  }

  if (!token)
    return (
      <AuthCard title="Link incompleto" icon={<KeyRound className="size-6" />}>
        <p className="text-sm text-muted">Este link não tem o código de redefinição. Abre novamente o link do email ou pede um novo.</p>
        <ButtonLink to="/recuperar-password" className="mt-6 w-full">
          Pedir novo link
        </ButtonLink>
      </AuthCard>
    )

  if (done)
    return (
      <AuthCard title="Password redefinida" icon={<KeyRound className="size-6" />}>
        <Alert tone="success">{done}</Alert>
        <p className="mt-3 text-sm text-muted">Por segurança, terminámos todas as sessões abertas.</p>
        <ButtonLink to="/login" className="mt-6 w-full">
          Entrar
        </ButtonLink>
      </AuthCard>
    )

  return (
    <AuthCard title="Nova password" description="Escolhe uma password nova para a tua conta TKWS.">
      <form onSubmit={submit} className="space-y-4">
        {error && (
          <Alert
            tone="danger"
            action={
              <ButtonLink to="/recuperar-password" size="sm" variant="secondary">
                Pedir novo
              </ButtonLink>
            }
          >
            {error}
          </Alert>
        )}
        <Field label="Nova password">
          <PasswordInput value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="new-password" autoFocus minLength={8} required />
        </Field>
        <PasswordMeter password={password} />
        <Field label="Confirmar password" error={mismatch ? 'As passwords não coincidem.' : undefined}>
          <PasswordInput value={confirm} onChange={(e) => setConfirm(e.target.value)} autoComplete="new-password" required />
        </Field>
        <Button type="submit" size="lg" className="w-full" loading={busy} disabled={password.length < 8 || mismatch || !confirm}>
          Guardar password
        </Button>
      </form>
    </AuthCard>
  )
}
