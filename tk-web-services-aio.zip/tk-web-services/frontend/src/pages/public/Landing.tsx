import { useMemo, type MouseEvent, type ReactNode } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import {
  Activity,
  ArrowRight,
  ArrowUpRight,
  Bot,
  ChevronDown,
  Database,
  Fingerprint,
  Gift,
  Globe,
  LayoutDashboard,
  LifeBuoy,
  Lock,
  Server,
  ShieldCheck,
  Sparkles,
} from 'lucide-react'
import { useCatalog, useConfig } from '../../api/queries'
import { useAuth } from '../../auth/AuthProvider'
import { Logo } from '../../components/Logo'
import { ThemeToggleButton } from '../../components/ThemeToggle'
import { AnnouncementBanner } from '../../components/Banners'
import { ProductIcon } from '../../components/billing/ProductIcon'
import { ButtonLink, Skeleton } from '../../components/ui'
import { SiteFooter } from '../../layouts/PublicLayout'
import { formatMoney } from '../../lib/format'
import { portalName } from '../../lib/brand'
import type { Product } from '../../api/types'

const COMPANY = 'TKmaster Productions'

/** O que aparece na página inicial: serviços web e, dos serviços em beta fechado, só o nome genérico (ex.: TK CDN). */
function isPublicTile(p: Product) {
  if (p.locked) return true
  return !p.jellyfin_managed && p.fulfillment !== 'streaming' && p.kind !== 'streaming'
}

function fromPrice(p: Product) {
  if (!p.plans.length) return null
  const cheapest = p.plans.reduce((min, pl) => (pl.monthly_equivalent_cents < min.monthly_equivalent_cents ? pl : min))
  return formatMoney(cheapest.monthly_equivalent_cents, cheapest.currency)
}

/* ------------------------------------------------------------------ Hero */

/** Ilustração genérica da consola (decorativa — não mostra serviços reais). */
function ConsoleVisual() {
  const tiles = [Bot, Globe, Server, Database, ShieldCheck, Activity]
  return (
    <div className="relative mx-auto w-full max-w-md lg:max-w-none" aria-hidden>
      <div className="absolute -inset-10 rounded-[3rem] bg-brand/15 blur-3xl" />
      <div className="animate-float relative overflow-hidden rounded-[1.5rem] border border-white/10 bg-[#0e0e10]/95 text-white shadow-[0_50px_100px_-30px_rgb(0_0_0/0.85)] backdrop-blur">
        <div className="flex items-center gap-2 border-b border-white/10 px-4 py-3">
          <span className="size-2.5 rounded-full bg-[#ff5f57]/80" />
          <span className="size-2.5 rounded-full bg-[#febc2e]/80" />
          <span className="size-2.5 rounded-full bg-[#28c840]/80" />
          <span className="ml-3 h-5 flex-1 rounded-md bg-white/5 px-2 text-[10px] leading-5 text-white/40">consola · tk web services</span>
        </div>
        <div className="flex">
          <div className="hidden w-14 shrink-0 flex-col items-center gap-3 border-r border-white/10 py-4 sm:flex">
            <span className="grid size-8 place-items-center rounded-lg bg-[#f5c518] text-black">
              <LayoutDashboard className="size-4" />
            </span>
            {[0, 1, 2, 3].map((i) => (
              <span key={i} className="size-8 rounded-lg bg-white/[0.06]" />
            ))}
          </div>
          <div className="min-w-0 flex-1 p-4 sm:p-5">
            <div className="mb-4 flex items-center justify-between">
              <span className="space-y-1.5">
                <span className="block h-2.5 w-28 rounded-full bg-white/40" />
                <span className="block h-2 w-16 rounded-full bg-white/15" />
              </span>
              <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-400/10 px-2.5 py-1 text-[10px] font-semibold text-emerald-400">
                <span className="size-1.5 rounded-full bg-emerald-400" /> operacional
              </span>
            </div>
            <div className="grid grid-cols-3 gap-2.5">
              {tiles.map((Icon, i) => (
                <span key={i} className="flex flex-col gap-2 rounded-xl border border-white/10 bg-white/[0.04] p-3">
                  <span className="grid size-8 place-items-center rounded-lg bg-[#f5c518]/15 text-[#f5c518]">
                    <Icon className="size-4" />
                  </span>
                  <span className="block h-1.5 w-3/4 rounded-full bg-white/25" />
                  <span className="block h-1.5 w-1/2 rounded-full bg-white/10" />
                </span>
              ))}
            </div>
            <div className="mt-4 flex h-16 items-end gap-1 rounded-xl border border-white/10 bg-white/[0.03] p-2.5">
              {[30, 45, 38, 60, 52, 70, 64, 82, 75, 90, 84, 96].map((h, i) => (
                <span key={i} className="flex-1 rounded-sm bg-gradient-to-t from-[#f5c518]/30 to-[#f5c518]/80" style={{ height: `${h}%` }} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

/* -------------------------------------------------------------- Produtos */

function ProductTile({ product, to }: { product: Product; to: string }) {
  const price = !product.locked && fromPrice(product)
  return (
    <Link to={to} className="bento-card group flex items-start gap-4 p-5 transition-colors hover:border-brand/40 focus-visible:outline-2 focus-visible:outline-brand">
      <ProductIcon icon={product.locked ? 'cdn' : product.icon} fulfillment={product.locked ? 'none' : product.fulfillment} size="sm" />
      <span className="min-w-0 flex-1">
        <span className="flex items-center gap-2">
          <span className="font-bold tracking-tight">{product.name}</span>
          {product.locked && (
            <span className="inline-flex items-center gap-1 rounded-full border border-border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-muted">
              <Lock className="size-3" aria-hidden /> por convite
            </span>
          )}
        </span>
        {product.description && <span className="mt-0.5 line-clamp-2 block text-sm text-muted">{product.description}</span>}
        {price && <span className="mt-2 block text-xs text-subtle">desde {price}/mês</span>}
      </span>
      <ArrowUpRight className="size-4 shrink-0 text-subtle transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-brand-text" aria-hidden />
    </Link>
  )
}

function Catalog({ products, loading, to }: { products: Product[]; loading: boolean; to: string }) {
  if (loading)
    return (
      <div className="grid grid-cols-1 gap-3 md:grid-cols-2 lg:grid-cols-3">
        <Skeleton className="h-28 rounded-3xl" />
        <Skeleton className="h-28 rounded-3xl" />
        <Skeleton className="h-28 rounded-3xl" />
      </div>
    )
  if (!products.length)
    return (
      <div className="bento-card mx-auto flex max-w-xl flex-col items-center gap-3 p-8 text-center">
        <span className="grid size-12 place-items-center rounded-2xl bg-brand-soft text-brand-text">
          <Sparkles className="size-6" aria-hidden />
        </span>
        <p className="text-lg font-bold">Novos serviços a caminho</p>
        <p className="text-sm text-muted">Cria a tua conta TKWS e serás dos primeiros a ter acesso.</p>
      </div>
    )
  return (
    <div className="grid grid-cols-1 gap-3 md:grid-cols-2 lg:grid-cols-3">
      {products.map((p) => (
        <ProductTile key={p.id} product={p} to={to} />
      ))}
    </div>
  )
}

/* ---------------------------------------------------------------- Página */

/** Âncoras na mesma página sem mexer no router (o header é fixo, por isso usamos scroll-mt nas secções). */
function scrollTo(id: string) {
  return (e: MouseEvent) => {
    const el = document.getElementById(id)
    if (!el) return
    e.preventDefault()
    el.scrollIntoView({ behavior: 'smooth', block: 'start' })
    history.replaceState(null, '', `#${id}`)
  }
}

function SectionHead({ id, eyebrow, title, text, action }: { id: string; eyebrow: string; title: ReactNode; text?: string; action?: ReactNode }) {
  return (
    <div className="mb-10 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div className="max-w-2xl">
        <p className="mb-2 text-xs font-semibold uppercase tracking-[0.14em] text-brand-text">{eyebrow}</p>
        <h2 id={id} className="text-3xl font-black tracking-tight sm:text-4xl">
          {title}
        </h2>
        {text && <p className="mt-3 text-base text-muted">{text}</p>}
      </div>
      {action}
    </div>
  )
}

const PILLARS = [
  { icon: LayoutDashboard, title: 'Uma consola', text: 'Todos os serviços, contas e faturas num só lugar.' },
  { icon: Fingerprint, title: 'Uma identidade', text: 'A mesma conta TKWS para entrar em tudo.' },
  { icon: ShieldCheck, title: 'Segurança', text: 'Autenticação em dois passos e parceiros de pagamento certificados.' },
  { icon: LifeBuoy, title: 'Suporte', text: 'Assistente sempre disponível e uma equipa por trás.' },
]

export function LandingPage() {
  const { me } = useAuth()
  const { data: config } = useConfig()
  const [params] = useSearchParams()
  const convite = params.get('convite')
  const catalog = useCatalog()
  const brand = portalName(config?.app_name)
  const products = useMemo(() => (catalog.data ?? []).filter(isPublicTile), [catalog.data])
  const faq = config?.site.faq ?? []
  const registerTo = convite ? `/registar?convite=${encodeURIComponent(convite)}` : '/registar'
  const open = config?.registration_mode === 'open'
  const joinLabel = open && !convite ? 'Criar conta' : 'Tenho um convite'
  const tileTo = me ? '/app/planos' : registerTo

  const nav: [string, string][] = [
    ['produtos', 'Produtos'],
    ['plataforma', 'Plataforma'],
  ]
  if (faq.length) nav.push(['faq', 'Perguntas'])

  return (
    <div className="flex min-h-dvh flex-col overflow-x-clip">
      <AnnouncementBanner />
      <header className="sticky top-0 z-30 border-b border-border/50 bg-bg/75 backdrop-blur-xl">
        <div className="mx-auto flex h-16 max-w-6xl items-center gap-2 px-4 sm:gap-3 sm:px-6">
          <Link to="/" aria-label={`${brand} — página inicial`} className="mr-auto shrink-0">
            <Logo />
          </Link>
          <nav aria-label="Secções" className="hidden items-center gap-1 text-sm text-muted md:flex">
            {nav.map(([id, label]) => (
              <a key={id} href={`#${id}`} onClick={scrollTo(id)} className="rounded-lg px-3 py-1.5 hover:bg-hover hover:text-fg">
                {label}
              </a>
            ))}
          </nav>
          <ThemeToggleButton className="hidden sm:grid" />
          {me ? (
            <ButtonLink to="/app" size="sm" icon={<LayoutDashboard className="size-4" />}>
              Consola
            </ButtonLink>
          ) : (
            <>
              <ButtonLink to="/login" variant="ghost" size="sm">
                Entrar
              </ButtonLink>
              <ButtonLink to={registerTo} size="sm" className="max-sm:hidden">
                {joinLabel}
              </ButtonLink>
            </>
          )}
        </div>
      </header>

      <main id="conteudo" className="flex-1">
        {/* Hero */}
        <section className="relative isolate overflow-hidden">
          <div className="landing-aurora -z-10" aria-hidden />
          <div className="landing-grid -z-10" aria-hidden />
          <div className="mx-auto grid max-w-6xl grid-cols-1 items-center gap-14 px-4 pb-24 pt-14 sm:px-6 lg:grid-cols-[1.1fr_1fr] lg:pb-28 lg:pt-24">
            <div className="animate-rise">
              <p className="mb-6 inline-flex items-center gap-2 rounded-full border border-brand/30 bg-surface/70 px-3 py-1.5 text-xs font-semibold text-fg shadow-sm backdrop-blur">
                <span className="size-1.5 rounded-full bg-brand" aria-hidden />
                {COMPANY}
              </p>
              <h1 className="text-[2.7rem] font-black leading-[0.98] tracking-[-0.035em] sm:text-6xl lg:text-[4.6rem]">
                TK <span className="text-gradient-brand">Web Services</span>
              </h1>
              <p className="mt-6 max-w-xl text-lg leading-relaxed text-muted sm:text-xl">
                A plataforma de serviços digitais da {COMPANY}. Adere, gere e acompanha tudo a partir de uma única consola.
              </p>
              <div className="mt-9 flex flex-col gap-3 sm:flex-row">
                {me ? (
                  <ButtonLink to="/app" size="lg" className="glow-ring" icon={<ArrowRight className="size-5" />}>
                    Abrir a consola
                  </ButtonLink>
                ) : (
                  <>
                    <ButtonLink to={registerTo} size="lg" className="glow-ring" icon={open && !convite ? <ArrowRight className="size-5" /> : <Gift className="size-5" />}>
                      {joinLabel}
                    </ButtonLink>
                    <ButtonLink to="/login" size="lg" variant="secondary" icon={<LayoutDashboard className="size-5" />}>
                      Entrar na consola
                    </ButtonLink>
                  </>
                )}
              </div>
            </div>
            <ConsoleVisual />
          </div>
        </section>

        {/* Produtos */}
        <section id="produtos" aria-labelledby="produtos-t" className="scroll-mt-20 border-y border-border bg-surface/40">
          <div className="mx-auto max-w-6xl px-4 py-20 sm:px-6">
            <SectionHead
              id="produtos-t"
              eyebrow="Produtos"
              title="Serviços TKWS"
              text="Um catálogo que vai crescendo. Ativa o que precisas, quando precisas."
              action={
                <ButtonLink to={tileTo} variant="secondary" size="sm" icon={<ArrowRight className="size-4" />}>
                  {me ? 'Ver na consola' : 'Começar'}
                </ButtonLink>
              }
            />
            <Catalog products={products} loading={catalog.isPending} to={tileTo} />
          </div>
        </section>

        {/* Plataforma */}
        <section id="plataforma" aria-labelledby="plataforma-t" className="scroll-mt-20">
          <div className="mx-auto max-w-6xl px-4 py-20 sm:px-6">
            <SectionHead id="plataforma-t" eyebrow="Plataforma" title="Feita para ser simples." />
            <ul className="grid grid-cols-1 gap-px overflow-hidden rounded-3xl border border-border bg-border sm:grid-cols-2 lg:grid-cols-4">
              {PILLARS.map((p) => (
                <li key={p.title} className="bg-surface p-6">
                  <p.icon className="mb-4 size-6 text-brand-text" aria-hidden />
                  <h3 className="font-bold">{p.title}</h3>
                  <p className="mt-1 text-sm text-muted">{p.text}</p>
                </li>
              ))}
            </ul>
          </div>
        </section>

        {/* FAQ (só se o administrador a definir em Admin → Configuração → Conteúdo do site) */}
        {faq.length > 0 && (
          <section id="faq" aria-labelledby="faq-t" className="scroll-mt-20 border-t border-border bg-surface/40">
            <div className="mx-auto max-w-3xl px-4 py-20 sm:px-6">
              <SectionHead id="faq-t" eyebrow="Perguntas frequentes" title="Dúvidas?" />
              <div className="space-y-3">
                {faq.map((item) => (
                  <details key={item.q} className="group rounded-2xl border border-border bg-surface px-5 transition-colors open:border-brand/40 sm:px-6">
                    <summary className="flex cursor-pointer list-none items-center justify-between gap-4 py-5 font-semibold">
                      {item.q}
                      <span className="grid size-8 shrink-0 place-items-center rounded-full bg-elevated transition-transform group-open:rotate-180">
                        <ChevronDown className="size-4 text-muted" aria-hidden />
                      </span>
                    </summary>
                    <p className="whitespace-pre-line pb-5 text-sm leading-relaxed text-muted">{item.a}</p>
                  </details>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* CTA final */}
        {!me && (
          <section className="px-4 pb-20 sm:px-6">
            <div className="relative mx-auto flex max-w-6xl flex-col items-start gap-6 overflow-hidden rounded-[2rem] bg-[#0e0e10] px-6 py-12 text-white sm:flex-row sm:items-center sm:justify-between sm:px-12">
              <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(60%_120%_at_100%_0%,rgb(245_197_24/0.3),transparent_70%)]" aria-hidden />
              <div className="relative">
                <h2 className="text-2xl font-black tracking-tight sm:text-4xl">Começa hoje com a TKWS.</h2>
                <p className="mt-2 text-white/65">Uma conta para todos os serviços da {COMPANY}.</p>
              </div>
              <div className="relative flex w-full flex-col gap-3 sm:w-auto sm:flex-row">
                <Link
                  to={registerTo}
                  className="inline-flex h-12 items-center justify-center gap-2 rounded-xl bg-[#f5c518] px-7 font-semibold text-black shadow-[0_12px_40px_-10px_rgb(245_197_24/0.8)] hover:bg-[#ffd84d]"
                >
                  {joinLabel} <ArrowRight className="size-4" aria-hidden />
                </Link>
                <Link to="/login" className="inline-flex h-12 items-center justify-center rounded-xl border border-white/20 px-7 font-semibold hover:bg-white/10">
                  Entrar na consola
                </Link>
              </div>
            </div>
          </section>
        )}
      </main>
      <SiteFooter />
    </div>
  )
}
