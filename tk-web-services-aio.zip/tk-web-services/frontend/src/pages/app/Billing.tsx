import { useEffect, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { Receipt } from 'lucide-react'
import { useBillingSummary, useInvoices } from '../../api/queries'
import type { Invoice } from '../../api/types'
import { errorMessage } from '../../api/client'
import { ActionBanners } from '../../components/billing/ActionBanners'
import { InvoiceList, NotAnInvoiceNote } from '../../components/billing/InvoiceList'
import { NextChargeCard, NextChargeSkeleton } from '../../components/billing/NextChargeCard'
import { AddMethodModal, PayInvoiceModal } from '../../components/billing/PaymentModals'
import { PaymentMethodsCard } from '../../components/billing/PaymentMethodsCard'
import { Alert, Button, Card, CardHeader, EmptyState, PageHeader, SkeletonCard, SkeletonRows } from '../../components/ui'

export function BillingPage() {
  const [params, setParams] = useSearchParams()
  const summary = useBillingSummary()
  const invoices = useInvoices()
  const [paying, setPaying] = useState<Invoice | null>(null)
  const [adding, setAdding] = useState(false)
  const cancelled = params.get('cancelado') === '1'

  const findInvoice = (id: string) => invoices.data?.find((i) => i.id === id) ?? summary.data?.unpaid_invoices.find((i) => i.id === id) ?? null

  // Atalhos vindos de outras páginas: ?pagar=<id> e ?metodo=novo
  const payParam = params.get('pagar')
  const methodParam = params.get('metodo')
  useEffect(() => {
    if (payParam && (invoices.data || summary.data)) {
      const inv = findInvoice(payParam)
      if (inv) setPaying(inv)
      params.delete('pagar')
      setParams(params, { replace: true })
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [payParam, invoices.data, summary.data])
  useEffect(() => {
    if (methodParam === 'novo' && summary.data) {
      setAdding(true)
      params.delete('metodo')
      setParams(params, { replace: true })
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [methodParam, summary.data])

  const s = summary.data
  const firstUnpaid = s?.unpaid_invoices[0]?.id ?? null

  return (
    <div>
      <PageHeader title="Faturação" description="Uma só cobrança por mês, com todos os teus serviços. Aqui vês o que vais pagar, como pagas e o histórico." />

      <div className="space-y-6">
        {cancelled && (
          <Alert
            tone="info"
            title="Operação cancelada"
            action={
              <Button
                size="sm"
                variant="ghost"
                onClick={() => {
                  params.delete('cancelado')
                  setParams(params, { replace: true })
                }}
              >
                Fechar
              </Button>
            }
          >
            Não foi feita nenhuma alteração nem cobrança. Podes tentar outra vez quando quiseres.
          </Alert>
        )}

        {s && (
          <ActionBanners
            actions={s.actions}
            firstUnpaidId={firstUnpaid}
            onAddMethod={() => setAdding(true)}
            onPayInvoice={(id) => setPaying(findInvoice(id))}
          />
        )}

        <div className="grid grid-cols-1 items-start gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,26rem)]">
          {summary.isPending ? (
            <>
              <NextChargeSkeleton />
              <SkeletonCard lines={3} />
            </>
          ) : summary.isError ? (
            <Alert tone="danger" className="lg:col-span-2">
              {errorMessage(summary.error)}
            </Alert>
          ) : (
            s && (
              <>
                <NextChargeCard summary={s} explain defaultOpen />
                <PaymentMethodsCard id="metodos" methods={s.payment_methods} onAdd={() => setAdding(true)} />
              </>
            )
          )}
        </div>

        <Card className="overflow-hidden">
          <CardHeader icon={<Receipt className="size-5" />} title="Histórico de cobranças" description="Toca numa cobrança para veres o que incluiu." />
          <div className="mt-4 border-t border-border">
            {invoices.isPending ? (
              <SkeletonRows rows={4} />
            ) : invoices.isError ? (
              <div className="p-5">
                <Alert tone="danger">{errorMessage(invoices.error)}</Alert>
              </div>
            ) : !invoices.data?.length ? (
              <EmptyState compact icon={<Receipt className="size-6" />} title="Ainda não há cobranças" description="Quando for emitida a primeira, aparece aqui." />
            ) : (
              <InvoiceList invoices={invoices.data} onPay={setPaying} />
            )}
          </div>
          <div className="border-t border-border px-5 py-3 sm:px-6">
            <NotAnInvoiceNote />
          </div>
        </Card>
      </div>

      <PayInvoiceModal invoice={paying} open={!!paying} onClose={() => setPaying(null)} />
      <AddMethodModal open={adding} onClose={() => setAdding(false)} />
    </div>
  )
}
