import { useEffect, useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { ArrowDownLeft, ArrowUpRight, CalendarClock, Dices, PiggyBank, Plus, ReceiptText, Sparkles, Wallet as WalletIcon, Zap } from 'lucide-react'
import clsx from 'clsx'
import { api, errorMessage } from '../../api/client'
import { BILLING_INVALIDATE } from '../../api/keys'
import { useAction } from '../../api/mutation'
import { useBillingSummary, useWallet } from '../../api/queries'
import type { Provider, TopupOut, WalletOut } from '../../api/types'
import { useMe } from '../../auth/AuthProvider'
import { firstAvailable, ProviderChoice, SecureRedirectNote } from '../../components/billing/ProviderChoice'
import { goToProvider } from '../../components/billing/hooks'
import { AmountPicker } from '../../components/wallet/AmountPicker'
import { Alert, Badge, Button, ButtonLink, Card, CardBody, CardHeader, EmptyState, PageHeader, Skeleton, Switch } from '../../components/ui'
import { WALLET_TX } from '../../i18n/labels'
import { formatDateTime, formatLongDate, formatMoney, formatSignedMoney } from '../../lib/format'

function BalanceHero({ w }: { w: WalletOut }) {
  const months = w.covers_months
  return (
    <section
      aria-label="Saldo da carteira"
      className="relative overflow-hidden rounded-3xl border border-brand/30 bg-gradient-to-br from-brand/20 via-surface to-surface p-6 sm:p-8"
    >
      <div className="pointer-events-none absolute -right-16 -top-16 size-64 rounded-full bg-brand/10 blur-3xl" aria-hidden />
      <div className="relative flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="flex items-center gap-2 text-sm font-medium text-muted">
            <WalletIcon className="size-4 text-brand-text" aria-hidden /> Saldo disponível
          </p>
          <p className={clsx('mt-2 text-5xl font-extrabold tracking-tight tabular-nums sm:text-6xl', w.balance_cents < 0 && 'text-danger')}>
            {formatMoney(w.balance_cents)}
          </p>
          <p className="mt-2 text-sm text-muted">
            {w.balance_cents <= 0
              ? 'Carrega a carteira: o saldo paga os teus serviços antes de qualquer cobrança.'
              : months && months >= 1
                ? `Chega para ${months} ${months === 1 ? 'mês' : 'meses'} dos teus serviços — sem cobranças.`
                : w.recurring_cents > 0
                  ? `Paga ${formatMoney(Math.min(w.balance_cents, w.recurring_cents))} da próxima mensalidade.`
                  : 'Usa-o em qualquer serviço TK.'}
          </p>
          {w.pending_topup_cents > 0 && (
            <p className="mt-3 inline-flex items-center gap-2 rounded-full bg-info-soft px-3 py-1 text-xs font-semibold text-info">
              <CalendarClock className="size-3.5" aria-hidden /> {formatMoney(w.pending_topup_cents)} a caminho (débito direto em confirmação)
            </p>
          )}
        </div>
        <div className="flex flex-wrap gap-2">
          <a href="#carregar" className="inline-flex h-11 items-center gap-2 rounded-xl bg-brand px-5 text-sm font-semibold text-brand-fg hover:bg-brand-hover">
            <Plus className="size-4" aria-hidden /> Carregar
          </a>
          {w.games_enabled && (
            <ButtonLink to="/app/jogos" variant="secondary" size="lg" icon={<Dices className="size-4" />} className="h-11 text-sm">
              Jogar
            </ButtonLink>
          )}
        </div>
      </div>
    </section>
  )
}

function MonthlyCard({ w, providers }: { w: WalletOut; providers: ReturnType<typeof useProviders> }) {
  const active = !!w.monthly_topup_cents
  const [editing, setEditing] = useState(!active)
  const [amount, setAmount] = useState(w.monthly_topup_cents ?? w.suggested_monthly_cents)
  const [skip, setSkip] = useState(w.monthly_skip_when_covered)
  const [provider, setProvider] = useState<Provider | null>(null)
  useEffect(() => {
    setEditing(!w.monthly_topup_cents)
    setAmount(w.monthly_topup_cents ?? w.suggested_monthly_cents)
    setSkip(w.monthly_skip_when_covered)
  }, [w.monthly_topup_cents, w.suggested_monthly_cents, w.monthly_skip_when_covered])
  const chosen = provider ?? firstAvailable(providers.list)
  const save = useAction(
    (body: { amount_cents: number | null; skip_when_covered: boolean; provider?: Provider }) => api.put<TopupOut>('/api/wallet/monthly', body),
    {
      invalidate: BILLING_INVALIDATE,
      onSuccess: (res) => {
        if (res.status === 'redirect' && res.redirect_url) goToProvider(res.redirect_url)
        else setEditing(false)
      },
    },
  )
  const needsMethod = !w.has_payment_method
  const bonus = w.monthly_bonus_percent
  const valid = amount >= w.min_monthly_cents && amount <= w.max_monthly_cents
  return (
    <Card className={clsx('flex flex-col', !active && 'border-brand/40')}>
      <CardHeader
        icon={<PiggyBank className="size-5" />}
        title={
          <span className="flex flex-wrap items-center gap-2">
            Carregamento mensal {active ? <Badge tone="success">Ativo</Badge> : <Badge tone="brand">Recomendado</Badge>}
          </span>
        }
        description="Uma só cobrança por mês, no teu dia de faturação. Paga os serviços desse mês e o que sobrar fica na carteira."
      />
      <CardBody className="flex-1 space-y-5">
        {!editing && active ? (
          <div className="space-y-4">
            <div className="flex items-end justify-between gap-4 rounded-2xl bg-elevated/70 p-4">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-subtle">Todos os meses</p>
                <p className="text-3xl font-extrabold tabular-nums">{formatMoney(w.monthly_topup_cents)}</p>
              </div>
              <p className="text-right text-sm text-muted">
                Próximo
                <br />
                <strong className="text-fg">{formatLongDate(w.next_billing_at)}</strong>
              </p>
            </div>
            <Switch
              checked={w.monthly_skip_when_covered}
              onChange={(v) => save.mutate({ amount_cents: w.monthly_topup_cents, skip_when_covered: v })}
              disabled={save.isPending}
              label="Saltar o mês em que o saldo já chega"
              description="Se o saldo pagar os serviços desse mês, não carregamos nada (mensalidade grátis)."
            />
            {w.recurring_cents > (w.monthly_topup_cents ?? 0) && (
              <Alert tone="info">
                Os teus serviços custam {formatMoney(w.recurring_cents)}/mês. Se o saldo não chegar, a diferença é cobrada na mesma cobrança — nunca ficas sem serviço.
              </Alert>
            )}
          </div>
        ) : (
          <div className="space-y-5">
            {bonus > 0 && (
              <p className="flex items-center gap-2 rounded-xl bg-brand-soft px-3 py-2 text-sm font-medium text-brand-text">
                <Sparkles className="size-4 shrink-0" aria-hidden /> Ganhas {bonus}% extra em créditos em cada carregamento mensal.
              </p>
            )}
            <AmountPicker
              value={amount}
              onChange={setAmount}
              presets={[500, 1000, 1500, 2000, 3000]}
              min={w.min_monthly_cents}
              max={w.max_monthly_cents}
              suggested={w.recurring_cents > 0 ? w.suggested_monthly_cents : null}
              label="Carregamento mensal"
            />
            <Switch
              checked={skip}
              onChange={setSkip}
              label="Saltar o mês em que o saldo já chega"
              description="Ganhaste nos jogos ou sobrou saldo? Nesse mês não há cobrança."
            />
            {needsMethod && (
              <div className="space-y-3">
                <p className="text-sm text-muted">Escolhe como pagar. Autorizas uma vez e fica tratado.</p>
                <ProviderChoice providers={providers.list} value={chosen} onChange={setProvider} name="monthly-provider" />
                <SecureRedirectNote />
              </div>
            )}
          </div>
        )}
        {save.isError && <Alert tone="danger">{errorMessage(save.error)}</Alert>}
      </CardBody>
      <div className="flex flex-wrap items-center justify-end gap-2 border-t border-border px-5 py-3.5 sm:px-6">
        {!editing && active ? (
          <>
            <Button variant="ghost" onClick={() => save.mutate({ amount_cents: null, skip_when_covered: true })} loading={save.isPending}>
              Desligar
            </Button>
            <Button variant="secondary" onClick={() => setEditing(true)}>
              Alterar valor
            </Button>
          </>
        ) : (
          <>
            {active && (
              <Button variant="ghost" onClick={() => setEditing(false)}>
                Cancelar
              </Button>
            )}
            <Button
              onClick={() =>
                save.mutate({ amount_cents: amount, skip_when_covered: skip, ...(needsMethod && chosen ? { provider: chosen } : {}) })
              }
              disabled={!valid || (needsMethod && !chosen)}
              loading={save.isPending}
              icon={<Zap className="size-4" />}
            >
              {active ? 'Guardar' : `Ativar ${formatMoney(amount)}/mês`}
            </Button>
          </>
        )}
      </div>
    </Card>
  )
}

function useProviders() {
  const summary = useBillingSummary()
  const methods = summary.data?.payment_methods ?? []
  const def = methods.find((m) => m.id === summary.data?.default_payment_method_id) ?? null
  return { list: summary.data?.providers ?? [], def, loading: summary.isPending }
}

function TopupCard({ w, providers }: { w: WalletOut; providers: ReturnType<typeof useProviders> }) {
  const [amount, setAmount] = useState(1000)
  const [provider, setProvider] = useState<Provider | null>(null)
  const [other, setOther] = useState(false)
  const chosen = provider ?? firstAvailable(providers.list)
  const useSaved = !!providers.def && !other
  const topup = useAction((body: { amount_cents: number; provider?: Provider }) => api.post<TopupOut>('/api/wallet/topup', body), {
    invalidate: BILLING_INVALIDATE,
    onSuccess: (res) => {
      if (res.status === 'redirect' && res.redirect_url) goToProvider(res.redirect_url)
    },
  })
  const valid = amount >= w.min_topup_cents && amount <= w.max_topup_cents
  return (
    <Card id="carregar" className="flex scroll-mt-24 flex-col">
      <CardHeader icon={<Plus className="size-5" />} title="Carregamento único" description={`A partir de ${formatMoney(w.min_topup_cents)}. O saldo fica logo disponível.`} />
      <CardBody className="flex-1 space-y-5">
        <AmountPicker value={amount} onChange={setAmount} presets={[500, 1000, 2000, 5000]} min={w.min_topup_cents} max={w.max_topup_cents} label="Carregamento único" />
        {useSaved ? (
          <p className="text-sm text-muted">
            Pagas com <strong className="text-fg">{providers.def?.label}</strong>.{' '}
            <button type="button" className="link" onClick={() => setOther(true)}>
              Usar outro
            </button>
          </p>
        ) : (
          <div className="space-y-3">
            <ProviderChoice providers={providers.list} value={chosen} onChange={setProvider} name="topup-provider" />
            <SecureRedirectNote />
          </div>
        )}
        {topup.isError && <Alert tone="danger">{errorMessage(topup.error)}</Alert>}
      </CardBody>
      <div className="flex justify-end border-t border-border px-5 py-3.5 sm:px-6">
        <Button
          onClick={() => topup.mutate(useSaved ? { amount_cents: amount } : { amount_cents: amount, provider: chosen ?? undefined })}
          disabled={!valid || (!useSaved && !chosen)}
          loading={topup.isPending || (topup.isSuccess && topup.data?.status === 'redirect')}
        >
          Carregar {formatMoney(amount)}
        </Button>
      </div>
    </Card>
  )
}

function SwitchToMonthly({ w }: { w: WalletOut }) {
  const save = useAction((amount: number) => api.put<TopupOut>('/api/wallet/monthly', { amount_cents: amount, skip_when_covered: true }), {
    invalidate: BILLING_INVALIDATE,
  })
  if (w.monthly_topup_cents || !w.has_services || !w.has_payment_method) return null
  return (
    <Alert
      tone="info"
      icon={<Sparkles className="size-5" />}
      title="Passa para os créditos mensais"
      action={
        <Button size="sm" onClick={() => save.mutate(w.suggested_monthly_cents)} loading={save.isPending}>
          Ativar {formatMoney(w.suggested_monthly_cents)}/mês
        </Button>
      }
    >
      Pagas o mesmo, no mesmo dia e com o mesmo método — mas tudo passa pela carteira: o que sobrar (ou ganhares nos jogos) paga meses inteiros e, nesses meses, não
      há cobrança.
      {w.monthly_bonus_percent > 0 && <> Ainda ganhas {w.monthly_bonus_percent}% extra em créditos.</>}
    </Alert>
  )
}

function Transactions({ w }: { w: WalletOut }) {
  if (!w.transactions.length)
    return <EmptyState icon={<WalletIcon className="size-6" />} title="Ainda sem movimentos" description="Os carregamentos, pagamentos e prémios aparecem aqui." />
  return (
    <ul className="divide-y divide-border">
      {w.transactions.map((t) => {
        const plus = t.amount_cents > 0
        return (
          <li key={t.id} className="flex items-center gap-3 py-3">
            <span className={clsx('grid size-9 shrink-0 place-items-center rounded-full', plus ? 'bg-success-soft text-success' : 'bg-elevated text-muted')}>
              {plus ? <ArrowDownLeft className="size-4" aria-hidden /> : <ArrowUpRight className="size-4" aria-hidden />}
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium">{t.description}</p>
              <p className="text-xs text-subtle">
                {WALLET_TX[t.kind] ?? t.kind} · {formatDateTime(t.created_at)}
              </p>
            </div>
            <div className="text-right">
              <p className={clsx('text-sm font-semibold tabular-nums', plus && 'text-success')}>{formatSignedMoney(t.amount_cents)}</p>
              <p className="text-xs text-subtle tabular-nums">{formatMoney(t.balance_after_cents)}</p>
            </div>
          </li>
        )
      })}
    </ul>
  )
}

export function WalletPage() {
  const me = useMe()
  const wallet = useWallet()
  const providers = useProviders()
  const [params, setParams] = useSearchParams()
  const cancelled = params.get('cancelado') === '1'
  const w = wallet.data
  return (
    <div className="space-y-8">
      <PageHeader
        title="Carteira"
        description="Os teus créditos pagam os serviços antes de qualquer cobrança. 1 crédito = 1 €."
        actions={
          <Link to="/app/faturacao" className="link text-sm">
            Ver cobranças
          </Link>
        }
      />
      {cancelled && (
        <Alert
          tone="info"
          title="Carregamento cancelado"
          action={
            <Button size="sm" variant="ghost" onClick={() => (params.delete('cancelado'), setParams(params, { replace: true }))}>
              Fechar
            </Button>
          }
        >
          Não foi cobrado nada.
        </Alert>
      )}
      {!me.email_verified && <Alert tone="warning">Confirma o teu email para poderes carregar a carteira.</Alert>}
      {wallet.isPending ? (
        <>
          <Skeleton className="h-48 rounded-3xl" />
          <div className="grid gap-4 lg:grid-cols-2">
            <Skeleton className="h-80" />
            <Skeleton className="h-80" />
          </div>
        </>
      ) : wallet.isError || !w ? (
        <Alert tone="danger">{errorMessage(wallet.error)}</Alert>
      ) : !w.enabled ? (
        <EmptyState icon={<WalletIcon className="size-6" />} title="Carteira indisponível" description="A carteira de créditos não está ativa de momento." />
      ) : (
        <>
          <BalanceHero w={w} />
          {w.monthly_enabled ? (
            <>
              {w.wallet_only && !w.monthly_topup_cents && w.has_services && (
                <Alert tone="warning" title="Os teus serviços são pagos pela carteira">
                  Ativa o carregamento mensal para nunca ficares sem saldo — é uma só cobrança por mês.
                </Alert>
              )}
              {!w.wallet_only && <SwitchToMonthly w={w} />}
              <div className="grid items-stretch gap-4 lg:grid-cols-2">
                <MonthlyCard w={w} providers={providers} />
                <TopupCard w={w} providers={providers} />
              </div>
            </>
          ) : (
            <div className="grid items-stretch gap-4 lg:grid-cols-2">
              <TopupCard w={w} providers={providers} />
              <Card className="flex flex-col">
                <CardHeader
                  icon={<ReceiptText className="size-5" />}
                  title="Os teus serviços"
                  description="São cobrados ao método de pagamento que autorizaste (débito direto ou cartão), numa só cobrança por mês."
                />
                <CardBody className="flex-1 space-y-3 text-sm text-muted">
                  <p>
                    O valor ajusta-se sozinho quando aderes, mudas de plano ou cancelas — não tens de carregar nada nem voltar a autorizar. O saldo da carteira, se tiveres,
                    é usado primeiro.
                  </p>
                  <Link to="/app/faturacao" className="link inline-flex items-center gap-1 font-medium">
                    Ver faturação e métodos de pagamento
                  </Link>
                </CardBody>
              </Card>
            </div>
          )}
          <Card>
            <CardHeader title="Movimentos" description="Carregamentos, pagamentos de serviços, devoluções e jogos." />
            <CardBody className="pt-2">
              <Transactions w={w} />
            </CardBody>
          </Card>
        </>
      )}
    </div>
  )
}
