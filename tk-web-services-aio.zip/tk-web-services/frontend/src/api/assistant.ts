/** Assistentes de IA (Faturação / Suporte): tipos e queries do chat do cliente e do painel admin. */
import { keepPreviousData, useQuery } from '@tanstack/react-query'
import { api, ApiError, qs } from './client'

export type AgentName = 'billing' | 'support'
export type MsgRole = 'user' | 'assistant' | 'event' | 'tool'
export type ActionStatus = 'pending' | 'done' | 'cancelled' | 'expired' | 'failed'
export type ConvStatus = 'open' | 'escalated' | 'resolved' | 'closed'
export type Channel = 'web' | 'jellyfin' | 'whatsapp' | 'seerr'

export interface MsgUi {
  type?: 'agent_switch' | 'confirm' | 'action_result' | string
  agent?: AgentName
  reason?: string
  action_id?: string
  summary?: string
  status?: ActionStatus
  hidden?: boolean
}

export interface ChatMessage {
  id: number
  role: MsgRole
  agent: AgentName | string
  content: string | null
  ui: MsgUi | null
  feedback: number | null
  created_at: string | null
}

export interface ToolCallInfo {
  id: string
  name: string
  arguments: Record<string, unknown>
}

export interface AdminChatMessage extends ChatMessage {
  tool_calls: ToolCallInfo[] | null
  tool_name: string | null
  model: string | null
  tokens_in: number | null
  tokens_out: number | null
  feedback_note: string | null
}

export interface Conversation {
  id: string
  channel: Channel | string
  agent: AgentName | string
  title: string | null
  status: ConvStatus | string
  created_at: string
  updated_at: string | null
}

export interface ConversationWithMessages extends Conversation {
  messages: ChatMessage[]
}

export interface AssistantStatus {
  enabled: boolean
  agents: { name: AgentName; label: string }[]
  whatsapp: { enabled: boolean; number: string | null; linked: string | null }
}

export interface ChatResponse {
  conversation_id: string
  agent: AgentName
  messages: ChatMessage[]
}

export interface WhatsAppLink {
  code: string
  expires_in: number
  wa_link: string | null
}

// ------------------------------------------------------------------ admin
export interface AssistantOverview {
  config: {
    enabled: boolean
    model: string | null
    fast_model: string | null
    embedding_model: string | null
    langfuse: boolean
    whatsapp: string | null
    bazarr: boolean
    seerr_webhook: boolean
    seerr_auto_triage: boolean
    jellyfin: boolean
  }
  last_7_days: {
    conversations: { channel: string; agent: string; count: number }[]
    thumbs_up: number
    thumbs_down: number
    tokens_in: number
    tokens_out: number
  }
  escalated_open: number
  knowledge_drafts: number
  whatsapp_linked: number
}

export interface InstructionVersion {
  id: number
  version: number
  note: string | null
  active: boolean
  created_by: string | null
  created_at: string
  content: string
}

export interface AgentTool {
  name: string
  description: string
  confirm: boolean
  channels: string[] | null
}

export interface AgentInfo {
  name: AgentName
  label: string
  rules: string
  default_instructions: string
  instructions: string
  versions: InstructionVersion[]
  tools: AgentTool[]
  knowledge: number
}

export type KnowledgeStatus = 'active' | 'draft' | 'archived'

export interface KnowledgeItem {
  id: number
  agent: AgentName
  title: string
  content: string
  tags: string[]
  source: 'manual' | 'promoted' | 'suggested' | string
  status: KnowledgeStatus
  uses: number
  embedded: boolean
  source_conversation_id: string | null
  created_by: string | null
  created_at: string
  updated_at: string | null
}

export interface KnowledgeIn {
  agent: AgentName
  title: string
  content: string
  tags: string[]
  status: KnowledgeStatus
}

export interface AdminConversationRow extends Conversation {
  username: string | null
  user_messages: number
  negative: number
  escalation: string | null
  admin_note: string | null
}

export interface PendingActionInfo {
  id: string
  tool: string
  summary: string
  status: ActionStatus
  result: string | null
  created_at: string
}

export interface AdminConversationDetail extends Conversation {
  username: string | null
  user_id: string | null
  external_ref: string | null
  meta: { escalation?: string; urgency?: string; [k: string]: unknown } | null
  admin_note: string | null
  reviewed: boolean
  messages: AdminChatMessage[]
  actions: PendingActionInfo[]
}

// ------------------------------------------------------------------ queries
export const akeys = {
  status: ['assistant', 'status'] as const,
  conversations: ['assistant', 'conversations'] as const,
  conversation: (id: string) => ['assistant', 'conversation', id] as const,
  admin: ['admin', 'assistant'] as const,
  overview: ['admin', 'assistant', 'overview'] as const,
  agents: ['admin', 'assistant', 'agents'] as const,
  knowledge: ['admin', 'assistant', 'knowledge'] as const,
  convs: ['admin', 'assistant', 'conversations'] as const,
  conv: (id: string) => ['admin', 'assistant', 'conversation', id] as const,
}

export function useAssistantStatus(enabled = true) {
  return useQuery({
    queryKey: akeys.status,
    queryFn: () => api.get<AssistantStatus>('/api/assistant/status'),
    staleTime: 5 * 60_000,
    retry: (n, err) => !(err instanceof ApiError && err.status < 500) && n < 2,
    enabled,
  })
}

export function useMyConversations(enabled = true) {
  return useQuery({
    queryKey: akeys.conversations,
    queryFn: () => api.get<Conversation[]>('/api/assistant/conversations'),
    enabled,
  })
}

export function useAssistantOverview() {
  return useQuery({ queryKey: akeys.overview, queryFn: () => api.get<AssistantOverview>('/api/admin/assistant/overview') })
}

export function useAssistantAgents() {
  return useQuery({ queryKey: akeys.agents, queryFn: () => api.get<AgentInfo[]>('/api/admin/assistant/agents') })
}

export function useKnowledge(params: { agent?: string; status?: string; q?: string }) {
  return useQuery({
    queryKey: [...akeys.knowledge, params],
    queryFn: () => api.get<KnowledgeItem[]>(`/api/admin/assistant/knowledge${qs(params)}`),
    placeholderData: keepPreviousData,
  })
}

export function useAdminConversations(params: { status?: string; agent?: string; channel?: string; negative?: boolean; user_id?: string; page?: number }) {
  return useQuery({
    queryKey: [...akeys.convs, params],
    queryFn: () => api.get<AdminConversationRow[]>(`/api/admin/assistant/conversations${qs({ ...params, negative: params.negative || undefined })}`),
    placeholderData: keepPreviousData,
  })
}

export function useAdminConversation(id: string) {
  return useQuery({
    queryKey: akeys.conv(id),
    queryFn: () => api.get<AdminConversationDetail>(`/api/admin/assistant/conversations/${encodeURIComponent(id)}`),
  })
}
