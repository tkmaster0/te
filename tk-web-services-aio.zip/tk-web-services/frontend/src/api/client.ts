/** Cliente HTTP da API do portal: cookies de sessão, header anti-CSRF e erros normalizados. */

export class ApiError extends Error {
  status: number
  detail: string
  data: unknown
  /** Âmbito da sessão quando o pedido foi recusado por a sessão ser limitada (header X-TK-Session-Scope). */
  scope: string | null

  constructor(status: number, detail: string, data?: unknown, scope: string | null = null) {
    super(detail)
    this.name = 'ApiError'
    this.status = status
    this.detail = detail
    this.data = data
    this.scope = scope
  }
}

/** Evento global emitido quando a API recusa um pedido por a sessão ser limitada (aberta a partir do Jellyfin). */
export const SCOPED_EVENT = 'tk:session-scoped'

type Method = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE'

function fallbackMessage(status: number): string {
  if (status === 0) return 'Sem ligação ao servidor. Verifica a tua ligação à internet.'
  if (status === 401) return 'A tua sessão terminou. Entra novamente.'
  if (status === 403) return 'Não tens permissão para fazer isto.'
  if (status === 404) return 'Não encontrado.'
  if (status === 429) return 'Demasiados pedidos. Espera um pouco e tenta de novo.'
  if (status === 502 || status === 503 || status === 504) return 'Um serviço externo não respondeu. Tenta novamente daqui a pouco.'
  if (status >= 500) return 'Ocorreu um erro no servidor. Tenta novamente.'
  return 'Não foi possível concluir o pedido.'
}

export async function request<T>(method: Method, path: string, body?: unknown, signal?: AbortSignal): Promise<T> {
  const headers: Record<string, string> = { Accept: 'application/json' }
  if (method !== 'GET') headers['X-Requested-With'] = 'tkportal'
  if (body !== undefined) headers['Content-Type'] = 'application/json'

  let res: Response
  try {
    res = await fetch(path, {
      method,
      headers,
      credentials: 'include',
      body: body !== undefined ? JSON.stringify(body) : undefined,
      signal,
    })
  } catch (err) {
    if ((err as Error)?.name === 'AbortError') throw err
    throw new ApiError(0, fallbackMessage(0))
  }

  const text = await res.text()
  let data: unknown = null
  if (text) {
    try {
      data = JSON.parse(text)
    } catch {
      data = text
    }
  }
  if (!res.ok) {
    let detail = fallbackMessage(res.status)
    if (data && typeof data === 'object' && 'detail' in data) {
      const d = (data as { detail: unknown }).detail
      if (typeof d === 'string' && d.trim()) detail = d
      else if (Array.isArray(d) && d.length && typeof d[0]?.msg === 'string') detail = d[0].msg
    }
    const scope = res.status === 403 ? res.headers.get('X-TK-Session-Scope') : null
    if (scope && typeof window !== 'undefined') window.dispatchEvent(new CustomEvent(SCOPED_EVENT, { detail: scope }))
    throw new ApiError(res.status, detail, data, scope)
  }
  return data as T
}

export const api = {
  get: <T>(path: string, signal?: AbortSignal) => request<T>('GET', path, undefined, signal),
  post: <T>(path: string, body?: unknown) => request<T>('POST', path, body ?? {}),
  put: <T>(path: string, body?: unknown) => request<T>('PUT', path, body ?? {}),
  patch: <T>(path: string, body?: unknown) => request<T>('PATCH', path, body ?? {}),
  del: <T>(path: string) => request<T>('DELETE', path),
  /** Envio de ficheiros (multipart/form-data) com o mesmo tratamento de erros. */
  upload: async <T>(path: string, form: FormData): Promise<T> => {
    let res: Response
    try {
      res = await fetch(path, { method: 'POST', headers: { 'X-Requested-With': 'tkportal', Accept: 'application/json' }, credentials: 'include', body: form })
    } catch {
      throw new ApiError(0, fallbackMessage(0))
    }
    const text = await res.text()
    let data: unknown = null
    try {
      data = text ? JSON.parse(text) : null
    } catch {
      data = text
    }
    if (!res.ok) {
      const d = data && typeof data === 'object' && 'detail' in data ? (data as { detail: unknown }).detail : null
      throw new ApiError(res.status, typeof d === 'string' && d ? d : fallbackMessage(res.status), data)
    }
    return data as T
  },
}

export function errorMessage(err: unknown): string {
  if (err instanceof ApiError) return err.detail
  if (err instanceof Error && err.message) return err.message
  return 'Ocorreu um erro inesperado.'
}

export function qs(params: Record<string, string | number | boolean | null | undefined>): string {
  const sp = new URLSearchParams()
  for (const [k, v] of Object.entries(params)) {
    if (v === undefined || v === null || v === '') continue
    sp.set(k, String(v))
  }
  const s = sp.toString()
  return s ? `?${s}` : ''
}
