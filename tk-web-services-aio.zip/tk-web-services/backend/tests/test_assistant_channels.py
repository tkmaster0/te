"""Canais dos assistentes: WhatsApp (Cloud API e Evolution), webhook do Seerr e chat dentro do Jellyfin."""
from __future__ import annotations

import hashlib
import hmac
import json
from datetime import timedelta

import httpx
import pytest
from sqlalchemy import update
from asst import linked_user
from conftest import add_method, add_sub, create_user, dbs, drain, fetch, get, jobs_of, update_row
from fakes import call

from app.assistant.channels import whatsapp
from app.assistant.llm import LLMError, LLMResponse
from app.assistant.models import AssistantConversation, AssistantMessage, ChannelIdentity, PendingAction
from app.db import utcnow
from app.models import EmailToken, Job, Subscription, SubStatus

GRAPH = "https://graph.facebook.com/v21.0/PNID/messages"
EVO = "http://evolution.test/message/sendText/tk"
PHONE = "351912345678"


async def run_all_jobs() -> int:
    """Corre a fila toda, incluindo jobs com atraso (ex.: o do Seerr espera 5 s)."""
    async with dbs() as db:
        await db.execute(update(Job).where(Job.status == "pending").values(run_after=utcnow() - timedelta(seconds=1)))
        await db.commit()
    return await drain()


# =========================================================================== WhatsApp
@pytest.fixture
def outbox(svc):
    """Mensagens enviadas pelo portal (Cloud API e Evolution)."""
    box = {"cloud": [], "evo": [], "status": 200}

    def cloud(request):
        box["cloud"].append(json.loads(request.content))
        return httpx.Response(box["status"], json={"messages": [{"id": "wamid.x"}]})

    def evo(request):
        box["evo"].append({"body": json.loads(request.content), "apikey": request.headers.get("apikey")})
        return httpx.Response(box["status"], json={})

    svc.mock.post(GRAPH).mock(side_effect=cloud)
    svc.mock.post(EVO).mock(side_effect=evo)
    return box


@pytest.fixture
def cloud(settings, llm):
    settings.set("whatsapp_provider", "cloud")
    settings.set("whatsapp_cloud_token", "wa-token")
    settings.set("whatsapp_cloud_phone_number_id", "PNID")
    settings.set("whatsapp_cloud_app_secret", "app-secret")
    settings.set("whatsapp_cloud_verify_token", "verify-me")
    settings.set("whatsapp_number", "351210000000")
    return llm


@pytest.fixture
def evolution(settings, llm):
    settings.set("whatsapp_provider", "evolution")
    settings.set("evolution_url", "http://evolution.test")
    settings.set("evolution_api_key", "evo-key")
    settings.set("evolution_instance", "tk")
    settings.set("evolution_webhook_token", "evo-hook-token")
    return llm


_mid = iter(range(1, 10**6))


def cloud_msg(text=None, *, phone=PHONE, button=None, kind=None, mid=None) -> dict:
    m = {"from": phone, "id": mid or f"wamid.{next(_mid)}", "timestamp": "1"}
    if button:
        m.update(type="interactive", interactive={"type": "button_reply",
                                                  "button_reply": {"id": button, "title": text or "Confirmar"}})
    elif kind:
        m.update(type=kind, **{kind: {"id": "media"}})
    else:
        m.update(type="text", text={"body": text})
    return {"object": "whatsapp_business_account", "entry": [{"id": "1", "changes": [{"field": "messages", "value": {
        "messaging_product": "whatsapp", "contacts": [{"wa_id": phone, "profile": {"name": "Ana"}}],
        "messages": [m]}}]}]}


async def post_cloud(client, payload: dict, *, secret="app-secret", signature: str | None = None):
    body = json.dumps(payload).encode()
    sig = signature if signature is not None else "sha256=" + hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    return await client.post("/api/webhooks/whatsapp", content=body,
                             headers={"X-Hub-Signature-256": sig, "Content-Type": "application/json"})


def evo_msg(text, *, phone=PHONE, from_me=False, jid_suffix="@s.whatsapp.net", mid=None) -> dict:
    return {"event": "messages.upsert", "instance": "tk", "data": {
        "key": {"remoteJid": f"{phone}{jid_suffix}", "fromMe": from_me, "id": mid or f"EVO{next(_mid)}"},
        "pushName": "Ana", "message": {"conversation": text}}}


async def post_evo(client, payload, token="evo-hook-token"):
    return await client.post("/api/webhooks/evolution", json=payload, headers={"Authorization": f"Bearer {token}"})


async def link_number(make_client, user, phone=PHONE, *, post=post_cloud, msg=cloud_msg) -> str:
    c = make_client()
    await c.login_as(user)
    r = await c.post("/api/assistant/whatsapp/link")
    assert r.status_code == 200, r.text
    code = r.json()["code"]
    await post(c, msg(f"Olá, o meu código é {code}", phone=phone))
    await drain()
    return code


def texts(outbox, kind="cloud") -> list[str]:
    if kind == "cloud":
        return [m["text"]["body"] if m["type"] == "text" else m["interactive"]["body"]["text"] for m in outbox[kind]]
    return [m["body"]["text"] for m in outbox[kind]]


async def test_cloud_verify_and_signature(client, cloud):
    r = await client.get("/api/webhooks/whatsapp", params={"hub.mode": "subscribe", "hub.verify_token": "verify-me",
                                                           "hub.challenge": "12345"})
    assert r.status_code == 200 and r.text == "12345"
    r = await client.get("/api/webhooks/whatsapp", params={"hub.mode": "subscribe", "hub.verify_token": "errado",
                                                           "hub.challenge": "12345"})
    assert r.status_code == 403
    assert (await post_cloud(client, cloud_msg("olá"), secret="outro")).status_code == 401
    assert (await post_cloud(client, cloud_msg("olá"), signature="")).status_code == 401
    assert (await post_cloud(client, cloud_msg("olá"), signature="sha1=abc")).status_code == 401
    assert not await jobs_of("assistant_whatsapp")


async def test_cloud_parse_kinds_and_dedupe(client, cloud):
    items = whatsapp.CloudAdapter.parse(cloud_msg("oi"))
    assert items[0]["text"] == "oi" and items[0]["phone"] == PHONE and items[0]["name"] == "Ana"
    items = whatsapp.CloudAdapter.parse(cloud_msg("Confirmar", button="confirm:abc"))
    assert items[0]["button"] == "confirm:abc" and items[0]["text"] == "Confirmar"
    items = whatsapp.CloudAdapter.parse(cloud_msg(kind="image"))
    assert items[0]["text"] == "[image]"
    payload = cloud_msg("olá", mid="wamid.same")
    r = await post_cloud(client, payload)
    assert r.json() == {"received": 1}
    r = await post_cloud(client, payload)  # o Meta reenvia: não duplica
    assert r.json() == {"received": 0}
    assert len(await jobs_of("assistant_whatsapp")) == 1


async def test_unlinked_number_gets_instructions_once(client, cloud, outbox):
    await post_cloud(client, cloud_msg("olá"))
    await post_cloud(client, cloud_msg("está aí alguém?"))
    await drain()
    assert len(outbox["cloud"]) == 1 and "Conta → WhatsApp" in texts(outbox)[0]
    assert not cloud.calls  # números não ligados nunca chegam ao modelo
    # Um código inválido tem sempre resposta própria (mesmo dentro da janela das instruções).
    await post_cloud(client, cloud_msg("TK-ZZZZZZ"))
    await drain()
    assert "não é válido ou já expirou" in texts(outbox)[-1]


async def test_link_with_code_and_chat(make_client, cloud, outbox, svc):
    u, _ = await linked_user(svc, "ana")
    code = await link_number(make_client, u)
    assert code.startswith("TK-") and len(code) == 9
    ident = (await fetch(ChannelIdentity))[0]
    assert ident.user_id == u.id and ident.external_id == PHONE and ident.verified_at
    assert "está agora ligado" in texts(outbox)[-1]
    c = make_client()
    await c.login_as(u)
    st = (await c.get("/api/assistant/status")).json()
    assert st["whatsapp"]["linked"] == whatsapp.mask(PHONE) and PHONE not in json.dumps(st)
    # O código não serve duas vezes.
    await post_cloud(c, cloud_msg(code, phone="351999999999"))
    await drain()
    assert "não é válido" in texts(outbox)[-1]
    # Mensagem normal → agente → resposta enviada (markdown convertido para WhatsApp, links absolutos).
    cloud.script = [LLMResponse("**Olá!** Vê a [faturação](/app/faturacao).")]
    await post_cloud(c, cloud_msg("o filme não carrega"))
    await drain()
    assert texts(outbox)[-1] == "*Olá!* Vê a faturação: https://portal.test/app/faturacao."
    conv = (await fetch(AssistantConversation))[0]
    assert (conv.channel, conv.external_ref, conv.user_id) == ("whatsapp", PHONE, u.id)
    assert "WhatsApp" in cloud.agent_calls()[-1]["messages"][0]["content"]


async def test_expired_code_and_one_number_per_account(make_client, cloud, outbox, svc):
    u = await create_user("ana")
    c = make_client()
    await c.login_as(u)
    code = (await c.post("/api/assistant/whatsapp/link")).json()["code"]
    async with dbs() as db:
        await db.execute(update(EmailToken).where(EmailToken.purpose == "whatsapp_link")
                         .values(expires_at=utcnow() - timedelta(minutes=1)))
        await db.commit()
    await post_cloud(c, cloud_msg(code))
    await drain()
    assert "expirou" in texts(outbox)[-1] and not await fetch(ChannelIdentity)
    # Gerar um código novo invalida o anterior.
    first = (await c.post("/api/assistant/whatsapp/link")).json()["code"]
    second = (await c.post("/api/assistant/whatsapp/link")).json()["code"]
    await post_cloud(c, cloud_msg(first))
    await drain()
    assert not await fetch(ChannelIdentity)
    await post_cloud(c, cloud_msg(second.lower().replace("-", "")))  # "tkabc123" também serve
    await drain()
    assert [i.external_id for i in await fetch(ChannelIdentity)] == [PHONE]
    # Ligar outro número à mesma conta desliga o primeiro.
    await link_number(make_client, u, phone="351933333333")
    assert [i.external_id for i in await fetch(ChannelIdentity)] == ["351933333333"]
    # O mesmo número ligado a outra conta passa para essa conta.
    bia = await create_user("bia")
    await link_number(make_client, bia, phone="351933333333")
    assert [(i.user_id, i.external_id) for i in await fetch(ChannelIdentity)] == [(bia.id, "351933333333")]


async def test_scoped_session_cannot_link_whatsapp(make_client, cloud):
    u = await create_user("ana")
    c = make_client()
    await c.login_as(u, scope="streaming")
    assert (await c.post("/api/assistant/whatsapp/link")).status_code == 403
    assert (await c.delete("/api/assistant/whatsapp")).status_code == 403


async def test_confirm_via_button_and_commands(make_client, cloud, outbox, svc):
    u = await create_user("ana")
    await add_method(svc, u)
    sub = await add_sub(u, current_period_start=utcnow(), current_period_end=utcnow() + timedelta(days=30))
    await link_number(make_client, u)
    c = make_client()
    cloud.script = [call("cancel_subscription", subscription_id=sub.id), LLMResponse("Responde SIM para confirmar.")]
    await post_cloud(c, cloud_msg("quero cancelar a subscrição"))
    await drain()
    interactive = [m for m in outbox["cloud"] if m["type"] == "interactive"]
    assert len(interactive) == 1
    buttons = interactive[0]["interactive"]["action"]["buttons"]
    action = (await fetch(PendingAction))[0]
    assert [b["reply"]["id"] for b in buttons] == [f"confirm:{action.id}", f"cancel:{action.id}"]
    assert interactive[0]["interactive"]["body"]["text"].startswith("Confirmas? Cancelar")
    # Botão de uma ação que não é deste cliente: recusado.
    bia = await create_user("bia")
    await link_number(make_client, bia, phone="351977777777")
    await post_cloud(c, cloud_msg("Confirmar", phone="351977777777", button=f"confirm:{action.id}"))
    await drain()
    assert texts(outbox)[-1] == "Esta ação não é tua."
    assert (await get(Subscription, sub.id)).status == SubStatus.active
    await post_cloud(c, cloud_msg("Confirmar", button=f"confirm:{action.id}"))
    await drain()
    assert texts(outbox)[-1].startswith("Cancelado")
    assert (await get(Subscription, sub.id)).status == SubStatus.canceling
    n_llm = len(cloud.calls)
    # "novo" fecha a conversa; "desligar" desliga o número. Nenhum dos dois passa pelo modelo.
    await post_cloud(c, cloud_msg("novo"))
    await drain()
    assert texts(outbox)[-1].startswith("Conversa nova")
    assert {cv.status for cv in await fetch(AssistantConversation, channel="whatsapp")} == {"closed"}
    await post_cloud(c, cloud_msg("Desligar"))
    await drain()
    assert texts(outbox)[-1].startswith("Número desligado")
    assert [i.user_id for i in await fetch(ChannelIdentity)] == [bia.id]
    assert len(cloud.calls) == n_llm


async def test_outbound_retries_on_server_errors(make_client, cloud, outbox, svc):
    outbox["status"] = 500
    await post_cloud(make_client(), cloud_msg("olá"))
    await drain()
    send = await jobs_of("assistant_whatsapp_send")
    assert send[0].status == "pending" and send[0].attempts == 1 and "WhatsApp Cloud 500" in send[0].last_error
    outbox["status"] = 429
    await run_all_jobs()
    assert (await jobs_of("assistant_whatsapp_send"))[0].attempts == 2
    outbox["status"] = 200
    await run_all_jobs()
    assert (await jobs_of("assistant_whatsapp_send"))[0].status == "done"
    assert len(outbox["cloud"]) == 3
    # 4xx (ex.: número inválido) não se repete.
    outbox["status"] = 400
    whatsapp._unlinked_notice.clear()
    await post_cloud(make_client(), cloud_msg("olá outra vez"))
    await drain()
    assert all(j.status == "done" for j in await jobs_of("assistant_whatsapp_send"))


async def test_evolution_adapter_end_to_end(make_client, evolution, outbox, svc):
    c = make_client()
    assert (await post_evo(c, evo_msg("olá"), token="errado")).status_code == 401
    r = await c.post("/api/webhooks/evolution?token=evo-hook-token", json=evo_msg("olá"))
    assert r.json() == {"received": 1}
    # Mensagens nossas, grupos e outros eventos são ignorados.
    assert (await post_evo(c, evo_msg("eco", from_me=True))).json() == {"received": 0}
    assert (await post_evo(c, evo_msg("grupo", jid_suffix="@g.us"))).json() == {"received": 0}
    assert (await post_evo(c, {"event": "connection.update", "data": {}})).json() == {"received": 0}
    assert (await post_cloud(c, cloud_msg("x"))).status_code == 401  # o outro fornecedor está desligado
    await drain()
    assert outbox["evo"][0]["apikey"] == "evo-key" and "Conta → WhatsApp" in texts(outbox, "evo")[0]
    # Ligar e confirmar uma ação respondendo "SIM".
    u = await create_user("ana")
    await add_method(svc, u)
    sub = await add_sub(u, current_period_start=utcnow(), current_period_end=utcnow() + timedelta(days=30))
    await link_number(make_client, u, post=post_evo, msg=evo_msg)
    assert "está agora ligado" in texts(outbox, "evo")[-1]
    evolution.script = [call("cancel_subscription", subscription_id=sub.id), LLMResponse("Confirma com SIM.")]
    await post_evo(c, evo_msg("quero cancelar a subscrição"))
    await drain()
    sent = texts(outbox, "evo")
    assert any("Responde *SIM* para confirmar" in t for t in sent)
    await post_evo(c, evo_msg("SIM"))
    await drain()
    assert texts(outbox, "evo")[-1].startswith("Cancelado")
    assert (await get(Subscription, sub.id)).status == SubStatus.canceling
    outbox["status"] = 503
    await post_evo(c, evo_msg("olá de novo"))
    await drain()
    assert any(j.status == "pending" and "Evolution API 503" in (j.last_error or "")
               for j in await jobs_of("assistant_whatsapp_send"))


# =========================================================================== Seerr
SECRET = "seerr-hook-secret"


@pytest.fixture
def seerr_hook(settings, llm):
    settings.set("seerr_webhook_secret", SECRET)
    return llm


async def post_seerr(client, ntype: str, issue_id, *, auth=f"Bearer {SECRET}", comment: str | None = None):
    payload = {"notification_type": ntype, "event": "x", "subject": "Filme",
               "issue": {"issue_id": str(issue_id) if issue_id else "", "issue_type": "SUBTITLES"},
               "comment": {"comment_message": comment or ""}}
    return await client.post("/api/webhooks/seerr", json=payload, headers={"Authorization": auth} if auth else {})


async def test_seerr_webhook_auth_and_ignored_types(client, seerr_hook, settings):
    assert (await post_seerr(client, "ISSUE_CREATED", 1, auth=None)).status_code == 401
    assert (await post_seerr(client, "ISSUE_CREATED", 1, auth="Bearer errado")).status_code == 401
    assert (await post_seerr(client, "TEST_NOTIFICATION", None)).json() == {"ok": True}
    assert (await post_seerr(client, "MEDIA_APPROVED", None)).json() == {"ignored": "MEDIA_APPROVED"}
    assert (await post_seerr(client, "ISSUE_RESOLVED", 3)).json() == {"ignored": "ISSUE_RESOLVED"}
    assert not await jobs_of("assistant_seerr")
    assert (await post_seerr(client, "ISSUE_CREATED", 1, auth=SECRET)).json() == {"ok": True}  # sem "Bearer"
    assert (await post_seerr(client, "ISSUE_CREATED", 1)).json() == {"ok": True}  # repetido: não duplica
    jobs = await jobs_of("assistant_seerr")
    assert len(jobs) == 1 and jobs[0].payload == {"issue_id": 1, "event": "ISSUE_CREATED"}
    settings.set("seerr_webhook_secret", None)
    assert (await post_seerr(client, "ISSUE_CREATED", 2, auth="Bearer ")).status_code == 401


@pytest.fixture
async def triage(svc, bazarr, seerr_hook):
    """Cliente ligado ao Jellyfin/Seerr, com um filme e uma issue de legendas em falta."""
    u, jf = await linked_user(svc, "ana", seerr_id=7)
    movie = svc.jf.add_item("The Matrix", year=1999, provider_ids={"Imdb": "tt0133093", "Tmdb": "603"})
    media = svc.seerr.add_media("movie", 603, jellyfin_id=movie["Id"])
    rec = bazarr.add_movie("The Matrix", imdb="tt0133093")
    bazarr.search_results[("movie", rec["radarrId"])] = [
        {"provider": "opensubtitles", "subtitle": "SUB-PT", "language": "pt", "score": 90}]
    creator = {"id": 7, "jellyfinUserId": jf["Id"], "email": "ana@example.com"}
    issue = svc.seerr.add_issue(creator, "Faltam as legendas em português", media=media)
    return {"user": u, "movie": movie, "issue": issue, "creator": creator, "bazarr": bazarr}


def pick_option_then(next_step):
    """Passo do modelo: lê o option_id do resultado de search_subtitles e pede o download."""

    def step(messages, tools):
        tool_msg = json.loads(next(m for m in reversed(messages) if m["role"] == "tool")["content"])
        return call("download_subtitle", item_id=next_step, option_id=tool_msg["options"][0]["option_id"])

    return step


async def test_seerr_triage_end_to_end(client, triage, svc, seerr_hook):
    issue, movie = triage["issue"], triage["movie"]
    seerr_hook.script = [
        call("search_subtitles", item_id=movie["Id"], language="pt"),
        pick_option_then(movie["Id"]),
        call("resolve_issue", note="legenda descarregada"),
        LLMResponse("Descarreguei a legenda em português. Reabre o filme e escolhe-a no menu."),
    ]
    assert (await post_seerr(client, "ISSUE_CREATED", issue["id"])).status_code == 200
    await run_all_jobs()
    first = seerr_hook.agent_calls()[0]
    assert "resolve_issue" in first["tools"] and "transfer_to_billing" not in first["tools"]
    assert "cancel_subscription" not in first["tools"] and "quick_connect_authorize" not in first["tools"]
    user_msg = first["messages"][-1]["content"]
    assert f"Issue #{issue['id']}" in user_msg and movie["Id"] in user_msg and "legendas em português" in user_msg
    assert triage["bazarr"].downloads[0]["subtitle"] == "SUB-PT"
    comments = svc.seerr.issues[issue["id"]]["comments"]
    assert comments[-1]["message"].startswith("🤖 Suporte TKFLIX: Descarreguei a legenda")
    assert svc.seerr.issues[issue["id"]]["status"] == 2
    conv = (await fetch(AssistantConversation))[0]
    assert (conv.channel, conv.status, conv.user_id, conv.scope) == ("seerr", "resolved", triage["user"].id,
                                                                      "streaming")
    # O nosso próprio comentário gera um webhook ISSUE_COMMENT: ignorado (sem chamar o agente). O resumo da memória
    # (job atrasado que o run_all_jobs também corre) não conta.
    n = len(seerr_hook.agent_calls())
    svc.seerr.issues[issue["id"]]["status"] = 1
    await post_seerr(client, "ISSUE_COMMENT", issue["id"], comment=comments[-1]["message"])
    await run_all_jobs()
    assert len(seerr_hook.agent_calls()) == n


async def test_seerr_customer_comment_continues_and_staff_is_ignored(client, triage, svc, seerr_hook):
    issue = triage["issue"]
    seerr_hook.script = [LLMResponse("Vou verificar.")]
    await post_seerr(client, "ISSUE_CREATED", issue["id"])
    await run_all_jobs()
    assert svc.seerr.issues[issue["id"]]["status"] == 1  # não chamou resolve_issue → continua aberta
    svc.seerr.add_comment(issue["id"], {"id": 1}, "Comentário da equipa")
    await post_seerr(client, "ISSUE_COMMENT", issue["id"], comment="Comentário da equipa")
    await run_all_jobs()
    n = len(seerr_hook.calls)
    svc.seerr.add_comment(issue["id"], triage["creator"], "Continua sem legendas!")
    seerr_hook.script = [LLMResponse("Tenta agora.")]
    await post_seerr(client, "ISSUE_COMMENT", issue["id"], comment="Continua sem legendas!")
    await run_all_jobs()
    assert len(seerr_hook.calls) > n
    assert "Continua sem legendas!" in seerr_hook.agent_calls()[-1]["messages"][-1]["content"]
    assert svc.seerr.issues[issue["id"]]["comments"][-1]["message"].endswith("Tenta agora.")
    assert len(await fetch(AssistantConversation)) == 1
    # Conversa escalada: uma pessoa está a tratar, o assistente não responde mais.
    conv = (await fetch(AssistantConversation))[0]
    await update_row(AssistantConversation, conv.id, status="escalated")
    svc.seerr.add_comment(issue["id"], triage["creator"], "Olá??")
    n = len(seerr_hook.agent_calls())  # (o resumo da memória, em segundo plano, não conta)
    await post_seerr(client, "ISSUE_COMMENT", issue["id"], comment="Olá??")
    await run_all_jobs()
    assert len(seerr_hook.agent_calls()) == n


async def test_seerr_unmapped_user_is_never_matched_by_email(client, triage, svc, seerr_hook):
    """O email no Seerr é editável pelo utilizador: não pode dar acesso à conta de outro cliente. E um criador sem conta
    no portal não gasta chamadas ao modelo (fica para um humano)."""
    intruder = {"id": 55, "jellyfinUserId": "jf-desconhecido", "email": "ana@example.com"}
    issue = svc.seerr.add_issue(intruder, "Legendas", media=triage["issue"]["media"])
    seerr_hook.script = [LLMResponse("Vou passar à equipa.")]
    await post_seerr(client, "ISSUE_CREATED", issue["id"])
    await run_all_jobs()
    assert not await fetch(AssistantConversation)
    assert not seerr_hook.agent_calls()
    assert len(svc.seerr.issues[issue["id"]]["comments"]) == 1  # só a descrição original


async def test_seerr_hourly_cap(client, triage, svc, seerr_hook, settings):
    settings.set("assistant_seerr_max_per_hour", 1)
    creator = triage["issue"]["createdBy"]
    seerr_hook.script = [LLMResponse("Ok."), LLMResponse("Ok.")]
    await post_seerr(client, "ISSUE_CREATED", triage["issue"]["id"])
    other = svc.seerr.add_issue(creator, "Outra", media=triage["issue"]["media"])
    await post_seerr(client, "ISSUE_CREATED", other["id"])
    await run_all_jobs()
    assert len(await fetch(AssistantConversation)) == 1


async def test_seerr_user_mapped_by_seerr_account(client, triage, svc, seerr_hook):
    creator = {"id": 7, "jellyfinUserId": None}
    issue = svc.seerr.add_issue(creator, "Áudio dessincronizado", issue_type=2, media=triage["issue"]["media"])
    seerr_hook.script = [LLMResponse("Ok.")]
    await post_seerr(client, "ISSUE_CREATED", issue["id"])
    await run_all_jobs()
    assert (await fetch(AssistantConversation))[0].user_id == triage["user"].id


async def test_seerr_llm_failure_does_not_resolve(client, triage, svc, seerr_hook):
    issue = triage["issue"]
    seerr_hook.script = [call("resolve_issue"), LLMError("timeout")]
    await post_seerr(client, "ISSUE_CREATED", issue["id"])
    await run_all_jobs()
    assert svc.seerr.issues[issue["id"]]["status"] == 1
    assert (await fetch(AssistantConversation))[0].status != "resolved"


async def test_seerr_job_edge_cases(client, triage, svc, seerr_hook, settings):
    issue = triage["issue"]
    svc.seerr.issues[issue["id"]]["status"] = 2  # já resolvida
    await post_seerr(client, "ISSUE_CREATED", issue["id"])
    await run_all_jobs()
    assert not seerr_hook.calls
    await post_seerr(client, "ISSUE_CREATED", 424242)  # não existe no Seerr → falha permanente
    await run_all_jobs()
    failed = [j for j in await jobs_of("assistant_seerr") if j.payload["issue_id"] == 424242][0]
    assert failed.status == "failed" and "PermanentError" in failed.last_error
    settings.set("seerr_auto_triage", False)
    svc.seerr.issues[issue["id"]]["status"] = 1
    svc.seerr.add_comment(issue["id"], triage["creator"], "outro")
    await post_seerr(client, "ISSUE_COMMENT", issue["id"], comment="outro")
    await run_all_jobs()
    assert not seerr_hook.calls


# =========================================================================== Jellyfin (Custom Pages)
TOKEN = "jf-user-token-0000000001"
BRIDGE = "/api/integrations/jellyfin/assistant"


@pytest.fixture
async def jf_ana(svc, llm):
    u, jf = await linked_user(svc, "ana")
    svc.jf.user_tokens[TOKEN] = jf["Id"]
    return u


async def bridge(client, origin="https://tv.test", **body):
    headers = {"Origin": origin} if origin else {}
    return await client.post(BRIDGE, json={"token": TOKEN, **body}, headers=headers)


async def test_bridge_chat_history_and_cors(client, jf_ana, llm):
    r = await bridge(client)
    assert r.status_code == 200 and r.json() == {"conversation_id": None, "messages": []}
    assert r.headers["access-control-allow-origin"] == "https://tv.test"
    llm.script = [LLMResponse("Olá! Em que posso ajudar?")]
    r = await bridge(client, message="as legendas não aparecem")
    data = r.json()
    assert data["agent"] == "support" and data["messages"][-1]["content"] == "Olá! Em que posso ajudar?"
    conv = await get(AssistantConversation, data["conversation_id"])
    assert (conv.channel, conv.scope, conv.user_id) == ("jellyfin", "streaming", jf_ana.id)
    assert "Jellyfin" in llm.agent_calls()[-1]["messages"][0]["content"]
    r = await bridge(client)  # histórico da conversa recente
    assert [m["role"] for m in r.json()["messages"]] == ["user", "assistant"]
    assert r.json()["conversation_id"] == conv.id
    r = await client.options(BRIDGE, headers={"Origin": "https://tv.test",
                                              "Access-Control-Request-Method": "POST"})
    assert r.status_code == 204 and r.headers["access-control-allow-origin"] == "https://tv.test"
    r = await bridge(client, origin="https://evil.example", message="olá")
    assert r.status_code == 403
    r = await client.options(BRIDGE, headers={"Origin": "https://evil.example"})
    assert "access-control-allow-origin" not in r.headers


async def test_bridge_auth_errors(client, svc, llm, settings):
    r = await client.post(BRIDGE, json={"token": "token-desconhecido-000", "message": "olá"})
    assert r.status_code == 401
    stranger = svc.jf.add_user("estranho")
    svc.jf.user_tokens["token-do-estranho-000"] = stranger["Id"]
    r = await client.post(BRIDGE, json={"token": "token-do-estranho-000", "message": "olá"})
    assert r.status_code == 404 and "não está ligada" in r.json()["detail"]
    u, jf = await linked_user(svc, "ana")
    svc.jf.user_tokens[TOKEN] = jf["Id"]
    settings.set("assistant_enabled", False)
    assert (await bridge(client, message="olá")).status_code == 503


async def test_bridge_confirm_and_isolation(make_client, jf_ana, llm, svc):
    c = make_client()
    await add_method(svc, jf_ana)
    sub = await add_sub(jf_ana, current_period_start=utcnow(), current_period_end=utcnow() + timedelta(days=30))
    llm.script = [call("cancel_subscription", subscription_id=sub.id), LLMResponse("Carrega em Confirmar.")]
    data = (await bridge(c, message="quero cancelar a subscrição")).json()
    confirm = next(m for m in data["messages"] if (m.get("ui") or {}).get("type") == "confirm")
    assert confirm["ui"]["status"] == "pending"
    assert "carregar em Confirmar" in (await fetch(AssistantMessage, role="tool"))[0].content
    r = await bridge(c, action_id=confirm["ui"]["action_id"], confirm=True)
    assert r.status_code == 200 and r.json()["messages"][0]["content"].startswith("Cancelado")
    assert (await get(Subscription, sub.id)).status == SubStatus.canceling
    r = await bridge(c, action_id=confirm["ui"]["action_id"], confirm=True)
    assert r.status_code == 400
    # Conversa de outra pessoa → conversa nova; ação de outra pessoa → 404.
    bia = await create_user("bia")
    async with dbs() as db:
        other = AssistantConversation(user_id=bia.id, channel="jellyfin", agent="support", scope="streaming")
        db.add(other)
        await db.flush()
        act = PendingAction(conversation_id=other.id, user_id=bia.id, agent="billing", tool="cancel_subscription",
                            args={}, summary="x", expires_at=utcnow() + timedelta(minutes=5))
        db.add(act)
        await db.commit()
    assert (await bridge(c, action_id=act.id, confirm=True)).status_code == 404
    llm.script = [LLMResponse("Olá.")]
    data = (await bridge(c, message="olá", conversation_id=other.id)).json()
    assert data["conversation_id"] != other.id
    r = await bridge(c, conversation_id=other.id)
    assert r.json()["conversation_id"] != other.id


async def test_bridge_cannot_confirm_actions_from_unscoped_channels(make_client, jf_ana, llm, svc):
    """Uma ação preparada no chat do portal (sem âmbito) não pode ser confirmada a partir do Jellyfin."""
    from conftest import make_product

    await make_product("cloud", plans=[("cloud-m", 300, "month")])
    await add_method(svc, jf_ana)
    cloud_sub = await add_sub(jf_ana, "cloud-m", current_period_start=utcnow(),
                              current_period_end=utcnow() + timedelta(days=30))
    web = make_client()
    await web.login_as(jf_ana)
    llm.script = [call("cancel_subscription", subscription_id=cloud_sub.id), LLMResponse("Confirma.")]
    out = (await web.post("/api/assistant/chat", json={"message": "quero cancelar a cloud"})).json()
    action_id = next(m for m in out["messages"] if (m.get("ui") or {}).get("type") == "confirm")["ui"]["action_id"]
    r = await bridge(make_client(), action_id=action_id, confirm=True)
    assert r.status_code == 404
    assert (await get(Subscription, cloud_sub.id)).status == SubStatus.active
    assert (await get(PendingAction, action_id)).status == "pending"


async def test_whatsapp_process_ignored_when_disabled(settings, llm):
    settings.set("whatsapp_provider", "none")
    async with dbs() as db:
        await whatsapp.process(db, {"phone": PHONE, "text": "olá", "id": "x"})
    assert not await jobs_of("assistant_whatsapp_send") and not llm.calls


async def test_bridge_refuses_jellyfin_admins_and_accepts_extra_origins(client, jf_ana, svc, llm, settings):
    svc.jf.users[next(iter(svc.jf.user_tokens.values()))]["Policy"]["IsAdministrator"] = True
    r = await bridge(client, message="olá")
    assert r.status_code == 403 and "administrador" in r.json()["detail"]
    assert not llm.calls
    svc.jf.users[svc.jf.user_tokens[TOKEN]]["Policy"]["IsAdministrator"] = False
    settings.set("jellyfin_extra_origins", ["https://jellyfin.lan:8920"])
    from app.routers import bridge as bridge_router
    bridge_router._token_cache.clear()
    r = await bridge(client, origin="https://jellyfin.lan:8920")
    assert r.status_code == 200 and r.headers["access-control-allow-origin"] == "https://jellyfin.lan:8920"
