"""Issues do Seerr → Agente de Suporte.

No Seerr: Definições → Notificações → Webhook
  * URL: https://<portal>/api/webhooks/seerr
  * Authorization Header: o valor de SEERR_WEBHOOK_SECRET
  * Tipos: "Issue Reported", "Issue Comment" (os outros são ignorados)
  * JSON Payload: o modelo por omissão serve.

Uma issue nova é analisada pelo agente de suporte (ex.: legendas em falta → procura e descarrega; legenda
dessincronizada → sincroniza), a resposta é publicada como comentário e, se ficou resolvida, a issue é fechada.
Comentários do cliente continuam a conversa; comentários do próprio assistente e da equipa são ignorados.
"""
from __future__ import annotations

import logging
from datetime import timedelta

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from ...config import get_settings
from ...db import utcnow
from ...integrations.seerr import SeerrClient, SeerrError
from ...models import ServiceAccount, User
from ...services.jobs import PermanentError, RetryLater, job_handler
from .. import runtime
from ..models import AssistantConversation

log = logging.getLogger("tkportal.assistant.seerr")

EVENTS = {"ISSUE_CREATED", "ISSUE_COMMENT"}


async def _find_user(db: AsyncSession, created_by: dict) -> User | None:
    jf = str(created_by.get("jellyfinUserId") or "").replace("-", "")
    if jf:
        sa = await db.scalar(select(ServiceAccount).where(ServiceAccount.service == "jellyfin",
                                                          ServiceAccount.external_id.in_([jf, created_by.get("jellyfinUserId")])))
        if sa:
            return await db.get(User, sa.user_id)
    sid = created_by.get("id")
    if sid is not None:
        sa = await db.scalar(select(ServiceAccount).where(ServiceAccount.service == "seerr",
                                                          ServiceAccount.external_id == str(sid)))
        if sa:
            return await db.get(User, sa.user_id)
    # Sem correspondência por email: no Seerr o email é editável pelo próprio utilizador, e um email copiado dava
    # ao agente acesso aos dados (dispositivos, pedidos, reprodução) de outro cliente.
    return None


def _describe(issue: dict) -> str:
    media = issue.get("media") or {}
    itype = SeerrClient.ISSUE_TYPES.get(issue.get("issueType"), "outro")
    parts = [f"Issue #{issue.get('id')} reportada no Seerr — tipo: {itype}."]
    if media.get("mediaType") == "tv":
        s, e = issue.get("problemSeason") or 0, issue.get("problemEpisode") or 0
        where = "série" + (f", temporada {s}" if s else " (todas as temporadas)") + (f", episódio {e}" if e else "")
        parts.append(f"Título: {where}.")
    jf_id = media.get("jellyfinMediaId") or media.get("jellyfinMediaId4k")
    if jf_id:
        parts.append(f"item_id no Jellyfin ({'série' if media.get('mediaType') == 'tv' else 'filme'}): {jf_id}")
    parts.append(f"TMDB: {media.get('tmdbId')}")
    comments = issue.get("comments") or []
    if comments:
        parts.append(f"Descrição do cliente: {comments[0].get('message', '')[:1500]}")
    return "\n".join(parts)


async def _conversation(db: AsyncSession, issue_id: int, user: User | None) -> AssistantConversation:
    conv = await db.scalar(select(AssistantConversation).where(
        AssistantConversation.channel == "seerr", AssistantConversation.external_ref == str(issue_id))
        .order_by(AssistantConversation.created_at.desc()).limit(1))
    if conv is None:
        conv = AssistantConversation(user_id=user.id if user else None, channel="seerr", external_ref=str(issue_id),
                                     agent="support", scope="streaming", meta={"issue_id": issue_id})
        db.add(conv)
        await db.flush()
    return conv


@job_handler("assistant_seerr")
async def process(db: AsyncSession, payload: dict) -> None:
    s = get_settings()
    if not (s.assistant_ready and s.seerr_enabled and s.seerr_auto_triage):
        return
    issue_id = int(payload["issue_id"])
    event = payload.get("event")
    sc = SeerrClient()
    try:
        issue = await sc.get_issue(issue_id)
    except SeerrError as exc:
        if exc.status == 404:
            raise PermanentError("issue não existe") from exc
        raise RetryLater(str(exc), 120) from exc
    if issue.get("status") != 1:  # já resolvida
        return
    created_by = issue.get("createdBy") or {}
    user = await _find_user(db, created_by)
    if user is None:
        # Sem cliente associado (equipa, conta antiga...) o agente não tem ferramentas úteis e qualquer utilizador do
        # Seerr podia gastar chamadas pagas ao modelo abrindo issues: fica para um humano.
        log.info("Issue %s de um utilizador do Seerr sem conta no portal — sem triagem automática.", issue_id)
        return
    recent = await db.scalar(select(func.count()).select_from(AssistantConversation).where(
        AssistantConversation.channel == "seerr", AssistantConversation.created_at >= utcnow() - timedelta(hours=1)))
    if (recent or 0) >= s.assistant_seerr_max_per_hour and not await db.scalar(
            select(AssistantConversation.id).where(AssistantConversation.channel == "seerr",
                                                   AssistantConversation.external_ref == str(issue_id))):
        log.warning("Limite de triagens do Seerr por hora atingido — issue %s fica para um humano.", issue_id)
        return
    conv = await _conversation(db, issue_id, user)
    if conv.status in ("escalated", "closed"):
        return  # uma pessoa está a tratar
    if event == "ISSUE_COMMENT":
        comments = issue.get("comments") or []
        last = comments[-1] if comments else {}
        text = str(last.get("message") or "")
        author = (last.get("user") or {}).get("id")
        if not text or text.startswith(s.seerr_bot_prefix or "🤖") or author != created_by.get("id") or len(comments) < 2:
            return  # comentário nosso, da equipa, ou a descrição inicial
        message = f"Novo comentário do cliente na issue #{issue_id}: {text[:1500]}"
    else:
        message = _describe(issue)
    extra: dict = {"issue_id": issue_id}
    result = await runtime.handle_message(db, conv, user, message, extra=extra)
    reply = next((m.content for m in reversed(result.messages) if m.role == "assistant" and m.content), None)
    try:
        if reply:
            await sc.comment_issue(issue_id, f"{s.seerr_bot_prefix or '🤖'} {reply}"[:2000])
        if extra.get("resolve") and reply != runtime.UNAVAILABLE:  # o modelo falhou a meio: não fechar
            await sc.set_issue_status(issue_id, "resolved")
            conv.status = "resolved"
            await db.commit()
    except SeerrError as exc:
        log.warning("Não consegui responder à issue %s: %s", issue_id, exc)
