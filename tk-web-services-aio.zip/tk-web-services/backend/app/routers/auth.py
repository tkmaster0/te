from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from sqlalchemy import func, or_, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from ..db import get_db, utcnow
from ..deps import (
    clear_session_cookie,
    client_ip,
    create_session,
    optional_session,
    rate_limit,
    require_user,
    require_user_any_scope,
    revoke_user_sessions,
    safe_redirect,
    session_scope,
)
from ..integrations.jellyfin import JellyfinClient, JellyfinError
from ..models import InviteCode, LoginSession, Product, User
from ..schemas import (
    CodeIn,
    ForgotIn,
    LoginIn,
    LoginOut,
    MeOut,
    Ok,
    PublicConfig,
    RegisterIn,
    ResetIn,
    TokenIn,
    TwoFactorIn,
)
from ..security import (
    RESERVED_USERNAMES,
    USERNAME_RE,
    decrypt,
    hash_password,
    hash_recovery_code,
    password_problems,
    verify_password,
    verify_totp,
)
from ..serializers import me_out, site_settings
from ..services import catalog as catalog_svc
from ..services import tokens
from ..services.audit import audit
from ..services.mailer import queue_email
from ..services.provisioning import queue_jellyfin_password

router = APIRouter(prefix="/api/auth", tags=["auth"])

_DUMMY_HASH = hash_password("dummy-password-for-timing")


@router.get("/config", response_model=PublicConfig)
async def public_config(db: AsyncSession = Depends(get_db)):
    s = get_settings()
    site = await site_settings(db)
    return PublicConfig(
        app_name=s.app_name,
        registration_mode=s.registration_mode,
        require_email_verification=s.require_email_verification,
        providers={"gocardless": s.gocardless_enabled, "stripe": s.stripe_enabled},
        jellyfin_url=s.jellyfin_public_url,
        seerr_url=s.seerr_public_url,
        bonus={"enabled": s.bonus_enabled, "threshold": s.bonus_threshold,
               "threshold_admin_referred": s.bonus_threshold_admin_referred},
        site={k: site.get(k) for k in ("announcement", "support_url", "support_email", "terms_url", "privacy_url",
                                       "apps", "faq")},
        billing={"require_method": s.billing_require_method},
        wallet={"enabled": s.wallet_enabled, "min_topup_cents": s.wallet_min_topup_cents,
                "min_monthly_cents": s.wallet_min_monthly_cents,
                "monthly_enabled": s.wallet_enabled and s.wallet_monthly_enabled,
                "monthly_bonus_percent": s.wallet_monthly_bonus_percent},
        games={"enabled": s.games_enabled and s.wallet_enabled, "min_bet_cents": s.games_min_bet_cents},
        sso={"enabled": s.oidc_enabled, "issuer": s.issuer, "jellyfin_url": s.jellyfin_public_url,
             "seerr_url": s.seerr_public_url, "librechat_url": s.librechat_url},
    )


async def _invite_valid(db: AsyncSession, code: str | None) -> InviteCode | None:
    if not code:
        return None
    inv = await db.scalar(select(InviteCode).where(func.upper(InviteCode.code) == code.strip().upper()))
    if inv is None or inv.disabled or inv.uses >= inv.max_uses:
        return None
    if inv.expires_at and inv.expires_at <= utcnow():
        return None
    if inv.created_by_id:
        creator = await db.get(User, inv.created_by_id)
        if creator is None or not creator.is_active:
            return None
    return inv


@router.get("/invite/{code}")
async def check_invite(code: str, request: Request, db: AsyncSession = Depends(get_db)):
    rate_limit(f"invite-check:{client_ip(request)}", 30, 600)
    inv = await _invite_valid(db, code)
    if not inv:
        return {"valid": False}
    creator = await db.get(User, inv.created_by_id) if inv.created_by_id else None
    unlocks = await catalog_svc.invite_unlocks(db, inv)
    names = (await db.scalars(select(Product.name).where(Product.code.in_(unlocks)))).all() if unlocks else []
    return {"valid": True, "inviter": creator.display_name or creator.username if creator else None,
            "unlocks": list(names)}


JELLYFIN_UNAVAILABLE = "Não foi possível confirmar a disponibilidade do username. Tenta novamente dentro de instantes."


async def _username_problem(db: AsyncSession, username: str) -> str | None:
    if not USERNAME_RE.match(username):
        return "O username só pode ter letras minúsculas, números, '.', '_' ou '-' (3 a 32 caracteres)."
    if username in RESERVED_USERNAMES:
        return "Esse username está reservado."
    if await db.scalar(select(User.id).where(User.username == username)):
        return "Esse username já está em uso."
    s = get_settings()
    if s.jellyfin_enabled:
        # Falha fechada: se o Jellyfin não responder não sabemos se o nome já existe lá, e o job de
        # provisionamento ligaria esta conta nova a uma conta Jellyfin alheia (e mudava-lhe a password).
        try:
            existing = await JellyfinClient(timeout=5).find_user_by_name(username)
        except JellyfinError:
            return JELLYFIN_UNAVAILABLE
        if existing:  # já existe no Jellyfin (ex.: utilizador antigo ou criado à mão)
            return "Esse username já está em uso."
    return None


@router.get("/check-username")
async def check_username(u: str, request: Request, db: AsyncSession = Depends(get_db)):
    rate_limit(f"check-username:{client_ip(request)}", 60, 600)
    problem = await _username_problem(db, u.strip().lower())
    return {"available": problem is None, "reason": problem}


def _promote_admin_email(db: AsyncSession, user: User) -> None:
    """Email de administrador (ADMIN_EMAILS) numa conta com o email confirmado → admin."""
    if not user.is_admin and user.email_verified_at and get_settings().is_admin_email(user.email):
        user.is_admin = True
        audit(db, "auth.admin_by_email", actor=user, target_type="user", target_id=user.id)


@router.post("/register", response_model=LoginOut)
async def register(body: RegisterIn, request: Request, response: Response, db: AsyncSession = Depends(get_db)):
    s = get_settings()
    ip = client_ip(request)
    rate_limit(f"register:{ip}", 5, 3600)
    username = body.username.strip().lower()
    email = body.email.strip().lower()

    invite = await _invite_valid(db, body.invite_code)
    # Email de administrador (ADMIN_EMAILS, ex.: geral@tkmasterproductions.eu) numa instalação sem nenhum admin: conta
    # admin já confirmada, sem OTP nem convite — é assim que se cria a primeira conta. Depois de haver um admin, os
    # outros emails da lista registam-se como qualquer cliente e só passam a admin com o email confirmado.
    owner = s.is_admin_email(email) and not await db.scalar(
        select(User.id).where(User.is_admin.is_(True)).limit(1))
    if s.registration_mode == "invite" and invite is None and not owner:
        raise HTTPException(400, detail="Código de convite inválido ou já utilizado.")
    if (problem := await _username_problem(db, username)):
        raise HTTPException(503 if problem == JELLYFIN_UNAVAILABLE else 400, detail=problem)
    if await db.scalar(select(User.id).where(User.email == email)):
        raise HTTPException(400, detail="Já existe uma conta com esse email. Faz login ou recupera a password.")
    if (problems := password_problems(body.password, username=username, email=email)):
        raise HTTPException(400, detail=" ".join(problems))

    first_user = not await db.scalar(select(User.id).limit(1))
    user = User(
        username=username,
        email=email,
        display_name=(body.display_name or "").strip() or None,
        password_hash=hash_password(body.password),
        referred_by_id=invite.created_by_id if invite else None,
        invite_code_id=invite.id if invite else None,
        # O primeiro utilizador registado é admin — só no modo por convite. Com registo aberto, quem chegasse
        # primeiro a um portal acabado de instalar ficava admin (usa `cli create-admin`).
        is_admin=owner or (first_user and s.registration_mode == "invite"),
        email_verified_at=utcnow() if owner or not s.require_email_verification else None,
        password_changed_at=utcnow(),
        # Contas novas: serviços pagos pela carteira de créditos e entrada no Jellyfin/Seerr/LibreChat por SSO.
        billing_mode="wallet" if (s.wallet_only_for_new_users and s.wallet_monthly_enabled) else "legacy",
        jellyfin_password_login=not s.sso_only_for_new_users,
        unlocked_products=(list(await catalog_svc.gated_codes(db)) if owner else
                           await catalog_svc.invite_unlocks(db, invite) if invite else []),
    )
    db.add(user)
    if invite:
        # Incremento atómico: dois registos em simultâneo não podem gastar o mesmo convite de uso único.
        res = await db.execute(update(InviteCode).where(InviteCode.id == invite.id,
                                                        InviteCode.uses < InviteCode.max_uses)
                               .values(uses=InviteCode.uses + 1).execution_options(synchronize_session=False))
        if not res.rowcount:
            await db.rollback()
            raise HTTPException(400, detail="Código de convite inválido ou já utilizado.")
    await db.flush()
    # Só com login "à antiga": cria a conta Jellyfin (desativada) com a mesma password. Com SSO a conta é criada
    # (com uma password aleatória que ninguém usa) quando o cliente tiver acesso ao streaming.
    await queue_jellyfin_password(db, user, body.password)
    if s.require_email_verification and not owner:
        # Um só email com o código (OTP, escrito no portal) e o link (alternativa).
        raw = await tokens.issue(db, user.id, "verify_email")
        code = await tokens.issue_code(db, user.id)
        await queue_email(db, email, "verify_email", username=username, code=code,
                          cta_url=f"{s.public_url}/verificar-email?token={raw}")
    audit(db, "user.register", actor=user, target_type="user", target_id=user.id, ip=ip,
          invite=invite.code if invite else None, admin=owner)
    await create_session(db, request, response, user)
    await db.commit()
    return LoginOut(status="ok", redirect="/admin/configurar" if owner else "/app", user=await me_out(db, user))


@router.post("/login", response_model=LoginOut)
async def login(body: LoginIn, request: Request, response: Response, db: AsyncSession = Depends(get_db)):
    ip = client_ip(request)
    ident = body.login.strip().lower()
    rate_limit(f"login-ip:{ip}", 20, 900)
    rate_limit(f"login-acct:{ident}", 10, 900)
    user = await db.scalar(select(User).where(or_(User.email == ident, User.username == ident)))
    if user is None:
        verify_password(_DUMMY_HASH, body.password)
        raise HTTPException(401, detail="Credenciais inválidas.")
    ok, needs_rehash = verify_password(user.password_hash, body.password)
    if not ok:
        audit(db, "auth.login_failed", target_type="user", target_id=user.id, ip=ip)
        await db.commit()
        raise HTTPException(401, detail="Credenciais inválidas.")
    if not user.is_active:
        raise HTTPException(403, detail="Esta conta está bloqueada. Contacta o suporte.")
    if needs_rehash:
        user.password_hash = hash_password(body.password)
    _promote_admin_email(db, user)
    if user.needs_password_sync:
        await queue_jellyfin_password(db, user, body.password)
    if user.totp_enabled:
        await create_session(db, request, response, user, mfa_pending=True, remember=body.remember)
        await db.commit()
        return LoginOut(status="mfa_required")
    user.last_login_at = utcnow()
    await create_session(db, request, response, user, remember=body.remember)
    audit(db, "auth.login", actor=user, target_type="user", target_id=user.id, ip=ip)
    await db.commit()
    return LoginOut(status="ok", redirect=safe_redirect(body.next), user=await me_out(db, user))


@router.post("/2fa", response_model=LoginOut)
async def two_factor(body: TwoFactorIn, request: Request, sess: LoginSession | None = Depends(optional_session),
                     db: AsyncSession = Depends(get_db)):
    if sess is None or not sess.mfa_pending:
        raise HTTPException(401, detail="Sessão de login expirou. Entra novamente.")
    rate_limit(f"2fa:{sess.id}", 6, 600)
    # Também por utilizador: cada novo login cria uma sessão mfa_pending nova, e o limite por sessão sozinho
    # deixava multiplicar as tentativas de adivinhar o código TOTP.
    rate_limit(f"2fa-user:{sess.user_id}", 10, 900)
    user = await db.get(User, sess.user_id)
    assert user is not None
    code = body.code.strip().lower()
    ok = False
    secret = decrypt(user.totp_secret_enc)
    if secret and verify_totp(secret, code):
        ok = True
    elif "-" in code and user.recovery_codes:
        h = hash_recovery_code(code)
        if h in user.recovery_codes:
            user.recovery_codes = [c for c in user.recovery_codes if c != h]
            ok = True
            audit(db, "auth.recovery_code_used", actor=user, target_type="user", target_id=user.id)
    if not ok:
        audit(db, "auth.2fa_failed", target_type="user", target_id=user.id, ip=client_ip(request))
        await db.commit()
        raise HTTPException(401, detail="Código inválido.")
    sess.mfa_pending = False
    sess.auth_time = utcnow()
    user.last_login_at = utcnow()
    audit(db, "auth.login", actor=user, target_type="user", target_id=user.id, ip=client_ip(request), mfa=True)
    await db.commit()
    out = await me_out(db, user)
    out.session_scope = sess.scope
    return LoginOut(status="ok", redirect="/app/streaming" if sess.scope else safe_redirect(body.next), user=out)


@router.post("/logout", response_model=Ok)
async def logout(request: Request, response: Response, sess: LoginSession | None = Depends(optional_session),
                 db: AsyncSession = Depends(get_db)):
    if sess:
        sess.revoked_at = utcnow()
        await db.commit()
    clear_session_cookie(response, request)
    return Ok()


@router.get("/me", response_model=MeOut)
async def me(request: Request, user: User = Depends(require_user_any_scope), db: AsyncSession = Depends(get_db)):
    out = await me_out(db, user)
    out.session_scope = session_scope(request)
    return out


@router.post("/verify-email", response_model=Ok)
async def verify_email(body: TokenIn, db: AsyncSession = Depends(get_db)):
    tok = await tokens.consume(db, body.token, "verify_email")
    if tok is None:
        raise HTTPException(400, detail="Link inválido ou expirado.")
    user = await db.get(User, tok.user_id)
    if user and not user.email_verified_at:
        user.email_verified_at = utcnow()
        audit(db, "user.email_verified", actor=user, target_type="user", target_id=user.id)
        _promote_admin_email(db, user)
    await db.commit()
    return Ok(message="Email confirmado.")


@router.post("/resend-verification", response_model=Ok)
async def resend_verification(request: Request, user: User = Depends(require_user), db: AsyncSession = Depends(get_db)):
    rate_limit(f"resend:{user.id}", 3, 3600)
    if user.email_verified_at:
        return Ok(message="O email já está confirmado.")
    raw = await tokens.issue(db, user.id, "verify_email")
    code = await tokens.issue_code(db, user.id)
    await queue_email(db, user.email, "verify_email", username=user.username, code=code,
                      cta_url=f"{get_settings().public_url}/verificar-email?token={raw}")
    await db.commit()
    return Ok(message="Enviámos um novo código para o teu email.")


@router.post("/verify-code", response_model=Ok)
async def verify_code(body: CodeIn, request: Request, user: User = Depends(require_user_any_scope),
                      db: AsyncSession = Depends(get_db)):
    """Confirma o email com o código de 6 dígitos (OTP) enviado na criação da conta."""
    rate_limit(f"verify-code:{user.id}", 10, 900)
    rate_limit(f"verify-code-ip:{client_ip(request)}", 30, 900)
    if user.email_verified_at:
        return Ok(message="O email já está confirmado.")
    if not await tokens.consume_code(db, user.id, body.code):
        await db.commit()  # guarda a tentativa falhada
        raise HTTPException(400, detail="Código inválido ou expirado. Confirma o código ou pede um novo.")
    user.email_verified_at = utcnow()
    audit(db, "user.email_verified", actor=user, target_type="user", target_id=user.id, method="code")
    _promote_admin_email(db, user)
    await db.commit()
    return Ok(message="Email confirmado. Tudo pronto!")


@router.post("/forgot", response_model=Ok)
async def forgot(body: ForgotIn, request: Request, db: AsyncSession = Depends(get_db)):
    ip = client_ip(request)
    rate_limit(f"forgot-ip:{ip}", 5, 900)
    email = body.email.strip().lower()
    rate_limit(f"forgot-acct:{email}", 3, 3600)
    user = await db.scalar(select(User).where(User.email == email))
    if user and user.is_active:
        raw = await tokens.issue(db, user.id, "reset_password")
        await queue_email(db, user.email, "reset_password", username=user.username,
                          cta_url=f"{get_settings().public_url}/redefinir-password?token={raw}")
        audit(db, "auth.reset_requested", target_type="user", target_id=user.id, ip=ip)
        await db.commit()
    return Ok(message="Se o email existir, vais receber um link para redefinir a password.")


@router.post("/reset", response_model=Ok)
async def reset(body: ResetIn, request: Request, db: AsyncSession = Depends(get_db)):
    rate_limit(f"reset:{client_ip(request)}", 10, 900)
    tok = await tokens.consume(db, body.token, "reset_password")
    if tok is None:
        raise HTTPException(400, detail="Link inválido ou expirado. Pede um novo.")
    user = await db.get(User, tok.user_id)
    assert user is not None
    if (problems := password_problems(body.password, username=user.username, email=user.email)):
        await db.rollback()
        raise HTTPException(400, detail=" ".join(problems))
    user.password_hash = hash_password(body.password)
    user.password_changed_at = utcnow()
    if not user.email_verified_at:
        user.email_verified_at = utcnow()  # quem recebeu o link controla o email
    await revoke_user_sessions(db, user.id)
    await queue_jellyfin_password(db, user, body.password)
    await queue_email(db, user.email, "password_changed", username=user.username,
                      when=utcnow().strftime("%d/%m/%Y %H:%M UTC"))
    audit(db, "auth.password_reset", target_type="user", target_id=user.id, ip=client_ip(request))
    await db.commit()
    return Ok(message="Password redefinida. Já podes entrar (também no Jellyfin, dentro de instantes).")


@router.post("/magic", response_model=LoginOut)
async def magic_login(body: TokenIn, request: Request, response: Response, db: AsyncSession = Depends(get_db)):
    """Login de uso único gerado a partir de uma sessão Jellyfin válida (página Custom Pages)."""
    rate_limit(f"magic:{client_ip(request)}", 20, 600)
    tok = await tokens.consume(db, body.token, "magic_login")
    if tok is None:
        raise HTTPException(400, detail="Link expirado. Volta a abrir a partir do Jellyfin.")
    user = await db.get(User, tok.user_id)
    if user is None or not user.is_active:
        raise HTTPException(403, detail="Conta indisponível.")
    if user.is_admin:
        # Um token do Jellyfin não deve bastar para abrir uma sessão de administrador.
        raise HTTPException(403, detail="Contas de administrador têm de entrar com password.")
    # Sessão limitada: a partir do Jellyfin só se gere o streaming (resto exige login com password).
    if user.totp_enabled:
        await create_session(db, request, response, user, mfa_pending=True, scope="streaming")
        await db.commit()
        return LoginOut(status="mfa_required")
    await create_session(db, request, response, user, scope="streaming")
    audit(db, "auth.login", actor=user, target_type="user", target_id=user.id, ip=client_ip(request), via="jellyfin",
          scope="streaming")
    await db.commit()
    out = await me_out(db, user)
    out.session_scope = "streaming"
    nxt = (tok.data or {}).get("next") or ""
    redirect = nxt if nxt.startswith("/app/streaming") and "//" not in nxt else "/app/streaming"
    return LoginOut(status="ok", redirect=redirect, user=out)
