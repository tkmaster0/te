"""Emails transacionais (pt-PT). Enviados sempre através da fila de jobs."""
from __future__ import annotations

import logging
from email.message import EmailMessage
from email.utils import make_msgid

import aiosmtplib
from jinja2 import Environment, select_autoescape
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from .jobs import RetryLater, enqueue, job_handler, redact_tokens

log = logging.getLogger("tkportal.mail")

_env = Environment(autoescape=select_autoescape(default=True, default_for_string=True))

BASE = """<!doctype html>
<html lang="pt-PT"><body style="margin:0;background:#0b0b0c;font-family:Segoe UI,Roboto,Helvetica,Arial,sans-serif;color:#e8e6e3">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#0b0b0c;padding:32px 12px"><tr><td align="center">
<table width="560" cellpadding="0" cellspacing="0" style="max-width:560px;width:100%;background:#151517;border-radius:14px;border:1px solid #26262a">
<tr><td style="padding:28px 32px 8px"><span style="display:inline-block;background:#f5c518;color:#0b0b0c;font-weight:800;letter-spacing:.5px;padding:6px 10px;border-radius:6px">{{ app_name }}</span></td></tr>
<tr><td style="padding:8px 32px 28px;font-size:15px;line-height:1.6">
<h1 style="font-size:20px;margin:12px 0 16px;color:#fff">{{ title }}</h1>
{{ body }}
{% if cta_url %}<p style="margin:28px 0"><a href="{{ cta_url }}" style="background:#f5c518;color:#0b0b0c;text-decoration:none;font-weight:700;padding:12px 20px;border-radius:8px;display:inline-block">{{ cta_label }}</a></p>
<p style="font-size:12px;color:#8b8b90">Se o botão não funcionar, copia este link: <br><span style="word-break:break-all">{{ cta_url }}</span></p>{% endif %}
</td></tr>
<tr><td style="padding:16px 32px;border-top:1px solid #26262a;font-size:12px;color:#8b8b90">Recebeste este email porque tens conta em {{ app_name }}. <a href="{{ portal_url }}" style="color:#f5c518">{{ portal_url }}</a></td></tr>
</table></td></tr></table></body></html>"""

# Cada template: (assunto, título, corpo HTML (jinja), rótulo do botão)
TEMPLATES: dict[str, tuple[str, str, str, str | None]] = {
    "verify_email": (
        "{% if code %}{{ code }} é o teu código de confirmação{% else %}Confirma o teu email{% endif %}",
        "Bem-vindo(a), {{ username }}!",
        "{% if code %}<p>O teu código de confirmação é:</p>"
        "<p style=\"font-size:32px;font-weight:800;letter-spacing:8px;margin:8px 0 16px\">{{ code }}</p>"
        "<p>Escreve-o no portal. É válido durante 30 minutos. Também podes confirmar com o botão abaixo "
        "(válido 48 horas).</p>{% else %}<p>Falta só confirmar o teu email para ativares a conta.</p>"
        "<p>O link é válido durante 48 horas.</p>{% endif %}"
        "<p style=\"color:#8b8b90;font-size:13px\">Se não criaste esta conta, ignora este email.</p>",
        "Confirmar email",
    ),
    "reset_password": (
        "Redefinir password",
        "Pedido de nova password",
        "<p>Recebemos um pedido para redefinir a password da conta <b>{{ username }}</b>.</p>"
        "<p>O link é válido durante 1 hora. Se não foste tu, ignora este email — a tua password mantém-se.</p>",
        "Definir nova password",
    ),
    "change_email": (
        "Confirma o novo email",
        "Alteração de email",
        "<p>Pediste para alterar o email da conta <b>{{ username }}</b> para este endereço.</p>",
        "Confirmar novo email",
    ),
    "password_changed": (
        "A tua password foi alterada",
        "Password alterada",
        "<p>A password da conta <b>{{ username }}</b> foi alterada em {{ when }}.</p>"
        "<p>Se não foste tu, redefine a password imediatamente e contacta o suporte.</p>",
        None,
    ),
    "subscription_active": (
        "A tua subscrição está ativa 🎉",
        "Subscrição {{ plan }} ativa",
        "<p>Obrigado, {{ username }}! A tua subscrição <b>{{ plan }}</b> está ativa.</p>"
        "<p>Entra no {{ app_name }} com o teu username <b>{{ username }}</b> e a mesma password do portal.</p>",
        "Abrir o portal",
    ),
    "payment_failed": (
        "Pagamento falhado",
        "Não conseguimos fazer a cobrança",
        "<p>O pagamento de <b>{{ amount }}</b> ({{ plan }}) não foi aceite{% if reason %}: {{ reason }}{% endif %}.</p>"
        "<p>Vamos tentar de novo automaticamente. Os teus serviços mantêm-se ativos até <b>{{ grace_until }}</b> — "
        "podes pagar já ou trocar de método de pagamento no portal.</p>",
        "Pagar agora",
    ),
    "payment_method_needed": (
        "Atualiza o teu método de pagamento",
        "Precisamos que atualizes o método de pagamento",
        "<p>{{ reason }}</p>"
        "<p>Para não ficares sem serviço, adiciona um método de pagamento até <b>{{ grace_until }}</b>. "
        "Demora menos de um minuto.</p>",
        "Atualizar método",
    ),
    "payment_received": (
        "Pagamento recebido — obrigado!",
        "Está tudo em dia",
        "<p>Recebemos o pagamento de <b>{{ amount }}</b> (cobrança {{ number }}). Os teus serviços estão ativos.</p>",
        "Ver faturação",
    ),
    "price_change": (
        "Alteração de preço — {{ plan }}",
        "O preço do plano {{ plan }} vai mudar",
        "<p>A partir de <b>{{ effective }}</b>, o plano <b>{{ plan }}</b> passa de <b>{{ old_price }}</b> para "
        "<b>{{ new_price }}</b> por {{ interval }}.</p>"
        "{% if note %}<p>{{ note }}</p>{% endif %}"
        "<p>A mudança aplica-se na primeira renovação a partir dessa data. Podes mudar de plano ou cancelar "
        "quando quiseres, sem custos.</p>",
        "Gerir serviços",
    ),
    "plan_migration": (
        "O teu plano vai mudar — {{ old_plan }} → {{ new_plan }}",
        "Mudança de plano",
        "<p>O plano <b>{{ old_plan }}</b> vai ser substituído por <b>{{ new_plan }}</b> ({{ new_price }} por "
        "{{ interval }}) a partir da tua próxima renovação, em <b>{{ when }}</b>.</p>"
        "{% if note %}<p>{{ note }}</p>{% endif %}",
        "Ver serviços",
    ),
    "subscription_canceled": (
        "Subscrição cancelada",
        "Cancelámos a renovação",
        "<p>A subscrição <b>{{ plan }}</b> não será renovada. Continuas com acesso até <b>{{ access_until }}</b>.</p>",
        "Reativar",
    ),
    "subscription_ended": (
        "A tua subscrição terminou",
        "Subscrição terminada",
        "<p>A subscrição <b>{{ plan }}</b> terminou e o acesso foi desativado. Podes voltar quando quiseres.</p>",
        "Ver planos",
    ),
    "subscription_suspended": (
        "Acesso suspenso",
        "Acesso suspenso por falta de pagamento",
        "<p>Não recebemos o pagamento da subscrição <b>{{ plan }}</b> e o acesso foi suspenso.</p>",
        "Resolver pagamento",
    ),
    "bonus_on": (
        "Ganhaste o Bónus! 🎁",
        "O teu streaming passou a gratuito",
        "<p>Tens {{ count }} convidados a pagar a subscrição — enquanto isso se mantiver, o teu streaming não é "
        "cobrado.</p>",
        "Ver convites",
    ),
    "bonus_off": (
        "Bónus terminado",
        "A cobrança do teu streaming vai ser retomada",
        "<p>O número de convidados com subscrição paga desceu abaixo de {{ threshold }}, por isso o streaming volta "
        "a ser cobrado a partir da próxima cobrança{% if when %} ({{ when }}){% endif %}.</p>",
        "Ver convites",
    ),
    "iptv_ready": (
        "Credenciais de TV prontas",
        "A tua TV está pronta",
        "<p>As credenciais IPTV já estão disponíveis na tua área de cliente.</p>",
        "Ver credenciais",
    ),
    "invite": (
        "{{ inviter }} convidou-te para o {{ app_name }}",
        "Tens um convite!",
        "<p><b>{{ inviter }}</b> convidou-te para o {{ app_name }}. Usa o código <b style='color:#f5c518'>{{ code }}</b> ao criar conta.</p>",
        "Criar conta",
    ),
    "admin_notice": (
        "[Admin] {{ subject }}",
        "{{ subject }}",
        "<p>{{ message }}</p>",
        None,
    ),
}


def render(template: str, ctx: dict) -> tuple[str, str, str]:
    s = get_settings()
    subject_t, title_t, body_t, cta = TEMPLATES[template]
    full = {"app_name": s.app_name, "portal_url": s.public_url, **ctx}
    subject = _env.from_string(subject_t).render(full)
    title = _env.from_string(title_t).render(full)
    body = _env.from_string(body_t).render(full)
    from markupsafe import Markup

    # `full` já traz o cta_url do contexto — passá-lo também como kwarg rebentava com TypeError em todos os
    # emails com botão (o job falhava e nunca era enviado).
    html = _env.from_string(BASE).render(
        {**full, "title": title, "body": Markup(body), "cta_label": cta, "cta_url": ctx.get("cta_url") if cta else None}
    )
    text_parts = [title, "", _strip_html(body)]
    if cta and ctx.get("cta_url"):
        text_parts += ["", f"{cta}: {ctx['cta_url']}"]
    return subject, html, "\n".join(text_parts)


def _strip_html(s: str) -> str:
    import re

    return re.sub(r"<[^>]+>", "", s.replace("</p>", "\n")).strip()


async def queue_email(db: AsyncSession, to: str, template: str, **ctx) -> None:
    await enqueue(db, "send_email", {"to": to, "template": template, "ctx": ctx}, max_attempts=6)


async def send_now(to: str, template: str, ctx: dict) -> None:
    s = get_settings()
    subject, html, text = render(template, ctx)
    if not s.smtp_enabled:
        # Em produção não escrever links com tokens (reset de password, etc.) nos logs.
        log.warning("SMTP não configurado — email '%s' para %s não enviado.\n%s", template, to,
                    text if s.is_dev else redact_tokens(text))
        return
    msg = EmailMessage()
    msg["From"] = s.mail_from
    msg["To"] = to
    msg["Subject"] = subject
    msg["Message-ID"] = make_msgid(domain=s.public_host)
    msg.set_content(text)
    msg.add_alternative(html, subtype="html")
    try:
        await aiosmtplib.send(
            msg,
            hostname=s.smtp_host,
            port=s.smtp_port,
            username=s.smtp_username,
            password=s.smtp_password,
            use_tls=s.smtp_tls_mode == "ssl",
            start_tls=s.smtp_tls_mode == "starttls",
            timeout=20,
        )
    except (aiosmtplib.SMTPException, OSError) as exc:
        raise RetryLater(f"SMTP: {exc}", delay_seconds=120) from exc


@job_handler("send_email")
async def _send_email_job(db: AsyncSession, payload: dict) -> None:
    await send_now(payload["to"], payload["template"], payload.get("ctx") or {})
