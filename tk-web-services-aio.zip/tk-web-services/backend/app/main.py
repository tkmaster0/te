from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.exceptions import HTTPException as StarletteHTTPException

from .assistant import api as assistant_api
from .config import get_settings
from .db import sessionmaker
from .deps import request_is_https
from .routers import (
    account,
    admin,
    auth,
    billing,
    bridge,
    games,
    invites,
    jellyfin_assets,
    migration,
    oidc,
    services,
    setup,
    wallet,
    webhooks,
)
from .seed import ensure_test_admin, seed_defaults
from .services import runtime_config, tasks, tunnel
from .services.jobs import worker_loop

log = logging.getLogger("tkportal")

STATIC_DIR = Path(__file__).resolve().parent.parent / "static"
CSRF_EXEMPT_PREFIXES = ("/api/webhooks/", "/api/integrations/")


@asynccontextmanager
async def lifespan(app: FastAPI):
    s = get_settings()
    logging.basicConfig(level=s.log_level, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    if len(s.secret_key) < 32:
        raise RuntimeError("SECRET_KEY tem de ter pelo menos 32 caracteres")
    try:
        async with sessionmaker()() as db:
            if await seed_defaults(db):
                log.info("Produto e planos iniciais criados.")
            if await ensure_test_admin(db):
                log.warning("Conta de administrador pré-carregada '%s' criada — muda a password ou desliga "
                            "TEST_ADMIN_ENABLED em produção.", get_settings().test_admin_username)
            n = await runtime_config.load(db)
            if n:
                log.info("%d definições aplicadas a partir da configuração por web.", n)
            if not await runtime_config.setup_completed(db):
                log.warning("Configuração inicial por fazer: abre %s/registar (ou http://<IP do servidor>:8090/registar) "
                            "e cria a conta com %s (fica administradora, sem código) — o assistente de configuração "
                            "abre sozinho.", s.public_url, " ou ".join(s.admin_emails) or "um email de ADMIN_EMAILS")
    except Exception as exc:  # noqa: BLE001 — BD pode ainda não estar migrada
        log.warning("Seed ignorado: %s", exc)
    stop = asyncio.Event()
    bg: list[asyncio.Task] = []
    if s.run_worker_in_api:
        bg.extend(asyncio.create_task(worker_loop(stop)) for _ in range(max(1, s.worker_concurrency)))
        bg.append(asyncio.create_task(tasks.scheduler_loop(stop)))
        bg.append(asyncio.create_task(tunnel.supervise(stop)))
        bg.append(asyncio.create_task(_config_refresher(stop)))
    yield
    stop.set()
    for t in bg:
        t.cancel()


async def _config_refresher(stop: asyncio.Event) -> None:
    """Relê as definições da BD de minuto a minuto (outros processos — ex.: um worker separado — também as mudam)."""
    while not stop.is_set():
        try:
            await asyncio.wait_for(stop.wait(), 60)
        except TimeoutError:
            pass
        if stop.is_set():
            return
        try:
            async with sessionmaker()() as db:
                await runtime_config.load(db)
        except Exception as exc:  # noqa: BLE001
            log.debug("Releitura das definições falhou: %s", exc)


_PT_MESSAGES = {
    "missing": "campo obrigatório",
    "string_too_short": "demasiado curto (mínimo {min_length} caracteres)",
    "string_too_long": "demasiado longo (máximo {max_length} caracteres)",
    "string_pattern_mismatch": "formato inválido",
    "greater_than_equal": "tem de ser maior ou igual a {ge}",
    "less_than_equal": "tem de ser menor ou igual a {le}",
    "int_parsing": "tem de ser um número inteiro",
    "bool_parsing": "tem de ser verdadeiro ou falso",
    "literal_error": "valor inválido",
    "json_invalid": "JSON inválido",
}


def _pt_validation_message(err: dict) -> str:
    etype = err.get("type", "")
    if etype == "value_error" and "email" in str(err.get("msg", "")).lower():
        return "email inválido"
    template = _PT_MESSAGES.get(etype)
    if template:
        try:
            return template.format(**(err.get("ctx") or {}))
        except (KeyError, IndexError):
            return template
    if etype.startswith("value_error"):
        msg = str(err.get("msg", ""))
        return msg.removeprefix("Value error, ") or "valor inválido"
    return "valor inválido"


def create_app() -> FastAPI:
    s = get_settings()
    app = FastAPI(title=f"{s.app_name} Portal API", version="2.0.0", lifespan=lifespan,
                  docs_url="/api/docs" if s.is_dev else None, redoc_url=None,
                  openapi_url="/api/openapi.json" if s.is_dev else None)

    @app.middleware("http")
    async def security_middleware(request: Request, call_next):
        path = request.url.path
        # Proteção CSRF: pedidos que alteram estado na API têm de trazer um header que um formulário
        # de outro site não consegue enviar sem pré-verificação CORS (que nunca autorizamos).
        if (request.method not in ("GET", "HEAD", "OPTIONS") and path.startswith("/api/")
                and not path.startswith(CSRF_EXEMPT_PREFIXES)
                and request.headers.get("x-requested-with") != "tkportal"):
            return JSONResponse({"detail": "Pedido rejeitado (CSRF)."}, status_code=403)
        response = await call_next(request)
        h = response.headers
        h.setdefault("X-Content-Type-Options", "nosniff")
        h.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        h.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        if not path.startswith("/api/integrations/"):
            h.setdefault("X-Frame-Options", "DENY")
        if s.cookie_secure and request_is_https(request):
            h.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
        if not path.startswith(("/api/", "/oidc/", "/.well-known/", "/auth/")):
            h.setdefault(
                "Content-Security-Policy",
                "default-src 'self'; img-src 'self' data: https:; style-src 'self' 'unsafe-inline'; "
                "font-src 'self' data:; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; "
                "base-uri 'self'; form-action 'self'",
            )
        if path.startswith("/api/"):
            h.setdefault("Cache-Control", "no-store")
        return response

    @app.exception_handler(RequestValidationError)
    async def validation_handler(request: Request, exc: RequestValidationError):
        errors = exc.errors()
        first = errors[0] if errors else {}
        field = ".".join(str(x) for x in first.get("loc", [])[1:])
        msg = _pt_validation_message(first)
        return JSONResponse({"detail": f"{field}: {msg}" if field else msg,
                             "errors": [{"loc": e.get("loc"), "type": e.get("type")} for e in errors[:5]]},
                            status_code=422)

    for r in (auth.router, account.router, billing.catalog_router, billing.router, wallet.router, games.router,
              services.router, invites.router, setup.router, migration.router, jellyfin_assets.router,
              jellyfin_assets.admin_router,
              admin.router, webhooks.router, oidc.router, bridge.router, assistant_api.router,
              assistant_api.admin_router, assistant_api.bridge_router, assistant_api.webhook_router):
        app.include_router(r)

    @app.get("/api/health")
    async def health():
        from sqlalchemy import text

        async with sessionmaker()() as db:
            await db.execute(text("SELECT 1"))
        return {"ok": True}

    # Frontend (build do React) servido pelo próprio backend — um só contentor.
    if STATIC_DIR.exists():
        assets = STATIC_DIR / "assets"
        if assets.exists():
            app.mount("/assets", StaticFiles(directory=assets), name="assets")

        @app.exception_handler(StarletteHTTPException)
        async def spa_fallback(request: Request, exc: StarletteHTTPException):
            path = request.url.path
            if exc.status_code == 404 and request.method == "GET" and not path.startswith(
                    ("/api/", "/oidc/", "/.well-known/", "/auth/", "/assets/")):
                root = STATIC_DIR.resolve()  # a pasta pode ser um link (ex.: desenvolvimento)
                candidate = (root / path.lstrip("/")).resolve()
                if candidate.is_file() and root in candidate.parents:
                    return FileResponse(candidate)
                return FileResponse(STATIC_DIR / "index.html", headers={"Cache-Control": "no-cache"})
            return JSONResponse({"detail": exc.detail}, status_code=exc.status_code, headers=getattr(exc, "headers", None))

    return app


app = create_app()
