#!/bin/sh
# TK Web Services — ponto de entrada do contentor.
#   all    → API + fila de jobs + tarefas periódicas num só processo (contentor isolado, modo recomendado)
#   api    → só a API (para separar API e worker em dois contentores)
#   worker → só a fila de jobs e as tarefas periódicas
#   cli    → comandos de gestão: create-admin, import-legacy, ...
set -e

# Segredos da instalação: gerados no primeiro arranque pelo contentor da base de dados (volume tkws_secrets) — não é
# preciso .env nenhum. Um SECRET_KEY / DATABASE_URL vindo do ambiente (ex.: .env antigo) tem sempre prioridade.
load_secrets() {
  d="${TKWS_SECRETS_DIR:-/var/lib/tkws}"
  if [ -z "$SECRET_KEY" ] && [ -r "$d/secret_key" ]; then
    SECRET_KEY="$(cat "$d/secret_key")"; export SECRET_KEY
  fi
  if [ -z "$DATABASE_URL" ] && [ -r "$d/db_password" ]; then
    DATABASE_URL="postgresql+asyncpg://tkws:$(cat "$d/db_password")@${TKWS_DB_HOST:-tkws-db}:5432/tkws"
    export DATABASE_URL
  fi
  if [ -z "$SECRET_KEY" ]; then
    echo "Sem SECRET_KEY: arranca com o docker-compose.yml do projeto (gera-a sozinho) ou define-a no .env." >&2
    exit 1
  fi
}

serve() {
  # O IP real do cliente é resolvido pela própria aplicação (TRUSTED_PROXIES). Com "*" o uvicorn aceitava o
  # X-Forwarded-For de qualquer origem e o rate limiting por IP deixava de valer.
  exec uvicorn app.main:app --host 0.0.0.0 --port ${PORT:-8000} --proxy-headers --no-access-log \
       --forwarded-allow-ips="${FORWARDED_ALLOW_IPS:-127.0.0.1}" --workers "$1"
}

migrate() {
  # A BD (contentor tkws-db) pode ainda estar a arrancar ou a recuperar: esperar por ela.
  i=0
  until alembic upgrade head; do
    i=$((i + 1))
    [ "$i" -ge 30 ] && { echo "Base de dados inacessível — desisto." >&2; exit 1; }
    echo "Base de dados ainda não disponível (tentativa $i/30) — nova tentativa em 5 s…" >&2
    sleep 5
  done
}

load_secrets

case "$1" in
  all)
    migrate
    # Um só processo: a fila de jobs, o agendador e os limites de pedidos (em memória) têm de ser únicos.
    export RUN_WORKER_IN_API=true
    serve 1
    ;;
  api)
    migrate
    serve "${WEB_WORKERS:-1}"
    ;;
  worker)
    exec python -m app.worker
    ;;
  cli)
    shift
    exec python -m app.cli "$@"
    ;;
  *)
    exec "$@"
    ;;
esac
