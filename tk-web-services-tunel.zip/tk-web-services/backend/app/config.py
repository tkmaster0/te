"""Configuração central — tudo vem de variáveis de ambiente / ficheiro .env.

Nenhum segredo vive no código. Ver `.env.example` na raiz do projeto.
"""
from __future__ import annotations

import json
from functools import lru_cache
from typing import Annotated
from urllib.parse import urlparse

from pydantic import AliasChoices, Field, field_validator
from pydantic_settings import BaseSettings, NoDecode, SettingsConfigDict

# Listas lidas do ambiente como CSV ("a,b,c") ou JSON ('["a","b"]'). Sem NoDecode o pydantic-settings
# tenta sempre JSON e rebenta com CSV.
CsvList = Annotated[list[str], NoDecode]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # --- Geral -----------------------------------------------------------
    env: str = Field("production", description="production | development | test")
    app_name: str = "TK Web Services"
    # URL pública do portal (frontend + API no mesmo host), sem barra final.
    public_url: str = "http://localhost:8080"
    # Segredo mestre (>= 32 chars). Usado para cifrar segredos em repouso e assinar tokens internos.
    secret_key: str = Field(..., min_length=32)
    database_url: str = "postgresql+asyncpg://tkportal:tkportal@localhost:5432/tkportal"
    log_level: str = "INFO"

    # --- Sessões / cookies -------------------------------------------------
    session_cookie_name: str = "tk_session"
    # Domínio do cookie. Para o forward-auth funcionar em subdomínios (sonarr.tkflix.eu, ...)
    # usa o domínio pai, ex: ".tkflix.eu". Vazio = só o host do portal.
    cookie_domain: str | None = None
    # true = cookies "Secure" quando o pedido chega por HTTPS (direto ou pelo túnel/proxy). Por HTTP simples (ex.: o
    # primeiro acesso por http://IP:8090) o cookie vai sem "Secure", senão o browser não o guardava.
    cookie_secure: bool = True
    session_ttl_hours: int = 24 * 14
    session_idle_hours: int = 24 * 3
    # Hosts para onde é permitido redirecionar após login (?next= / ?rd=). O host do portal é sempre permitido.
    # Aceita wildcard de subdomínio: "*.tkflix.eu"
    allowed_redirect_hosts: CsvList = Field(default_factory=list)
    # Proxies de confiança para ler X-Forwarded-For (IPs/CIDRs). Vazio = usar IP do socket.
    trusted_proxies: CsvList = Field(default_factory=lambda: ["127.0.0.1", "::1", "172.16.0.0/12", "10.0.0.0/8", "192.168.0.0/16"])

    # --- Registo / convites -------------------------------------------------
    registration_mode: str = Field("open", description="invite | open")
    require_email_verification: bool = True
    invites_per_user: int = 5
    invites_require_active_subscription: bool = True
    bonus_enabled: bool = True
    bonus_threshold: int = 3
    bonus_threshold_admin_referred: int = 2
    # Dias de tolerância após um pagamento falhado antes de suspender o acesso.
    grace_period_days: int = 10

    # --- Faturação consolidada ---------------------------------------------------
    # Hora (UTC) a que as cobranças do dia são feitas.
    billing_hour_utc: int = Field(6, ge=0, le=23)
    # Novas tentativas depois de um pagamento falhar (dias após a tentativa anterior).
    billing_retry_days: CsvList = Field(default_factory=lambda: ["3", "4"])
    # Abaixo deste valor não se cobra: o montante passa para a cobrança seguinte (poupa taxas fixas).
    billing_min_charge_cents: int = 100
    # Pro-rata de upgrades / novos produtos a meio do ciclo: "next_invoice" (junta à próxima cobrança,
    # uma só cobrança por mês) ou "immediate" (cobra logo).
    proration_charge: str = Field("next_invoice", description="next_invoice | immediate")
    # Clientes que ainda nunca pagaram nada são sempre cobrados logo na primeira subscrição.
    charge_first_purchase_immediately: bool = True
    # Aviso mínimo (dias) para mudanças de preço a subscritores existentes.
    price_change_notice_days: int = 30
    # Tolerância quando o método de pagamento deixa de ser utilizável (fornecedor desativado / conta trocada).
    payment_method_grace_days: int = 14
    # Subscrições suspensas há mais de N dias terminam (deixam de gerar cobranças).
    suspended_end_days: int = 30

    # --- Carteira de créditos ---------------------------------------------------------
    wallet_enabled: bool = True
    # Carregamento único mínimo / máximo.
    wallet_min_topup_cents: int = 500
    wallet_max_topup_cents: int = 50000
    # Carregamento mensal mínimo / máximo.
    wallet_min_monthly_cents: int = 500
    wallet_max_monthly_cents: int = 50000
    # Bónus (%) sobre cada carregamento mensal pago — incentivo para passar para os créditos mensais. 0 = sem bónus.
    wallet_monthly_bonus_percent: int = Field(0, ge=0, le=50)
    # Carregamento mensal da carteira (desligado: os serviços são cobrados pelo método autorizado — débito direto
    # ou cartão — e o portal ajusta o valor conforme o cliente adere/cancela). A carteira fica para carregamentos
    # únicos (ex.: jogos), sempre usada antes de qualquer cobrança.
    wallet_monthly_enabled: bool = False
    # true = as contas novas só podem pagar os serviços com a carteira (exige o carregamento mensal ligado).
    wallet_only_for_new_users: bool = False

    # --- Administradores -------------------------------------------------------------------
    # Quem se registar com um destes emails fica logo administrador, com o email dado como confirmado (sem código
    # OTP), mesmo com o registo só por convite. É assim que se cria a primeira conta numa instalação nova.
    # Regista-te logo a seguir ao primeiro arranque — o primeiro a usar o email fica com a conta.
    admin_emails: CsvList = Field(default_factory=lambda: ["geral@tkmasterproductions.eu"])

    # --- Conta de administrador pré-carregada (desligada por omissão) ---------------------------------
    # Criada no arranque se ainda não existir (nunca repõe a password de uma conta que já exista). Email já verificado.
    test_admin_enabled: bool = False
    test_admin_username: str = "testews"
    test_admin_password: str = "testews"
    test_admin_email: str = "testews@tkmasterproductions.eu"

    # --- Faturação ---------------------------------------------------------------------
    # true = aderir exige sempre uma autorização de pagamento (mandato de débito direto GoCardless ou cartão Stripe),
    # mesmo que o saldo da carteira chegue. A partir daí o portal cobra o valor certo em cada ciclo.
    billing_require_method: bool = True

    # --- Jogos (roleta europeia e blackjack com créditos) ---------------------------------
    games_enabled: bool = False
    games_min_bet_cents: int = 100
    games_max_bet_cents: int = 5000
    # Perda líquida máxima por dia (o cliente pode escolher um limite mais baixo). 0 = sem limite.
    games_daily_loss_limit_cents: int = 5000
    # Idade mínima (confirmada pelo cliente antes de jogar).
    games_min_age: int = 18
    # Os jogos só existem para quem tem este produto desbloqueado (convite TKFLIX ou código). Vazio = para todos.
    games_require_product: str = "tkflix"

    # --- Email --------------------------------------------------------------
    smtp_host: str | None = None
    smtp_port: int = 465
    smtp_username: str | None = None
    smtp_password: str | None = None
    smtp_tls_mode: str = Field("ssl", description="ssl | starttls | none")
    mail_from: str = "TK Web Services <no-reply@localhost>"
    admin_notify_email: str | None = None

    # --- Ligação aos serviços do TKFLIX (portal noutra máquina) ------------------------------------------------
    # Service token do Cloudflare Access enviado ao Jellyfin/Seerr/Bazarr/Dispatcharr quando as URLs são https
    # (hostnames protegidos por uma política "Service Auth"). Vazio = não envia nada.
    tkflix_access_client_id: str | None = None
    tkflix_access_client_secret: str | None = None
    # Limitar o envio do token a estes hosts (CSV). Vazio = os hosts das URLs do Jellyfin/Seerr/Bazarr/Dispatcharr.
    tkflix_access_hosts: CsvList = Field(default_factory=list)

    # --- Jellyfin -----------------------------------------------------------
    jellyfin_url: str | None = None  # URL interna usada pelo backend, ex: http://jellyfin:8096
    jellyfin_public_url: str | None = None  # URL que os utilizadores usam, ex: https://tkflix.eu
    # Outras origens (esquema + host) por onde os utilizadores abrem o Jellyfin — CSV. Autorizadas no CORS da página
    # "A minha conta" e do chat de suporte dentro do Jellyfin.
    jellyfin_extra_origins: CsvList = Field(default_factory=list)
    jellyfin_api_key: str | None = None
    # Usar o Jellyfin como fonte da password (manter password do Jellyfin = password do portal). Só se aplica a
    # quem mantém o login "à antiga" (clientes migrados); as contas novas entram por SSO.
    jellyfin_sync_password: bool = True
    # true = contas novas entram no Jellyfin/Seerr/LibreChat só por SSO (OIDC) e Quick Connect; os clientes
    # migrados continuam a poder usar o username + password no Jellyfin.
    sso_only_for_new_users: bool = True

    # --- Seerr / Jellyseerr -------------------------------------------------
    seerr_url: str | None = None
    seerr_public_url: str | None = None
    seerr_api_key: str | None = None

    # --- Dispatcharr (IPTV) --------------------------------------------------
    dispatcharr_url: str | None = None
    dispatcharr_public_url: str | None = None  # URL do servidor XC/M3U dado aos clientes
    dispatcharr_api_key: str | None = None
    # Dias sem acesso à TV até o utilizador ser apagado no Dispatcharr (antes disso fica só desativado e volta com a
    # mesma password se o cliente regressar). 0 = nunca apagar.
    dispatcharr_delete_after_days: int = Field(30, ge=0)

    # --- Túnel Cloudflare (cloudflared dentro do contentor do portal) ---------------------------------------------
    # Token do túnel (Zero Trust → Networks → Tunnels). No painel do túnel, o Public Hostname do portal aponta para
    # http://localhost:8000. Vazio = sem túnel (o portal fica só na porta publicada).
    cloudflare_tunnel_token: str | None = Field(
        None, validation_alias=AliasChoices("CLOUDFLARE_TUNNEL_TOKEN", "CLOUDFLARED_TOKEN", "cloudflare_tunnel_token"))

    # --- GoCardless ------------------------------------------------------------
    gocardless_access_token: str | None = None
    gocardless_environment: str = Field("sandbox", description="sandbox | live")
    gocardless_webhook_secret: str | None = None
    gocardless_scheme: str = "sepa_core"

    # --- Stripe ----------------------------------------------------------------
    stripe_secret_key: str | None = None
    stripe_webhook_secret: str | None = None
    stripe_publishable_key: str | None = None

    # --- OIDC provider ---------------------------------------------------------
    oidc_enabled: bool = True
    oidc_access_token_ttl: int = 3600
    oidc_id_token_ttl: int = 3600
    oidc_refresh_token_ttl_days: int = 30
    oidc_code_ttl: int = 60
    # Endereços das apps que usam o SSO (para criar os clientes OIDC predefinidos no painel). Vazio = não criar.
    librechat_url: str | None = None
    # Slug do fornecedor OIDC no plugin Jellyfin Security (redirect /TwoFactorAuth/Oidc/Callback/<slug>)
    jellyfin_security_oidc_slug: str = "tkws"
    # Produto que dá acesso ao LibreChat (TKGPT). O cliente OIDC "librechat" exige uma subscrição ativa dele.
    librechat_product_code: str = "tkgpt"

    # --- Assistentes de IA (via LiteLLM) -------------------------------------------
    # Qualquer modelo suportado pelo LiteLLM: "anthropic/claude-sonnet-4-5", "openai/gpt-4.1-mini",
    # "ollama/qwen2.5:14b", ... Com um proxy LiteLLM usa "litellm_proxy/<nome>" + ASSISTANT_API_BASE.
    assistant_enabled: bool = False
    assistant_model: str | None = None
    assistant_api_base: str | None = None
    assistant_api_key: str | None = None
    # Modelo separado (mais barato) para o encaminhamento e para os rascunhos de conhecimento. Vazio = o mesmo.
    assistant_fast_model: str | None = None
    # Embeddings para a base de conhecimento (ex: "openai/text-embedding-3-small", "ollama/nomic-embed-text").
    # Vazio = pesquisa por palavras-chave (funciona bem com bases pequenas).
    assistant_embedding_model: str | None = None
    assistant_temperature: float = 0.2
    assistant_max_tool_rounds: int = Field(6, ge=1, le=20)
    assistant_timeout_seconds: int = 60
    # Mensagens por utilizador por hora (todos os canais).
    assistant_rate_limit_per_hour: int = 60
    # Langfuse (opcional): LANGFUSE_PUBLIC_KEY / LANGFUSE_SECRET_KEY / LANGFUSE_HOST são lidos pelo LiteLLM.
    assistant_langfuse: bool = False
    langfuse_public_key: str | None = None
    langfuse_secret_key: str | None = None
    langfuse_host: str | None = None

    # --- Bazarr (legendas) -------------------------------------------------------------
    bazarr_url: str | None = None
    bazarr_api_key: str | None = None
    # Coleção do Jellyfin que o plugin Bazarr usa para descarregar legendas automaticamente (opcional).
    bazarr_auto_collection_id: str | None = None
    # Idiomas preferidos para legendas (código ISO 639-1), por ordem.
    subtitle_languages: CsvList = Field(default_factory=lambda: ["pt", "en"])

    # --- Seerr → assistente (webhook de issues) ------------------------------------------
    seerr_webhook_secret: str | None = None
    seerr_auto_triage: bool = True
    # Máximo de issues novas analisadas pelo assistente por hora (proteção de custos).
    assistant_seerr_max_per_hour: int = 30
    # Prefixo dos comentários do assistente no Seerr (para não responder a si próprio).
    seerr_bot_prefix: str = "🤖 Suporte TKFLIX:"

    # --- WhatsApp ----------------------------------------------------------------------
    whatsapp_provider: str = Field("none", description="none | cloud | evolution")
    # Número do WhatsApp do serviço (só dígitos, com indicativo) — usado para o link wa.me no portal.
    whatsapp_number: str | None = None
    # WhatsApp Cloud API (Meta)
    whatsapp_cloud_token: str | None = None
    whatsapp_cloud_phone_number_id: str | None = None
    whatsapp_cloud_app_secret: str | None = None
    whatsapp_cloud_verify_token: str | None = None
    whatsapp_cloud_api_version: str = "v21.0"
    # Evolution API (Baileys)
    evolution_url: str | None = None
    evolution_api_key: str | None = None
    evolution_instance: str | None = None
    evolution_webhook_token: str | None = None

    # --- Worker ------------------------------------------------------------------
    # true = a fila de jobs e as tarefas periódicas correm dentro do processo da API (contentor único — o modo "all").
    run_worker_in_api: bool = False
    worker_concurrency: int = Field(2, ge=1, le=8)

    @field_validator("public_url", "jellyfin_url", "jellyfin_public_url", "seerr_url", "seerr_public_url",
                     "dispatcharr_url", "dispatcharr_public_url", "bazarr_url", "evolution_url", "assistant_api_base",
                     "librechat_url")
    @classmethod
    def _strip_slash(cls, v: str | None) -> str | None:
        return v.rstrip("/") if v else v

    @field_validator("secret_key")
    @classmethod
    def _not_placeholder(cls, v: str) -> str:
        # O valor de exemplo do .env.example tem mais de 32 caracteres e passava a validação de tamanho:
        # uma instalação que se esquecesse de o trocar ficava com os segredos da BD cifrados com uma chave pública.
        if "troca-isto" in v.lower() or "change-me" in v.lower():
            raise ValueError("SECRET_KEY ainda tem o valor de exemplo — gera uma com: openssl rand -base64 48")
        return v

    @field_validator("allowed_redirect_hosts", "trusted_proxies", "tkflix_access_hosts", "billing_retry_days", "subtitle_languages",
                     "admin_emails",
                     "jellyfin_extra_origins",
                     mode="before")
    @classmethod
    def _split_csv(cls, v):
        if isinstance(v, str):
            v = v.strip()
            if v.startswith("["):
                return json.loads(v)
            return [x.strip() for x in v.split(",") if x.strip()]
        return v

    # --- helpers -----------------------------------------------------------------
    @property
    def public_host(self) -> str:
        return urlparse(self.public_url).hostname or "localhost"

    @property
    def issuer(self) -> str:
        return self.public_url

    @property
    def is_dev(self) -> bool:
        return self.env in ("development", "test")

    @property
    def jellyfin_enabled(self) -> bool:
        return bool(self.jellyfin_url and self.jellyfin_api_key)

    @property
    def seerr_enabled(self) -> bool:
        return bool(self.seerr_url and self.seerr_api_key)

    @property
    def dispatcharr_enabled(self) -> bool:
        return bool(self.dispatcharr_url and self.dispatcharr_api_key)

    @property
    def gocardless_enabled(self) -> bool:
        return bool(self.gocardless_access_token)

    @property
    def stripe_enabled(self) -> bool:
        return bool(self.stripe_secret_key)

    @property
    def assistant_ready(self) -> bool:
        return bool(self.assistant_enabled and self.assistant_model)

    @property
    def bazarr_enabled(self) -> bool:
        return bool(self.bazarr_url and self.bazarr_api_key)

    @property
    def whatsapp_enabled(self) -> bool:
        if self.whatsapp_provider == "cloud":
            return bool(self.whatsapp_cloud_token and self.whatsapp_cloud_phone_number_id)
        if self.whatsapp_provider == "evolution":
            return bool(self.evolution_url and self.evolution_api_key and self.evolution_instance)
        return False

    @property
    def retry_days(self) -> list[int]:
        return [int(x) for x in self.billing_retry_days if str(x).strip().isdigit()]

    def is_admin_email(self, email: str | None) -> bool:
        e = (email or "").strip().lower()
        return bool(e) and e in {x.strip().lower() for x in self.admin_emails if x.strip()}

    @property
    def smtp_enabled(self) -> bool:
        return bool(self.smtp_host)


@lru_cache
def get_settings() -> Settings:
    return Settings()  # type: ignore[call-arg]
