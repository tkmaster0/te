"""Definições editadas por web, guardadas na base de dados e aplicadas sem reiniciar.

Ordem de prioridade: **web (BD) > variável de ambiente / .env > valor por omissão**. Assim a instalação arranca sem
`.env` nenhum e tudo o resto (URLs, chaves, passwords, túnel…) é definido no assistente de configuração ou em
Admin → Definições — e pode ser mudado lá mais tarde.

Só as definições listadas em `FIELDS` são editáveis por web. A SECRET_KEY e a ligação à base de dados nunca são:
são geradas no primeiro arranque (ver deploy/entrypoint.sh).

Os segredos ficam cifrados com a SECRET_KEY e nunca são devolvidos à interface (só "definido" e os 4 últimos
caracteres).
"""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from typing import Any
from urllib.parse import urlparse

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from ..db import utcnow
from ..models import ConfigEntry
from ..security import decrypt, encrypt

log = logging.getLogger("tkportal.config")

SETUP_KEY = "_setup_completed_at"


@dataclass(frozen=True)
class F:
    name: str
    label: str
    type: str = "text"  # text | url | secret | bool | int | float | money | list | select | email
    help: str | None = None
    placeholder: str | None = None
    options: tuple[tuple[str, str], ...] = ()
    advanced: bool = False
    min: int | None = None
    max: int | None = None


@dataclass(frozen=True)
class Section:
    id: str
    title: str
    description: str
    fields: tuple[F, ...]
    links: tuple[tuple[str, str], ...] = field(default_factory=tuple)  # (rótulo, url) — "{public_url}" é substituído
    test: bool = False


SECTIONS: tuple[Section, ...] = (
    Section("geral", "Geral", "Nome, endereço público e registo.", (
        F("app_name", "Nome do portal", placeholder="TK Web Services"),
        F("public_url", "Endereço público do portal", "url",
          "O endereço por onde os clientes abrem o portal (ex.: https://tkws.tkflix.eu). Usado nos emails, no SSO e "
          "nos webhooks.", "https://tkws.exemplo.pt"),
        F("registration_mode", "Registo", "select", options=(("open", "Aberto a todos"), ("invite", "Só com convite"))),
        F("require_email_verification", "Exigir email confirmado (código OTP) para aderir", "bool"),
        F("admin_notify_email", "Email para avisos do administrador", "email"),
        F("admin_emails", "Emails de administrador", "list",
          "Quem se registar (ou entrar, com o email confirmado) com um destes emails fica administrador. O primeiro "
          "registo destes emails não pede código OTP.", "geral@tkmasterproductions.eu"),
        F("cookie_domain", "Domínio da sessão", help="Domínio pai para a sessão valer nos subdomínios protegidos por "
          "forward-auth (ex.: .tkflix.eu). Vazio = só o endereço do portal.", placeholder=".tkflix.eu"),
        F("allowed_redirect_hosts", "Hosts para onde o login pode voltar", "list",
          "Separados por vírgulas; aceita *.dominio.", "*.tkflix.eu, tkflix.eu"),
        F("trusted_proxies", "Proxies de confiança (IP real dos clientes)", "list", advanced=True),
        F("log_level", "Detalhe dos registos (logs)", "select", options=(
            ("ERROR", "Só erros"), ("WARNING", "Avisos"), ("INFO", "Normal"), ("DEBUG", "Tudo (diagnóstico)")),
          advanced=True),
    )),
    Section("seguranca", "Sessões e segurança", "Quanto tempo as sessões duram e como os cookies são enviados.", (
        F("session_ttl_hours", "Duração máxima de uma sessão (horas)", "int", min=1, max=8760),
        F("session_idle_hours", "Termina a sessão depois de N horas sem uso", "int", min=1, max=8760),
        F("cookie_secure", "Cookies só por HTTPS", "bool",
          "Ligado: em HTTPS o cookie leva a flag Secure (por HTTP, ex. http://IP:8090 na rede local, o login continua "
          "a funcionar)."),
        F("oidc_access_token_ttl", "SSO: validade do access token (segundos)", "int", min=60, max=86400,
          advanced=True),
        F("oidc_id_token_ttl", "SSO: validade do ID token (segundos)", "int", min=60, max=86400, advanced=True),
        F("oidc_refresh_token_ttl_days", "SSO: validade do refresh token (dias)", "int", min=1, max=365,
          advanced=True),
        F("oidc_code_ttl", "SSO: validade do código de autorização (segundos)", "int", min=10, max=600,
          advanced=True),
    )),
    Section("tunel", "Túnel Cloudflare", "Publica o portal na internet sem abrir portas. O cloudflared corre dentro do "
            "contentor do portal: no painel do túnel, o Public Hostname aponta para http://localhost:8000.", (
        F("cloudflare_tunnel_token", "Token do túnel", "secret",
          "Zero Trust → Networks → Tunnels → Create a tunnel (Cloudflared) → copia o token (o texto depois de "
          "--token)."),
    ), links=(("Abrir os túneis na Cloudflare", "https://one.dash.cloudflare.com/?to=/:account/networks/tunnels"),)),
    Section("email", "Email (SMTP)", "Códigos de confirmação, recuperação de password e avisos de pagamento.", (
        F("smtp_host", "Servidor SMTP", placeholder="smtp.mail.ovh.net"),
        F("smtp_port", "Porta", "int", min=1, max=65535),
        F("smtp_tls_mode", "Segurança", "select", options=(("ssl", "SSL/TLS (465)"), ("starttls", "STARTTLS (587)"),
                                                           ("none", "Nenhuma"))),
        F("smtp_username", "Utilizador"),
        F("smtp_password", "Password", "secret"),
        F("mail_from", "Remetente", placeholder="TK Web Services <no-reply@exemplo.pt>"),
    ), test=True),
    Section("gocardless", "GoCardless (débito direto SEPA)", "O cliente autoriza o mandato uma vez; o portal cobra o "
            "valor de cada mês. Não é preciso criar planos nem preços na GoCardless.", (
        F("gocardless_environment", "Ambiente", "select", options=(("live", "Produção (live)"),
                                                                   ("sandbox", "Testes (sandbox)"))),
        F("gocardless_access_token", "Access token", "secret", "Developers → Access tokens → Create (Read-write)."),
        F("gocardless_webhook_secret", "Segredo do webhook", "secret",
          "Developers → Webhook endpoints → Create: URL {public_url}/api/webhooks/gocardless — copia o segredo."),
        F("gocardless_scheme", "Esquema", "select", options=(("sepa_core", "SEPA Core"), ("bacs", "Bacs (UK)")),
          advanced=True),
    ), links=(("Criar access token (live)", "https://manage.gocardless.com/developers/access-tokens/create"),
              ("Criar webhook (live)", "https://manage.gocardless.com/developers/webhook-endpoints/create"),
              ("Criar access token (sandbox)", "https://manage-sandbox.gocardless.com/developers/access-tokens/create"),
              ("Criar webhook (sandbox)",
               "https://manage-sandbox.gocardless.com/developers/webhook-endpoints/create")), test=True),
    Section("stripe", "Stripe (cartão, Apple Pay, Google Pay)", "O cartão fica guardado com autorização para "
            "cobranças futuras; o portal cobra o valor de cada mês. Não é preciso criar produtos nem preços no Stripe.", (
        F("stripe_secret_key", "Secret key", "secret", "Developers → API keys → Secret key (sk_live_… ou sk_test_…)."),
        F("stripe_publishable_key", "Publishable key", placeholder="pk_live_…"),
        F("stripe_webhook_secret", "Segredo do webhook", "secret",
          "Usa o botão \"Criar webhook automaticamente\" — ou cria um em Developers → Webhooks com o URL "
          "{public_url}/api/webhooks/stripe e copia o segredo (whsec_…)."),
    ), links=(("Chaves da API", "https://dashboard.stripe.com/apikeys"),
              ("Webhooks", "https://dashboard.stripe.com/webhooks"),
              ("Chaves de teste", "https://dashboard.stripe.com/test/apikeys")), test=True),
    Section("faturacao", "Faturação", "Como e quando o portal cobra.", (
        F("billing_require_method", "Aderir exige autorização de pagamento (débito direto ou cartão)", "bool"),
        F("billing_hour_utc", "Hora das cobranças (UTC)", "int", min=0, max=23),
        F("grace_period_days", "Dias de tolerância depois de uma falha", "int", min=0, max=60),
        F("billing_retry_days", "Novas tentativas (dias depois da anterior)", "list", placeholder="3, 4"),
        F("billing_min_charge_cents", "Valor mínimo a cobrar", "money",
          "Abaixo disto passa para a cobrança seguinte (poupa taxas)."),
        F("proration_charge", "Pro-rata de upgrades", "select",
          options=(("next_invoice", "Na próxima cobrança mensal"), ("immediate", "Cobrar logo"))),
        F("charge_first_purchase_immediately", "Cobrar logo a primeira adesão", "bool"),
        F("price_change_notice_days", "Aviso mínimo de mudança de preço (dias)", "int", min=0),
        F("payment_method_grace_days", "Dias para o cliente autorizar um novo método (mandato revogado)", "int",
          min=0, max=90),
        F("suspended_end_days", "Dias suspensa até terminar", "int", min=1, advanced=True),
    )),
    Section("jellyfin", "Jellyfin", "Contas, acessos e SSO do streaming.", (
        F("jellyfin_url", "Endereço usado pelo portal", "url",
          "Mesma máquina: http://host.docker.internal:8096 ou http://DUMB:8096 (rede tkflix-link). Noutra máquina: o "
          "endereço público.", "http://host.docker.internal:8096"),
        F("jellyfin_public_url", "Endereço público (clientes)", "url", placeholder="https://tkflix.eu"),
        F("jellyfin_api_key", "API key", "secret", "Painel do Jellyfin → API Keys → +"),
        F("jellyfin_extra_origins", "Outros endereços do Jellyfin", "list", advanced=True),
        F("sso_only_for_new_users", "Contas novas entram só por SSO / Quick Connect", "bool"),
        F("jellyfin_sync_password", "Clientes antigos: password do Jellyfin igual à do portal", "bool"),
        F("jellyfin_security_oidc_slug", "Nome do fornecedor no plugin Jellyfin Security", advanced=True),
    ), test=True),
    Section("seerr", "Seerr (pedidos)", "Contas e quotas de pedidos.", (
        F("seerr_url", "Endereço usado pelo portal", "url", placeholder="http://host.docker.internal:5055"),
        F("seerr_public_url", "Endereço público", "url", placeholder="https://pedidos.tkflix.eu"),
        F("seerr_api_key", "API key", "secret", "Seerr → Definições → Geral → API Key."),
        F("seerr_webhook_secret", "Segredo do webhook de issues", "secret",
          "Seerr → Notificações → Webhook: URL {public_url}/api/webhooks/seerr e este valor no Authorization Header."),
        F("seerr_auto_triage", "O assistente analisa as issues novas", "bool"),
        F("seerr_bot_prefix", "Prefixo dos comentários do assistente nas issues", advanced=True),
        F("assistant_seerr_max_per_hour", "Máximo de issues analisadas por hora", "int", min=0, advanced=True),
    ), test=True),
    Section("tv", "TV / IPTV (Dispatcharr)", "Os planos com TV criam, renovam, desativam e apagam o utilizador no "
            "Dispatcharr sozinhos. A password XC é gerada automaticamente e o cliente vê-a e muda-a no portal.", (
        F("dispatcharr_url", "Endereço usado pelo portal", "url", placeholder="http://host.docker.internal:9191"),
        F("dispatcharr_public_url", "Servidor XC/M3U dado aos clientes", "url", placeholder="https://tv.tkflix.eu"),
        F("dispatcharr_api_key", "API key", "secret"),
        F("dispatcharr_delete_after_days", "Apagar no Dispatcharr depois de N dias sem TV (0 = nunca)", "int", min=0),
    ), test=True),
    Section("bazarr", "Bazarr (legendas)", "Pedidos de legendas a partir do assistente.", (
        F("bazarr_url", "Endereço usado pelo portal", "url", placeholder="http://host.docker.internal:6767"),
        F("bazarr_api_key", "API key", "secret", "Bazarr → Settings → General → Security → API Key."),
        F("subtitle_languages", "Idiomas preferidos", "list", placeholder="pt, en"),
        F("bazarr_auto_collection_id", "Coleção do Jellyfin para legendas automáticas (id)", advanced=True,
          help="Opcional: os itens com legendas pedidas pelo assistente são juntos a esta coleção."),
    ), test=True),
    Section("acesso", "Acesso remoto ao TKFLIX", "Só se o portal estiver noutra máquina e alguma API do TKFLIX estiver "
            "protegida pelo Cloudflare Access (política Service Auth).", (
        F("tkflix_access_client_id", "Client ID do service token"),
        F("tkflix_access_client_secret", "Client secret do service token", "secret"),
        F("tkflix_access_hosts", "Hosts que recebem o token", "list", "Vazio = os hosts das URLs acima."),
    ), links=(("Service tokens (Cloudflare Access)",
               "https://one.dash.cloudflare.com/?to=/:account/access/service-auth"),)),
    Section("sso", "SSO e apps", "O portal é o fornecedor de identidade (OIDC) do Jellyfin, Seerr e LibreChat.", (
        F("oidc_enabled", "SSO ligado", "bool"),
        F("librechat_url", "Endereço do LibreChat (TKGPT)", "url", placeholder="https://chat.exemplo.pt"),
        F("librechat_product_code", "Produto que dá acesso ao LibreChat", advanced=True),
    )),
    Section("convites", "Convites e bónus", "Programa de convites.", (
        F("invites_per_user", "Convites por cliente", "int", min=0),
        F("invites_require_active_subscription", "Só quem tem subscrição ativa convida", "bool"),
        F("bonus_enabled", "Bónus de convites", "bool"),
        F("bonus_threshold", "Convidados a pagar para o bónus", "int", min=1),
        F("bonus_threshold_admin_referred", "… se foi convidado pelo admin", "int", min=1),
    )),
    Section("carteira", "Carteira e jogos", "Créditos (1 crédito = 1 €) usados antes de cada cobrança.", (
        F("wallet_enabled", "Carteira ligada", "bool"),
        F("wallet_min_topup_cents", "Carregamento mínimo", "money"),
        F("wallet_max_topup_cents", "Carregamento máximo", "money"),
        F("wallet_monthly_enabled", "Carregamento mensal", "bool", "Desligado = os serviços são cobrados pelo método "
          "autorizado (recomendado)."),
        F("wallet_min_monthly_cents", "Carregamento mensal mínimo", "money", advanced=True),
        F("wallet_max_monthly_cents", "Carregamento mensal máximo", "money", advanced=True),
        F("wallet_monthly_bonus_percent", "Bónus do carregamento mensal (%)", "int", min=0, max=100, advanced=True),
        F("wallet_only_for_new_users", "Carteira só para contas novas", "bool", advanced=True),
        F("games_enabled", "Jogos (roleta e blackjack)", "bool", "Precisa de licença do SRIJ em Portugal."),
        F("games_min_bet_cents", "Aposta mínima", "money"),
        F("games_max_bet_cents", "Aposta máxima", "money"),
        F("games_daily_loss_limit_cents", "Perda máxima por dia", "money"),
        F("games_min_age", "Idade mínima para jogar", "int", min=18, max=99),
        F("games_require_product", "Só para clientes com o produto (código)", advanced=True,
          help="Vazio = qualquer cliente com conta pode jogar."),
    )),
    Section("assistente", "Assistente de IA", "Suporte no portal, no Jellyfin e no WhatsApp.", (
        F("assistant_enabled", "Assistente ligado", "bool"),
        F("assistant_model", "Modelo (LiteLLM)", placeholder="anthropic/claude-sonnet-4-5"),
        F("assistant_api_key", "API key do modelo", "secret"),
        F("assistant_api_base", "Endereço da API (opcional)", "url", advanced=True),
        F("assistant_fast_model", "Modelo rápido (opcional)", advanced=True),
        F("assistant_embedding_model", "Modelo de embeddings (opcional)", advanced=True),
        F("assistant_temperature", "Criatividade (temperatura)", "float", "0 = respostas mais previsíveis.",
          min=0, max=2, advanced=True),
        F("assistant_max_tool_rounds", "Máximo de ações por resposta", "int", min=1, max=20, advanced=True),
        F("assistant_timeout_seconds", "Tempo máximo por resposta (segundos)", "int", min=5, max=600, advanced=True),
        F("assistant_rate_limit_per_hour", "Mensagens por cliente por hora", "int", min=1, max=10000,
          advanced=True),
        F("assistant_langfuse", "Enviar conversas para o Langfuse (observabilidade)", "bool", advanced=True),
        F("langfuse_host", "Langfuse: endereço", "url", placeholder="https://cloud.langfuse.com", advanced=True),
        F("langfuse_public_key", "Langfuse: public key", advanced=True),
        F("langfuse_secret_key", "Langfuse: secret key", "secret", advanced=True),
    )),
    Section("whatsapp", "WhatsApp", "Suporte por WhatsApp (opcional).", (
        F("whatsapp_provider", "Fornecedor", "select", options=(("none", "Desligado"), ("cloud", "WhatsApp Cloud API"),
                                                                ("evolution", "Evolution API"))),
        F("whatsapp_number", "Número (só dígitos, com indicativo)"),
        F("whatsapp_cloud_token", "Cloud API: token", "secret"),
        F("whatsapp_cloud_phone_number_id", "Cloud API: phone number ID"),
        F("whatsapp_cloud_app_secret", "Cloud API: app secret", "secret"),
        F("whatsapp_cloud_verify_token", "Cloud API: verify token", "secret"),
        F("evolution_url", "Evolution: endereço", "url"),
        F("evolution_api_key", "Evolution: API key", "secret"),
        F("evolution_instance", "Evolution: instância"),
        F("evolution_webhook_token", "Evolution: token do webhook", "secret"),
        F("whatsapp_cloud_api_version", "Cloud API: versão da Graph API", advanced=True, placeholder="v21.0"),
    )),
)

FIELDS: dict[str, F] = {f.name: f for sec in SECTIONS for f in sec.fields}
SECRET = {n for n, f in FIELDS.items() if f.type == "secret"}

# Valores vindos do ambiente/omissão de cada definição sobreposta (para repor quando o override é apagado).
_base: dict[str, Any] = {}
_applied: set[str] = set()


class ConfigError(ValueError):
    pass


def coerce(name: str, raw: Any) -> Any:
    """Valida e converte um valor vindo da interface para o tipo da definição."""
    f = FIELDS.get(name)
    if f is None:
        raise ConfigError(f"Definição desconhecida: {name}")
    if isinstance(raw, str):
        raw = raw.strip()
    if f.type == "bool":
        if isinstance(raw, str):
            return raw.lower() in ("1", "true", "sim", "on", "yes")
        return bool(raw)
    if f.type in ("int", "money"):
        if raw in (None, ""):
            raise ConfigError(f"{f.label}: indica um número.")
        try:
            v = int(raw)
        except (TypeError, ValueError) as exc:
            raise ConfigError(f"{f.label}: tem de ser um número inteiro.") from exc
        if f.min is not None and v < f.min:
            raise ConfigError(f"{f.label}: mínimo {f.min}.")
        if f.max is not None and v > f.max:
            raise ConfigError(f"{f.label}: máximo {f.max}.")
        if f.type == "money" and v < 0:
            raise ConfigError(f"{f.label}: não pode ser negativo.")
        return v
    if f.type == "float":
        try:
            v = float(str(raw).replace(",", "."))
        except (TypeError, ValueError) as exc:
            raise ConfigError(f"{f.label}: tem de ser um número.") from exc
        if (f.min is not None and v < f.min) or (f.max is not None and v > f.max):
            raise ConfigError(f"{f.label}: entre {f.min} e {f.max}.")
        return v
    if f.type == "list":
        if raw in (None, ""):
            return []
        items = raw if isinstance(raw, list) else str(raw).split(",")
        return [str(x).strip() for x in items if str(x).strip()]
    if f.type == "select":
        allowed = {o[0] for o in f.options}
        if raw not in allowed:
            raise ConfigError(f"{f.label}: valor inválido.")
        return raw
    # texto / url / email / segredo
    if raw in (None, ""):
        return None
    v = str(raw)
    if len(v) > 4000:
        raise ConfigError(f"{f.label}: demasiado longo.")
    if f.type == "url":
        p = urlparse(v)
        if p.scheme not in ("http", "https") or not p.netloc:
            raise ConfigError(f"{f.label}: tem de começar por http:// ou https://")
        v = v.rstrip("/")
    if f.type == "email" and "@" not in v:
        raise ConfigError(f"{f.label}: email inválido.")
    return v


def _set(name: str, value: Any) -> None:
    s = get_settings()
    if name not in _base:
        _base[name] = getattr(s, name)
    setattr(s, name, value)
    _applied.add(name)
    _after_change(name)


def _restore(name: str) -> None:
    if name in _applied:
        setattr(get_settings(), name, _base.get(name))
        _applied.discard(name)
        _after_change(name)


_LANGFUSE_ENV = {"langfuse_public_key": "LANGFUSE_PUBLIC_KEY", "langfuse_secret_key": "LANGFUSE_SECRET_KEY",
                 "langfuse_host": "LANGFUSE_HOST"}


def _after_change(name: str) -> None:
    # Clientes com estado em cache que dependem destas chaves.
    if name.startswith("stripe_"):
        from ..integrations import stripe_client

        stripe_client.reset_client()
    elif name == "log_level":
        logging.getLogger().setLevel(str(get_settings().log_level or "INFO").upper())
    elif name in _LANGFUSE_ENV:
        # O LiteLLM lê as chaves do Langfuse do ambiente do processo.
        value = getattr(get_settings(), name)
        if value:
            os.environ[_LANGFUSE_ENV[name]] = str(value)
        else:
            os.environ.pop(_LANGFUSE_ENV[name], None)


async def load(db: AsyncSession) -> int:
    """Aplica às definições em memória o que está guardado na BD. Devolve quantas estão sobrepostas."""
    rows = {r.key: r for r in (await db.scalars(select(ConfigEntry))).all()}
    n = 0
    for name in FIELDS:
        row = rows.get(name)
        if row is None:
            _restore(name)
            continue
        value = row.value
        if row.secret:
            value = decrypt(value) if isinstance(value, str) else None
        try:
            value = coerce(name, value)
        except ConfigError as exc:
            log.warning("Definição %s inválida na BD (%s) — ignorada", name, exc)
            continue
        if getattr(get_settings(), name, object()) != value or name not in _applied:
            _set(name, value)
        n += 1
    return n


async def save(db: AsyncSession, changes: dict[str, Any], *, actor_id: str | None = None) -> list[str]:
    """Grava alterações vindas da web. Num segredo, "" ou None mantém o valor; `{"clear": true}` apaga-o.
    Para voltar ao valor do ambiente usa `{"reset": true}`."""
    changed: list[str] = []
    for name, raw in changes.items():
        f = FIELDS.get(name)
        if f is None:
            raise ConfigError(f"Definição desconhecida: {name}")
        row = await db.get(ConfigEntry, name)
        if isinstance(raw, dict) and raw.get("reset"):
            if row is not None:
                await db.delete(row)
                changed.append(name)
            continue
        if f.type == "secret":
            if isinstance(raw, dict) and raw.get("clear"):
                value = None
            elif raw in (None, ""):
                continue  # campo de segredo vazio = manter o atual
            else:
                value = coerce(name, raw)
            stored = encrypt(value) if value else None
        else:
            value = coerce(name, raw)
            stored = value
        if row is None:
            db.add(ConfigEntry(key=name, value=stored, secret=f.type == "secret", updated_by=actor_id))
        else:
            row.value, row.secret, row.updated_by, row.updated_at = stored, f.type == "secret", actor_id, utcnow()
        changed.append(name)
    await db.flush()
    return changed


def _mask(v: Any) -> str | None:
    if not v:
        return None
    t = str(v)
    return f"••••{t[-4:]}" if len(t) > 8 else "••••"


async def describe(db: AsyncSession) -> list[dict]:
    """Esquema das secções + valores atuais (segredos mascarados) para a interface."""
    s = get_settings()
    stored = set((await db.scalars(select(ConfigEntry.key))).all())
    pub = s.public_url
    out = []
    for sec in SECTIONS:
        fields = []
        for f in sec.fields:
            cur = getattr(s, f.name, None)
            item = {"name": f.name, "label": f.label, "type": f.type, "help": (f.help or "").replace("{public_url}", pub)
                    or None, "placeholder": f.placeholder, "advanced": f.advanced, "min": f.min, "max": f.max,
                    "options": [{"value": v, "label": lbl} for v, lbl in f.options],
                    "source": "web" if f.name in stored else ("env" if cur not in (None, "", [], _default(f.name))
                                                              else "default")}
            if f.type == "secret":
                item.update({"value": None, "is_set": bool(cur), "masked": _mask(cur)})
            else:
                item["value"] = cur
            fields.append(item)
        out.append({"id": sec.id, "title": sec.title, "description": sec.description.replace("{public_url}", pub),
                    "fields": fields, "test": sec.test,
                    "links": [{"label": lbl, "url": url.replace("{public_url}", pub)} for lbl, url in sec.links]})
    return out


def _default(name: str) -> Any:
    from ..config import Settings

    fld = Settings.model_fields.get(name)
    if fld is None:
        return None
    if fld.default_factory is not None:
        return fld.default_factory()  # type: ignore[call-arg]
    return fld.default


async def setup_completed(db: AsyncSession) -> bool:
    return (await db.get(ConfigEntry, SETUP_KEY)) is not None


async def mark_setup_completed(db: AsyncSession, actor_id: str | None) -> None:
    if await db.get(ConfigEntry, SETUP_KEY) is None:
        db.add(ConfigEntry(key=SETUP_KEY, value=utcnow().isoformat(), secret=False, updated_by=actor_id))
