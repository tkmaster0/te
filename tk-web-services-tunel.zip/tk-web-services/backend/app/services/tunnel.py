"""Túnel Cloudflare dentro do contentor do portal.

O `cloudflared` vem na imagem e é arrancado (e vigiado) pelo próprio portal quando há um token definido — no
assistente de configuração ou em Admin → Definições → Túnel. Mudar ou apagar o token reinicia/para o túnel sem
reiniciar o contentor.

No painel da Cloudflare, o Public Hostname do portal aponta para **http://localhost:8000** (o cloudflared está no
mesmo contentor). Para um túnel já existente funcionar sem mexer no painel, o portal também atende dentro do
contentor em 8090, 8080 e 80 (reencaminhados para o 8000) — ex.: um hostname antigo em http://localhost:8090.
"""
from __future__ import annotations

import asyncio
import contextlib
import logging
import os
import shutil
from collections import deque

import httpx

from ..config import get_settings

log = logging.getLogger("tkportal.tunnel")

METRICS = "127.0.0.1:20241"
_proc: asyncio.subprocess.Process | None = None
_token_running: str | None = None
_lines: deque[str] = deque(maxlen=40)
_lock = asyncio.Lock()
_restarts = 0
ALIAS_PORTS = (8090, 8080, 80)
APP_PORT = 8000
_alias_servers: list[asyncio.base_events.Server] = []


async def _forward(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
    try:
        up_r, up_w = await asyncio.open_connection("127.0.0.1", APP_PORT)
    except OSError:
        writer.close()
        return

    async def pipe(src: asyncio.StreamReader, dst: asyncio.StreamWriter) -> None:
        try:
            while data := await src.read(65536):
                dst.write(data)
                await dst.drain()
        except (OSError, asyncio.CancelledError):
            pass
        finally:
            with contextlib.suppress(Exception):
                dst.close()

    await asyncio.gather(pipe(reader, up_w), pipe(up_r, writer))


async def start_aliases() -> list[int]:
    """Portas extra (só dentro do contentor) que reencaminham para o portal."""
    bound = []
    for port in ALIAS_PORTS:
        try:
            _alias_servers.append(await asyncio.start_server(_forward, "0.0.0.0", port))
            bound.append(port)
        except OSError:
            pass  # porta ocupada ou sem permissão (ex.: 80) — o 8000 continua a funcionar
    if bound:
        log.info("Túnel: o portal também atende em %s (reencaminhado para %d)", bound, APP_PORT)
    return bound


async def stop_aliases() -> None:
    while _alias_servers:
        srv = _alias_servers.pop()
        srv.close()
        with contextlib.suppress(Exception):
            await srv.wait_closed()


def binary() -> str | None:
    return shutil.which("cloudflared")


async def _pump(stream: asyncio.StreamReader) -> None:
    while True:
        line = await stream.readline()
        if not line:
            return
        text = line.decode(errors="replace").rstrip()
        # O token nunca vai para os registos.
        if _token_running and _token_running in text:
            text = text.replace(_token_running, "••••")
        _lines.append(text)


async def _start(token: str) -> None:
    global _proc, _token_running
    exe = binary()
    if not exe:
        _lines.append("cloudflared não está instalado nesta imagem.")
        return
    env = {**os.environ, "TUNNEL_TOKEN": token, "HOME": os.environ.get("HOME") or "/tmp"}
    _token_running = token
    _proc = await asyncio.create_subprocess_exec(
        exe, "tunnel", "--no-autoupdate", "--metrics", METRICS, "run",
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT, env=env)
    assert _proc.stdout is not None
    asyncio.get_running_loop().create_task(_pump(_proc.stdout))
    log.info("Túnel Cloudflare a arrancar (pid %s)", _proc.pid)


async def _stop() -> None:
    global _proc, _token_running
    p, _proc, _token_running = _proc, None, None
    if p and p.returncode is None:
        p.terminate()
        try:
            await asyncio.wait_for(p.wait(), 10)
        except TimeoutError:
            p.kill()
        log.info("Túnel Cloudflare parado")


async def ensure() -> None:
    """Põe o processo de acordo com a definição atual (arranca, reinicia com o token novo, ou para)."""
    global _restarts
    async with _lock:
        token = (get_settings().cloudflare_tunnel_token or "").strip() or None
        if token is None:
            await _stop()
            return
        if _proc is not None and _proc.returncode is None and token == _token_running:
            return
        if _proc is not None and _proc.returncode is not None:
            _restarts += 1
        await _stop()
        await _start(token)


async def supervise(stop: asyncio.Event) -> None:
    """Corre com o portal: reinicia o túnel se cair (com espera crescente) e aplica mudanças do token."""
    delay = 5
    with contextlib.suppress(Exception):
        await start_aliases()
    while not stop.is_set():
        try:
            crashed = _proc is not None and _proc.returncode is not None
            await ensure()
            delay = min(delay * 2, 120) if crashed else 5
        except Exception as exc:  # noqa: BLE001
            log.warning("Túnel: %s", exc)
        with contextlib.suppress(TimeoutError):
            await asyncio.wait_for(stop.wait(), delay)
    await _stop()
    await stop_aliases()


async def status() -> dict:
    s = get_settings()
    running = _proc is not None and _proc.returncode is None
    connections = None
    if running:
        try:
            async with httpx.AsyncClient(timeout=2) as c:
                r = await c.get(f"http://{METRICS}/ready")
            connections = int((r.json() or {}).get("readyConnections") or 0) if r.status_code in (200, 503) else 0
        except (httpx.HTTPError, ValueError):
            connections = 0
    return {
        "installed": binary() is not None,
        "configured": bool(s.cloudflare_tunnel_token),
        "running": running,
        "connected": bool(connections),
        "connections": connections,
        "restarts": _restarts,
        "exit_code": _proc.returncode if _proc is not None and not running else None,
        "log": list(_lines)[-15:],
        "service_url": "http://localhost:8000",
    }
