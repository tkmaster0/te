import { useEffect, useState } from 'react'
import { useQueryClient } from '@tanstack/react-query'
import clsx from 'clsx'
import { ArrowDownRight, ArrowUpRight, CheckCircle2 } from 'lucide-react'
import { api, errorMessage } from '../../api/client'
import { BILLING_INVALIDATE } from '../../api/keys'
import { useAction } from '../../api/mutation'
import { useBillingSummary, useProducts, useQuote } from '../../api/queries'
import type { ChangePlanOut, Plan, Subscription } from '../../api/types'
import { formatMoney, perInterval } from '../../lib/format'
import { Alert, Badge, Button, Modal, Skeleton } from '../ui'
import { QuoteSummary } from './QuoteSummary'

function PlanOption({
  plan,
  current,
  selected,
  onSelect,
  price,
  selectable,
}: {
  plan: Plan
  current: boolean
  selected: boolean
  onSelect: () => void
  price: number
  selectable?: boolean
}) {
  const locked = current && !selectable
  return (
    <label
      className={clsx(
        'flex items-center gap-3 rounded-xl border p-3.5 transition-colors',
        locked ? 'cursor-default border-border bg-elevated/50' : 'cursor-pointer hover:border-border-strong',
        selected && 'border-brand bg-brand-soft',
      )}
    >
      <input
        type="radio"
        name="change-plan"
        checked={selected}
        disabled={locked}
        onChange={onSelect}
        className="size-4 shrink-0 accent-[var(--c-brand)] disabled:opacity-40"
      />
      <span className="min-w-0 flex-1">
        <span className="flex flex-wrap items-center gap-2 text-sm font-semibold">
          {plan.name}
          {current && <Badge tone="success">Atual</Badge>}
        </span>
        {plan.highlights.length > 0 && <span className="mt-0.5 block truncate text-xs text-muted">{plan.highlights.slice(0, 2).join(' · ')}</span>}
      </span>
      <span className="shrink-0 text-right">
        <span className="block text-sm font-bold tabular-nums">
          {formatMoney(price, plan.currency)}
          <span className="font-normal text-muted">{perInterval(plan.interval_unit, plan.interval_count)}</span>
        </span>
        {plan.interval_unit === 'year' && (
          <span className="block text-[11px] text-muted">equivale a {formatMoney(plan.monthly_equivalent_cents, plan.currency)}/mês</span>
        )}
      </span>
    </label>
  )
}

/** Mudar de plano dentro do mesmo produto, com pré-visualização pro-rata antes de confirmar. */
export function ChangePlanModal({
  sub,
  open,
  onClose,
  initialPlanId,
}: {
  sub: Subscription | null
  open: boolean
  onClose: () => void
  initialPlanId?: number | null
}) {
  const qc = useQueryClient()
  const products = useProducts()
  const summary = useBillingSummary()
  const [selected, setSelected] = useState<number | null>(initialPlanId ?? null)
  const [done, setDone] = useState<string | null>(null)

  useEffect(() => {
    if (open) {
      setSelected(initialPlanId && (initialPlanId !== sub?.plan.id || sub?.pending_plan) ? initialPlanId : null)
      setDone(null)
    }
  }, [open, initialPlanId, sub?.plan.id])

  const quote = useQuote(open && selected ? selected : null, sub?.id)
  const change = useAction((planId: number) => api.post<ChangePlanOut>(`/api/billing/subscriptions/${sub!.id}/change`, { plan_id: planId }), {
    success: false,
    errorTitle: false,
    onSuccess: async (res) => {
      await Promise.all(BILLING_INVALIDATE.map((k) => qc.invalidateQueries({ queryKey: k })))
      setDone(res.message)
    },
  })

  if (!sub) return null
  const product = products.data?.find((p) => p.id === sub.product.id)
  const plans = product?.plans ?? []
  const list = plans.some((p) => p.id === sub.plan.id) ? plans : [sub.plan, ...plans]
  const def = summary.data?.payment_methods.find((m) => m.id === summary.data?.default_payment_method_id)
  const target = list.find((p) => p.id === selected)
  const q = selected ? quote.data : undefined
  const direction = q?.is_upgrade === true ? 'up' : q?.is_upgrade === false ? 'down' : null
  const keeping = !!sub.pending_plan && selected === sub.plan.id

  if (done)
    return (
      <Modal open={open} onClose={onClose} title={done.includes('renovação') ? 'Mudança agendada' : 'Plano alterado'} size="sm" footer={<Button onClick={onClose}>Feito</Button>}>
        <div className="flex flex-col items-center gap-3 py-2 text-center" role="status">
          <CheckCircle2 className="size-10 text-success" aria-hidden />
          <p className="text-sm">{done}</p>
        </div>
      </Modal>
    )

  return (
    <Modal
      open={open}
      onClose={change.isPending ? () => undefined : onClose}
      title="Mudar de plano"
      description={`${sub.product_name} · estás no plano ${sub.plan.name}`}
      size="lg"
      footer={
        <>
          <Button variant="secondary" onClick={onClose} disabled={change.isPending}>
            Cancelar
          </Button>
          <Button onClick={() => selected && change.mutate(selected)} loading={change.isPending} disabled={!selected || !q || quote.isFetching || quote.isError}>
            {keeping ? 'Manter o plano atual' : !target ? 'Escolhe um plano' : q?.scheduled_at ? `Agendar ${target.name}` : `Mudar para ${target.name}`}
          </Button>
        </>
      }
    >
      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        <div className="min-w-0">
          <p className="mb-2 text-sm font-medium">Escolhe o novo plano</p>
          {products.isPending ? (
            <div className="space-y-2">
              <Skeleton className="h-16" />
              <Skeleton className="h-16" />
            </div>
          ) : list.length <= 1 ? (
            <p className="text-sm text-muted">Não há outros planos disponíveis para este serviço.</p>
          ) : (
            <div className="space-y-2" role="radiogroup" aria-label="Planos disponíveis">
              {list.map((p) => (
                <PlanOption
                  key={p.id}
                  plan={p}
                  current={p.id === sub.plan.id}
                  selectable={p.id === sub.plan.id && !!sub.pending_plan}
                  selected={selected === p.id}
                  onSelect={() => setSelected(p.id)}
                  price={p.id === sub.plan.id ? sub.price_cents : p.price_cents}
                />
              ))}
            </div>
          )}
          <p className="mt-3 text-xs text-muted">
            Subir de plano é imediato: os dias que já pagaste são descontados e o novo plano conta só a partir de hoje (pro-rata). Descer de plano acontece na renovação — até lá
            continuas com o plano atual, que já está pago.
          </p>
          {sub.pending_plan && (
            <Alert tone="info" className="mt-3">
              Já tens agendada a passagem para {sub.pending_plan}. Escolhe o plano atual para a cancelar.
            </Alert>
          )}
        </div>
        <div className="min-w-0">
          {!selected ? (
            <div className="grid h-full min-h-40 place-items-center rounded-2xl border border-dashed border-border p-6 text-center text-sm text-muted">
              Escolhe um plano para veres exatamente quanto pagas e quando.
            </div>
          ) : quote.isError ? (
            <Alert tone="danger">{errorMessage(quote.error)}</Alert>
          ) : (
            <div className="space-y-3">
              {direction && (
                <Badge tone={direction === 'up' ? 'brand' : 'info'}>
                  <span className="inline-flex items-center gap-1">
                    {direction === 'up' ? <ArrowUpRight className="size-3.5" /> : <ArrowDownRight className="size-3.5" />}
                    {direction === 'up' ? 'Upgrade' : 'Downgrade'}
                  </span>
                </Badge>
              )}
              <QuoteSummary quote={q} loading={quote.isPending || (quote.isFetching && quote.isPlaceholderData)} methodLabel={def?.label} />
            </div>
          )}
        </div>
      </div>
      {change.isError && (
        <Alert tone="danger" className="mt-4">
          {errorMessage(change.error)}
        </Alert>
      )}
    </Modal>
  )
}
