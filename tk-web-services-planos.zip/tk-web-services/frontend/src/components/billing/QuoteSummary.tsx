import clsx from 'clsx'
import { ChevronDown, Gift } from 'lucide-react'
import type { Quote } from '../../api/types'
import { formatDayMonth, formatMoney, formatSignedMoney, perInterval } from '../../lib/format'
import { ChargeLines } from './ChargeLines'
import { Skeleton } from '../ui'

/** Frase simples que resume a pré-visualização (sempre "quanto" e "quando"). */
export function quoteHeadline(q: Quote): string {
  const when = formatDayMonth(q.next_billing_at)
  const net = q.next_invoice_cents
  if (q.kind === 'keep') return 'Ficas no plano atual — a descida agendada é cancelada.'
  if (q.scheduled_at) return `Muda a ${formatDayMonth(q.scheduled_at)}, na renovação. Até lá continuas com o plano atual (já pago).`
  if (q.bonus_applies && q.due_now_cents === 0 && net <= 0) return 'Coberto pelo teu bónus de convites — não pagas nada por isto.'
  if (q.kind === 'change') {
    if (q.due_now_cents > 0) return `Pagas hoje ${formatMoney(q.due_now_cents)} pela diferença.`
    if (net > 0) return `Total: +${formatMoney(net)} na próxima cobrança, a ${when}.`
    if (net < 0) return `Ficas com ${formatMoney(-net)} de crédito, descontado na cobrança de ${when}.`
    return 'Sem diferença a pagar.'
  }
  const wallet = q.wallet_cents ?? 0
  if (q.due_now_cents > 0 && wallet >= q.due_now_cents) return `Pago com o saldo da tua carteira (${formatMoney(wallet)}).`
  if (q.due_now_cents > 0 && wallet > 0)
    return `Pagas hoje ${formatMoney(q.due_now_cents)}: ${formatMoney(wallet)} da carteira e ${formatMoney(q.charge_now_cents ?? 0)} cobrados.`
  if (q.due_now_cents > 0) return `Pagas hoje ${formatMoney(q.due_now_cents)}.`
  if (net > 0) return `Não pagas nada hoje. ${formatMoney(net)} entram na tua próxima cobrança, a ${when}.`
  return 'Não pagas nada hoje.'
}

function todaySub(q: Quote, methodLabel?: string | null): string {
  const wallet = q.wallet_cents ?? 0
  if (q.due_now_cents <= 0) return 'Não pagas nada agora'
  if (wallet >= q.due_now_cents) return 'Sai do saldo da carteira — sem cobrança'
  if (wallet > 0)
    return `${formatMoney(wallet)} da carteira + ${formatMoney(q.charge_now_cents ?? 0)} cobrados${methodLabel ? ` com ${methodLabel}` : ''}`
  return methodLabel ? `Cobrado agora com ${methodLabel}` : 'Cobrado agora'
}

function Row({ label, sub, value, strong, tone }: { label: string; sub?: string; value: string; strong?: boolean; tone?: 'success' }) {
  return (
    <li className="relative flex items-start gap-3 pb-4 pl-6 last:pb-0">
      <span
        className={clsx('absolute left-0 top-1.5 size-2.5 rounded-full ring-4 ring-surface', strong ? 'bg-brand' : 'bg-border-strong')}
        aria-hidden
      />
      <div className="min-w-0 flex-1">
        <p className={clsx('text-sm', strong ? 'font-semibold' : 'text-fg/90')}>{label}</p>
        {sub && <p className="mt-0.5 text-xs text-muted">{sub}</p>}
      </div>
      <span className={clsx('shrink-0 tabular-nums', strong ? 'text-lg font-bold' : 'font-semibold', tone === 'success' && 'text-success')}>{value}</span>
    </li>
  )
}

/**
 * Pré-visualização clara de uma subscrição nova ou mudança de plano:
 * hoje → próxima cobrança → valor recorrente, e as linhas que explicam o cálculo.
 */
export function QuoteSummary({ quote, loading, methodLabel }: { quote: Quote | undefined; loading?: boolean; methodLabel?: string | null }) {
  if (loading || !quote)
    return (
      <div className="space-y-3" aria-busy="true" aria-label="A calcular">
        <Skeleton className="h-5 w-3/4" />
        <Skeleton className="h-28 w-full" />
      </div>
    )
  const q = quote
  if (q.kind === 'keep' || q.scheduled_at)
    return (
      <div className="space-y-4" aria-live="polite">
        <p className="text-base font-semibold leading-snug">{quoteHeadline(q)}</p>
        {q.scheduled_at && (
          <ol className="rounded-2xl border border-border bg-bg/40 p-4 sm:p-5">
            <Row label="Hoje" sub="Nada muda nem é cobrado agora" value={formatMoney(0)} />
            <Row
              label={`A partir de ${formatDayMonth(q.scheduled_at)}`}
              sub="O novo valor entra na renovação e o acesso passa a ser o do novo plano"
              value={`${formatMoney(q.recurring_cents)}${perInterval(q.interval_unit, q.interval_count)}`}
              strong
            />
          </ol>
        )}
      </div>
    )
  const when = formatDayMonth(q.next_billing_at)
  const per = perInterval(q.interval_unit, q.interval_count)
  const net = q.next_invoice_cents
  const isChange = q.kind === 'change'
  const annual = q.interval_unit === 'year'

  return (
    <div className="space-y-4" aria-live="polite">
      <p className="text-base font-semibold leading-snug">{quoteHeadline(q)}</p>

      {q.bonus_applies && (
        <p className="flex items-center gap-2 rounded-xl bg-brand-soft px-3 py-2 text-sm font-medium text-brand-text">
          <Gift className="size-4 shrink-0" aria-hidden /> O teu bónus de convites cobre este serviço.
        </p>
      )}

      <ol className="rounded-2xl border border-border bg-bg/40 p-4 sm:p-5">
        <Row
          label="Hoje"
          sub={todaySub(q, methodLabel)}
          value={formatMoney(q.due_now_cents)}
          strong={q.due_now_cents > 0}
        />
        {net !== 0 && (
          <Row
            label={`Na cobrança de ${when}`}
            sub={
              net < 0
                ? 'Crédito descontado automaticamente'
                : isChange
                  ? 'Diferença pro-rata, somada aos teus outros serviços'
                  : 'Só os dias até lá (pro-rata), numa só cobrança com o resto'
            }
            value={formatSignedMoney(net)}
            strong={q.due_now_cents === 0}
            tone={net < 0 ? 'success' : undefined}
          />
        )}
        <Row
          label={isChange ? 'Novo valor' : annual ? 'Anuidade' : 'Mensalidade'}
          sub={
            isChange
              ? `A partir de ${formatDayMonth(q.period_end)}, no teu dia de faturação`
              : annual
                ? 'Renova uma vez por ano, no teu dia de faturação'
                : `Depois, a cada mês, na mesma cobrança dos outros serviços`
          }
          value={`${formatMoney(q.recurring_cents)}${per}`}
        />
      </ol>

      {isChange ? (
        <div>
          <p className="mb-1 text-xs font-semibold uppercase tracking-wider text-subtle">Como é calculado</p>
          <ChargeLines lines={q.lines} total={undefined} />
        </div>
      ) : (
        <details className="group">
          <summary className="inline-flex cursor-pointer items-center gap-1 text-sm text-muted hover:text-fg">
            <ChevronDown className="size-4 transition-transform group-open:rotate-180" aria-hidden />
            Como é calculado
          </summary>
          <ChargeLines lines={q.lines} className="mt-2" />
        </details>
      )}
    </div>
  )
}
