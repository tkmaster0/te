"""Mudanças de preço com ou sem aviso pelo portal; pagamentos interativos (email de pagamento recebido)

Revision ID: 0009
Revises: 0008
Create Date: 2026-10-08 12:00:00

"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = '0009'
down_revision: Union[str, Sequence[str], None] = '0008'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    with op.batch_alter_table('payments') as batch:
        batch.add_column(sa.Column('interactive', sa.Boolean(), nullable=False, server_default=sa.false()))
    with op.batch_alter_table('price_changes') as batch:
        batch.add_column(sa.Column('notify', sa.Boolean(), nullable=False, server_default=sa.true()))


def downgrade() -> None:
    with op.batch_alter_table('price_changes') as batch:
        batch.drop_column('notify')
    with op.batch_alter_table('payments') as batch:
        batch.drop_column('interactive')
