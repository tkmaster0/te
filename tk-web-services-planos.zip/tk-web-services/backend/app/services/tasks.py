"""Processamento de webhooks e tarefas periódicas."""
from __future__ import annotations

import asyncio
import logging
import time
from datetime import timedelta

from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..assistant import jobs as _assistant_jobs  # noqa: F401  (regista handlers)
from ..config import get_settings
from ..db import sessionmaker, utcnow
from ..models import (
    Checkout,
    EmailToken,
    Invoice,
    Job,
    LoginSession,
    OIDCCode,
    OIDCRefreshToken,
    Payment,
    PriceChange,
    Subscription,
    User,
    WebhookEvent,
)
from ..payments import registry
from ..payments.base import ProviderError
from . import billing, bonus, fulfillment, provisioning  # noqa: F401  (regista handlers)
from .jobs import PermanentError, enqueue, job_handler, recover_stale
from .subscriptions import sweep

log = logging.getLogger("tkportal.tasks")


@job_handler("process_webhook")
async def process_webhook(db: AsyncSession, payload: dict) -> None:
    ev = await db.get(WebhookEvent, payload["id"])
    if ev is None or ev.status == "processed":
        return
    try:
        provider = registry.get(ev.provider)
        if provider is None:
            raise PermanentError(f"fornecedor desconhecido {ev.provider}")
        # Mesmo com o fornecedor desligado no painel, os eventos de pagamentos em curso são processados.
        result = await provider.handle_event(db, ev.payload)
    except Exception as exc:
        await db.rollback()
        ev = await db.get(WebhookEvent, payload["id"])
        if ev:
            ev.error = f"{type(exc).__name__}: {exc}"[:2000]
            ev.status = "failed"
            await db.commit()
        raise
    ev.status = "ignored" if result.startswith("ignored") else "processed"
    ev.error = None if ev.status == "processed" else result
    ev.processed_at = utcnow()


async def cleanup(db: AsyncSession) -> None:
    now = utcnow()
    await db.execute(delete(LoginSession).where(LoginSession.expires_at < now - timedelta(days=7)))
    await db.execute(delete(EmailToken).where(EmailToken.expires_at < now - timedelta(days=7)))
    await db.execute(delete(OIDCCode).where(OIDCCode.expires_at < now - timedelta(hours=1)))
    await db.execute(delete(OIDCRefreshToken).where(OIDCRefreshToken.expires_at < now - timedelta(days=7)))
    await db.execute(delete(Job).where(Job.status == "done", Job.finished_at < now - timedelta(days=14)))
    await db.commit()


async def sync_pending(db: AsyncSession) -> dict:
    """Rede de segurança caso um webhook se perca: confirma pagamentos e checkouts pendentes na API."""
    counts = {"payments": 0, "checkouts": 0}
    now = utcnow()
    for inv in (await db.scalars(select(Invoice).where(Invoice.status == "processing",
                                                       Invoice.created_at < now - timedelta(hours=6)))).all():
        pays = (await db.scalars(select(Payment).where(Payment.invoice_id == inv.id, Payment.status == "pending"))).all()
        for pay in pays:
            provider = registry.get(pay.provider)
            if provider is None or pay.provider_payment_id.startswith("local-"):
                continue
            try:
                res = await provider.fetch_payment(pay.provider_payment_id)
            except (ProviderError, Exception):  # noqa: BLE001
                continue
            if res.status != "processing":
                await billing.apply_payment_result(db, pay, res)
                counts["payments"] += 1
    for co in (await db.scalars(select(Checkout).where(Checkout.status == "pending", Checkout.provider_ref.is_not(None),
                                                       Checkout.created_at > now - timedelta(days=2),
                                                       Checkout.created_at < now - timedelta(minutes=20)))).all():
        try:
            await billing.complete_checkout(db, co)
            await db.commit()
            counts["checkouts"] += 1
        except Exception:  # noqa: BLE001
            await db.rollback()
            continue
    await db.commit()
    return counts


async def send_price_notices(db: AsyncSession) -> int:
    """Envia os avisos de mudanças de preço agendadas aos subscritores afetados (uma vez)."""
    from ..models import ENTITLED_STATUSES, Plan
    from .subscriptions import fmt_date, fmt_money

    n = 0
    for pc in (await db.scalars(select(PriceChange).where(PriceChange.notified_at.is_(None),
                                                          PriceChange.notify.is_not(False),
                                                          PriceChange.cancelled_at.is_(None)))).all():
        plan = await db.get(Plan, pc.plan_id)
        if plan is None:
            continue
        subs = (await db.scalars(select(Subscription).where(
            Subscription.plan_id == plan.id, Subscription.provider == "portal",
            Subscription.status.in_([st.value for st in ENTITLED_STATUSES])))).all()
        for sub in subs:
            if sub.price_cents is not None and sub.price_cents != pc.old_price_cents:
                continue
            user = await db.get(User, sub.user_id)
            if user:
                await fulfillment.queue_email(
                    db, user.email, "price_change", plan=plan.name, effective=fmt_date(pc.effective_at),
                    old_price=fmt_money(pc.old_price_cents), new_price=fmt_money(pc.new_price_cents),
                    interval="ano" if plan.interval_unit == "year" else "mês", note=pc.note,
                    cta_url=f"{get_settings().public_url}/app/servicos")
                n += 1
        pc.notified_at = utcnow()
    await db.commit()
    return n


PERIODIC = [
    # (nome, intervalo em segundos)
    ("billing", 300),
    ("sweep", 300),
    ("price_notices", 900),
    ("check_methods", 1800),
    ("sync_pending", 3600),
    ("recover_stale", 300),
    ("bonus", 3600),
    ("cleanup", 3600),
    ("reconcile_all", 6 * 3600),
    ("assistant_expire", 600),
    ("assistant_learn", 6 * 3600),
    ("legacy_sync", 6 * 3600),
    ("seerr_poll", 120),
]


async def run_periodic(name: str) -> None:
    async with sessionmaker()() as db:
        if name == "billing":
            await billing.schedule_due(db)
        elif name == "check_methods":
            counts = await billing.check_methods(db)
            if any(counts.values()):
                log.info("check_methods: %s", counts)
        elif name == "sync_pending":
            await sync_pending(db)
        elif name == "price_notices":
            await send_price_notices(db)
        elif name == "sweep":
            counts = await sweep(db)
            if any(counts.values()):
                log.info("sweep: %s", counts)
        elif name == "recover_stale":
            await recover_stale(db)
        elif name == "bonus" and get_settings().bonus_enabled:
            await enqueue(db, "bonus_evaluate_all", {}, dedupe_key="bonus_evaluate_all", max_attempts=2)
            await db.commit()
        elif name == "cleanup":
            await cleanup(db)
        elif name == "reconcile_all":
            await enqueue(db, "reconcile_all", {}, dedupe_key="reconcile_all", max_attempts=2)
            await db.commit()
        elif name == "assistant_expire":
            from ..assistant import learning

            await learning.expire_actions(db)
        elif name == "legacy_sync":
            from . import legacy

            n = await legacy.sync_all(db)
            if n:
                log.info("legacy_sync: %d subscrições antigas (GoCardless) verificadas", n)
        elif name == "seerr_poll":
            from ..assistant.channels import seerr as seerr_channel

            await seerr_channel.poll(db)
        elif name == "assistant_learn" and get_settings().assistant_ready:
            await enqueue(db, "assistant_learn", {}, dedupe_key="assistant_learn", max_attempts=2)
            await db.commit()


async def scheduler_loop(stop: asyncio.Event) -> None:
    last: dict[str, float] = {name: 0.0 for name, _ in PERIODIC}
    # O reconcile_all não precisa de correr logo no arranque.
    last["reconcile_all"] = time.monotonic()
    while not stop.is_set():
        now = time.monotonic()
        for name, every in PERIODIC:
            if now - last[name] >= every:
                last[name] = now
                try:
                    await run_periodic(name)
                except Exception:
                    log.exception("Tarefa periódica %s falhou", name)
        try:
            await asyncio.wait_for(stop.wait(), timeout=15)
        except TimeoutError:
            pass


async def job_counts(db: AsyncSession) -> dict:
    from sqlalchemy import func

    rows = (await db.execute(select(Job.status, func.count()).group_by(Job.status))).all()
    return {status: n for status, n in rows}
