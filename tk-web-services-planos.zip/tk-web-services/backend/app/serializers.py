from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from .db import utcnow
from .features import PlanFeatures
from .models import (
    ENTITLED_STATUSES,
    Invoice,
    InvoiceLine,
    Payment,
    PaymentMethod,
    Plan,
    PriceChange,
    Product,
    SiteSetting,
    Subscription,
    SubStatus,
    User,
)
from .schemas import (
    AccessSource,
    InvoiceLineOut,
    InvoiceOut,
    MeOut,
    PaymentMethodOut,
    PaymentOut,
    PlanOut,
    ProductBrief,
    SubscriptionOut,
    UpcomingPriceChange,
)
from .services.subscriptions import compute_access

SITE_DEFAULTS: dict = {
    "announcement": None,
    "support_url": None,
    "support_email": None,
    "terms_url": None,
    "privacy_url": None,
    "apps": [
        {"name": "Jellyfin (Android / Android TV)", "platform": "android",
         "url": "https://play.google.com/store/apps/details?id=org.jellyfin.mobile"},
        {"name": "Jellyfin (iPhone / iPad)", "platform": "ios", "url": "https://apps.apple.com/app/jellyfin-mobile/id1480192618"},
        {"name": "Jellyfin Media Player (PC)", "platform": "desktop", "url": "https://jellyfin.org/downloads/clients/"},
        {"name": "Swiftfin (Apple TV)", "platform": "tvos", "url": "https://apps.apple.com/app/swiftfin/id1604098728"},
    ],
    "faq": [],
    # Textos editados no admin (chave → texto); o que não está aqui usa o texto por omissão do frontend.
    "texts": {},
    # Emails editados no admin (template → {subject, title, body, cta}).
    "emails": {},
}


async def site_settings(db: AsyncSession) -> dict:
    rows = (await db.scalars(select(SiteSetting))).all()
    out = dict(SITE_DEFAULTS)
    out.update({r.key: r.value for r in rows})
    return out


def plan_out(plan: Plan, providers: list[str] | None = None) -> PlanOut:
    from .services.billing import monthly_equivalent

    return PlanOut(
        id=plan.id, code=plan.code, name=plan.name, description=plan.description, price_cents=plan.price_cents,
        currency=plan.currency, interval_unit=plan.interval_unit, interval_count=plan.interval_count,
        monthly_equivalent_cents=round(monthly_equivalent(plan.price_cents, plan)),
        highlights=list(plan.highlights or []), features=PlanFeatures.model_validate(plan.features or {}),
        providers=list(providers or []), product_id=plan.product_id,
    )


def product_brief(p: Product) -> ProductBrief:
    return ProductBrief(id=p.id, code=p.code, name=p.name, kind=p.kind, fulfillment=p.fulfillment or "streaming",
                        icon=p.icon, image_url=p.image_url, jellyfin_managed=bool(p.jellyfin_managed), bonus_eligible=bool(p.bonus_eligible),
                        requires_invite=bool(p.requires_invite))


async def sub_out(db: AsyncSession, sub: Subscription, providers: list[str] | None = None) -> SubscriptionOut:
    from .services.billing import plan_price
    from .services.fulfillment import access_details

    plan = await db.get(Plan, sub.plan_id)
    product = await db.get(Product, sub.product_id)
    assert plan is not None and product is not None
    st = SubStatus(sub.status)
    # "gocardless" = subscrição antiga ainda cobrada pela GoCardless: as ações passam-na sozinha para o portal.
    portal = sub.provider in ("portal", "gocardless")
    pending = await db.get(Plan, sub.pending_plan_id) if sub.pending_plan_id else None
    upcoming = None
    change = await db.scalar(select(PriceChange).where(
        PriceChange.plan_id == plan.id, PriceChange.cancelled_at.is_(None), PriceChange.notify.is_not(False),
        PriceChange.effective_at > utcnow()).order_by(PriceChange.effective_at).limit(1))
    end = sub.access_until or sub.current_period_end
    # Uma subscrição cancelada que termina antes da mudança de preço não é afetada por ela.
    ends_first = st == SubStatus.canceling and change is not None and end is not None and end <= change.effective_at
    if change and not ends_first and (sub.price_cents is None or sub.price_cents == change.old_price_cents) \
            and st in ENTITLED_STATUSES:
        upcoming = UpcomingPriceChange(new_price_cents=change.new_price_cents, effective_at=change.effective_at)
    entitled = st in ENTITLED_STATUSES
    return SubscriptionOut(
        id=sub.id, plan=plan_out(plan, providers), product=product_brief(product), product_name=product.name,
        provider=sub.provider, status=st.value, price_cents=plan_price(sub, plan),
        current_period_start=sub.current_period_start, current_period_end=sub.current_period_end,
        access_until=sub.access_until, grace_until=sub.grace_until, cancel_at_period_end=sub.cancel_at_period_end,
        started_at=sub.started_at, ended_at=sub.ended_at, pending_plan=pending.name if pending else None,
        upcoming_price_change=upcoming, fulfillment_status=sub.fulfillment_status,
        access_details=access_details(sub) if entitled else {},
        access_instructions=product.access_instructions if entitled else None,
        app_url=product.app_url if entitled else None,
        can_cancel=portal and st in (SubStatus.active, SubStatus.past_due, SubStatus.bonus),
        can_resume=portal and st == SubStatus.canceling,
        can_change=portal and st in (SubStatus.active, SubStatus.bonus),
    )


def payment_method_out(pm: PaymentMethod) -> PaymentMethodOut:
    from .payments import registry

    prov = registry.get(pm.provider)
    return PaymentMethodOut(id=pm.id, provider=pm.provider, provider_label=prov.method_label if prov else pm.provider,
                            kind=pm.kind, label=pm.label, status=pm.status, status_reason=pm.status_reason,
                            is_default=pm.is_default, expires_at=pm.expires_at, created_at=pm.created_at)


async def invoice_out(db: AsyncSession, inv: Invoice) -> InvoiceOut:
    lines = (await db.scalars(select(InvoiceLine).where(InvoiceLine.invoice_id == inv.id)
                              .order_by(InvoiceLine.id))).all()
    pm = await db.get(PaymentMethod, inv.payment_method_id) if inv.payment_method_id else None
    return InvoiceOut(
        id=inv.id, number=inv.number, kind=inv.kind, status=inv.status, currency=inv.currency,
        subtotal_cents=inv.subtotal_cents, total_cents=inv.total_cents, created_at=inv.created_at,
        paid_at=inv.paid_at, attempt_count=inv.attempt_count, next_attempt_at=inv.next_attempt_at,
        last_error=inv.last_error, payment_method=pm.label if pm else None,
        lines=[InvoiceLineOut(description=ln.description, amount_cents=ln.amount_cents, kind=ln.kind,
                              period_start=ln.period_start, period_end=ln.period_end) for ln in lines],
    )


def payment_out(p: Payment) -> PaymentOut:
    return PaymentOut(id=p.id, provider=p.provider, amount_cents=p.amount_cents, currency=p.currency, status=p.status,
                      description=p.description, charge_date=p.charge_date, created_at=p.created_at,
                      receipt_url=p.receipt_url)


async def me_out(db: AsyncSession, user: User) -> MeOut:
    access = await compute_access(db, user)
    ref = await db.get(User, user.referred_by_id) if user.referred_by_id else None
    return MeOut(
        id=user.id, username=user.username, email=user.email, display_name=user.display_name,
        email_verified=user.email_verified_at is not None, is_admin=user.is_admin, totp_enabled=user.totp_enabled,
        created_at=user.created_at, has_access=access.any_active, features=access.flags,
        access=[AccessSource(**{k: v for k, v in src.items() if k in AccessSource.model_fields}) for src in access.sources],
        needs_password_sync=user.needs_password_sync and user.jellyfin_password_login,
        referred_by=ref.username if ref else None,
        billing_anchor_day=user.billing_anchor_day, next_billing_at=user.next_billing_at,
        billing_mode=user.billing_mode or "wallet", jellyfin_password_login=bool(user.jellyfin_password_login),
        unlocked_products=list(user.unlocked_products or []),
        wallet_balance_cents=await wallet_balance(db, user.id),
        games_available=_games_available(user),
    )


def _games_available(user: User) -> bool:
    from .games.service import games_available

    return games_available(user)


async def wallet_balance(db: AsyncSession, user_id: str) -> int:
    from .models import Wallet

    w = await db.get(Wallet, user_id)
    return w.balance_cents if w else 0
