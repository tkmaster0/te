"""API de faturação do cliente (faturação consolidada: um método de pagamento, uma cobrança por mês)."""
from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from ..config import get_settings
from ..db import get_db
from ..deps import (
    client_ip,
    rate_limit,
    require_user,
    require_user_any_scope,
    require_verified,
    require_verified_any_scope,
    session_scope,
)
from ..models import (
    ENTITLED_STATUSES,
    USABLE_PM_STATUSES,
    Checkout,
    InviteCode,
    Invoice,
    Payment,
    PaymentMethod,
    Plan,
    Product,
    Subscription,
    SubStatus,
    User,
)
from ..payments import registry
from ..payments.base import ProviderError
from ..schemas import (
    AddPaymentMethodIn,
    ChangePlanIn,
    ChangePlanOut,
    CheckoutStatusOut,
    InvoiceOut,
    Ok,
    PayInvoiceIn,
    PaymentMethodOut,
    PaymentOut,
    ProductOut,
    QuoteOut,
    SubscribeIn,
    SubscribeOut,
    SubscriptionOut,
    UnlockIn,
)
from ..serializers import invoice_out, payment_method_out, payment_out, plan_out, product_brief, sub_out
from ..services import billing
from ..services import catalog as catalog_svc
from ..services import wallet as wallet_svc
from ..services.billing import BillingError
from ..services.jobs import RetryLater
from ..services.subscriptions import fmt_date, fmt_money

log = logging.getLogger("tkportal.billing.api")

catalog_router = APIRouter(prefix="/api/catalog", tags=["catalog"])
router = APIRouter(prefix="/api/billing", tags=["billing"])


def _err(exc: Exception) -> HTTPException:
    if isinstance(exc, BillingError | wallet_svc.WalletError):
        return HTTPException(400, detail=str(exc))
    log.warning("Erro do fornecedor de pagamentos: %s", exc)
    return HTTPException(502, detail="O fornecedor de pagamentos não respondeu. Tenta novamente dentro de instantes.")


PROVIDER_ERRORS = (BillingError, ProviderError, RetryLater, wallet_svc.WalletError)


async def _products(db: AsyncSession, *, streaming_only: bool = False, user: User | None = None
                    ) -> list[ProductOut]:
    """Catálogo visto por este cliente: os produtos em beta fechado que ainda não desbloqueou aparecem com o nome
    genérico (ex.: "TK CDN"), sem planos nem preços."""
    providers = await registry.available_for_new(db)
    q = select(Product).options(selectinload(Product.plans)).where(Product.is_active.is_(True))
    if streaming_only:
        q = q.where(Product.jellyfin_managed.is_(True))
    out = []
    for p in (await db.scalars(q.order_by(Product.sort_order, Product.id))).all():
        plans = [plan_out(pl, providers) for pl in p.plans if pl.is_active and pl.is_public]
        if not plans:
            continue
        b = product_brief(p).model_dump()
        shown = catalog_svc.display(p, catalog_svc.product_unlocked(user, p))
        if shown["locked"]:
            # Nada que denuncie o que é (nem o tipo de entrega): só o nome genérico.
            b.update(name=shown["name"], code=f"locked-{p.id}", kind="beta", icon=None, jellyfin_managed=False,
                     fulfillment="none", bonus_eligible=False, image_url=None)
            out.append(ProductOut(**b, description=shown["description"], locked=True, plans=[]))
        else:
            out.append(ProductOut(**b, description=p.description, plans=plans))
    return out


@catalog_router.get("", response_model=list[ProductOut])
async def catalog(request: Request, convite: str | None = None, db: AsyncSession = Depends(get_db)):
    """Catálogo público. Com `?convite=CÓDIGO` válido mostra também os produtos que esse convite desbloqueia (a
    página de registo aberta por um link de convite do TKFLIX mostra o TKFLIX)."""
    viewer = None
    if convite:
        rate_limit(f"catalog-invite:{client_ip(request)}", 30, 600)
        inv = await db.scalar(select(InviteCode).where(func.upper(InviteCode.code) == convite.strip().upper()))
        if inv is not None and not inv.disabled and inv.uses < inv.max_uses:
            viewer = User(id="", username="", email="", password_hash="", is_admin=False,
                          unlocked_products=await catalog_svc.invite_unlocks(db, inv))
    return await _products(db, user=viewer)


@router.post("/unlock", response_model=Ok)
async def unlock_product(body: UnlockIn, user: User = Depends(require_user), db: AsyncSession = Depends(get_db)):
    """Desbloqueia um produto em beta fechado (ex.: TKFLIX) com um código de convite."""
    rate_limit(f"unlock:{user.id}", 10, 3600)
    try:
        new = await catalog_svc.unlock_with_code(db, user, body.code)
    except catalog_svc.UnlockError as exc:
        await db.rollback()
        raise HTTPException(400, detail=str(exc)) from exc
    names = (await db.scalars(select(Product.name).where(Product.code.in_(new)))).all()
    await db.commit()
    return Ok(message=f"Desbloqueado: {', '.join(names)}. Já podes aderir!")


# =========================================================================== resumo
@router.get("/summary")
async def summary(request: Request, user: User = Depends(require_user_any_scope), db: AsyncSession = Depends(get_db)):
    """Tudo o que o dashboard precisa: próxima cobrança, métodos, avisos."""
    scope = session_scope(request)
    methods = (await db.scalars(select(PaymentMethod).where(PaymentMethod.user_id == user.id,
                                                            PaymentMethod.status != "revoked")
                                .order_by(PaymentMethod.is_default.desc(), PaymentMethod.created_at.desc()))).all()
    usable = await billing.usable_methods(db, user.id)
    live = await billing.live_subs(db, user.id)
    unpaid = await billing.unpaid_invoices(db, user.id)
    state = await registry.state(db)
    actions: list[dict] = []
    preview = await billing.preview_next(db, user)
    wallet_info = await wallet_svc.summary(db, user)
    needs_method = any(s.status != SubStatus.canceling for s in live)
    if needs_method and not usable and not get_settings().billing_require_method \
            and wallet_info["balance_cents"] >= (preview.get("services_cents") or 0) \
            and not wallet_info["monthly_topup_cents"]:
        needs_method = False  # o saldo da carteira cobre a próxima cobrança
    if needs_method and not usable and wallet_info["wallet_only"]:
        actions.append({
            "type": "wallet", "severity": "high",
            "title": "Carrega a carteira",
            "message": "O saldo não chega para a próxima cobrança. Faz um carregamento ou ativa o carregamento mensal.",
            "deadline": user.next_billing_at.isoformat() if user.next_billing_at else None,
        })
    elif needs_method and not usable:
        bad = next((m for m in methods if m.status == "unusable"), None)
        actions.append({
            "type": "payment_method", "severity": "high",
            "title": "Adiciona um método de pagamento",
            "message": (bad.status_reason if bad and bad.status_reason else
                        "Não tens nenhum método de pagamento válido para as próximas cobranças."),
            "deadline": user.next_billing_at.isoformat() if user.next_billing_at else None,
        })
    else:
        for m in methods:
            if m.status == "unusable" and m.is_default is False and needs_method:
                continue
            if m.expires_at and m.status == "active" and m.is_default and usable and usable[0].id == m.id \
                    and user.next_billing_at and m.expires_at <= user.next_billing_at:
                actions.append({"type": "payment_method", "severity": "medium",
                                "title": "O teu cartão vai expirar",
                                "message": f"{m.label} expira antes da próxima cobrança ({fmt_date(user.next_billing_at)}).",
                                "deadline": user.next_billing_at.isoformat()})
    for inv in unpaid:
        actions.append({
            "type": "invoice", "severity": "high", "invoice_id": inv.id,
            "title": f"Cobrança {inv.number} por pagar ({fmt_money(inv.total_cents, inv.currency)})",
            "message": inv.last_error or "O pagamento não foi concluído.",
            "deadline": None,
        })
    for s in live:
        if s.status == SubStatus.past_due and s.grace_until:
            actions.append({"type": "grace", "severity": "high", "subscription_id": s.id,
                            "title": "Serviço em risco de suspensão",
                            "message": f"Regulariza o pagamento até {fmt_date(s.grace_until)} para não perderes o acesso.",
                            "deadline": s.grace_until.isoformat()})
    if scope == "streaming":  # a sessão do Jellyfin só vê o streaming
        streaming_ids = set((await db.scalars(select(Product.id).where(Product.jellyfin_managed.is_(True)))).all())
        preview["lines"] = [ln for ln in preview["lines"] if ln.get("product_id") in streaming_ids]
        preview["total_cents"] = max(0, sum(ln["amount_cents"] for ln in preview["lines"]))
    from ..services.bonus import bonus_status

    return {
        "anchor_day": user.billing_anchor_day,
        "next_billing_at": user.next_billing_at,
        "upcoming": preview,
        "payment_methods": [payment_method_out(m).model_dump() for m in methods],
        "default_payment_method_id": usable[0].id if usable else None,
        "providers": [{"name": n, "label": st["method_label"], "provider_label": st["label"],
                       "available": st["accept_new"]} for n, st in state.items() if st["configured"]],
        "actions": actions,
        "unpaid_invoices": [(await invoice_out(db, i)).model_dump() for i in unpaid],
        "bonus": await bonus_status(db, user),
        "wallet": wallet_info,
        "session_scope": scope,
    }


# =========================================================================== subscrições
async def _visible_subs(db: AsyncSession, user: User, scope: str | None) -> list[Subscription]:
    q = select(Subscription).where(Subscription.user_id == user.id, Subscription.status != SubStatus.pending.value)
    if scope == "streaming":
        q = q.join(Product, Product.id == Subscription.product_id).where(Product.jellyfin_managed.is_(True))
    return list((await db.scalars(q.order_by(Subscription.created_at.desc()).limit(100))).all())


@router.get("/subscriptions", response_model=list[SubscriptionOut])
async def my_subscriptions(request: Request, user: User = Depends(require_user_any_scope),
                           db: AsyncSession = Depends(get_db)):
    providers = await registry.available_for_new(db)
    return [await sub_out(db, s, providers) for s in await _visible_subs(db, user, session_scope(request))]


@router.get("/products", response_model=list[ProductOut])
async def products_for_me(request: Request, user: User = Depends(require_user_any_scope),
                          db: AsyncSession = Depends(get_db)):
    return await _products(db, streaming_only=session_scope(request) == "streaming", user=user)


async def _plan_for(db: AsyncSession, plan_id: int, scope: str | None, user: User | None = None) -> Plan:
    plan = await db.get(Plan, plan_id)
    if plan is None or not plan.is_active or not plan.is_public:
        raise HTTPException(404, detail="Plano indisponível.")
    product = await db.get(Product, plan.product_id)
    if product is None or not product.is_active:
        raise HTTPException(404, detail="Produto indisponível.")
    if user is not None and not catalog_svc.product_unlocked(user, product):
        raise HTTPException(404, detail="Plano indisponível.")
    if scope == "streaming" and not product.jellyfin_managed:
        raise HTTPException(403, detail="A partir do Jellyfin só é possível gerir o streaming.")
    return plan


async def _own_sub(db: AsyncSession, user: User, sub_id: str, scope: str | None) -> Subscription:
    sub = await db.scalar(select(Subscription).where(Subscription.id == sub_id, Subscription.user_id == user.id))
    if sub is None:
        raise HTTPException(404, detail="Subscrição não encontrada.")
    if scope == "streaming":
        product = await db.get(Product, sub.product_id)
        if not (product and product.jellyfin_managed):
            raise HTTPException(403, detail="A partir do Jellyfin só é possível gerir o streaming.")
    return sub


@router.get("/quote", response_model=QuoteOut)
async def quote(request: Request, plan_id: int, subscription_id: str | None = None,
                user: User = Depends(require_user_any_scope), db: AsyncSession = Depends(get_db)):
    """Pré-visualização de quanto se paga (e quando) ao subscrever ou mudar de plano."""
    scope = session_scope(request)
    plan = await _plan_for(db, plan_id, scope, user)
    if subscription_id:
        sub = await _own_sub(db, user, subscription_id, scope)
        if plan.product_id != sub.product_id:
            raise HTTPException(400, detail="Plano inválido para esta subscrição.")
        q = await billing.quote_change(db, user, sub, plan)
    else:
        q = await billing.quote_new(db, user, plan)
    out = q.as_dict()
    out["requires_payment_method"] = (await billing.default_method(db, user.id)) is None
    w = await wallet_svc.get_wallet(db, user.id)
    out["wallet_only"] = wallet_svc.is_wallet_only(user)
    out["monthly_enabled"] = wallet_svc.monthly_enabled()
    out["monthly_topup_cents"] = w.monthly_topup_cents if wallet_svc.monthly_enabled() else None
    extra = 0 if subscription_id else round(billing.monthly_equivalent(plan.price_cents, plan))
    out["suggested_monthly_cents"] = wallet_svc.suggest_monthly(
        await wallet_svc.monthly_recurring_cents(db, user.id) + extra)
    await db.commit()
    return out


@router.post("/subscribe", response_model=SubscribeOut)
async def subscribe(body: SubscribeIn, request: Request, user: User = Depends(require_verified_any_scope),
                    db: AsyncSession = Depends(get_db)):
    rate_limit(f"subscribe:{user.id}", 10, 600)
    scope = session_scope(request)
    plan = await _plan_for(db, body.plan_id, scope, user)
    method = None
    if body.payment_method_id:
        method = await db.get(PaymentMethod, body.payment_method_id)
        if method is None or method.user_id != user.id or method.status not in USABLE_PM_STATUSES:
            raise HTTPException(400, detail="Método de pagamento inválido.")
    else:
        method = await billing.default_method(db, user.id)
    try:
        quote = await billing.quote_new(db, user, plan)
        covered = quote.wallet_balance_cents >= quote.due_now_cents + quote.next_invoice_cents
        wants_monthly = bool(body.monthly_topup_cents) and scope != "streaming" and wallet_svc.monthly_enabled()
        # Sem método autorizado vai sempre ao fornecedor (mandato GoCardless ou cartão Stripe): é a autorização
        # única — daí em diante o portal cobra o valor certo em cada ciclo.
        needs_setup = get_settings().billing_require_method or not covered or wants_monthly
        if method is None and needs_setup:
            if not body.provider:
                raise BillingError("Escolhe como queres pagar.")
            # Verifica já as regras (produto repetido, dívida) antes de mandar o cliente para o fornecedor.
            if await billing.live_sub_for_product(db, user.id, plan.product_id):
                raise BillingError("Já tens este serviço — usa 'Mudar de plano'.")
            if await billing.unpaid_invoices(db, user.id):
                raise BillingError("Tens uma cobrança por pagar. Regulariza-a primeiro em Faturação.")
            intent = {"action": "subscribe", "plan_id": plan.id}
            if wants_monthly:
                intent["monthly_topup_cents"] = int(body.monthly_topup_cents or 0)
            res = await billing.start_method_setup(db, user, body.provider, intent=intent, scope=scope)
            return SubscribeOut(status="redirect", **res)
        if wants_monthly:
            await wallet_svc.set_monthly(db, user, int(body.monthly_topup_cents or 0), skip_when_covered=True)
        sub = await billing.subscribe(db, user, plan, method=method, scope=scope)
        await db.commit()
    except PROVIDER_ERRORS as exc:
        await db.rollback()
        raise _err(exc) from exc
    if sub.status == SubStatus.pending:  # o fornecedor não respondeu: a cobrança foi agendada
        return SubscribeOut(status="active", subscription_id=sub.id,
                            message=f"Estamos a processar o pagamento de {plan.name} — o serviço fica ativo assim "
                                    "que for confirmado.")
    return SubscribeOut(status="active", subscription_id=sub.id, message=f"{plan.name} ativo. Bom proveito!")


@router.post("/subscriptions/{sub_id}/change", response_model=ChangePlanOut)
async def change_plan(sub_id: str, body: ChangePlanIn, request: Request,
                      user: User = Depends(require_verified_any_scope), db: AsyncSession = Depends(get_db)):
    rate_limit(f"change-plan:{user.id}", 10, 3600)
    scope = session_scope(request)
    sub = await _own_sub(db, user, sub_id, scope)
    plan = await _plan_for(db, body.plan_id, scope, user)
    try:
        q = await billing.change_plan(db, user, sub, plan, scope=scope)
        await db.commit()
    except PROVIDER_ERRORS as exc:
        await db.rollback()
        raise _err(exc) from exc
    msg = billing.change_message(plan.name, q)
    out = q.as_dict()
    return ChangePlanOut(message=msg, quote=out)


@router.post("/subscriptions/{sub_id}/cancel", response_model=Ok)
async def cancel_subscription(sub_id: str, request: Request, user: User = Depends(require_user_any_scope),
                              db: AsyncSession = Depends(get_db)):
    scope = session_scope(request)
    sub = await _own_sub(db, user, sub_id, scope)
    try:
        await billing.cancel(db, user, sub, scope=scope)
        await db.commit()
    except BillingError as exc:
        await db.rollback()
        raise _err(exc) from exc
    return Ok(message=f"Cancelado. Manténs o acesso até {fmt_date(sub.access_until or sub.current_period_end)} e não "
                      "voltas a ser cobrado.")


@router.post("/subscriptions/{sub_id}/resume", response_model=Ok)
async def resume_subscription(sub_id: str, request: Request, user: User = Depends(require_user_any_scope),
                              db: AsyncSession = Depends(get_db)):
    scope = session_scope(request)
    sub = await _own_sub(db, user, sub_id, scope)
    try:
        await billing.resume(db, user, sub, scope=scope)
        await db.commit()
    except BillingError as exc:
        await db.rollback()
        raise _err(exc) from exc
    return Ok(message="Reativado — continua tudo como antes.")


# =========================================================================== métodos de pagamento
@router.get("/payment-methods", response_model=list[PaymentMethodOut])
async def payment_methods(user: User = Depends(require_user_any_scope), db: AsyncSession = Depends(get_db)):
    rows = (await db.scalars(select(PaymentMethod).where(PaymentMethod.user_id == user.id,
                                                         PaymentMethod.status != "revoked")
                             .order_by(PaymentMethod.is_default.desc(), PaymentMethod.created_at.desc()))).all()
    return [payment_method_out(m) for m in rows]


@router.post("/payment-methods")
async def add_payment_method(body: AddPaymentMethodIn, user: User = Depends(require_verified),
                             db: AsyncSession = Depends(get_db)):
    rate_limit(f"add-pm:{user.id}", 10, 3600)
    try:
        return await billing.start_method_setup(db, user, body.provider)
    except PROVIDER_ERRORS as exc:
        await db.rollback()
        raise _err(exc) from exc


async def _own_method(db: AsyncSession, user: User, pm_id: str) -> PaymentMethod:
    pm = await db.get(PaymentMethod, pm_id)
    if pm is None or pm.user_id != user.id:
        raise HTTPException(404, detail="Método não encontrado.")
    return pm


@router.post("/payment-methods/{pm_id}/default", response_model=Ok)
async def make_default(pm_id: str, user: User = Depends(require_user), db: AsyncSession = Depends(get_db)):
    pm = await _own_method(db, user, pm_id)
    try:
        await billing.set_default(db, user, pm)
        await db.commit()
    except BillingError as exc:
        raise _err(exc) from exc
    return Ok(message=f"{pm.label} é agora o método predefinido.")


@router.delete("/payment-methods/{pm_id}", response_model=Ok)
async def delete_method(pm_id: str, user: User = Depends(require_user), db: AsyncSession = Depends(get_db)):
    pm = await _own_method(db, user, pm_id)
    try:
        await billing.remove_method(db, user, pm)
        await db.commit()
    except BillingError as exc:
        await db.rollback()
        raise _err(exc) from exc
    return Ok(message="Método removido.")


# =========================================================================== checkouts (regresso do fornecedor)
@router.get("/checkout/{checkout_id}", response_model=CheckoutStatusOut)
async def checkout_status(checkout_id: str, user: User = Depends(require_user_any_scope),
                          db: AsyncSession = Depends(get_db)):
    co = await db.scalar(select(Checkout).where(Checkout.id == checkout_id, Checkout.user_id == user.id))
    if co is None:
        raise HTTPException(404, detail="Pedido não encontrado.")
    if co.status == "pending":
        rate_limit(f"checkout-poll:{co.id}", 90, 600)
        try:
            await billing.complete_checkout(db, co)
            await db.commit()
        except Exception as exc:  # noqa: BLE001 — o webhook trata disto de qualquer forma
            await db.rollback()
            # Depois do rollback os objetos da sessão estão expirados: usar o id guardado e recarregar.
            log.info("Checkout %s ainda não concluído: %s", checkout_id, exc)
        co = await db.get(Checkout, checkout_id, populate_existing=True)
        assert co is not None
    inv = await db.get(Invoice, co.invoice_id) if co.invoice_id else None
    action = (co.intent or {}).get("action")
    if co.session_scope == "streaming":
        return_to = "/app/streaming"
    elif action == "monthly_topup" or (inv is not None and inv.kind == "topup"):
        return_to = "/app/carteira"
    elif action == "subscribe":
        return_to = "/app/servicos"
    else:
        return_to = "/app/faturacao"
    return CheckoutStatusOut(id=co.id, status=co.status, purpose=co.purpose, provider=co.provider,
                             subscription_id=(co.intent or {}).get("subscription_id"), invoice_id=co.invoice_id,
                             error=co.error, return_to=return_to)


# =========================================================================== cobranças
@router.get("/invoices", response_model=list[InvoiceOut])
async def invoices(user: User = Depends(require_user), db: AsyncSession = Depends(get_db)):
    rows = (await db.scalars(select(Invoice).where(Invoice.user_id == user.id, Invoice.status != "void")
                             .order_by(Invoice.created_at.desc()).limit(60))).all()
    return [await invoice_out(db, i) for i in rows]


@router.get("/invoices/{invoice_id}", response_model=InvoiceOut)
async def invoice_detail(invoice_id: str, user: User = Depends(require_user), db: AsyncSession = Depends(get_db)):
    inv = await db.get(Invoice, invoice_id)
    if inv is None or inv.user_id != user.id:
        raise HTTPException(404, detail="Cobrança não encontrada.")
    return await invoice_out(db, inv)


@router.post("/invoices/{invoice_id}/pay")
async def pay_invoice(invoice_id: str, body: PayInvoiceIn, user: User = Depends(require_verified),
                      db: AsyncSession = Depends(get_db)):
    """Pagar já uma cobrança em atraso: com um método guardado, ou num fornecedor (redireciona)."""
    rate_limit(f"pay:{user.id}", 10, 600)
    inv = await db.get(Invoice, invoice_id)
    if inv is None or inv.user_id != user.id:
        raise HTTPException(404, detail="Cobrança não encontrada.")
    if inv.status not in billing.UNPAID_INVOICE:
        raise HTTPException(400, detail="Esta cobrança já não está por pagar.")
    try:
        if body.provider:
            return await billing.start_invoice_payment(db, user, inv, body.provider)
        pm = await _own_method(db, user, body.payment_method_id) if body.payment_method_id else \
            await billing.default_method(db, user.id)
        if pm is None:
            raise BillingError("Adiciona um método de pagamento ou escolhe um fornecedor.")
        if pm.status not in USABLE_PM_STATUSES:
            raise BillingError("Esse método não pode ser usado.")
        status = await billing.charge_invoice(db, inv, method=pm, interactive=True)
        await db.commit()
    except PROVIDER_ERRORS as exc:
        await db.rollback()
        raise _err(exc) from exc
    msgs = {"paid": "Pagamento concluído — obrigado!",
            "processing": "Pagamento submetido. Pode demorar alguns dias úteis a confirmar (débito direto).",
            "failed": f"O pagamento falhou: {inv.last_error or 'tenta outro método'}"}
    return {"status": status, "message": msgs.get(status, status)}


@router.get("/payments", response_model=list[PaymentOut])
async def my_payments(user: User = Depends(require_user), db: AsyncSession = Depends(get_db)):
    rows = (await db.scalars(select(Payment).where(Payment.user_id == user.id)
                             .order_by(Payment.created_at.desc()).limit(100))).all()
    return [payment_out(p) for p in rows]


__all__ = ["ENTITLED_STATUSES", "catalog_router", "router"]
