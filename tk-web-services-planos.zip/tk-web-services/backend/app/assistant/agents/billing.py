"""Agente de Faturação — só cobranças, planos, preços, métodos de pagamento e bónus de convites.

Não tem nenhuma ferramenta do Jellyfin/Seerr/Bazarr e as regras proíbem-no de falar de funcionalidades do
streaming. O que sabe sobre produtos e preços é lido do catálogo em cada conversa: um serviço novo criado no
painel fica logo conhecido, sem mexer em nada.
"""
from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import selectinload

from ...config import get_settings
from ...models import Invoice, PaymentMethod, Plan, Product, Subscription, SubStatus
from ...services.catalog import display, product_unlocked
from ...payments import registry
from ...services import billing
from ...services.billing import BillingError
from ...services.bonus import bonus_status
from ...services.subscriptions import fmt_date, fmt_money
from ..tools import ToolContext, ToolFailure, ToolRegistry, obj
from .base import COMMON_RULES, Agent, add_common_tools

reg = ToolRegistry("billing")
add_common_tools(reg, other="support", other_label="Agente de Suporte (streaming, apps, legendas, conteúdos)")

STATUS = {"active": "ativa", "past_due": "pagamento em atraso", "canceling": "cancelada (acesso até ao fim do período)",
          "bonus": "grátis pelo bónus de convites", "suspended": "suspensa por falta de pagamento",
          "ended": "terminada", "pending": "a aguardar confirmação do pagamento"}
INVOICE_STATUS = {"open": "por cobrar", "processing": "em processamento (débito submetido)", "paid": "paga",
                  "failed": "falhada (vamos tentar de novo)", "void": "anulada"}
INTERVAL = {"month": "mês", "year": "ano", "week": "semana"}

RULES = COMMON_RULES + """
És o **Agente de Faturação da TK Web Services** (o portal onde o cliente subscreve o TKFLIX e outros serviços TK). Tratas EXCLUSIVAMENTE de:
subscrições (aderir, mudar de plano, cancelar, reativar), preços e periodicidade, a cobrança mensal única e o que
inclui, faturas/cobranças e o seu estado, pagamentos falhados e prazos, métodos de pagamento (débito direto SEPA /
cartão), pro-ratas e créditos, mudanças de preço anunciadas, e o bónus de convites enquanto regra de cobrança.

É PROIBIDO falares de funcionalidades ou conteúdos do streaming ou de qualquer serviço (filmes, séries, canais,
qualidade, legendas, apps, dispositivos, contas do Jellyfin/Seerr, pedidos, problemas técnicos). Nem para
comparar planos: sobre planos dizes só nome, preço e periodicidade; para saber o que cada plano inclui, indica a
página Loja do portal. Qualquer questão desse tipo → transfer_to_support.

Nunca prometes reembolsos, descontos ou exceções: explicas as regras e, se o cliente insistir, escalate_to_human.
Para pagar uma cobrança em atraso ou adicionar/trocar método de pagamento, dás o link do portal
(get_portal_link) — os dados de pagamento nunca passam pelo chat.
"""

DEFAULT_INSTRUCTIONS = """\
- Começa por perceber o que o cliente quer; se for sobre valores ou datas, consulta get_billing_overview antes de responder.
- Quando o cliente quer mudar de plano ou aderir, mostra primeiro o orçamento (quote_plan) com o valor a pagar já
  e o valor normal por período, e só depois propõe a ação.
- Antes de propor um cancelamento, pergunta (uma vez, sem insistir) se é por algum problema que o suporte possa
  resolver; respeita a decisão.
- Valores sempre em euros com vírgula (ex.: 7,50 €) e datas no formato dd/mm/aaaa.
"""


def _in_scope(ctx: ToolContext, product: Product | None) -> bool:
    return ctx.scope != "streaming" or bool(product and product.jellyfin_managed)


async def _plan_in_scope(ctx: ToolContext, plan_id) -> Plan:
    try:
        pid = int(plan_id)
    except (TypeError, ValueError) as exc:
        raise ToolFailure("plan_id inválido — usa get_catalog para ver os planos.") from exc
    plan = await ctx.db.get(Plan, pid)
    if plan is None or not plan.is_active or not plan.is_public:
        raise ToolFailure("Esse plano não existe ou não está disponível.")
    product = await ctx.db.get(Product, plan.product_id)
    if product is None or not product.is_active:
        raise ToolFailure("Esse serviço não está disponível.")
    if not _in_scope(ctx, product):
        raise ToolFailure("Aqui (a partir do Jellyfin) só é possível gerir a subscrição de streaming. Os outros "
                          "serviços geram-se no portal.")
    if not product_unlocked(ctx.user, product):
        raise ToolFailure("Esse serviço está em beta fechado — o cliente pode desbloqueá-lo na Loja com um código de "
                          "convite.")
    return plan


async def _sub_for(ctx: ToolContext, subscription_id: str | None = None, plan: Plan | None = None) -> Subscription | None:
    user = ctx.require_user()
    if subscription_id is not None and not subscription_id:
        raise ToolFailure("Falta o subscription_id — usa get_billing_overview.")
    subs = await billing.live_subs(ctx.db, user.id)
    for s in subs:
        prod = await ctx.db.get(Product, s.product_id)
        if not _in_scope(ctx, prod):
            continue
        if subscription_id and s.id == subscription_id:
            return s
        if plan is not None and s.product_id == plan.product_id:
            return s
    if subscription_id:
        raise ToolFailure("Subscrição não encontrada nesta conta.")
    return None


async def _own_sub(ctx: ToolContext, args: dict) -> Subscription:
    sub = await _sub_for(ctx, subscription_id=str(args.get("subscription_id") or ""))
    if sub is None:  # pragma: no cover — _sub_for já levanta ToolFailure com um id
        raise ToolFailure("Subscrição não encontrada nesta conta.")
    return sub


# =========================================================================== leitura
@reg.tool("get_billing_overview",
          "Resumo da faturação do cliente: subscrições e estado, próxima cobrança (data, total e linhas), métodos "
          "de pagamento, cobranças por pagar e bónus de convites.")
async def overview(ctx: ToolContext, args: dict):
    db, user = ctx.db, ctx.require_user()
    subs = []
    for s in await billing.live_subs(db, user.id):
        prod = await db.get(Product, s.product_id)
        if not _in_scope(ctx, prod):
            continue
        plan = await db.get(Plan, s.plan_id)
        assert plan and prod
        pending = await db.get(Plan, s.pending_plan_id) if s.pending_plan_id else None
        subs.append({
            "subscription_id": s.id, "service": prod.name, "plan": plan.name, "plan_id": plan.id,
            "status": STATUS.get(s.status, s.status),
            "price": f"{fmt_money(billing.plan_price(s, plan), plan.currency)}/{INTERVAL.get(plan.interval_unit)}",
            "current_period_end": fmt_date(s.current_period_end),
            "access_until": fmt_date(s.access_until) if s.access_until else None,
            "grace_until": fmt_date(s.grace_until) if s.grace_until else None,
            "next_plan_at_renewal": pending.name if pending else None,
            "managed_elsewhere": s.provider != "portal",
        })
    preview = await billing.preview_next(db, user)
    lines = preview["lines"]
    hidden = 0
    if ctx.scope == "streaming":
        keep = []
        for ln in lines:
            prod = await db.get(Product, ln["product_id"]) if ln.get("product_id") else None
            if prod is None or prod.jellyfin_managed or ln["kind"] == "bonus":
                keep.append(ln)
            else:
                hidden += 1
        lines = keep
    methods = (await db.scalars(select(PaymentMethod).where(PaymentMethod.user_id == user.id,
                                                            PaymentMethod.status != "revoked")
                                .order_by(PaymentMethod.is_default.desc()))).all()
    unpaid = await billing.unpaid_invoices(db, user.id)
    bonus = await bonus_status(db, user)
    return {
        "billing_day_of_month": user.billing_anchor_day,
        "subscriptions": subs or "sem subscrições ativas",
        "next_charge": {
            "date": fmt_date(user.next_billing_at) if user.next_billing_at else None,
            "total": fmt_money(preview["total_cents"]),
            "lines": [f"{ln['description']}: {fmt_money(ln['amount_cents'])}" for ln in lines],
            **({"note": f"inclui mais {hidden} linha(s) de outros serviços (ver no portal)"} if hidden else {}),
        },
        "payment_methods": [{"label": m.label, "status": {"active": "ativo", "pending": "a aguardar confirmação do banco",
                                                          "unusable": "inutilizável"}.get(m.status, m.status),
                             "reason": m.status_reason, "default": m.is_default,
                             "expires": fmt_date(m.expires_at) if m.expires_at else None} for m in methods]
        or "nenhum método guardado",
        "unpaid_charges": [{"number": i.number, "total": fmt_money(i.total_cents, i.currency),
                            "status": INVOICE_STATUS.get(i.status, i.status),
                            "next_attempt": fmt_date(i.next_attempt_at) if i.next_attempt_at else None,
                            "last_error": i.last_error} for i in unpaid],
        "invite_bonus": {"paying_invitees": bonus["active_invitees"], "needed": bonus["threshold"],
                         "active": bonus["eligible"], "program_enabled": bonus["enabled"]},
    }


@reg.tool("list_charges", "Histórico das cobranças do cliente (número, data, estado, total e linhas).",
          obj({"limit": {"type": "integer", "minimum": 1, "maximum": 24}}))
async def list_charges(ctx: ToolContext, args: dict):
    user = ctx.require_user()
    limit = max(1, min(int(args.get("limit") or 6), 24))
    rows = (await ctx.db.scalars(select(Invoice).options(selectinload(Invoice.lines))
                                 .where(Invoice.user_id == user.id, Invoice.status != "void")
                                 .order_by(Invoice.created_at.desc()).limit(limit))).all()
    if not rows:
        return "Ainda não há cobranças."
    out = []
    for inv in rows:
        item = {"number": inv.number, "date": fmt_date(inv.created_at), "status": INVOICE_STATUS.get(inv.status),
                "total": fmt_money(inv.total_cents, inv.currency),
                "paid_at": fmt_date(inv.paid_at) if inv.paid_at else None, "error": inv.last_error}
        if ctx.scope != "streaming":
            item["lines"] = [f"{ln.description}: {fmt_money(ln.amount_cents)}" for ln in inv.lines]
        out.append(item)
    return out


@reg.tool("get_catalog",
          "Serviços e planos disponíveis agora (nome, preço, periodicidade, plan_id). Usa isto em vez de "
          "memorizar preços: o catálogo muda.", requires_user=False)
async def catalog(ctx: ToolContext, args: dict):
    q = select(Product).options(selectinload(Product.plans)).where(Product.is_active.is_(True))
    if ctx.scope == "streaming":
        q = q.where(Product.jellyfin_managed.is_(True))
    out = []
    for p in (await ctx.db.scalars(q.order_by(Product.sort_order, Product.id))).all():
        if not product_unlocked(ctx.user, p):
            shown = display(p, False)
            out.append({"service": shown["name"], "status": shown["description"],
                        "note": "Beta fechado: só com código de convite (Loja → Tens um código de convite?)."})
            continue
        plans = [{"plan_id": pl.id, "name": pl.name,
                  "price": f"{fmt_money(pl.price_cents, pl.currency)}/"
                           f"{(str(pl.interval_count) + ' ') if pl.interval_count > 1 else ''}"
                           f"{INTERVAL.get(pl.interval_unit, pl.interval_unit)}"}
                 for pl in p.plans if pl.is_active and pl.is_public]
        if plans:
            out.append({"service": p.name, "plans": plans})
    return {"services": out, "details": "O que cada plano inclui está na página Loja do portal (/app/loja)."}


@reg.tool("quote_plan",
          "Orçamento para aderir a um plano ou mudar para ele (pro-rata, créditos, quanto paga já e quanto paga "
          "por período depois).", obj({"plan_id": {"type": "integer"}}, ["plan_id"]))
async def quote(ctx: ToolContext, args: dict):
    user = ctx.require_user()
    plan = await _plan_in_scope(ctx, args.get("plan_id"))
    sub = await _sub_for(ctx, plan=plan)
    if sub is not None:
        if sub.plan_id == plan.id:
            return "O cliente já está neste plano."
        if sub.status not in (SubStatus.active, SubStatus.bonus):
            return f"A subscrição atual está '{STATUS.get(sub.status)}' — só dá para mudar de plano com ela ativa."
        q = await billing.quote_change(ctx.db, user, sub, plan)
    else:
        q = await billing.quote_new(ctx.db, user, plan)
    if q.scheduled_at:
        return {"type": "descida de plano (na renovação)", "starts_on": fmt_date(q.scheduled_at),
                "pay_now": fmt_money(0), "until_then": "mantém o plano atual, já pago; o acesso muda nessa data",
                "regular_price": f"{fmt_money(q.recurring_cents)}/{INTERVAL.get(q.interval_unit)}"}
    return {
        "type": "mudança de plano" if q.kind == "change" else "nova subscrição",
        "lines": [f"{ln['description']}: {fmt_money(ln['amount_cents'])}" for ln in q.lines],
        "pay_now": fmt_money(q.due_now_cents), "added_to_next_charge": fmt_money(q.next_invoice_cents),
        "next_charge_date": fmt_date(q.next_billing_at),
        "regular_price": f"{fmt_money(q.recurring_cents)}/{INTERVAL.get(q.interval_unit)}",
        "invite_bonus_applies": q.bonus_applies,
    }


@reg.tool("get_portal_link",
          "Link do portal para o cliente fazer algo que não se faz no chat: pagar uma cobrança em atraso, "
          "adicionar/trocar método de pagamento, ver faturas, ou gerir outros serviços.",
          obj({"purpose": {"type": "string", "enum": ["pay", "payment_method", "invoices", "services", "store"]}},
              ["purpose"]), requires_user=False)
async def portal_link(ctx: ToolContext, args: dict):
    path = {"pay": "/app/faturacao", "payment_method": "/app/faturacao#metodos", "invoices": "/app/faturacao",
            "services": "/app/servicos", "store": "/app/loja"}.get(str(args.get("purpose")), "/app")
    if ctx.channel == "web":
        return {"link": path}
    return {"link": f"{get_settings().public_url}{path}",
            "note": "O cliente tem de iniciar sessão no portal (a sessão do Jellyfin não serve para pagamentos)."}


# =========================================================================== ações (com confirmação)
async def _sum_change(ctx: ToolContext, args: dict) -> str:
    user = ctx.require_user()
    plan = await _plan_in_scope(ctx, args.get("plan_id"))
    sub = await _sub_for(ctx, plan=plan)
    if sub is None:
        q = await billing.quote_new(ctx.db, user, plan)
        pay = f"pagas {fmt_money(q.due_now_cents)} agora" if q.due_now_cents else \
            f"{fmt_money(q.next_invoice_cents)} entram na próxima cobrança"
        return f"Aderir a {plan.name} — {pay}; depois {fmt_money(q.recurring_cents)}/{INTERVAL.get(q.interval_unit)}."
    if sub.plan_id == plan.id:
        raise ToolFailure("O cliente já está neste plano.")
    if sub.status not in (SubStatus.active, SubStatus.bonus):
        raise ToolFailure("Só é possível mudar de plano com a subscrição ativa e em dia.")
    q = await billing.quote_change(ctx.db, user, sub, plan)
    if q.scheduled_at:
        return (f"Passar para {plan.name} a {fmt_date(q.scheduled_at)} (na renovação) — até lá mantém o plano "
                f"atual, sem custos; depois {fmt_money(q.recurring_cents)}/{INTERVAL.get(q.interval_unit)}.")
    net = q.due_now_cents + q.next_invoice_cents
    diff = (f"diferença de {fmt_money(net)} " + ("cobrada agora" if q.due_now_cents else "na próxima cobrança")) \
        if net > 0 else (f"crédito de {fmt_money(-net)} na próxima cobrança" if net < 0 else "sem diferença a pagar")
    return f"Mudar para {plan.name} já — {diff}; depois {fmt_money(q.recurring_cents)}/{INTERVAL.get(q.interval_unit)}."


@reg.tool("change_or_subscribe_plan",
          "Adere a um plano (se o cliente ainda não tem o serviço) ou muda para ele (se já tem). Subir de plano é "
          "imediato, com pro-rata; descer só acontece na renovação (até lá mantém o atual, já pago). "
          "Fica pendente até o cliente confirmar.", obj({"plan_id": {"type": "integer"}}, ["plan_id"]),
          confirm=True, summary=_sum_change)
async def change_or_subscribe(ctx: ToolContext, args: dict):
    user = ctx.require_user()
    plan = await _plan_in_scope(ctx, args.get("plan_id"))
    sub = await _sub_for(ctx, plan=plan)
    try:
        if sub is None:
            method = await billing.default_method(ctx.db, user.id)
            if method is None:
                raise ToolFailure(f"Falta um método de pagamento. Adiciona-o em {get_settings().public_url}"
                                  "/app/faturacao e depois volta a pedir.")
            new = await billing.subscribe(ctx.db, user, plan, method=method, scope=ctx.scope)
            await ctx.db.commit()
            if new.status == SubStatus.pending:
                return f"Pedido feito: {plan.name} fica ativo assim que o pagamento for confirmado."
            return f"{plan.name} ativo. 🎉"
        q = await billing.change_plan(ctx.db, user, sub, plan, scope=ctx.scope)
        await ctx.db.commit()
    except BillingError as exc:
        await ctx.db.rollback()
        raise ToolFailure(str(exc)) from exc  # o runtime marca a ação como falhada
    return billing.change_message(plan.name, q)


async def _sum_cancel(ctx: ToolContext, args: dict) -> str:
    sub = await _own_sub(ctx, args)
    if sub.status not in (SubStatus.active, SubStatus.bonus, SubStatus.past_due) or sub.provider != "portal":
        raise ToolFailure("Esta subscrição não pode ser cancelada aqui.")
    plan = await ctx.db.get(Plan, sub.plan_id)
    return (f"Cancelar {plan.name if plan else 'a subscrição'} — deixas de ser cobrado e manténs o acesso até "
            f"{fmt_date(sub.current_period_end)}. Podes reativar até lá.")


@reg.tool("cancel_subscription",
          "Cancela uma subscrição no fim do período pago. Fica pendente até o cliente confirmar.",
          obj({"subscription_id": {"type": "string"}}, ["subscription_id"]), confirm=True, summary=_sum_cancel)
async def cancel(ctx: ToolContext, args: dict):
    user = ctx.require_user()
    sub = await _own_sub(ctx, args)
    try:
        await billing.cancel(ctx.db, user, sub, scope=ctx.scope)
        await ctx.db.commit()
    except BillingError as exc:
        await ctx.db.rollback()
        raise ToolFailure(str(exc)) from exc  # o runtime marca a ação como falhada
    return f"Cancelado. Manténs o acesso até {fmt_date(sub.access_until or sub.current_period_end)}."


async def _sum_resume(ctx: ToolContext, args: dict) -> str:
    sub = await _own_sub(ctx, args)
    if sub.status != SubStatus.canceling:
        raise ToolFailure("Esta subscrição não está cancelada.")
    plan = await ctx.db.get(Plan, sub.plan_id)
    return f"Reativar {plan.name if plan else 'a subscrição'} — volta a renovar normalmente em {fmt_date(sub.current_period_end)}."


@reg.tool("resume_subscription", "Reativa uma subscrição cancelada que ainda não terminou. Pede confirmação.",
          obj({"subscription_id": {"type": "string"}}, ["subscription_id"]), confirm=True, summary=_sum_resume)
async def resume(ctx: ToolContext, args: dict):
    user = ctx.require_user()
    sub = await _own_sub(ctx, args)
    try:
        await billing.resume(ctx.db, user, sub, scope=ctx.scope)
        await ctx.db.commit()
    except BillingError as exc:
        await ctx.db.rollback()
        raise ToolFailure(str(exc)) from exc  # o runtime marca a ação como falhada
    return "Reativado — continua tudo como antes."


# =========================================================================== factos vivos
async def live_facts(ctx: ToolContext) -> str:
    s = get_settings()
    st = await registry.state(ctx.db)
    methods = [f"{v['method_label']} ({v['label']})" for v in st.values() if v.get("accept_new")]
    q = select(Product).options(selectinload(Product.plans)).where(Product.is_active.is_(True))
    if ctx.scope == "streaming":
        q = q.where(Product.jellyfin_managed.is_(True))
    services = []
    for p in (await ctx.db.scalars(q.order_by(Product.sort_order, Product.id))).all():
        if not product_unlocked(ctx.user, p):
            shown = display(p, False)
            services.append(f"- {shown['name']}: {shown['description']} (só com código de convite; não reveles o "
                            "nome verdadeiro nem os planos)")
            continue
        plans = ", ".join(f"{pl.name} {fmt_money(pl.price_cents, pl.currency)}/{INTERVAL.get(pl.interval_unit)}"
                          for pl in p.plans if pl.is_active and pl.is_public)
        if plans:
            extra = "" if p.bonus_eligible else " (não coberto pelo bónus)"
            services.append(f"- {p.name}{extra}: {plans}")
    retry = ", ".join(str(d) for d in s.retry_days)
    monthly_txt = ((" Carregamento mensal (uma só cobrança no dia de faturação; o que sobra fica na carteira)"
                    + (f"; bónus de {s.wallet_monthly_bonus_percent}% nos carregamentos mensais"
                       if s.wallet_monthly_bonus_percent else "") + ".")
                   if s.wallet_monthly_enabled else " Não há carregamento mensal.")
    facts = f"""\
Factos atuais do sistema (lidos agora, prevalecem sobre qualquer outra fonte):
- Cobrança única: todos os serviços do cliente são cobrados juntos, uma vez por mês, no mesmo dia (o "dia de
  faturação", fixado na primeira subscrição). Planos anuais renovam no dia de faturação do mês respetivo.
- Aderir a um serviço a meio do mês: paga-se só a parte até ao dia de faturação (pro-rata){'; a primeira compra é cobrada logo' if s.charge_first_purchase_immediately else ''}.
- Mudar de plano: crédito do tempo não usado do plano antigo + pro-rata do novo; a diferença vai {'para a próxima cobrança' if s.proration_charge == 'next_invoice' else 'ser cobrada logo'}.
- Valores abaixo de {fmt_money(s.billing_min_charge_cents)} passam para a cobrança seguinte (evita taxas).
- Pagamento falhado: novas tentativas {retry} dias depois; o acesso mantém-se durante {s.grace_period_days} dias de
  tolerância ({s.payment_method_grace_days} se o método de pagamento deixou de funcionar); depois o serviço é suspenso
  e volta assim que a cobrança for paga.
- Cancelar: não há mais cobranças e o acesso mantém-se até ao fim do período já pago; pode reativar até lá.
- Mudanças de preço são avisadas com pelo menos {s.price_change_notice_days} dias; quem já subscreve mantém o preço até lá.
- Bónus de convites: {'ativo' if s.bonus_enabled else 'desativado'}. Quem tiver {s.bonus_threshold} convidados a pagar
  ({s.bonus_threshold_admin_referred} se foi convidado pelo administrador) deixa de pagar os serviços cobertos pelo bónus;
  quando os convidados deixam de pagar, a cobrança é retomada.
- Métodos de pagamento aceites agora: {', '.join(methods) or 'nenhum (contactar o suporte)'}.
- Carteira de créditos ({'ativa' if s.wallet_enabled else 'desativada'}): 1 crédito = 1 €. O saldo paga primeiro todas
  as cobranças; o que faltar é cobrado ao método de pagamento na mesma cobrança. Carregamento único a partir de
  {fmt_money(s.wallet_min_topup_cents)}.{monthly_txt}
- Aderir exige uma autorização de pagamento única (mandato de débito direto SEPA pela GoCardless ou cartão pela
  Stripe). A partir daí o portal cobra sozinho o valor certo em cada mês e ajusta-o quando o cliente adere, muda de
  plano ou cancela (com pro-rata) — o cliente não tem de voltar a autorizar nada.
- Serviços e planos à venda{' (só streaming neste canal)' if ctx.scope == 'streaming' else ''}:
{chr(10).join(services) or '- (nenhum)'}"""
    if ctx.user is not None:
        facts += f"\n- Cliente: {ctx.user.display_name or ctx.user.username}; dia de faturação: {ctx.user.billing_anchor_day or 'ainda não definido'}."
        if s.wallet_enabled:
            from ...models import Wallet

            w = await ctx.db.get(Wallet, ctx.user.id)
            from ...services import wallet as wallet_svc

            if wallet_svc.monthly_enabled():
                facts += (f"\n- Carteira do cliente: saldo {fmt_money(w.balance_cents if w else 0)}; carregamento mensal "
                          f"{fmt_money(w.monthly_topup_cents) if w and w.monthly_topup_cents else 'desligado'}; "
                          f"{'só carteira (conta nova)' if ctx.user.billing_mode == 'wallet' else 'cliente antigo'}.")
            else:
                facts += (f"\n- Carteira do cliente: saldo {fmt_money(w.balance_cents if w else 0)} (usado antes de "
                          "qualquer cobrança). Não há carregamento mensal: os serviços são cobrados pelo método "
                          "autorizado (débito direto GoCardless ou cartão Stripe), com o valor ajustado pelo portal "
                          "conforme o cliente adere, muda ou cancela.")
    return facts


AGENT = Agent(name="billing", label="Faturação", registry=reg, rules=RULES,
              default_instructions=DEFAULT_INSTRUCTIONS, live_facts=live_facts)
